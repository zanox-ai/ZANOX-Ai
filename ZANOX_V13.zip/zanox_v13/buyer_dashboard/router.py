"""
ZANOX V13 - Buyer Dashboard Router
"""
from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Query, Path, Body, status
from pydantic import BaseModel, Field

from shared.database import get_db_session
from shared.cache import cache_get, cache_set, cache_delete
from shared.models import ResponseModel, PaginationParams, PaginatedResponse
from shared.utils import generate_id
from .service import BuyerDashboardService

router = APIRouter()
service = BuyerDashboardService()


class CreateRequest(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    status: str = "active"
    metadata: dict = {}


class UpdateRequest(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[str] = None
    metadata: Optional[dict] = None


@router.get("/", response_model=ResponseModel)
async def list_items(
    page: int = Query(1, ge=1),
    size: int = Query(20, ge=1, le=100),
    status: Optional[str] = None,
):
    filters = {}
    if status:
        filters["status"] = status
    result = await service.list(page=page, size=size, filters=filters if filters else None)
    return ResponseModel(data=result)


@router.post("/", response_model=ResponseModel, status_code=status.HTTP_201_CREATED)
async def create_item(request: CreateRequest):
    data = request.model_dump()
    result = await service.create(data)
    return ResponseModel(data=result, message="Item created successfully")


@router.get("/{item_id}", response_model=ResponseModel)
async def get_item(item_id: str = Path(...)):
    result = await service.get(item_id)
    if not result:
        raise HTTPException(status_code=404, detail="Item not found")
    return ResponseModel(data=result)


@router.patch("/{item_id}", response_model=ResponseModel)
async def update_item(item_id: str, request: UpdateRequest):
    update_data = {k: v for k, v in request.model_dump().items() if v is not None}
    if not update_data:
        raise HTTPException(status_code=400, detail="No fields to update")
    result = await service.update(item_id, update_data)
    if not result:
        raise HTTPException(status_code=404, detail="Item not found")
    return ResponseModel(data=result, message="Item updated successfully")


@router.delete("/{item_id}", response_model=ResponseModel)
async def delete_item(item_id: str):
    success = await service.delete(item_id)
    if not success:
        raise HTTPException(status_code=404, detail="Item not found")
    return ResponseModel(message="Item deleted successfully")


@router.get("/health", response_model=ResponseModel)
async def health_check():
    healthy = await service.health_check()
    return ResponseModel(data={"healthy": healthy})
