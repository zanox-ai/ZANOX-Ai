"""
ZANOX V13 - Commerce & Marketplace Layer
Main FastAPI Application Entry Point
"""

import asyncio
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import ORJSONResponse

from marketplace_engine.router import router as marketplace_router
from product_management.router import router as product_router
from product_builder.router import router as builder_router
from catalog.router import router as catalog_router
from search.router import router as search_router
from recommendations.router import router as recommendations_router
from analytics.router import router as analytics_router
from licensing.router import router as licensing_router
from drm.router import router as drm_router
from versioning.router import router as versioning_router
from inventory.router import router as inventory_router
from vendors.router import router as vendors_router
from seller_dashboard.router import router as seller_dashboard_router
from buyer_dashboard.router import router as buyer_dashboard_router
from orders.router import router as orders_router
from cart.router import router as cart_router
from checkout.router import router as checkout_router
from subscriptions.router import router as subscriptions_router
from memberships.router import router as memberships_router
from affiliate.router import router as affiliate_router
from referral.router import router as referral_router
from commissions.router import router as commissions_router
from coupons.router import router as coupons_router
from discounts.router import router as discounts_router
from revenue.router import router as revenue_router
from payouts.router import router as payouts_router
from invoices.router import router as invoices_router
from tax.router import router as tax_router
from payments.router import router as payments_router
from payment_routing.router import router as payment_routing_router
from reviews.router import router as reviews_router
from ratings.router import router as ratings_router
from trust.router import router as trust_router
from fraud_detection.router import router as fraud_router
from disputes.router import router as disputes_router
from notifications.router import router as notifications_router
from email_delivery.router import router as email_router
from file_delivery.router import router as file_delivery_router
from license_delivery.router import router as license_delivery_router
from distribution.router import router as distribution_router
from security.router import router as security_router
from governance.router import router as governance_router
from compliance.router import router as compliance_router
from monitoring.router import router as monitoring_router

from shared.database import init_db, close_db
from shared.cache import init_cache, close_cache
from shared.search import init_search, close_search
from shared.messaging import init_messaging, close_messaging
from shared.config import get_settings


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager."""
    settings = get_settings()
    await init_db()
    await init_cache()
    await init_search()
    await init_messaging()
    yield
    await close_messaging()
    await close_search()
    await close_cache()
    await close_db()


app = FastAPI(
    title="ZANOX V13 - Commerce & Marketplace Layer",
    description="Complete digital commerce ecosystem for creating, managing, selling, distributing, licensing and monetizing digital products.",
    version="13.0.0",
    docs_url="/v13/docs",
    redoc_url="/v13/redoc",
    openapi_url="/v13/openapi.json",
    default_response_class=ORJSONResponse,
    lifespan=lifespan,
)

app.add_middleware(GZipMiddleware, minimum_size=1000)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register all routers
routers = [
    (marketplace_router, "/v13/marketplace", "Marketplace"),
    (product_router, "/v13/products", "Products"),
    (builder_router, "/v13/builder", "Product Builder"),
    (catalog_router, "/v13/catalog", "Catalog"),
    (search_router, "/v13/search", "Search"),
    (recommendations_router, "/v13/recommendations", "Recommendations"),
    (analytics_router, "/v13/analytics", "Analytics"),
    (licensing_router, "/v13/licensing", "Licensing"),
    (drm_router, "/v13/drm", "DRM"),
    (versioning_router, "/v13/versioning", "Versioning"),
    (inventory_router, "/v13/inventory", "Inventory"),
    (vendors_router, "/v13/vendors", "Vendors"),
    (seller_dashboard_router, "/v13/seller", "Seller Dashboard"),
    (buyer_dashboard_router, "/v13/buyer", "Buyer Dashboard"),
    (orders_router, "/v13/orders", "Orders"),
    (cart_router, "/v13/cart", "Cart"),
    (checkout_router, "/v13/checkout", "Checkout"),
    (subscriptions_router, "/v13/subscriptions", "Subscriptions"),
    (memberships_router, "/v13/memberships", "Memberships"),
    (affiliate_router, "/v13/affiliate", "Affiliate"),
    (referral_router, "/v13/referral", "Referral"),
    (commissions_router, "/v13/commissions", "Commissions"),
    (coupons_router, "/v13/coupons", "Coupons"),
    (discounts_router, "/v13/discounts", "Discounts"),
    (revenue_router, "/v13/revenue", "Revenue"),
    (payouts_router, "/v13/payouts", "Payouts"),
    (invoices_router, "/v13/invoices", "Invoices"),
    (tax_router, "/v13/tax", "Tax"),
    (payments_router, "/v13/payments", "Payments"),
    (payment_routing_router, "/v13/payment-routing", "Payment Routing"),
    (reviews_router, "/v13/reviews", "Reviews"),
    (ratings_router, "/v13/ratings", "Ratings"),
    (trust_router, "/v13/trust", "Trust & Reputation"),
    (fraud_router, "/v13/fraud", "Fraud Detection"),
    (disputes_router, "/v13/disputes", "Disputes"),
    (notifications_router, "/v13/notifications", "Notifications"),
    (email_router, "/v13/email", "Email Delivery"),
    (file_delivery_router, "/v13/file-delivery", "File Delivery"),
    (license_delivery_router, "/v13/license-delivery", "License Delivery"),
    (distribution_router, "/v13/distribution", "Distribution"),
    (security_router, "/v13/security", "Security"),
    (governance_router, "/v13/governance", "Governance"),
    (compliance_router, "/v13/compliance", "Compliance"),
    (monitoring_router, "/v13/monitoring", "Monitoring"),
]

for router, prefix, tag in routers:
    app.include_router(router, prefix=prefix, tags=[tag])


@app.get("/v13/health", tags=["Health"])
async def health_check():
    return {"status": "healthy", "version": "13.0.0", "layer": "commerce_marketplace"}


@app.get("/v13/stats", tags=["Stats"])
async def layer_stats():
    return {
        "version": "13.0.0",
        "layer": "commerce_marketplace",
        "modules": len(routers),
        "features": [
            "marketplace_engine",
            "product_management",
            "product_builder",
            "catalog",
            "search",
            "recommendations",
            "analytics",
            "licensing",
            "drm",
            "versioning",
            "inventory",
            "vendors",
            "seller_dashboard",
            "buyer_dashboard",
            "orders",
            "cart",
            "checkout",
            "subscriptions",
            "memberships",
            "affiliate",
            "referral",
            "commissions",
            "coupons",
            "discounts",
            "revenue",
            "payouts",
            "invoices",
            "tax",
            "payments",
            "payment_routing",
            "reviews",
            "ratings",
            "trust",
            "fraud_detection",
            "disputes",
            "notifications",
            "email_delivery",
            "file_delivery",
            "license_delivery",
            "distribution",
            "security",
            "governance",
            "compliance",
            "monitoring",
        ],
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8130, reload=True)
