"""
ZANOX V13 - Marketplace Engine Models
"""
from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field

from shared.models import ProductTypeEnum, ProductStatusEnum, Money, TimestampedModel


class MarketplaceListing(BaseModel):
    id: str
    product_id: str
    vendor_id: str
    name: str
    description: str
    type: ProductTypeEnum
    category: str
    tags: List[str] = []
    price: Money
    compare_at_price: Optional[Money] = None
    currency: str = "USD"
    status: ProductStatusEnum = ProductStatusEnum.PUBLISHED
    featured: bool = False
    trending: bool = False
    badge: Optional[str] = None
    rating: float = Field(0.0, ge=0.0, le=5.0)
    review_count: int = 0
    sales_count: int = 0
    view_count: int = 0
    thumbnail_url: Optional[str] = None
    preview_urls: List[str] = []
    metadata: Dict[str, Any] = {}
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    published_at: Optional[datetime] = None


class MarketplaceCategory(BaseModel):
    id: str
    name: str
    slug: str
    description: Optional[str] = None
    parent_id: Optional[str] = None
    image_url: Optional[str] = None
    product_count: int = 0
    sort_order: int = 0
    is_active: bool = True
    metadata: Dict[str, Any] = {}
    created_at: datetime = Field(default_factory=datetime.utcnow)


class MarketplaceFeaturedSection(BaseModel):
    id: str
    name: str
    title: str
    subtitle: Optional[str] = None
    section_type: str = "collection"  # collection, category, vendor, custom
    entity_id: Optional[str] = None
    product_ids: List[str] = []
    display_order: int = 0
    is_active: bool = True
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)


class MarketplaceTrendingItem(BaseModel):
    product_id: str
    rank: int
    score: float
    sales_velocity: float
    view_velocity: float
    period: str = "24h"
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class MarketplaceDiscoveryFilter(BaseModel):
    query: Optional[str] = None
    type: Optional[ProductTypeEnum] = None
    category: Optional[str] = None
    min_price: Optional[float] = None
    max_price: Optional[float] = None
    rating: Optional[float] = None
    vendor_id: Optional[str] = None
    tags: Optional[List[str]] = None
    sort_by: str = "relevance"  # relevance, price_asc, price_desc, newest, popular, rating
    page: int = Field(1, ge=1)
    size: int = Field(20, ge=1, le=100)


class MarketplaceStats(BaseModel):
    total_products: int = 0
    total_vendors: int = 0
    total_sales: int = 0
    total_revenue: float = 0.0
    active_listings: int = 0
    pending_review: int = 0
    today_sales: int = 0
    today_revenue: float = 0.0
