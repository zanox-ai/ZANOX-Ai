"""
ZANOX V13 - Marketplace Engine Service
"""
import asyncio
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any

from sqlalchemy import select, and_, or_, func, desc, asc
from sqlalchemy.ext.asyncio import AsyncSession

from shared.database import get_session
from shared.cache import cache_get, cache_set, cache_delete, cache_flush_pattern
from shared.search import search_documents, index_document
from shared.messaging import publish_marketplace_event
from shared.utils import generate_id, slugify, paginate
from shared.models import ProductTypeEnum, ProductStatusEnum
from .models import *


class MarketplaceEngineService:
    CACHE_PREFIX = "marketplace:"

    async def get_listing(self, listing_id: str) -> Optional[Dict[str, Any]]:
        cache_key = f"{self.CACHE_PREFIX}listing:{listing_id}"
        cached = await cache_get(cache_key)
        if cached:
            return cached

        async with get_session() as session:
            from shared.database import Base
            result = await session.execute(
                select(Base.metadata.tables["marketplace_listings"]).where(
                    Base.metadata.tables["marketplace_listings"].c.id == listing_id
                )
            )
            row = result.mappings().first()
            if row:
                data = dict(row)
                await cache_set(cache_key, data, ttl=3600)
                return data
            return None

    async def create_listing(self, data: MarketplaceListing) -> Dict[str, Any]:
        listing_data = data.model_dump()
        listing_data["id"] = generate_id("lst_")
        listing_data["slug"] = slugify(data.name)
        listing_data["created_at"] = datetime.utcnow().isoformat()
        listing_data["updated_at"] = datetime.utcnow().isoformat()

        if data.status == ProductStatusEnum.PUBLISHED:
            listing_data["published_at"] = datetime.utcnow().isoformat()

        async with get_session() as session:
            from shared.database import Base
            await session.execute(
                Base.metadata.tables["marketplace_listings"].insert().values(**listing_data)
            )

        await index_document("products", listing_data["id"], listing_data)
        await publish_marketplace_event("listing.created", {"listing_id": listing_data["id"]})
        await cache_delete(f"{self.CACHE_PREFIX}listings:*")

        return listing_data

    async def update_listing(self, listing_id: str, data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        data["updated_at"] = datetime.utcnow().isoformat()

        async with get_session() as session:
            from shared.database import Base
            await session.execute(
                Base.metadata.tables["marketplace_listings"]
                .update()
                .where(Base.metadata.tables["marketplace_listings"].c.id == listing_id)
                .values(**data)
            )

        await index_document("products", listing_id, data)
        await cache_delete(f"{self.CACHE_PREFIX}listing:{listing_id}")
        await cache_delete(f"{self.CACHE_PREFIX}listings:*")

        return await self.get_listing(listing_id)

    async def delete_listing(self, listing_id: str) -> bool:
        async with get_session() as session:
            from shared.database import Base
            result = await session.execute(
                Base.metadata.tables["marketplace_listings"]
                .delete()
                .where(Base.metadata.tables["marketplace_listings"].c.id == listing_id)
            )
            deleted = result.rowcount > 0

        if deleted:
            from shared.search import delete_document
            await delete_document("products", listing_id)
            await cache_delete(f"{self.CACHE_PREFIX}listing:{listing_id}")
            await cache_flush_pattern(f"{self.CACHE_PREFIX}*")

        return deleted

    async def discover(self, filters: MarketplaceDiscoveryFilter) -> Dict[str, Any]:
        cache_key = (
            f"{self.CACHE_PREFIX}discover:"
            f"q={filters.query}:t={filters.type}:c={filters.category}:"
            f"min={filters.min_price}:max={filters.max_price}:"
            f"r={filters.rating}:v={filters.vendor_id}:"
            f"sort={filters.sort_by}:p={filters.page}:s={filters.size}"
        )

        cached = await cache_get(cache_key)
        if cached:
            return cached

        es_filters = {"status": "published"}
        if filters.type:
            es_filters["type"] = filters.type.value
        if filters.category:
            es_filters["category"] = filters.category
        if filters.vendor_id:
            es_filters["vendor_id"] = filters.vendor_id
        if filters.min_price is not None or filters.max_price is not None:
            es_filters["price"] = {}
            if filters.min_price is not None:
                es_filters["price"]["gte"] = filters.min_price
            if filters.max_price is not None:
                es_filters["price"]["lte"] = filters.max_price
        if filters.rating:
            es_filters["rating"] = {"gte": filters.rating}

        query = None
        if filters.query:
            query = {
                "multi_match": {
                    "query": filters.query,
                    "fields": ["name^3", "description", "tags^2", "vendor_name"],
                    "type": "best_fields",
                }
            }

        sort_mapping = {
            "newest": [{"created_at": "desc"}],
            "price_asc": [{"price": "asc"}],
            "price_desc": [{"price": "desc"}],
            "popular": [{"sales_count": "desc"}],
            "rating": [{"rating": "desc"}],
        }
        sort = sort_mapping.get(filters.sort_by)

        result = await search_documents(
            "products",
            query=query,
            filters=es_filters,
            sort=sort,
            page=filters.page,
            size=filters.size,
        )

        await cache_set(cache_key, result, ttl=300)
        return result

    async def get_trending(self, period: str = "24h", limit: int = 20) -> List[Dict[str, Any]]:
        cache_key = f"{self.CACHE_PREFIX}trending:{period}:{limit}"
        cached = await cache_get(cache_key)
        if cached:
            return cached

        async with get_session() as session:
            from shared.database import Base
            table = Base.metadata.tables["marketplace_listings"]
            result = await session.execute(
                select(table)
                .where(table.c.status == "published")
                .order_by(desc(table.c.sales_count))
                .limit(limit)
            )
            items = [dict(row) for row in result.mappings()]

        await cache_set(cache_key, items, ttl=1800)
        return items

    async def get_featured(self) -> List[Dict[str, Any]]:
        cache_key = f"{self.CACHE_PREFIX}featured"
        cached = await cache_get(cache_key)
        if cached:
            return cached

        async with get_session() as session:
            from shared.database import Base
            table = Base.metadata.tables["marketplace_listings"]
            result = await session.execute(
                select(table)
                .where(and_(table.c.status == "published", table.c.featured == True))
                .order_by(desc(table.c.created_at))
                .limit(20)
            )
            items = [dict(row) for row in result.mappings()]

        await cache_set(cache_key, items, ttl=3600)
        return items

    async def get_categories(self, parent_id: Optional[str] = None) -> List[Dict[str, Any]]:
        cache_key = f"{self.CACHE_PREFIX}categories:{parent_id or 'root'}"
        cached = await cache_get(cache_key)
        if cached:
            return cached

        async with get_session() as session:
            from shared.database import Base
            table = Base.metadata.tables["marketplace_categories"]
            if parent_id:
                result = await session.execute(
                    select(table).where(table.c.parent_id == parent_id)
                )
            else:
                result = await session.execute(
                    select(table).where(table.c.parent_id.is_(None))
                )
            items = [dict(row) for row in result.mappings()]

        await cache_set(cache_key, items, ttl=3600)
        return items

    async def get_stats(self) -> Dict[str, Any]:
        cache_key = f"{self.CACHE_PREFIX}stats"
        cached = await cache_get(cache_key)
        if cached:
            return cached

        async with get_session() as session:
            from shared.database import Base
            listings = Base.metadata.tables["marketplace_listings"]

            total = await session.execute(select(func.count()).select_from(listings))
            active = await session.execute(
                select(func.count()).select_from(listings).where(listings.c.status == "published")
            )
            pending = await session.execute(
                select(func.count()).select_from(listings).where(listings.c.status == "pending_review")
            )
            revenue = await session.execute(
                select(func.sum(listings.c.price_amount)).select_from(listings)
            )

            stats = {
                "total_products": total.scalar() or 0,
                "active_listings": active.scalar() or 0,
                "pending_review": pending.scalar() or 0,
                "total_revenue": float(revenue.scalar() or 0),
            }

        await cache_set(cache_key, stats, ttl=300)
        return stats

    async def increment_view(self, listing_id: str) -> bool:
        async with get_session() as session:
            from shared.database import Base
            table = Base.metadata.tables["marketplace_listings"]
            await session.execute(
                table.update()
                .where(table.c.id == listing_id)
                .values(view_count=table.c.view_count + 1)
            )
        await cache_delete(f"{self.CACHE_PREFIX}listing:{listing_id}")
        return True
