"""
ZANOX V13 - Marketplace Engine Router
"""
from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Query, Path, Body, status
from pydantic import BaseModel, Field

from shared.database import get_db_session
from shared.cache import cache_get, cache_set, cache_delete
from shared.models import ResponseModel, PaginationParams, PaginatedResponse
from shared.utils import generate_id
from .models import *
from .service import MarketplaceEngineService

router = APIRouter()
service = MarketplaceEngineService()


class ListingCreateRequest(BaseModel):
    product_id: str
    vendor_id: str
    name: str
    description: str
    type: str
    category: str
    tags: List[str] = []
    price_amount: float = Field(..., ge=0)
    currency: str = "USD"
    compare_at_price: Optional[float] = None
    featured: bool = False
    thumbnail_url: Optional[str] = None
    preview_urls: List[str] = []
    metadata: dict = {}


class ListingUpdateRequest(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    category: Optional[str] = None
    tags: Optional[List[str]] = None
    price_amount: Optional[float] = None
    compare_at_price: Optional[float] = None
    status: Optional[str] = None
    featured: Optional[bool] = None
    thumbnail_url: Optional[str] = None
    preview_urls: Optional[List[str]] = None
    metadata: Optional[dict] = None


@router.get("/listings", response_model=ResponseModel)
async def list_listings(
    page: int = Query(1, ge=1),
    size: int = Query(20, ge=1, le=100),
    status: Optional[str] = None,
    vendor_id: Optional[str] = None,
    category: Optional[str] = None,
    featured: Optional[bool] = None,
):
    from sqlalchemy import select, and_
    from shared.database import get_session, Base
    async with get_session() as session:
        table = Base.metadata.tables["marketplace_listings"]
        query = select(table)
        conditions = []
        if status:
            conditions.append(table.c.status == status)
        if vendor_id:
            conditions.append(table.c.vendor_id == vendor_id)
        if category:
            conditions.append(table.c.category == category)
        if featured is not None:
            conditions.append(table.c.featured == featured)
        if conditions:
            query = query.where(and_(*conditions))

        count_result = await session.execute(select(func.count()).select_from(query.subquery()))
        total = count_result.scalar()

        query = query.offset((page - 1) * size).limit(size)
        result = await session.execute(query)
        items = [dict(row) for row in result.mappings()]

    return ResponseModel(
        data={"items": items, "total": total, "page": page, "size": size,
              "pages": (total + size - 1) // size}
    )


@router.get("/listings/{listing_id}", response_model=ResponseModel)
async def get_listing(listing_id: str = Path(...)):
    listing = await service.get_listing(listing_id)
    if not listing:
        raise HTTPException(status_code=404, detail="Listing not found")
    await service.increment_view(listing_id)
    return ResponseModel(data=listing)


@router.post("/listings", response_model=ResponseModel, status_code=status.HTTP_201_CREATED)
async def create_listing(request: ListingCreateRequest):
    listing = MarketplaceListing(
        id=generate_id("lst_"),
        product_id=request.product_id,
        vendor_id=request.vendor_id,
        name=request.name,
        description=request.description,
        type=request.type,
        category=request.category,
        tags=request.tags,
        price={"amount": request.price_amount, "currency": request.currency},
        compare_at_price={"amount": request.compare_at_price, "currency": request.currency} if request.compare_at_price else None,
        currency=request.currency,
        featured=request.featured,
        thumbnail_url=request.thumbnail_url,
        preview_urls=request.preview_urls,
        metadata=request.metadata,
    )
    result = await service.create_listing(listing)
    return ResponseModel(data=result, message="Listing created successfully")


@router.patch("/listings/{listing_id}", response_model=ResponseModel)
async def update_listing(listing_id: str, request: ListingUpdateRequest):
    update_data = {k: v for k, v in request.model_dump().items() if v is not None}
    if not update_data:
        raise HTTPException(status_code=400, detail="No fields to update")
    result = await service.update_listing(listing_id, update_data)
    if not result:
        raise HTTPException(status_code=404, detail="Listing not found")
    return ResponseModel(data=result, message="Listing updated successfully")


@router.delete("/listings/{listing_id}", response_model=ResponseModel)
async def delete_listing(listing_id: str):
    success = await service.delete_listing(listing_id)
    if not success:
        raise HTTPException(status_code=404, detail="Listing not found")
    return ResponseModel(message="Listing deleted successfully")


@router.post("/discover", response_model=ResponseModel)
async def discover(request: MarketplaceDiscoveryFilter):
    results = await service.discover(request)
    return ResponseModel(data=results)


@router.get("/trending", response_model=ResponseModel)
async def get_trending(
    period: str = Query("24h", pattern="^(24h|7d|30d)$"),
    limit: int = Query(20, ge=1, le=100),
):
    items = await service.get_trending(period, limit)
    return ResponseModel(data={"items": items, "period": period})


@router.get("/featured", response_model=ResponseModel)
async def get_featured():
    items = await service.get_featured()
    return ResponseModel(data={"items": items})


@router.get("/categories", response_model=ResponseModel)
async def get_categories(parent_id: Optional[str] = None):
    items = await service.get_categories(parent_id)
    return ResponseModel(data={"items": items})


@router.get("/stats", response_model=ResponseModel)
async def get_stats():
    stats = await service.get_stats()
    return ResponseModel(data=stats)
