# ZANOX V13 - Deployment Guide

## Prerequisites

- Docker 24.0+
- Docker Compose 2.20+
- Kubernetes 1.28+ (for production)
- Helm 3.12+ (optional)

## Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `ZANOX_V13_DATABASE_URL` | PostgreSQL connection string | `postgresql+asyncpg://zanox:zanox_pass@localhost:5432/zanox_v13` |
| `ZANOX_V13_REDIS_URL` | Redis connection string | `redis://localhost:6379/13` |
| `ZANOX_V13_ELASTICSEARCH_URL` | Elasticsearch URL | `http://localhost:9200` |
| `ZANOX_V13_MESSAGING_URL` | Message queue URL | `redis://localhost:6379/14` |
| `ZANOX_V13_ENV` | Environment | `production` |
| `ZANOX_V13_DEBUG` | Debug mode | `false` |
| `ZANOX_V13_PORT` | Server port | `8130` |
| `ZANOX_V13_JWT_SECRET` | JWT signing secret | Required |
| `ZANOX_V13_STRIPE_SECRET_KEY` | Stripe API key | Optional |
| `ZANOX_V13_PAYPAL_CLIENT_ID` | PayPal client ID | Optional |

## Docker Deployment

### Development
```bash
docker-compose up -d
```

### Production
```bash
docker-compose -f docker-compose.yml up -d --scale zanox-v13=3
```

## Kubernetes Deployment

### Create Namespace
```bash
kubectl create namespace zanox
```

### Apply Configurations
```bash
kubectl apply -f deployment/k8s-configmap.yaml
kubectl apply -f deployment/k8s-deployment.yaml
```

### Verify
```bash
kubectl get pods -n zanox -l app=zanox-v13-commerce
kubectl get svc -n zanox
kubectl get ingress -n zanox
```

### Scaling
```bash
kubectl scale deployment zanox-v13-commerce --replicas=5 -n zanox
```

## Monitoring

### Prometheus
Prometheus configuration is in `deployment/prometheus.yml`.

### Grafana
Import dashboard from `deployment/grafana-dashboard.json`.

## Health Checks

- Liveness: `GET /v13/health`
- Readiness: `GET /v13/health`
- Metrics: `GET /v13/metrics`
