# ZANOX V13 - API Reference

## Base URL
```
/v13
```

## Authentication
All endpoints require a valid JWT token in the Authorization header:
```
Authorization: Bearer <token>
```

## Core Endpoints

### Health & Status
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/v13/health` | Health check |
| GET | `/v13/stats` | Layer statistics |

### Marketplace
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/v13/marketplace/listings` | List all listings |
| POST | `/v13/marketplace/listings` | Create listing |
| GET | `/v13/marketplace/listings/{id}` | Get listing |
| PATCH | `/v13/marketplace/listings/{id}` | Update listing |
| DELETE | `/v13/marketplace/listings/{id}` | Delete listing |
| POST | `/v13/marketplace/discover` | Discover products |
| GET | `/v13/marketplace/trending` | Trending items |
| GET | `/v13/marketplace/featured` | Featured items |
| GET | `/v13/marketplace/categories` | Get categories |
| GET | `/v13/marketplace/stats` | Marketplace stats |

### Products
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/v13/products/` | List products |
| POST | `/v13/products/` | Create product |
| GET | `/v13/products/{id}` | Get product |
| PATCH | `/v13/products/{id}` | Update product |
| DELETE | `/v13/products/{id}` | Delete product |

### Catalog
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/v13/catalog/categories` | List categories |
| POST | `/v13/catalog/categories` | Create category |
| GET | `/v13/catalog/categories/tree` | Category tree |
| POST | `/v13/catalog/browse` | Browse catalog |

### Search
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/v13/search/` | Search products |
| GET | `/v13/search/suggest` | Search suggestions |
| POST | `/v13/search/facets` | Search facets |

### Recommendations
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/v13/recommendations/` | Get recommendations |
| GET | `/v13/recommendations/similar/{id}` | Similar products |
| GET | `/v13/recommendations/frequently-bought/{id}` | Frequently bought |
| GET | `/v13/recommendations/trending` | Trending |

### Cart
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/v13/cart/` | Get cart |
| POST | `/v13/cart/items` | Add item |
| PATCH | `/v13/cart/items/{id}` | Update item |
| DELETE | `/v13/cart/items/{id}` | Remove item |
| POST | `/v13/cart/clear` | Clear cart |
| POST | `/v13/cart/apply-coupon` | Apply coupon |

### Checkout
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/v13/checkout/` | Initiate checkout |
| POST | `/v13/checkout/payment` | Process payment |
| GET | `/v13/checkout/{id}/status` | Check status |
| POST | `/v13/checkout/{id}/complete` | Complete order |

### Orders
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/v13/orders/` | List orders |
| GET | `/v13/orders/{id}` | Get order |
| POST | `/v13/orders/{id}/refund` | Request refund |
| GET | `/v13/orders/{id}/download` | Get download links |

### Subscriptions
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/v13/subscriptions/` | List subscriptions |
| POST | `/v13/subscriptions/` | Create subscription |
| GET | `/v13/subscriptions/{id}` | Get subscription |
| POST | `/v13/subscriptions/{id}/cancel` | Cancel |
| POST | `/v13/subscriptions/{id}/pause` | Pause |
| POST | `/v13/subscriptions/{id}/resume` | Resume |

### Licensing
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/v13/licensing/licenses` | Create license |
| GET | `/v13/licensing/licenses/{id}` | Get license |
| POST | `/v13/licensing/licenses/validate` | Validate |
| POST | `/v13/licensing/licenses/{id}/revoke` | Revoke |

### Reviews
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/v13/reviews/` | List reviews |
| POST | `/v13/reviews/` | Create review |
| GET | `/v13/reviews/{id}` | Get review |
| POST | `/v13/reviews/{id}/helpful` | Mark helpful |

### Payments
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/v13/payments/intents` | Create payment intent |
| POST | `/v13/payments/confirm` | Confirm payment |
| POST | `/v13/payments/refund` | Process refund |
| GET | `/v13/payments/methods` | List methods |

### Analytics
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/v13/analytics/dashboard` | Dashboard |
| POST | `/v13/analytics/query` | Query metrics |
| GET | `/v13/analytics/products/{id}` | Product analytics |
| GET | `/v13/analytics/vendors/{id}` | Vendor analytics |

### Vendors
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/v13/vendors/` | Register vendor |
| GET | `/v13/vendors/{id}` | Get vendor |
| PATCH | `/v13/vendors/{id}` | Update vendor |
| GET | `/v13/vendors/{id}/products` | Vendor products |
| GET | `/v13/vendors/{id}/analytics` | Vendor analytics |

### Fraud Detection
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/v13/fraud/check` | Check transaction |
| GET | `/v13/fraud/risk-score` | Get risk score |
| POST | `/v13/fraud/rules` | Create rule |

### Notifications
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/v13/notifications/send` | Send notification |
| GET | `/v13/notifications/` | List notifications |
| POST | `/v13/notifications/preferences` | Set preferences |

## Response Format

### Success
```json
{
  "success": true,
  "message": "Operation completed",
  "data": {},
  "meta": {
    "page": 1,
    "size": 20,
    "total": 100
  }
}
```

### Error
```json
{
  "success": false,
  "message": "Error description",
  "errors": ["Detailed error message"]
}
```

## Status Codes
- `200` - Success
- `201` - Created
- `400` - Bad Request
- `401` - Unauthorized
- `403` - Forbidden
- `404` - Not Found
- `409` - Conflict
- `429` - Too Many Requests
- `500` - Internal Server Error
