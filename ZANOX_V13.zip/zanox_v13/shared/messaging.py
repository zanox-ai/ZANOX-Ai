"""
ZANOX V13 - Messaging Layer
Redis Streams for event-driven architecture
Integrates with V10 Unified Core messaging and V12 Hyper Automation
"""

import json
import asyncio
from typing import Any, Dict, Optional, Callable, List
from datetime import datetime

import redis.asyncio as redis
from redis.asyncio.connection import ConnectionPool

from shared.config import get_settings

_pool: Optional[ConnectionPool] = None
_client: Optional[redis.Redis] = None
_subscribers: Dict[str, List[Callable]] = {}


def get_messaging_client() -> redis.Redis:
    global _client
    if _client is None:
        settings = get_settings()
        _pool = ConnectionPool.from_url(
            settings.MESSAGING_URL,
            max_connections=50,
            socket_timeout=5,
            health_check_interval=30,
        )
        _client = redis.Redis.from_pool(_pool)
    return _client


async def init_messaging():
    client = get_messaging_client()
    await client.ping()


async def close_messaging():
    global _pool, _client
    if _client:
        await _client.close()
        _client = None
    if _pool:
        await _pool.disconnect()
        _pool = None


def _serialize_message(data: Dict[str, Any]) -> str:
    return json.dumps(data, default=str)


def _deserialize_message(data: str) -> Dict[str, Any]:
    return json.loads(data)


async def publish_event(stream: str, event_type: str, payload: Dict[str, Any]) -> str:
    client = get_messaging_client()
    message = {
        "type": event_type,
        "payload": payload,
        "timestamp": datetime.utcnow().isoformat(),
        "source": "v13_commerce_marketplace",
    }
    event_id = await client.xadd(stream, {"data": _serialize_message(message)})
    return event_id.decode() if isinstance(event_id, bytes) else event_id


async def publish_to_v10(event_type: str, payload: Dict[str, Any]) -> str:
    return await publish_event("zanox:v10:events", event_type, payload)


async def publish_to_v11(event_type: str, payload: Dict[str, Any]) -> str:
    return await publish_event("zanox:v11:events", event_type, payload)


async def publish_to_v12(event_type: str, payload: Dict[str, Any]) -> str:
    return await publish_event("zanox:v12:events", event_type, payload)


async def consume_events(
    stream: str,
    group: str,
    consumer: str,
    handler: Callable[[Dict[str, Any]], Any],
    count: int = 10,
    block: int = 5000,
):
    client = get_messaging_client()
    try:
        await client.xgroup_create(stream, group, id="0", mkstream=True)
    except redis.ResponseError:
        pass
    
    while True:
        try:
            messages = await client.xreadgroup(
                group,
                consumer,
                {stream: ">"},
                count=count,
                block=block,
            )
            for stream_name, entries in messages:
                for message_id, fields in entries:
                    try:
                        data = fields.get(b"data") or fields.get("data", "{}")
                        if isinstance(data, bytes):
                            data = data.decode()
                        event = _deserialize_message(data)
                        await handler(event)
                        await client.xack(stream, group, message_id)
                    except Exception:
                        pass
        except asyncio.CancelledError:
            break
        except Exception:
            await asyncio.sleep(1)


async def publish_marketplace_event(event_type: str, payload: Dict[str, Any]) -> str:
    return await publish_event("zanox:v13:marketplace", event_type, payload)


async def publish_order_event(event_type: str, payload: Dict[str, Any]) -> str:
    return await publish_event("zanox:v13:orders", event_type, payload)


async def publish_payment_event(event_type: str, payload: Dict[str, Any]) -> str:
    return await publish_event("zanox:v13:payments", event_type, payload)


async def publish_product_event(event_type: str, payload: Dict[str, Any]) -> str:
    return await publish_event("zanox:v13:products", event_type, payload)


async def publish_notification_event(event_type: str, payload: Dict[str, Any]) -> str:
    return await publish_event("zanox:v13:notifications", event_type, payload)


async def get_stream_info(stream: str) -> Dict[str, Any]:
    client = get_messaging_client()
    try:
        info = await client.xinfo_stream(stream)
        return {
            "length": info.get(b"length", 0),
            "radix_tree_keys": info.get(b"radix-tree-keys", 0),
            "groups": info.get(b"groups", 0),
            "last_generated_id": info.get(b"last-generated-id", "").decode() if isinstance(info.get(b"last-generated-id"), bytes) else "",
            "first_entry": info.get(b"first-entry"),
            "last_entry": info.get(b"last-entry"),
        }
    except Exception:
        return {}


async def trim_stream(stream: str, max_length: int = 10000) -> int:
    client = get_messaging_client()
    return await client.xtrim(stream, maxlen=max_length)
