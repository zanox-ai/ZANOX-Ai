"""
ZANOX V13 - Database Layer
PostgreSQL with async SQLAlchemy
Integrates with V10 Unified Core database
"""

from contextlib import asynccontextmanager
from typing import AsyncGenerator, Optional

from sqlalchemy.ext.asyncio import (
    AsyncSession,
    AsyncEngine,
    create_async_engine,
    async_sessionmaker,
)
from sqlalchemy.orm import declarative_base, relationship
from sqlalchemy import (
    Column, String, Integer, BigInteger, Float, Boolean, DateTime,
    Text, JSON, ForeignKey, Index, UniqueConstraint, Numeric,
    Enum as SQLEnum, ARRAY, event,
)
from sqlalchemy.sql import func

from shared.config import get_settings

Base = declarative_base()

_engine: Optional[AsyncEngine] = None
_session_factory: Optional[async_sessionmaker] = None


class ProductType:
    DIGITAL_PRODUCT = "digital_product"
    PROMPT_PACK = "prompt_pack"
    AI_AGENT = "ai_agent"
    AUTOMATION_WORKFLOW = "automation_workflow"
    N8N_TEMPLATE = "n8n_template"
    ACTIVEPIECES_TEMPLATE = "activepieces_template"
    DIFY_TEMPLATE = "dify_template"
    FLOWISE_TEMPLATE = "flowise_template"
    LANGFLOW_TEMPLATE = "langflow_template"
    DOCUMENT = "document"
    PDF = "pdf"
    EBOOK = "ebook"
    COURSE = "course"
    MEMBERSHIP = "membership"
    SUBSCRIPTION = "subscription"
    IMAGE = "image"
    VIDEO = "video"
    ANIMATION = "animation"
    MUSIC = "music"
    VOICE_PACK = "voice_pack"
    THREE_D_MODEL = "3d_model"
    APP = "app"
    WEBSITE = "website"
    GAME = "game"
    PLUGIN = "plugin"
    EXTENSION = "extension"
    API = "api"
    SAAS_PRODUCT = "saas_product"


class ProductStatus:
    DRAFT = "draft"
    PENDING_REVIEW = "pending_review"
    APPROVED = "approved"
    REJECTED = "rejected"
    PUBLISHED = "published"
    UNPUBLISHED = "unpublished"
    ARCHIVED = "archived"
    SUSPENDED = "suspended"


class OrderStatus:
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    REFUNDED = "refunded"
    PARTIALLY_REFUNDED = "partially_refunded"
    DISPUTED = "disputed"


class PaymentStatus:
    PENDING = "pending"
    AUTHORIZED = "authorized"
    CAPTURED = "captured"
    FAILED = "failed"
    REFUNDED = "refunded"
    PARTIALLY_REFUNDED = "partially_refunded"
    CHARGEBACK = "chargeback"


class SubscriptionStatus:
    TRIALING = "trialing"
    ACTIVE = "active"
    PAST_DUE = "past_due"
    CANCELLED = "cancelled"
    UNPAID = "unpaid"
    PAUSED = "paused"


class LicenseType:
    PERPETUAL = "perpetual"
    SUBSCRIPTION = "subscription"
    TRIAL = "trial"
    ENTERPRISE = "enterprise"
    EDUCATIONAL = "educational"
    NODE_LOCKED = "node_locked"
    FLOATING = "floating"


class CommissionType:
    PERCENTAGE = "percentage"
    FIXED = "fixed"
    TIERED = "tiered"
    HYBRID = "hybrid"


def get_engine() -> AsyncEngine:
    global _engine
    if _engine is None:
        settings = get_settings()
        _engine = create_async_engine(
            settings.DATABASE_URL,
            pool_size=settings.DB_POOL_SIZE,
            max_overflow=settings.DB_MAX_OVERFLOW,
            pool_timeout=settings.DB_POOL_TIMEOUT,
            pool_recycle=settings.DB_POOL_RECYCLE,
            echo=settings.DB_ECHO,
            pool_pre_ping=True,
        )
    return _engine


def get_session_factory() -> async_sessionmaker:
    global _session_factory
    if _session_factory is None:
        _session_factory = async_sessionmaker(
            get_engine(),
            class_=AsyncSession,
            expire_on_commit=False,
            autocommit=False,
            autoflush=False,
        )
    return _session_factory


@asynccontextmanager
async def get_session() -> AsyncGenerator[AsyncSession, None]:
    factory = get_session_factory()
    async with factory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


async def get_db_session() -> AsyncGenerator[AsyncSession, None]:
    async with get_session() as session:
        yield session


async def init_db():
    engine = get_engine()
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


async def close_db():
    global _engine, _session_factory
    if _engine:
        await _engine.dispose()
        _engine = None
    _session_factory = None


async def check_db_health() -> bool:
    try:
        engine = get_engine()
        from sqlalchemy import text
        async with engine.connect() as conn:
            result = await conn.execute(text("SELECT 1"))
            return result.scalar() == 1
    except Exception:
        return False
