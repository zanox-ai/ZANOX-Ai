"""
ZANOX V13 - Shared Pydantic Models
Base models for all V13 modules
"""

from datetime import datetime
from typing import Any, Dict, List, Optional
from enum import Enum
from pydantic import BaseModel, Field, field_validator


class ProductTypeEnum(str, Enum):
    DIGITAL_PRODUCT = "digital_product"
    PROMPT_PACK = "prompt_pack"
    AI_AGENT = "ai_agent"
    AUTOMATION_WORKFLOW = "automation_workflow"
    N8N_TEMPLATE = "n8n_template"
    ACTIVEPIECES_TEMPLATE = "activepieces_template"
    DIFY_TEMPLATE = "dify_template"
    FLOWISE_TEMPLATE = "flowise_template"
    LANGFLOW_TEMPLATE = "langflow_template"
    DOCUMENT = "document"
    PDF = "pdf"
    EBOOK = "ebook"
    COURSE = "course"
    MEMBERSHIP = "membership"
    SUBSCRIPTION = "subscription"
    IMAGE = "image"
    VIDEO = "video"
    ANIMATION = "animation"
    MUSIC = "music"
    VOICE_PACK = "voice_pack"
    THREE_D_MODEL = "3d_model"
    APP = "app"
    WEBSITE = "website"
    GAME = "game"
    PLUGIN = "plugin"
    EXTENSION = "extension"
    API = "api"
    SAAS_PRODUCT = "saas_product"


class ProductStatusEnum(str, Enum):
    DRAFT = "draft"
    PENDING_REVIEW = "pending_review"
    APPROVED = "approved"
    REJECTED = "rejected"
    PUBLISHED = "published"
    UNPUBLISHED = "unpublished"
    ARCHIVED = "archived"
    SUSPENDED = "suspended"


class OrderStatusEnum(str, Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    REFUNDED = "refunded"
    PARTIALLY_REFUNDED = "partially_refunded"
    DISPUTED = "disputed"


class PaymentStatusEnum(str, Enum):
    PENDING = "pending"
    AUTHORIZED = "authorized"
    CAPTURED = "captured"
    FAILED = "failed"
    REFUNDED = "refunded"
    PARTIALLY_REFUNDED = "partially_refunded"
    CHARGEBACK = "chargeback"


class SubscriptionStatusEnum(str, Enum):
    TRIALING = "trialing"
    ACTIVE = "active"
    PAST_DUE = "past_due"
    CANCELLED = "cancelled"
    UNPAID = "unpaid"
    PAUSED = "paused"


class LicenseTypeEnum(str, Enum):
    PERPETUAL = "perpetual"
    SUBSCRIPTION = "subscription"
    TRIAL = "trial"
    ENTERPRISE = "enterprise"
    EDUCATIONAL = "educational"
    NODE_LOCKED = "node_locked"
    FLOATING = "floating"


class CommissionTypeEnum(str, Enum):
    PERCENTAGE = "percentage"
    FIXED = "fixed"
    TIERED = "tiered"
    HYBRID = "hybrid"


class VendorStatusEnum(str, Enum):
    PENDING = "pending"
    ACTIVE = "active"
    SUSPENDED = "suspended"
    BANNED = "banned"


class CurrencyEnum(str, Enum):
    USD = "USD"
    EUR = "EUR"
    GBP = "GBP"
    JPY = "JPY"
    CAD = "CAD"
    AUD = "AUD"


class PayoutStatusEnum(str, Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class DiscountTypeEnum(str, Enum):
    PERCENTAGE = "percentage"
    FIXED_AMOUNT = "fixed_amount"
    FREE_SHIPPING = "free_shipping"
    BUY_X_GET_Y = "buy_x_get_y"


class CartStatusEnum(str, Enum):
    ACTIVE = "active"
    CONVERTED = "converted"
    EXPIRED = "expired"
    ABANDONED = "abandoned"


class FileTypeEnum(str, Enum):
    DIGITAL_DOWNLOAD = "digital_download"
    LICENSE_KEY = "license_key"
    API_ACCESS = "api_access"
    STREAMING = "streaming"
    PREVIEW = "preview"


class RiskLevelEnum(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class DisputeStatusEnum(str, Enum):
    OPEN = "open"
    UNDER_REVIEW = "under_review"
    RESOLVED_SELLER = "resolved_seller"
    RESOLVED_BUYER = "resolved_buyer"
    CLOSED = "closed"


class ResponseModel(BaseModel):
    success: bool = True
    message: str = ""
    data: Optional[Dict[str, Any]] = None
    errors: Optional[List[str]] = None
    meta: Optional[Dict[str, Any]] = None


class PaginationParams(BaseModel):
    page: int = Field(1, ge=1)
    size: int = Field(20, ge=1, le=100)
    sort_by: Optional[str] = None
    sort_order: str = Field("desc", pattern="^(asc|desc)$")


class PaginatedResponse(BaseModel):
    items: List[Dict[str, Any]] = []
    total: int = 0
    page: int = 1
    size: int = 20
    pages: int = 0


class Money(BaseModel):
    amount: float = Field(..., ge=0)
    currency: str = Field("USD", pattern="^[A-Z]{3}$")

    @field_validator("amount")
    @classmethod
    def round_amount(cls, v: float) -> float:
        return round(v, 2)


class Address(BaseModel):
    line1: str
    line2: Optional[str] = None
    city: str
    state: Optional[str] = None
    postal_code: Optional[str] = None
    country: str = Field(..., pattern="^[A-Z]{2}$")


class TimestampedModel(BaseModel):
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class AuditLog(BaseModel):
    id: str
    action: str
    entity_type: str
    entity_id: str
    user_id: Optional[str] = None
    old_values: Optional[Dict[str, Any]] = None
    new_values: Optional[Dict[str, Any]] = None
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
