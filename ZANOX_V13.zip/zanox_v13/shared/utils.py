"""
ZANOX V13 - Shared Utilities
Common functions for all modules
"""

import re
import hashlib
import secrets
import string
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
from decimal import Decimal, ROUND_HALF_UP

from shared.config import get_settings


def generate_id(prefix: str = "") -> str:
    """Generate a unique prefixed ID."""
    timestamp = datetime.utcnow().strftime("%Y%m%d%H%M%S")
    random_part = secrets.token_hex(4)
    return f"{prefix}{timestamp}{random_part}" if prefix else f"{timestamp}{random_part}"


def generate_sku(vendor_id: str, product_type: str, sequence: int) -> str:
    """Generate a product SKU."""
    type_code = product_type.upper()[:4]
    return f"ZNX-{vendor_id[:8].upper()}-{type_code}-{sequence:06d}"


def generate_license_key() -> str:
    """Generate a secure license key."""
    chars = string.ascii_uppercase + string.digits
    segments = [''.join(secrets.choice(chars) for _ in range(4)) for _ in range(4)]
    return '-'.join(segments)


def generate_api_key() -> str:
    """Generate a secure API key."""
    prefix = "znak_live" if get_settings().ENV == "production" else "znak_test"
    key = secrets.token_urlsafe(32)
    return f"{prefix}_{key}"


def generate_webhook_secret() -> str:
    """Generate a webhook secret."""
    return secrets.token_urlsafe(48)


def hash_file_content(content: bytes) -> str:
    """Generate SHA-256 hash of file content."""
    return hashlib.sha256(content).hexdigest()


def format_currency(amount: float, currency: str = "USD") -> str:
    """Format amount as currency string."""
    symbols = {"USD": "$", "EUR": "€", "GBP": "£", "JPY": "¥"}
    symbol = symbols.get(currency, currency)
    return f"{symbol}{amount:,.2f}"


def round_money(amount: float) -> float:
    """Round amount to 2 decimal places."""
    return float(Decimal(str(amount)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def calculate_discount(price: float, discount_type: str, discount_value: float) -> float:
    """Calculate discounted price."""
    if discount_type == "percentage":
        return round_money(price * (1 - discount_value / 100))
    elif discount_type == "fixed_amount":
        return max(0, round_money(price - discount_value))
    return price


def calculate_tax(amount: float, tax_rate: float) -> float:
    """Calculate tax amount."""
    return round_money(amount * tax_rate)


def calculate_commission(amount: float, rate: float) -> float:
    """Calculate commission amount."""
    return round_money(amount * rate)


def slugify(text: str) -> str:
    """Convert text to URL-friendly slug."""
    text = text.lower().strip()
    text = re.sub(r'[^\w\s-]', '', text)
    text = re.sub(r'[-\s]+', '-', text)
    return text[:100]


def truncate_text(text: str, length: int = 100) -> str:
    """Truncate text to specified length."""
    if len(text) <= length:
        return text
    return text[:length].rsplit(' ', 1)[0] + '...'


def validate_email(email: str) -> bool:
    """Validate email address format."""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))


def validate_url(url: str) -> bool:
    """Validate URL format."""
    pattern = r'^https?://(?:[-\w.]|(?:%[\da-fA-F]{2}))+[/\w.-]*$'
    return bool(re.match(pattern, url))


def safe_json_loads(data: Any) -> Dict[str, Any]:
    """Safely parse JSON string to dict."""
    import json
    if isinstance(data, dict):
        return data
    if isinstance(data, str):
        try:
            return json.loads(data)
        except (json.JSONDecodeError, TypeError):
            return {}
    return {}


def paginate(items: List[Any], page: int = 1, size: int = 20) -> Dict[str, Any]:
    """Paginate a list of items."""
    total = len(items)
    start = (page - 1) * size
    end = start + size
    return {
        "items": items[start:end],
        "total": total,
        "page": page,
        "size": size,
        "pages": (total + size - 1) // size,
    }


def time_ago(dt: datetime) -> str:
    """Convert datetime to human-readable time ago string."""
    now = datetime.utcnow()
    diff = now - dt
    
    if diff.days > 365:
        return f"{diff.days // 365}y ago"
    if diff.days > 30:
        return f"{diff.days // 30}mo ago"
    if diff.days > 0:
        return f"{diff.days}d ago"
    if diff.seconds > 3600:
        return f"{diff.seconds // 3600}h ago"
    if diff.seconds > 60:
        return f"{diff.seconds // 60}m ago"
    return "just now"


def is_expired(dt: datetime) -> bool:
    """Check if a datetime is expired."""
    return datetime.utcnow() > dt


def days_until(dt: datetime) -> int:
    """Calculate days until a datetime."""
    diff = dt - datetime.utcnow()
    return max(0, diff.days)


def merge_dicts(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    """Deep merge two dictionaries."""
    result = base.copy()
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = merge_dicts(result[key], value)
        else:
            result[key] = value
    return result


def mask_sensitive(data: str, visible: int = 4) -> str:
    """Mask sensitive data showing only last N characters."""
    if len(data) <= visible:
        return "*" * len(data)
    return "*" * (len(data) - visible) + data[-visible:]


def parse_price_range(price_range: str) -> tuple:
    """Parse price range string like '10-50' or '100+' into tuple."""
    if '-' in price_range:
        parts = price_range.split('-')
        return float(parts[0]), float(parts[1])
    elif price_range.endswith('+'):
        return float(price_range[:-1]), float('inf')
    else:
        return 0, float(price_range)
