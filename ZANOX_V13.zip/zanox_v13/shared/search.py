"""
ZANOX V13 - Search Layer
Elasticsearch integration for product search and discovery
"""

from typing import Any, Dict, List, Optional

from elasticsearch import AsyncElasticsearch
from elasticsearch.helpers import async_bulk

from shared.config import get_settings

_client: Optional[AsyncElasticsearch] = None


def get_search_client() -> AsyncElasticsearch:
    global _client
    if _client is None:
        settings = get_settings()
        _client = AsyncElasticsearch(
            [settings.ELASTICSEARCH_URL],
            timeout=settings.ELASTICSEARCH_TIMEOUT,
            max_retries=3,
            retry_on_timeout=True,
        )
    return _client


def get_index_name(index: str) -> str:
    settings = get_settings()
    return f"{settings.ELASTICSEARCH_INDEX_PREFIX}_{index}"


async def init_search():
    client = get_search_client()
    settings = get_settings()
    # Create indices if they don't exist
    indices = ["products", "vendors", "orders", "reviews"]
    for idx in indices:
        index_name = get_index_name(idx)
        if not await client.indices.exists(index=index_name):
            await _create_index(idx)


async def close_search():
    global _client
    if _client:
        await _client.close()
        _client = None


async def _create_index(index: str):
    client = get_search_client()
    index_name = get_index_name(index)
    
    mappings = {
        "products": {
            "mappings": {
                "properties": {
                    "id": {"type": "keyword"},
                    "name": {"type": "text", "analyzer": "standard", "fields": {"keyword": {"type": "keyword"}}},
                    "description": {"type": "text", "analyzer": "standard"},
                    "type": {"type": "keyword"},
                    "category": {"type": "keyword"},
                    "tags": {"type": "keyword"},
                    "price": {"type": "float"},
                    "currency": {"type": "keyword"},
                    "vendor_id": {"type": "keyword"},
                    "vendor_name": {"type": "keyword"},
                    "status": {"type": "keyword"},
                    "rating": {"type": "float"},
                    "review_count": {"type": "integer"},
                    "sales_count": {"type": "integer"},
                    "created_at": {"type": "date"},
                    "updated_at": {"type": "date"},
                    "metadata": {"type": "object"},
                }
            },
            "settings": {
                "number_of_shards": 2,
                "number_of_replicas": 1,
                "analysis": {
                    "analyzer": {
                        "product_analyzer": {
                            "type": "custom",
                            "tokenizer": "standard",
                            "filter": ["lowercase", "asciifolding", "word_delimiter"]
                        }
                    }
                }
            }
        },
        "vendors": {
            "mappings": {
                "properties": {
                    "id": {"type": "keyword"},
                    "name": {"type": "text", "analyzer": "standard"},
                    "description": {"type": "text"},
                    "rating": {"type": "float"},
                    "product_count": {"type": "integer"},
                    "sales_count": {"type": "integer"},
                    "created_at": {"type": "date"},
                }
            },
            "settings": {"number_of_shards": 1, "number_of_replicas": 1}
        },
        "orders": {
            "mappings": {
                "properties": {
                    "id": {"type": "keyword"},
                    "buyer_id": {"type": "keyword"},
                    "vendor_id": {"type": "keyword"},
                    "product_id": {"type": "keyword"},
                    "status": {"type": "keyword"},
                    "total": {"type": "float"},
                    "created_at": {"type": "date"},
                }
            },
            "settings": {"number_of_shards": 2, "number_of_replicas": 1}
        },
        "reviews": {
            "mappings": {
                "properties": {
                    "id": {"type": "keyword"},
                    "product_id": {"type": "keyword"},
                    "user_id": {"type": "keyword"},
                    "rating": {"type": "integer"},
                    "content": {"type": "text"},
                    "created_at": {"type": "date"},
                }
            },
            "settings": {"number_of_shards": 1, "number_of_replicas": 1}
        }
    }
    
    config = mappings.get(index, {})
    await client.indices.create(index=index_name, body=config, ignore=400)


async def index_document(index: str, doc_id: str, document: Dict[str, Any]) -> bool:
    client = get_search_client()
    try:
        await client.index(index=get_index_name(index), id=doc_id, document=document)
        return True
    except Exception:
        return False


async def get_document(index: str, doc_id: str) -> Optional[Dict[str, Any]]:
    client = get_search_client()
    try:
        result = await client.get(index=get_index_name(index), id=doc_id)
        return result.get("_source")
    except Exception:
        return None


async def update_document(index: str, doc_id: str, document: Dict[str, Any]) -> bool:
    client = get_search_client()
    try:
        await client.update(index=get_index_name(index), id=doc_id, doc={"doc": document})
        return True
    except Exception:
        return False


async def delete_document(index: str, doc_id: str) -> bool:
    client = get_search_client()
    try:
        await client.delete(index=get_index_name(index), id=doc_id)
        return True
    except Exception:
        return False


async def search_documents(
    index: str,
    query: Optional[Dict[str, Any]] = None,
    filters: Optional[Dict[str, Any]] = None,
    sort: Optional[List[Dict[str, str]]] = None,
    page: int = 1,
    size: int = 20,
) -> Dict[str, Any]:
    client = get_search_client()
    
    body = {"query": {"bool": {"must": [], "filter": []}}}
    
    if query:
        body["query"]["bool"]["must"].append(query)
    else:
        body["query"]["bool"]["must"].append({"match_all": {}})
    
    if filters:
        for key, value in filters.items():
            if isinstance(value, list):
                body["query"]["bool"]["filter"].append({"terms": {key: value}})
            elif isinstance(value, dict):
                range_query = {key: {}}
                if "gte" in value:
                    range_query[key]["gte"] = value["gte"]
                if "lte" in value:
                    range_query[key]["lte"] = value["lte"]
                body["query"]["bool"]["filter"].append({"range": range_query})
            else:
                body["query"]["bool"]["filter"].append({"term": {key: value}})
    
    if sort:
        body["sort"] = sort
    
    from_offset = (page - 1) * size
    
    try:
        result = await client.search(
            index=get_index_name(index),
            body=body,
            from_=from_offset,
            size=size,
        )
        return {
            "total": result["hits"]["total"]["value"],
            "page": page,
            "size": size,
            "results": [hit["_source"] for hit in result["hits"]["hits"]],
        }
    except Exception:
        return {"total": 0, "page": page, "size": size, "results": []}


async def bulk_index(index: str, documents: List[Dict[str, Any]]) -> Dict[str, Any]:
    client = get_search_client()
    actions = [
        {"_index": get_index_name(index), "_id": doc.get("id"), "_source": doc}
        for doc in documents
    ]
    try:
        success, errors = await async_bulk(client, actions, raise_on_error=False)
        return {"success": success, "errors": len(errors) if errors else 0}
    except Exception as e:
        return {"success": 0, "errors": str(e)}


async def check_search_health() -> bool:
    try:
        client = get_search_client()
        return await client.ping()
    except Exception:
        return False
