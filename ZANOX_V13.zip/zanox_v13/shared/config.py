"""
ZANOX V13 - Configuration Management
Integrates with V10 Unified Core configuration
"""

import os
from functools import lru_cache
from typing import Optional, List
from pydantic_settings import BaseSettings
from pydantic import Field


class Settings(BaseSettings):
    # Application
    APP_NAME: str = "ZANOX V13 Commerce & Marketplace Layer"
    APP_VERSION: str = "13.0.0"
    DEBUG: bool = False
    ENV: str = "production"
    
    # Server
    HOST: str = "0.0.0.0"
    PORT: int = 8130
    
    # Database - PostgreSQL
    DATABASE_URL: str = "postgresql+asyncpg://zanox:zanox_pass@localhost:5432/zanox_v13"
    DB_POOL_SIZE: int = 20
    DB_MAX_OVERFLOW: int = 40
    DB_POOL_TIMEOUT: int = 30
    DB_POOL_RECYCLE: int = 1800
    DB_ECHO: bool = False
    
    # Cache - Redis
    REDIS_URL: str = "redis://localhost:6379/13"
    REDIS_POOL_SIZE: int = 50
    REDIS_TIMEOUT: int = 5
    REDIS_KEY_PREFIX: str = "zanox:v13:"
    
    # Search - Elasticsearch
    ELASTICSEARCH_URL: str = "http://localhost:9200"
    ELASTICSEARCH_INDEX_PREFIX: str = "zanox_v13"
    ELASTICSEARCH_TIMEOUT: int = 30
    
    # Messaging - Redis Streams / RabbitMQ
    MESSAGING_URL: str = "redis://localhost:6379/14"
    
    # Storage
    STORAGE_TYPE: str = "s3"  # s3, gcs, azure, local
    STORAGE_BUCKET: str = "zanox-v13-marketplace"
    STORAGE_ENDPOINT: Optional[str] = None
    STORAGE_ACCESS_KEY: Optional[str] = None
    STORAGE_SECRET_KEY: Optional[str] = None
    STORAGE_REGION: str = "us-east-1"
    STORAGE_PUBLIC_URL: Optional[str] = None
    
    # WebSockets
    WS_MESSAGE_QUEUE: str = "redis://localhost:6379/15"
    WS_MAX_CONNECTIONS: int = 10000
    
    # Payment Gateways
    STRIPE_SECRET_KEY: Optional[str] = None
    STRIPE_WEBHOOK_SECRET: Optional[str] = None
    STRIPE_PUBLISHABLE_KEY: Optional[str] = None
    
    PAYPAL_CLIENT_ID: Optional[str] = None
    PAYPAL_CLIENT_SECRET: Optional[str] = None
    PAYPAL_WEBHOOK_ID: Optional[str] = None
    PAYPAL_ENVIRONMENT: str = "sandbox"
    
    LEMONSQUEEZY_API_KEY: Optional[str] = None
    LEMONSQUEEZY_WEBHOOK_SECRET: Optional[str] = None
    LEMONSQUEEZY_STORE_ID: Optional[str] = None
    
    PADDLE_API_KEY: Optional[str] = None
    PADDLE_VENDOR_ID: Optional[str] = None
    PADDLE_VENDOR_AUTH_CODE: Optional[str] = None
    PADDLE_ENVIRONMENT: str = "sandbox"
    
    GUMROAD_ACCESS_TOKEN: Optional[str] = None
    
    PAYHIP_API_KEY: Optional[str] = None
    
    SELLFY_API_KEY: Optional[str] = None
    
    WOOCOMMERCE_URL: Optional[str] = None
    WOOCOMMERCE_CONSUMER_KEY: Optional[str] = None
    WOOCOMMERCE_CONSUMER_SECRET: Optional[str] = None
    
    SHOPIFY_SHOP_DOMAIN: Optional[str] = None
    SHOPIFY_API_KEY: Optional[str] = None
    SHOPIFY_API_PASSWORD: Optional[str] = None
    SHOPIFY_API_VERSION: str = "2024-01"
    
    # Tax
    TAX_JAR_API_KEY: Optional[str] = None
    TAX_JAR_ENVIRONMENT: str = "sandbox"
    
    # Email
    SMTP_HOST: str = "smtp.sendgrid.net"
    SMTP_PORT: int = 587
    SMTP_USER: Optional[str] = None
    SMTP_PASSWORD: Optional[str] = None
    SMTP_TLS: bool = True
    EMAIL_FROM: str = "marketplace@zanox.io"
    EMAIL_FROM_NAME: str = "ZANOX Marketplace"
    
    # Security
    JWT_SECRET: str = "zanox-v13-jwt-secret-change-in-production"
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRATION_HOURS: int = 24
    
    ENCRYPTION_KEY: Optional[str] = None
    
    # Rate Limiting
    RATE_LIMIT_DEFAULT: int = 100
    RATE_LIMIT_WINDOW: int = 60
    
    # Marketplace
    MARKETPLACE_NAME: str = "ZANOX Marketplace"
    MARKETPLACE_CURRENCY: str = "USD"
    MARKETPLACE_COMMISSION_RATE: float = 0.10
    MARKETPLACE_MINIMUM_PAYOUT: float = 50.0
    MARKETPLACE_PAYOUT_SCHEDULE: str = "monthly"
    MARKETPLACE_GRACE_PERIOD_DAYS: int = 30
    MARKETPLACE_REFUND_WINDOW_DAYS: int = 14
    MARKETPLACE_REVIEW_COOLDOWN_HOURS: int = 24
    
    # Affiliate
    AFFILIATE_ENABLED: bool = True
    AFFILIATE_COMMISSION_TIER1: float = 0.30
    AFFILIATE_COMMISSION_TIER2: float = 0.10
    AFFILIATE_COOKIES_DAYS: int = 30
    AFFILIATE_MINIMUM_PAYOUT: float = 25.0
    
    # Subscription
    SUBSCRIPTION_ENABLED: bool = True
    SUBSCRIPTION_TRIAL_DAYS: int = 14
    SUBSCRIPTION_GRACE_PERIOD_DAYS: int = 3
    
    # Fraud Detection
    FRAUD_MAX_ORDER_VALUE: float = 10000.0
    FRAUD_MAX_DAILY_ORDERS: int = 10
    FRAUD_VELOCITY_CHECK_WINDOW: int = 3600
    FRAUD_RISK_THRESHOLD: float = 0.7
    
    class Config:
        env_file = ".env"
        env_prefix = "ZANOX_V13_"
        extra = "allow"


@lru_cache()
def get_settings() -> Settings:
    return Settings()
