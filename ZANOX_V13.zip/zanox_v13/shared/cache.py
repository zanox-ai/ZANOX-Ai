"""
ZANOX V13 - Cache Layer
Redis with connection pooling
Integrates with V10 Unified Core cache
"""

import json
import pickle
from typing import Any, Optional, List, Dict, Union
from datetime import timedelta

import redis.asyncio as redis
from redis.asyncio.connection import ConnectionPool

from shared.config import get_settings

_pool: Optional[ConnectionPool] = None
_client: Optional[redis.Redis] = None


def get_pool() -> ConnectionPool:
    global _pool
    if _pool is None:
        settings = get_settings()
        _pool = ConnectionPool.from_url(
            settings.REDIS_URL,
            max_connections=settings.REDIS_POOL_SIZE,
            socket_timeout=settings.REDIS_TIMEOUT,
            socket_connect_timeout=settings.REDIS_TIMEOUT,
            health_check_interval=30,
        )
    return _pool


def get_cache_client() -> redis.Redis:
    global _client
    if _client is None:
        settings = get_settings()
        _client = redis.Redis.from_pool(get_pool())
    return _client


def _make_key(key: str) -> str:
    settings = get_settings()
    return f"{settings.REDIS_KEY_PREFIX}{key}"


async def init_cache():
    client = get_cache_client()
    await client.ping()


async def close_cache():
    global _pool, _client
    if _client:
        await _client.close()
        _client = None
    if _pool:
        await _pool.disconnect()
        _pool = None


async def cache_get(key: str, default: Any = None) -> Any:
    client = get_cache_client()
    value = await client.get(_make_key(key))
    if value is None:
        return default
    try:
        return json.loads(value)
    except (json.JSONDecodeError, TypeError, ValueError):
        return pickle.loads(value)


async def cache_set(
    key: str,
    value: Any,
    ttl: Optional[Union[int, timedelta]] = None,
) -> bool:
    client = get_cache_client()
    full_key = _make_key(key)
    try:
        serialized = json.dumps(value, default=str)
    except (TypeError, ValueError):
        serialized = pickle.dumps(value)
    if isinstance(ttl, timedelta):
        ttl = int(ttl.total_seconds())
    return await client.set(full_key, serialized, ex=ttl)


async def cache_delete(key: str) -> bool:
    client = get_cache_client()
    return bool(await client.delete(_make_key(key)))


async def cache_exists(key: str) -> bool:
    client = get_cache_client()
    return bool(await client.exists(_make_key(key)))


async def cache_incr(key: str, amount: int = 1) -> int:
    client = get_cache_client()
    return await client.incr(_make_key(key), amount)


async def cache_decr(key: str, amount: int = 1) -> int:
    client = get_cache_client()
    return await client.decr(_make_key(key), amount)


async def cache_expire(key: str, ttl: Union[int, timedelta]) -> bool:
    client = get_cache_client()
    if isinstance(ttl, timedelta):
        ttl = int(ttl.total_seconds())
    return await client.expire(_make_key(key), ttl)


async def cache_ttl(key: str) -> int:
    client = get_cache_client()
    return await client.ttl(_make_key(key))


async def cache_keys(pattern: str) -> List[str]:
    client = get_cache_client()
    keys = await client.keys(_make_key(pattern))
    prefix = get_settings().REDIS_KEY_PREFIX
    return [k.decode().replace(prefix, "") if isinstance(k, bytes) else k.replace(prefix, "") for k in keys]


async def cache_flush_pattern(pattern: str) -> int:
    client = get_cache_client()
    keys = await client.keys(_make_key(pattern))
    if keys:
        return await client.delete(*keys)
    return 0


# Hash operations
async def cache_hset(key: str, field: str, value: Any) -> bool:
    client = get_cache_client()
    serialized = json.dumps(value, default=str) if not isinstance(value, (str, int, float)) else value
    return bool(await client.hset(_make_key(key), field, serialized))


async def cache_hget(key: str, field: str, default: Any = None) -> Any:
    client = get_cache_client()
    value = await client.hget(_make_key(key), field)
    if value is None:
        return default
    try:
        return json.loads(value)
    except (json.JSONDecodeError, TypeError, ValueError):
        return value.decode() if isinstance(value, bytes) else value


async def cache_hgetall(key: str) -> Dict[str, Any]:
    client = get_cache_client()
    data = await client.hgetall(_make_key(key))
    result = {}
    for k, v in data.items():
        k = k.decode() if isinstance(k, bytes) else k
        try:
            result[k] = json.loads(v)
        except (json.JSONDecodeError, TypeError, ValueError):
            result[k] = v.decode() if isinstance(v, bytes) else v
    return result


async def cache_hdel(key: str, field: str) -> bool:
    client = get_cache_client()
    return bool(await client.hdel(_make_key(key), field))


# List operations
async def cache_lpush(key: str, *values: Any) -> int:
    client = get_cache_client()
    serialized = [json.dumps(v, default=str) for v in values]
    return await client.lpush(_make_key(key), *serialized)


async def cache_rpush(key: str, *values: Any) -> int:
    client = get_cache_client()
    serialized = [json.dumps(v, default=str) for v in values]
    return await client.rpush(_make_key(key), *serialized)


async def cache_lpop(key: str) -> Optional[Any]:
    client = get_cache_client()
    value = await client.lpop(_make_key(key))
    if value is None:
        return None
    try:
        return json.loads(value)
    except (json.JSONDecodeError, TypeError, ValueError):
        return value.decode() if isinstance(value, bytes) else value


async def cache_lrange(key: str, start: int = 0, end: int = -1) -> List[Any]:
    client = get_cache_client()
    values = await client.lrange(_make_key(key), start, end)
    result = []
    for v in values:
        try:
            result.append(json.loads(v))
        except (json.JSONDecodeError, TypeError, ValueError):
            result.append(v.decode() if isinstance(v, bytes) else v)
    return result


# Set operations
async def cache_sadd(key: str, *members: Any) -> int:
    client = get_cache_client()
    serialized = [json.dumps(m, default=str) for m in members]
    return await client.sadd(_make_key(key), *serialized)


async def cache_sismember(key: str, member: Any) -> bool:
    client = get_cache_client()
    serialized = json.dumps(member, default=str)
    return bool(await client.sismember(_make_key(key), serialized))


async def cache_smembers(key: str) -> set:
    client = get_cache_client()
    members = await client.smembers(_make_key(key))
    result = set()
    for m in members:
        try:
            result.add(json.loads(m))
        except (json.JSONDecodeError, TypeError, ValueError):
            result.add(m.decode() if isinstance(m, bytes) else m)
    return result


# Distributed locking
async def acquire_lock(key: str, ttl: int = 30) -> Optional[str]:
    client = get_cache_client()
    import uuid
    token = str(uuid.uuid4())
    acquired = await client.set(_make_key(f"lock:{key}"), token, nx=True, ex=ttl)
    return token if acquired else None


async def release_lock(key: str, token: str) -> bool:
    client = get_cache_client()
    lock_key = _make_key(f"lock:{key}")
    current = await client.get(lock_key)
    if current and (current.decode() if isinstance(current, bytes) else current) == token:
        return await client.delete(lock_key)
    return False


async def check_cache_health() -> bool:
    try:
        client = get_cache_client()
        return await client.ping()
    except Exception:
        return False
