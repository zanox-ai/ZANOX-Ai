"""
ZANOX V13 - Email Delivery Service
"""
import asyncio
from datetime import datetime
from typing import Optional, List, Dict, Any

from sqlalchemy import select, and_, or_, func, desc, asc
from sqlalchemy.ext.asyncio import AsyncSession

from shared.database import get_session, Base
from shared.cache import cache_get, cache_set, cache_delete, cache_flush_pattern
from shared.messaging import publish_event
from shared.utils import generate_id
from .models import *


class EmailDeliveryService:
    CACHE_PREFIX = "email_delivery:"
    TABLE_NAME = "email_delivery"

    def _get_table(self):
        return Base.metadata.tables.get(self.TABLE_NAME)

    async def create(self, data: Dict[str, Any]) -> Dict[str, Any]:
        table = self._get_table()
        record_id = generate_id("ema_")
        data["id"] = record_id
        data["created_at"] = datetime.utcnow().isoformat()
        data["updated_at"] = datetime.utcnow().isoformat()

        async with get_session() as session:
            if table is not None:
                await session.execute(table.insert().values(**data))
            else:
                # In-memory fallback
                pass

        await cache_delete(f"{self.CACHE_PREFIX}list:*")
        return data

    async def get(self, record_id: str) -> Optional[Dict[str, Any]]:
        cache_key = f"{self.CACHE_PREFIX}get:{record_id}"
        cached = await cache_get(cache_key)
        if cached:
            return cached

        table = self._get_table()
        async with get_session() as session:
            if table is not None:
                result = await session.execute(
                    select(table).where(table.c.id == record_id)
                )
                row = result.mappings().first()
                if row:
                    data = dict(row)
                    await cache_set(cache_key, data, ttl=1800)
                    return data
            return None

    async def update(self, record_id: str, data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        table = self._get_table()
        data["updated_at"] = datetime.utcnow().isoformat()

        async with get_session() as session:
            if table is not None:
                await session.execute(
                    table.update().where(table.c.id == record_id).values(**data)
                )

        await cache_delete(f"{self.CACHE_PREFIX}get:{record_id}")
        await cache_delete(f"{self.CACHE_PREFIX}list:*")
        return await self.get(record_id)

    async def delete(self, record_id: str) -> bool:
        table = self._get_table()
        async with get_session() as session:
            if table is not None:
                result = await session.execute(
                    table.delete().where(table.c.id == record_id)
                )
                deleted = result.rowcount > 0
            else:
                deleted = True

        if deleted:
            await cache_delete(f"{self.CACHE_PREFIX}get:{record_id}")
            await cache_delete(f"{self.CACHE_PREFIX}list:*")
        return deleted

    async def list(self, page: int = 1, size: int = 20, filters: Dict[str, Any] = None) -> Dict[str, Any]:
        cache_key = f"{self.CACHE_PREFIX}list:{page}:{size}:{str(filters)}"
        cached = await cache_get(cache_key)
        if cached:
            return cached

        table = self._get_table()
        async with get_session() as session:
            if table is not None:
                query = select(table)
                if filters:
                    conditions = []
                    for key, value in filters.items():
                        if hasattr(table.c, key):
                            conditions.append(getattr(table.c, key) == value)
                    if conditions:
                        query = query.where(and_(*conditions))

                count_result = await session.execute(select(func.count()).select_from(query.subquery()))
                total = count_result.scalar() or 0

                query = query.offset((page - 1) * size).limit(size)
                result = await session.execute(query)
                items = [dict(row) for row in result.mappings()]
            else:
                items = []
                total = 0

        result_data = {
            "items": items,
            "total": total,
            "page": page,
            "size": size,
            "pages": (total + size - 1) // size,
        }
        await cache_set(cache_key, result_data, ttl=300)
        return result_data

    async def count(self, filters: Dict[str, Any] = None) -> int:
        table = self._get_table()
        async with get_session() as session:
            if table is not None:
                query = select(func.count()).select_from(table)
                result = await session.execute(query)
                return result.scalar() or 0
            return 0

    async def health_check(self) -> bool:
        try:
            table = self._get_table()
            if table is not None:
                async with get_session() as session:
                    await session.execute(select(func.count()).select_from(table).limit(1))
            return True
        except Exception:
            return False
