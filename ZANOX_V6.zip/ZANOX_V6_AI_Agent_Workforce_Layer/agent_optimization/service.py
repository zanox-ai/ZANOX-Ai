"""Agent Optimization Service - FastAPI service wrapper."""
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Dict, List, Optional, Any
import asyncio
import logging

from .core import AgentOptimization
from .models import AgentOptimizationConfig


logger = logging.getLogger(__name__)


class CreateRecordRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    data: Dict[str, Any] = {}
    metadata: Dict[str, Any] = {}


class UpdateRecordRequest(BaseModel):
    data: Optional[Dict[str, Any]] = None
    metadata: Optional[Dict[str, Any]] = None


class ExecuteRequest(BaseModel):
    operation: str
    params: Dict[str, Any] = {}


class AgentOptimizationService:
    """FastAPI service for agent_optimization."""

    def __init__(self, core: Optional[AgentOptimization] = None):
        self.core = core or AgentOptimization()
        self.app = FastAPI(title=f"ZANOX {self.core.config.name} API", version="6.0.0")
        self._setup_routes()

    def _setup_routes(self):
        @self.app.post("/records")
        async def create_record(request: CreateRecordRequest):
            record = await self.core.create_record(request.name, request.data, request.metadata)
            return record.to_dict()

        @self.app.get("/records")
        async def list_records(status: Optional[str] = None):
            records = await self.core.list_records(status)
            return [r.to_dict() for r in records]

        @self.app.get("/records/{record_id}")
        async def get_record(record_id: str):
            record = await self.core.get_record(record_id)
            if not record:
                raise HTTPException(status_code=404, detail="Record not found")
            return record.to_dict()

        @self.app.patch("/records/{record_id}")
        async def update_record(record_id: str, request: UpdateRecordRequest):
            record = await self.core.update_record(record_id, request.data, request.metadata)
            if not record:
                raise HTTPException(status_code=404, detail="Record not found")
            return record.to_dict()

        @self.app.delete("/records/{record_id}")
        async def delete_record(record_id: str):
            success = await self.core.delete_record(record_id)
            if not success:
                raise HTTPException(status_code=404, detail="Record not found")
            return {"message": "Record deleted", "record_id": record_id}

        @self.app.post("/records/{record_id}/execute")
        async def execute(record_id: str, request: ExecuteRequest):
            result = await self.core.execute(record_id, request.operation, request.params)
            if "error" in result and result["error"] == "Record not found":
                raise HTTPException(status_code=404, detail="Record not found")
            return result

        @self.app.get("/metrics")
        async def get_metrics():
            return await self.core.get_metrics()

        @self.app.get("/health")
        async def health_check():
            return await self.core.health_check()

    def get_app(self) -> FastAPI:
        return self.app
