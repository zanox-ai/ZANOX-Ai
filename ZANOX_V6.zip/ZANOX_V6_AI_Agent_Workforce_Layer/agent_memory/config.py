"""Agent Memory Configuration."""
import os
from dataclasses import dataclass, field
from typing import Dict, List, Any


@dataclass
class AgentMemoryModuleConfig:
    """Configuration for agent_memory module."""
    module_name: str = "agent_memory"
    max_workers: int = int(os.getenv("AGENT_MEMORY_MAX_WORKERS", "10"))
    timeout_seconds: int = int(os.getenv("AGENT_MEMORY_TIMEOUT", "300"))
    log_level: str = os.getenv("AGENT_MEMORY_LOG_LEVEL", "INFO")
    enable_metrics: bool = os.getenv("AGENT_MEMORY_METRICS", "true").lower() == "true"
    database_url: str = os.getenv("AGENT_MEMORY_DATABASE_URL", "postgresql://localhost/zanox")
    redis_url: str = os.getenv("AGENT_MEMORY_REDIS_URL", "redis://localhost:6379")
    api_host: str = os.getenv("AGENT_MEMORY_API_HOST", "0.0.0.0")
    api_port: int = int(os.getenv("AGENT_MEMORY_API_PORT", "8000"))
    custom_settings: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {k: v for k, v in self.__dict__.items()}
