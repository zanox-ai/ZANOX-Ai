"""ZANOX Support Team - Customer support team with ticket routing, resolution, and escalation."""
from .core import SupportTeam
from .models import SupportTeamConfig
from .service import SupportTeamService

__all__ = ["SupportTeam", "SupportTeamConfig", "SupportTeamService"]
