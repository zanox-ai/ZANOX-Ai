"""Agent Qa Data Models."""
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Callable
from datetime import datetime
from enum import Enum
import uuid


class AgentQaStatus(Enum):
    """Status enumeration for agent_qa."""
    IDLE = "idle"
    ACTIVE = "active"
    PAUSED = "paused"
    ERROR = "error"
    COMPLETED = "completed"
    PENDING = "pending"
    RUNNING = "running"
    STOPPED = "stopped"
    MAINTENANCE = "maintenance"


@dataclass
class AgentQaConfig:
    """Configuration for agent_qa."""
    module_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    description: str = ""
    version: str = "1.0.0"
    status: AgentQaStatus = AgentQaStatus.IDLE
    max_workers: int = 10
    timeout_seconds: int = 300
    retry_count: int = 3
    log_level: str = "INFO"
    enable_metrics: bool = True
    enable_tracing: bool = True
    custom_settings: Dict[str, Any] = field(default_factory=dict)
    tags: List[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "module_id": self.module_id,
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "status": self.status.value,
            "max_workers": self.max_workers,
            "timeout_seconds": self.timeout_seconds,
            "retry_count": self.retry_count,
            "log_level": self.log_level,
            "enable_metrics": self.enable_metrics,
            "enable_tracing": self.enable_tracing,
            "custom_settings": self.custom_settings,
            "tags": self.tags,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
        }


@dataclass
class AgentQaRecord:
    """Record model for agent_qa."""
    record_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    module_id: str = ""
    name: str = ""
    data: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    status: str = "active"
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "record_id": self.record_id,
            "module_id": self.module_id,
            "name": self.name,
            "data": self.data,
            "metadata": self.metadata,
            "status": self.status,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
        }
