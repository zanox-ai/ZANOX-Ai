# ZANOX V6 API Documentation

## Base URL
```
https://api.zanox.io/api/v6
```

## Authentication
All endpoints require Bearer token authentication:
```
Authorization: Bearer <jwt_token>
```

## Agent Engine API

### Create Agent
```http
POST /engine/agents
Content-Type: application/json

{
  "name": "Research Assistant",
  "description": "AI agent for research tasks",
  "agent_type": "research",
  "max_concurrent_tasks": 5,
  "skills": ["research", "analysis", "synthesis"],
  "tags": ["research", "ai"]
}
```

Response:
```json
{
  "agent_id": "uuid",
  "name": "Research Assistant",
  "status": "draft",
  "created_at": "2024-01-01T00:00:00Z"
}
```

### Execute Task
```http
POST /engine/agents/{agent_id}/execute
Content-Type: application/json

{
  "task_id": "task-uuid",
  "input": {
    "query": "Analyze market trends for AI agents"
  },
  "timeout": 300
}
```

Response:
```json
{
  "agent_id": "uuid",
  "task_id": "task-uuid",
  "status": "success",
  "output": {
    "analysis": "...",
    "capabilities_used": ["research", "analysis"]
  },
  "execution_time_ms": 1500,
  "tokens_used": 2500,
  "cost": 0.05
}
```

### Scale Agent
```http
POST /engine/agents/{agent_id}/scale?replica_count=5
```

Response:
```json
{
  "agent_id": "uuid",
  "replica_count": 5,
  "replicas": [
    {"agent_id": "replica-1-uuid", "name": "Research Assistant_replica_1"}
  ]
}
```

## Team APIs

### Research Team
```http
POST /teams/research/tasks
{
  "objective": "Research quantum computing advances",
  "depth": "comprehensive",
  "sources": ["arxiv", "nature", "ieee"]
}
```

### Marketing Team
```http
POST /teams/marketing/campaigns
{
  "campaign_name": "Q1 Product Launch",
  "target_audience": "enterprise",
  "channels": ["email", "social", "content"]
}
```

### Development Team
```http
POST /teams/development/code
{
  "language": "python",
  "task": "Build REST API for user management",
  "framework": "fastapi",
  "requirements": ["auth", "crud", "pagination"]
}
```

## Error Codes

| Code | Description |
|------|-------------|
| 400 | Bad Request |
| 401 | Unauthorized |
| 403 | Forbidden |
| 404 | Not Found |
| 409 | Conflict |
| 429 | Rate Limited |
| 500 | Internal Server Error |
| 503 | Service Unavailable |

## Rate Limiting

- Default: 1000 requests per minute
- Burst: 100 requests per second
- Headers: `X-RateLimit-Limit`, `X-RateLimit-Remaining`, `X-RateLimit-Reset`
