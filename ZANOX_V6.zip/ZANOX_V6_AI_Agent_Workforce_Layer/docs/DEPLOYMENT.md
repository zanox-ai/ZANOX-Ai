# ZANOX V6 Deployment Guide

## Prerequisites

- Docker 24.0+
- Docker Compose 2.20+
- Kubernetes 1.28+ (for K8s deployment)
- Helm 3.12+ (optional)
- 16GB RAM minimum
- 4 CPU cores minimum

## Docker Compose Deployment

### 1. Clone Repository
```bash
git clone https://github.com/zanox/zanox-v6.git
cd zanox-v6
```

### 2. Configure Environment
```bash
cp .env.example .env
# Edit .env with your configuration
```

### 3. Start Services
```bash
cd deployment
docker-compose up -d
```

### 4. Verify Deployment
```bash
docker-compose ps
docker-compose logs -f zanox-agent-engine
```

### 5. Access Services
- API Gateway: http://localhost
- Prometheus: http://localhost/prometheus
- Grafana: http://localhost/grafana
- Agent Engine: http://localhost:8000

## Kubernetes Deployment

### 1. Create Namespace
```bash
kubectl apply -f deployment/k8s-namespace.yaml
```

### 2. Configure Secrets
```bash
kubectl apply -f deployment/k8s-secret.yaml
```

### 3. Deploy Core Services
```bash
kubectl apply -f deployment/k8s-configmap.yaml
kubectl apply -f deployment/k8s-agent-engine.yaml
kubectl apply -f deployment/k8s-agent-runtime.yaml
```

### 4. Deploy Supporting Services
```bash
kubectl apply -f deployment/k8s-agent-registry.yaml
kubectl apply -f deployment/k8s-agent-monitoring.yaml
kubectl apply -f deployment/k8s-agent-tasks.yaml
kubectl apply -f deployment/k8s-agent-workflows.yaml
```

### 5. Deploy Teams
```bash
kubectl apply -f deployment/k8s-research-team.yaml
kubectl apply -f deployment/k8s-marketing-team.yaml
kubectl apply -f deployment/k8s-development-team.yaml
```

### 6. Configure Autoscaling
```bash
kubectl apply -f deployment/k8s-hpa.yaml
```

### 7. Configure Ingress
```bash
kubectl apply -f deployment/k8s-ingress.yaml
```

### 8. Verify
```bash
kubectl get pods -n zanox-v6
kubectl get svc -n zanox-v6
kubectl get ingress -n zanox-v6
```

## Scaling

### Horizontal Scaling
```bash
kubectl scale deployment zanox-agent-engine --replicas=10 -n zanox-v6
kubectl scale deployment zanox-agent-runtime --replicas=20 -n zanox-v6
```

### Vertical Scaling
Edit deployment YAML and apply:
```bash
kubectl apply -f deployment/k8s-agent-engine.yaml
```

## Monitoring

### Prometheus Metrics
- Agent Engine: http://zanox-agent-engine:9090/metrics
- Agent Runtime: http://zanox-agent-runtime:9090/metrics

### Grafana Dashboards
Import dashboards from `deployment/grafana-dashboards/`

### Health Checks
```bash
curl http://localhost:8000/health
curl http://localhost:8001/health
```

## Backup and Recovery

### Database Backup
```bash
pg_dump -h postgres -U postgres zanox > backup.sql
```

### Redis Backup
```bash
redis-cli BGSAVE
```

### Recovery
```bash
psql -h postgres -U postgres zanox < backup.sql
```

## Troubleshooting

### Check Logs
```bash
kubectl logs -f deployment/zanox-agent-engine -n zanox-v6
```

### Debug Mode
```bash
kubectl exec -it deployment/zanox-agent-engine -n zanox-v6 -- /bin/sh
```

### Common Issues
1. **Connection refused**: Check service endpoints
2. **Out of memory**: Increase resource limits
3. **Slow responses**: Check HPA scaling
4. **Database errors**: Verify connection strings
