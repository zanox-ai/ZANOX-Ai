"""ZANOX Agent Resources - Agent resource management with CPU, memory, GPU, and storage allocation."""
from .core import AgentResources
from .models import AgentResourcesConfig
from .service import AgentResourcesService

__all__ = ["AgentResources", "AgentResourcesConfig", "AgentResourcesService"]
