"""ZANOX Marketing Team - Marketing team with campaign planning, content creation, and analytics."""
from .core import MarketingTeam
from .models import MarketingTeamConfig
from .service import MarketingTeamService

__all__ = ["MarketingTeam", "MarketingTeamConfig", "MarketingTeamService"]
