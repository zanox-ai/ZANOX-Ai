"""Agent Engine Data Models."""
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Callable
from datetime import datetime
from enum import Enum
import uuid
import json


class AgentStatus(Enum):
    """Agent lifecycle statuses."""
    DRAFT = "draft"
    PENDING = "pending"
    PROVISIONING = "provisioning"
    ACTIVE = "active"
    PAUSED = "paused"
    ERROR = "error"
    TERMINATING = "terminating"
    TERMINATED = "terminated"
    SUSPENDED = "suspended"
    MAINTENANCE = "maintenance"


class AgentPriority(Enum):
    """Agent priority levels."""
    CRITICAL = 0
    HIGH = 1
    NORMAL = 2
    LOW = 3
    BACKGROUND = 4


@dataclass
class AgentCapability:
    """Defines what an agent can do."""
    name: str
    description: str
    version: str = "1.0.0"
    parameters: Dict[str, Any] = field(default_factory=dict)
    required_skills: List[str] = field(default_factory=list)
    input_schema: Dict[str, Any] = field(default_factory=dict)
    output_schema: Dict[str, Any] = field(default_factory=dict)
    rate_limit: int = 100
    timeout_seconds: int = 30
    cost_per_call: float = 0.0


@dataclass
class AgentConfig:
    """Agent configuration parameters."""
    agent_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    description: str = ""
    agent_type: str = "general"
    version: str = "1.0.0"
    priority: AgentPriority = AgentPriority.NORMAL
    max_concurrent_tasks: int = 5
    max_queue_size: int = 100
    memory_limit_mb: int = 512
    cpu_limit: float = 1.0
    timeout_seconds: int = 300
    retry_count: int = 3
    retry_delay: float = 1.0
    log_level: str = "INFO"
    enable_tracing: bool = True
    enable_metrics: bool = True
    custom_settings: Dict[str, Any] = field(default_factory=dict)
    environment_variables: Dict[str, str] = field(default_factory=dict)
    secrets: Dict[str, str] = field(default_factory=dict)
    tags: List[str] = field(default_factory=list)
    labels: Dict[str, str] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)


@dataclass
class AgentDefinition:
    """Complete agent blueprint definition."""
    agent_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    description: str = ""
    agent_type: str = "general"
    version: str = "1.0.0"
    status: AgentStatus = AgentStatus.DRAFT
    config: AgentConfig = field(default_factory=AgentConfig)
    capabilities: List[AgentCapability] = field(default_factory=list)
    skills: List[str] = field(default_factory=list)
    knowledge_bases: List[str] = field(default_factory=list)
    memory_profile: str = "default"
    communication_channels: List[str] = field(default_factory=list)
    team_affiliations: List[str] = field(default_factory=list)
    dependencies: List[str] = field(default_factory=list)
    parent_agent_id: Optional[str] = None
    child_agent_ids: List[str] = field(default_factory=list)
    owner_id: str = ""
    organization_id: str = ""
    billing_profile: str = "default"
    security_profile: str = "default"
    governance_profile: str = "default"
    compliance_tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    activated_at: Optional[datetime] = None
    terminated_at: Optional[datetime] = None

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "agent_id": self.agent_id,
            "name": self.name,
            "description": self.description,
            "agent_type": self.agent_type,
            "version": self.version,
            "status": self.status.value,
            "config": {
                "agent_id": self.config.agent_id,
                "name": self.config.name,
                "description": self.config.description,
                "agent_type": self.config.agent_type,
                "version": self.config.version,
                "priority": self.config.priority.value,
                "max_concurrent_tasks": self.config.max_concurrent_tasks,
                "max_queue_size": self.config.max_queue_size,
                "memory_limit_mb": self.config.memory_limit_mb,
                "cpu_limit": self.config.cpu_limit,
                "timeout_seconds": self.config.timeout_seconds,
                "retry_count": self.config.retry_count,
                "retry_delay": self.config.retry_delay,
                "log_level": self.config.log_level,
                "enable_tracing": self.config.enable_tracing,
                "enable_metrics": self.config.enable_metrics,
                "custom_settings": self.config.custom_settings,
                "environment_variables": self.config.environment_variables,
                "tags": self.config.tags,
                "labels": self.config.labels,
                "created_at": self.config.created_at.isoformat(),
                "updated_at": self.config.updated_at.isoformat(),
            },
            "capabilities": [
                {
                    "name": c.name,
                    "description": c.description,
                    "version": c.version,
                    "parameters": c.parameters,
                    "required_skills": c.required_skills,
                    "input_schema": c.input_schema,
                    "output_schema": c.output_schema,
                    "rate_limit": c.rate_limit,
                    "timeout_seconds": c.timeout_seconds,
                    "cost_per_call": c.cost_per_call,
                }
                for c in self.capabilities
            ],
            "skills": self.skills,
            "knowledge_bases": self.knowledge_bases,
            "memory_profile": self.memory_profile,
            "communication_channels": self.communication_channels,
            "team_affiliations": self.team_affiliations,
            "dependencies": self.dependencies,
            "parent_agent_id": self.parent_agent_id,
            "child_agent_ids": self.child_agent_ids,
            "owner_id": self.owner_id,
            "organization_id": self.organization_id,
            "billing_profile": self.billing_profile,
            "security_profile": self.security_profile,
            "governance_profile": self.governance_profile,
            "compliance_tags": self.compliance_tags,
            "metadata": self.metadata,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "activated_at": self.activated_at.isoformat() if self.activated_at else None,
            "terminated_at": self.terminated_at.isoformat() if self.terminated_at else None,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AgentDefinition":
        """Deserialize from dictionary."""
        config_data = data.get("config", {})
        config = AgentConfig(
            agent_id=config_data.get("agent_id", str(uuid.uuid4())),
            name=config_data.get("name", ""),
            description=config_data.get("description", ""),
            agent_type=config_data.get("agent_type", "general"),
            version=config_data.get("version", "1.0.0"),
            priority=AgentPriority(config_data.get("priority", 2)),
            max_concurrent_tasks=config_data.get("max_concurrent_tasks", 5),
            max_queue_size=config_data.get("max_queue_size", 100),
            memory_limit_mb=config_data.get("memory_limit_mb", 512),
            cpu_limit=config_data.get("cpu_limit", 1.0),
            timeout_seconds=config_data.get("timeout_seconds", 300),
            retry_count=config_data.get("retry_count", 3),
            retry_delay=config_data.get("retry_delay", 1.0),
            log_level=config_data.get("log_level", "INFO"),
            enable_tracing=config_data.get("enable_tracing", True),
            enable_metrics=config_data.get("enable_metrics", True),
            custom_settings=config_data.get("custom_settings", {}),
            environment_variables=config_data.get("environment_variables", {}),
            tags=config_data.get("tags", []),
            labels=config_data.get("labels", {}),
        )
        capabilities = [
            AgentCapability(
                name=c.get("name", ""),
                description=c.get("description", ""),
                version=c.get("version", "1.0.0"),
                parameters=c.get("parameters", {}),
                required_skills=c.get("required_skills", []),
                input_schema=c.get("input_schema", {}),
                output_schema=c.get("output_schema", {}),
                rate_limit=c.get("rate_limit", 100),
                timeout_seconds=c.get("timeout_seconds", 30),
                cost_per_call=c.get("cost_per_call", 0.0),
            )
            for c in data.get("capabilities", [])
        ]
        return cls(
            agent_id=data.get("agent_id", str(uuid.uuid4())),
            name=data.get("name", ""),
            description=data.get("description", ""),
            agent_type=data.get("agent_type", "general"),
            version=data.get("version", "1.0.0"),
            status=AgentStatus(data.get("status", "draft")),
            config=config,
            capabilities=capabilities,
            skills=data.get("skills", []),
            knowledge_bases=data.get("knowledge_bases", []),
            memory_profile=data.get("memory_profile", "default"),
            communication_channels=data.get("communication_channels", []),
            team_affiliations=data.get("team_affiliations", []),
            dependencies=data.get("dependencies", []),
            parent_agent_id=data.get("parent_agent_id"),
            child_agent_ids=data.get("child_agent_ids", []),
            owner_id=data.get("owner_id", ""),
            organization_id=data.get("organization_id", ""),
            billing_profile=data.get("billing_profile", "default"),
            security_profile=data.get("security_profile", "default"),
            governance_profile=data.get("governance_profile", "default"),
            compliance_tags=data.get("compliance_tags", []),
            metadata=data.get("metadata", {}),
            created_at=datetime.fromisoformat(data.get("created_at", datetime.utcnow().isoformat())),
            updated_at=datetime.fromisoformat(data.get("updated_at", datetime.utcnow().isoformat())),
            activated_at=datetime.fromisoformat(data["activated_at"]) if data.get("activated_at") else None,
            terminated_at=datetime.fromisoformat(data["terminated_at"]) if data.get("terminated_at") else None,
        )


class AgentExecutionResult:
    """Result of an agent execution."""
    def __init__(
        self,
        agent_id: str,
        task_id: str,
        status: str,
        output: Any = None,
        error: Optional[str] = None,
        execution_time_ms: float = 0.0,
        tokens_used: int = 0,
        cost: float = 0.0,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        self.agent_id = agent_id
        self.task_id = task_id
        self.status = status
        self.output = output
        self.error = error
        self.execution_time_ms = execution_time_ms
        self.tokens_used = tokens_used
        self.cost = cost
        self.metadata = metadata or {}
        self.timestamp = datetime.utcnow()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "agent_id": self.agent_id,
            "task_id": self.task_id,
            "status": self.status,
            "output": self.output,
            "error": self.error,
            "execution_time_ms": self.execution_time_ms,
            "tokens_used": self.tokens_used,
            "cost": self.cost,
            "metadata": self.metadata,
            "timestamp": self.timestamp.isoformat(),
        }
