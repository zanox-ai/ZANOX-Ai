"""Agent Engine Service - FastAPI service wrapper."""
from fastapi import FastAPI, HTTPException, BackgroundTasks
from pydantic import BaseModel, Field
from typing import Dict, List, Optional, Any
import asyncio
import logging

from .core import AgentEngine
from .models import AgentDefinition, AgentConfig, AgentStatus, AgentCapability


logger = logging.getLogger(__name__)


class CreateAgentRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    description: str = ""
    agent_type: str = "general"
    max_concurrent_tasks: int = 5
    max_queue_size: int = 100
    memory_limit_mb: int = 512
    cpu_limit: float = 1.0
    timeout_seconds: int = 300
    retry_count: int = 3
    tags: List[str] = []
    skills: List[str] = []
    owner_id: str = ""
    organization_id: str = ""
    metadata: Dict[str, Any] = {}


class UpdateAgentRequest(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    max_concurrent_tasks: Optional[int] = None
    max_queue_size: Optional[int] = None
    memory_limit_mb: Optional[int] = None
    cpu_limit: Optional[float] = None
    timeout_seconds: Optional[int] = None
    retry_count: Optional[int] = None
    tags: Optional[List[str]] = None
    skills: Optional[List[str]] = None
    metadata: Optional[Dict[str, Any]] = None


class ExecuteTaskRequest(BaseModel):
    task_id: str
    input: Dict[str, Any] = {}
    timeout: Optional[int] = None


class AgentResponse(BaseModel):
    agent_id: str
    name: str
    description: str
    agent_type: str
    version: str
    status: str
    created_at: str
    updated_at: str


class AgentEngineService:
    """FastAPI service for the Agent Engine."""

    def __init__(self, engine: Optional[AgentEngine] = None):
        self.engine = engine or AgentEngine()
        self.app = FastAPI(title="ZANOX Agent Engine API", version="6.0.0")
        self._setup_routes()

    def _setup_routes(self):
        @self.app.post("/agents", response_model=AgentResponse)
        async def create_agent(request: CreateAgentRequest):
            config = AgentConfig(
                name=request.name,
                description=request.description,
                agent_type=request.agent_type,
                max_concurrent_tasks=request.max_concurrent_tasks,
                max_queue_size=request.max_queue_size,
                memory_limit_mb=request.memory_limit_mb,
                cpu_limit=request.cpu_limit,
                timeout_seconds=request.timeout_seconds,
                retry_count=request.retry_count,
                tags=request.tags,
            )
            agent = await self.engine.create_agent(
                name=request.name,
                description=request.description,
                agent_type=request.agent_type,
                config=config,
                skills=request.skills,
                owner_id=request.owner_id,
                organization_id=request.organization_id,
                metadata=request.metadata,
            )
            return AgentResponse(
                agent_id=agent.agent_id,
                name=agent.name,
                description=agent.description,
                agent_type=agent.agent_type,
                version=agent.version,
                status=agent.status.value,
                created_at=agent.created_at.isoformat(),
                updated_at=agent.updated_at.isoformat(),
            )

        @self.app.get("/agents")
        async def list_agents(
            status: Optional[str] = None,
            agent_type: Optional[str] = None,
            owner_id: Optional[str] = None,
            organization_id: Optional[str] = None,
        ):
            status_enum = AgentStatus(status) if status else None
            agents = await self.engine.list_agents(
                status=status_enum,
                agent_type=agent_type,
                owner_id=owner_id,
                organization_id=organization_id,
            )
            return [
                AgentResponse(
                    agent_id=a.agent_id,
                    name=a.name,
                    description=a.description,
                    agent_type=a.agent_type,
                    version=a.version,
                    status=a.status.value,
                    created_at=a.created_at.isoformat(),
                    updated_at=a.updated_at.isoformat(),
                )
                for a in agents
            ]

        @self.app.get("/agents/{agent_id}", response_model=AgentResponse)
        async def get_agent(agent_id: str):
            agent = await self.engine.get_agent(agent_id)
            if not agent:
                raise HTTPException(status_code=404, detail="Agent not found")
            return AgentResponse(
                agent_id=agent.agent_id,
                name=agent.name,
                description=agent.description,
                agent_type=agent.agent_type,
                version=agent.version,
                status=agent.status.value,
                created_at=agent.created_at.isoformat(),
                updated_at=agent.updated_at.isoformat(),
            )

        @self.app.patch("/agents/{agent_id}", response_model=AgentResponse)
        async def update_agent(agent_id: str, request: UpdateAgentRequest):
            kwargs = {}
            if request.name is not None:
                kwargs["name"] = request.name
            if request.description is not None:
                kwargs["description"] = request.description
            if request.skills is not None:
                kwargs["skills"] = request.skills
            if request.metadata is not None:
                kwargs["metadata"] = request.metadata

            agent = await self.engine.update_agent(agent_id, **kwargs)
            if not agent:
                raise HTTPException(status_code=404, detail="Agent not found")
            return AgentResponse(
                agent_id=agent.agent_id,
                name=agent.name,
                description=agent.description,
                agent_type=agent.agent_type,
                version=agent.version,
                status=agent.status.value,
                created_at=agent.created_at.isoformat(),
                updated_at=agent.updated_at.isoformat(),
            )

        @self.app.delete("/agents/{agent_id}")
        async def delete_agent(agent_id: str):
            success = await self.engine.delete_agent(agent_id)
            if not success:
                raise HTTPException(status_code=404, detail="Agent not found")
            return {"message": "Agent deleted", "agent_id": agent_id}

        @self.app.post("/agents/{agent_id}/activate")
        async def activate_agent(agent_id: str):
            success = await self.engine.activate_agent(agent_id)
            if not success:
                raise HTTPException(status_code=404, detail="Agent not found")
            return {"message": "Agent activated", "agent_id": agent_id}

        @self.app.post("/agents/{agent_id}/pause")
        async def pause_agent(agent_id: str):
            success = await self.engine.pause_agent(agent_id)
            if not success:
                raise HTTPException(status_code=404, detail="Agent not found")
            return {"message": "Agent paused", "agent_id": agent_id}

        @self.app.post("/agents/{agent_id}/terminate")
        async def terminate_agent(agent_id: str):
            success = await self.engine.terminate_agent(agent_id)
            if not success:
                raise HTTPException(status_code=404, detail="Agent not found")
            return {"message": "Agent terminated", "agent_id": agent_id}

        @self.app.post("/agents/{agent_id}/execute")
        async def execute_task(agent_id: str, request: ExecuteTaskRequest):
            result = await self.engine.execute_task(
                agent_id=agent_id,
                task_id=request.task_id,
                task_input=request.input,
                timeout=request.timeout,
            )
            return result.to_dict()

        @self.app.get("/agents/{agent_id}/metrics")
        async def get_agent_metrics(agent_id: str):
            metrics = await self.engine.get_agent_metrics(agent_id)
            if metrics is None:
                raise HTTPException(status_code=404, detail="Agent not found")
            return metrics

        @self.app.get("/metrics")
        async def get_all_metrics():
            return await self.engine.get_all_metrics()

        @self.app.post("/agents/{agent_id}/clone")
        async def clone_agent(agent_id: str, new_name: str):
            clone = await self.engine.clone_agent(agent_id, new_name)
            if not clone:
                raise HTTPException(status_code=404, detail="Agent not found")
            return AgentResponse(
                agent_id=clone.agent_id,
                name=clone.name,
                description=clone.description,
                agent_type=clone.agent_type,
                version=clone.version,
                status=clone.status.value,
                created_at=clone.created_at.isoformat(),
                updated_at=clone.updated_at.isoformat(),
            )

        @self.app.post("/agents/{agent_id}/scale")
        async def scale_agent(agent_id: str, replica_count: int = 1):
            replicas = await self.engine.scale_agent(agent_id, replica_count)
            return {
                "agent_id": agent_id,
                "replica_count": len(replicas),
                "replicas": [
                    {"agent_id": r.agent_id, "name": r.name}
                    for r in replicas
                ],
            }

    def get_app(self) -> FastAPI:
        return self.app
