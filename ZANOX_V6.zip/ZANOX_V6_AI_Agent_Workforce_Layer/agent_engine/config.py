"""Agent Engine Configuration."""
import os
from dataclasses import dataclass, field
from typing import Dict, List, Any


@dataclass
class AgentEngineConfig:
    """Configuration for the Agent Engine."""
    max_workers: int = int(os.getenv("AGENT_ENGINE_MAX_WORKERS", "100"))
    default_timeout: int = int(os.getenv("AGENT_ENGINE_DEFAULT_TIMEOUT", "300"))
    enable_metrics: bool = os.getenv("AGENT_ENGINE_ENABLE_METRICS", "true").lower() == "true"
    log_level: str = os.getenv("AGENT_ENGINE_LOG_LEVEL", "INFO")
    database_url: str = os.getenv("AGENT_ENGINE_DATABASE_URL", "postgresql://localhost/zanox")
    redis_url: str = os.getenv("AGENT_ENGINE_REDIS_URL", "redis://localhost:6379")
    kafka_bootstrap_servers: str = os.getenv("AGENT_ENGINE_KAFKA_SERVERS", "localhost:9092")
    elasticsearch_url: str = os.getenv("AGENT_ENGINE_ES_URL", "http://localhost:9200")
    neo4j_uri: str = os.getenv("AGENT_ENGINE_NEO4J_URI", "bolt://localhost:7687")
    neo4j_user: str = os.getenv("AGENT_ENGINE_NEO4J_USER", "neo4j")
    neo4j_password: str = os.getenv("AGENT_ENGINE_NEO4J_PASSWORD", "password")
    api_host: str = os.getenv("AGENT_ENGINE_API_HOST", "0.0.0.0")
    api_port: int = int(os.getenv("AGENT_ENGINE_API_PORT", "8000"))
    api_workers: int = int(os.getenv("AGENT_ENGINE_API_WORKERS", "4"))
    enable_auth: bool = os.getenv("AGENT_ENGINE_ENABLE_AUTH", "true").lower() == "true"
    jwt_secret: str = os.getenv("AGENT_ENGINE_JWT_SECRET", "zanox-secret-key")
    jwt_algorithm: str = os.getenv("AGENT_ENGINE_JWT_ALGORITHM", "HS256")
    jwt_expiry_hours: int = int(os.getenv("AGENT_ENGINE_JWT_EXPIRY", "24"))
    rate_limit_requests: int = int(os.getenv("AGENT_ENGINE_RATE_LIMIT", "1000"))
    rate_limit_window: int = int(os.getenv("AGENT_ENGINE_RATE_WINDOW", "60"))
    enable_cors: bool = os.getenv("AGENT_ENGINE_ENABLE_CORS", "true").lower() == "true"
    cors_origins: List[str] = field(default_factory=lambda: ["*"])
    enable_health_checks: bool = os.getenv("AGENT_ENGINE_ENABLE_HEALTH", "true").lower() == "true"
    health_check_interval: int = int(os.getenv("AGENT_ENGINE_HEALTH_INTERVAL", "30"))
    max_agent_lifetime_hours: int = int(os.getenv("AGENT_ENGINE_MAX_LIFETIME", "168"))
    auto_terminate_inactive: bool = os.getenv("AGENT_ENGINE_AUTO_TERMINATE", "false").lower() == "true"
    inactive_threshold_hours: int = int(os.getenv("AGENT_ENGINE_INACTIVE_THRESHOLD", "72"))
    enable_audit_logging: bool = os.getenv("AGENT_ENGINE_AUDIT_LOG", "true").lower() == "true"
    audit_log_retention_days: int = int(os.getenv("AGENT_ENGINE_AUDIT_RETENTION", "90"))
    encryption_key: str = os.getenv("AGENT_ENGINE_ENCRYPTION_KEY", "")
    backup_interval_hours: int = int(os.getenv("AGENT_ENGINE_BACKUP_INTERVAL", "24"))
    backup_retention_days: int = int(os.getenv("AGENT_ENGINE_BACKUP_RETENTION", "30"))
    sandbox_enabled: bool = os.getenv("AGENT_ENGINE_SANDBOX", "true").lower() == "true"
    sandbox_cpu_limit: float = float(os.getenv("AGENT_ENGINE_SANDBOX_CPU", "0.5"))
    sandbox_memory_limit_mb: int = int(os.getenv("AGENT_ENGINE_SANDBOX_MEMORY", "256"))
    tracing_endpoint: str = os.getenv("AGENT_ENGINE_TRACING_ENDPOINT", "")
    prometheus_port: int = int(os.getenv("AGENT_ENGINE_PROMETHEUS_PORT", "9090"))

    def to_dict(self) -> Dict[str, Any]:
        return {
            k: v for k, v in self.__dict__.items()
        }


# Global config instance
_config = None


def get_config() -> AgentEngineConfig:
    """Get or create global configuration."""
    global _config
    if _config is None:
        _config = AgentEngineConfig()
    return _config


def set_config(config: AgentEngineConfig):
    """Set global configuration."""
    global _config
    _config = config
