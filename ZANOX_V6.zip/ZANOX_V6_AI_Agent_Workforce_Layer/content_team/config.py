"""Content Team Configuration."""
import os
from dataclasses import dataclass, field
from typing import Dict, List, Any


@dataclass
class ContentTeamModuleConfig:
    """Configuration for content_team module."""
    module_name: str = "content_team"
    max_workers: int = int(os.getenv("CONTENT_TEAM_MAX_WORKERS", "10"))
    timeout_seconds: int = int(os.getenv("CONTENT_TEAM_TIMEOUT", "300"))
    log_level: str = os.getenv("CONTENT_TEAM_LOG_LEVEL", "INFO")
    enable_metrics: bool = os.getenv("CONTENT_TEAM_METRICS", "true").lower() == "true"
    database_url: str = os.getenv("CONTENT_TEAM_DATABASE_URL", "postgresql://localhost/zanox")
    redis_url: str = os.getenv("CONTENT_TEAM_REDIS_URL", "redis://localhost:6379")
    api_host: str = os.getenv("CONTENT_TEAM_API_HOST", "0.0.0.0")
    api_port: int = int(os.getenv("CONTENT_TEAM_API_PORT", "8000"))
    custom_settings: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {k: v for k, v in self.__dict__.items()}
