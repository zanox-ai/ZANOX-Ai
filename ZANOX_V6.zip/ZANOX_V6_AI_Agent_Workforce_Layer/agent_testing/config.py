"""Agent Testing Configuration."""
import os
from dataclasses import dataclass, field
from typing import Dict, List, Any


@dataclass
class AgentTestingModuleConfig:
    """Configuration for agent_testing module."""
    module_name: str = "agent_testing"
    max_workers: int = int(os.getenv("AGENT_TESTING_MAX_WORKERS", "10"))
    timeout_seconds: int = int(os.getenv("AGENT_TESTING_TIMEOUT", "300"))
    log_level: str = os.getenv("AGENT_TESTING_LOG_LEVEL", "INFO")
    enable_metrics: bool = os.getenv("AGENT_TESTING_METRICS", "true").lower() == "true"
    database_url: str = os.getenv("AGENT_TESTING_DATABASE_URL", "postgresql://localhost/zanox")
    redis_url: str = os.getenv("AGENT_TESTING_REDIS_URL", "redis://localhost:6379")
    api_host: str = os.getenv("AGENT_TESTING_API_HOST", "0.0.0.0")
    api_port: int = int(os.getenv("AGENT_TESTING_API_PORT", "8000"))
    custom_settings: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {k: v for k, v in self.__dict__.items()}
