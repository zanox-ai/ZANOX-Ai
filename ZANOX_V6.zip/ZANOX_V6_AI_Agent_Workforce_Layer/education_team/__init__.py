"""ZANOX Education Team - Education team with curriculum design, tutoring, and assessment."""
from .core import EducationTeam
from .models import EducationTeamConfig
from .service import EducationTeamService

__all__ = ["EducationTeam", "EducationTeamConfig", "EducationTeamService"]
