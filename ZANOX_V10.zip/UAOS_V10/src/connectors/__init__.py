"""UAOS AI Connectors"""
from .chatgpt import ChatGPTConnector
from .claude import ClaudeConnector
from .gemini import GeminiConnector
from .grok import GrokConnector
from .kimi import KimiConnector
from .perplexity import PerplexityConnector
from .qwen import QwenConnector
from .copilot import CopilotConnector
from .manus import ManusConnector
__all__ = ["ChatGPTConnector", "ClaudeConnector", "GeminiConnector", "GrokConnector", "KimiConnector", "PerplexityConnector", "QwenConnector", "CopilotConnector", "ManusConnector"]
