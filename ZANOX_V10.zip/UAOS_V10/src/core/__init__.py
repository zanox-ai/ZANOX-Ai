"""
UAOS - Universal AI Operating System
Core Module Initialization
"""

__version__ = "10.0.0"
__author__ = "UAOS Development Team"
__license__ = "MIT"

from .system import UAOSCore
from .config import UAOSConfig
from .events import EventBus
from .scheduler import TaskScheduler
from .router import ModelRouter
from .context import ContextManager
from .cost import CostOptimizer

__all__ = [
    'UAOSCore',
    'UAOSConfig', 
    'EventBus',
    'TaskScheduler',
    'ModelRouter',
    'ContextManager',
    'CostOptimizer'
]
