"""
UAOS Configuration Management
Production-Ready Implementation
"""
import os
import yaml
import json
from typing import Dict, Any, Optional
from dataclasses import dataclass, field

@dataclass
class UAOSConfig:
    """Central configuration for UAOS"""

    # System Settings
    system_name: str = "UAOS"
    version: str = "10.0.0"
    environment: str = "production"
    debug: bool = False

    # Server Settings
    host: str = "0.0.0.0"
    port: int = 8080
    workers: int = 4

    # Database Settings
    database_url: str = "postgresql://uaos:uaos@localhost:5432/uaos"
    redis_url: str = "redis://localhost:6379/0"

    # AI Provider Settings
    openai_api_key: str = ""
    anthropic_api_key: str = ""
    google_api_key: str = ""
    grok_api_key: str = ""
    kimi_api_key: str = ""
    perplexity_api_key: str = ""
    qwen_api_key: str = ""
    copilot_api_key: str = ""
    manus_api_key: str = ""

    # Security Settings
    jwt_secret: str = "uaos-jwt-secret-change-in-production"
    encryption_key: str = "uaos-encryption-key-change-in-production"

    # Monitoring Settings
    metrics_enabled: bool = True
    logging_level: str = "INFO"

    # Feature Flags
    features: Dict[str, bool] = field(default_factory=lambda: {
        "agents": True,
        "builders": True,
        "games": True,
        "creative": True,
        "business": True,
        "self_evolution": True
    })

    @classmethod
    def from_env(cls) -> "UAOSConfig":
        """Load configuration from environment variables"""
        config = cls()

        # Override with environment variables
        config.system_name = os.getenv("UAOS_SYSTEM_NAME", config.system_name)
        config.environment = os.getenv("UAOS_ENVIRONMENT", config.environment)
        config.debug = os.getenv("UAOS_DEBUG", "false").lower() == "true"
        config.host = os.getenv("UAOS_HOST", config.host)
        config.port = int(os.getenv("UAOS_PORT", config.port))
        config.workers = int(os.getenv("UAOS_WORKERS", config.workers))

        # Database
        config.database_url = os.getenv("UAOS_DATABASE_URL", config.database_url)
        config.redis_url = os.getenv("UAOS_REDIS_URL", config.redis_url)

        # AI Keys
        config.openai_api_key = os.getenv("OPENAI_API_KEY", "")
        config.anthropic_api_key = os.getenv("ANTHROPIC_API_KEY", "")
        config.google_api_key = os.getenv("GOOGLE_API_KEY", "")
        config.grok_api_key = os.getenv("GROK_API_KEY", "")
        config.kimi_api_key = os.getenv("KIMI_API_KEY", "")
        config.perplexity_api_key = os.getenv("PERPLEXITY_API_KEY", "")
        config.qwen_api_key = os.getenv("QWEN_API_KEY", "")
        config.copilot_api_key = os.getenv("COPILOT_API_KEY", "")
        config.manus_api_key = os.getenv("MANUS_API_KEY", "")

        # Security
        config.jwt_secret = os.getenv("UAOS_JWT_SECRET", config.jwt_secret)
        config.encryption_key = os.getenv("UAOS_ENCRYPTION_KEY", config.encryption_key)

        return config

    @classmethod
    def from_file(cls, filepath: str) -> "UAOSConfig":
        """Load configuration from file"""
        config = cls()

        if os.path.exists(filepath):
            with open(filepath, 'r') as f:
                if filepath.endswith('.yaml') or filepath.endswith('.yml'):
                    data = yaml.safe_load(f)
                else:
                    data = json.load(f)

            for key, value in data.items():
                if hasattr(config, key):
                    setattr(config, key, value)

        return config

    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary"""
        return {
            "system_name": self.system_name,
            "version": self.version,
            "environment": self.environment,
            "debug": self.debug,
            "host": self.host,
            "port": self.port,
            "workers": self.workers,
            "database_url": self.database_url,
            "redis_url": self.redis_url,
            "features": self.features
        }
