"""
UAOS Context Manager - Advanced Context Handling
Production-Ready Implementation
"""
import asyncio
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
import uuid

logger = logging.getLogger(__name__)

class ContextManager:
    """
    Advanced context management for AI interactions.
    Supports multi-turn conversations, context windows, and summarization.
    """

    def __init__(self):
        self._contexts: Dict[str, Dict[str, Any]] = {}
        self._max_context_size = 100000
        self._default_ttl = 3600

    async def initialize(self):
        """Initialize context manager"""
        logger.info("Context manager initialized")

    async def create_context(
        self,
        session_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> str:
        """Create new context"""
        context_id = session_id or str(uuid.uuid4())

        self._contexts[context_id] = {
            "id": context_id,
            "messages": [],
            "metadata": metadata or {},
            "created_at": datetime.utcnow().isoformat(),
            "last_accessed": datetime.utcnow().isoformat(),
            "token_count": 0
        }

        logger.info(f"Context created: {context_id}")
        return context_id

    async def add_message(
        self,
        context_id: str,
        role: str,
        content: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> bool:
        """Add message to context"""
        if context_id not in self._contexts:
            return False

        message = {
            "id": str(uuid.uuid4()),
            "role": role,
            "content": content,
            "metadata": metadata or {},
            "timestamp": datetime.utcnow().isoformat()
        }

        self._contexts[context_id]["messages"].append(message)
        self._contexts[context_id]["last_accessed"] = datetime.utcnow().isoformat()

        # Check context size and compress if needed
        await self._manage_context_size(context_id)

        return True

    async def get_context(self, context_id: str) -> Optional[Dict[str, Any]]:
        """Get context by ID"""
        context = self._contexts.get(context_id)
        if context:
            context["last_accessed"] = datetime.utcnow().isoformat()
        return context

    async def get_messages(self, context_id: str, limit: Optional[int] = None) -> List[Dict[str, Any]]:
        """Get messages from context"""
        context = self._contexts.get(context_id)
        if not context:
            return []

        messages = context["messages"]
        if limit:
            messages = messages[-limit:]
        return messages

    async def clear_context(self, context_id: str) -> bool:
        """Clear context messages"""
        if context_id in self._contexts:
            self._contexts[context_id]["messages"] = []
            self._contexts[context_id]["token_count"] = 0
            return True
        return False

    async def delete_context(self, context_id: str) -> bool:
        """Delete context"""
        if context_id in self._contexts:
            del self._contexts[context_id]
            return True
        return False

    async def _manage_context_size(self, context_id: str):
        """Manage context size to stay within limits"""
        context = self._contexts[context_id]
        total_length = sum(len(m["content"]) for m in context["messages"])

        if total_length > self._max_context_size:
            # Summarize older messages
            await self._summarize_context(context_id)

    async def _summarize_context(self, context_id: str):
        """Summarize context to reduce size"""
        context = self._contexts[context_id]
        messages = context["messages"]

        if len(messages) > 10:
            # Keep first message (system prompt) and last 5 messages
            preserved = [messages[0]] + messages[-5:]
            context["messages"] = preserved

            logger.info(f"Context summarized: {context_id}")

    async def health_check(self) -> str:
        """Health check"""
        return "healthy"
