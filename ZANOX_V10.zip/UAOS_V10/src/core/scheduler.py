"""
UAOS Task Scheduler - Advanced Task Management
Production-Ready Implementation
"""
import asyncio
import logging
from typing import Dict, List, Any, Callable, Optional
from datetime import datetime, timedelta
import uuid
import heapq

logger = logging.getLogger(__name__)

class TaskScheduler:
    """
    Advanced task scheduler with priority queue, cron support,
    and distributed task execution.
    """

    def __init__(self):
        self._tasks: Dict[str, Dict[str, Any]] = {}
        self._queue: List[tuple] = []
        self._running = False
        self._workers: List[asyncio.Task] = []
        self._task_counter = 0

    async def initialize(self):
        """Initialize scheduler"""
        logger.info("Task scheduler initialized")

    async def start(self):
        """Start scheduler with worker pool"""
        self._running = True
        for i in range(4):
            worker = asyncio.create_task(self._worker_loop(f"worker-{i}"))
            self._workers.append(worker)
        logger.info("Task scheduler started with 4 workers")

    async def stop(self):
        """Stop scheduler and workers"""
        self._running = False
        for worker in self._workers:
            worker.cancel()
        self._workers = []
        logger.info("Task scheduler stopped")

    async def schedule_task(
        self,
        task_func: Callable,
        args: tuple = (),
        kwargs: Dict[str, Any] = None,
        priority: int = 5,
        delay: float = 0,
        task_id: Optional[str] = None
    ) -> str:
        """Schedule a task for execution"""
        task_id = task_id or str(uuid.uuid4())
        kwargs = kwargs or {}

        scheduled_time = datetime.utcnow() + timedelta(seconds=delay)

        task = {
            "id": task_id,
            "func": task_func,
            "args": args,
            "kwargs": kwargs,
            "priority": priority,
            "scheduled_time": scheduled_time,
            "status": "scheduled",
            "created_at": datetime.utcnow().isoformat()
        }

        self._tasks[task_id] = task
        heapq.heappush(self._queue, (priority, scheduled_time.timestamp(), task_id))

        logger.info(f"Task scheduled: {task_id} (priority: {priority})")
        return task_id

    async def cancel_task(self, task_id: str) -> bool:
        """Cancel a scheduled task"""
        if task_id in self._tasks:
            self._tasks[task_id]["status"] = "cancelled"
            logger.info(f"Task cancelled: {task_id}")
            return True
        return False

    async def get_task_status(self, task_id: str) -> Optional[Dict[str, Any]]:
        """Get task status"""
        task = self._tasks.get(task_id)
        if task:
            return {
                "id": task["id"],
                "status": task["status"],
                "scheduled_time": task["scheduled_time"].isoformat(),
                "priority": task["priority"]
            }
        return None

    async def _worker_loop(self, worker_id: str):
        """Worker loop for processing tasks"""
        while self._running:
            try:
                if self._queue:
                    now = datetime.utcnow().timestamp()
                    if self._queue[0][1] <= now:
                        _, _, task_id = heapq.heappop(self._queue)
                        task = self._tasks.get(task_id)

                        if task and task["status"] == "scheduled":
                            await self._execute_task(task)

                await asyncio.sleep(0.1)
            except Exception as e:
                logger.error(f"Worker {worker_id} error: {e}")

    async def _execute_task(self, task: Dict[str, Any]):
        """Execute a task"""
        task["status"] = "running"

        try:
            func = task["func"]
            args = task["args"]
            kwargs = task["kwargs"]

            if asyncio.iscoroutinefunction(func):
                result = await func(*args, **kwargs)
            else:
                result = func(*args, **kwargs)

            task["status"] = "completed"
            task["result"] = result
            task["completed_at"] = datetime.utcnow().isoformat()

            logger.info(f"Task completed: {task['id']}")

        except Exception as e:
            task["status"] = "failed"
            task["error"] = str(e)
            logger.error(f"Task failed: {task['id']} - {e}")

    async def health_check(self) -> str:
        """Health check"""
        return "healthy" if self._running else "unhealthy"
