"""
UAOS Event Bus - Central Communication System
Production-Ready Implementation
"""
import asyncio
import logging
from typing import Dict, List, Any, Callable, Optional
from datetime import datetime
import uuid

logger = logging.getLogger(__name__)

class EventBus:
    """
    Central event bus for inter-system communication.
    Supports pub/sub, request/response, and broadcast patterns.
    """

    def __init__(self):
        self._subscribers: Dict[str, List[Callable]] = {}
        self._running = False
        self._event_queue = asyncio.Queue()
        self._handlers: Dict[str, List[Callable]] = {}

    async def initialize(self):
        """Initialize the event bus"""
        self._running = True
        logger.info("Event bus initialized")

    async def start(self):
        """Start event processing loop"""
        self._running = True
        asyncio.create_task(self._process_events())
        logger.info("Event bus started")

    async def stop(self):
        """Stop event processing"""
        self._running = False
        logger.info("Event bus stopped")

    async def publish(self, event_type: str, payload: Dict[str, Any]) -> str:
        """Publish an event to the bus"""
        event_id = str(uuid.uuid4())
        event = {
            "id": event_id,
            "type": event_type,
            "payload": payload,
            "timestamp": datetime.utcnow().isoformat()
        }

        await self._event_queue.put(event)
        logger.debug(f"Event published: {event_type}")
        return event_id

    async def subscribe(self, event_type: str, handler: Callable):
        """Subscribe to an event type"""
        if event_type not in self._handlers:
            self._handlers[event_type] = []
        self._handlers[event_type].append(handler)
        logger.info(f"Handler subscribed to: {event_type}")

    async def unsubscribe(self, event_type: str, handler: Callable):
        """Unsubscribe from an event type"""
        if event_type in self._handlers and handler in self._handlers[event_type]:
            self._handlers[event_type].remove(handler)
            logger.info(f"Handler unsubscribed from: {event_type}")

    async def _process_events(self):
        """Process events from queue"""
        while self._running:
            try:
                event = await asyncio.wait_for(self._event_queue.get(), timeout=1.0)
                await self._dispatch_event(event)
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                logger.error(f"Error processing event: {e}")

    async def _dispatch_event(self, event: Dict[str, Any]):
        """Dispatch event to handlers"""
        event_type = event.get("type")
        handlers = self._handlers.get(event_type, [])

        for handler in handlers:
            try:
                if asyncio.iscoroutinefunction(handler):
                    await handler(event)
                else:
                    handler(event)
            except Exception as e:
                logger.error(f"Error in event handler: {e}")

    async def health_check(self) -> str:
        """Health check for event bus"""
        return "healthy" if self._running else "unhealthy"
