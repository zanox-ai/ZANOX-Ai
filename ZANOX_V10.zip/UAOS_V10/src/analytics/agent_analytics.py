"""UAOS Agent Analytics"""
import logging
from typing import Dict, List, Any
from datetime import datetime
import statistics
logger = logging.getLogger(__name__)

class AgentAnalytics:
    def __init__(self):
        self._agents: Dict[str, List[Dict[str, Any]]] = {}

    async def initialize(self):
        logger.info("Agent analytics initialized")

    async def record_agent_metric(self, agent_id: str, metric_name: str, value: float):
        if agent_id not in self._agents: self._agents[agent_id] = []
        self._agents[agent_id].append({"metric": metric_name, "value": value, "timestamp": datetime.utcnow().isoformat()})

    async def get_agent_performance(self, agent_id: str) -> Dict[str, Any]:
        data = self._agents.get(agent_id, [])
        if not data: return {}
        response_times = [d["value"] for d in data if d["metric"] == "response_time"]
        success_rates = [d["value"] for d in data if d["metric"] == "success_rate"]
        return {"agent_id": agent_id, "total_metrics": len(data), "avg_response_time": statistics.mean(response_times) if response_times else 0, "avg_success_rate": statistics.mean(success_rates) if success_rates else 0}
