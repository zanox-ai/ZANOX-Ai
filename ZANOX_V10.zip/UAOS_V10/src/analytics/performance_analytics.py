"""UAOS Performance Analytics"""
import logging
from typing import Dict, List, Any
from datetime import datetime
import statistics
logger = logging.getLogger(__name__)

class PerformanceAnalytics:
    def __init__(self):
        self._metrics: Dict[str, List[Dict[str, Any]]] = {}

    async def initialize(self):
        logger.info("Performance analytics initialized")

    async def record_metric(self, metric_name: str, value: float, source: str = "system"):
        if metric_name not in self._metrics: self._metrics[metric_name] = []
        self._metrics[metric_name].append({"value": value, "source": source, "timestamp": datetime.utcnow().isoformat()})

    async def get_performance_report(self, metric_name: str) -> Dict[str, Any]:
        data = self._metrics.get(metric_name, [])
        if not data: return {}
        values = [d["value"] for d in data]
        return {"metric": metric_name, "total_samples": len(data), "avg": statistics.mean(values) if values else 0, "p95": sorted(values)[int(len(values)*0.95)] if values else 0, "p99": sorted(values)[int(len(values)*0.99)] if values else 0}
