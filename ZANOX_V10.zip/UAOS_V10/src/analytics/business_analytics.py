"""UAOS Business Analytics"""
import logging
from typing import Dict, List, Any
from datetime import datetime
logger = logging.getLogger(__name__)

class BusinessAnalytics:
    def __init__(self):
        self._kpis: Dict[str, List[Dict[str, Any]]] = {}

    async def initialize(self):
        logger.info("Business analytics initialized")

    async def record_kpi(self, kpi_name: str, value: float, category: str = "general"):
        if kpi_name not in self._kpis: self._kpis[kpi_name] = []
        self._kpis[kpi_name].append({"value": value, "category": category, "timestamp": datetime.utcnow().isoformat()})

    async def get_kpi_summary(self, kpi_name: str) -> Dict[str, Any]:
        data = self._kpis.get(kpi_name, [])
        if not data: return {}
        values = [d["value"] for d in data]
        return {"kpi_name": kpi_name, "total_records": len(data), "current": values[-1] if values else 0, "min": min(values) if values else 0, "max": max(values) if values else 0, "avg": sum(values)/len(values) if values else 0}
