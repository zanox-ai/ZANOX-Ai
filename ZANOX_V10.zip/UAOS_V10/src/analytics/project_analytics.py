"""UAOS Project Analytics"""
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
import statistics
logger = logging.getLogger(__name__)

class ProjectAnalytics:
    def __init__(self):
        self._projects: Dict[str, Dict[str, Any]] = {}

    async def initialize(self):
        logger.info("Project analytics initialized")

    async def track_project(self, project_id: str, metrics: Dict[str, Any]):
        if project_id not in self._projects: self._projects[project_id] = []
        self._projects[project_id].append({"metrics": metrics, "timestamp": datetime.utcnow().isoformat()})

    async def get_project_stats(self, project_id: str) -> Dict[str, Any]:
        data = self._projects.get(project_id, [])
        if not data: return {}
        completion = [m["metrics"].get("completion", 0) for m in data]
        return {"project_id": project_id, "total_updates": len(data), "avg_completion": statistics.mean(completion) if completion else 0, "latest_completion": completion[-1] if completion else 0}
