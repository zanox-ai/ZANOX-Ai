"""UAOS Workflow Analytics"""
import logging
from typing import Dict, List, Any
from datetime import datetime
import statistics
logger = logging.getLogger(__name__)

class WorkflowAnalytics:
    def __init__(self):
        self._workflows: Dict[str, List[Dict[str, Any]]] = {}

    async def initialize(self):
        logger.info("Workflow analytics initialized")

    async def record_execution(self, workflow_id: str, duration: float, status: str = "success"):
        if workflow_id not in self._workflows: self._workflows[workflow_id] = []
        self._workflows[workflow_id].append({"duration": duration, "status": status, "timestamp": datetime.utcnow().isoformat()})

    async def get_workflow_stats(self, workflow_id: str) -> Dict[str, Any]:
        data = self._workflows.get(workflow_id, [])
        if not data: return {}
        durations = [d["duration"] for d in data]
        successes = sum(1 for d in data if d["status"] == "success")
        return {"workflow_id": workflow_id, "total_executions": len(data), "avg_duration": statistics.mean(durations) if durations else 0, "success_rate": successes/len(data)*100 if data else 0}
