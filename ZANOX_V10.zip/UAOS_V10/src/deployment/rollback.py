"""UAOS Rollback Engine"""
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
import uuid
logger = logging.getLogger(__name__)

class RollbackEngine:
    def __init__(self):
        self._snapshots: Dict[str, List[Dict[str, Any]]] = {}

    async def initialize(self):
        logger.info("Rollback engine initialized")

    async def create_snapshot(self, deployment_id: str, state: Dict[str, Any]) -> str:
        snapshot_id = str(uuid.uuid4())
        if deployment_id not in self._snapshots: self._snapshots[deployment_id] = []
        self._snapshots[deployment_id].append({"id": snapshot_id, "state": state, "created_at": datetime.utcnow().isoformat()})
        if len(self._snapshots[deployment_id]) > 10: self._snapshots[deployment_id] = self._snapshots[deployment_id][-10:]
        return snapshot_id

    async def rollback(self, deployment_id: str, snapshot_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
        snapshots = self._snapshots.get(deployment_id, [])
        if not snapshots: return None
        if snapshot_id:
            for snap in snapshots:
                if snap["id"] == snapshot_id: return snap["state"]
        return snapshots[-1]["state"]

    async def list_snapshots(self, deployment_id: str) -> List[Dict[str, Any]]:
        return self._snapshots.get(deployment_id, [])
