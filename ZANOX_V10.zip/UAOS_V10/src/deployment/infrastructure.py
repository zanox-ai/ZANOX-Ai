"""UAOS Infrastructure Manager"""
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
import uuid
logger = logging.getLogger(__name__)

class InfrastructureManager:
    def __init__(self):
        self._resources: Dict[str, Dict[str, Any]] = {}

    async def initialize(self):
        logger.info("Infrastructure manager initialized")

    async def provision_resource(self, resource_type: str, config: Dict[str, Any], name: str = "") -> str:
        resource_id = str(uuid.uuid4())
        self._resources[resource_id] = {"id": resource_id, "type": resource_type, "name": name or resource_id, "config": config, "status": "provisioning", "created_at": datetime.utcnow().isoformat()}
        self._resources[resource_id]["status"] = "ready"
        return resource_id

    async def deprovision_resource(self, resource_id: str) -> bool:
        if resource_id in self._resources:
            self._resources[resource_id]["status"] = "terminated"
            self._resources[resource_id]["terminated_at"] = datetime.utcnow().isoformat()
            return True
        return False

    async def get_resource(self, resource_id: str) -> Optional[Dict[str, Any]]:
        return self._resources.get(resource_id)

    async def list_resources(self, resource_type: Optional[str] = None) -> List[Dict[str, Any]]:
        resources = list(self._resources.values())
        if resource_type:
            resources = [r for r in resources if r["type"] == resource_type]
        return resources
