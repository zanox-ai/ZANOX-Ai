"""UAOS AI Registry"""
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
logger = logging.getLogger(__name__)

class AIRegistry:
    PROVIDERS = ["chatgpt", "claude", "gemini", "grok", "kimi", "perplexity", "qwen", "copilot", "manus"]

    def __init__(self):
        self._providers: Dict[str, Dict[str, Any]] = {}

    async def initialize(self):
        for p in self.PROVIDERS:
            self._providers[p] = {"name": p, "status": "available", "models": [], "registered_at": datetime.utcnow().isoformat()}
        logger.info("AI registry initialized")

    async def register_provider(self, name: str, models: List[str], endpoint: str):
        self._providers[name] = {"name": name, "models": models, "endpoint": endpoint, "status": "available", "registered_at": datetime.utcnow().isoformat()}

    async def get_provider(self, name: str) -> Optional[Dict[str, Any]]:
        return self._providers.get(name)

    async def list_providers(self) -> List[Dict[str, Any]]:
        return list(self._providers.values())
