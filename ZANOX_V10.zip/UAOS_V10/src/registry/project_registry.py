"""UAOS Project Registry"""
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
import uuid
logger = logging.getLogger(__name__)

class ProjectRegistry:
    def __init__(self):
        self._projects: Dict[str, Dict[str, Any]] = {}

    async def initialize(self):
        logger.info("Project registry initialized")

    async def register_project(self, project_id: str, name: str, project_type: str, config: Dict[str, Any]):
        self._projects[project_id] = {"id": project_id, "name": name, "type": project_type, "config": config, "status": "active", "created_at": datetime.utcnow().isoformat()}

    async def get_project(self, project_id: str) -> Optional[Dict[str, Any]]:
        return self._projects.get(project_id)

    async def list_projects(self, project_type: Optional[str] = None) -> List[Dict[str, Any]]:
        projects = list(self._projects.values())
        if project_type: projects = [p for p in projects if p["type"] == project_type]
        return projects

    async def update_project(self, project_id: str, updates: Dict[str, Any]) -> bool:
        if project_id in self._projects:
            self._projects[project_id].update(updates)
            self._projects[project_id]["updated_at"] = datetime.utcnow().isoformat()
            return True
        return False
