"""UAOS Builder Registry"""
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
logger = logging.getLogger(__name__)

class BuilderRegistry:
    BUILDERS = ["replit", "firebase", "flutterflow", "bolt", "lovable", "v0", "softgen", "draftbit", "glide", "framer", "adalo", "bubble", "wix", "appsmith"]

    def __init__(self):
        self._builders: Dict[str, Dict[str, Any]] = {}

    async def initialize(self):
        for b in self.BUILDERS:
            self._builders[b] = {"name": b, "status": "available", "capabilities": [], "registered_at": datetime.utcnow().isoformat()}
        logger.info("Builder registry initialized")

    async def register_builder(self, name: str, capabilities: List[str], endpoint: str):
        self._builders[name] = {"name": name, "capabilities": capabilities, "endpoint": endpoint, "status": "available", "registered_at": datetime.utcnow().isoformat()}

    async def get_builder(self, name: str) -> Optional[Dict[str, Any]]:
        return self._builders.get(name)

    async def list_builders(self) -> List[Dict[str, Any]]:
        return list(self._builders.values())
