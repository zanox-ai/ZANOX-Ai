"""UAOS Agent Registry"""
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
import uuid
logger = logging.getLogger(__name__)

class AgentRegistry:
    def __init__(self):
        self._agents: Dict[str, Dict[str, Any]] = {}

    async def initialize(self):
        logger.info("Agent registry initialized")

    async def register(self, agent_id: str, metadata: Dict[str, Any]) -> bool:
        self._agents[agent_id] = {"id": agent_id, "metadata": metadata, "registered_at": datetime.utcnow().isoformat(), "status": "active"}
        return True

    async def unregister(self, agent_id: str) -> bool:
        if agent_id in self._agents:
            self._agents[agent_id]["status"] = "inactive"
            return True
        return False

    async def get_agent(self, agent_id: str) -> Optional[Dict[str, Any]]:
        return self._agents.get(agent_id)

    async def list_agents(self, status: Optional[str] = None) -> List[Dict[str, Any]]:
        agents = list(self._agents.values())
        if status: agents = [a for a in agents if a["status"] == status]
        return agents
