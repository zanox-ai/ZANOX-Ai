"""UAOS Tool Registry"""
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
import uuid
logger = logging.getLogger(__name__)

class ToolRegistry:
    def __init__(self):
        self._tools: Dict[str, Dict[str, Any]] = {}

    async def initialize(self):
        logger.info("Tool registry initialized")

    async def register_tool(self, tool_id: str, name: str, tool_type: str, schema: Dict[str, Any]):
        self._tools[tool_id] = {"id": tool_id, "name": name, "type": tool_type, "schema": schema, "status": "active", "registered_at": datetime.utcnow().isoformat()}

    async def get_tool(self, tool_id: str) -> Optional[Dict[str, Any]]:
        return self._tools.get(tool_id)

    async def list_tools(self, tool_type: Optional[str] = None) -> List[Dict[str, Any]]:
        tools = list(self._tools.values())
        if tool_type: tools = [t for t in tools if t["type"] == tool_type]
        return tools

    async def unregister_tool(self, tool_id: str) -> bool:
        if tool_id in self._tools:
            self._tools[tool_id]["status"] = "inactive"
            return True
        return False
