"""UAOS Pipeline Manager"""
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
import uuid
logger = logging.getLogger(__name__)

class PipelineManager:
    def __init__(self):
        self._pipelines: Dict[str, Dict[str, Any]] = {}

    async def initialize(self):
        logger.info("Pipeline manager initialized")

    async def create_pipeline(self, name: str, stages: List[Dict[str, Any]]) -> str:
        pipeline_id = str(uuid.uuid4())
        self._pipelines[name] = dict(id=pipeline_id, name=name, stages=stages, status="ready", created_at=datetime.utcnow().isoformat())
        return pipeline_id

    async def execute_pipeline(self, name: str, input_data: Any) -> Dict[str, Any]:
        pipeline = self._pipelines.get(name)
        if not pipeline:
            return dict(error="Pipeline not found")
        pipeline["status"] = "running"
        results = []
        current = input_data
        for stage in pipeline["stages"]:
            try:
                handler = stage.get("handler")
                if handler and hasattr(handler, "__call__"):
                    result = handler(current)
                    if hasattr(result, "__await__"):
                        import asyncio
                        result = await result
                    current = result
                results.append(dict(stage=stage.get("name"), status="completed"))
            except Exception as e:
                results.append(dict(stage=stage.get("name"), status="failed", error=str(e)))
                break
        pipeline["status"] = "completed"
        return dict(pipeline=name, results=results, output=current, timestamp=datetime.utcnow().isoformat())

    async def get_pipeline(self, name: str) -> Optional[Dict[str, Any]]:
        return self._pipelines.get(name)

    async def list_pipelines(self) -> List[Dict[str, Any]]:
        return list(self._pipelines.values())
