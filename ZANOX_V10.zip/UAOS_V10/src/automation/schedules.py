"""UAOS Schedule Manager"""
import asyncio, logging
from typing import Dict, List, Any, Callable
from datetime import datetime, timedelta
import uuid
logger = logging.getLogger(__name__)

class ScheduleManager:
    def __init__(self):
        self._schedules: Dict[str, Dict[str, Any]] = {}
        self._running = False

    async def initialize(self):
        self._running = True
        asyncio.create_task(self._scheduler_loop())
        logger.info("Schedule manager initialized")

    async def add_schedule(self, name: str, interval_seconds: int, handler: Callable, enabled: bool = True) -> str:
        schedule_id = str(uuid.uuid4())
        self._schedules[name] = dict(id=schedule_id, name=name, interval=interval_seconds, handler=handler, enabled=enabled, last_run=None, next_run=datetime.utcnow().isoformat(), created_at=datetime.utcnow().isoformat())
        return schedule_id

    async def enable_schedule(self, name: str) -> bool:
        if name in self._schedules:
            self._schedules[name]["enabled"] = True
            return True
        return False

    async def disable_schedule(self, name: str) -> bool:
        if name in self._schedules:
            self._schedules[name]["enabled"] = False
            return True
        return False

    async def _scheduler_loop(self):
        while self._running:
            now = datetime.utcnow()
            for schedule in self._schedules.values():
                if not schedule["enabled"]:
                    continue
                last_run = schedule.get("last_run")
                if last_run:
                    last = datetime.fromisoformat(last_run)
                    if (now - last).total_seconds() < schedule["interval"]:
                        continue
                try:
                    if hasattr(schedule["handler"], "__call__"):
                        result = schedule["handler"]()
                        if hasattr(result, "__await__"):
                            asyncio.create_task(result)
                    schedule["last_run"] = now.isoformat()
                except Exception as e:
                    logger.error(f"Schedule error: {e}")
            await asyncio.sleep(1)

    async def list_schedules(self) -> List[Dict[str, Any]]:
        return list(self._schedules.values())
