"""UAOS Trigger Manager"""
import logging
from typing import Dict, List, Any, Callable, Optional
from datetime import datetime
import uuid
logger = logging.getLogger(__name__)

class TriggerManager:
    def __init__(self):
        self._triggers: Dict[str, Dict[str, Any]] = {}

    async def initialize(self):
        logger.info("Trigger manager initialized")

    async def add_trigger(self, name: str, trigger_type: str, condition: Dict[str, Any], action: Callable) -> str:
        trigger_id = str(uuid.uuid4())
        self._triggers[name] = dict(id=trigger_id, name=name, type=trigger_type, condition=condition, action=action, created_at=datetime.utcnow().isoformat())
        return trigger_id

    async def evaluate_trigger(self, name: str, event: Dict[str, Any]) -> bool:
        trigger = self._triggers.get(name)
        if not trigger:
            return False
        condition = trigger["condition"]
        match = all(event.get(k) == v for k, v in condition.items())
        if match and trigger["action"]:
            try:
                if hasattr(trigger["action"], "__call__"):
                    result = trigger["action"](event)
                    if hasattr(result, "__await__"):
                        import asyncio
                        asyncio.create_task(result)
            except Exception as e:
                logger.error(f"Trigger action error: {e}")
        return match

    async def list_triggers(self) -> List[Dict[str, Any]]:
        return list(self._triggers.values())

    async def remove_trigger(self, name: str) -> bool:
        if name in self._triggers:
            del self._triggers[name]
            return True
        return False
