"""UAOS Action Manager"""
import logging
from typing import Dict, List, Any, Callable
from datetime import datetime
import uuid
logger = logging.getLogger(__name__)

class ActionManager:
    def __init__(self):
        self._actions: Dict[str, Dict[str, Any]] = {}

    async def initialize(self):
        logger.info("Action manager initialized")

    async def register_action(self, name: str, handler: Callable, parameters: Dict[str, Any] = None):
        self._actions[name] = dict(name=name, handler=handler, parameters=parameters or {}, created_at=datetime.utcnow().isoformat())

    async def execute_action(self, name: str, parameters: Dict[str, Any] = None) -> Any:
        action = self._actions.get(name)
        if not action:
            return None
        try:
            merged = dict(action["parameters"])
            if parameters:
                merged.update(parameters)
            result = action["handler"](**merged)
            if hasattr(result, "__await__"):
                import asyncio
                return await result
            return result
        except Exception as e:
            logger.error(f"Action execution error: {e}")
            return None

    async def list_actions(self) -> List[Dict[str, Any]]:
        return list(self._actions.values())
