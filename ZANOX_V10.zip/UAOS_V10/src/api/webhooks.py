"""UAOS Webhook Manager"""
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
import uuid
logger = logging.getLogger(__name__)

class WebhookManager:
    def __init__(self):
        self._webhooks: Dict[str, Dict[str, Any]] = {}

    async def initialize(self):
        logger.info("Webhook manager initialized")

    async def register_webhook(self, name: str, url: str, events: List[str], secret: str = "") -> str:
        webhook_id = str(uuid.uuid4())
        self._webhooks[name] = dict(id=webhook_id, name=name, url=url, events=events, secret=secret, created_at=datetime.utcnow().isoformat())
        return webhook_id

    async def trigger_webhook(self, name: str, payload: Dict[str, Any]) -> bool:
        if name not in self._webhooks:
            return False
        logger.info(f"Webhook triggered: {name}")
        return True

    async def list_webhooks(self) -> List[Dict[str, Any]]:
        return list(self._webhooks.values())

    async def delete_webhook(self, name: str) -> bool:
        if name in self._webhooks:
            del self._webhooks[name]
            return True
        return False
