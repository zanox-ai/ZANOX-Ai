"""UAOS API Middleware"""
import logging
from typing import Dict, List, Any, Callable
from datetime import datetime
logger = logging.getLogger(__name__)

class APIMiddleware:
    def __init__(self):
        self._middlewares: List[Dict[str, Any]] = []

    async def initialize(self):
        logger.info("API middleware initialized")

    async def add_middleware(self, name: str, handler: Callable, priority: int = 5):
        self._middlewares.append(dict(name=name, handler=handler, priority=priority))
        self._middlewares.sort(key=lambda x: x["priority"])

    async def process_request(self, request: Dict[str, Any]) -> Dict[str, Any]:
        for mw in self._middlewares:
            try:
                request = await mw["handler"](request) if hasattr(mw["handler"], "__call__") else request
            except Exception as e:
                logger.error(f"Middleware {mw['name']} error: {e}")
        return request

    async def list_middleware(self) -> List[Dict[str, Any]]:
        return self._middlewares
