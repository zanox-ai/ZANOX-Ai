"""UAOS API Routes"""
import logging
from typing import Dict, List, Any
from datetime import datetime
logger = logging.getLogger(__name__)

class APIRoutes:
    def __init__(self):
        self._routes: Dict[str, Dict[str, Any]] = {}

    async def initialize(self):
        logger.info("API routes initialized")

    async def define_route(self, path: str, methods: List[str], handler, tags: List[str] = None):
        self._routes[path] = dict(path=path, methods=methods, handler=handler, tags=tags or [], created_at=datetime.utcnow().isoformat())

    async def get_route(self, path: str) -> Dict[str, Any]:
        return self._routes.get(path)

    async def list_routes(self) -> List[Dict[str, Any]]:
        return list(self._routes.values())

    async def remove_route(self, path: str) -> bool:
        if path in self._routes:
            del self._routes[path]
            return True
        return False
