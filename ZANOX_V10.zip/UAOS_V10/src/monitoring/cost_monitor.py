"""UAOS Cost Monitoring"""
import asyncio, logging
from typing import Dict, List, Any, Optional
from datetime import datetime
logger = logging.getLogger(__name__)

class CostMonitoring:
    def __init__(self):
        self._costs: Dict[str, List[Dict[str, Any]]] = {}
        self._budgets: Dict[str, float] = {}

    async def initialize(self):
        logger.info("Cost monitoring initialized")

    async def record_cost(self, service_id: str, amount: float, category: str = "compute"):
        if service_id not in self._costs: self._costs[service_id] = []
        self._costs[service_id].append({"amount": amount, "category": category, "timestamp": datetime.utcnow().isoformat()})

    async def set_budget(self, service_id: str, budget: float):
        self._budgets[service_id] = budget

    async def get_cost_summary(self, service_id: Optional[str] = None) -> Dict[str, Any]:
        if service_id:
            costs = self._costs.get(service_id, [])
            total = sum(c["amount"] for c in costs)
            budget = self._budgets.get(service_id, 0)
            return {"service_id": service_id, "total_cost": total, "budget": budget, "utilization": (total / budget * 100) if budget else 0, "entries": len(costs)}
        return {sid: await self.get_cost_summary(sid) for sid in self._costs}
