"""UAOS Capacity Monitoring"""
import asyncio, logging
from typing import Dict, List, Any
from datetime import datetime
logger = logging.getLogger(__name__)

class CapacityMonitoring:
    def __init__(self):
        self._resources: Dict[str, Dict[str, Any]] = {}

    async def initialize(self):
        logger.info("Capacity monitoring initialized")

    async def track_resource(self, resource_id: str, total_capacity: float, current_usage: float):
        self._resources[resource_id] = {"id": resource_id, "total": total_capacity, "usage": current_usage, "utilization": (current_usage / total_capacity) * 100 if total_capacity else 0, "timestamp": datetime.utcnow().isoformat()}

    async def get_utilization(self, resource_id: str) -> float:
        return self._resources.get(resource_id, {}).get("utilization", 0)

    async def get_all_capacity(self) -> Dict[str, Any]:
        return {rid: {"utilization": r["utilization"], "total": r["total"], "usage": r["usage"]} for rid, r in self._resources.items()}

    async def predict_capacity(self, resource_id: str, days: int = 7) -> Dict[str, Any]:
        current = self._resources.get(resource_id, {})
        return {"resource_id": resource_id, "current_utilization": current.get("utilization", 0), "predicted_utilization_7d": min(current.get("utilization", 0) * 1.1, 100), "timestamp": datetime.utcnow().isoformat()}
