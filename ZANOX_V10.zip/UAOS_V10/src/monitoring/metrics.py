"""
UAOS Metrics Collection
Production-Ready Implementation
"""
import asyncio
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
import uuid
import statistics

logger = logging.getLogger(__name__)

class MetricsCollection:
    """
    Centralized metrics collection system.
    Collects, aggregates, and stores system metrics.
    """

    def __init__(self):
        self._metrics: Dict[str, List[Dict[str, Any]]] = {}
        self._running = False
        self._collectors: List[Dict[str, Any]] = []

    async def initialize(self):
        """Initialize metrics collection"""
        self._running = True
        logger.info("Metrics collection initialized")

    async def start(self):
        """Start metrics collection"""
        asyncio.create_task(self._collection_loop())
        logger.info("Metrics collection started")

    async def record_metric(
        self,
        metric_name: str,
        value: float,
        labels: Optional[Dict[str, str]] = None,
        metric_type: str = "gauge"
    ):
        """Record a metric"""
        if metric_name not in self._metrics:
            self._metrics[metric_name] = []

        self._metrics[metric_name].append({
            "value": value,
            "labels": labels or {},
            "type": metric_type,
            "timestamp": datetime.utcnow().isoformat()
        })

    async def get_metric(
        self,
        metric_name: str,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """Get metric data"""
        metrics = self._metrics.get(metric_name, [])

        if start_time:
            metrics = [m for m in metrics if m["timestamp"] >= start_time]
        if end_time:
            metrics = [m for m in metrics if m["timestamp"] <= end_time]

        return metrics

    async def get_aggregated(
        self,
        metric_name: str,
        aggregation: str = "avg"
    ) -> Optional[float]:
        """Get aggregated metric value"""
        metrics = self._metrics.get(metric_name, [])
        values = [m["value"] for m in metrics]

        if not values:
            return None

        if aggregation == "avg":
            return statistics.mean(values)
        elif aggregation == "min":
            return min(values)
        elif aggregation == "max":
            return max(values)
        elif aggregation == "sum":
            return sum(values)
        elif aggregation == "count":
            return len(values)

        return None

    async def register_collector(self, name: str, collector_func, interval: int = 60):
        """Register a metric collector"""
        self._collectors.append({
            "name": name,
            "func": collector_func,
            "interval": interval
        })

    async def _collection_loop(self):
        """Periodic collection loop"""
        while self._running:
            for collector in self._collectors:
                try:
                    metrics = await collector["func"]()
                    for metric in metrics:
                        await self.record_metric(
                            metric["name"],
                            metric["value"],
                            metric.get("labels"),
                            metric.get("type", "gauge")
                        )
                except Exception as e:
                    logger.error(f"Collector {collector['name']} error: {e}")

            await asyncio.sleep(60)

    async def get_all_metrics(self) -> Dict[str, Any]:
        """Get all metrics summary"""
        return {
            metric_name: {
                "count": len(data),
                "latest": data[-1]["value"] if data else None,
                "avg": statistics.mean([d["value"] for d in data]) if data else None
            }
            for metric_name, data in self._metrics.items()
        }
