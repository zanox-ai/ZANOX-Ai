"""UAOS Alerting Engine"""
import asyncio, logging
from typing import Dict, List, Any, Optional
from datetime import datetime
import uuid
logger = logging.getLogger(__name__)

class AlertingEngine:
    def __init__(self):
        self._rules: Dict[str, Dict[str, Any]] = {}
        self._alerts: List[Dict[str, Any]] = []
        self._running = False

    async def initialize(self):
        self._running = True
        asyncio.create_task(self._evaluation_loop())
        logger.info("Alerting engine initialized")

    async def add_rule(self, name: str, condition: str, threshold: float, severity: str = "warning") -> str:
        rule_id = str(uuid.uuid4())
        self._rules[rule_id] = {"id": rule_id, "name": name, "condition": condition, "threshold": threshold, "severity": severity, "created_at": datetime.utcnow().isoformat()}
        return rule_id

    async def evaluate(self, metric_name: str, value: float) -> List[Dict[str, Any]]:
        triggered = []
        for rule in self._rules.values():
            if rule["condition"] == "gt" and value > rule["threshold"]:
                alert = {"id": str(uuid.uuid4()), "rule_id": rule["id"], "metric": metric_name, "value": value, "severity": rule["severity"], "timestamp": datetime.utcnow().isoformat()}
                self._alerts.append(alert)
                triggered.append(alert)
                logger.warning(f"Alert triggered: {rule['name']} - {value}")
        return triggered

    async def get_alerts(self, severity: Optional[str] = None) -> List[Dict[str, Any]]:
        if severity: return [a for a in self._alerts if a["severity"] == severity]
        return self._alerts

    async def _evaluation_loop(self):
        while self._running:
            await asyncio.sleep(60)
