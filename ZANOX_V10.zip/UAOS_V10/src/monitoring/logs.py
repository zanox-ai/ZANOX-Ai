"""
UAOS Log Aggregation
Production-Ready Implementation
"""
import asyncio
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
import uuid
import json

logger = logging.getLogger(__name__)

class LogAggregation:
    """
    Centralized log aggregation system.
    Collects, indexes, and queries logs from all services.
    """

    def __init__(self):
        self._logs: List[Dict[str, Any]] = []
        self._running = False
        self._index: Dict[str, List[int]] = {}

    async def initialize(self):
        """Initialize log aggregation"""
        self._running = True
        logger.info("Log aggregation initialized")

    async def ingest_log(self, log_entry: Dict[str, Any]):
        """Ingest a log entry"""
        log_entry["id"] = str(uuid.uuid4())
        log_entry["ingested_at"] = datetime.utcnow().isoformat()

        index = len(self._logs)
        self._logs.append(log_entry)

        # Index by service
        service = log_entry.get("service", "unknown")
        if service not in self._index:
            self._index[service] = []
        self._index[service].append(index)

    async def query_logs(
        self,
        service: Optional[str] = None,
        level: Optional[str] = None,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        search_query: Optional[str] = None,
        limit: int = 100
    ) -> List[Dict[str, Any]]:
        """Query logs"""
        results = self._logs

        if service and service in self._index:
            results = [self._logs[i] for i in self._index[service]]

        if level:
            results = [l for l in results if l.get("level") == level]
        if start_time:
            results = [l for l in results if l.get("timestamp", "") >= start_time]
        if end_time:
            results = [l for l in results if l.get("timestamp", "") <= end_time]
        if search_query:
            results = [
                l for l in results
                if search_query.lower() in json.dumps(l).lower()
            ]

        return results[-limit:]

    async def get_log_stats(self) -> Dict[str, Any]:
        """Get log statistics"""
        levels = {}
        for log in self._logs:
            level = log.get("level", "unknown")
            levels[level] = levels.get(level, 0) + 1

        return {
            "total_logs": len(self._logs),
            "by_service": {k: len(v) for k, v in self._index.items()},
            "by_level": levels
        }
