"""UAOS Health Monitoring"""
import asyncio, logging
from typing import Dict, List, Any, Optional
from datetime import datetime
logger = logging.getLogger(__name__)

class HealthMonitoring:
    def __init__(self):
        self._services: Dict[str, Dict[str, Any]] = {}
        self._running = False

    async def initialize(self):
        self._running = True
        asyncio.create_task(self._check_loop())
        logger.info("Health monitoring initialized")

    async def register_service(self, service_id: str, name: str, check_func):
        self._services[service_id] = {"id": service_id, "name": name, "check": check_func, "status": "unknown", "last_check": None}

    async def check_service(self, service_id: str) -> Dict[str, Any]:
        svc = self._services.get(service_id)
        if not svc: return {}
        try:
            result = await svc["check"]() if asyncio.iscoroutinefunction(svc["check"]) else svc["check"]()
            svc["status"] = "healthy" if result else "unhealthy"
        except Exception as e:
            svc["status"] = "unhealthy"
            svc["error"] = str(e)
        svc["last_check"] = datetime.utcnow().isoformat()
        return {"service_id": service_id, "status": svc["status"], "last_check": svc["last_check"]}

    async def get_all_health(self) -> Dict[str, Any]:
        return {sid: {"status": s["status"], "last_check": s["last_check"]} for sid, s in self._services.items()}

    async def _check_loop(self):
        while self._running:
            for sid in self._services:
                await self.check_service(sid)
            await asyncio.sleep(30)
