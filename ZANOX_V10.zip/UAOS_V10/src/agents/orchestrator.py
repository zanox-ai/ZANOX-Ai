"""
UAOS Multi-Agent Orchestrator
Production-Ready Implementation
"""
import asyncio
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
import uuid

logger = logging.getLogger(__name__)

class MultiAgentOrchestrator:
    """
    Central orchestrator for multi-agent systems.
    Manages agent coordination, task distribution, and workflow execution.
    """

    def __init__(self):
        self._agents: Dict[str, Dict[str, Any]] = {}
        self._workflows: Dict[str, Dict[str, Any]] = {}
        self._running = False
        self._task_queue = asyncio.Queue()

    async def initialize(self):
        """Initialize orchestrator"""
        logger.info("Multi-agent orchestrator initialized")

    async def start(self):
        """Start orchestrator"""
        self._running = True
        asyncio.create_task(self._orchestration_loop())
        logger.info("Multi-agent orchestrator started")

    async def stop(self):
        """Stop orchestrator"""
        self._running = False
        logger.info("Multi-agent orchestrator stopped")

    async def register_agent(self, agent_config: Dict[str, Any]) -> str:
        """Register an agent"""
        agent_id = agent_config.get("id") or str(uuid.uuid4())

        self._agents[agent_id] = {
            "id": agent_id,
            "name": agent_config.get("name", "unnamed"),
            "type": agent_config.get("type", "generic"),
            "capabilities": agent_config.get("capabilities", []),
            "status": "idle",
            "registered_at": datetime.utcnow().isoformat(),
            "last_heartbeat": datetime.utcnow().isoformat(),
            "tasks_completed": 0,
            "tasks_failed": 0
        }

        logger.info(f"Agent registered: {agent_id}")
        return agent_id

    async def unregister_agent(self, agent_id: str) -> bool:
        """Unregister an agent"""
        if agent_id in self._agents:
            del self._agents[agent_id]
            logger.info(f"Agent unregistered: {agent_id}")
            return True
        return False

    async def submit_task(self, task: Dict[str, Any]) -> str:
        """Submit task for execution"""
        task_id = str(uuid.uuid4())

        task_obj = {
            "id": task_id,
            "type": task.get("type", "generic"),
            "priority": task.get("priority", 5),
            "requirements": task.get("requirements", []),
            "payload": task.get("payload", {}),
            "status": "queued",
            "assigned_agent": None,
            "created_at": datetime.utcnow().isoformat()
        }

        await self._task_queue.put(task_obj)
        logger.info(f"Task submitted: {task_id}")
        return task_id

    async def get_agent_status(self, agent_id: str) -> Optional[Dict[str, Any]]:
        """Get agent status"""
        return self._agents.get(agent_id)

    async def list_agents(self, agent_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """List all agents"""
        agents = list(self._agents.values())
        if agent_type:
            agents = [a for a in agents if a["type"] == agent_type]
        return agents

    async def _orchestration_loop(self):
        """Main orchestration loop"""
        while self._running:
            try:
                task = await asyncio.wait_for(self._task_queue.get(), timeout=1.0)
                await self._assign_task(task)
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                logger.error(f"Orchestration error: {e}")

    async def _assign_task(self, task: Dict[str, Any]):
        """Assign task to appropriate agent"""
        requirements = task.get("requirements", [])

        # Find suitable agent
        suitable_agents = [
            a for a in self._agents.values()
            if a["status"] == "idle" and all(r in a["capabilities"] for r in requirements)
        ]

        if suitable_agents:
            # Select agent with lowest load
            agent = min(suitable_agents, key=lambda a: a["tasks_completed"])
            agent["status"] = "busy"
            task["assigned_agent"] = agent["id"]
            task["status"] = "assigned"

            logger.info(f"Task {task['id']} assigned to agent {agent['id']}")

            # Execute task
            asyncio.create_task(self._execute_task(task, agent))
        else:
            # Re-queue task
            await self._task_queue.put(task)
            logger.warning(f"No suitable agent for task {task['id']}, re-queued")

    async def _execute_task(self, task: Dict[str, Any], agent: Dict[str, Any]):
        """Execute task with agent"""
        try:
            task["status"] = "running"

            # Simulate task execution
            await asyncio.sleep(1)

            task["status"] = "completed"
            task["completed_at"] = datetime.utcnow().isoformat()
            agent["tasks_completed"] += 1
            agent["status"] = "idle"

            logger.info(f"Task {task['id']} completed by agent {agent['id']}")

        except Exception as e:
            task["status"] = "failed"
            task["error"] = str(e)
            agent["tasks_failed"] += 1
            agent["status"] = "idle"

            logger.error(f"Task {task['id']} failed: {e}")
