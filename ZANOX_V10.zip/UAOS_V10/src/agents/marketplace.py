"""
UAOS Agent Marketplace
Production-Ready Implementation
"""
import asyncio
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
import uuid

logger = logging.getLogger(__name__)

class AgentMarketplace:
    """
    Marketplace for agents - publish, discover, and acquire agents.
    """

    def __init__(self):
        self._listings: Dict[str, Dict[str, Any]] = {}
        self._transactions: List[Dict[str, Any]] = []

    async def list_agent(self, agent_config: Dict[str, Any], price: float = 0.0) -> str:
        """List an agent on the marketplace"""
        listing_id = str(uuid.uuid4())

        self._listings[listing_id] = {
            "id": listing_id,
            "agent": agent_config,
            "price": price,
            "status": "active",
            "created_at": datetime.utcnow().isoformat(),
            "downloads": 0,
            "rating": 0.0
        }

        logger.info(f"Agent listed: {listing_id}")
        return listing_id

    async def search_listings(self, query: str) -> List[Dict[str, Any]]:
        """Search marketplace listings"""
        results = []
        for listing in self._listings.values():
            if query.lower() in listing["agent"].get("name", "").lower():
                results.append(listing)
        return results

    async def acquire_agent(self, listing_id: str, buyer_id: str) -> Optional[Dict[str, Any]]:
        """Acquire an agent from marketplace"""
        if listing_id in self._listings:
            listing = self._listings[listing_id]
            listing["downloads"] += 1

            transaction = {
                "id": str(uuid.uuid4()),
                "listing_id": listing_id,
                "buyer_id": buyer_id,
                "price": listing["price"],
                "timestamp": datetime.utcnow().isoformat()
            }
            self._transactions.append(transaction)

            logger.info(f"Agent acquired: {listing_id} by {buyer_id}")
            return listing["agent"]
        return None

    async def rate_agent(self, listing_id: str, rating: float, review: str = ""):
        """Rate an agent listing"""
        if listing_id in self._listings:
            listing = self._listings[listing_id]
            current_rating = listing["rating"]
            downloads = listing["downloads"]

            if downloads > 0:
                new_rating = (current_rating * (downloads - 1) + rating) / downloads
                listing["rating"] = new_rating

            logger.info(f"Agent rated: {listing_id} - {rating}")
