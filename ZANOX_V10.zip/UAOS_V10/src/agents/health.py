"""
UAOS Agent Health Monitor
Production-Ready Implementation
"""
import asyncio
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime

logger = logging.getLogger(__name__)

class AgentHealthMonitor:
    """
    Monitors agent health and performance.
    Detects failures and triggers recovery.
    """

    def __init__(self):
        self._health_data: Dict[str, Dict[str, Any]] = {}
        self._running = False
        self._check_interval = 30

    async def start(self):
        """Start health monitoring"""
        self._running = True
        asyncio.create_task(self._monitoring_loop())
        logger.info("Agent health monitor started")

    async def stop(self):
        """Stop health monitoring"""
        self._running = False
        logger.info("Agent health monitor stopped")

    async def register_agent(self, agent_id: str):
        """Register agent for monitoring"""
        self._health_data[agent_id] = {
            "agent_id": agent_id,
            "status": "healthy",
            "last_heartbeat": datetime.utcnow().isoformat(),
            "cpu_usage": 0.0,
            "memory_usage": 0.0,
            "task_success_rate": 1.0,
            "response_time_ms": 0,
            "error_count": 0
        }

    async def update_heartbeat(self, agent_id: str, metrics: Dict[str, Any]):
        """Update agent heartbeat"""
        if agent_id in self._health_data:
            self._health_data[agent_id].update(metrics)
            self._health_data[agent_id]["last_heartbeat"] = datetime.utcnow().isoformat()

    async def get_health(self, agent_id: Optional[str] = None) -> Dict[str, Any]:
        """Get health status"""
        if agent_id:
            return self._health_data.get(agent_id, {})
        return self._health_data

    async def _monitoring_loop(self):
        """Health monitoring loop"""
        while self._running:
            for agent_id, data in self._health_data.items():
                last_heartbeat = datetime.fromisoformat(data["last_heartbeat"])
                elapsed = (datetime.utcnow() - last_heartbeat).total_seconds()

                if elapsed > 60:
                    data["status"] = "unhealthy"
                    logger.warning(f"Agent {agent_id} heartbeat timeout")
                elif data["error_count"] > 10:
                    data["status"] = "degraded"
                    logger.warning(f"Agent {agent_id} degraded - high error count")
                else:
                    data["status"] = "healthy"

            await asyncio.sleep(self._check_interval)
