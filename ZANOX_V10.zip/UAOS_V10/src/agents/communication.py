"""
UAOS Agent Communication Bus
Production-Ready Implementation
"""
import asyncio
import logging
from typing import Dict, List, Any, Callable, Optional
from datetime import datetime
import uuid

logger = logging.getLogger(__name__)

class AgentCommunicationBus:
    """
    Communication bus for inter-agent messaging.
    Supports direct, broadcast, and pub/sub patterns.
    """

    def __init__(self):
        self._channels: Dict[str, List[Callable]] = {}
        self._agent_mailboxes: Dict[str, asyncio.Queue] = {}
        self._message_history: List[Dict[str, Any]] = []

    async def register_agent(self, agent_id: str):
        """Register agent mailbox"""
        self._agent_mailboxes[agent_id] = asyncio.Queue()
        logger.info(f"Agent registered on bus: {agent_id}")

    async def send_message(
        self,
        sender_id: str,
        recipient_id: str,
        message_type: str,
        payload: Dict[str, Any]
    ) -> str:
        """Send message to specific agent"""
        message_id = str(uuid.uuid4())

        message = {
            "id": message_id,
            "sender": sender_id,
            "recipient": recipient_id,
            "type": message_type,
            "payload": payload,
            "timestamp": datetime.utcnow().isoformat()
        }

        if recipient_id in self._agent_mailboxes:
            await self._agent_mailboxes[recipient_id].put(message)

        self._message_history.append(message)
        logger.debug(f"Message sent: {message_id} from {sender_id} to {recipient_id}")
        return message_id

    async def broadcast(self, sender_id: str, message_type: str, payload: Dict[str, Any]):
        """Broadcast message to all agents"""
        for agent_id in self._agent_mailboxes:
            await self.send_message(sender_id, agent_id, message_type, payload)

    async def subscribe(self, channel: str, handler: Callable):
        """Subscribe to channel"""
        if channel not in self._channels:
            self._channels[channel] = []
        self._channels[channel].append(handler)

    async def get_messages(self, agent_id: str, timeout: float = 1.0) -> List[Dict[str, Any]]:
        """Get messages for agent"""
        messages = []
        if agent_id in self._agent_mailboxes:
            try:
                while True:
                    msg = await asyncio.wait_for(
                        self._agent_mailboxes[agent_id].get(),
                        timeout=timeout
                    )
                    messages.append(msg)
            except asyncio.TimeoutError:
                pass
        return messages
