"""
UAOS Agent Governance System
Production-Ready Implementation
"""
import asyncio
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
import uuid

logger = logging.getLogger(__name__)

class AgentGovernanceSystem:
    """
    Governance system for agent behavior and compliance.
    Enforces policies and tracks compliance.
    """

    def __init__(self):
        self._policies: Dict[str, Dict[str, Any]] = {}
        self._violations: List[Dict[str, Any]] = []
        self._audit_log: List[Dict[str, Any]] = []

    async def create_policy(
        self,
        name: str,
        rules: List[Dict[str, Any]],
        scope: str = "global"
    ) -> str:
        """Create governance policy"""
        policy_id = str(uuid.uuid4())

        self._policies[policy_id] = {
            "id": policy_id,
            "name": name,
            "rules": rules,
            "scope": scope,
            "status": "active",
            "created_at": datetime.utcnow().isoformat()
        }

        logger.info(f"Policy created: {policy_id}")
        return policy_id

    async def check_compliance(
        self,
        agent_id: str,
        action: Dict[str, Any]
    ) -> bool:
        """Check if action complies with policies"""
        for policy in self._policies.values():
            if policy["status"] == "active":
                for rule in policy["rules"]:
                    if not self._check_rule(rule, action):
                        self._violations.append({
                            "agent_id": agent_id,
                            "policy_id": policy["id"],
                            "rule": rule["name"],
                            "action": action,
                            "timestamp": datetime.utcnow().isoformat()
                        })
                        return False

        self._audit_log.append({
            "agent_id": agent_id,
            "action": action,
            "compliant": True,
            "timestamp": datetime.utcnow().isoformat()
        })

        return True

    def _check_rule(self, rule: Dict[str, Any], action: Dict[str, Any]) -> bool:
        """Check if action complies with rule"""
        action_type = action.get("type", "")
        allowed_types = rule.get("allowed_types", [])

        if allowed_types and action_type not in allowed_types:
            return False

        return True

    async def get_violations(self, agent_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get policy violations"""
        if agent_id:
            return [v for v in self._violations if v["agent_id"] == agent_id]
        return self._violations

    async def get_audit_log(self, agent_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get audit log"""
        if agent_id:
            return [entry for entry in self._audit_log if entry["agent_id"] == agent_id]
        return self._audit_log
