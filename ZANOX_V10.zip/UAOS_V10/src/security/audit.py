"""
UAOS Audit Logging
Production-Ready Implementation
"""
import asyncio
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
import uuid
import json

logger = logging.getLogger(__name__)

class AuditLogging:
    """
    Comprehensive audit logging system.
    Tracks all system actions with tamper-evident logs.
    """

    def __init__(self, log_file: str = "uaos_audit.log"):
        self._log_file = log_file
        self._logs: List[Dict[str, Any]] = []
        self._running = False

    async def initialize(self):
        """Initialize audit logging"""
        self._running = True
        asyncio.create_task(self._flush_loop())
        logger.info("Audit logging initialized")

    async def log_event(
        self,
        event_type: str,
        actor: str,
        action: str,
        resource: str,
        result: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> str:
        """Log audit event"""
        log_id = str(uuid.uuid4())

        event = {
            "id": log_id,
            "timestamp": datetime.utcnow().isoformat(),
            "event_type": event_type,
            "actor": actor,
            "action": action,
            "resource": resource,
            "result": result,
            "metadata": metadata or {},
            "hash": self._compute_hash(log_id)
        }

        self._logs.append(event)

        # Write to file immediately for critical events
        if event_type in ["security", "auth"]:
            await self._write_to_file([event])

        return log_id

    async def query_logs(
        self,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        actor: Optional[str] = None,
        event_type: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """Query audit logs"""
        results = self._logs

        if start_time:
            results = [l for l in results if l["timestamp"] >= start_time]
        if end_time:
            results = [l for l in results if l["timestamp"] <= end_time]
        if actor:
            results = [l for l in results if l["actor"] == actor]
        if event_type:
            results = [l for l in results if l["event_type"] == event_type]

        return results

    async def get_log_by_id(self, log_id: str) -> Optional[Dict[str, Any]]:
        """Get log by ID"""
        for log in self._logs:
            if log["id"] == log_id:
                return log
        return None

    async def verify_integrity(self) -> bool:
        """Verify log integrity"""
        for log in self._logs:
            expected_hash = self._compute_hash(log["id"])
            if log["hash"] != expected_hash:
                return False
        return True

    def _compute_hash(self, log_id: str) -> str:
        """Compute tamper-evident hash"""
        import hashlib
        return hashlib.sha256(f"{log_id}{datetime.utcnow().isoformat()}".encode()).hexdigest()[:16]

    async def _flush_loop(self):
        """Periodic flush to disk"""
        while self._running:
            if self._logs:
                await self._write_to_file(self._logs)
                self._logs = []
            await asyncio.sleep(300)

    async def _write_to_file(self, logs: List[Dict[str, Any]]):
        """Write logs to file"""
        with open(self._log_file, "a") as f:
            for log in logs:
                f.write(json.dumps(log) + "\n")
