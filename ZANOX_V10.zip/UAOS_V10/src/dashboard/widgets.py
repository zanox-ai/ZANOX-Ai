"""UAOS Dashboard Widgets"""
import logging
from typing import Dict, List, Any
from datetime import datetime
logger = logging.getLogger(__name__)

class DashboardWidgets:
    WIDGET_TYPES = ["chart", "table", "metric", "list", "map", "timeline"]

    def __init__(self):
        self._widget_registry: Dict[str, Dict[str, Any]] = {}

    async def initialize(self):
        logger.info("Dashboard widgets initialized")

    async def register_widget_type(self, widget_type: str, schema: Dict[str, Any]):
        self._widget_registry[widget_type] = {"type": widget_type, "schema": schema, "registered_at": datetime.utcnow().isoformat()}

    async def create_widget(self, widget_type: str, title: str, data_source: str) -> Dict[str, Any]:
        if widget_type not in self.WIDGET_TYPES: return {"error": "Invalid widget type"}
        return {"type": widget_type, "title": title, "data_source": data_source, "created_at": datetime.utcnow().isoformat()}

    async def get_widget_types(self) -> List[str]:
        return self.WIDGET_TYPES
