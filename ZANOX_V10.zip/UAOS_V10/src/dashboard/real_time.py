"""UAOS Real-Time Updates"""
import asyncio, logging
from typing import Dict, List, Any, Callable
from datetime import datetime
logger = logging.getLogger(__name__)

class RealTimeUpdates:
    def __init__(self):
        self._subscribers: Dict[str, List[Callable]] = {}
        self._running = False

    async def initialize(self):
        self._running = True
        asyncio.create_task(self._broadcast_loop())
        logger.info("Real-time updates initialized")

    async def subscribe(self, channel: str, callback: Callable):
        if channel not in self._subscribers: self._subscribers[channel] = []
        self._subscribers[channel].append(callback)

    async def publish(self, channel: str, data: Any):
        if channel in self._subscribers:
            for callback in self._subscribers[channel]:
                try:
                    if asyncio.iscoroutinefunction(callback): await callback(data)
                    else: callback(data)
                except Exception as e: logger.error(f"Callback error: {e}")

    async def _broadcast_loop(self):
        while self._running:
            await asyncio.sleep(1)
