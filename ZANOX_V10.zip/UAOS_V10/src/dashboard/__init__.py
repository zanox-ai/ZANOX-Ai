"""UAOS Dashboard System"""
from .unified_dashboard import UnifiedDashboard
from .widgets import DashboardWidgets
from .real_time import RealTimeUpdates
from .reporting import ReportingEngine
__all__ = ["UnifiedDashboard", "DashboardWidgets", "RealTimeUpdates", "ReportingEngine"]
