"""UAOS Seed Manager"""
import logging
from typing import Dict, List, Any
from datetime import datetime
import uuid
logger = logging.getLogger(__name__)

class SeedManager:
    def __init__(self):
        self._seeds: List[Dict[str, Any]] = []

    async def initialize(self):
        logger.info("Seed manager initialized")

    async def add_seed(self, table: str, data: Dict[str, Any]):
        self._seeds.append(dict(table=table, data=data, id=str(uuid.uuid4()), created_at=datetime.utcnow().isoformat()))

    async def execute_seeds(self) -> Dict[str, Any]:
        count = len(self._seeds)
        return dict(seeded=count, tables=list(set(s["table"] for s in self._seeds)), timestamp=datetime.utcnow().isoformat())

    async def get_seeds(self) -> List[Dict[str, Any]]:
        return self._seeds

    async def clear_seeds(self):
        self._seeds = []
