"""UAOS Query Builder"""
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
logger = logging.getLogger(__name__)

class QueryBuilder:
    def __init__(self):
        self._query = ""
        self._parameters = {}

    async def initialize(self):
        logger.info("Query builder initialized")

    async def select(self, table: str, columns: List[str] = None) -> "QueryBuilder":
        self._query = f"SELECT {', '.join(columns or ['*'])} FROM {table}"
        return self

    async def where(self, conditions: Dict[str, Any]) -> "QueryBuilder":
        clauses = [f"{k} = :{k}" for k in conditions]
        self._query += " WHERE " + " AND ".join(clauses)
        self._parameters.update(conditions)
        return self

    async def order_by(self, column: str, direction: str = "ASC") -> "QueryBuilder":
        self._query += f" ORDER BY {column} {direction}"
        return self

    async def build(self) -> Dict[str, Any]:
        return dict(query=self._query, parameters=self._parameters, timestamp=datetime.utcnow().isoformat())
