"""UAOS Data Models"""
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
import uuid
logger = logging.getLogger(__name__)

class DataModels:
    def __init__(self):
        self._models: Dict[str, Dict[str, Any]] = {}

    async def initialize(self):
        logger.info("Data models initialized")

    async def define_model(self, name: str, fields: Dict[str, Any], relationships: Optional[Dict[str, Any]] = None):
        self._models[name] = dict(name=name, fields=fields, relationships=relationships or {}, created_at=datetime.utcnow().isoformat())

    async def get_model(self, name: str) -> Optional[Dict[str, Any]]:
        return self._models.get(name)

    async def list_models(self) -> List[Dict[str, Any]]:
        return list(self._models.values())

    async def validate_data(self, model_name: str, data: Dict[str, Any]) -> List[str]:
        model = self._models.get(model_name)
        if not model:
            return ["Model not found"]
        errors = []
        for field, config in model["fields"].items():
            if config.get("required") and field not in data:
                errors.append(f"Required field missing: {field}")
        return errors
