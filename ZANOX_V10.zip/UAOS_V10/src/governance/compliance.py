"""UAOS Compliance Manager"""
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
import uuid
logger = logging.getLogger(__name__)

class ComplianceManager:
    def __init__(self):
        self._frameworks: Dict[str, Dict[str, Any]] = {}
        self._checks: List[Dict[str, Any]] = []

    async def initialize(self):
        logger.info("Compliance manager initialized")

    async def register_framework(self, code: str, name: str, description: str) -> str:
        self._frameworks[code] = dict(code=code, name=name, description=description, controls=[], registered_at=datetime.utcnow().isoformat())
        return code

    async def add_control(self, framework: str, control_id: str, name: str, requirement: str) -> bool:
        if framework not in self._frameworks:
            return False
        self._frameworks[framework]["controls"].append(dict(id=control_id, name=name, requirement=requirement, status="active"))
        return True

    async def run_check(self, framework: str, resource: Dict[str, Any]) -> Dict[str, Any]:
        if framework not in self._frameworks:
            return dict(error="Framework not found")
        results = dict(framework=framework, checked_at=datetime.utcnow().isoformat(), passed=0, failed=0, violations=[])
        for control in self._frameworks[framework]["controls"]:
            passed = self._evaluate_control(control, resource)
            if passed:
                results["passed"] += 1
            else:
                results["failed"] += 1
                results["violations"].append(dict(control=control["id"], name=control["name"]))
        return results

    def _evaluate_control(self, control: Dict[str, Any], resource: Dict[str, Any]) -> bool:
        control_id = control["id"]
        if control_id == "data_encryption":
            return resource.get("encrypted", False)
        elif control_id == "access_logging":
            return resource.get("logging_enabled", False)
        return True

    async def get_frameworks(self) -> List[Dict[str, Any]]:
        return list(self._frameworks.values())
