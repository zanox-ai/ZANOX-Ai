"""UAOS Policy Manager"""
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
import uuid
logger = logging.getLogger(__name__)

class PolicyManager:
    def __init__(self):
        self._policies: Dict[str, Dict[str, Any]] = {}

    async def initialize(self):
        logger.info("Policy manager initialized")

    async def create_policy(self, name: str, rules: List[Dict[str, Any]], scope: str = "global") -> str:
        policy_id = str(uuid.uuid4())
        self._policies[name] = dict(id=policy_id, name=name, rules=rules, scope=scope, status="active", created_at=datetime.utcnow().isoformat())
        return policy_id

    async def evaluate_policy(self, name: str, context: Dict[str, Any]) -> Dict[str, Any]:
        policy = self._policies.get(name)
        if not policy:
            return dict(allowed=False, error="Policy not found")
        violations = []
        for rule in policy["rules"]:
            if not self._evaluate_rule(rule, context):
                violations.append(rule["name"])
        return dict(allowed=len(violations) == 0, violations=violations, policy=name)

    def _evaluate_rule(self, rule: Dict[str, Any], context: Dict[str, Any]) -> bool:
        condition = rule.get("condition", {})
        for key, expected in condition.items():
            if context.get(key) != expected:
                return False
        return True

    async def get_policy(self, name: str) -> Optional[Dict[str, Any]]:
        return self._policies.get(name)

    async def list_policies(self) -> List[Dict[str, Any]]:
        return list(self._policies.values())

    async def deactivate_policy(self, name: str) -> bool:
        if name in self._policies:
            self._policies[name]["status"] = "inactive"
            return True
        return False
