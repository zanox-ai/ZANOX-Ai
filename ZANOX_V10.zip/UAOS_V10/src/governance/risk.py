"""UAOS Risk Manager"""
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
import uuid
logger = logging.getLogger(__name__)

class RiskManager:
    def __init__(self):
        self._risks: Dict[str, Dict[str, Any]] = {}
        self._assessments: List[Dict[str, Any]] = []

    async def initialize(self):
        logger.info("Risk manager initialized")

    async def register_risk(self, name: str, category: str, probability: float, impact: float, mitigation: str) -> str:
        risk_id = str(uuid.uuid4())
        score = probability * impact
        self._risks[name] = dict(id=risk_id, name=name, category=category, probability=probability, impact=impact, score=score, mitigation=mitigation, status="active", created_at=datetime.utcnow().isoformat())
        return risk_id

    async def assess_risk(self, name: str) -> Dict[str, Any]:
        risk = self._risks.get(name)
        if not risk:
            return dict(error="Risk not found")
        assessment = dict(risk_id=risk["id"], score=risk["score"], level="high" if risk["score"] > 15 else "medium" if risk["score"] > 7 else "low", assessed_at=datetime.utcnow().isoformat())
        self._assessments.append(assessment)
        return assessment

    async def get_risk(self, name: str) -> Optional[Dict[str, Any]]:
        return self._risks.get(name)

    async def list_risks(self, category: Optional[str] = None) -> List[Dict[str, Any]]:
        risks = list(self._risks.values())
        if category:
            risks = [r for r in risks if r["category"] == category]
        return risks

    async def get_assessments(self) -> List[Dict[str, Any]]:
        return self._assessments
