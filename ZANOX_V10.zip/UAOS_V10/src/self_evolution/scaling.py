"""UAOS Auto Scaling"""
import logging
from typing import Dict, Any
from datetime import datetime
logger = logging.getLogger(__name__)

class AutoScaling:
    def __init__(self):
        self._scaling_events: list = []

    async def initialize(self):
        logger.info("Auto scaling initialized")

    async def evaluate_scaling(self, current_load: float, current_instances: int, min_instances: int = 1, max_instances: int = 100) -> Dict[str, Any]:
        target = current_instances
        if current_load > 80: target = min(current_instances + 2, max_instances)
        elif current_load < 20: target = max(current_instances - 1, min_instances)
        event = {"timestamp": datetime.utcnow().isoformat(), "from": current_instances, "to": target, "load": current_load}
        self._scaling_events.append(event)
        return {"current": current_instances, "target": target, "action": "scale_up" if target > current_instances else "scale_down" if target < current_instances else "no_change"}

    async def get_scaling_history(self) -> list:
        return self._scaling_events
