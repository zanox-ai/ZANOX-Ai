"""UAOS Self-Evolution System"""
from .optimization import AutoOptimization
from .scaling import AutoScaling
from .tool_discovery import AutoToolDiscovery
from .connector_discovery import AutoConnectorDiscovery
from .workflow_improvement import AutoWorkflowImprovement
from .agent_improvement import AutoAgentImprovement
from .memory_improvement import AutoMemoryImprovement
from .cost_optimization import AutoCostOptimization
from .architecture_optimization import AutoArchitectureOptimization
__all__ = ["AutoOptimization", "AutoScaling", "AutoToolDiscovery", "AutoConnectorDiscovery", "AutoWorkflowImprovement", "AutoAgentImprovement", "AutoMemoryImprovement", "AutoCostOptimization", "AutoArchitectureOptimization"]
