"""
UAOS Long-Term Memory
Production-Ready Implementation
"""
import asyncio
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
import uuid
import sqlite3
import json

logger = logging.getLogger(__name__)

class LongTermMemory:
    """
    Persistent long-term memory with structured storage.
    Supports categorization, tagging, and retrieval.
    """

    def __init__(self, db_path: str = "uaos_ltm.db"):
        self._db_path = db_path
        self._conn = None

    async def initialize(self):
        """Initialize long-term memory database"""
        self._conn = sqlite3.connect(self._db_path)
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS memories (
                id TEXT PRIMARY KEY,
                key TEXT UNIQUE,
                value TEXT,
                category TEXT,
                tags TEXT,
                importance REAL,
                created_at TEXT,
                updated_at TEXT
            )
        """)
        self._conn.commit()
        logger.info("Long-term memory initialized")

    async def store(
        self,
        key: str,
        value: Any,
        category: str = "general",
        tags: List[str] = None,
        importance: float = 0.5
    ) -> bool:
        """Store value in long-term memory"""
        memory_id = str(uuid.uuid4())
        now = datetime.utcnow().isoformat()

        self._conn.execute(
            """INSERT OR REPLACE INTO memories 
               (id, key, value, category, tags, importance, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (memory_id, key, json.dumps(value), category, 
             json.dumps(tags or []), importance, now, now)
        )
        self._conn.commit()
        return True

    async def retrieve(self, key: str) -> Optional[Any]:
        """Retrieve value from long-term memory"""
        cursor = self._conn.execute(
            "SELECT value FROM memories WHERE key = ?", (key,)
        )
        row = cursor.fetchone()
        if row:
            return json.loads(row[0])
        return None

    async def search_by_category(self, category: str) -> List[Dict[str, Any]]:
        """Search memories by category"""
        cursor = self._conn.execute(
            "SELECT key, value, category, tags, importance FROM memories WHERE category = ?",
            (category,)
        )
        return [
            {
                "key": row[0],
                "value": json.loads(row[1]),
                "category": row[2],
                "tags": json.loads(row[3]),
                "importance": row[4]
            }
            for row in cursor.fetchall()
        ]

    async def search_by_tags(self, tags: List[str]) -> List[Dict[str, Any]]:
        """Search memories by tags"""
        results = []
        cursor = self._conn.execute("SELECT key, value, tags FROM memories")
        for row in cursor.fetchall():
            memory_tags = json.loads(row[2])
            if any(tag in memory_tags for tag in tags):
                results.append({"key": row[0], "value": json.loads(row[1])})
        return results

    async def delete(self, key: str) -> bool:
        """Delete memory"""
        cursor = self._conn.execute("DELETE FROM memories WHERE key = ?", (key,))
        self._conn.commit()
        return cursor.rowcount > 0
