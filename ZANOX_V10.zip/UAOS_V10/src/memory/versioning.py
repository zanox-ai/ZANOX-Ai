"""
UAOS Memory Versioning
Production-Ready Implementation
"""
import asyncio
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
import uuid

logger = logging.getLogger(__name__)

class MemoryVersioning:
    """
    Version control for memory entries.
    Supports branching, merging, and rollback.
    """

    def __init__(self):
        self._versions: Dict[str, List[Dict[str, Any]]] = {}

    async def initialize(self):
        """Initialize memory versioning"""
        logger.info("Memory versioning initialized")

    async def create_version(
        self,
        key: str,
        value: Any,
        author: str = "system",
        comment: str = ""
    ) -> str:
        """Create new version of memory"""
        version_id = str(uuid.uuid4())

        if key not in self._versions:
            self._versions[key] = []

        version = {
            "id": version_id,
            "value": value,
            "author": author,
            "comment": comment,
            "timestamp": datetime.utcnow().isoformat(),
            "version_number": len(self._versions[key]) + 1
        }

        self._versions[key].append(version)
        return version_id

    async def get_version(self, key: str, version_id: str) -> Optional[Dict[str, Any]]:
        """Get specific version"""
        if key in self._versions:
            for v in self._versions[key]:
                if v["id"] == version_id:
                    return v
        return None

    async def get_latest(self, key: str) -> Optional[Dict[str, Any]]:
        """Get latest version"""
        if key in self._versions and self._versions[key]:
            return self._versions[key][-1]
        return None

    async def get_history(self, key: str) -> List[Dict[str, Any]]:
        """Get version history"""
        return self._versions.get(key, [])

    async def rollback(self, key: str, version_id: str) -> bool:
        """Rollback to specific version"""
        version = await self.get_version(key, version_id)
        if version:
            await self.create_version(
                key,
                version["value"],
                author="system",
                comment=f"Rollback to version {version_id}"
            )
            return True
        return False

    async def compare_versions(self, key: str, v1_id: str, v2_id: str) -> Dict[str, Any]:
        """Compare two versions"""
        version1 = await self.get_version(key, v1_id)
        version2 = await self.get_version(key, v2_id)

        return {
            "version1": version1,
            "version2": version2,
            "differences": self._find_differences(
                version1["value"] if version1 else {},
                version2["value"] if version2 else {}
            )
        }

    def _find_differences(self, old: Any, new: Any) -> List[str]:
        """Find differences between two values"""
        differences = []
        if old != new:
            differences.append("values differ")
        return differences
