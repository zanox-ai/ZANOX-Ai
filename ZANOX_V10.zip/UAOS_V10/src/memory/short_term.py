"""
UAOS Short-Term Memory
Production-Ready Implementation
"""
import asyncio
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
import uuid
from collections import OrderedDict

logger = logging.getLogger(__name__)

class ShortTermMemory:
    """
    High-speed short-term memory with TTL-based expiration.
    Optimized for recent context and working memory.
    """

    def __init__(self, max_size: int = 10000, default_ttl: int = 3600):
        self._memory = OrderedDict()
        self._max_size = max_size
        self._default_ttl = default_ttl
        self._running = False

    async def initialize(self):
        """Initialize short-term memory"""
        self._running = True
        asyncio.create_task(self._cleanup_loop())
        logger.info("Short-term memory initialized")

    async def store(self, key: str, value: Any, ttl: Optional[int] = None) -> bool:
        """Store value in short-term memory"""
        ttl = ttl or self._default_ttl
        expires_at = datetime.utcnow() + timedelta(seconds=ttl)

        self._memory[key] = {
            "value": value,
            "expires_at": expires_at,
            "created_at": datetime.utcnow().isoformat(),
            "access_count": 0
        }

        if len(self._memory) > self._max_size:
            self._evict_oldest()

        return True

    async def retrieve(self, key: str) -> Optional[Any]:
        """Retrieve value from short-term memory"""
        if key in self._memory:
            item = self._memory[key]
            if datetime.utcnow() < item["expires_at"]:
                item["access_count"] += 1
                self._memory.move_to_end(key)
                return item["value"]
            else:
                del self._memory[key]
        return None

    async def delete(self, key: str) -> bool:
        """Delete value from short-term memory"""
        if key in self._memory:
            del self._memory[key]
            return True
        return False

    async def clear(self):
        """Clear all short-term memory"""
        self._memory.clear()

    async def get_stats(self) -> Dict[str, Any]:
        """Get memory statistics"""
        return {
            "total_items": len(self._memory),
            "max_size": self._max_size,
            "default_ttl": self._default_ttl
        }

    def _evict_oldest(self):
        """Evict oldest item"""
        if self._memory:
            self._memory.popitem(last=False)

    async def _cleanup_loop(self):
        """Periodic cleanup of expired items"""
        while self._running:
            now = datetime.utcnow()
            expired = [k for k, v in self._memory.items() if now >= v["expires_at"]]
            for k in expired:
                del self._memory[k]
            await asyncio.sleep(60)
