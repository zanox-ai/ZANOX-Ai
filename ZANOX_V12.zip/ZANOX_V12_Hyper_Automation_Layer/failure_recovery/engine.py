"""ZANOX V12 Failure Recovery Engine - Self-Healing Automation"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, and_, or_
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime, timedelta
import uuid
import logging
import asyncio

from shared.database import get_db
from shared.models import WorkflowExecution, WorkflowStatus, TaskRecord, TaskStatus, ConnectorRegistry
from shared.redis_client import redis_client
from shared.config import config
from automation_engine.engine import automation_engine

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v12/failure-recovery", tags=["Failure Recovery"])

class RecoveryAction(BaseModel):
    """Recovery action configuration"""
    action_type: str
    max_attempts: int = 3
    backoff_strategy: str = "exponential"
    fallback_platform: Optional[str] = None
    notify_on_failure: bool = True

class RecoveryResult(BaseModel):
    """Result of recovery attempt"""
    execution_id: str
    task_id: str
    action_taken: str
    success: bool
    attempts: int
    duration_ms: float
    error: Optional[str]

class FailureRecoveryEngine:
    """Self-healing automation with intelligent failure recovery"""

    RECOVERY_STRATEGIES = {
        "retry": "Retry same task with exponential backoff",
        "alternate_platform": "Switch to alternative platform",
        "skip": "Skip task and continue workflow",
        "escalate": "Escalate to human approval",
        "rollback": "Rollback to previous state"
    }

    async def recover_task(self, db: AsyncSession, task_id: str, 
                          action: RecoveryAction) -> RecoveryResult:
        """Attempt to recover failed task"""
        task = await db.get(TaskRecord, task_id)
        if not task:
            raise HTTPException(status_code=404, detail="Task not found")

        if task.status != TaskStatus.FAILED:
            return RecoveryResult(
                execution_id=task.execution_id,
                task_id=task_id,
                action_taken="none",
                success=True,
                attempts=0,
                duration_ms=0,
                error="Task is not in failed state"
            )

        start_time = datetime.utcnow()
        attempts = 0
        success = False

        for attempt in range(action.max_attempts):
            attempts = attempt + 1

            try:
                if action.action_type == "retry":
                    success = await self._retry_task(db, task, action)
                elif action.action_type == "alternate_platform":
                    success = await self._alternate_platform(db, task, action)
                elif action.action_type == "skip":
                    success = await self._skip_task(db, task)
                elif action.action_type == "escalate":
                    success = await self._escalate_task(db, task)
                elif action.action_type == "rollback":
                    success = await self._rollback_task(db, task)

                if success:
                    break

                if action.backoff_strategy == "exponential":
                    wait = 2 ** attempt
                elif action.backoff_strategy == "linear":
                    wait = attempt + 1
                else:
                    wait = 2

                await asyncio.sleep(wait)

            except Exception as e:
                logger.error(f"Recovery attempt {attempts} failed: {e}")
                continue

        duration_ms = (datetime.utcnow() - start_time).total_seconds() * 1000

        if not success and action.notify_on_failure:
            await self._notify_failure(db, task, action)

        return RecoveryResult(
            execution_id=task.execution_id,
            task_id=task_id,
            action_taken=action.action_type,
            success=success,
            attempts=attempts,
            duration_ms=duration_ms,
            error=None if success else "Recovery failed after all attempts"
        )

    async def _retry_task(self, db: AsyncSession, task: TaskRecord, 
                          action: RecoveryAction) -> bool:
        from connector_registry.registry import connector_manager

        if not task.connector_id:
            return False

        try:
            result = await connector_manager.execute_connector(
                db, task.connector_id, "POST", "", task.input_data
            )

            if result.get("success"):
                task.status = TaskStatus.COMPLETED
                task.output_data = result
                task.completed_at = datetime.utcnow()
                task.retry_count += 1
                await db.commit()
                return True
            else:
                task.retry_count += 1
                await db.commit()
                return False
        except Exception as e:
            task.retry_count += 1
            await db.commit()
            return False

    async def _alternate_platform(self, db: AsyncSession, task: TaskRecord,
                                   action: RecoveryAction) -> bool:
        from task_distribution.engine import task_distribution_engine, DistributionTask

        if not action.fallback_platform:
            dist_task = DistributionTask(
                task_id=task.id,
                task_type=task.task_type,
                platform_type=task.platform or "ai"
            )

            try:
                result = await task_distribution_engine.distribute(db, dist_task)
                task.platform = result.assigned_platform
                task.connector_id = result.assigned_connector
                task.status = TaskStatus.PENDING
                await db.commit()
                return await self._retry_task(db, task, RecoveryAction(action_type="retry"))
            except Exception:
                return False
        else:
            task.platform = action.fallback_platform
            task.status = TaskStatus.PENDING
            await db.commit()
            return await self._retry_task(db, task, RecoveryAction(action_type="retry"))

    async def _skip_task(self, db: AsyncSession, task: TaskRecord) -> bool:
        task.status = TaskStatus.COMPLETED
        task.output_data = {"skipped": True, "reason": "Recovery skip"}
        task.completed_at = datetime.utcnow()
        await db.commit()
        return True

    async def _escalate_task(self, db: AsyncSession, task: TaskRecord) -> bool:
        from shared.models import EventRecord

        event = EventRecord(
            id=str(uuid.uuid4()),
            event_type="human_approval_required",
            source="failure_recovery",
            target="human_approval",
            payload={
                "task_id": task.id,
                "execution_id": task.execution_id,
                "error": task.error_data,
                "action_required": "approve_or_retry"
            },
            priority=1
        )
        db.add(event)
        await db.commit()
        task.status = TaskStatus.PENDING
        await db.commit()
        return True

    async def _rollback_task(self, db: AsyncSession, task: TaskRecord) -> bool:
        result = await db.execute(
            select(TaskRecord)
            .where(TaskRecord.execution_id == task.execution_id)
            .where(TaskRecord.status == TaskStatus.COMPLETED)
            .order_by(TaskRecord.completed_at.desc())
        )
        previous = result.scalar_one_or_none()

        if previous:
            task.output_data = previous.output_data
            task.status = TaskStatus.COMPLETED
            task.completed_at = datetime.utcnow()
            await db.commit()
            return True
        return False

    async def _notify_failure(self, db: AsyncSession, task: TaskRecord, 
                               action: RecoveryAction):
        from shared.models import EventRecord

        event = EventRecord(
            id=str(uuid.uuid4()),
            event_type="recovery_failed",
            source="failure_recovery",
            target="notification",
            payload={
                "task_id": task.id,
                "execution_id": task.execution_id,
                "action": action.action_type,
                "attempts": task.retry_count,
                "error": task.error_data
            },
            priority=1
        )
        db.add(event)
        await db.commit()

    async def auto_recover_execution(self, db: AsyncSession, 
                                      execution_id: str) -> Dict[str, Any]:
        result = await db.execute(
            select(TaskRecord)
            .where(TaskRecord.execution_id == execution_id)
            .where(TaskRecord.status == TaskStatus.FAILED)
        )
        failed_tasks = result.scalars().all()

        if not failed_tasks:
            return {"message": "No failed tasks to recover", "execution_id": execution_id}

        recovered = []
        for task in failed_tasks:
            action = RecoveryAction(action_type="retry", max_attempts=3)
            result = await self.recover_task(db, task.id, action)
            recovered.append(result.dict())

        return {
            "execution_id": execution_id,
            "failed_count": len(failed_tasks),
            "recovered": recovered
        }

failure_recovery_engine = FailureRecoveryEngine()

@router.post("/recover/{task_id}")
async def recover_task(task_id: str, action: RecoveryAction, db: AsyncSession = Depends(get_db)):
    result = await failure_recovery_engine.recover_task(db, task_id, action)
    return result.dict()

@router.post("/auto-recover/{execution_id}")
async def auto_recover(execution_id: str, db: AsyncSession = Depends(get_db)):
    return await failure_recovery_engine.auto_recover_execution(db, execution_id)

@router.get("/strategies")
async def get_recovery_strategies():
    return failure_recovery_engine.RECOVERY_STRATEGIES
