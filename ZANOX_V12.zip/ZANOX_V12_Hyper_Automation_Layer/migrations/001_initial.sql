-- ZANOX V12 Database Schema
-- Run this to initialize the database

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Tables are created automatically by SQLAlchemy
-- Run: alembic upgrade head
