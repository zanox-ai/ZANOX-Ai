"""ZANOX V12 Webhook Gateway - Webhook Management"""
from fastapi import APIRouter, Depends, HTTPException, Request, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime
import uuid
import logging
import hashlib
import hmac

from shared.database import get_db
from shared.models import EventRecord
from shared.security import security_manager
from shared.redis_client import redis_client

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v12/webhooks", tags=["Webhook Gateway"])

class WebhookConfig(BaseModel):
    """Webhook configuration"""
    webhook_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    url: str
    events: List[str]
    secret: Optional[str] = None
    headers: Optional[Dict[str, str]] = {}
    active: bool = True
    retry_count: int = 3
    timeout_seconds: int = 30

class WebhookDelivery(BaseModel):
    """Webhook delivery record"""
    delivery_id: str
    webhook_id: str
    event_id: str
    status: str
    http_status: Optional[int]
    response_body: Optional[str]
    delivered_at: Optional[datetime]
    error: Optional[str]

class WebhookGateway:
    """Manages webhook subscriptions and deliveries"""

    def __init__(self):
        self._webhooks: Dict[str, WebhookConfig] = {}

    async def register_webhook(self, db: AsyncSession, config: WebhookConfig) -> str:
        """Register new webhook"""
        # Store in Redis
        await redis_client.hset(
            f"webhook:{config.webhook_id}",
            "config",
            json.dumps(config.dict())
        )

        logger.info(f"Webhook registered: {config.webhook_id}")
        return config.webhook_id

    async def deliver_webhook(self, db: AsyncSession, webhook_id: str,
                             event: EventRecord) -> WebhookDelivery:
        """Deliver event to webhook"""
        delivery_id = str(uuid.uuid4())

        # Get webhook config
        config_data = await redis_client.hget(f"webhook:{webhook_id}", "config")
        if not config_data:
            return WebhookDelivery(
                delivery_id=delivery_id,
                webhook_id=webhook_id,
                event_id=event.id,
                status="failed",
                error="Webhook not found"
            )

        webhook = WebhookConfig(**json.loads(config_data))

        if not webhook.active:
            return WebhookDelivery(
                delivery_id=delivery_id,
                webhook_id=webhook_id,
                event_id=event.id,
                status="skipped",
                error="Webhook inactive"
            )

        # Build payload
        payload = {
            "event_id": event.id,
            "event_type": event.event_type,
            "source": event.source,
            "payload": event.payload,
            "timestamp": datetime.utcnow().isoformat()
        }

        # Sign payload if secret exists
        headers = {**webhook.headers, "Content-Type": "application/json"}
        if webhook.secret:
            signature = hmac.new(
                webhook.secret.encode(),
                json.dumps(payload).encode(),
                hashlib.sha256
            ).hexdigest()
            headers["X-Webhook-Signature"] = f"sha256={signature}"

        # Deliver
        import httpx
        start_time = datetime.utcnow()

        for attempt in range(webhook.retry_count):
            try:
                async with httpx.AsyncClient() as client:
                    response = await client.post(
                        webhook.url,
                        json=payload,
                        headers=headers,
                        timeout=webhook.timeout_seconds
                    )

                return WebhookDelivery(
                    delivery_id=delivery_id,
                    webhook_id=webhook_id,
                    event_id=event.id,
                    status="delivered" if response.status_code < 400 else "failed",
                    http_status=response.status_code,
                    response_body=response.text[:1000],
                    delivered_at=datetime.utcnow(),
                    error=None if response.status_code < 400 else f"HTTP {response.status_code}"
                )
            except Exception as e:
                if attempt == webhook.retry_count - 1:
                    return WebhookDelivery(
                        delivery_id=delivery_id,
                        webhook_id=webhook_id,
                        event_id=event.id,
                        status="failed",
                        error=str(e)
                    )
                await asyncio.sleep(2 ** attempt)

        return WebhookDelivery(
            delivery_id=delivery_id,
            webhook_id=webhook_id,
            event_id=event.id,
            status="failed",
            error="Max retries exceeded"
        )

    async def verify_signature(self, payload: bytes, signature: str,
                               secret: str) -> bool:
        """Verify webhook signature"""
        expected = hmac.new(secret.encode(), payload, hashlib.sha256).hexdigest()
        return hmac.compare_digest(f"sha256={expected}", signature)

    async def get_webhooks(self, db: AsyncSession, 
                          event_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get registered webhooks"""
        # This would query from database in production
        return []

webhook_gateway = WebhookGateway()

@router.post("/register")
async def register_webhook(config: WebhookConfig, db: AsyncSession = Depends(get_db)):
    """Register webhook"""
    webhook_id = await webhook_gateway.register_webhook(db, config)
    return {"webhook_id": webhook_id, "status": "registered"}

@router.post("/deliver/{webhook_id}")
async def deliver_webhook(
    webhook_id: str,
    event: EventRecord,
    db: AsyncSession = Depends(get_db)
):
    """Deliver event to webhook"""
    result = await webhook_gateway.deliver_webhook(db, webhook_id, event)
    return result.dict()

@router.post("/verify")
async def verify_signature(
    payload: bytes,
    signature: str,
    secret: str
):
    """Verify webhook signature"""
    valid = await webhook_gateway.verify_signature(payload, signature, secret)
    return {"valid": valid}
