"""ZANOX V12 Context Sync - Cross-Platform Context Synchronization"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, or_
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime, timedelta
import uuid
import logging
import json

from shared.database import get_db
from shared.models import ContextSync
from shared.redis_client import redis_client
from shared.config import config

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v12/context-sync", tags=["Context Sync"])

class ContextEntry(BaseModel):
    """Context entry for sync"""
    session_id: str
    platform: str
    context_data: Dict[str, Any]
    priority: int = 5
    ttl_seconds: int = 3600

class ContextSyncResult(BaseModel):
    """Result of context sync"""
    sync_id: str
    session_id: str
    platform: str
    status: str
    synced_at: datetime

class ContextSyncManager:
    """Manages cross-platform context synchronization"""

    async def sync_context(self, db: AsyncSession, entry: ContextEntry) -> ContextSyncResult:
        """Sync context entry"""
        sync_id = str(uuid.uuid4())
        expires_at = datetime.utcnow() + timedelta(seconds=entry.ttl_seconds)

        context = ContextSync(
            id=sync_id,
            session_id=entry.session_id,
            platform=entry.platform,
            context_data=entry.context_data,
            priority=entry.priority,
            expires_at=expires_at
        )
        db.add(context)
        await db.commit()

        # Sync to Redis
        redis_key = f"context:{entry.session_id}:{entry.platform}"
        await redis_client.set(redis_key, json.dumps(entry.context_data), expire=entry.ttl_seconds)

        logger.info(f"Context synced: {entry.session_id}/{entry.platform}")

        return ContextSyncResult(
            sync_id=sync_id,
            session_id=entry.session_id,
            platform=entry.platform,
            status="synced",
            synced_at=datetime.utcnow()
        )

    async def get_context(self, db: AsyncSession, session_id: str,
                         platform: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get context for session"""
        # Try Redis first
        if platform:
            redis_key = f"context:{session_id}:{platform}"
            cached = await redis_client.get(redis_key)
            if cached:
                return [json.loads(cached)]

        # Database fallback
        query = select(ContextSync).where(ContextSync.session_id == session_id)
        if platform:
            query = query.where(ContextSync.platform == platform)

        result = await db.execute(query)
        contexts = result.scalars().all()

        return [
            {
                "platform": c.platform,
                "context_data": c.context_data,
                "priority": c.priority,
                "expires_at": c.expires_at.isoformat() if c.expires_at else None,
                "created_at": c.created_at.isoformat() if c.created_at else None
            }
            for c in contexts
        ]

    async def propagate_context(self, db: AsyncSession, session_id: str,
                               source_platform: str, target_platforms: List[str]) -> List[ContextSyncResult]:
        """Propagate context from one platform to others"""
        # Get source context
        contexts = await self.get_context(db, session_id, source_platform)
        if not contexts:
            raise HTTPException(status_code=404, detail="Source context not found")

        source_context = contexts[0]

        results = []
        for target in target_platforms:
            entry = ContextEntry(
                session_id=session_id,
                platform=target,
                context_data=source_context["context_data"],
                priority=source_context.get("priority", 5)
            )
            result = await self.sync_context(db, entry)
            results.append(result)

        return results

    async def clear_context(self, db: AsyncSession, session_id: str,
                           platform: Optional[str] = None) -> bool:
        """Clear context entries"""
        query = select(ContextSync).where(ContextSync.session_id == session_id)
        if platform:
            query = query.where(ContextSync.platform == platform)

        result = await db.execute(query)
        contexts = result.scalars().all()

        for context in contexts:
            await db.delete(context)
            redis_key = f"context:{session_id}:{context.platform}"
            await redis_client.delete(redis_key)

        await db.commit()
        return len(contexts) > 0

context_sync_manager = ContextSyncManager()

@router.post("/sync")
async def sync_context(entry: ContextEntry, db: AsyncSession = Depends(get_db)):
    """Sync context entry"""
    result = await context_sync_manager.sync_context(db, entry)
    return result.dict()

@router.get("/{session_id}")
async def get_context(
    session_id: str,
    platform: Optional[str] = None,
    db: AsyncSession = Depends(get_db)
):
    """Get context for session"""
    return await context_sync_manager.get_context(db, session_id, platform)

@router.post("/propagate/{session_id}")
async def propagate_context(
    session_id: str,
    source_platform: str,
    target_platforms: List[str],
    db: AsyncSession = Depends(get_db)
):
    """Propagate context across platforms"""
    results = await context_sync_manager.propagate_context(db, session_id, source_platform, target_platforms)
    return {"results": [r.dict() for r in results]}

@router.delete("/{session_id}")
async def clear_context(
    session_id: str,
    platform: Optional[str] = None,
    db: AsyncSession = Depends(get_db)
):
    """Clear context"""
    success = await context_sync_manager.clear_context(db, session_id, platform)
    return {"cleared": success}
