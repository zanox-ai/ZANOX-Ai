"""ZANOX V12 Workflow Composer - Visual Workflow Builder"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, or_
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime
import uuid
import logging

from shared.database import get_db
from shared.models import WorkflowDefinition
from workflow_orchestrator.orchestrator import orchestrator

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v12/workflow-composer", tags=["Workflow Composer"])

class NodeTemplate(BaseModel):
    """Node template for visual builder"""
    node_type: str
    label: str
    icon: str
    color: str
    default_config: Dict[str, Any]
    inputs: List[str] = []
    outputs: List[str] = []

class WorkflowComposer:
    """Visual workflow composition engine"""

    NODE_TEMPLATES = [
        NodeTemplate(
            node_type="ai_call",
            label="AI Call",
            icon="brain",
            color="#6366f1",
            default_config={"platform": "openrouter", "model": "default", "temperature": 0.7},
            inputs=["prompt"],
            outputs=["response"]
        ),
        NodeTemplate(
            node_type="api_call",
            label="API Call",
            icon="globe",
            color="#3b82f6",
            default_config={"method": "GET", "path": ""},
            inputs=["payload"],
            outputs=["response"]
        ),
        NodeTemplate(
            node_type="automation_trigger",
            label="Automation",
            icon="zap",
            color="#f59e0b",
            default_config={"platform": "n8n", "workflow_id": ""},
            inputs=["trigger_data"],
            outputs=["result"]
        ),
        NodeTemplate(
            node_type="agent_task",
            label="Agent Task",
            icon="bot",
            color="#10b981",
            default_config={"platform": "crewai", "task_description": ""},
            inputs=["context"],
            outputs=["result"]
        ),
        NodeTemplate(
            node_type="builder_deploy",
            label="Builder Deploy",
            icon="hammer",
            color="#ec4899",
            default_config={"platform": "bolt", "project_name": ""},
            inputs=["code"],
            outputs=["deploy_url"]
        ),
        NodeTemplate(
            node_type="condition",
            label="Condition",
            icon="git-branch",
            color="#8b5cf6",
            default_config={"condition": "True"},
            inputs=["input"],
            outputs=["true", "false"]
        ),
        NodeTemplate(
            node_type="loop",
            label="Loop",
            icon="repeat",
            color="#06b6d4",
            default_config={"items": [], "tasks": []},
            inputs=["items"],
            outputs=["results"]
        ),
        NodeTemplate(
            node_type="wait",
            label="Wait",
            icon="clock",
            color="#64748b",
            default_config={"duration_seconds": 1},
            inputs=["trigger"],
            outputs=["done"]
        ),
        NodeTemplate(
            node_type="transform",
            label="Transform",
            icon="shuffle",
            color="#14b8a6",
            default_config={"mapping": {}},
            inputs=["data"],
            outputs=["transformed"]
        ),
        NodeTemplate(
            node_type="notify",
            label="Notify",
            icon="bell",
            color="#f97316",
            default_config={"channel": "webhook", "message": ""},
            inputs=["trigger"],
            outputs=["sent"]
        ),
        NodeTemplate(
            node_type="memory_sync",
            label="Memory Sync",
            icon="database",
            color="#84cc16",
            default_config={"platform": "", "key": ""},
            inputs=["value"],
            outputs=["synced"]
        ),
        NodeTemplate(
            node_type="context_sync",
            label="Context Sync",
            icon="layers",
            color="#a855f7",
            default_config={"platform": "", "context": {}},
            inputs=["context"],
            outputs=["synced"]
        )
    ]

    async def get_templates(self) -> List[Dict[str, Any]]:
        """Get all node templates"""
        return [t.dict() for t in self.NODE_TEMPLATES]

    async def compose_workflow(self, db: AsyncSession, 
                              name: str,
                              nodes: List[Dict[str, Any]],
                              edges: List[Dict[str, Any]],
                              owner_id: str = "system") -> Dict[str, Any]:
        """Compose workflow from visual nodes and edges"""
        # Convert visual nodes to workflow definition
        workflow_nodes = []
        for node in nodes:
            template = next((t for t in self.NODE_TEMPLATES if t.node_type == node.get("type")), None)
            if template:
                workflow_nodes.append({
                    "id": node.get("id", str(uuid.uuid4())),
                    "name": node.get("label", template.label),
                    "task_type": template.node_type,
                    "platform": node.get("config", {}).get("platform", template.default_config.get("platform")),
                    "config": {**template.default_config, **node.get("config", {})},
                    "inputs": {},
                    "outputs": {},
                    "dependencies": [],
                    "retry_count": 0,
                    "max_retries": 3,
                    "timeout_seconds": 300,
                    "on_failure": "fail"
                })

        # Build edges/dependencies
        for edge in edges:
            source_id = edge.get("from")
            target_id = edge.get("to")

            for node in workflow_nodes:
                if node["id"] == target_id:
                    if source_id not in node["dependencies"]:
                        node["dependencies"].append(source_id)

        # Create workflow
        definition = {
            "nodes": workflow_nodes,
            "edges": edges
        }

        from workflow_orchestrator.orchestrator import WorkflowCreate
        workflow_data = WorkflowCreate(
            name=name,
            definition=definition,
            category="composed"
        )

        workflow = await orchestrator.create_workflow(db, owner_id, workflow_data)

        return {
            "workflow_id": workflow.id,
            "name": workflow.name,
            "node_count": len(workflow_nodes),
            "edge_count": len(edges),
            "status": "composed"
        }

workflow_composer = WorkflowComposer()

@router.get("/templates")
async def get_templates():
    """Get node templates"""
    return await workflow_composer.get_templates()

@router.post("/compose")
async def compose_workflow(
    name: str,
    nodes: List[Dict[str, Any]],
    edges: List[Dict[str, Any]],
    db: AsyncSession = Depends(get_db)
):
    """Compose workflow from visual builder"""
    return await workflow_composer.compose_workflow(db, name, nodes, edges)
