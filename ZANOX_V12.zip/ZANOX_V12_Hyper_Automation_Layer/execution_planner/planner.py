"""ZANOX V12 Execution Planner - Intelligent Workflow Planning"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime, timedelta
import uuid
import logging
import json

from shared.database import get_db
from shared.models import WorkflowDefinition, WorkflowExecution
from automation_engine.engine import TaskNode, WorkflowGraph

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v12/execution-planner", tags=["Execution Planner"])

class PlanRequest(BaseModel):
    """Request for execution planning"""
    workflow_id: str
    variables: Optional[Dict[str, Any]] = {}
    optimization_goal: str = "balanced"  # speed, cost, reliability, balanced
    constraints: Optional[Dict[str, Any]] = {}

class ExecutionPlan(BaseModel):
    """Generated execution plan"""
    plan_id: str
    workflow_id: str
    execution_order: List[str]
    parallel_groups: List[List[str]]
    estimated_duration_ms: int
    estimated_cost_usd: float
    risk_score: float
    fallback_plan: Optional[Dict[str, Any]]

class ExecutionPlanner:
    """Intelligent execution planning with optimization"""

    def __init__(self):
        self._plan_cache: Dict[str, ExecutionPlan] = {}

    async def generate_plan(self, db: AsyncSession, request: PlanRequest) -> ExecutionPlan:
        """Generate optimized execution plan for workflow"""
        workflow = await db.get(WorkflowDefinition, request.workflow_id)
        if not workflow:
            raise HTTPException(status_code=404, detail="Workflow not found")

        graph = WorkflowGraph(**workflow.definition)

        # Build dependency graph
        dependencies = {node.id: set(node.dependencies) for node in graph.nodes}

        # Topological sort for execution order
        execution_order = self._topological_sort(dependencies)

        # Identify parallel groups
        parallel_groups = self._find_parallel_groups(graph, dependencies)

        # Estimate duration and cost
        estimated_duration = self._estimate_duration(graph, request.optimization_goal)
        estimated_cost = self._estimate_cost(graph, request.optimization_goal)

        # Calculate risk score
        risk_score = self._calculate_risk(graph)

        # Generate fallback plan
        fallback = self._generate_fallback(graph, execution_order)

        plan = ExecutionPlan(
            plan_id=str(uuid.uuid4()),
            workflow_id=request.workflow_id,
            execution_order=execution_order,
            parallel_groups=parallel_groups,
            estimated_duration_ms=estimated_duration,
            estimated_cost_usd=estimated_cost,
            risk_score=risk_score,
            fallback_plan=fallback
        )

        self._plan_cache[plan.plan_id] = plan
        logger.info(f"Generated execution plan {plan.plan_id} for workflow {request.workflow_id}")

        return plan

    def _topological_sort(self, dependencies: Dict[str, set]) -> List[str]:
        """Topological sort of task dependencies"""
        in_degree = {node: 0 for node in dependencies}
        for deps in dependencies.values():
            for dep in deps:
                if dep in in_degree:
                    in_degree[dep] += 1

        queue = [node for node, degree in in_degree.items() if degree == 0]
        result = []

        while queue:
            node = queue.pop(0)
            result.append(node)

            for other, deps in dependencies.items():
                if node in deps:
                    in_degree[other] -= 1
                    if in_degree[other] == 0:
                        queue.append(other)

        return result

    def _find_parallel_groups(self, graph: WorkflowGraph, 
                             dependencies: Dict[str, set]) -> List[List[str]]:
        """Find groups of tasks that can execute in parallel"""
        groups = []
        executed = set()
        remaining = {node.id for node in graph.nodes}

        while remaining:
            group = []
            for node_id in list(remaining):
                if all(dep in executed for dep in dependencies.get(node_id, set())):
                    group.append(node_id)

            if group:
                groups.append(group)
                executed.update(group)
                remaining -= set(group)
            else:
                break

        return groups

    def _estimate_duration(self, graph: WorkflowGraph, goal: str) -> int:
        """Estimate total execution duration in ms"""
        total = 0
        for node in graph.nodes:
            base_time = node.timeout_seconds * 1000
            if goal == "speed":
                base_time *= 0.7  # Optimistic
            elif goal == "reliability":
                base_time *= 1.3  # Conservative
            total += base_time
        return int(total)

    def _estimate_cost(self, graph: WorkflowGraph, goal: str) -> float:
        """Estimate total execution cost in USD"""
        total = 0.0
        for node in graph.nodes:
            if node.task_type == "ai_call":
                total += 0.05
            elif node.task_type == "api_call":
                total += 0.01
            elif node.task_type == "builder_deploy":
                total += 0.10
            elif node.task_type == "automation_trigger":
                total += 0.02

        if goal == "cost":
            total *= 0.8
        return round(total, 4)

    def _calculate_risk(self, graph: WorkflowGraph) -> float:
        """Calculate execution risk score (0-1, lower is better)"""
        risk = 0.0
        for node in graph.nodes:
            if node.on_failure == "fail":
                risk += 0.2
            if node.retry_count == 0:
                risk += 0.1
            if node.timeout_seconds < 30:
                risk += 0.15
        return min(risk / max(len(graph.nodes), 1), 1.0)

    def _generate_fallback(self, graph: WorkflowGraph, 
                          execution_order: List[str]) -> Dict[str, Any]:
        """Generate fallback execution plan"""
        # Simplified fallback: skip non-critical tasks
        critical_tasks = []
        for node in graph.nodes:
            if node.on_failure == "fail":
                critical_tasks.append(node.id)

        return {
            "critical_only": critical_tasks,
            "skip_non_critical": True,
            "max_retries": 5
        }

    async def optimize_plan(self, db: AsyncSession, plan_id: str, 
                          optimization_type: str) -> ExecutionPlan:
        """Optimize existing plan"""
        plan = self._plan_cache.get(plan_id)
        if not plan:
            raise HTTPException(status_code=404, detail="Plan not found")

        # Re-generate with different optimization goal
        request = PlanRequest(
            workflow_id=plan.workflow_id,
            optimization_goal=optimization_type
        )

        return await self.generate_plan(db, request)

execution_planner = ExecutionPlanner()

# API Endpoints
@router.post("/plan")
async def create_plan(request: PlanRequest, db: AsyncSession = Depends(get_db)):
    """Generate execution plan"""
    plan = await execution_planner.generate_plan(db, request)
    return plan.dict()

@router.post("/optimize/{plan_id}")
async def optimize_plan(plan_id: str, optimization_type: str, db: AsyncSession = Depends(get_db)):
    """Optimize existing plan"""
    plan = await execution_planner.optimize_plan(db, plan_id, optimization_type)
    return plan.dict()

@router.get("/plan/{plan_id}")
async def get_plan(plan_id: str):
    """Get plan details"""
    plan = execution_planner._plan_cache.get(plan_id)
    if not plan:
        raise HTTPException(status_code=404, detail="Plan not found")
    return plan.dict()
