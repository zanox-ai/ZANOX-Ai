"""ZANOX V12 Hyper Automation & Integration Layer - Main Application"""
from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from contextlib import asynccontextmanager
import logging
import sys

from shared.database import init_db, engine
from shared.config import config
from shared.redis_client import redis_client
from shared.security import security_manager

# Import all routers
from integration_registry.registry import router as integration_router
from connector_registry.registry import router as connector_router
from connector_marketplace.marketplace import router as marketplace_router
from connector_lifecycle.manager import router as lifecycle_router
from connector_discovery.engine import router as discovery_router
from connector_monitoring.engine import router as connector_monitoring_router
from automation_engine.engine import router as automation_router
from workflow_orchestrator.orchestrator import router as workflow_router
from workflow_composer.composer import router as composer_router
from workflow_marketplace.marketplace import router as wf_marketplace_router
from workflow_builder.builder import router as builder_router
from multi_agent.coordinator import router as multi_agent_router
from multi_ai.coordinator import router as multi_ai_router
from multi_builder.coordinator import router as multi_builder_router
from task_distribution.engine import router as task_dist_router
from task_delegation.engine import router as task_del_router
from execution_planner.planner import router as planner_router
from execution_optimizer.optimizer import router as optimizer_router
from cost_optimization.engine import router as cost_router
from failure_recovery.engine import router as recovery_router
from human_approval.engine import router as approval_router
from memory_sync.sync import router as memory_router
from context_sync.sync import router as context_router
from event_bus.bus import router as event_router
from api_gateway.gateway import router as api_gateway_router
from webhook_gateway.gateway import router as webhook_router
from analytics.engine import router as analytics_router
from monitoring.engine import router as monitoring_router
from security.layer import router as security_router
from governance.engine import router as governance_router
from compliance.engine import router as compliance_router
from self_healing.engine import router as self_healing_router

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("/mnt/agents/output/ZANOX_V12_Hyper_Automation_Layer/logs/zanox.log")
    ]
)
logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager"""
    logger.info(f"Starting {config.APP_NAME} v{config.APP_VERSION}")

    # Initialize database
    await init_db()

    # Initialize Redis
    await redis_client.connect()

    # Initialize integrations
    from integration_registry.registry import integration_manager
    from shared.database import AsyncSessionLocal
    async with AsyncSessionLocal() as db:
        await integration_manager.initialize_defaults(db)

    logger.info("ZANOX V12 initialized successfully")
    yield

    # Cleanup
    await redis_client.disconnect()
    await engine.dispose()
    logger.info("ZANOX V12 shutdown complete")

app = FastAPI(
    title="ZANOX V12 Hyper Automation & Integration Layer",
    description="Universal orchestration platform for AI, Agents, Builders, Workflows, SaaS, APIs and Automation platforms",
    version="12.0.0",
    lifespan=lifespan
)

# Middleware
app.add_middleware(GZipMiddleware, minimum_size=1000)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include all routers
app.include_router(integration_router)
app.include_router(connector_router)
app.include_router(marketplace_router)
app.include_router(lifecycle_router)
app.include_router(discovery_router)
app.include_router(connector_monitoring_router)
app.include_router(automation_router)
app.include_router(workflow_router)
app.include_router(composer_router)
app.include_router(wf_marketplace_router)
app.include_router(builder_router)
app.include_router(multi_agent_router)
app.include_router(multi_ai_router)
app.include_router(multi_builder_router)
app.include_router(task_dist_router)
app.include_router(task_del_router)
app.include_router(planner_router)
app.include_router(optimizer_router)
app.include_router(cost_router)
app.include_router(recovery_router)
app.include_router(approval_router)
app.include_router(memory_router)
app.include_router(context_router)
app.include_router(event_router)
app.include_router(api_gateway_router)
app.include_router(webhook_router)
app.include_router(analytics_router)
app.include_router(monitoring_router)
app.include_router(security_router)
app.include_router(governance_router)
app.include_router(compliance_router)
app.include_router(self_healing_router)

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "name": config.APP_NAME,
        "version": config.APP_VERSION,
        "status": "operational",
        "modules": [
            "integration_registry", "connector_registry", "automation_engine",
            "workflow_orchestrator", "multi_agent", "multi_ai", "multi_builder",
            "task_distribution", "cost_optimization", "failure_recovery",
            "human_approval", "memory_sync", "context_sync", "event_bus",
            "api_gateway", "webhook_gateway", "analytics", "monitoring",
            "security", "governance", "compliance", "self_healing"
        ]
    }

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "version": config.APP_VERSION
    }

@app.get("/api/v12/status")
async def system_status():
    """System status endpoint"""
    return {
        "platform": "ZANOX V12",
        "status": "operational",
        "supported_ai": config.SUPPORTED_AI_SYSTEMS,
        "supported_automation": config.SUPPORTED_AUTOMATION_PLATFORMS,
        "supported_agents": config.SUPPORTED_AGENT_PLATFORMS,
        "supported_builders": config.SUPPORTED_BUILDER_PLATFORMS,
        "supported_backends": config.SUPPORTED_BACKEND_PLATFORMS,
        "supported_devops": config.SUPPORTED_DEVOPS_PLATFORMS,
        "supported_creative": config.SUPPORTED_CREATIVE_PLATFORMS
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
