"""ZANOX V12 Connector Marketplace - Connector Discovery & Distribution"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, or_, func
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime
import uuid
import logging

from shared.database import get_db
from shared.models import ConnectorMarketplace, ConnectorRegistry
from shared.config import config

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v12/connector-marketplace", tags=["Connector Marketplace"])

class MarketplaceEntry(BaseModel):
    """Marketplace entry"""
    connector_id: str
    publisher_name: str
    price_usd: float = 0.0
    tags: List[str] = []
    documentation_url: Optional[str] = None
    is_premium: bool = False

class ConnectorMarketplaceEngine:
    """Manages connector marketplace"""

    async def publish(self, db: AsyncSession, entry: MarketplaceEntry) -> ConnectorMarketplace:
        """Publish connector to marketplace"""
        # Verify connector exists
        connector = await db.get(ConnectorRegistry, entry.connector_id)
        if not connector:
            raise HTTPException(status_code=404, detail="Connector not found")

        marketplace = ConnectorMarketplace(
            id=str(uuid.uuid4()),
            connector_id=entry.connector_id,
            publisher_id=str(uuid.uuid4()),
            publisher_name=entry.publisher_name,
            price_usd=entry.price_usd,
            tags=entry.tags,
            documentation_url=entry.documentation_url,
            is_premium=entry.is_premium
        )
        db.add(marketplace)
        await db.commit()
        await db.refresh(marketplace)
        return marketplace

    async def search(self, db: AsyncSession, 
                    query: Optional[str] = None,
                    tags: Optional[List[str]] = None,
                    is_premium: Optional[bool] = None) -> List[Dict[str, Any]]:
        """Search marketplace"""
        sql = select(ConnectorMarketplace).join(ConnectorRegistry)

        if query:
            sql = sql.where(
                or_(
                    ConnectorMarketplace.publisher_name.ilike(f"%{query}%"),
                    ConnectorRegistry.name.ilike(f"%{query}%")
                )
            )

        if tags:
            sql = sql.where(ConnectorMarketplace.tags.overlap(tags))

        if is_premium is not None:
            sql = sql.where(ConnectorMarketplace.is_premium == is_premium)

        result = await db.execute(sql)
        entries = result.scalars().all()

        return [
            {
                "id": e.id,
                "connector_id": e.connector_id,
                "publisher": e.publisher_name,
                "rating": e.rating,
                "reviews": e.review_count,
                "downloads": e.download_count,
                "price": e.price_usd,
                "tags": e.tags,
                "is_premium": e.is_premium,
                "is_verified": e.is_verified
            }
            for e in entries
        ]

    async def download(self, db: AsyncSession, marketplace_id: str) -> Dict[str, Any]:
        """Download connector from marketplace"""
        entry = await db.get(ConnectorMarketplace, marketplace_id)
        if not entry:
            raise HTTPException(status_code=404, detail="Marketplace entry not found")

        entry.download_count += 1
        await db.commit()

        connector = await db.get(ConnectorRegistry, entry.connector_id)

        return {
            "connector_id": entry.connector_id,
            "name": connector.name if connector else "unknown",
            "version": connector.version if connector else "unknown",
            "download_count": entry.download_count,
            "documentation": entry.documentation_url
        }

marketplace_engine = ConnectorMarketplaceEngine()

@router.post("/publish")
async def publish_connector(entry: MarketplaceEntry, db: AsyncSession = Depends(get_db)):
    """Publish connector"""
    result = await marketplace_engine.publish(db, entry)
    return {"id": result.id, "status": "published"}

@router.get("/search")
async def search_marketplace(
    query: Optional[str] = None,
    tags: Optional[List[str]] = None,
    is_premium: Optional[bool] = None,
    db: AsyncSession = Depends(get_db)
):
    """Search marketplace"""
    return await marketplace_engine.search(db, query, tags, is_premium)

@router.get("/download/{marketplace_id}")
async def download_connector(marketplace_id: str, db: AsyncSession = Depends(get_db)):
    """Download connector"""
    return await marketplace_engine.download(db, marketplace_id)
