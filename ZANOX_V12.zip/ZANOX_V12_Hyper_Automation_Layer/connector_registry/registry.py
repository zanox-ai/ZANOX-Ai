"""ZANOX V12 Connector Registry - Real Connector Implementations"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, and_
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime
import uuid
import logging
import httpx
import asyncio

from shared.database import get_db
from shared.models import ConnectorRegistry, ConnectorStatus, IntegrationRegistry
from shared.redis_client import redis_client
from shared.security import security_manager

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v12/connectors", tags=["Connector Registry"])

class ConnectorCreate(BaseModel):
    integration_id: str
    name: str = Field(..., min_length=1, max_length=255)
    version: str = "1.0.0"
    connector_type: str = "rest"  # rest, graphql, webhook, sdk, grpc
    protocol: str = "https"
    endpoint_url: Optional[str] = None
    auth_config: Optional[Dict[str, Any]] = {}
    headers: Optional[Dict[str, str]] = {}
    timeout_seconds: int = 30
    retry_policy: Optional[Dict[str, Any]] = {"max_retries": 3, "backoff": "exponential"}
    circuit_breaker_config: Optional[Dict[str, Any]] = {"failure_threshold": 5, "recovery_timeout": 60}

class ConnectorUpdate(BaseModel):
    name: Optional[str] = None
    endpoint_url: Optional[str] = None
    auth_config: Optional[Dict[str, Any]] = None
    headers: Optional[Dict[str, str]] = None
    timeout_seconds: Optional[int] = None
    retry_policy: Optional[Dict[str, Any]] = None
    status: Optional[ConnectorStatus] = None

class ConnectorResponse(BaseModel):
    id: str
    integration_id: str
    name: str
    version: str
    connector_type: str
    protocol: str
    endpoint_url: Optional[str]
    status: str
    failure_count: int
    response_time_ms: Optional[float]
    request_count: int
    error_rate: float
    created_at: datetime

class ConnectorExecutor:
    """Real connector execution engine with circuit breaker, retries, and monitoring"""

    def __init__(self):
        self._circuit_states: Dict[str, Dict] = {}
        self._http_client: Optional[httpx.AsyncClient] = None

    async def _get_client(self) -> httpx.AsyncClient:
        if self._http_client is None:
            self._http_client = httpx.AsyncClient(
                timeout=30.0,
                limits=httpx.Limits(max_connections=100, max_keepalive_connections=20)
            )
        return self._http_client

    def _get_circuit_state(self, connector_id: str) -> Dict:
        if connector_id not in self._circuit_states:
            self._circuit_states[connector_id] = {
                "state": "closed",  # closed, open, half_open
                "failure_count": 0,
                "last_failure_time": None,
                "success_count": 0
            }
        return self._circuit_states[connector_id]

    def _check_circuit(self, connector_id: str, config: Dict) -> bool:
        """Check if circuit breaker allows request"""
        state = self._get_circuit_state(connector_id)
        threshold = config.get("failure_threshold", 5)
        recovery = config.get("recovery_timeout", 60)

        if state["state"] == "open":
            if state["last_failure_time"] and                (datetime.utcnow() - state["last_failure_time"]).seconds > recovery:
                state["state"] = "half_open"
                state["failure_count"] = 0
                return True
            return False
        return True

    def _record_success(self, connector_id: str):
        state = self._get_circuit_state(connector_id)
        state["success_count"] += 1
        if state["state"] == "half_open" and state["success_count"] >= 3:
            state["state"] = "closed"
            state["failure_count"] = 0

    def _record_failure(self, connector_id: str, config: Dict):
        state = self._get_circuit_state(connector_id)
        state["failure_count"] += 1
        state["last_failure_time"] = datetime.utcnow()

        threshold = config.get("failure_threshold", 5)
        if state["failure_count"] >= threshold:
            state["state"] = "open"
            logger.warning(f"Circuit breaker OPEN for connector {connector_id}")

    async def execute(self, connector: ConnectorRegistry, 
                     method: str = "GET", 
                     path: str = "", 
                     payload: Optional[Dict] = None,
                     headers: Optional[Dict] = None) -> Dict[str, Any]:
        """Execute real HTTP request through connector"""

        # Check circuit breaker
        if not self._check_circuit(connector.id, connector.circuit_breaker_config or {}):
            raise HTTPException(status_code=503, detail="Circuit breaker is OPEN")

        # Build request
        integration = await connector.awaitable_attrs.integration
        base_url = connector.endpoint_url or integration.api_base_url
        url = f"{base_url.rstrip('/')}/{path.lstrip('/')}" if path else base_url

        # Prepare auth headers
        auth_config = connector.auth_config or {}
        request_headers = {"Content-Type": "application/json", "Accept": "application/json"}

        if integration.auth_type == "bearer":
            api_key = auth_config.get("api_key", "")
            request_headers["Authorization"] = f"Bearer {api_key}"
        elif integration.auth_type == "api_key":
            api_key = auth_config.get("api_key", "")
            request_headers["X-API-Key"] = api_key
        elif integration.auth_type == "basic":
            import base64
            username = auth_config.get("username", "")
            password = auth_config.get("password", "")
            creds = base64.b64encode(f"{username}:{password}".encode()).decode()
            request_headers["Authorization"] = f"Basic {creds}"

        # Merge custom headers
        if connector.headers:
            request_headers.update(connector.headers)
        if headers:
            request_headers.update(headers)

        # Execute with retries
        max_retries = (connector.retry_policy or {}).get("max_retries", 3)
        client = await self._get_client()

        start_time = datetime.utcnow()
        last_error = None

        for attempt in range(max_retries + 1):
            try:
                response = await client.request(
                    method=method.upper(),
                    url=url,
                    headers=request_headers,
                    json=payload,
                    timeout=connector.timeout_seconds or 30
                )

                duration_ms = (datetime.utcnow() - start_time).total_seconds() * 1000

                # Record success
                self._record_success(connector.id)

                # Update connector stats
                connector.request_count += 1
                connector.response_time_ms = duration_ms
                connector.last_success = datetime.utcnow()

                return {
                    "success": True,
                    "status_code": response.status_code,
                    "headers": dict(response.headers),
                    "body": response.json() if response.headers.get("content-type", "").startswith("application/json") else response.text,
                    "duration_ms": duration_ms,
                    "connector_id": connector.id
                }

            except httpx.HTTPStatusError as e:
                last_error = e
                if attempt < max_retries:
                    wait = 2 ** attempt
                    await asyncio.sleep(wait)
                    continue
                break
            except Exception as e:
                last_error = e
                if attempt < max_retries:
                    wait = 2 ** attempt
                    await asyncio.sleep(wait)
                    continue
                break

        # All retries failed
        duration_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
        self._record_failure(connector.id, connector.circuit_breaker_config or {})

        connector.failure_count += 1
        connector.last_failure = datetime.utcnow()
        connector.error_rate = connector.failure_count / max(connector.request_count, 1)

        return {
            "success": False,
            "error": str(last_error),
            "duration_ms": duration_ms,
            "connector_id": connector.id,
            "retries_attempted": max_retries
        }

connector_executor = ConnectorExecutor()

class ConnectorManager:
    """Manages connector lifecycle and operations"""

    async def create(self, db: AsyncSession, data: ConnectorCreate) -> ConnectorRegistry:
        """Create new connector"""
        # Verify integration exists
        integration = await db.get(IntegrationRegistry, data.integration_id)
        if not integration:
            raise HTTPException(status_code=404, detail="Integration not found")

        connector = ConnectorRegistry(
            id=str(uuid.uuid4()),
            **data.dict()
        )
        db.add(connector)
        await db.commit()
        await db.refresh(connector)
        logger.info(f"Created connector: {connector.name} for {integration.provider}")
        return connector

    async def get_all(self, db: AsyncSession, integration_id: Optional[str] = None,
                     status: Optional[str] = None) -> List[ConnectorRegistry]:
        """Get all connectors"""
        query = select(ConnectorRegistry)
        if integration_id:
            query = query.where(ConnectorRegistry.integration_id == integration_id)
        if status:
            query = query.where(ConnectorRegistry.status == status)
        result = await db.execute(query)
        return result.scalars().all()

    async def get_by_id(self, db: AsyncSession, connector_id: str) -> Optional[ConnectorRegistry]:
        """Get connector by ID"""
        return await db.get(ConnectorRegistry, connector_id)

    async def update(self, db: AsyncSession, connector_id: str, data: ConnectorUpdate) -> ConnectorRegistry:
        """Update connector"""
        connector = await db.get(ConnectorRegistry, connector_id)
        if not connector:
            raise HTTPException(status_code=404, detail="Connector not found")

        update_data = data.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(connector, field, value)

        await db.commit()
        await db.refresh(connector)
        return connector

    async def execute_connector(self, db: AsyncSession, connector_id: str,
                                method: str = "GET", path: str = "",
                                payload: Optional[Dict] = None) -> Dict[str, Any]:
        """Execute real request through connector"""
        connector = await db.get(ConnectorRegistry, connector_id)
        if not connector:
            raise HTTPException(status_code=404, detail="Connector not found")

        if connector.status != ConnectorStatus.ACTIVE:
            raise HTTPException(status_code=400, detail="Connector is not active")

        # Eager load integration
        result = await db.execute(
            select(ConnectorRegistry).where(ConnectorRegistry.id == connector_id)
        )
        connector = result.scalar_one()

        return await connector_executor.execute(connector, method, path, payload)

    async def health_check(self, db: AsyncSession, connector_id: str) -> Dict[str, Any]:
        """Perform health check on connector"""
        connector = await db.get(ConnectorRegistry, connector_id)
        if not connector:
            raise HTTPException(status_code=404, detail="Connector not found")

        integration = await db.get(IntegrationRegistry, connector.integration_id)
        if not integration:
            return {"status": "error", "message": "Integration not found"}

        # Try a simple GET request or HEAD
        test_path = integration.api_base_url
        try:
            client = await connector_executor._get_client()
            headers = {}
            if integration.auth_type == "bearer":
                api_key = (connector.auth_config or {}).get("api_key", "")
                headers["Authorization"] = f"Bearer {api_key}"

            response = await client.head(test_path, headers=headers, timeout=10)

            status = "healthy" if response.status_code < 500 else "degraded"
            return {
                "connector_id": connector_id,
                "status": status,
                "http_status": response.status_code,
                "response_time_ms": None,
                "checked_at": datetime.utcnow().isoformat()
            }
        except Exception as e:
            return {
                "connector_id": connector_id,
                "status": "unhealthy",
                "error": str(e),
                "checked_at": datetime.utcnow().isoformat()
            }

connector_manager = ConnectorManager()

# API Endpoints
@router.post("/", response_model=ConnectorResponse)
async def create_connector(data: ConnectorCreate, db: AsyncSession = Depends(get_db)):
    """Create new connector"""
    return await connector_manager.create(db, data)

@router.get("/", response_model=List[ConnectorResponse])
async def list_connectors(
    integration_id: Optional[str] = None,
    status: Optional[str] = None,
    db: AsyncSession = Depends(get_db)
):
    """List all connectors"""
    return await connector_manager.get_all(db, integration_id, status)

@router.get("/{connector_id}", response_model=ConnectorResponse)
async def get_connector(connector_id: str, db: AsyncSession = Depends(get_db)):
    """Get connector by ID"""
    connector = await connector_manager.get_by_id(db, connector_id)
    if not connector:
        raise HTTPException(status_code=404, detail="Connector not found")
    return connector

@router.put("/{connector_id}", response_model=ConnectorResponse)
async def update_connector(connector_id: str, data: ConnectorUpdate, db: AsyncSession = Depends(get_db)):
    """Update connector"""
    return await connector_manager.update(db, connector_id, data)

@router.post("/{connector_id}/execute")
async def execute_connector(
    connector_id: str,
    method: str = "GET",
    path: str = "",
    payload: Optional[Dict] = None,
    db: AsyncSession = Depends(get_db)
):
    """Execute real request through connector"""
    return await connector_manager.execute_connector(db, connector_id, method, path, payload)

@router.get("/{connector_id}/health")
async def check_connector_health(connector_id: str, db: AsyncSession = Depends(get_db)):
    """Check connector health"""
    return await connector_manager.health_check(db, connector_id)
