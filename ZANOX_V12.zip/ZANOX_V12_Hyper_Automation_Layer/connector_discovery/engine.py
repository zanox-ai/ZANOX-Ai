"""ZANOX V12 Connector Discovery Engine"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime
import uuid
import logging

from shared.database import get_db
from shared.models import IntegrationRegistry, ConnectorRegistry
from shared.config import config

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v12/connector-discovery", tags=["Connector Discovery"])

class DiscoveryResult(BaseModel):
    """Discovery result"""
    platform: str
    discovered: bool
    capabilities: List[str]
    suggested_connector: Optional[str]

class ConnectorDiscoveryEngine:
    """Discovers and suggests connectors for platforms"""

    async def discover(self, db: AsyncSession, 
                      platform_type: Optional[str] = None) -> List[DiscoveryResult]:
        """Discover available connectors"""
        query = select(IntegrationRegistry)
        if platform_type:
            query = query.where(IntegrationRegistry.platform_type == platform_type)

        result = await db.execute(query)
        integrations = result.scalars().all()

        discoveries = []
        for integration in integrations:
            # Check if connector exists
            conn_result = await db.execute(
                select(ConnectorRegistry)
                .where(ConnectorRegistry.integration_id == integration.id)
                .where(ConnectorRegistry.status == "active")
            )
            connector = conn_result.scalar_one_or_none()

            discoveries.append(DiscoveryResult(
                platform=integration.provider,
                discovered=connector is not None,
                capabilities=integration.capabilities or [],
                suggested_connector=connector.name if connector else None
            ))

        return discoveries

    async def suggest(self, db: AsyncSession, 
                     task_type: str) -> List[Dict[str, Any]]:
        """Suggest connectors for task type"""
        # Map task types to platform types
        type_mapping = {
            "ai_call": "ai",
            "api_call": "automation",
            "agent_task": "agent",
            "builder_deploy": "builder"
        }

        platform_type = type_mapping.get(task_type, "automation")

        result = await db.execute(
            select(IntegrationRegistry)
            .where(IntegrationRegistry.platform_type == platform_type)
            .where(IntegrationRegistry.is_active == True)
        )
        integrations = result.scalars().all()

        return [
            {
                "platform": i.provider,
                "name": i.name,
                "capabilities": i.capabilities,
                "auth_type": i.auth_type
            }
            for i in integrations
        ]

discovery_engine = ConnectorDiscoveryEngine()

@router.get("/discover")
async def discover_connectors(
    platform_type: Optional[str] = None,
    db: AsyncSession = Depends(get_db)
):
    """Discover connectors"""
    results = await discovery_engine.discover(db, platform_type)
    return {"discoveries": [r.dict() for r in results]}

@router.get("/suggest/{task_type}")
async def suggest_connectors(task_type: str, db: AsyncSession = Depends(get_db)):
    """Suggest connectors for task"""
    return await discovery_engine.suggest(db, task_type)
