# ZANOX V12 Connector Discovery
