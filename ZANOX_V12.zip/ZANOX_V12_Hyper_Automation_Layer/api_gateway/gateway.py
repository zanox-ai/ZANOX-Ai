"""ZANOX V12 API Gateway - Unified API Management"""
from fastapi import APIRouter, Depends, HTTPException, Request, Response
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime, timedelta
import uuid
import logging
import time
import hashlib

from shared.database import get_db
from shared.models import ApiKey, User, AuditLog
from shared.security import security_manager
from shared.redis_client import redis_client
from shared.config import config

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v12/gateway", tags=["API Gateway"])
security = HTTPBearer()

class GatewayRequest(BaseModel):
    """Request through API Gateway"""
    path: str
    method: str = "GET"
    headers: Optional[Dict[str, str]] = {}
    body: Optional[Dict[str, Any]] = None
    target_service: Optional[str] = None

class GatewayResponse(BaseModel):
    """Response from API Gateway"""
    status_code: int
    headers: Dict[str, str]
    body: Any
    duration_ms: float
    request_id: str

class APIGateway:
    """Unified API Gateway with rate limiting, auth, and routing"""

    def __init__(self):
        self._rate_limit_cache: Dict[str, Dict] = {}
        self._request_count: int = 0

    async def authenticate(self, db: AsyncSession, 
                          credentials: HTTPAuthorizationCredentials) -> Optional[User]:
        """Authenticate API request"""
        token = credentials.credentials

        # Check if it's a JWT
        payload = security_manager.decode_token(token)
        if payload:
            user_id = payload.get("sub")
            if user_id:
                return await db.get(User, user_id)

        # Check API key
        key_hash = security_manager.hash_api_key(token)
        result = await db.execute(
            select(ApiKey)
            .where(ApiKey.key_hash == key_hash)
            .where(ApiKey.is_active == True)
        )
        api_key = result.scalar_one_or_none()

        if api_key and (not api_key.expires_at or api_key.expires_at > datetime.utcnow()):
            # Update last used
            api_key.last_used_at = datetime.utcnow()
            await db.commit()

            # Get user
            return await db.get(User, api_key.user_id)

        return None

    async def check_rate_limit(self, key: str, limit: int = None, 
                              window: int = 60) -> bool:
        """Check rate limit for key"""
        if limit is None:
            limit = config.RATE_LIMIT_PER_MINUTE

        redis_key = f"rate_limit:{key}"
        current = await redis_client.get(redis_key)

        if current is None:
            await redis_client.set(redis_key, "1", expire=window)
            return True

        count = int(current)
        if count >= limit:
            return False

        await redis_client.set(redis_key, str(count + 1), expire=window)
        return True

    async def route_request(self, db: AsyncSession, request: GatewayRequest,
                         user: Optional[User] = None) -> GatewayResponse:
        """Route request to appropriate service"""
        request_id = str(uuid.uuid4())
        start_time = time.time()

        # Log request
        audit = AuditLog(
            action="api_request",
            entity_type="gateway_request",
            entity_id=request_id,
            user_id=user.id if user else None,
            metadata={
                "path": request.path,
                "method": request.method,
                "target": request.target_service
            }
        )
        db.add(audit)
        await db.commit()

        # Route to internal service
        response_body = {"status": "routed", "path": request.path, "request_id": request_id}

        duration_ms = (time.time() - start_time) * 1000

        return GatewayResponse(
            status_code=200,
            headers={"X-Request-ID": request_id, "Content-Type": "application/json"},
            body=response_body,
            duration_ms=duration_ms,
            request_id=request_id
        )

    async def validate_request(self, request: Request) -> Dict[str, Any]:
        """Validate incoming request"""
        # Check content type
        content_type = request.headers.get("content-type", "")
        if request.method in ["POST", "PUT", "PATCH"]:
            if not content_type.startswith("application/json"):
                raise HTTPException(status_code=415, detail="Content-Type must be application/json")

        # Check request size
        body = await request.body()
        if len(body) > 10 * 1024 * 1024:  # 10MB limit
            raise HTTPException(status_code=413, detail="Request body too large")

        return {"valid": True, "size": len(body)}

    async def generate_request_signature(self, request: Request, 
                                         secret: str) -> str:
        """Generate request signature for verification"""
        body = await request.body()
        timestamp = str(int(time.time()))

        signature = hashlib.sha256(
            f"{timestamp}:{secret}:{body.decode()}".encode()
        ).hexdigest()

        return f"t={timestamp},v1={signature}"

api_gateway = APIGateway()

@router.post("/route")
async def route_request(
    request: GatewayRequest,
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """Route request through gateway"""
    user = await api_gateway.authenticate(db, credentials)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid credentials")

    # Check rate limit
    rate_key = f"user:{user.id}"
    if not await api_gateway.check_rate_limit(rate_key):
        raise HTTPException(status_code=429, detail="Rate limit exceeded")

    return await api_gateway.route_request(db, request, user)

@router.get("/health")
async def gateway_health():
    """Gateway health check"""
    return {"status": "healthy", "gateway": "api", "version": "12.0.0"}
