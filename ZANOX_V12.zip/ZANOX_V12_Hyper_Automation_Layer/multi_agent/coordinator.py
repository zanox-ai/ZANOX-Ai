"""ZANOX V12 Multi-Agent Coordinator - Orchestrates Multiple Agent Platforms"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime
import uuid
import logging
import asyncio

from shared.database import get_db
from shared.models import ConnectorRegistry, IntegrationRegistry, PlatformType
from connector_registry.registry import connector_manager

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v12/multi-agent", tags=["Multi-Agent Coordinator"])

class AgentTask(BaseModel):
    """Task to be executed by an agent platform"""
    task_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    description: str
    platform: str  # flowise, langflow, dify, etc.
    agent_config: Dict[str, Any] = {}
    tools: List[str] = []
    context: Dict[str, Any] = {}
    priority: int = 5  # 1-10, 1 = highest
    timeout_seconds: int = 600

class AgentResult(BaseModel):
    """Result from agent execution"""
    task_id: str
    platform: str
    status: str
    result: Optional[Dict[str, Any]]
    error: Optional[str]
    duration_ms: float
    tokens_used: Optional[int]

class MultiAgentCoordinator:
    """Coordinates tasks across multiple agent platforms with intelligent routing"""

    AGENT_CAPABILITIES = {
        "flowise": ["chatbot", "rag", "api_integration", "custom_workflow"],
        "langflow": ["langchain", "rag", "agent", "workflow"],
        "dify": ["chatbot", "agent", "workflow", "knowledge_base"],
        "openwebui": ["chat", "rag", "model_management"],
        "crewai": ["multi_agent", "task_delegation", "research", "writing"],
        "autogen": ["multi_agent", "code_generation", "conversation"],
        "langgraph": ["state_machine", "agent", "workflow"],
        "semantic_kernel": ["planner", "memory", "plugins"]
    }

    def __init__(self):
        self._active_tasks: Dict[str, Dict] = {}

    async def _get_platform_connector(self, db: AsyncSession, platform: str) -> Optional[ConnectorRegistry]:
        """Get active connector for agent platform"""
        result = await db.execute(
            select(ConnectorRegistry)
            .join(IntegrationRegistry)
            .where(IntegrationRegistry.provider == platform)
            .where(IntegrationRegistry.platform_type == PlatformType.AGENT)
            .where(ConnectorRegistry.status == "active")
        )
        return result.scalar_one_or_none()

    async def route_task(self, db: AsyncSession, task: AgentTask) -> str:
        """Intelligently route task to best agent platform"""
        # If platform specified, use it
        if task.platform:
            connector = await self._get_platform_connector(db, task.platform)
            if not connector:
                raise HTTPException(status_code=400, detail=f"Agent platform {task.platform} not available")
            return task.platform

        # Auto-select based on capabilities
        best_platform = None
        best_score = -1

        for platform, capabilities in self.AGENT_CAPABILITIES.items():
            connector = await self._get_platform_connector(db, platform)
            if not connector:
                continue

            score = 0
            for tool in task.tools:
                if tool in capabilities:
                    score += 10

            if score > best_score:
                best_score = score
                best_platform = platform

        if not best_platform:
            # Fallback to first available
            for platform in self.AGENT_CAPABILITIES:
                connector = await self._get_platform_connector(db, platform)
                if connector:
                    best_platform = platform
                    break

        if not best_platform:
            raise HTTPException(status_code=503, detail="No agent platforms available")

        return best_platform

    async def execute_task(self, db: AsyncSession, task: AgentTask) -> AgentResult:
        """Execute task on agent platform"""
        platform = await self.route_task(db, task)
        connector = await self._get_platform_connector(db, platform)

        if not connector:
            return AgentResult(
                task_id=task.task_id,
                platform=platform,
                status="failed",
                result=None,
                error="Connector not found",
                duration_ms=0,
                tokens_used=None
            )

        start_time = datetime.utcnow()

        # Build payload based on platform
        payload = self._build_agent_payload(platform, task)

        try:
            result = await connector_manager.execute_connector(
                db, connector.id, "POST", "execute", payload
            )

            duration_ms = (datetime.utcnow() - start_time).total_seconds() * 1000

            return AgentResult(
                task_id=task.task_id,
                platform=platform,
                status="completed" if result.get("success") else "failed",
                result=result.get("body") if result.get("success") else None,
                error=result.get("error") if not result.get("success") else None,
                duration_ms=duration_ms,
                tokens_used=result.get("body", {}).get("usage", {}).get("total_tokens") if result.get("success") else None
            )
        except Exception as e:
            duration_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            return AgentResult(
                task_id=task.task_id,
                platform=platform,
                status="failed",
                result=None,
                error=str(e),
                duration_ms=duration_ms,
                tokens_used=None
            )

    def _build_agent_payload(self, platform: str, task: AgentTask) -> Dict[str, Any]:
        """Build platform-specific payload"""
        payloads = {
            "flowise": {
                "question": task.description,
                "overrideConfig": task.agent_config,
                "history": task.context.get("history", [])
            },
            "langflow": {
                "input_value": task.description,
                "output_type": "chat",
                "input_type": "chat"
            },
            "dify": {
                "inputs": task.context,
                "query": task.description,
                "response_mode": "blocking"
            },
            "crewai": {
                "task": task.description,
                "agents": task.agent_config.get("agents", []),
                "tools": task.tools,
                "context": task.context
            },
            "autogen": {
                "message": task.description,
                "config_list": task.agent_config.get("config_list", []),
                "group_chat": task.agent_config.get("group_chat", False)
            },
            "langgraph": {
                "input": task.description,
                "config": task.agent_config,
                "thread_id": task.context.get("thread_id")
            },
            "semantic_kernel": {
                "input": task.description,
                "skills": task.tools,
                "settings": task.agent_config
            }
        }
        return payloads.get(platform, {"task": task.description, "context": task.context})

    async def execute_parallel(self, db: AsyncSession, tasks: List[AgentTask]) -> List[AgentResult]:
        """Execute multiple agent tasks in parallel"""
        async def execute_single(task):
            return await self.execute_task(db, task)

        results = await asyncio.gather(*[execute_single(t) for t in tasks], return_exceptions=True)

        processed_results = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                processed_results.append(AgentResult(
                    task_id=tasks[i].task_id,
                    platform=tasks[i].platform,
                    status="failed",
                    result=None,
                    error=str(result),
                    duration_ms=0,
                    tokens_used=None
                ))
            else:
                processed_results.append(result)

        return processed_results

    async def get_platform_status(self, db: AsyncSession) -> Dict[str, Any]:
        """Get status of all agent platforms"""
        status = {}
        for platform in self.AGENT_CAPABILITIES:
            connector = await self._get_platform_connector(db, platform)
            status[platform] = {
                "available": connector is not None,
                "connector_id": connector.id if connector else None,
                "capabilities": self.AGENT_CAPABILITIES[platform],
                "status": connector.status.value if connector else "unavailable"
            }
        return status

multi_agent_coordinator = MultiAgentCoordinator()

# API Endpoints
@router.post("/execute")
async def execute_agent_task(task: AgentTask, db: AsyncSession = Depends(get_db)):
    """Execute single agent task"""
    result = await multi_agent_coordinator.execute_task(db, task)
    return result.dict()

@router.post("/execute-parallel")
async def execute_parallel_tasks(tasks: List[AgentTask], db: AsyncSession = Depends(get_db)):
    """Execute multiple agent tasks in parallel"""
    results = await multi_agent_coordinator.execute_parallel(db, tasks)
    return {"results": [r.dict() for r in results]}

@router.get("/platforms")
async def get_agent_platforms(db: AsyncSession = Depends(get_db)):
    """Get all available agent platforms"""
    return await multi_agent_coordinator.get_platform_status(db)

@router.post("/route")
async def route_task(task: AgentTask, db: AsyncSession = Depends(get_db)):
    """Get routing decision for task"""
    platform = await multi_agent_coordinator.route_task(db, task)
    return {"task_id": task.task_id, "routed_to": platform, "reason": "capability_match"}
