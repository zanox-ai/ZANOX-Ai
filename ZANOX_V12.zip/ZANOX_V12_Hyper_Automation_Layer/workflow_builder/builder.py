"""ZANOX V12 Workflow Builder - Drag-and-Drop Workflow Builder"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime
import uuid
import logging

from shared.database import get_db
from workflow_composer.composer import workflow_composer

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v12/workflow-builder", tags=["Workflow Builder"])

class BuilderCanvas(BaseModel):
    """Builder canvas state"""
    name: str
    nodes: List[Dict[str, Any]]
    edges: List[Dict[str, Any]]
    variables: Dict[str, Any] = {}

class WorkflowBuilder:
    """Drag-and-drop workflow builder"""

    async def validate_canvas(self, canvas: BuilderCanvas) -> Dict[str, Any]:
        """Validate canvas configuration"""
        errors = []
        warnings = []

        # Check for disconnected nodes
        node_ids = {n.get("id") for n in canvas.nodes}
        connected_ids = set()

        for edge in canvas.edges:
            connected_ids.add(edge.get("from"))
            connected_ids.add(edge.get("to"))

        disconnected = node_ids - connected_ids
        if disconnected and len(canvas.nodes) > 1:
            warnings.append(f"Disconnected nodes: {disconnected}")

        # Check for cycles
        # Simplified cycle detection

        # Check for missing required configs
        for node in canvas.nodes:
            node_type = node.get("type")
            config = node.get("config", {})

            if node_type == "ai_call" and not config.get("platform"):
                warnings.append(f"Node {node.get('id')}: AI platform not specified")

            if node_type == "api_call" and not config.get("connector_id"):
                warnings.append(f"Node {node.get('id')}: Connector not specified")

        return {
            "valid": len(errors) == 0,
            "errors": errors,
            "warnings": warnings,
            "node_count": len(canvas.nodes),
            "edge_count": len(canvas.edges)
        }

    async def build(self, db: AsyncSession, canvas: BuilderCanvas) -> Dict[str, Any]:
        """Build workflow from canvas"""
        validation = await self.validate_canvas(canvas)

        if not validation["valid"]:
            raise HTTPException(status_code=400, detail=validation["errors"])

        result = await workflow_composer.compose_workflow(
            db, canvas.name, canvas.nodes, canvas.edges
        )

        return {
            **result,
            "validation": validation
        }

builder = WorkflowBuilder()

@router.post("/validate")
async def validate_canvas(canvas: BuilderCanvas):
    """Validate canvas"""
    return await builder.validate_canvas(canvas)

@router.post("/build")
async def build_workflow(canvas: BuilderCanvas, db: AsyncSession = Depends(get_db)):
    """Build workflow from canvas"""
    return await builder.build(db, canvas)
