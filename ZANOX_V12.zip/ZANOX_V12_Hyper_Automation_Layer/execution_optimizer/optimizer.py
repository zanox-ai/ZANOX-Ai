"""ZANOX V12 Execution Optimizer - Runtime Optimization"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime, timedelta
import uuid
import logging

from shared.database import get_db
from shared.models import WorkflowExecution, TaskRecord, CostRecord
from shared.redis_client import redis_client
from shared.config import config

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v12/execution-optimizer", tags=["Execution Optimizer"])

class OptimizationResult(BaseModel):
    """Result of optimization analysis"""
    execution_id: str
    optimizations_applied: List[str]
    cost_savings_usd: float
    time_savings_ms: int
    recommendations: List[Dict[str, Any]]

class ExecutionOptimizer:
    """Optimizes workflow execution in real-time"""

    async def analyze_execution(self, db: AsyncSession, execution_id: str) -> OptimizationResult:
        """Analyze execution for optimization opportunities"""
        execution = await db.get(WorkflowExecution, execution_id)
        if not execution:
            raise HTTPException(status_code=404, detail="Execution not found")

        optimizations = []
        cost_savings = 0.0
        time_savings = 0
        recommendations = []

        # Get all tasks
        result = await db.execute(
            select(TaskRecord).where(TaskRecord.execution_id == execution_id)
        )
        tasks = result.scalars().all()

        # Analyze task patterns
        task_types = {}
        for task in tasks:
            if task.task_type not in task_types:
                task_types[task.task_type] = []
            task_types[task.task_type].append(task)

        # Check for batching opportunities
        for task_type, task_list in task_types.items():
            if len(task_list) > 3 and task_type in ["ai_call", "api_call"]:
                optimizations.append("batch_tasks")
                recommendations.append({
                    "type": "batching",
                    "task_type": task_type,
                    "suggestion": f"Batch {len(task_list)} {task_type} tasks into single request",
                    "estimated_savings": len(task_list) * 0.01
                })
                cost_savings += len(task_list) * 0.01

        # Check for parallelization opportunities
        sequential_tasks = [t for t in tasks if t.duration_ms and t.duration_ms > 5000]
        if len(sequential_tasks) > 2:
            optimizations.append("parallelize")
            recommendations.append({
                "type": "parallelization",
                "suggestion": "Tasks can be parallelized to reduce total execution time",
                "estimated_time_savings": sum(t.duration_ms for t in sequential_tasks) * 0.5
            })
            time_savings += int(sum(t.duration_ms for t in sequential_tasks) * 0.5)

        # Check for caching opportunities
        repeated_tasks = [t for t in tasks if t.task_type == "api_call" and t.input_data]
        if len(repeated_tasks) > 2:
            optimizations.append("enable_caching")
            recommendations.append({
                "type": "caching",
                "suggestion": "Enable response caching for repeated API calls",
                "estimated_savings": len(repeated_tasks) * 0.005
            })
            cost_savings += len(repeated_tasks) * 0.005

        # Check for platform optimization
        cost_result = await db.execute(
            select(CostRecord)
            .where(CostRecord.execution_id == execution_id)
        )
        costs = cost_result.scalars().all()

        high_cost_platforms = [c for c in costs if c.cost_usd > 0.1]
        if high_cost_platforms:
            optimizations.append("platform_switch")
            for cost in high_cost_platforms:
                recommendations.append({
                    "type": "platform_switch",
                    "platform": cost.platform,
                    "suggestion": f"Consider cheaper alternative to {cost.platform}",
                    "estimated_savings": cost.cost_usd * 0.3
                })
                cost_savings += cost.cost_usd * 0.3

        return OptimizationResult(
            execution_id=execution_id,
            optimizations_applied=optimizations,
            cost_savings_usd=round(cost_savings, 4),
            time_savings_ms=time_savings,
            recommendations=recommendations
        )

    async def optimize_workflow_definition(self, db: AsyncSession, 
                                           workflow_id: str) -> Dict[str, Any]:
        """Optimize workflow definition for better performance"""
        from shared.models import WorkflowDefinition

        workflow = await db.get(WorkflowDefinition, workflow_id)
        if not workflow:
            raise HTTPException(status_code=404, detail="Workflow not found")

        definition = workflow.definition
        optimizations = []

        # Check for redundant nodes
        nodes = definition.get("nodes", [])
        node_types = {}
        for node in nodes:
            node_types[node.get("task_type", "unknown")] = node_types.get(node.get("task_type"), 0) + 1

        # Suggest merging similar tasks
        for task_type, count in node_types.items():
            if count > 3:
                optimizations.append({
                    "type": "merge",
                    "task_type": task_type,
                    "suggestion": f"Consider merging {count} {task_type} tasks",
                    "impact": "high"
                })

        # Check for missing error handling
        for node in nodes:
            if node.get("on_failure", "fail") == "fail" and node.get("retry_count", 0) == 0:
                optimizations.append({
                    "type": "error_handling",
                    "node_id": node.get("id"),
                    "suggestion": "Add retry logic or fallback for this task",
                    "impact": "medium"
                })

        return {
            "workflow_id": workflow_id,
            "optimizations": optimizations,
            "optimized_definition": definition  # Could return modified definition
        }

execution_optimizer = ExecutionOptimizer()

# API Endpoints
@router.get("/analyze/{execution_id}")
async def analyze_execution(execution_id: str, db: AsyncSession = Depends(get_db)):
    """Analyze execution for optimizations"""
    return await execution_optimizer.analyze_execution(db, execution_id)

@router.get("/optimize-workflow/{workflow_id}")
async def optimize_workflow(workflow_id: str, db: AsyncSession = Depends(get_db)):
    """Optimize workflow definition"""
    return await execution_optimizer.optimize_workflow_definition(db, workflow_id)
