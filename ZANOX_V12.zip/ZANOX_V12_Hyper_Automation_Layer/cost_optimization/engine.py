"""ZANOX V12 Cost Optimization Engine - Budget Management"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_, between
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime, timedelta
import uuid
import logging

from shared.database import get_db
from shared.models import CostRecord, WorkflowExecution, TaskRecord
from shared.config import config
from shared.redis_client import redis_client

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v12/cost-optimization", tags=["Cost Optimization"])

class CostBudget(BaseModel):
    """Cost budget configuration"""
    daily_limit: float = Field(default=100.0, gt=0)
    alert_threshold: float = Field(default=0.8, ge=0, le=1)
    platform_limits: Optional[Dict[str, float]] = {}

class CostReport(BaseModel):
    """Cost report"""
    period: str
    total_cost: float
    by_platform: Dict[str, float]
    by_workflow: Dict[str, float]
    budget_utilization: float
    alerts: List[str]

class CostOptimizationEngine:
    """Manages cost optimization and budget enforcement"""

    async def get_daily_cost(self, db: AsyncSession, date: Optional[datetime] = None) -> float:
        """Get total cost for a day"""
        if not date:
            date = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)

        next_day = date + timedelta(days=1)

        result = await db.execute(
            select(func.sum(CostRecord.cost_usd))
            .where(CostRecord.created_at >= date)
            .where(CostRecord.created_at < next_day)
        )
        return result.scalar() or 0.0

    async def check_budget(self, db: AsyncSession) -> Dict[str, Any]:
        """Check current budget status"""
        today_cost = await self.get_daily_cost(db)
        budget = config.COST_BUDGET_DAILY_USD
        threshold = config.COST_ALERT_THRESHOLD

        utilization = today_cost / budget if budget > 0 else 0

        alerts = []
        if utilization >= threshold:
            alerts.append(f"Budget alert: {utilization*100:.1f}% of daily budget used")
        if utilization >= 1.0:
            alerts.append("CRITICAL: Daily budget exceeded")

        return {
            "daily_budget": budget,
            "today_cost": round(today_cost, 4),
            "utilization": round(utilization, 4),
            "remaining": round(budget - today_cost, 4),
            "alerts": alerts,
            "status": "critical" if utilization >= 1.0 else "warning" if utilization >= threshold else "ok"
        }

    async def get_cost_report(self, db: AsyncSession, 
                              start_date: datetime, 
                              end_date: datetime) -> CostReport:
        """Generate detailed cost report"""
        # Total cost
        total_result = await db.execute(
            select(func.sum(CostRecord.cost_usd))
            .where(CostRecord.created_at >= start_date)
            .where(CostRecord.created_at <= end_date)
        )
        total = total_result.scalar() or 0.0

        # By platform
        platform_result = await db.execute(
            select(CostRecord.platform, func.sum(CostRecord.cost_usd))
            .where(CostRecord.created_at >= start_date)
            .where(CostRecord.created_at <= end_date)
            .group_by(CostRecord.platform)
        )
        by_platform = {p: round(c, 4) for p, c in platform_result.all()}

        # By workflow
        workflow_result = await db.execute(
            select(CostRecord.execution_id, func.sum(CostRecord.cost_usd))
            .where(CostRecord.created_at >= start_date)
            .where(CostRecord.created_at <= end_date)
            .group_by(CostRecord.execution_id)
        )
        by_workflow = {str(e): round(c, 4) for e, c in workflow_result.all()}

        # Budget utilization
        days = (end_date - start_date).days or 1
        budget = config.COST_BUDGET_DAILY_USD * days
        utilization = total / budget if budget > 0 else 0

        # Check for alerts
        alerts = []
        if utilization > config.COST_ALERT_THRESHOLD:
            alerts.append(f"Budget utilization: {utilization*100:.1f}%")

        for platform, cost in by_platform.items():
            if cost > budget * 0.5:
                alerts.append(f"High cost on {platform}: ${cost:.4f}")

        return CostReport(
            period=f"{start_date.date()} to {end_date.date()}",
            total_cost=round(total, 4),
            by_platform=by_platform,
            by_workflow=by_workflow,
            budget_utilization=round(utilization, 4),
            alerts=alerts
        )

    async def optimize_cost(self, db: AsyncSession, execution_id: str) -> Dict[str, Any]:
        """Apply cost optimizations to execution"""
        # Get execution costs
        result = await db.execute(
            select(CostRecord)
            .where(CostRecord.execution_id == execution_id)
        )
        costs = result.scalars().all()

        optimizations = []
        total_savings = 0.0

        for cost in costs:
            if cost.cost_usd > 0.05 and cost.platform in ["chatgpt", "claude"]:
                # Suggest cheaper model
                optimizations.append({
                    "type": "model_downgrade",
                    "platform": cost.platform,
                    "current_cost": cost.cost_usd,
                    "suggested_cost": cost.cost_usd * 0.5,
                    "savings": cost.cost_usd * 0.5
                })
                total_savings += cost.cost_usd * 0.5

            if cost.tokens_input and cost.tokens_input > 4000:
                optimizations.append({
                    "type": "context_compression",
                    "platform": cost.platform,
                    "tokens_input": cost.tokens_input,
                    "suggestion": "Compress context to reduce token usage",
                    "savings": (cost.tokens_input - 2000) / 1000 * 0.003
                })
                total_savings += (cost.tokens_input - 2000) / 1000 * 0.003

        return {
            "execution_id": execution_id,
            "optimizations": optimizations,
            "total_savings": round(total_savings, 4),
            "current_cost": round(sum(c.cost_usd for c in costs), 4)
        }

    async def enforce_budget(self, db: AsyncSession, estimated_cost: float) -> bool:
        """Check if execution is within budget"""
        current = await self.get_daily_cost(db)
        budget = config.COST_BUDGET_DAILY_USD

        if current + estimated_cost > budget:
            logger.warning(f"Budget enforcement: {current + estimated_cost} > {budget}")
            return False
        return True

cost_optimizer = CostOptimizationEngine()

# API Endpoints
@router.get("/budget")
async def check_budget(db: AsyncSession = Depends(get_db)):
    """Check current budget status"""
    return await cost_optimizer.check_budget(db)

@router.get("/report")
async def get_cost_report(
    days: int = 7,
    db: AsyncSession = Depends(get_db)
):
    """Get cost report for period"""
    end = datetime.utcnow()
    start = end - timedelta(days=days)
    report = await cost_optimizer.get_cost_report(db, start, end)
    return report.dict()

@router.get("/optimize/{execution_id}")
async def optimize_execution_cost(execution_id: str, db: AsyncSession = Depends(get_db)):
    """Get cost optimization suggestions"""
    return await cost_optimizer.optimize_cost(db, execution_id)

@router.post("/enforce")
async def enforce_budget_check(estimated_cost: float, db: AsyncSession = Depends(get_db)):
    """Check if execution is within budget"""
    allowed = await cost_optimizer.enforce_budget(db, estimated_cost)
    return {"allowed": allowed, "estimated_cost": estimated_cost}
