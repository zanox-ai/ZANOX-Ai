"""ZANOX V12 Governance Layer - Integration Governance Controls"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, or_
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime
import uuid
import logging

from shared.database import get_db
from shared.models import GovernancePolicy, WorkflowExecution, CostRecord
from shared.config import config

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v12/governance", tags=["Governance"])

class PolicyCreate(BaseModel):
    """Create governance policy"""
    name: str
    policy_type: str  # access, data, workflow, cost
    rules: Dict[str, Any]
    scope: str = "global"
    target_id: Optional[str] = None
    enforcement_mode: str = "enforce"  # enforce, audit, warn

class GovernanceEngine:
    """Manages governance policies and enforcement"""

    async def create_policy(self, db: AsyncSession, data: PolicyCreate) -> GovernancePolicy:
        """Create governance policy"""
        policy = GovernancePolicy(
            id=str(uuid.uuid4()),
            name=data.name,
            policy_type=data.policy_type,
            rules=data.rules,
            scope=data.scope,
            target_id=data.target_id,
            enforcement_mode=data.enforcement_mode
        )
        db.add(policy)
        await db.commit()
        await db.refresh(policy)
        return policy

    async def enforce_policy(self, db: AsyncSession, policy_id: str,
                            context: Dict[str, Any]) -> Dict[str, Any]:
        """Enforce policy against context"""
        policy = await db.get(GovernancePolicy, policy_id)
        if not policy or not policy.is_active:
            return {"allowed": True, "reason": "No active policy"}

        rules = policy.rules
        violations = []

        # Check access rules
        if policy.policy_type == "access":
            required_role = rules.get("required_role")
            if required_role and context.get("user_role") != required_role:
                violations.append(f"Required role: {required_role}")

        # Check cost rules
        elif policy.policy_type == "cost":
            max_cost = rules.get("max_cost_usd")
            if max_cost and context.get("estimated_cost", 0) > max_cost:
                violations.append(f"Cost exceeds limit: ${max_cost}")

        # Check workflow rules
        elif policy.policy_type == "workflow":
            allowed_platforms = rules.get("allowed_platforms", [])
            if allowed_platforms and context.get("platform") not in allowed_platforms:
                violations.append(f"Platform not allowed: {context.get('platform')}")

        # Check data rules
        elif policy.policy_type == "data":
            required_encryption = rules.get("encryption_required", False)
            if required_encryption and not context.get("encrypted"):
                violations.append("Encryption required")

        allowed = len(violations) == 0

        if not allowed and policy.enforcement_mode == "enforce":
            return {"allowed": False, "violations": violations, "action": "blocked"}
        elif not allowed and policy.enforcement_mode == "warn":
            return {"allowed": True, "violations": violations, "action": "warning"}
        elif not allowed and policy.enforcement_mode == "audit":
            return {"allowed": True, "violations": violations, "action": "audited"}

        return {"allowed": True, "violations": []}

    async def get_policies(self, db: AsyncSession, 
                          policy_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get all policies"""
        query = select(GovernancePolicy)
        if policy_type:
            query = query.where(GovernancePolicy.policy_type == policy_type)

        result = await db.execute(query)
        policies = result.scalars().all()

        return [
            {
                "id": p.id,
                "name": p.name,
                "policy_type": p.policy_type,
                "scope": p.scope,
                "is_active": p.is_active,
                "enforcement_mode": p.enforcement_mode,
                "created_at": p.created_at.isoformat() if p.created_at else None
            }
            for p in policies
        ]

governance_engine = GovernanceEngine()

@router.post("/policies")
async def create_policy(data: PolicyCreate, db: AsyncSession = Depends(get_db)):
    """Create governance policy"""
    policy = await governance_engine.create_policy(db, data)
    return {"id": policy.id, "name": policy.name, "status": "created"}

@router.post("/enforce/{policy_id}")
async def enforce_policy(
    policy_id: str,
    context: Dict[str, Any],
    db: AsyncSession = Depends(get_db)
):
    """Enforce policy"""
    return await governance_engine.enforce_policy(db, policy_id, context)

@router.get("/policies")
async def get_policies(
    policy_type: Optional[str] = None,
    db: AsyncSession = Depends(get_db)
):
    """Get policies"""
    return await governance_engine.get_policies(db, policy_type)
