"""ZANOX V12 Compliance Layer - Integration Compliance Controls"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, or_
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime, timedelta
import uuid
import logging

from shared.database import get_db
from shared.models import ComplianceRecord, AuditLog
from shared.config import config

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v12/compliance", tags=["Compliance"])

class ComplianceAssessment(BaseModel):
    """Compliance assessment"""
    standard: str  # GDPR, SOC2, HIPAA, ISO27001
    control_id: str
    control_name: str
    status: str  # compliant, non_compliant, partial, not_applicable
    evidence: Optional[Dict[str, Any]] = None
    assessor: str
    findings: Optional[List[str]] = None

class ComplianceEngine:
    """Manages compliance assessments and reporting"""

    COMPLIANCE_STANDARDS = {
        "GDPR": ["data_minimization", "purpose_limitation", "storage_limitation", 
                 "accuracy", "integrity_confidentiality", "accountability"],
        "SOC2": ["security", "availability", "processing_integrity", 
                 "confidentiality", "privacy"],
        "HIPAA": ["administrative_safeguards", "physical_safeguards", 
                  "technical_safeguards", "audit_controls"],
        "ISO27001": ["information_security_policies", "organization_of_security",
                     "asset_management", "access_control", "cryptography",
                     "physical_security", "operations_security", "communications_security",
                     "system_acquisition", "supplier_relationships", "incident_management",
                     "business_continuity", "compliance"]
    }

    async def assess_control(self, db: AsyncSession, 
                            assessment: ComplianceAssessment) -> ComplianceRecord:
        """Record compliance assessment"""
        record = ComplianceRecord(
            id=str(uuid.uuid4()),
            standard=assessment.standard,
            control_id=assessment.control_id,
            control_name=assessment.control_name,
            status=assessment.status,
            evidence=assessment.evidence,
            assessed_at=datetime.utcnow(),
            assessor=assessment.assessor,
            findings=assessment.findings,
            next_assessment=datetime.utcnow() + timedelta(days=90)
        )
        db.add(record)
        await db.commit()
        await db.refresh(record)
        return record

    async def get_compliance_status(self, db: AsyncSession, 
                                    standard: Optional[str] = None) -> Dict[str, Any]:
        """Get compliance status"""
        query = select(ComplianceRecord)
        if standard:
            query = query.where(ComplianceRecord.standard == standard)

        result = await db.execute(query)
        records = result.scalars().all()

        status_counts = {}
        for record in records:
            if record.standard not in status_counts:
                status_counts[record.standard] = {}
            status_counts[record.standard][record.status] =                 status_counts[record.standard].get(record.status, 0) + 1

        return {
            "standards": list(self.COMPLIANCE_STANDARDS.keys()),
            "status": status_counts,
            "total_assessments": len(records),
            "last_updated": datetime.utcnow().isoformat()
        }

    async def generate_report(self, db: AsyncSession, 
                             standard: str) -> Dict[str, Any]:
        """Generate compliance report"""
        result = await db.execute(
            select(ComplianceRecord)
            .where(ComplianceRecord.standard == standard)
        )
        records = result.scalars().all()

        controls = self.COMPLIANCE_STANDARDS.get(standard, [])
        assessed_controls = {r.control_id for r in records}
        missing_controls = [c for c in controls if c not in assessed_controls]

        compliant = sum(1 for r in records if r.status == "compliant")
        non_compliant = sum(1 for r in records if r.status == "non_compliant")
        partial = sum(1 for r in records if r.status == "partial")

        return {
            "standard": standard,
            "total_controls": len(controls),
            "assessed": len(records),
            "missing": missing_controls,
            "compliant": compliant,
            "non_compliant": non_compliant,
            "partial": partial,
            "compliance_rate": round(compliant / max(len(controls), 1) * 100, 2),
            "generated_at": datetime.utcnow().isoformat()
        }

compliance_engine = ComplianceEngine()

@router.post("/assess")
async def assess_control(assessment: ComplianceAssessment, db: AsyncSession = Depends(get_db)):
    """Record compliance assessment"""
    record = await compliance_engine.assess_control(db, assessment)
    return {"id": record.id, "status": "recorded"}

@router.get("/status")
async def get_compliance_status(
    standard: Optional[str] = None,
    db: AsyncSession = Depends(get_db)
):
    """Get compliance status"""
    return await compliance_engine.get_compliance_status(db, standard)

@router.get("/report/{standard}")
async def generate_report(standard: str, db: AsyncSession = Depends(get_db)):
    """Generate compliance report"""
    return await compliance_engine.generate_report(db, standard)
