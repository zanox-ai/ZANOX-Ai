"""ZANOX V12 Automation Engine - Core Workflow Execution"""
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, and_, or_
from typing import List, Optional, Dict, Any, Callable
from pydantic import BaseModel, Field
from datetime import datetime, timedelta
import uuid
import logging
import asyncio
import json

from shared.database import get_db
from shared.models import (
    WorkflowDefinition, WorkflowExecution, WorkflowStatus,
    TaskRecord, TaskStatus, ConnectorRegistry, EventRecord
)
from shared.redis_client import redis_client
from shared.config import config

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v12/automation", tags=["Automation Engine"])

class TaskNode(BaseModel):
    """Represents a single task in a workflow"""
    id: str
    name: str
    task_type: str  # ai_call, api_call, automation_trigger, agent_task, builder_deploy, condition, loop, wait
    platform: Optional[str] = None
    connector_id: Optional[str] = None
    config: Dict[str, Any] = {}
    inputs: Dict[str, Any] = {}
    outputs: Dict[str, Any] = {}
    dependencies: List[str] = []
    retry_count: int = 0
    max_retries: int = 3
    timeout_seconds: int = 300
    on_failure: str = "fail"  # fail, retry, skip, alternate
    condition: Optional[str] = None  # Python expression for conditional execution

class WorkflowGraph(BaseModel):
    """Complete workflow definition graph"""
    nodes: List[TaskNode]
    edges: List[Dict[str, str]]  # [{"from": "node1", "to": "node2"}]
    variables: Dict[str, Any] = {}
    triggers: List[Dict[str, Any]] = []

class ExecutionContext(BaseModel):
    """Runtime context for workflow execution"""
    execution_id: str
    workflow_id: str
    variables: Dict[str, Any] = {}
    outputs: Dict[str, Any] = {}
    task_results: Dict[str, Any] = {}
    metadata: Dict[str, Any] = {}
    started_at: datetime = Field(default_factory=datetime.utcnow)
    current_task: Optional[str] = None

class AutomationEngine:
    """Core automation engine for executing workflows end-to-end"""

    def __init__(self):
        self._executions: Dict[str, ExecutionContext] = {}
        self._task_handlers: Dict[str, Callable] = {}
        self._register_default_handlers()

    def _register_default_handlers(self):
        """Register all task type handlers"""
        self._task_handlers = {
            "ai_call": self._handle_ai_call,
            "api_call": self._handle_api_call,
            "automation_trigger": self._handle_automation_trigger,
            "agent_task": self._handle_agent_task,
            "builder_deploy": self._handle_builder_deploy,
            "condition": self._handle_condition,
            "loop": self._handle_loop,
            "wait": self._handle_wait,
            "transform": self._handle_transform,
            "notify": self._handle_notify,
            "webhook": self._handle_webhook,
            "memory_sync": self._handle_memory_sync,
            "context_sync": self._handle_context_sync,
        }

    async def _handle_ai_call(self, task: TaskNode, context: ExecutionContext, db: AsyncSession) -> Dict[str, Any]:
        """Execute AI model call through connector"""
        from connector_registry.registry import connector_manager

        platform = task.platform or task.config.get("platform", "openrouter")
        connector_id = task.connector_id or task.config.get("connector_id")

        if not connector_id:
            # Find connector for platform
            result = await db.execute(
                select(ConnectorRegistry)
                .join(ConnectorRegistry.integration)
                .where(ConnectorRegistry.integration.has(provider=platform))
                .where(ConnectorRegistry.status == "active")
            )
            connector = result.scalar_one_or_none()
            if connector:
                connector_id = connector.id

        if connector_id:
            payload = {
                "model": task.config.get("model", "default"),
                "messages": task.config.get("messages", []),
                "temperature": task.config.get("temperature", 0.7),
                "max_tokens": task.config.get("max_tokens", 2000)
            }
            result = await connector_manager.execute_connector(db, connector_id, "POST", "chat/completions", payload)
            return result

        return {"success": False, "error": "No connector found for AI platform"}

    async def _handle_api_call(self, task: TaskNode, context: ExecutionContext, db: AsyncSession) -> Dict[str, Any]:
        """Execute generic API call through connector"""
        from connector_registry.registry import connector_manager

        connector_id = task.connector_id or task.config.get("connector_id")
        if not connector_id:
            return {"success": False, "error": "No connector specified"}

        method = task.config.get("method", "GET")
        path = task.config.get("path", "")
        payload = task.config.get("body", task.config.get("payload"))

        result = await connector_manager.execute_connector(db, connector_id, method, path, payload)
        return result

    async def _handle_automation_trigger(self, task: TaskNode, context: ExecutionContext, db: AsyncSession) -> Dict[str, Any]:
        """Trigger external automation platform workflow"""
        from connector_registry.registry import connector_manager

        platform = task.platform or task.config.get("platform", "n8n")
        connector_id = task.connector_id

        if not connector_id:
            return {"success": False, "error": "No connector for automation platform"}

        payload = {
            "workflow_id": task.config.get("workflow_id"),
            "payload": task.config.get("payload", {}),
            "trigger_data": context.variables
        }

        result = await connector_manager.execute_connector(db, connector_id, "POST", "webhook/trigger", payload)
        return result

    async def _handle_agent_task(self, task: TaskNode, context: ExecutionContext, db: AsyncSession) -> Dict[str, Any]:
        """Delegate task to agent platform"""
        from connector_registry.registry import connector_manager

        platform = task.platform or task.config.get("platform", "crewai")
        connector_id = task.connector_id

        if not connector_id:
            return {"success": False, "error": "No connector for agent platform"}

        payload = {
            "task": task.config.get("task_description", ""),
            "agents": task.config.get("agents", []),
            "tools": task.config.get("tools", []),
            "context": context.variables
        }

        result = await connector_manager.execute_connector(db, connector_id, "POST", "execute", payload)
        return result

    async def _handle_builder_deploy(self, task: TaskNode, context: ExecutionContext, db: AsyncSession) -> Dict[str, Any]:
        """Deploy or update builder platform project"""
        from connector_registry.registry import connector_manager

        platform = task.platform or task.config.get("platform", "replit")
        connector_id = task.connector_id

        if not connector_id:
            return {"success": False, "error": "No connector for builder platform"}

        payload = {
            "project_name": task.config.get("project_name"),
            "template": task.config.get("template"),
            "code": task.config.get("code"),
            "config": task.config.get("config", {})
        }

        result = await connector_manager.execute_connector(db, connector_id, "POST", "deploy", payload)
        return result

    async def _handle_condition(self, task: TaskNode, context: ExecutionContext, db: AsyncSession) -> Dict[str, Any]:
        """Evaluate condition and branch"""
        condition = task.condition or task.config.get("condition", "True")

        # Safe evaluation with context variables
        safe_globals = {"__builtins__": {}}
        safe_locals = {**context.variables, **context.task_results}

        try:
            result = eval(condition, safe_globals, safe_locals)
            return {"success": True, "result": bool(result), "condition": condition}
        except Exception as e:
            return {"success": False, "error": f"Condition evaluation failed: {str(e)}"}

    async def _handle_loop(self, task: TaskNode, context: ExecutionContext, db: AsyncSession) -> Dict[str, Any]:
        """Execute loop over collection"""
        items = task.config.get("items", [])
        sub_tasks = task.config.get("tasks", [])
        results = []

        for item in items:
            context.variables["loop_item"] = item
            context.variables["loop_index"] = items.index(item)

            for sub_task_data in sub_tasks:
                sub_task = TaskNode(**sub_task_data)
                handler = self._task_handlers.get(sub_task.task_type)
                if handler:
                    sub_result = await handler(sub_task, context, db)
                    results.append(sub_result)

        return {"success": True, "iterations": len(items), "results": results}

    async def _handle_wait(self, task: TaskNode, context: ExecutionContext, db: AsyncSession) -> Dict[str, Any]:
        """Wait for specified duration or event"""
        duration = task.config.get("duration_seconds", 1)
        event_type = task.config.get("event_type")

        if event_type:
            # Wait for specific event
            timeout = task.config.get("timeout_seconds", 300)
            start = datetime.utcnow()
            while (datetime.utcnow() - start).seconds < timeout:
                # Check event bus
                event = await db.execute(
                    select(EventRecord)
                    .where(EventRecord.event_type == event_type)
                    .where(EventRecord.processed == False)
                )
                if event.scalar_one_or_none():
                    return {"success": True, "event_received": True}
                await asyncio.sleep(1)
            return {"success": False, "error": "Wait timeout exceeded"}
        else:
            await asyncio.sleep(duration)
            return {"success": True, "waited_seconds": duration}

    async def _handle_transform(self, task: TaskNode, context: ExecutionContext, db: AsyncSession) -> Dict[str, Any]:
        """Transform data using mapping or script"""
        mapping = task.config.get("mapping", {})
        input_data = task.config.get("input", context.variables)

        result = {}
        for key, value in mapping.items():
            if isinstance(value, str) and value.startswith("$"):
                # JSONPath-like reference
                path = value[1:].split(".")
                current = input_data
                for p in path:
                    current = current.get(p, {}) if isinstance(current, dict) else {}
                result[key] = current
            else:
                result[key] = value

        return {"success": True, "transformed": result}

    async def _handle_notify(self, task: TaskNode, context: ExecutionContext, db: AsyncSession) -> Dict[str, Any]:
        """Send notification"""
        channel = task.config.get("channel", "webhook")
        message = task.config.get("message", "")

        # Format message with context variables
        formatted = message
        for key, value in {**context.variables, **context.task_results}.items():
            formatted = formatted.replace(f"{{{key}}}", str(value))

        # Store notification in event bus
        event = EventRecord(
            id=str(uuid.uuid4()),
            event_type="notification",
            source="automation_engine",
            target=channel,
            payload={"message": formatted, "channel": channel},
            correlation_id=context.execution_id
        )
        db.add(event)
        await db.commit()

        return {"success": True, "channel": channel, "message": formatted}

    async def _handle_webhook(self, task: TaskNode, context: ExecutionContext, db: AsyncSession) -> Dict[str, Any]:
        """Send webhook"""
        url = task.config.get("url", "")
        method = task.config.get("method", "POST")
        headers = task.config.get("headers", {})
        payload = task.config.get("payload", context.variables)

        import httpx
        async with httpx.AsyncClient() as client:
            try:
                if method.upper() == "GET":
                    response = await client.get(url, headers=headers, params=payload)
                else:
                    response = await client.request(method.upper(), url, headers=headers, json=payload)

                return {
                    "success": response.status_code < 400,
                    "status_code": response.status_code,
                    "body": response.text[:1000]
                }
            except Exception as e:
                return {"success": False, "error": str(e)}

    async def _handle_memory_sync(self, task: TaskNode, context: ExecutionContext, db: AsyncSession) -> Dict[str, Any]:
        """Sync memory across platforms"""
        from memory_sync.sync import memory_sync_manager

        platform = task.platform or task.config.get("platform")
        key = task.config.get("key", "")
        value = task.config.get("value", context.variables)

        result = await memory_sync_manager.sync_memory(platform, key, value)
        return result

    async def _handle_context_sync(self, task: TaskNode, context: ExecutionContext, db: AsyncSession) -> Dict[str, Any]:
        """Sync context across platforms"""
        from context_sync.sync import context_sync_manager

        session_id = context.execution_id
        platform = task.platform or task.config.get("platform")
        context_data = task.config.get("context", context.variables)

        result = await context_sync_manager.sync_context(session_id, platform, context_data)
        return result

    async def execute_workflow(self, db: AsyncSession, workflow_id: str, 
                              trigger_data: Optional[Dict] = None,
                              variables: Optional[Dict] = None) -> str:
        """Execute a workflow definition"""
        # Get workflow
        workflow = await db.get(WorkflowDefinition, workflow_id)
        if not workflow:
            raise HTTPException(status_code=404, detail="Workflow not found")

        # Create execution record
        execution_id = str(uuid.uuid4())
        execution = WorkflowExecution(
            id=execution_id,
            workflow_id=workflow_id,
            status=WorkflowStatus.RUNNING,
            trigger_type="manual",
            trigger_data=trigger_data,
            context=variables or {},
            started_at=datetime.utcnow()
        )
        db.add(execution)
        await db.commit()

        # Create execution context
        ctx = ExecutionContext(
            execution_id=execution_id,
            workflow_id=workflow_id,
            variables=variables or {},
            metadata={"workflow_name": workflow.name}
        )
        self._executions[execution_id] = ctx

        # Parse workflow graph
        graph = WorkflowGraph(**workflow.definition)

        # Build dependency graph
        completed_tasks = set()
        failed_tasks = set()

        # Execute tasks in dependency order
        pending_tasks = [node for node in graph.nodes]

        try:
            while pending_tasks:
                # Find ready tasks (all dependencies completed)
                ready = []
                for task in pending_tasks:
                    if all(dep in completed_tasks for dep in task.dependencies):
                        ready.append(task)

                if not ready and pending_tasks:
                    # Circular dependency or missing dependency
                    raise Exception("Dependency resolution failed - possible circular dependency")

                for task in ready:
                    ctx.current_task = task.id

                    # Create task record
                    task_record = TaskRecord(
                        id=str(uuid.uuid4()),
                        execution_id=execution_id,
                        task_name=task.name,
                        task_type=task.task_type,
                        platform=task.platform,
                        connector_id=task.connector_id,
                        status=TaskStatus.RUNNING,
                        input_data=task.inputs,
                        started_at=datetime.utcnow()
                    )
                    db.add(task_record)
                    await db.commit()

                    # Execute task
                    handler = self._task_handlers.get(task.task_type)
                    if not handler:
                        task_record.status = TaskStatus.FAILED
                        task_record.error_data = {"error": f"Unknown task type: {task.task_type}"}
                        failed_tasks.add(task.id)
                    else:
                        try:
                            result = await asyncio.wait_for(
                                handler(task, ctx, db),
                                timeout=task.timeout_seconds
                            )

                            task_record.status = TaskStatus.COMPLETED if result.get("success") else TaskStatus.FAILED
                            task_record.output_data = result
                            task_record.completed_at = datetime.utcnow()
                            task_record.duration_ms = (task_record.completed_at - task_record.started_at).total_seconds() * 1000

                            if result.get("success"):
                                ctx.task_results[task.id] = result
                                completed_tasks.add(task.id)
                            else:
                                if task.on_failure == "retry" and task.retry_count < task.max_retries:
                                    task.retry_count += 1
                                    task_record.status = TaskStatus.RETRYING
                                    await asyncio.sleep(2 ** task.retry_count)
                                    continue  # Retry this task
                                failed_tasks.add(task.id)

                        except asyncio.TimeoutError:
                            task_record.status = TaskStatus.FAILED
                            task_record.error_data = {"error": "Task timeout"}
                            failed_tasks.add(task.id)
                        except Exception as e:
                            task_record.status = TaskStatus.FAILED
                            task_record.error_data = {"error": str(e)}
                            failed_tasks.add(task.id)

                    await db.commit()
                    pending_tasks.remove(task)

            # Update execution status
            execution.status = WorkflowStatus.COMPLETED if not failed_tasks else WorkflowStatus.FAILED
            execution.completed_at = datetime.utcnow()
            execution.duration_ms = (execution.completed_at - execution.started_at).total_seconds() * 1000
            execution.result = {
                "completed_tasks": list(completed_tasks),
                "failed_tasks": list(failed_tasks),
                "task_results": ctx.task_results
            }

            await db.commit()

            # Update workflow stats
            workflow.usage_count += 1
            await db.commit()

            logger.info(f"Workflow {workflow_id} execution {execution_id} completed: {execution.status}")

        except Exception as e:
            execution.status = WorkflowStatus.FAILED
            execution.error_message = str(e)
            execution.completed_at = datetime.utcnow()
            await db.commit()
            logger.error(f"Workflow execution failed: {e}")

        return execution_id

    async def get_execution_status(self, db: AsyncSession, execution_id: str) -> Dict[str, Any]:
        """Get execution status and results"""
        execution = await db.get(WorkflowExecution, execution_id)
        if not execution:
            raise HTTPException(status_code=404, detail="Execution not found")

        # Get tasks
        result = await db.execute(
            select(TaskRecord).where(TaskRecord.execution_id == execution_id)
        )
        tasks = result.scalars().all()

        return {
            "execution_id": execution_id,
            "workflow_id": execution.workflow_id,
            "status": execution.status.value,
            "started_at": execution.started_at.isoformat() if execution.started_at else None,
            "completed_at": execution.completed_at.isoformat() if execution.completed_at else None,
            "duration_ms": execution.duration_ms,
            "cost_usd": execution.cost_usd,
            "error_message": execution.error_message,
            "result": execution.result,
            "tasks": [
                {
                    "id": t.id,
                    "name": t.task_name,
                    "type": t.task_type,
                    "status": t.status.value,
                    "platform": t.platform,
                    "duration_ms": t.duration_ms,
                    "cost_usd": t.cost_usd
                }
                for t in tasks
            ]
        }

automation_engine = AutomationEngine()

# API Endpoints
@router.post("/execute/{workflow_id}")
async def execute_workflow(
    workflow_id: str,
    trigger_data: Optional[Dict] = None,
    variables: Optional[Dict] = None,
    background_tasks: BackgroundTasks = None,
    db: AsyncSession = Depends(get_db)
):
    """Execute a workflow"""
    execution_id = await automation_engine.execute_workflow(db, workflow_id, trigger_data, variables)
    return {
        "execution_id": execution_id,
        "status": "started",
        "message": "Workflow execution initiated"
    }

@router.get("/execution/{execution_id}")
async def get_execution(execution_id: str, db: AsyncSession = Depends(get_db)):
    """Get execution status"""
    return await automation_engine.get_execution_status(db, execution_id)

@router.post("/execution/{execution_id}/cancel")
async def cancel_execution(execution_id: str, db: AsyncSession = Depends(get_db)):
    """Cancel running execution"""
    execution = await db.get(WorkflowExecution, execution_id)
    if not execution:
        raise HTTPException(status_code=404, detail="Execution not found")

    if execution.status == WorkflowStatus.RUNNING:
        execution.status = WorkflowStatus.CANCELLED
        execution.completed_at = datetime.utcnow()
        await db.commit()

    return {"status": "cancelled", "execution_id": execution_id}
