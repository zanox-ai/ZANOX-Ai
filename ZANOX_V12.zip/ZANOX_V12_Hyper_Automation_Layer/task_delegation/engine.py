"""ZANOX V12 Task Delegation Engine - Smart Task Assignment"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime
import uuid
import logging

from shared.database import get_db
from shared.models import TaskRecord, TaskStatus, WorkflowExecution
from task_distribution.engine import task_distribution_engine, DistributionTask

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v12/task-delegation", tags=["Task Delegation"])

class DelegationRequest(BaseModel):
    """Request to delegate tasks"""
    execution_id: str
    tasks: List[DistributionTask]
    strategy: str = "auto"  # auto, cost_first, speed_first, reliability_first, round_robin
    fallback_enabled: bool = True

class DelegationResult(BaseModel):
    """Result of task delegation"""
    execution_id: str
    delegated_tasks: List[Dict[str, Any]]
    failed_tasks: List[Dict[str, Any]]
    strategy_used: str
    total_estimated_cost: float
    total_estimated_latency_ms: int

class TaskDelegationEngine:
    """Smart task delegation with fallback and retry strategies"""

    STRATEGIES = {
        "cost_first": lambda c, t: -task_distribution_engine._estimate_cost(c, t),
        "speed_first": lambda c, t: -(c.response_time_ms or 999999),
        "reliability_first": lambda c, t: -c.error_rate * 100 + (c.request_count / 1000),
        "round_robin": lambda c, t: 0  # Handled separately
    }

    async def delegate(self, db: AsyncSession, request: DelegationRequest) -> DelegationResult:
        """Delegate tasks according to strategy"""
        execution = await db.get(WorkflowExecution, request.execution_id)
        if not execution:
            raise HTTPException(status_code=404, detail="Execution not found")

        delegated = []
        failed = []
        total_cost = 0.0
        total_latency = 0

        for task in request.tasks:
            try:
                if request.strategy == "round_robin":
                    result = await task_distribution_engine.distribute(db, task)
                else:
                    # Custom strategy
                    connectors = await task_distribution_engine._get_available_connectors(
                        db, task.platform_type
                    )

                    if not connectors:
                        failed.append({"task_id": task.task_id, "reason": "No platforms available"})
                        continue

                    # Score based on strategy
                    scored = []
                    for connector in connectors:
                        score = await self.STRATEGIES[request.strategy](connector, task)
                        integration = await connector.awaitable_attrs.integration
                        scored.append((connector, integration.provider, score))

                    scored.sort(key=lambda x: x[2], reverse=True)
                    best = scored[0]

                    estimated_cost = await task_distribution_engine._estimate_cost(best[0], task)
                    estimated_latency = best[0].response_time_ms or 1000

                    result = DistributionResult(
                        task_id=task.task_id,
                        assigned_platform=best[1],
                        assigned_connector=best[0].id,
                        strategy=request.strategy,
                        estimated_cost=estimated_cost,
                        estimated_latency_ms=int(estimated_latency),
                        status="assigned"
                    )

                delegated.append(result.dict())
                total_cost += result.estimated_cost
                total_latency += result.estimated_latency_ms

                # Create task record
                task_record = TaskRecord(
                    id=str(uuid.uuid4()),
                    execution_id=request.execution_id,
                    task_name=task.task_type,
                    task_type=task.task_type,
                    platform=result.assigned_platform,
                    connector_id=result.assigned_connector,
                    status=TaskStatus.ASSIGNED,
                    input_data=task.payload,
                    assigned_to=result.assigned_platform
                )
                db.add(task_record)

            except Exception as e:
                failed.append({"task_id": task.task_id, "reason": str(e)})

                if request.fallback_enabled:
                    # Try fallback to any available platform
                    try:
                        fallback = await task_distribution_engine.distribute(db, task)
                        delegated.append({**fallback.dict(), "is_fallback": True})
                    except Exception:
                        pass

        await db.commit()

        return DelegationResult(
            execution_id=request.execution_id,
            delegated_tasks=delegated,
            failed_tasks=failed,
            strategy_used=request.strategy,
            total_estimated_cost=total_cost,
            total_estimated_latency_ms=total_latency
        )

    async def redelegate_failed(self, db: AsyncSession, execution_id: str) -> Dict[str, Any]:
        """Redelegate failed tasks to alternative platforms"""
        result = await db.execute(
            select(TaskRecord)
            .where(TaskRecord.execution_id == execution_id)
            .where(TaskRecord.status == TaskStatus.FAILED)
        )
        failed_tasks = result.scalars().all()

        if not failed_tasks:
            return {"message": "No failed tasks to redelegate"}

        redelegated = 0
        for task in failed_tasks:
            # Find alternative platform
            task_dist = DistributionTask(
                task_id=task.id,
                task_type=task.task_type,
                platform_type=task.platform or "ai"
            )

            try:
                new_assignment = await task_distribution_engine.distribute(db, task_dist)
                task.platform = new_assignment.assigned_platform
                task.connector_id = new_assignment.assigned_connector
                task.status = TaskStatus.PENDING
                task.retry_count += 1
                redelegated += 1
            except Exception as e:
                logger.warning(f"Redelegation failed for task {task.id}: {e}")

        await db.commit()
        return {"redelegated_count": redelegated, "execution_id": execution_id}

task_delegation_engine = TaskDelegationEngine()

# API Endpoints
@router.post("/delegate")
async def delegate_tasks(request: DelegationRequest, db: AsyncSession = Depends(get_db)):
    """Delegate tasks with strategy"""
    result = await task_delegation_engine.delegate(db, request)
    return result.dict()

@router.post("/redelegate/{execution_id}")
async def redelegate_failed(execution_id: str, db: AsyncSession = Depends(get_db)):
    """Redelegate failed tasks"""
    return await task_delegation_engine.redelegate_failed(db, execution_id)
