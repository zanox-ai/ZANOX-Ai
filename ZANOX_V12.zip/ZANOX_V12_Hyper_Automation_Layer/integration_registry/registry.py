"""ZANOX V12 Integration Registry - Universal Platform Registration"""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, delete, and_, or_
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime
import uuid
import logging

from shared.database import get_db
from shared.models import IntegrationRegistry, PlatformType
from shared.security import security_manager

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v12/integrations", tags=["Integration Registry"])

# Pydantic Models
class IntegrationCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    platform_type: PlatformType
    provider: str = Field(..., min_length=1, max_length=100)
    description: Optional[str] = None
    api_base_url: Optional[str] = None
    auth_type: Optional[str] = "api_key"
    config_schema: Optional[Dict[str, Any]] = {}
    capabilities: Optional[List[str]] = []
    rate_limits: Optional[Dict[str, Any]] = {}
    pricing_tier: Optional[str] = "free"

class IntegrationUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    api_base_url: Optional[str] = None
    auth_type: Optional[str] = None
    config_schema: Optional[Dict[str, Any]] = None
    capabilities: Optional[List[str]] = None
    rate_limits: Optional[Dict[str, Any]] = None
    pricing_tier: Optional[str] = None
    is_active: Optional[bool] = None

class IntegrationResponse(BaseModel):
    id: str
    name: str
    platform_type: str
    provider: str
    description: Optional[str]
    api_base_url: Optional[str]
    auth_type: Optional[str]
    capabilities: List[str]
    is_active: bool
    health_score: float
    created_at: datetime

# Pre-defined platform configurations
PLATFORM_CONFIGS = {
    # AI Systems
    "chatgpt": {"name": "OpenAI ChatGPT", "type": PlatformType.AI, "auth": "bearer", "url": "https://api.openai.com/v1"},
    "claude": {"name": "Anthropic Claude", "type": PlatformType.AI, "auth": "bearer", "url": "https://api.anthropic.com/v1"},
    "gemini": {"name": "Google Gemini", "type": PlatformType.AI, "auth": "api_key", "url": "https://generativelanguage.googleapis.com/v1"},
    "grok": {"name": "xAI Grok", "type": PlatformType.AI, "auth": "bearer", "url": "https://api.x.ai/v1"},
    "kimi": {"name": "Moonshot Kimi", "type": PlatformType.AI, "auth": "bearer", "url": "https://api.moonshot.cn/v1"},
    "perplexity": {"name": "Perplexity AI", "type": PlatformType.AI, "auth": "bearer", "url": "https://api.perplexity.ai"},
    "qwen": {"name": "Alibaba Qwen", "type": PlatformType.AI, "auth": "bearer", "url": "https://dashscope.aliyuncs.com/api/v1"},
    "copilot": {"name": "Microsoft Copilot", "type": PlatformType.AI, "auth": "oauth2", "url": "https://api.copilot.microsoft.com"},
    "manus": {"name": "Manus AI", "type": PlatformType.AI, "auth": "api_key", "url": "https://api.manus.im"},
    "deepseek": {"name": "DeepSeek", "type": PlatformType.AI, "auth": "bearer", "url": "https://api.deepseek.com/v1"},
    "mistral": {"name": "Mistral AI", "type": PlatformType.AI, "auth": "bearer", "url": "https://api.mistral.ai/v1"},
    "openrouter": {"name": "OpenRouter", "type": PlatformType.AI, "auth": "bearer", "url": "https://openrouter.ai/api/v1"},

    # Automation
    "n8n": {"name": "n8n", "type": PlatformType.AUTOMATION, "auth": "api_key", "url": "https://{instance}.n8n.cloud/api/v1"},
    "zapier": {"name": "Zapier", "type": PlatformType.AUTOMATION, "auth": "bearer", "url": "https://api.zapier.com/v1"},
    "make": {"name": "Make (Integromat)", "type": PlatformType.AUTOMATION, "auth": "api_key", "url": "https://us1.make.com/api/v2"},
    "activepieces": {"name": "Activepieces", "type": PlatformType.AUTOMATION, "auth": "bearer", "url": "https://cloud.activepieces.com/api/v1"},
    "pipedream": {"name": "Pipedream", "type": PlatformType.AUTOMATION, "auth": "bearer", "url": "https://api.pipedream.com/v1"},
    "windmill": {"name": "Windmill", "type": PlatformType.AUTOMATION, "auth": "bearer", "url": "https://app.windmill.dev/api"},
    "kestra": {"name": "Kestra", "type": PlatformType.AUTOMATION, "auth": "bearer", "url": "https://api.kestra.io/v1"},
    "temporal": {"name": "Temporal", "type": PlatformType.AUTOMATION, "auth": "api_key", "url": "https://{namespace}.tmprl.cloud/api/v1"},
    "node-red": {"name": "Node-RED", "type": PlatformType.AUTOMATION, "auth": "basic", "url": "http://{instance}:1880"},
    "huginn": {"name": "Huginn", "type": PlatformType.AUTOMATION, "auth": "basic", "url": "https://{instance}/api/v1"},

    # Agent Platforms
    "flowise": {"name": "Flowise", "type": PlatformType.AGENT, "auth": "api_key", "url": "https://{instance}.flowiseai.com/api/v1"},
    "langflow": {"name": "Langflow", "type": PlatformType.AGENT, "auth": "bearer", "url": "https://api.langflow.ai/api/v1"},
    "dify": {"name": "Dify", "type": PlatformType.AGENT, "auth": "bearer", "url": "https://api.dify.ai/v1"},
    "openwebui": {"name": "OpenWebUI", "type": PlatformType.AGENT, "auth": "bearer", "url": "https://{instance}/api/v1"},
    "crewai": {"name": "CrewAI", "type": PlatformType.AGENT, "auth": "api_key", "url": "https://api.crewai.com/v1"},
    "autogen": {"name": "AutoGen", "type": PlatformType.AGENT, "auth": "api_key", "url": "https://api.autogen.dev/v1"},
    "langgraph": {"name": "LangGraph", "type": PlatformType.AGENT, "auth": "bearer", "url": "https://api.langchain.com/v1"},
    "semantic_kernel": {"name": "Semantic Kernel", "type": PlatformType.AGENT, "auth": "api_key", "url": "https://api.semantic-kernel.ai/v1"},

    # Builder Platforms
    "replit": {"name": "Replit", "type": PlatformType.BUILDER, "auth": "bearer", "url": "https://api.replit.com/v0"},
    "firebase_studio": {"name": "Firebase Studio", "type": PlatformType.BUILDER, "auth": "oauth2", "url": "https://firebase.googleapis.com/v1"},
    "flutterflow": {"name": "FlutterFlow", "type": PlatformType.BUILDER, "auth": "bearer", "url": "https://api.flutterflow.io/v1"},
    "bolt": {"name": "Bolt", "type": PlatformType.BUILDER, "auth": "api_key", "url": "https://api.bolt.new/v1"},
    "lovable": {"name": "Lovable", "type": PlatformType.BUILDER, "auth": "bearer", "url": "https://api.lovable.dev/v1"},
    "v0": {"name": "v0 by Vercel", "type": PlatformType.BUILDER, "auth": "bearer", "url": "https://api.v0.dev/v1"},
    "softgen": {"name": "Softgen", "type": PlatformType.BUILDER, "auth": "api_key", "url": "https://api.softgen.ai/v1"},
    "draftbit": {"name": "Draftbit", "type": PlatformType.BUILDER, "auth": "bearer", "url": "https://api.draftbit.com/v1"},
    "glide": {"name": "Glide", "type": PlatformType.BUILDER, "auth": "bearer", "url": "https://api.glideapps.com/v1"},
    "framer": {"name": "Framer", "type": PlatformType.BUILDER, "auth": "bearer", "url": "https://api.framer.com/v1"},
    "adalo": {"name": "Adalo", "type": PlatformType.BUILDER, "auth": "bearer", "url": "https://api.adalo.com/v0"},
    "bubble": {"name": "Bubble", "type": PlatformType.BUILDER, "auth": "api_key", "url": "https://{app}.bubbleapps.io/api/1.1/wf"},
    "wix_ai": {"name": "Wix AI", "type": PlatformType.BUILDER, "auth": "bearer", "url": "https://api.wix.com/v1"},
    "appsmith": {"name": "Appsmith", "type": PlatformType.BUILDER, "auth": "bearer", "url": "https://api.appsmith.com/v1"},
    "tooljet": {"name": "ToolJet", "type": PlatformType.BUILDER, "auth": "bearer", "url": "https://api.tooljet.com/v1"},
    "budibase": {"name": "Budibase", "type": PlatformType.BUILDER, "auth": "bearer", "url": "https://api.budibase.app/api/v1"},

    # Backend Platforms
    "supabase": {"name": "Supabase", "type": PlatformType.BACKEND, "auth": "api_key", "url": "https://{project}.supabase.co/rest/v1"},
    "firebase": {"name": "Firebase", "type": PlatformType.BACKEND, "auth": "oauth2", "url": "https://firebase.googleapis.com/v1"},
    "appwrite": {"name": "Appwrite", "type": PlatformType.BACKEND, "auth": "api_key", "url": "https://cloud.appwrite.io/v1"},
    "pocketbase": {"name": "PocketBase", "type": PlatformType.BACKEND, "auth": "bearer", "url": "https://{instance}/api"},
    "nocodb": {"name": "NocoDB", "type": PlatformType.BACKEND, "auth": "api_key", "url": "https://{instance}/api/v1"},
    "hasura": {"name": "Hasura", "type": PlatformType.BACKEND, "auth": "admin_secret", "url": "https://{instance}/v1/graphql"},

    # DevOps Platforms
    "github": {"name": "GitHub", "type": PlatformType.DEVOPS, "auth": "bearer", "url": "https://api.github.com"},
    "gitlab": {"name": "GitLab", "type": PlatformType.DEVOPS, "auth": "bearer", "url": "https://gitlab.com/api/v4"},
    "bitbucket": {"name": "Bitbucket", "type": PlatformType.DEVOPS, "auth": "bearer", "url": "https://api.bitbucket.org/2.0"},
    "docker": {"name": "Docker Hub", "type": PlatformType.DEVOPS, "auth": "bearer", "url": "https://hub.docker.com/v2"},
    "kubernetes": {"name": "Kubernetes", "type": PlatformType.DEVOPS, "auth": "bearer", "url": "https://{cluster}/api/v1"},
    "argocd": {"name": "ArgoCD", "type": PlatformType.DEVOPS, "auth": "bearer", "url": "https://{instance}/api/v1"},
    "jenkins": {"name": "Jenkins", "type": PlatformType.DEVOPS, "auth": "basic", "url": "https://{instance}/api"},
    "terraform": {"name": "Terraform Cloud", "type": PlatformType.DEVOPS, "auth": "bearer", "url": "https://app.terraform.io/api/v2"},

    # Creative Platforms
    "runway": {"name": "Runway ML", "type": PlatformType.CREATIVE, "auth": "bearer", "url": "https://api.runwayml.com/v1"},
    "kling": {"name": "Kling AI", "type": PlatformType.CREATIVE, "auth": "api_key", "url": "https://api.klingai.com/v1"},
    "pika": {"name": "Pika Labs", "type": PlatformType.CREATIVE, "auth": "bearer", "url": "https://api.pika.art/v1"},
    "luma": {"name": "Luma AI", "type": PlatformType.CREATIVE, "auth": "bearer", "url": "https://api.lumalabs.ai/v1"},
    "hailuo": {"name": "Hailuo AI", "type": PlatformType.CREATIVE, "auth": "api_key", "url": "https://api.hailuo.ai/v1"},
    "suno": {"name": "Suno", "type": PlatformType.CREATIVE, "auth": "bearer", "url": "https://api.suno.ai/v1"},
    "udio": {"name": "Udio", "type": PlatformType.CREATIVE, "auth": "bearer", "url": "https://api.udio.com/v1"},
    "elevenlabs": {"name": "ElevenLabs", "type": PlatformType.CREATIVE, "auth": "api_key", "url": "https://api.elevenlabs.io/v1"},
    "midjourney": {"name": "Midjourney", "type": PlatformType.CREATIVE, "auth": "bearer", "url": "https://api.midjourney.com/v1"},
    "flux": {"name": "Flux (Black Forest Labs)", "type": PlatformType.CREATIVE, "auth": "api_key", "url": "https://api.bfl.ml/v1"},
    "leonardo": {"name": "Leonardo.ai", "type": PlatformType.CREATIVE, "auth": "bearer", "url": "https://api.leonardo.ai/v1"},
    "ideogram": {"name": "Ideogram", "type": PlatformType.CREATIVE, "auth": "api_key", "url": "https://api.ideogram.ai/v1"},
    "adobe_firefly": {"name": "Adobe Firefly", "type": PlatformType.CREATIVE, "auth": "bearer", "url": "https://firefly-api.adobe.io/v1"},
    "meshy": {"name": "Meshy", "type": PlatformType.CREATIVE, "auth": "api_key", "url": "https://api.meshy.ai/v1"},
    "tripo": {"name": "Tripo AI", "type": PlatformType.CREATIVE, "auth": "api_key", "url": "https://api.tripo.ai/v1"},
}

class IntegrationRegistryManager:
    """Manages all platform integrations in ZANOX"""

    async def initialize_defaults(self, db: AsyncSession):
        """Seed default integrations from PLATFORM_CONFIGS"""
        for provider, config_data in PLATFORM_CONFIGS.items():
            existing = await db.execute(
                select(IntegrationRegistry).where(IntegrationRegistry.provider == provider)
            )
            if existing.scalar_one_or_none() is None:
                integration = IntegrationRegistry(
                    id=str(uuid.uuid4()),
                    name=config_data["name"],
                    platform_type=config_data["type"],
                    provider=provider,
                    description=f"Integration for {config_data['name']}",
                    api_base_url=config_data["url"],
                    auth_type=config_data["auth"],
                    config_schema={
                        "type": "object",
                        "properties": {
                            "api_key": {"type": "string", "description": "API Key"},
                            "base_url": {"type": "string", "description": "Custom base URL"},
                            "timeout": {"type": "integer", "default": 30},
                        },
                        "required": ["api_key"]
                    },
                    capabilities=["api_call", "webhook", "data_sync"],
                    rate_limits={"requests_per_minute": 60, "requests_per_day": 10000},
                    pricing_tier="free",
                    is_active=True,
                    health_score=100.0
                )
                db.add(integration)
        await db.commit()
        logger.info(f"Initialized {len(PLATFORM_CONFIGS)} default integrations")

    async def get_all(self, db: AsyncSession, platform_type: Optional[str] = None, 
                      active_only: bool = True) -> List[IntegrationRegistry]:
        """Get all integrations with optional filtering"""
        query = select(IntegrationRegistry)
        if platform_type:
            query = query.where(IntegrationRegistry.platform_type == platform_type)
        if active_only:
            query = query.where(IntegrationRegistry.is_active == True)
        result = await db.execute(query)
        return result.scalars().all()

    async def get_by_provider(self, db: AsyncSession, provider: str) -> Optional[IntegrationRegistry]:
        """Get integration by provider name"""
        result = await db.execute(
            select(IntegrationRegistry).where(IntegrationRegistry.provider == provider)
        )
        return result.scalar_one_or_none()

    async def create(self, db: AsyncSession, data: IntegrationCreate) -> IntegrationRegistry:
        """Register new integration"""
        integration = IntegrationRegistry(
            id=str(uuid.uuid4()),
            **data.dict()
        )
        db.add(integration)
        await db.commit()
        await db.refresh(integration)
        logger.info(f"Created integration: {integration.name} ({integration.provider})")
        return integration

    async def update(self, db: AsyncSession, integration_id: str, data: IntegrationUpdate) -> IntegrationRegistry:
        """Update integration"""
        integration = await db.get(IntegrationRegistry, integration_id)
        if not integration:
            raise HTTPException(status_code=404, detail="Integration not found")

        update_data = data.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(integration, field, value)

        await db.commit()
        await db.refresh(integration)
        logger.info(f"Updated integration: {integration.name}")
        return integration

    async def delete(self, db: AsyncSession, integration_id: str):
        """Soft delete integration"""
        integration = await db.get(IntegrationRegistry, integration_id)
        if not integration:
            raise HTTPException(status_code=404, detail="Integration not found")
        integration.is_active = False
        await db.commit()
        logger.info(f"Deactivated integration: {integration.name}")

integration_manager = IntegrationRegistryManager()

# API Endpoints
@router.post("/", response_model=IntegrationResponse)
async def create_integration(data: IntegrationCreate, db: AsyncSession = Depends(get_db)):
    """Register a new integration"""
    return await integration_manager.create(db, data)

@router.get("/", response_model=List[IntegrationResponse])
async def list_integrations(
    platform_type: Optional[str] = Query(None, description="Filter by platform type"),
    active_only: bool = Query(True, description="Show only active integrations"),
    db: AsyncSession = Depends(get_db)
):
    """List all registered integrations"""
    return await integration_manager.get_all(db, platform_type, active_only)

@router.get("/{integration_id}", response_model=IntegrationResponse)
async def get_integration(integration_id: str, db: AsyncSession = Depends(get_db)):
    """Get integration by ID"""
    integration = await db.get(IntegrationRegistry, integration_id)
    if not integration:
        raise HTTPException(status_code=404, detail="Integration not found")
    return integration

@router.get("/provider/{provider}", response_model=IntegrationResponse)
async def get_integration_by_provider(provider: str, db: AsyncSession = Depends(get_db)):
    """Get integration by provider name"""
    integration = await integration_manager.get_by_provider(db, provider)
    if not integration:
        raise HTTPException(status_code=404, detail="Integration not found")
    return integration

@router.put("/{integration_id}", response_model=IntegrationResponse)
async def update_integration(integration_id: str, data: IntegrationUpdate, db: AsyncSession = Depends(get_db)):
    """Update integration"""
    return await integration_manager.update(db, integration_id, data)

@router.delete("/{integration_id}")
async def delete_integration(integration_id: str, db: AsyncSession = Depends(get_db)):
    """Deactivate integration"""
    await integration_manager.delete(db, integration_id)
    return {"status": "success", "message": "Integration deactivated"}

@router.post("/initialize")
async def initialize_defaults(db: AsyncSession = Depends(get_db)):
    """Initialize all default platform integrations"""
    await integration_manager.initialize_defaults(db)
    return {"status": "success", "message": "Default integrations initialized"}
