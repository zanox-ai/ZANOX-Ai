"""ZANOX V12 Security Layer"""
from datetime import datetime, timedelta
from typing import Optional, Dict, Any
from jose import JWTError, jwt
from passlib.context import CryptContext
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import base64
import hashlib
import secrets
import logging
from shared.config import config

logger = logging.getLogger(__name__)

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

class SecurityManager:
    """Production security manager for encryption, hashing, and token management"""

    def __init__(self):
        self._fernet = self._init_fernet()

    def _init_fernet(self) -> Fernet:
        """Initialize Fernet encryption from config key"""
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=b'zanox_salt_2024',
            iterations=100000,
        )
        key = base64.urlsafe_b64encode(kdf.derive(config.ENCRYPTION_KEY.encode()))
        return Fernet(key)

    def hash_password(self, password: str) -> str:
        """Hash password using bcrypt"""
        return pwd_context.hash(password)

    def verify_password(self, plain_password: str, hashed_password: str) -> bool:
        """Verify password against hash"""
        return pwd_context.verify(plain_password, hashed_password)

    def create_access_token(self, data: Dict[str, Any], expires_delta: Optional[timedelta] = None) -> str:
        """Create JWT access token"""
        to_encode = data.copy()
        if expires_delta:
            expire = datetime.utcnow() + expires_delta
        else:
            expire = datetime.utcnow() + timedelta(minutes=config.JWT_ACCESS_TOKEN_EXPIRE_MINUTES)
        to_encode.update({"exp": expire, "iat": datetime.utcnow(), "type": "access"})
        return jwt.encode(to_encode, config.JWT_SECRET_KEY, algorithm=config.JWT_ALGORITHM)

    def create_refresh_token(self, data: Dict[str, Any]) -> str:
        """Create JWT refresh token"""
        to_encode = data.copy()
        expire = datetime.utcnow() + timedelta(days=config.JWT_REFRESH_TOKEN_EXPIRE_DAYS)
        to_encode.update({"exp": expire, "iat": datetime.utcnow(), "type": "refresh"})
        return jwt.encode(to_encode, config.JWT_SECRET_KEY, algorithm=config.JWT_ALGORITHM)

    def decode_token(self, token: str) -> Optional[Dict[str, Any]]:
        """Decode and validate JWT token"""
        try:
            payload = jwt.decode(token, config.JWT_SECRET_KEY, algorithms=[config.JWT_ALGORITHM])
            return payload
        except JWTError as e:
            logger.warning(f"Token decode failed: {e}")
            return None

    def encrypt(self, data: str) -> str:
        """Encrypt string data"""
        return self._fernet.encrypt(data.encode()).decode()

    def decrypt(self, token: str) -> str:
        """Decrypt encrypted data"""
        return self._fernet.decrypt(token.encode()).decode()

    def encrypt_dict(self, data: Dict[str, Any]) -> str:
        """Encrypt dictionary"""
        import json
        return self.encrypt(json.dumps(data))

    def decrypt_dict(self, token: str) -> Dict[str, Any]:
        """Decrypt to dictionary"""
        import json
        return json.loads(self.decrypt(token))

    def generate_api_key(self) -> str:
        """Generate secure API key"""
        return f"zanox_{secrets.token_urlsafe(32)}"

    def hash_api_key(self, api_key: str) -> str:
        """Hash API key for storage"""
        return hashlib.sha256(api_key.encode()).hexdigest()

    def generate_nonce(self, length: int = 32) -> str:
        """Generate cryptographically secure nonce"""
        return secrets.token_hex(length)

    def sanitize_input(self, value: str) -> str:
        """Sanitize user input"""
        allowed = {"\n", "\t", "\r"}
        sanitized = "".join(char for char in value if ord(char) >= 32 or char in allowed)
        return sanitized[:1000]

security_manager = SecurityManager()
