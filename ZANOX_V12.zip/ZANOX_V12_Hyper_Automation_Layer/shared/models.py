"""ZANOX V12 Database Models"""
from sqlalchemy import (
    Column, String, Integer, Float, Boolean, DateTime, Text, 
    JSON, ForeignKey, Enum, ARRAY, BigInteger, Index, UniqueConstraint
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from shared.database import Base
import enum

# Enums
class ConnectorStatus(str, enum.Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    ERROR = "error"
    MAINTENANCE = "maintenance"
    DEPRECATED = "deprecated"

class WorkflowStatus(str, enum.Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    PAUSED = "paused"

class TaskStatus(str, enum.Enum):
    PENDING = "pending"
    ASSIGNED = "assigned"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    RETRYING = "retrying"

class PlatformType(str, enum.Enum):
    AI = "ai"
    AUTOMATION = "automation"
    AGENT = "agent"
    BUILDER = "builder"
    BACKEND = "backend"
    DEVOPS = "devops"
    CREATIVE = "creative"

class IntegrationRegistry(Base):
    __tablename__ = "integration_registry"

    id = Column(String(36), primary_key=True)
    name = Column(String(255), nullable=False)
    platform_type = Column(Enum(PlatformType), nullable=False)
    provider = Column(String(100), nullable=False)
    description = Column(Text)
    api_base_url = Column(String(500))
    auth_type = Column(String(50))  # oauth2, api_key, bearer, basic
    config_schema = Column(JSON)
    capabilities = Column(ARRAY(String))
    rate_limits = Column(JSON)
    pricing_tier = Column(String(50))
    is_active = Column(Boolean, default=True)
    health_score = Column(Float, default=100.0)
    last_health_check = Column(DateTime(timezone=True))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    __table_args__ = (
        Index('idx_integration_provider', 'provider'),
        Index('idx_integration_type', 'platform_type'),
        Index('idx_integration_active', 'is_active'),
    )

class ConnectorRegistry(Base):
    __tablename__ = "connector_registry"

    id = Column(String(36), primary_key=True)
    integration_id = Column(String(36), ForeignKey("integration_registry.id"), nullable=False)
    name = Column(String(255), nullable=False)
    version = Column(String(50), nullable=False)
    connector_type = Column(String(100), nullable=False)  # rest, graphql, webhook, sdk
    protocol = Column(String(50))  # http, https, grpc, websocket
    endpoint_url = Column(String(500))
    auth_config = Column(JSON)
    headers = Column(JSON)
    timeout_seconds = Column(Integer, default=30)
    retry_policy = Column(JSON)
    circuit_breaker_config = Column(JSON)
    status = Column(Enum(ConnectorStatus), default=ConnectorStatus.ACTIVE)
    failure_count = Column(Integer, default=0)
    last_failure = Column(DateTime(timezone=True))
    last_success = Column(DateTime(timezone=True))
    response_time_ms = Column(Float)
    request_count = Column(BigInteger, default=0)
    error_rate = Column(Float, default=0.0)
    metadata = Column(JSON)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    integration = relationship("IntegrationRegistry", backref="connectors")

    __table_args__ = (
        Index('idx_connector_integration', 'integration_id'),
        Index('idx_connector_status', 'status'),
        Index('idx_connector_name', 'name'),
    )

class ConnectorMarketplace(Base):
    __tablename__ = "connector_marketplace"

    id = Column(String(36), primary_key=True)
    connector_id = Column(String(36), ForeignKey("connector_registry.id"), nullable=False)
    publisher_id = Column(String(36), nullable=False)
    publisher_name = Column(String(255))
    rating = Column(Float, default=0.0)
    review_count = Column(Integer, default=0)
    download_count = Column(Integer, default=0)
    price_usd = Column(Float, default=0.0)
    is_premium = Column(Boolean, default=False)
    tags = Column(ARRAY(String))
    documentation_url = Column(String(500))
    icon_url = Column(String(500))
    screenshots = Column(ARRAY(String))
    changelog = Column(JSON)
    is_verified = Column(Boolean, default=False)
    is_featured = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    __table_args__ = (
        Index('idx_marketplace_connector', 'connector_id'),
        Index('idx_marketplace_publisher', 'publisher_id'),
        Index('idx_marketplace_featured', 'is_featured'),
    )

class WorkflowDefinition(Base):
    __tablename__ = "workflow_definitions"

    id = Column(String(36), primary_key=True)
    name = Column(String(255), nullable=False)
    description = Column(Text)
    version = Column(String(50), default="1.0.0")
    definition = Column(JSON, nullable=False)  # Full workflow graph
    triggers = Column(JSON)
    variables = Column(JSON)
    inputs = Column(JSON)
    outputs = Column(JSON)
    owner_id = Column(String(36), nullable=False)
    is_public = Column(Boolean, default=False)
    is_template = Column(Boolean, default=False)
    category = Column(String(100))
    tags = Column(ARRAY(String))
    usage_count = Column(Integer, default=0)
    success_rate = Column(Float, default=0.0)
    avg_execution_time_ms = Column(Float)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    __table_args__ = (
        Index('idx_workflow_owner', 'owner_id'),
        Index('idx_workflow_public', 'is_public'),
        Index('idx_workflow_template', 'is_template'),
    )

class WorkflowExecution(Base):
    __tablename__ = "workflow_executions"

    id = Column(String(36), primary_key=True)
    workflow_id = Column(String(36), ForeignKey("workflow_definitions.id"), nullable=False)
    status = Column(Enum(WorkflowStatus), default=WorkflowStatus.PENDING)
    trigger_type = Column(String(50))  # manual, scheduled, webhook, event
    trigger_data = Column(JSON)
    context = Column(JSON)
    result = Column(JSON)
    error_message = Column(Text)
    error_stack = Column(Text)
    started_at = Column(DateTime(timezone=True))
    completed_at = Column(DateTime(timezone=True))
    duration_ms = Column(Float)
    cost_usd = Column(Float, default=0.0)
    executor_node = Column(String(100))
    retry_count = Column(Integer, default=0)
    parent_execution_id = Column(String(36))

    workflow = relationship("WorkflowDefinition", backref="executions")

    __table_args__ = (
        Index('idx_execution_workflow', 'workflow_id'),
        Index('idx_execution_status', 'status'),
        Index('idx_execution_started', 'started_at'),
    )

class TaskRecord(Base):
    __tablename__ = "task_records"

    id = Column(String(36), primary_key=True)
    execution_id = Column(String(36), ForeignKey("workflow_executions.id"), nullable=False)
    task_name = Column(String(255), nullable=False)
    task_type = Column(String(100), nullable=False)
    platform = Column(String(100))
    connector_id = Column(String(36), ForeignKey("connector_registry.id"))
    status = Column(Enum(TaskStatus), default=TaskStatus.PENDING)
    input_data = Column(JSON)
    output_data = Column(JSON)
    error_data = Column(JSON)
    started_at = Column(DateTime(timezone=True))
    completed_at = Column(DateTime(timezone=True))
    duration_ms = Column(Float)
    cost_usd = Column(Float, default=0.0)
    assigned_to = Column(String(100))  # agent_id, ai_model, builder_id
    retry_count = Column(Integer, default=0)

    execution = relationship("WorkflowExecution", backref="tasks")
    connector = relationship("ConnectorRegistry", backref="tasks")

    __table_args__ = (
        Index('idx_task_execution', 'execution_id'),
        Index('idx_task_status', 'status'),
        Index('idx_task_platform', 'platform'),
    )

class EventRecord(Base):
    __tablename__ = "event_records"

    id = Column(String(36), primary_key=True)
    event_type = Column(String(100), nullable=False)
    source = Column(String(100), nullable=False)
    target = Column(String(100))
    payload = Column(JSON)
    priority = Column(Integer, default=5)  # 1-10, 1 = highest
    correlation_id = Column(String(36))
    causation_id = Column(String(36))
    processed = Column(Boolean, default=False)
    processed_at = Column(DateTime(timezone=True))
    error_count = Column(Integer, default=0)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        Index('idx_event_type', 'event_type'),
        Index('idx_event_source', 'source'),
        Index('idx_event_correlation', 'correlation_id'),
        Index('idx_event_processed', 'processed'),
    )

class CostRecord(Base):
    __tablename__ = "cost_records"

    id = Column(String(36), primary_key=True)
    execution_id = Column(String(36), ForeignKey("workflow_executions.id"))
    task_id = Column(String(36), ForeignKey("task_records.id"))
    platform = Column(String(100), nullable=False)
    operation_type = Column(String(100), nullable=False)
    cost_usd = Column(Float, nullable=False)
    tokens_input = Column(Integer)
    tokens_output = Column(Integer)
    compute_seconds = Column(Float)
    storage_bytes = Column(BigInteger)
    network_bytes = Column(BigInteger)
    billing_period = Column(String(10))  # YYYY-MM
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        Index('idx_cost_execution', 'execution_id'),
        Index('idx_cost_platform', 'platform'),
        Index('idx_cost_billing', 'billing_period'),
    )

class AuditLog(Base):
    __tablename__ = "audit_logs"

    id = Column(BigInteger, primary_key=True, autoincrement=True)
    action = Column(String(100), nullable=False)
    entity_type = Column(String(100), nullable=False)
    entity_id = Column(String(36), nullable=False)
    user_id = Column(String(36))
    user_email = Column(String(255))
    ip_address = Column(String(45))
    user_agent = Column(String(500))
    before_state = Column(JSON)
    after_state = Column(JSON)
    metadata = Column(JSON)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        Index('idx_audit_entity', 'entity_type', 'entity_id'),
        Index('idx_audit_user', 'user_id'),
        Index('idx_audit_action', 'action'),
        Index('idx_audit_created', 'created_at'),
    )

class HealthCheck(Base):
    __tablename__ = "health_checks"

    id = Column(BigInteger, primary_key=True, autoincrement=True)
    connector_id = Column(String(36), ForeignKey("connector_registry.id"), nullable=False)
    status = Column(String(50), nullable=False)
    response_time_ms = Column(Float)
    http_status = Column(Integer)
    error_message = Column(Text)
    details = Column(JSON)
    checked_at = Column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        Index('idx_health_connector', 'connector_id'),
        Index('idx_health_checked', 'checked_at'),
    )

class User(Base):
    __tablename__ = "users"

    id = Column(String(36), primary_key=True)
    email = Column(String(255), nullable=False, unique=True)
    password_hash = Column(String(255), nullable=False)
    full_name = Column(String(255))
    role = Column(String(50), default="user")  # user, admin, super_admin
    is_active = Column(Boolean, default=True)
    api_key_hash = Column(String(64))
    preferences = Column(JSON)
    last_login = Column(DateTime(timezone=True))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    __table_args__ = (
        Index('idx_user_email', 'email'),
        Index('idx_user_active', 'is_active'),
    )

class ApiKey(Base):
    __tablename__ = "api_keys"

    id = Column(String(36), primary_key=True)
    user_id = Column(String(36), ForeignKey("users.id"), nullable=False)
    name = Column(String(255), nullable=False)
    key_hash = Column(String(64), nullable=False, unique=True)
    permissions = Column(ARRAY(String))
    rate_limit = Column(Integer, default=1000)
    last_used_at = Column(DateTime(timezone=True))
    expires_at = Column(DateTime(timezone=True))
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    user = relationship("User", backref="api_keys")

    __table_args__ = (
        Index('idx_apikey_user', 'user_id'),
        Index('idx_apikey_hash', 'key_hash'),
    )

class MemorySync(Base):
    __tablename__ = "memory_sync"

    id = Column(String(36), primary_key=True)
    platform = Column(String(100), nullable=False)
    memory_type = Column(String(50), nullable=False)  # conversation, context, state, preference
    key = Column(String(500), nullable=False)
    value = Column(JSON)
    vector_embedding = Column(ARRAY(Float))
    sync_version = Column(Integer, default=1)
    last_synced_at = Column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        Index('idx_memory_platform', 'platform'),
        Index('idx_memory_key', 'key'),
        Index('idx_memory_synced', 'last_synced_at'),
    )

class ContextSync(Base):
    __tablename__ = "context_sync"

    id = Column(String(36), primary_key=True)
    session_id = Column(String(36), nullable=False)
    platform = Column(String(100), nullable=False)
    context_data = Column(JSON)
    priority = Column(Integer, default=5)
    expires_at = Column(DateTime(timezone=True))
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        Index('idx_context_session', 'session_id'),
        Index('idx_context_platform', 'platform'),
    )

class GovernancePolicy(Base):
    __tablename__ = "governance_policies"

    id = Column(String(36), primary_key=True)
    name = Column(String(255), nullable=False)
    policy_type = Column(String(100), nullable=False)  # access, data, workflow, cost
    rules = Column(JSON, nullable=False)
    scope = Column(String(100))  # global, organization, user, workflow
    target_id = Column(String(36))
    is_active = Column(Boolean, default=True)
    enforcement_mode = Column(String(20), default="enforce")  # enforce, audit, warn
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    __table_args__ = (
        Index('idx_governance_type', 'policy_type'),
        Index('idx_governance_active', 'is_active'),
    )

class ComplianceRecord(Base):
    __tablename__ = "compliance_records"

    id = Column(String(36), primary_key=True)
    standard = Column(String(100), nullable=False)  # GDPR, SOC2, HIPAA, ISO27001
    control_id = Column(String(100), nullable=False)
    control_name = Column(String(255))
    status = Column(String(50), nullable=False)  # compliant, non_compliant, partial, not_applicable
    evidence = Column(JSON)
    assessed_at = Column(DateTime(timezone=True))
    assessor = Column(String(255))
    next_assessment = Column(DateTime(timezone=True))
    findings = Column(JSON)
    remediation_plan = Column(JSON)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    __table_args__ = (
        Index('idx_compliance_standard', 'standard'),
        Index('idx_compliance_status', 'status'),
        Index('idx_compliance_next', 'next_assessment'),
    )
