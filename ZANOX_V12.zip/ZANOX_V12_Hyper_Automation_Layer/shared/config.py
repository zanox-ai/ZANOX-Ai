"""ZANOX V12 Configuration Management"""
import os
from pydantic_settings import BaseSettings
from pydantic import Field
from typing import Optional, List

class ZANOXConfig(BaseSettings):
    """Central configuration for ZANOX V12"""

    # Application
    APP_NAME: str = "ZANOX V12 Hyper Automation Layer"
    APP_VERSION: str = "12.0.0"
    DEBUG: bool = Field(default=False, env="DEBUG")
    ENVIRONMENT: str = Field(default="production", env="ENVIRONMENT")

    # Database
    DATABASE_URL: str = Field(default="postgresql://zanox:zanox_secret@localhost:5432/zanox_v12", env="DATABASE_URL")
    DATABASE_POOL_SIZE: int = 20
    DATABASE_MAX_OVERFLOW: int = 40

    # Redis
    REDIS_URL: str = Field(default="redis://localhost:6379/0", env="REDIS_URL")
    REDIS_POOL_SIZE: int = 50

    # Message Queue
    KAFKA_BOOTSTRAP_SERVERS: str = Field(default="localhost:9092", env="KAFKA_BOOTSTRAP_SERVERS")
    NATS_URL: str = Field(default="nats://localhost:4222", env="NATS_URL")

    # Security
    JWT_SECRET_KEY: str = Field(default="zanox-super-secret-jwt-key-2024", env="JWT_SECRET_KEY")
    JWT_ALGORITHM: str = "HS256"
    JWT_ACCESS_TOKEN_EXPIRE_MINUTES: int = 60
    JWT_REFRESH_TOKEN_EXPIRE_DAYS: int = 30
    ENCRYPTION_KEY: str = Field(default="zanox-encryption-key-32bytes-long!!", env="ENCRYPTION_KEY")

    # API Rate Limits
    RATE_LIMIT_PER_MINUTE: int = 1000
    RATE_LIMIT_BURST: int = 200

    # Workflow Engine
    MAX_CONCURRENT_WORKFLOWS: int = 500
    WORKFLOW_TIMEOUT_SECONDS: int = 3600
    TASK_RETRY_MAX_ATTEMPTS: int = 5
    TASK_RETRY_BACKOFF_BASE: float = 2.0

    # Connector Settings
    CONNECTOR_TIMEOUT_SECONDS: int = 30
    CONNECTOR_HEALTH_CHECK_INTERVAL: int = 60
    CONNECTOR_MAX_FAILURES: int = 5

    # Monitoring
    PROMETHEUS_PORT: int = 9090
    METRICS_ENABLED: bool = True
    TRACE_SAMPLING_RATE: float = 0.1

    # Cost Optimization
    COST_BUDGET_DAILY_USD: float = 100.0
    COST_ALERT_THRESHOLD: float = 0.8

    # Supported Platforms (loaded from registry)
    SUPPORTED_AI_SYSTEMS: List[str] = [
        "chatgpt", "claude", "gemini", "grok", "kimi", "perplexity",
        "qwen", "copilot", "manus", "deepseek", "mistral", "openrouter"
    ]

    SUPPORTED_AUTOMATION_PLATFORMS: List[str] = [
        "n8n", "zapier", "make", "activepieces", "pipedream",
        "windmill", "kestra", "temporal", "node-red", "huginn"
    ]

    SUPPORTED_AGENT_PLATFORMS: List[str] = [
        "flowise", "langflow", "dify", "openwebui", "crewai",
        "autogen", "langgraph", "semantic_kernel"
    ]

    SUPPORTED_BUILDER_PLATFORMS: List[str] = [
        "replit", "firebase_studio", "flutterflow", "bolt", "lovable",
        "v0", "softgen", "draftbit", "glide", "framer", "adalo",
        "bubble", "wix_ai", "appsmith", "tooljet", "budibase"
    ]

    SUPPORTED_BACKEND_PLATFORMS: List[str] = [
        "supabase", "firebase", "appwrite", "pocketbase", "nocodb", "hasura"
    ]

    SUPPORTED_DEVOPS_PLATFORMS: List[str] = [
        "github", "gitlab", "bitbucket", "docker", "kubernetes",
        "argocd", "jenkins", "terraform"
    ]

    SUPPORTED_CREATIVE_PLATFORMS: List[str] = [
        "runway", "kling", "pika", "luma", "hailuo", "suno", "udio",
        "elevenlabs", "midjourney", "flux", "leonardo", "ideogram",
        "adobe_firefly", "meshy", "tripo"
    ]

    class Config:
        env_file = ".env"
        case_sensitive = True

# Global config instance
config = ZANOXConfig()
