"""ZANOX V12 Redis Client"""
import aioredis
import json
import logging
from typing import Optional, Any, List
from shared.config import config

logger = logging.getLogger(__name__)

class RedisClient:
    """Production Redis client with connection pooling"""

    _instance: Optional['RedisClient'] = None
    _redis: Optional[aioredis.Redis] = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    async def connect(self):
        """Initialize Redis connection"""
        if self._redis is None:
            self._redis = aioredis.from_url(
                config.REDIS_URL,
                decode_responses=True,
                max_connections=config.REDIS_POOL_SIZE
            )
            logger.info("Redis connection established")

    async def disconnect(self):
        """Close Redis connection"""
        if self._redis:
            await self._redis.close()
            self._redis = None
            logger.info("Redis connection closed")

    async def get(self, key: str) -> Optional[str]:
        """Get value by key"""
        await self.connect()
        return await self._redis.get(key)

    async def set(self, key: str, value: str, expire: Optional[int] = None):
        """Set value with optional expiration"""
        await self.connect()
        await self._redis.set(key, value, ex=expire)

    async def delete(self, key: str):
        """Delete key"""
        await self.connect()
        await self._redis.delete(key)

    async def hget(self, key: str, field: str) -> Optional[str]:
        """Get hash field"""
        await self.connect()
        return await self._redis.hget(key, field)

    async def hset(self, key: str, field: str, value: str):
        """Set hash field"""
        await self.connect()
        await self._redis.hset(key, field, value)

    async def hgetall(self, key: str) -> dict:
        """Get all hash fields"""
        await self.connect()
        return await self._redis.hgetall(key)

    async def publish(self, channel: str, message: str):
        """Publish message to channel"""
        await self.connect()
        await self._redis.publish(channel, message)

    async def lpush(self, key: str, value: str):
        """Push to list"""
        await self.connect()
        await self._redis.lpush(key, value)

    async def lrange(self, key: str, start: int, end: int) -> List[str]:
        """Get list range"""
        await self.connect()
        return await self._redis.lrange(key, start, end)

    async def expire(self, key: str, seconds: int):
        """Set expiration"""
        await self.connect()
        await self._redis.expire(key, seconds)

    async def exists(self, key: str) -> bool:
        """Check if key exists"""
        await self.connect()
        return await self._redis.exists(key) > 0

redis_client = RedisClient()
