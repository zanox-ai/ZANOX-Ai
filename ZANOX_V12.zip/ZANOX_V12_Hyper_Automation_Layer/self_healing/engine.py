"""ZANOX V12 Self-Healing Layer - Automated Recovery"""
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, or_, func
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime, timedelta
import uuid
import logging
import asyncio

from shared.database import get_db
from shared.models import ConnectorRegistry, WorkflowExecution, TaskRecord, EventRecord
from shared.redis_client import redis_client
from connector_registry.registry import connector_manager
from failure_recovery.engine import failure_recovery_engine, RecoveryAction

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v12/self-healing", tags=["Self-Healing"])

class HealingAction(BaseModel):
    """Self-healing action"""
    action_type: str  # restart_connector, retry_failed, rebalance, cleanup
    target_type: str  # connector, workflow, task, system
    target_id: str
    parameters: Optional[Dict[str, Any]] = {}

class SelfHealingEngine:
    """Automated self-healing for ZANOX infrastructure"""

    async def heal_connector(self, db: AsyncSession, connector_id: str) -> Dict[str, Any]:
        """Heal unhealthy connector"""
        connector = await db.get(ConnectorRegistry, connector_id)
        if not connector:
            return {"status": "failed", "error": "Connector not found"}

        if connector.status.value == "error":
            # Reset failure count
            connector.failure_count = 0
            connector.status = "active"
            await db.commit()

            # Verify health
            health = await connector_manager.health_check(db, connector_id)

            return {
                "connector_id": connector_id,
                "action": "reset_and_verify",
                "new_status": connector.status.value,
                "health_check": health
            }

        return {"status": "no_action_needed", "current_status": connector.status.value}

    async def heal_workflow(self, db: AsyncSession, 
                           execution_id: str) -> Dict[str, Any]:
        """Heal failed workflow execution"""
        execution = await db.get(WorkflowExecution, execution_id)
        if not execution:
            return {"status": "failed", "error": "Execution not found"}

        if execution.status.value == "failed":
            # Auto-recover failed tasks
            result = await failure_recovery_engine.auto_recover_execution(db, execution_id)

            # Check if all tasks recovered
            result = await db.execute(
                select(TaskRecord)
                .where(TaskRecord.execution_id == execution_id)
                .where(TaskRecord.status == "failed")
            )
            remaining_failed = len(result.scalars().all())

            if remaining_failed == 0:
                execution.status = "completed"
                await db.commit()

            return {
                "execution_id": execution_id,
                "action": "auto_recover",
                "remaining_failed": remaining_failed,
                "new_status": execution.status.value
            }

        return {"status": "no_action_needed", "current_status": execution.status.value}

    async def cleanup_orphaned(self, db: AsyncSession) -> Dict[str, Any]:
        """Clean up orphaned resources"""
        # Find old pending executions
        cutoff = datetime.utcnow() - timedelta(hours=24)

        result = await db.execute(
            select(WorkflowExecution)
            .where(WorkflowExecution.status == "running")
            .where(WorkflowExecution.started_at < cutoff)
        )
        stale = result.scalars().all()

        cleaned = 0
        for execution in stale:
            execution.status = "cancelled"
            execution.completed_at = datetime.utcnow()
            cleaned += 1

        await db.commit()

        return {
            "action": "cleanup_stale_executions",
            "cleaned_count": cleaned,
            "cutoff": cutoff.isoformat()
        }

    async def rebalance_load(self, db: AsyncSession) -> Dict[str, Any]:
        """Rebalance load across connectors"""
        result = await db.execute(
            select(ConnectorRegistry)
            .where(ConnectorRegistry.status == "active")
        )
        connectors = result.scalars().all()

        if not connectors:
            return {"status": "no_connectors"}

        # Calculate average load
        avg_requests = sum(c.request_count for c in connectors) / len(connectors)

        rebalanced = 0
        for connector in connectors:
            if connector.request_count > avg_requests * 2:
                # High load connector - could trigger scaling
                rebalanced += 1

        return {
            "action": "load_analysis",
            "total_connectors": len(connectors),
            "avg_requests": avg_requests,
            "high_load_connectors": rebalanced
        }

    async def run_health_scan(self, db: AsyncSession) -> Dict[str, Any]:
        """Run comprehensive health scan"""
        actions = []

        # Heal connectors
        result = await db.execute(
            select(ConnectorRegistry)
            .where(ConnectorRegistry.status == "error")
        )
        error_connectors = result.scalars().all()

        for connector in error_connectors:
            healing = await self.heal_connector(db, connector.id)
            actions.append(healing)

        # Heal workflows
        result = await db.execute(
            select(WorkflowExecution)
            .where(WorkflowExecution.status == "failed")
        )
        failed_executions = result.scalars().all()

        for execution in failed_executions:
            healing = await self.heal_workflow(db, execution.id)
            actions.append(healing)

        # Cleanup
        cleanup = await self.cleanup_orphaned(db)
        actions.append(cleanup)

        # Rebalance
        rebalance = await self.rebalance_load(db)
        actions.append(rebalance)

        return {
            "scan_time": datetime.utcnow().isoformat(),
            "actions_taken": actions,
            "total_actions": len(actions)
        }

self_healing_engine = SelfHealingEngine()

@router.post("/heal-connector/{connector_id}")
async def heal_connector(connector_id: str, db: AsyncSession = Depends(get_db)):
    """Heal connector"""
    return await self_healing_engine.heal_connector(db, connector_id)

@router.post("/heal-workflow/{execution_id}")
async def heal_workflow(execution_id: str, db: AsyncSession = Depends(get_db)):
    """Heal workflow"""
    return await self_healing_engine.heal_workflow(db, execution_id)

@router.post("/cleanup")
async def cleanup_orphaned(db: AsyncSession = Depends(get_db)):
    """Clean up orphaned resources"""
    return await self_healing_engine.cleanup_orphaned(db)

@router.post("/rebalance")
async def rebalance_load(db: AsyncSession = Depends(get_db)):
    """Rebalance load"""
    return await self_healing_engine.rebalance_load(db)

@router.post("/health-scan")
async def run_health_scan(background_tasks: BackgroundTasks, db: AsyncSession = Depends(get_db)):
    """Run comprehensive health scan"""
    result = await self_healing_engine.run_health_scan(db)
    return result
