"""ZANOX V12 Security Layer - Integration Security Controls"""
from fastapi import APIRouter, Depends, HTTPException, Request, Security
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, or_
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime, timedelta
import uuid
import logging

from shared.database import get_db
from shared.models import User, ApiKey, AuditLog, GovernancePolicy
from shared.security import security_manager
from shared.redis_client import redis_client
from shared.config import config

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v12/security", tags=["Security Layer"])
security = HTTPBearer()

class SecurityPolicy(BaseModel):
    """Security policy configuration"""
    policy_name: str
    policy_type: str  # access_control, data_protection, encryption, audit
    rules: Dict[str, Any]
    scope: str = "global"
    target_id: Optional[str] = None
    is_active: bool = True

class SecurityEngine:
    """Comprehensive security engine for ZANOX"""

    async def authenticate(self, db: AsyncSession, 
                          credentials: HTTPAuthorizationCredentials) -> Optional[User]:
        """Authenticate user from token"""
        token = credentials.credentials

        # Try JWT first
        payload = security_manager.decode_token(token)
        if payload:
            user_id = payload.get("sub")
            if user_id:
                user = await db.get(User, user_id)
                if user and user.is_active:
                    return user

        # Try API key
        key_hash = security_manager.hash_api_key(token)
        result = await db.execute(
            select(ApiKey)
            .where(ApiKey.key_hash == key_hash)
            .where(ApiKey.is_active == True)
        )
        api_key = result.scalar_one_or_none()

        if api_key:
            if api_key.expires_at and api_key.expires_at < datetime.utcnow():
                return None

            api_key.last_used_at = datetime.utcnow()
            await db.commit()

            return await db.get(User, api_key.user_id)

        return None

    async def authorize(self, db: AsyncSession, user: User, 
                       action: str, resource: str) -> bool:
        """Check if user is authorized for action"""
        # Admin has all permissions
        if user.role == "super_admin":
            return True

        # Check role-based permissions
        permissions = {
            "user": ["read", "execute"],
            "admin": ["read", "write", "execute", "delete"]
        }

        user_perms = permissions.get(user.role, [])
        return action in user_perms

    async def audit_log(self, db: AsyncSession, action: str, entity_type: str,
                       entity_id: str, user_id: Optional[str] = None,
                       before_state: Optional[Dict] = None,
                       after_state: Optional[Dict] = None,
                       metadata: Optional[Dict] = None):
        """Create audit log entry"""
        audit = AuditLog(
            action=action,
            entity_type=entity_type,
            entity_id=entity_id,
            user_id=user_id,
            before_state=before_state,
            after_state=after_state,
            metadata=metadata or {}
        )
        db.add(audit)
        await db.commit()

    async def encrypt_sensitive_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Encrypt sensitive fields in data"""
        encrypted = {}
        sensitive_fields = ["api_key", "password", "token", "secret", "credential"]

        for key, value in data.items():
            if any(sf in key.lower() for sf in sensitive_fields) and isinstance(value, str):
                encrypted[key] = security_manager.encrypt(value)
            else:
                encrypted[key] = value

        return encrypted

    async def decrypt_sensitive_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Decrypt sensitive fields in data"""
        decrypted = {}

        for key, value in data.items():
            try:
                decrypted[key] = security_manager.decrypt(value)
            except Exception:
                decrypted[key] = value

        return decrypted

    async def validate_input(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Validate and sanitize input"""
        sanitized = {}

        for key, value in data.items():
            if isinstance(value, str):
                sanitized[key] = security_manager.sanitize_input(value)
            elif isinstance(value, dict):
                sanitized[key] = await self.validate_input(value)
            else:
                sanitized[key] = value

        return sanitized

security_engine = SecurityEngine()

@router.post("/authenticate")
async def authenticate(
    credentials: HTTPAuthorizationCredentials = Security(security),
    db: AsyncSession = Depends(get_db)
):
    """Authenticate user"""
    user = await security_engine.authenticate(db, credentials)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid credentials")

    return {
        "user_id": user.id,
        "email": user.email,
        "role": user.role,
        "authenticated": True
    }

@router.post("/audit")
async def create_audit_log(
    action: str,
    entity_type: str,
    entity_id: str,
    before_state: Optional[Dict] = None,
    after_state: Optional[Dict] = None,
    db: AsyncSession = Depends(get_db)
):
    """Create audit log"""
    await security_engine.audit_log(db, action, entity_type, entity_id, 
                                     before_state=before_state, after_state=after_state)
    return {"status": "logged"}

@router.get("/audit/{entity_type}/{entity_id}")
async def get_audit_logs(
    entity_type: str,
    entity_id: str,
    limit: int = 100,
    db: AsyncSession = Depends(get_db)
):
    """Get audit logs for entity"""
    result = await db.execute(
        select(AuditLog)
        .where(AuditLog.entity_type == entity_type)
        .where(AuditLog.entity_id == entity_id)
        .order_by(AuditLog.created_at.desc())
        .limit(limit)
    )
    logs = result.scalars().all()

    return [
        {
            "id": l.id,
            "action": l.action,
            "user_id": l.user_id,
            "before_state": l.before_state,
            "after_state": l.after_state,
            "created_at": l.created_at.isoformat() if l.created_at else None
        }
        for l in logs
    ]
