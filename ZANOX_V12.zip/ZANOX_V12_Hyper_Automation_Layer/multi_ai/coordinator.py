"""ZANOX V12 Multi-AI Coordinator - Orchestrates Multiple AI Systems"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime
import uuid
import logging

from shared.database import get_db
from shared.models import ConnectorRegistry, IntegrationRegistry, PlatformType
from connector_registry.registry import connector_manager
from shared.config import config

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v12/multi-ai", tags=["Multi-AI Coordinator"])

class AIRequest(BaseModel):
    """Request to AI system"""
    request_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    prompt: str
    platform: Optional[str] = None  # Auto-select if not specified
    model: Optional[str] = None
    system_prompt: Optional[str] = None
    temperature: float = 0.7
    max_tokens: int = 2000
    context: Optional[Dict[str, Any]] = {}
    priority: int = 5

class AIResult(BaseModel):
    """Result from AI execution"""
    request_id: str
    platform: str
    model: str
    status: str
    content: Optional[str]
    error: Optional[str]
    duration_ms: float
    tokens_input: int = 0
    tokens_output: int = 0
    cost_usd: float = 0.0

class MultiAICoordinator:
    """Coordinates AI requests across multiple AI systems with intelligent routing"""

    AI_MODELS = {
        "chatgpt": {"models": ["gpt-4o", "gpt-4-turbo", "gpt-3.5-turbo"], "cost_per_1k_input": 0.005, "cost_per_1k_output": 0.015},
        "claude": {"models": ["claude-3-5-sonnet-20241022", "claude-3-opus-20240229", "claude-3-haiku-20240307"], "cost_per_1k_input": 0.003, "cost_per_1k_output": 0.015},
        "gemini": {"models": ["gemini-1.5-pro", "gemini-1.5-flash"], "cost_per_1k_input": 0.00125, "cost_per_1k_output": 0.005},
        "grok": {"models": ["grok-1", "grok-1.5"], "cost_per_1k_input": 0.005, "cost_per_1k_output": 0.015},
        "kimi": {"models": ["kimi-moonshot-v1-128k", "kimi-moonshot-v1-32k"], "cost_per_1k_input": 0.003, "cost_per_1k_output": 0.009},
        "perplexity": {"models": ["llama-3.1-sonar-large-128k-online"], "cost_per_1k_input": 0.001, "cost_per_1k_output": 0.001},
        "qwen": {"models": ["qwen-max", "qwen-plus", "qwen-turbo"], "cost_per_1k_input": 0.002, "cost_per_1k_output": 0.006},
        "deepseek": {"models": ["deepseek-chat", "deepseek-coder"], "cost_per_1k_input": 0.00014, "cost_per_1k_output": 0.00028},
        "mistral": {"models": ["mistral-large-latest", "mistral-medium-latest"], "cost_per_1k_input": 0.002, "cost_per_1k_output": 0.006},
        "openrouter": {"models": ["openai/gpt-4o", "anthropic/claude-3.5-sonnet"], "cost_per_1k_input": 0.005, "cost_per_1k_output": 0.015}
    }

    def __init__(self):
        self._request_history: Dict[str, List[AIResult]] = {}

    async def _get_ai_connector(self, db: AsyncSession, platform: str) -> Optional[ConnectorRegistry]:
        """Get active connector for AI platform"""
        result = await db.execute(
            select(ConnectorRegistry)
            .join(IntegrationRegistry)
            .where(IntegrationRegistry.provider == platform)
            .where(IntegrationRegistry.platform_type == PlatformType.AI)
            .where(ConnectorRegistry.status == "active")
        )
        return result.scalar_one_or_none()

    async def select_platform(self, db: AsyncSession, request: AIRequest) -> str:
        """Intelligently select best AI platform"""
        if request.platform:
            connector = await self._get_ai_connector(db, request.platform)
            if connector:
                return request.platform
            raise HTTPException(status_code=400, detail=f"AI platform {request.platform} not available")

        # Scoring system
        scores = {}
        for platform, info in self.AI_MODELS.items():
            connector = await self._get_ai_connector(db, platform)
            if not connector:
                continue

            score = 100

            # Cost efficiency (lower cost = higher score)
            avg_cost = (info["cost_per_1k_input"] + info["cost_per_1k_output"]) / 2
            score -= avg_cost * 1000

            # Health score
            score += (connector.error_rate * -100)

            # Response time
            if connector.response_time_ms:
                score -= connector.response_time_ms / 10

            scores[platform] = score

        if not scores:
            raise HTTPException(status_code=503, detail="No AI platforms available")

        best_platform = max(scores, key=scores.get)
        logger.info(f"Auto-selected AI platform: {best_platform} (score: {scores[best_platform]:.2f})")
        return best_platform

    async def execute(self, db: AsyncSession, request: AIRequest) -> AIResult:
        """Execute AI request"""
        platform = await self.select_platform(db, request)
        connector = await self._get_ai_connector(db, platform)

        if not connector:
            return AIResult(
                request_id=request.request_id,
                platform=platform,
                model=request.model or "default",
                status="failed",
                content=None,
                error="Connector not available",
                duration_ms=0,
                tokens_input=0,
                tokens_output=0,
                cost_usd=0
            )

        start_time = datetime.utcnow()

        # Build platform-specific payload
        payload = self._build_payload(platform, request)

        try:
            result = await connector_manager.execute_connector(
                db, connector.id, "POST", "chat/completions", payload
            )

            duration_ms = (datetime.utcnow() - start_time).total_seconds() * 1000

            if result.get("success"):
                body = result.get("body", {})
                content = self._extract_content(platform, body)
                usage = body.get("usage", {})
                tokens_in = usage.get("prompt_tokens", 0) or usage.get("input_tokens", 0)
                tokens_out = usage.get("completion_tokens", 0) or usage.get("output_tokens", 0)

                # Calculate cost
                cost = self._calculate_cost(platform, tokens_in, tokens_out)

                return AIResult(
                    request_id=request.request_id,
                    platform=platform,
                    model=request.model or body.get("model", "unknown"),
                    status="completed",
                    content=content,
                    error=None,
                    duration_ms=duration_ms,
                    tokens_input=tokens_in,
                    tokens_output=tokens_out,
                    cost_usd=cost
                )
            else:
                return AIResult(
                    request_id=request.request_id,
                    platform=platform,
                    model=request.model or "unknown",
                    status="failed",
                    content=None,
                    error=result.get("error", "Unknown error"),
                    duration_ms=duration_ms,
                    tokens_input=0,
                    tokens_output=0,
                    cost_usd=0
                )
        except Exception as e:
            duration_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            return AIResult(
                request_id=request.request_id,
                platform=platform,
                model=request.model or "unknown",
                status="failed",
                content=None,
                error=str(e),
                duration_ms=duration_ms,
                tokens_input=0,
                tokens_output=0,
                cost_usd=0
            )

    def _build_payload(self, platform: str, request: AIRequest) -> Dict[str, Any]:
        """Build platform-specific API payload"""
        model = request.model or self.AI_MODELS.get(platform, {}).get("models", ["default"])[0]

        messages = []
        if request.system_prompt:
            messages.append({"role": "system", "content": request.system_prompt})

        messages.append({"role": "user", "content": request.prompt})

        return {
            "model": model,
            "messages": messages,
            "temperature": request.temperature,
            "max_tokens": request.max_tokens
        }

    def _extract_content(self, platform: str, body: Dict) -> Optional[str]:
        """Extract content from API response"""
        if "choices" in body:
            choices = body["choices"]
            if choices:
                return choices[0].get("message", {}).get("content", "")
        elif "content" in body:
            return body["content"]
        elif "response" in body:
            return body["response"]
        return str(body)

    def _calculate_cost(self, platform: str, tokens_in: int, tokens_out: int) -> float:
        """Calculate cost in USD"""
        info = self.AI_MODELS.get(platform, {})
        cost_in = (tokens_in / 1000) * info.get("cost_per_1k_input", 0)
        cost_out = (tokens_out / 1000) * info.get("cost_per_1k_output", 0)
        return round(cost_in + cost_out, 6)

    async def compare_models(self, db: AsyncSession, prompt: str, 
                            platforms: Optional[List[str]] = None) -> List[AIResult]:
        """Execute same prompt across multiple AI platforms for comparison"""
        if not platforms:
            platforms = list(self.AI_MODELS.keys())

        requests = [
            AIRequest(prompt=prompt, platform=p)
            for p in platforms
        ]

        import asyncio
        results = await asyncio.gather(*[self.execute(db, req) for req in requests])
        return list(results)

multi_ai_coordinator = MultiAICoordinator()

# API Endpoints
@router.post("/execute")
async def execute_ai_request(request: AIRequest, db: AsyncSession = Depends(get_db)):
    """Execute AI request with auto-routing"""
    result = await multi_ai_coordinator.execute(db, request)
    return result.dict()

@router.post("/compare")
async def compare_ai_models(
    prompt: str,
    platforms: Optional[List[str]] = None,
    db: AsyncSession = Depends(get_db)
):
    """Compare AI model responses"""
    results = await multi_ai_coordinator.compare_models(db, prompt, platforms)
    return {
        "prompt": prompt,
        "comparisons": [r.dict() for r in results],
        "best_by_cost": min(results, key=lambda x: x.cost_usd).dict() if results else None,
        "best_by_speed": min(results, key=lambda x: x.duration_ms).dict() if results else None
    }

@router.get("/platforms")
async def get_ai_platforms(db: AsyncSession = Depends(get_db)):
    """Get all available AI platforms with pricing"""
    status = {}
    for platform, info in multi_ai_coordinator.AI_MODELS.items():
        connector = await multi_ai_coordinator._get_ai_connector(db, platform)
        status[platform] = {
            "available": connector is not None,
            "models": info["models"],
            "cost_per_1k_input": info["cost_per_1k_input"],
            "cost_per_1k_output": info["cost_per_1k_output"],
            "connector_status": connector.status.value if connector else "unavailable",
            "error_rate": connector.error_rate if connector else None
        }
    return status
