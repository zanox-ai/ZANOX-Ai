"""ZANOX V12 Connector Lifecycle Manager"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime
import uuid
import logging

from shared.database import get_db
from shared.models import ConnectorRegistry, ConnectorStatus
from connector_registry.registry import connector_manager

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v12/connector-lifecycle", tags=["Connector Lifecycle"])

class LifecycleAction(BaseModel):
    """Lifecycle action"""
    action: str  # create, activate, deactivate, update, deprecate, delete
    connector_id: Optional[str] = None
    config: Optional[Dict[str, Any]] = None

class ConnectorLifecycleManager:
    """Manages connector lifecycle states"""

    async def transition(self, db: AsyncSession, connector_id: str,
                      new_status: ConnectorStatus) -> Dict[str, Any]:
        """Transition connector to new status"""
        connector = await db.get(ConnectorRegistry, connector_id)
        if not connector:
            raise HTTPException(status_code=404, detail="Connector not found")

        old_status = connector.status
        connector.status = new_status
        connector.updated_at = datetime.utcnow()

        await db.commit()

        logger.info(f"Connector {connector_id} transitioned: {old_status} -> {new_status}")

        return {
            "connector_id": connector_id,
            "old_status": old_status.value,
            "new_status": new_status.value,
            "transitioned_at": datetime.utcnow().isoformat()
        }

    async def get_lifecycle(self, db: AsyncSession, 
                           connector_id: str) -> Dict[str, Any]:
        """Get connector lifecycle info"""
        connector = await db.get(ConnectorRegistry, connector_id)
        if not connector:
            raise HTTPException(status_code=404, detail="Connector not found")

        return {
            "connector_id": connector_id,
            "name": connector.name,
            "status": connector.status.value,
            "version": connector.version,
            "created_at": connector.created_at.isoformat() if connector.created_at else None,
            "updated_at": connector.updated_at.isoformat() if connector.updated_at else None,
            "failure_count": connector.failure_count,
            "request_count": connector.request_count
        }

lifecycle_manager = ConnectorLifecycleManager()

@router.post("/transition/{connector_id}")
async def transition_connector(
    connector_id: str,
    new_status: ConnectorStatus,
    db: AsyncSession = Depends(get_db)
):
    """Transition connector status"""
    return await lifecycle_manager.transition(db, connector_id, new_status)

@router.get("/{connector_id}")
async def get_lifecycle(connector_id: str, db: AsyncSession = Depends(get_db)):
    """Get connector lifecycle"""
    return await lifecycle_manager.get_lifecycle(db, connector_id)
