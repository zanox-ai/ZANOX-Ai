# ZANOX V12 Connector Lifecycle
