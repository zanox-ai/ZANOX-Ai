# ZANOX V12 Config
