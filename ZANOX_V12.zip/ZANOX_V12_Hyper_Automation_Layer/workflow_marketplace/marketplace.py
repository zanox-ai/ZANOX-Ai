"""ZANOX V12 Workflow Marketplace - Share & Discover Workflows"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, or_, func
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime
import uuid
import logging

from shared.database import get_db
from shared.models import WorkflowDefinition

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v12/workflow-marketplace", tags=["Workflow Marketplace"])

class WorkflowListing(BaseModel):
    """Workflow listing"""
    workflow_id: str
    publisher: str
    description: str
    tags: List[str] = []
    category: str = "general"
    is_premium: bool = False
    price_usd: float = 0.0

class WorkflowMarketplace:
    """Workflow sharing and discovery"""

    async def publish(self, db: AsyncSession, listing: WorkflowListing) -> Dict[str, Any]:
        """Publish workflow to marketplace"""
        workflow = await db.get(WorkflowDefinition, listing.workflow_id)
        if not workflow:
            raise HTTPException(status_code=404, detail="Workflow not found")

        workflow.is_public = True
        workflow.category = listing.category
        workflow.tags = listing.tags
        await db.commit()

        return {
            "workflow_id": listing.workflow_id,
            "publisher": listing.publisher,
            "status": "published",
            "category": listing.category
        }

    async def search(self, db: AsyncSession,
                    query: Optional[str] = None,
                    category: Optional[str] = None,
                    tags: Optional[List[str]] = None) -> List[Dict[str, Any]]:
        """Search marketplace workflows"""
        sql = select(WorkflowDefinition).where(WorkflowDefinition.is_public == True)

        if query:
            sql = sql.where(
                or_(
                    WorkflowDefinition.name.ilike(f"%{query}%"),
                    WorkflowDefinition.description.ilike(f"%{query}%")
                )
            )

        if category:
            sql = sql.where(WorkflowDefinition.category == category)

        if tags:
            sql = sql.where(WorkflowDefinition.tags.overlap(tags))

        result = await db.execute(sql.order_by(WorkflowDefinition.usage_count.desc()))
        workflows = result.scalars().all()

        return [
            {
                "id": w.id,
                "name": w.name,
                "description": w.description,
                "category": w.category,
                "tags": w.tags,
                "usage_count": w.usage_count,
                "success_rate": w.success_rate,
                "version": w.version
            }
            for w in workflows
        ]

    async def install(self, db: AsyncSession, workflow_id: str,
                     owner_id: str) -> Dict[str, Any]:
        """Install workflow from marketplace"""
        from workflow_orchestrator.orchestrator import orchestrator

        cloned = await orchestrator.clone_workflow(db, workflow_id, 
                                                   f"Installed Workflow", owner_id)
        return {
            "workflow_id": cloned.id,
            "name": cloned.name,
            "status": "installed"
        }

marketplace = WorkflowMarketplace()

@router.post("/publish")
async def publish_workflow(listing: WorkflowListing, db: AsyncSession = Depends(get_db)):
    """Publish workflow"""
    return await marketplace.publish(db, listing)

@router.get("/search")
async def search_workflows(
    query: Optional[str] = None,
    category: Optional[str] = None,
    tags: Optional[List[str]] = None,
    db: AsyncSession = Depends(get_db)
):
    """Search workflows"""
    return await marketplace.search(db, query, category, tags)

@router.post("/install/{workflow_id}")
async def install_workflow(workflow_id: str, owner_id: str, db: AsyncSession = Depends(get_db)):
    """Install workflow"""
    return await marketplace.install(db, workflow_id, owner_id)
