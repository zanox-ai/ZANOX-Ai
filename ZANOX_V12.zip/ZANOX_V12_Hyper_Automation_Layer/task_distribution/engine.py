"""ZANOX V12 Task Distribution Engine - Intelligent Load Balancing"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, func
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime
import uuid
import logging
import asyncio

from shared.database import get_db
from shared.models import ConnectorRegistry, IntegrationRegistry, TaskRecord, TaskStatus
from shared.redis_client import redis_client
from shared.config import config

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v12/task-distribution", tags=["Task Distribution"])

class DistributionTask(BaseModel):
    task_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    task_type: str
    platform_type: str  # ai, automation, agent, builder, backend, devops, creative
    payload: Dict[str, Any] = {}
    priority: int = 5
    required_capabilities: List[str] = []
    cost_budget: Optional[float] = None
    max_latency_ms: Optional[int] = None

class DistributionResult(BaseModel):
    task_id: str
    assigned_platform: str
    assigned_connector: str
    strategy: str
    estimated_cost: float
    estimated_latency_ms: int
    status: str

class TaskDistributionEngine:
    """Intelligent task distribution with load balancing and cost optimization"""

    def __init__(self):
        self._platform_scores: Dict[str, Dict] = {}

    async def _get_available_connectors(self, db: AsyncSession, platform_type: str) -> List[ConnectorRegistry]:
        """Get all active connectors for platform type"""
        result = await db.execute(
            select(ConnectorRegistry)
            .join(IntegrationRegistry)
            .where(IntegrationRegistry.platform_type == platform_type)
            .where(ConnectorRegistry.status == "active")
        )
        return result.scalars().all()

    async def _calculate_platform_score(self, connector: ConnectorRegistry, 
                                        task: DistributionTask) -> float:
        """Calculate suitability score for platform"""
        score = 100.0

        # Health penalty
        score -= connector.error_rate * 200

        # Response time penalty
        if connector.response_time_ms:
            score -= connector.response_time_ms / 10

        # Failure penalty
        score -= connector.failure_count * 5

        # Load penalty (request count)
        score -= connector.request_count / 1000

        # Capability match bonus
        integration = await connector.awaitable_attrs.integration
        capabilities = integration.capabilities or []
        for cap in task.required_capabilities:
            if cap in capabilities:
                score += 20

        # Cost check
        if task.cost_budget is not None:
            # Estimate cost (simplified)
            estimated = await self._estimate_cost(connector, task)
            if estimated > task.cost_budget:
                score -= 50

        # Latency check
        if task.max_latency_ms is not None and connector.response_time_ms:
            if connector.response_time_ms > task.max_latency_ms:
                score -= 50

        return max(score, 0)

    async def _estimate_cost(self, connector: ConnectorRegistry, task: DistributionTask) -> float:
        """Estimate cost for task on platform"""
        integration = await connector.awaitable_attrs.integration
        pricing = integration.pricing_tier or "free"

        if pricing == "free":
            return 0.0

        # Base cost estimation
        base_cost = 0.01
        if task.task_type == "ai_call":
            base_cost = 0.05
        elif task.task_type == "automation_trigger":
            base_cost = 0.02
        elif task.task_type == "builder_deploy":
            base_cost = 0.10

        return base_cost

    async def distribute(self, db: AsyncSession, task: DistributionTask) -> DistributionResult:
        """Distribute task to best available platform"""
        connectors = await self._get_available_connectors(db, task.platform_type)

        if not connectors:
            raise HTTPException(status_code=503, 
                            detail=f"No available platforms for type: {task.platform_type}")

        # Score all platforms
        scored = []
        for connector in connectors:
            score = await self._calculate_platform_score(connector, task)
            integration = await connector.awaitable_attrs.integration
            scored.append((connector, integration.provider, score))

        # Sort by score descending
        scored.sort(key=lambda x: x[2], reverse=True)

        best = scored[0]
        connector, platform, score = best

        estimated_cost = await self._estimate_cost(connector, task)
        estimated_latency = connector.response_time_ms or 1000

        logger.info(f"Distributed task {task.task_id} to {platform} (score: {score:.2f})")

        return DistributionResult(
            task_id=task.task_id,
            assigned_platform=platform,
            assigned_connector=connector.id,
            strategy="score_based",
            estimated_cost=estimated_cost,
            estimated_latency_ms=int(estimated_latency),
            status="assigned"
        )

    async def distribute_batch(self, db: AsyncSession, 
                               tasks: List[DistributionTask]) -> List[DistributionResult]:
        """Distribute multiple tasks with global optimization"""
        results = []

        # Group by platform type for batch optimization
        by_type = {}
        for task in tasks:
            if task.platform_type not in by_type:
                by_type[task.platform_type] = []
            by_type[task.platform_type].append(task)

        # Distribute each group
        for platform_type, task_group in by_type.items():
            connectors = await self._get_available_connectors(db, platform_type)

            # Round-robin distribution for load balancing
            for i, task in enumerate(task_group):
                if not connectors:
                    results.append(DistributionResult(
                        task_id=task.task_id,
                        assigned_platform="none",
                        assigned_connector="none",
                        strategy="failed",
                        estimated_cost=0,
                        estimated_latency_ms=0,
                        status="failed"
                    ))
                    continue

                connector = connectors[i % len(connectors)]
                integration = await connector.awaitable_attrs.integration

                estimated_cost = await self._estimate_cost(connector, task)
                estimated_latency = connector.response_time_ms or 1000

                results.append(DistributionResult(
                    task_id=task.task_id,
                    assigned_platform=integration.provider,
                    assigned_connector=connector.id,
                    strategy="round_robin",
                    estimated_cost=estimated_cost,
                    estimated_latency_ms=int(estimated_latency),
                    status="assigned"
                ))

        return results

    async def get_distribution_stats(self, db: AsyncSession) -> Dict[str, Any]:
        """Get distribution statistics"""
        result = await db.execute(
            select(TaskRecord.platform, func.count(TaskRecord.id), func.avg(TaskRecord.duration_ms))
            .group_by(TaskRecord.platform)
        )
        stats = result.all()

        return {
            "platform_distribution": [
                {
                    "platform": s[0] or "unknown",
                    "task_count": s[1],
                    "avg_duration_ms": round(s[2] or 0, 2)
                }
                for s in stats
            ]
        }

task_distribution_engine = TaskDistributionEngine()

# API Endpoints
@router.post("/distribute")
async def distribute_task(task: DistributionTask, db: AsyncSession = Depends(get_db)):
    """Distribute single task"""
    result = await task_distribution_engine.distribute(db, task)
    return result.dict()

@router.post("/distribute-batch")
async def distribute_batch(tasks: List[DistributionTask], db: AsyncSession = Depends(get_db)):
    """Distribute batch of tasks"""
    results = await task_distribution_engine.distribute_batch(db, tasks)
    return {"results": [r.dict() for r in results]}

@router.get("/stats")
async def get_distribution_stats(db: AsyncSession = Depends(get_db)):
    """Get distribution statistics"""
    return await task_distribution_engine.get_distribution_stats(db)
