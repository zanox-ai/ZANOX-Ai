"""ZANOX V12 Analytics Layer - Integration Analytics"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_, or_, between
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime, timedelta
import uuid
import logging

from shared.database import get_db
from shared.models import (
    WorkflowExecution, WorkflowDefinition, TaskRecord, CostRecord,
    ConnectorRegistry, IntegrationRegistry, EventRecord, HealthCheck
)
from shared.redis_client import redis_client

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v12/analytics", tags=["Analytics"])

class AnalyticsDashboard(BaseModel):
    """Analytics dashboard data"""
    period: str
    total_executions: int
    success_rate: float
    total_cost: float
    avg_duration: float
    platform_usage: Dict[str, Any]
    top_workflows: List[Dict[str, Any]]
    trends: Dict[str, Any]

class AnalyticsEngine:
    """Comprehensive analytics for ZANOX operations"""

    async def get_dashboard(self, db: AsyncSession, 
                           days: int = 7) -> AnalyticsDashboard:
        """Get analytics dashboard"""
        end = datetime.utcnow()
        start = end - timedelta(days=days)

        # Total executions
        exec_result = await db.execute(
            select(func.count(WorkflowExecution.id))
            .where(WorkflowExecution.started_at >= start)
        )
        total_executions = exec_result.scalar() or 0

        # Success rate
        success_result = await db.execute(
            select(func.count(WorkflowExecution.id))
            .where(WorkflowExecution.started_at >= start)
            .where(WorkflowExecution.status == "completed")
        )
        success_count = success_result.scalar() or 0
        success_rate = (success_count / max(total_executions, 1)) * 100

        # Total cost
        cost_result = await db.execute(
            select(func.sum(CostRecord.cost_usd))
            .where(CostRecord.created_at >= start)
        )
        total_cost = cost_result.scalar() or 0.0

        # Average duration
        duration_result = await db.execute(
            select(func.avg(WorkflowExecution.duration_ms))
            .where(WorkflowExecution.started_at >= start)
        )
        avg_duration = duration_result.scalar() or 0.0

        # Platform usage
        platform_result = await db.execute(
            select(TaskRecord.platform, func.count(TaskRecord.id), func.avg(TaskRecord.duration_ms))
            .where(TaskRecord.started_at >= start)
            .group_by(TaskRecord.platform)
        )
        platform_usage = {}
        for platform, count, avg_dur in platform_result.all():
            platform_usage[platform or "unknown"] = {
                "count": count,
                "avg_duration_ms": round(avg_dur or 0, 2)
            }

        # Top workflows
        top_result = await db.execute(
            select(WorkflowDefinition.name, func.count(WorkflowExecution.id))
            .join(WorkflowExecution)
            .where(WorkflowExecution.started_at >= start)
            .group_by(WorkflowDefinition.name)
            .order_by(func.count(WorkflowExecution.id).desc())
            .limit(10)
        )
        top_workflows = [
            {"name": name, "executions": count}
            for name, count in top_result.all()
        ]

        # Daily trends
        trends = {}
        for i in range(days):
            day_start = start + timedelta(days=i)
            day_end = day_start + timedelta(days=1)

            day_exec = await db.execute(
                select(func.count(WorkflowExecution.id))
                .where(WorkflowExecution.started_at >= day_start)
                .where(WorkflowExecution.started_at < day_end)
            )
            day_cost = await db.execute(
                select(func.sum(CostRecord.cost_usd))
                .where(CostRecord.created_at >= day_start)
                .where(CostRecord.created_at < day_end)
            )

            trends[day_start.strftime("%Y-%m-%d")] = {
                "executions": day_exec.scalar() or 0,
                "cost": round(day_cost.scalar() or 0, 4)
            }

        return AnalyticsDashboard(
            period=f"{start.date()} to {end.date()}",
            total_executions=total_executions,
            success_rate=round(success_rate, 2),
            total_cost=round(total_cost, 4),
            avg_duration=round(avg_duration, 2),
            platform_usage=platform_usage,
            top_workflows=top_workflows,
            trends=trends
        )

    async def get_connector_analytics(self, db: AsyncSession,
                                      connector_id: Optional[str] = None) -> Dict[str, Any]:
        """Get connector analytics"""
        query = select(ConnectorRegistry)
        if connector_id:
            query = query.where(ConnectorRegistry.id == connector_id)

        result = await db.execute(query)
        connectors = result.scalars().all()

        return {
            "connectors": [
                {
                    "id": c.id,
                    "name": c.name,
                    "status": c.status.value,
                    "request_count": c.request_count,
                    "error_rate": round(c.error_rate, 4),
                    "response_time_ms": round(c.response_time_ms or 0, 2),
                    "failure_count": c.failure_count,
                    "last_success": c.last_success.isoformat() if c.last_success else None,
                    "last_failure": c.last_failure.isoformat() if c.last_failure else None
                }
                for c in connectors
            ]
        }

    async def get_cost_analytics(self, db: AsyncSession,
                                 days: int = 30) -> Dict[str, Any]:
        """Get cost analytics"""
        end = datetime.utcnow()
        start = end - timedelta(days=days)

        # Daily costs
        daily_costs = {}
        for i in range(days):
            day = start + timedelta(days=i)
            next_day = day + timedelta(days=1)

            result = await db.execute(
                select(func.sum(CostRecord.cost_usd))
                .where(CostRecord.created_at >= day)
                .where(CostRecord.created_at < next_day)
            )
            daily_costs[day.strftime("%Y-%m-%d")] = round(result.scalar() or 0, 4)

        # Platform costs
        platform_result = await db.execute(
            select(CostRecord.platform, func.sum(CostRecord.cost_usd))
            .where(CostRecord.created_at >= start)
            .group_by(CostRecord.platform)
        )
        platform_costs = {p: round(c, 4) for p, c in platform_result.all()}

        return {
            "period": f"{start.date()} to {end.date()}",
            "daily_costs": daily_costs,
            "platform_costs": platform_costs,
            "total": round(sum(daily_costs.values()), 4)
        }

analytics_engine = AnalyticsEngine()

@router.get("/dashboard")
async def get_dashboard(days: int = 7, db: AsyncSession = Depends(get_db)):
    """Get analytics dashboard"""
    dashboard = await analytics_engine.get_dashboard(db, days)
    return dashboard.dict()

@router.get("/connectors")
async def get_connector_analytics(
    connector_id: Optional[str] = None,
    db: AsyncSession = Depends(get_db)
):
    """Get connector analytics"""
    return await analytics_engine.get_connector_analytics(db, connector_id)

@router.get("/costs")
async def get_cost_analytics(days: int = 30, db: AsyncSession = Depends(get_db)):
    """Get cost analytics"""
    return await analytics_engine.get_cost_analytics(db, days)
