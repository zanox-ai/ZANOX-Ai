"""ZANOX V12 Connector Monitoring - Real-time Connector Health"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime, timedelta
import uuid
import logging

from shared.database import get_db
from shared.models import ConnectorRegistry, HealthCheck
from connector_registry.registry import connector_manager

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v12/connector-monitoring", tags=["Connector Monitoring"])

class MonitoringDashboard(BaseModel):
    """Monitoring dashboard"""
    total_connectors: int
    healthy: int
    degraded: int
    unhealthy: int
    avg_response_time: float
    error_rate: float

class ConnectorMonitoringEngine:
    """Real-time connector monitoring"""

    async def get_dashboard(self, db: AsyncSession) -> MonitoringDashboard:
        """Get monitoring dashboard"""
        total = await db.execute(select(func.count(ConnectorRegistry.id)))
        total_count = total.scalar() or 0

        healthy = await db.execute(
            select(func.count(ConnectorRegistry.id))
            .where(ConnectorRegistry.status == "active")
            .where(ConnectorRegistry.error_rate < 0.05)
        )
        healthy_count = healthy.scalar() or 0

        degraded = await db.execute(
            select(func.count(ConnectorRegistry.id))
            .where(ConnectorRegistry.status == "active")
            .where(ConnectorRegistry.error_rate >= 0.05)
            .where(ConnectorRegistry.error_rate < 0.2)
        )
        degraded_count = degraded.scalar() or 0

        unhealthy = await db.execute(
            select(func.count(ConnectorRegistry.id))
            .where(ConnectorRegistry.status == "error")
        )
        unhealthy_count = unhealthy.scalar() or 0

        avg_response = await db.execute(
            select(func.avg(ConnectorRegistry.response_time_ms))
            .where(ConnectorRegistry.status == "active")
        )
        avg_response_time = avg_response.scalar() or 0

        error_rate = await db.execute(
            select(func.avg(ConnectorRegistry.error_rate))
        )
        avg_error_rate = error_rate.scalar() or 0

        return MonitoringDashboard(
            total_connectors=total_count,
            healthy=healthy_count,
            degraded=degraded_count,
            unhealthy=unhealthy_count,
            avg_response_time=round(avg_response_time, 2),
            error_rate=round(avg_error_rate, 4)
        )

    async def get_connector_metrics(self, db: AsyncSession, 
                                   connector_id: str) -> Dict[str, Any]:
        """Get detailed metrics for connector"""
        connector = await db.get(ConnectorRegistry, connector_id)
        if not connector:
            raise HTTPException(status_code=404, detail="Connector not found")

        # Get recent health checks
        result = await db.execute(
            select(HealthCheck)
            .where(HealthCheck.connector_id == connector_id)
            .order_by(HealthCheck.checked_at.desc())
            .limit(50)
        )
        checks = result.scalars().all()

        return {
            "connector_id": connector_id,
            "name": connector.name,
            "status": connector.status.value,
            "request_count": connector.request_count,
            "failure_count": connector.failure_count,
            "error_rate": round(connector.error_rate, 4),
            "response_time_ms": round(connector.response_time_ms or 0, 2),
            "last_success": connector.last_success.isoformat() if connector.last_success else None,
            "last_failure": connector.last_failure.isoformat() if connector.last_failure else None,
            "health_checks": [
                {
                    "status": c.status,
                    "http_status": c.http_status,
                    "checked_at": c.checked_at.isoformat() if c.checked_at else None
                }
                for c in checks
            ]
        }

monitoring_engine = ConnectorMonitoringEngine()

@router.get("/dashboard")
async def get_dashboard(db: AsyncSession = Depends(get_db)):
    """Get monitoring dashboard"""
    dashboard = await monitoring_engine.get_dashboard(db)
    return dashboard.dict()

@router.get("/metrics/{connector_id}")
async def get_connector_metrics(connector_id: str, db: AsyncSession = Depends(get_db)):
    """Get connector metrics"""
    return await monitoring_engine.get_connector_metrics(db, connector_id)
