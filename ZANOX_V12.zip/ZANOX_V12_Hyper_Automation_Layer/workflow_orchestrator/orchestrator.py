"""ZANOX V12 Workflow Orchestrator - Advanced Workflow Management"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, and_, or_, func
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime, timedelta
import uuid
import logging
import asyncio

from shared.database import get_db
from shared.models import WorkflowDefinition, WorkflowExecution, WorkflowStatus, TaskRecord
from shared.redis_client import redis_client
from automation_engine.engine import automation_engine, TaskNode, WorkflowGraph

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v12/workflows", tags=["Workflow Orchestrator"])

class WorkflowCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    description: Optional[str] = None
    definition: Dict[str, Any]  # Workflow graph definition
    triggers: Optional[List[Dict[str, Any]]] = []
    variables: Optional[Dict[str, Any]] = {}
    inputs: Optional[Dict[str, Any]] = {}
    outputs: Optional[Dict[str, Any]] = {}
    category: Optional[str] = "general"
    tags: Optional[List[str]] = []
    is_public: bool = False
    is_template: bool = False

class WorkflowUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    definition: Optional[Dict[str, Any]] = None
    triggers: Optional[List[Dict[str, Any]]] = None
    variables: Optional[Dict[str, Any]] = None
    category: Optional[str] = None
    tags: Optional[List[str]] = None
    is_public: Optional[bool] = None

class WorkflowOrchestrator:
    """Advanced workflow orchestration with scheduling, dependencies, and optimization"""

    def __init__(self):
        self._scheduled_workflows: Dict[str, asyncio.Task] = {}

    async def create_workflow(self, db: AsyncSession, owner_id: str, data: WorkflowCreate) -> WorkflowDefinition:
        """Create new workflow definition"""
        # Validate workflow graph
        self._validate_graph(data.definition)

        workflow = WorkflowDefinition(
            id=str(uuid.uuid4()),
            name=data.name,
            description=data.description,
            version="1.0.0",
            definition=data.definition,
            triggers=data.triggers or [],
            variables=data.variables or {},
            inputs=data.inputs or {},
            outputs=data.outputs or {},
            owner_id=owner_id,
            is_public=data.is_public,
            is_template=data.is_template,
            category=data.category or "general",
            tags=data.tags or []
        )
        db.add(workflow)
        await db.commit()
        await db.refresh(workflow)
        logger.info(f"Created workflow: {workflow.name} ({workflow.id})")
        return workflow

    def _validate_graph(self, definition: Dict[str, Any]):
        """Validate workflow graph structure"""
        nodes = definition.get("nodes", [])
        edges = definition.get("edges", [])

        if not nodes:
            raise HTTPException(status_code=400, detail="Workflow must have at least one node")

        node_ids = {n["id"] for n in nodes}

        # Check all edges reference valid nodes
        for edge in edges:
            if edge.get("from") not in node_ids:
                raise HTTPException(status_code=400, detail=f"Edge references unknown node: {edge.get('from')}")
            if edge.get("to") not in node_ids:
                raise HTTPException(status_code=400, detail=f"Edge references unknown node: {edge.get('to')}")

        # Check for cycles using DFS
        adjacency = {n["id"]: [] for n in nodes}
        for edge in edges:
            adjacency[edge["from"]].append(edge["to"])

        visited = set()
        rec_stack = set()

        def has_cycle(node_id):
            visited.add(node_id)
            rec_stack.add(node_id)
            for neighbor in adjacency.get(node_id, []):
                if neighbor not in visited:
                    if has_cycle(neighbor):
                        return True
                elif neighbor in rec_stack:
                    return True
            rec_stack.remove(node_id)
            return False

        for node_id in node_ids:
            if node_id not in visited:
                if has_cycle(node_id):
                    raise HTTPException(status_code=400, detail="Workflow graph contains cycles")

    async def schedule_workflow(self, db: AsyncSession, workflow_id: str, 
                               schedule: str, timezone: str = "UTC") -> Dict[str, Any]:
        """Schedule workflow for recurring execution"""
        from apscheduler.triggers.cron import CronTrigger

        try:
            trigger = CronTrigger.from_crontab(schedule, timezone=timezone)
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Invalid cron schedule: {str(e)}")

        schedule_id = str(uuid.uuid4())

        # Store schedule in Redis
        await redis_client.hset(
            f"workflow_schedule:{workflow_id}",
            schedule_id,
            json.dumps({
                "schedule": schedule,
                "timezone": timezone,
                "created_at": datetime.utcnow().isoformat()
            })
        )

        logger.info(f"Scheduled workflow {workflow_id} with cron: {schedule}")
        return {"schedule_id": schedule_id, "workflow_id": workflow_id, "cron": schedule}

    async def get_workflow_analytics(self, db: AsyncSession, workflow_id: str) -> Dict[str, Any]:
        """Get comprehensive analytics for a workflow"""
        # Execution stats
        result = await db.execute(
            select(WorkflowExecution)
            .where(WorkflowExecution.workflow_id == workflow_id)
        )
        executions = result.scalars().all()

        total = len(executions)
        completed = sum(1 for e in executions if e.status == WorkflowStatus.COMPLETED)
        failed = sum(1 for e in executions if e.status == WorkflowStatus.FAILED)

        avg_duration = sum(e.duration_ms for e in executions if e.duration_ms) / max(total, 1)
        total_cost = sum(e.cost_usd for e in executions)

        # Task breakdown
        task_result = await db.execute(
            select(TaskRecord)
            .where(TaskRecord.execution_id.in_([e.id for e in executions]))
        )
        tasks = task_result.scalars().all()

        platform_usage = {}
        for task in tasks:
            platform = task.platform or "unknown"
            if platform not in platform_usage:
                platform_usage[platform] = {"count": 0, "cost": 0, "duration": 0}
            platform_usage[platform]["count"] += 1
            platform_usage[platform]["cost"] += task.cost_usd or 0
            platform_usage[platform]["duration"] += task.duration_ms or 0

        return {
            "workflow_id": workflow_id,
            "total_executions": total,
            "success_rate": (completed / max(total, 1)) * 100,
            "failure_rate": (failed / max(total, 1)) * 100,
            "average_duration_ms": avg_duration,
            "total_cost_usd": total_cost,
            "platform_breakdown": platform_usage,
            "last_executions": [
                {
                    "id": e.id,
                    "status": e.status.value,
                    "started_at": e.started_at.isoformat() if e.started_at else None,
                    "duration_ms": e.duration_ms
                }
                for e in sorted(executions, key=lambda x: x.started_at or datetime.min, reverse=True)[:10]
            ]
        }

    async def clone_workflow(self, db: AsyncSession, workflow_id: str, 
                            new_name: str, owner_id: str) -> WorkflowDefinition:
        """Clone existing workflow"""
        original = await db.get(WorkflowDefinition, workflow_id)
        if not original:
            raise HTTPException(status_code=404, detail="Workflow not found")

        cloned = WorkflowDefinition(
            id=str(uuid.uuid4()),
            name=new_name,
            description=original.description,
            version="1.0.0",
            definition=original.definition,
            triggers=original.triggers,
            variables=original.variables,
            inputs=original.inputs,
            outputs=original.outputs,
            owner_id=owner_id,
            is_public=False,
            is_template=False,
            category=original.category,
            tags=original.tags
        )
        db.add(cloned)
        await db.commit()
        await db.refresh(cloned)
        return cloned

    async def export_workflow(self, db: AsyncSession, workflow_id: str) -> Dict[str, Any]:
        """Export workflow as portable JSON"""
        workflow = await db.get(WorkflowDefinition, workflow_id)
        if not workflow:
            raise HTTPException(status_code=404, detail="Workflow not found")

        return {
            "zanox_version": "12.0.0",
            "export_date": datetime.utcnow().isoformat(),
            "workflow": {
                "name": workflow.name,
                "description": workflow.description,
                "version": workflow.version,
                "definition": workflow.definition,
                "triggers": workflow.triggers,
                "variables": workflow.variables,
                "inputs": workflow.inputs,
                "outputs": workflow.outputs,
                "category": workflow.category,
                "tags": workflow.tags
            }
        }

    async def import_workflow(self, db: AsyncSession, owner_id: str, 
                              data: Dict[str, Any]) -> WorkflowDefinition:
        """Import workflow from portable JSON"""
        workflow_data = data.get("workflow", {})

        create_data = WorkflowCreate(
            name=workflow_data.get("name", "Imported Workflow"),
            description=workflow_data.get("description"),
            definition=workflow_data.get("definition", {}),
            triggers=workflow_data.get("triggers", []),
            variables=workflow_data.get("variables", {}),
            inputs=workflow_data.get("inputs", {}),
            outputs=workflow_data.get("outputs", {}),
            category=workflow_data.get("category", "general"),
            tags=workflow_data.get("tags", [])
        )

        return await self.create_workflow(db, owner_id, create_data)

orchestrator = WorkflowOrchestrator()

# API Endpoints
@router.post("/", response_model=Dict[str, Any])
async def create_workflow(data: WorkflowCreate, db: AsyncSession = Depends(get_db)):
    """Create new workflow"""
    workflow = await orchestrator.create_workflow(db, "system", data)
    return {"id": workflow.id, "name": workflow.name, "status": "created"}

@router.get("/", response_model=List[Dict[str, Any]])
async def list_workflows(
    category: Optional[str] = None,
    is_template: bool = False,
    db: AsyncSession = Depends(get_db)
):
    """List workflows"""
    query = select(WorkflowDefinition)
    if category:
        query = query.where(WorkflowDefinition.category == category)
    if is_template:
        query = query.where(WorkflowDefinition.is_template == True)
    result = await db.execute(query)
    workflows = result.scalars().all()
    return [
        {
            "id": w.id,
            "name": w.name,
            "category": w.category,
            "version": w.version,
            "is_public": w.is_public,
            "is_template": w.is_template,
            "usage_count": w.usage_count,
            "created_at": w.created_at.isoformat() if w.created_at else None
        }
        for w in workflows
    ]

@router.get("/{workflow_id}")
async def get_workflow(workflow_id: str, db: AsyncSession = Depends(get_db)):
    """Get workflow by ID"""
    workflow = await db.get(WorkflowDefinition, workflow_id)
    if not workflow:
        raise HTTPException(status_code=404, detail="Workflow not found")
    return {
        "id": workflow.id,
        "name": workflow.name,
        "description": workflow.description,
        "version": workflow.version,
        "definition": workflow.definition,
        "triggers": workflow.triggers,
        "variables": workflow.variables,
        "category": workflow.category,
        "tags": workflow.tags,
        "is_public": workflow.is_public,
        "is_template": workflow.is_template,
        "usage_count": workflow.usage_count,
        "success_rate": workflow.success_rate
    }

@router.put("/{workflow_id}")
async def update_workflow(workflow_id: str, data: WorkflowUpdate, db: AsyncSession = Depends(get_db)):
    """Update workflow"""
    workflow = await db.get(WorkflowDefinition, workflow_id)
    if not workflow:
        raise HTTPException(status_code=404, detail="Workflow not found")

    update_data = data.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(workflow, field, value)

    await db.commit()
    await db.refresh(workflow)
    return {"id": workflow.id, "status": "updated"}

@router.delete("/{workflow_id}")
async def delete_workflow(workflow_id: str, db: AsyncSession = Depends(get_db)):
    """Delete workflow"""
    workflow = await db.get(WorkflowDefinition, workflow_id)
    if not workflow:
        raise HTTPException(status_code=404, detail="Workflow not found")

    await db.delete(workflow)
    await db.commit()
    return {"status": "deleted", "id": workflow_id}

@router.post("/{workflow_id}/schedule")
async def schedule_workflow(
    workflow_id: str,
    schedule: str,
    timezone: str = "UTC",
    db: AsyncSession = Depends(get_db)
):
    """Schedule workflow with cron expression"""
    return await orchestrator.schedule_workflow(db, workflow_id, schedule, timezone)

@router.get("/{workflow_id}/analytics")
async def get_workflow_analytics(workflow_id: str, db: AsyncSession = Depends(get_db)):
    """Get workflow analytics"""
    return await orchestrator.get_workflow_analytics(db, workflow_id)

@router.post("/{workflow_id}/clone")
async def clone_workflow(workflow_id: str, new_name: str, db: AsyncSession = Depends(get_db)):
    """Clone workflow"""
    cloned = await orchestrator.clone_workflow(db, workflow_id, new_name, "system")
    return {"id": cloned.id, "name": cloned.name, "status": "cloned"}

@router.get("/{workflow_id}/export")
async def export_workflow(workflow_id: str, db: AsyncSession = Depends(get_db)):
    """Export workflow"""
    return await orchestrator.export_workflow(db, workflow_id)

@router.post("/import")
async def import_workflow(data: Dict[str, Any], db: AsyncSession = Depends(get_db)):
    """Import workflow"""
    imported = await orchestrator.import_workflow(db, "system", data)
    return {"id": imported.id, "name": imported.name, "status": "imported"}
