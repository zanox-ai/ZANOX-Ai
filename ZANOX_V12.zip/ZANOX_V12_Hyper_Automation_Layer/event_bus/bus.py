"""ZANOX V12 Universal Event Bus - Real-time Event Processing"""
from fastapi import APIRouter, Depends, HTTPException, WebSocket, WebSocketDisconnect
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, and_, or_
from typing import List, Optional, Dict, Any, Callable
from pydantic import BaseModel, Field
from datetime import datetime
import uuid
import logging
import asyncio
import json

from shared.database import get_db
from shared.models import EventRecord
from shared.redis_client import redis_client
from shared.config import config

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v12/event-bus", tags=["Event Bus"])

class EventPublish(BaseModel):
    """Event to publish"""
    event_type: str
    source: str
    target: Optional[str] = None
    payload: Dict[str, Any] = {}
    priority: int = 5
    correlation_id: Optional[str] = None
    causation_id: Optional[str] = None

class EventSubscription(BaseModel):
    """Event subscription"""
    subscriber_id: str
    event_types: List[str]
    source_filter: Optional[str] = None
    target_filter: Optional[str] = None

class EventBus:
    """Universal event bus with pub/sub, routing, and persistence"""

    def __init__(self):
        self._subscribers: Dict[str, List[Callable]] = {}
        self._websocket_connections: List[WebSocket] = []
        self._event_handlers: Dict[str, List[Callable]] = {}

    async def publish(self, db: AsyncSession, event: EventPublish) -> str:
        """Publish event to bus"""
        event_id = str(uuid.uuid4())

        # Persist event
        record = EventRecord(
            id=event_id,
            event_type=event.event_type,
            source=event.source,
            target=event.target,
            payload=event.payload,
            priority=event.priority,
            correlation_id=event.correlation_id,
            causation_id=event.causation_id,
            processed=False
        )
        db.add(record)
        await db.commit()

        # Publish to Redis pub/sub
        await redis_client.publish(
            f"events:{event.event_type}",
            json.dumps({
                "id": event_id,
                "type": event.event_type,
                "source": event.source,
                "payload": event.payload,
                "priority": event.priority
            })
        )

        # Notify WebSocket subscribers
        await self._notify_websocket_subscribers(event)

        # Execute registered handlers
        await self._execute_handlers(event)

        logger.info(f"Event published: {event_id} ({event.event_type})")
        return event_id

    async def _notify_websocket_subscribers(self, event: EventPublish):
        """Notify WebSocket subscribers"""
        disconnected = []
        for ws in self._websocket_connections:
            try:
                await ws.send_json({
                    "event_type": event.event_type,
                    "source": event.source,
                    "payload": event.payload,
                    "timestamp": datetime.utcnow().isoformat()
                })
            except Exception:
                disconnected.append(ws)

        for ws in disconnected:
            self._websocket_connections.remove(ws)

    async def _execute_handlers(self, event: EventPublish):
        """Execute registered event handlers"""
        handlers = self._event_handlers.get(event.event_type, [])
        for handler in handlers:
            try:
                await handler(event)
            except Exception as e:
                logger.error(f"Event handler error: {e}")

    async def subscribe(self, subscription: EventSubscription):
        """Subscribe to events"""
        for event_type in subscription.event_types:
            if event_type not in self._subscribers:
                self._subscribers[event_type] = []

        logger.info(f"Subscribed: {subscription.subscriber_id} to {subscription.event_types}")
        return {"status": "subscribed", "subscriber_id": subscription.subscriber_id}

    async def get_events(self, db: AsyncSession, 
                        event_type: Optional[str] = None,
                        source: Optional[str] = None,
                        processed: Optional[bool] = None,
                        limit: int = 100) -> List[Dict[str, Any]]:
        """Get events from bus"""
        query = select(EventRecord)

        if event_type:
            query = query.where(EventRecord.event_type == event_type)
        if source:
            query = query.where(EventRecord.source == source)
        if processed is not None:
            query = query.where(EventRecord.processed == processed)

        query = query.order_by(EventRecord.created_at.desc()).limit(limit)

        result = await db.execute(query)
        events = result.scalars().all()

        return [
            {
                "id": e.id,
                "event_type": e.event_type,
                "source": e.source,
                "target": e.target,
                "payload": e.payload,
                "priority": e.priority,
                "correlation_id": e.correlation_id,
                "processed": e.processed,
                "created_at": e.created_at.isoformat() if e.created_at else None
            }
            for e in events
        ]

    async def mark_processed(self, db: AsyncSession, event_id: str) -> bool:
        """Mark event as processed"""
        event = await db.get(EventRecord, event_id)
        if not event:
            return False

        event.processed = True
        event.processed_at = datetime.utcnow()
        await db.commit()
        return True

    async def process_pending(self, db: AsyncSession, batch_size: int = 100) -> Dict[str, Any]:
        """Process all pending events"""
        result = await db.execute(
            select(EventRecord)
            .where(EventRecord.processed == False)
            .where(EventRecord.error_count < 5)
            .order_by(EventRecord.priority.asc())
            .limit(batch_size)
        )
        events = result.scalars().all()

        processed = 0
        failed = 0

        for event in events:
            try:
                # Route to appropriate handler
                await self._route_event(db, event)
                event.processed = True
                event.processed_at = datetime.utcnow()
                processed += 1
            except Exception as e:
                event.error_count += 1
                failed += 1
                logger.error(f"Event processing failed: {e}")

        await db.commit()
        return {"processed": processed, "failed": failed, "total": len(events)}

    async def _route_event(self, db: AsyncSession, event: EventRecord):
        """Route event to appropriate destination"""
        if event.target:
            # Route to specific target
            if event.target == "workflow_engine":
                # Trigger workflow
                pass
            elif event.target == "human_approval":
                # Send to approval queue
                pass
            elif event.target == "notification":
                # Send notification
                pass

    async def websocket_endpoint(self, websocket: WebSocket):
        """WebSocket endpoint for real-time events"""
        await websocket.accept()
        self._websocket_connections.append(websocket)
        try:
            while True:
                data = await websocket.receive_text()
                message = json.loads(data)
                # Handle subscription messages
                if message.get("action") == "subscribe":
                    await self.subscribe(EventSubscription(**message.get("subscription", {})))
        except WebSocketDisconnect:
            self._websocket_connections.remove(websocket)
        except Exception:
            if websocket in self._websocket_connections:
                self._websocket_connections.remove(websocket)

event_bus = EventBus()

@router.post("/publish")
async def publish_event(event: EventPublish, db: AsyncSession = Depends(get_db)):
    """Publish event to bus"""
    event_id = await event_bus.publish(db, event)
    return {"event_id": event_id, "status": "published"}

@router.post("/subscribe")
async def subscribe_events(subscription: EventSubscription):
    """Subscribe to events"""
    return await event_bus.subscribe(subscription)

@router.get("/events")
async def get_events(
    event_type: Optional[str] = None,
    source: Optional[str] = None,
    processed: Optional[bool] = None,
    limit: int = 100,
    db: AsyncSession = Depends(get_db)
):
    """Get events"""
    return await event_bus.get_events(db, event_type, source, processed, limit)

@router.post("/process/{event_id}")
async def mark_processed(event_id: str, db: AsyncSession = Depends(get_db)):
    """Mark event as processed"""
    success = await event_bus.mark_processed(db, event_id)
    return {"processed": success}

@router.post("/process-pending")
async def process_pending(batch_size: int = 100, db: AsyncSession = Depends(get_db)):
    """Process pending events"""
    return await event_bus.process_pending(db, batch_size)

@router.websocket("/ws")
async def websocket_events(websocket: WebSocket):
    """WebSocket for real-time events"""
    await event_bus.websocket_endpoint(websocket)
