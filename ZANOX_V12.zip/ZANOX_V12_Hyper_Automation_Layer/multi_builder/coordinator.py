"""ZANOX V12 Multi-Builder Coordinator - Orchestrates Multiple Builder Platforms"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime
import uuid
import logging

from shared.database import get_db
from shared.models import ConnectorRegistry, IntegrationRegistry, PlatformType
from connector_registry.registry import connector_manager

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v12/multi-builder", tags=["Multi-Builder Coordinator"])

class BuilderTask(BaseModel):
    """Task for builder platform"""
    task_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    project_name: str
    platform: str  # replit, bolt, lovable, etc.
    task_type: str  # create, deploy, update, delete
    template: Optional[str] = None
    code: Optional[str] = None
    config: Dict[str, Any] = {}
    assets: Optional[List[str]] = None

class BuilderResult(BaseModel):
    """Result from builder execution"""
    task_id: str
    platform: str
    status: str
    project_url: Optional[str]
    deploy_url: Optional[str]
    error: Optional[str]
    duration_ms: float

class MultiBuilderCoordinator:
    """Coordinates builder platforms for project creation and deployment"""

    BUILDER_TEMPLATES = {
        "replit": ["python", "node", "react", "nextjs", "flask", "django"],
        "bolt": ["nextjs", "react", "vue", "svelte", "html"],
        "lovable": ["webapp", "landing", "dashboard", "ecommerce"],
        "v0": ["nextjs", "react", "component"],
        "softgen": ["webapp", "mobile", "api"],
        "flutterflow": ["mobile", "web", "pwa"],
        "draftbit": ["mobile", "web"],
        "glide": ["app", "page", "integration"],
        "framer": ["site", "component"],
        "adalo": ["app", "component"],
        "bubble": ["webapp", "api"],
        "wix_ai": ["site", "store", "blog"],
        "appsmith": ["dashboard", "admin", "internal"],
        "tooljet": ["dashboard", "app", "workflow"],
        "budibase": ["app", "form", "dashboard"]
    }

    async def _get_builder_connector(self, db: AsyncSession, platform: str) -> Optional[ConnectorRegistry]:
        """Get active connector for builder platform"""
        result = await db.execute(
            select(ConnectorRegistry)
            .join(IntegrationRegistry)
            .where(IntegrationRegistry.provider == platform)
            .where(IntegrationRegistry.platform_type == PlatformType.BUILDER)
            .where(ConnectorRegistry.status == "active")
        )
        return result.scalar_one_or_none()

    async def select_platform(self, db: AsyncSession, task: BuilderTask) -> str:
        """Select best builder platform for task"""
        if task.platform:
            connector = await self._get_builder_connector(db, task.platform)
            if connector:
                return task.platform
            raise HTTPException(status_code=400, detail=f"Builder platform {task.platform} not available")

        # Match by template support
        for platform, templates in self.BUILDER_TEMPLATES.items():
            if task.template and task.template in templates:
                connector = await self._get_builder_connector(db, platform)
                if connector:
                    return platform

        # Fallback to first available
        for platform in self.BUILDER_TEMPLATES:
            connector = await self._get_builder_connector(db, platform)
            if connector:
                return platform

        raise HTTPException(status_code=503, detail="No builder platforms available")

    async def execute(self, db: AsyncSession, task: BuilderTask) -> BuilderResult:
        """Execute builder task"""
        platform = await self.select_platform(db, task)
        connector = await self._get_builder_connector(db, platform)

        if not connector:
            return BuilderResult(
                task_id=task.task_id,
                platform=platform,
                status="failed",
                project_url=None,
                deploy_url=None,
                error="Connector not available",
                duration_ms=0
            )

        start_time = datetime.utcnow()

        payload = self._build_payload(platform, task)

        try:
            endpoint = self._get_endpoint(task.task_type)
            result = await connector_manager.execute_connector(
                db, connector.id, "POST", endpoint, payload
            )

            duration_ms = (datetime.utcnow() - start_time).total_seconds() * 1000

            if result.get("success"):
                body = result.get("body", {})
                return BuilderResult(
                    task_id=task.task_id,
                    platform=platform,
                    status="completed",
                    project_url=body.get("project_url") or body.get("url"),
                    deploy_url=body.get("deploy_url") or body.get("live_url"),
                    error=None,
                    duration_ms=duration_ms
                )
            else:
                return BuilderResult(
                    task_id=task.task_id,
                    platform=platform,
                    status="failed",
                    project_url=None,
                    deploy_url=None,
                    error=result.get("error", "Unknown error"),
                    duration_ms=duration_ms
                )
        except Exception as e:
            duration_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            return BuilderResult(
                task_id=task.task_id,
                platform=platform,
                status="failed",
                project_url=None,
                deploy_url=None,
                error=str(e),
                duration_ms=duration_ms
            )

    def _build_payload(self, platform: str, task: BuilderTask) -> Dict[str, Any]:
        """Build platform-specific payload"""
        return {
            "project_name": task.project_name,
            "template": task.template,
            "code": task.code,
            "config": task.config,
            "assets": task.assets or []
        }

    def _get_endpoint(self, task_type: str) -> str:
        """Get API endpoint for task type"""
        endpoints = {
            "create": "projects",
            "deploy": "deploy",
            "update": "projects/update",
            "delete": "projects/delete"
        }
        return endpoints.get(task_type, "projects")

    async def get_platforms(self, db: AsyncSession) -> Dict[str, Any]:
        """Get all available builder platforms"""
        status = {}
        for platform, templates in self.BUILDER_TEMPLATES.items():
            connector = await self._get_builder_connector(db, platform)
            status[platform] = {
                "available": connector is not None,
                "templates": templates,
                "connector_status": connector.status.value if connector else "unavailable"
            }
        return status

multi_builder_coordinator = MultiBuilderCoordinator()

# API Endpoints
@router.post("/execute")
async def execute_builder_task(task: BuilderTask, db: AsyncSession = Depends(get_db)):
    """Execute builder task"""
    result = await multi_builder_coordinator.execute(db, task)
    return result.dict()

@router.get("/platforms")
async def get_builder_platforms(db: AsyncSession = Depends(get_db)):
    """Get all available builder platforms"""
    return await multi_builder_coordinator.get_platforms(db)
