"""ZANOX V12 Monitoring Layer - Integration Monitoring"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_, or_
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime, timedelta
import uuid
import logging
import asyncio

from shared.database import get_db
from shared.models import ConnectorRegistry, HealthCheck, IntegrationRegistry, EventRecord
from shared.redis_client import redis_client
from shared.config import config
from connector_registry.registry import connector_manager

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v12/monitoring", tags=["Monitoring"])

class HealthStatus(BaseModel):
    """Health status report"""
    overall: str
    connectors: List[Dict[str, Any]]
    integrations: List[Dict[str, Any]]
    last_check: datetime

class MonitoringEngine:
    """Comprehensive monitoring for all integrations"""

    async def check_all_connectors(self, db: AsyncSession) -> HealthStatus:
        """Health check all connectors"""
        result = await db.execute(
            select(ConnectorRegistry)
            .where(ConnectorRegistry.status == "active")
        )
        connectors = result.scalars().all()

        connector_status = []
        healthy_count = 0

        for connector in connectors:
            try:
                health = await connector_manager.health_check(db, connector.id)

                # Record health check
                check = HealthCheck(
                    connector_id=connector.id,
                    status=health.get("status", "unknown"),
                    http_status=health.get("http_status"),
                    error_message=health.get("error"),
                    checked_at=datetime.utcnow()
                )
                db.add(check)

                connector_status.append({
                    "id": connector.id,
                    "name": connector.name,
                    "status": health.get("status"),
                    "http_status": health.get("http_status"),
                    "error": health.get("error")
                })

                if health.get("status") == "healthy":
                    healthy_count += 1

            except Exception as e:
                connector_status.append({
                    "id": connector.id,
                    "name": connector.name,
                    "status": "error",
                    "error": str(e)
                })

        await db.commit()

        overall = "healthy" if healthy_count == len(connectors) else                   "degraded" if healthy_count > len(connectors) / 2 else "unhealthy"

        return HealthStatus(
            overall=overall,
            connectors=connector_status,
            integrations=[],
            last_check=datetime.utcnow()
        )

    async def get_connector_health(self, db: AsyncSession,
                                   connector_id: str) -> Dict[str, Any]:
        """Get health history for connector"""
        result = await db.execute(
            select(HealthCheck)
            .where(HealthCheck.connector_id == connector_id)
            .order_by(HealthCheck.checked_at.desc())
            .limit(100)
        )
        checks = result.scalars().all()

        return {
            "connector_id": connector_id,
            "checks": [
                {
                    "status": c.status,
                    "http_status": c.http_status,
                    "response_time_ms": c.response_time_ms,
                    "error": c.error_message,
                    "checked_at": c.checked_at.isoformat() if c.checked_at else None
                }
                for c in checks
            ]
        }

    async def get_system_metrics(self, db: AsyncSession) -> Dict[str, Any]:
        """Get system-wide metrics"""
        # Connector counts
        total = await db.execute(select(func.count(ConnectorRegistry.id)))
        active = await db.execute(
            select(func.count(ConnectorRegistry.id))
            .where(ConnectorRegistry.status == "active")
        )
        error = await db.execute(
            select(func.count(ConnectorRegistry.id))
            .where(ConnectorRegistry.status == "error")
        )

        # Recent events
        events = await db.execute(
            select(func.count(EventRecord.id))
            .where(EventRecord.created_at >= datetime.utcnow() - timedelta(hours=1))
        )

        # Failed events
        failed_events = await db.execute(
            select(func.count(EventRecord.id))
            .where(EventRecord.created_at >= datetime.utcnow() - timedelta(hours=1))
            .where(EventRecord.error_count > 0)
        )

        return {
            "connectors": {
                "total": total.scalar(),
                "active": active.scalar(),
                "error": error.scalar()
            },
            "events": {
                "last_hour": events.scalar(),
                "failed_last_hour": failed_events.scalar()
            },
            "timestamp": datetime.utcnow().isoformat()
        }

monitoring_engine = MonitoringEngine()

@router.get("/health")
async def check_health(db: AsyncSession = Depends(get_db)):
    """Check overall health"""
    health = await monitoring_engine.check_all_connectors(db)
    return health.dict()

@router.get("/health/{connector_id}")
async def get_connector_health(connector_id: str, db: AsyncSession = Depends(get_db)):
    """Get connector health history"""
    return await monitoring_engine.get_connector_health(db, connector_id)

@router.get("/metrics")
async def get_system_metrics(db: AsyncSession = Depends(get_db)):
    """Get system metrics"""
    return await monitoring_engine.get_system_metrics(db)
