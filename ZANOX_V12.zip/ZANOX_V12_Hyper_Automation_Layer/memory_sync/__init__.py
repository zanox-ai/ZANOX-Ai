# ZANOX V12 Memory Sync
