"""ZANOX V12 Memory Sync - Cross-Platform Memory Synchronization"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, or_
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime
import uuid
import logging
import json

from shared.database import get_db
from shared.models import MemorySync
from shared.redis_client import redis_client
from shared.config import config

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v12/memory-sync", tags=["Memory Sync"])

class MemoryEntry(BaseModel):
    """Memory entry for sync"""
    platform: str
    memory_type: str = "conversation"  # conversation, context, state, preference
    key: str
    value: Dict[str, Any]
    vector_embedding: Optional[List[float]] = None

class MemorySyncResult(BaseModel):
    """Result of memory sync operation"""
    sync_id: str
    platform: str
    key: str
    status: str
    sync_version: int
    synced_at: datetime

class MemorySyncManager:
    """Manages cross-platform memory synchronization"""

    async def sync_memory(self, db: AsyncSession, entry: MemoryEntry) -> MemorySyncResult:
        """Sync memory entry to database and Redis"""
        sync_id = str(uuid.uuid4())

        # Check existing
        result = await db.execute(
            select(MemorySync)
            .where(MemorySync.platform == entry.platform)
            .where(MemorySync.key == entry.key)
        )
        existing = result.scalar_one_or_none()

        if existing:
            existing.value = entry.value
            existing.sync_version += 1
            existing.last_synced_at = datetime.utcnow()
            if entry.vector_embedding:
                existing.vector_embedding = entry.vector_embedding
            sync_version = existing.sync_version
        else:
            memory = MemorySync(
                id=sync_id,
                platform=entry.platform,
                memory_type=entry.memory_type,
                key=entry.key,
                value=entry.value,
                vector_embedding=entry.vector_embedding,
                sync_version=1
            )
            db.add(memory)
            sync_version = 1

        await db.commit()

        # Also sync to Redis for fast access
        redis_key = f"memory:{entry.platform}:{entry.key}"
        await redis_client.set(redis_key, json.dumps(entry.value), expire=86400)

        logger.info(f"Memory synced: {entry.platform}/{entry.key} v{sync_version}")

        return MemorySyncResult(
            sync_id=sync_id,
            platform=entry.platform,
            key=entry.key,
            status="synced",
            sync_version=sync_version,
            synced_at=datetime.utcnow()
        )

    async def get_memory(self, db: AsyncSession, platform: str, 
                        key: str) -> Optional[Dict[str, Any]]:
        """Get memory entry"""
        # Try Redis first
        redis_key = f"memory:{platform}:{key}"
        cached = await redis_client.get(redis_key)
        if cached:
            return json.loads(cached)

        # Fallback to database
        result = await db.execute(
            select(MemorySync)
            .where(MemorySync.platform == platform)
            .where(MemorySync.key == key)
        )
        memory = result.scalar_one_or_none()

        if memory:
            return memory.value
        return None

    async def get_platform_memory(self, db: AsyncSession, platform: str,
                                 memory_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get all memory for a platform"""
        query = select(MemorySync).where(MemorySync.platform == platform)
        if memory_type:
            query = query.where(MemorySync.memory_type == memory_type)

        result = await db.execute(query)
        memories = result.scalars().all()

        return [
            {
                "key": m.key,
                "value": m.value,
                "memory_type": m.memory_type,
                "sync_version": m.sync_version,
                "last_synced_at": m.last_synced_at.isoformat() if m.last_synced_at else None
            }
            for m in memories
        ]

    async def sync_all_platforms(self, db: AsyncSession, key: str,
                                value: Dict[str, Any]) -> List[MemorySyncResult]:
        """Sync memory to all platforms"""
        platforms = config.SUPPORTED_AI_SYSTEMS + config.SUPPORTED_AGENT_PLATFORMS

        results = []
        for platform in platforms:
            entry = MemoryEntry(platform=platform, key=key, value=value)
            result = await self.sync_memory(db, entry)
            results.append(result)

        return results

    async def delete_memory(self, db: AsyncSession, platform: str, 
                           key: str) -> bool:
        """Delete memory entry"""
        result = await db.execute(
            select(MemorySync)
            .where(MemorySync.platform == platform)
            .where(MemorySync.key == key)
        )
        memory = result.scalar_one_or_none()

        if memory:
            await db.delete(memory)
            await db.commit()

            redis_key = f"memory:{platform}:{key}"
            await redis_client.delete(redis_key)

            return True
        return False

memory_sync_manager = MemorySyncManager()

@router.post("/sync")
async def sync_memory(entry: MemoryEntry, db: AsyncSession = Depends(get_db)):
    """Sync memory entry"""
    result = await memory_sync_manager.sync_memory(db, entry)
    return result.dict()

@router.get("/{platform}/{key}")
async def get_memory(platform: str, key: str, db: AsyncSession = Depends(get_db)):
    """Get memory entry"""
    memory = await memory_sync_manager.get_memory(db, platform, key)
    if not memory:
        raise HTTPException(status_code=404, detail="Memory not found")
    return memory

@router.get("/{platform}")
async def get_platform_memory(
    platform: str,
    memory_type: Optional[str] = None,
    db: AsyncSession = Depends(get_db)
):
    """Get all memory for platform"""
    return await memory_sync_manager.get_platform_memory(db, platform, memory_type)

@router.post("/sync-all")
async def sync_all_platforms(key: str, value: Dict[str, Any], db: AsyncSession = Depends(get_db)):
    """Sync to all platforms"""
    results = await memory_sync_manager.sync_all_platforms(db, key, value)
    return {"results": [r.dict() for r in results]}

@router.delete("/{platform}/{key}")
async def delete_memory(platform: str, key: str, db: AsyncSession = Depends(get_db)):
    """Delete memory entry"""
    success = await memory_sync_manager.delete_memory(db, platform, key)
    return {"deleted": success}
