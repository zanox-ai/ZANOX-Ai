"""ZANOX V12 Human Approval Engine - Human-in-the-Loop"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, and_
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime, timedelta
import uuid
import logging

from shared.database import get_db
from shared.models import TaskRecord, TaskStatus, EventRecord, WorkflowExecution
from shared.redis_client import redis_client
from shared.security import security_manager

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v12/human-approval", tags=["Human Approval"])

class ApprovalRequest(BaseModel):
    """Request for human approval"""
    request_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    task_id: str
    execution_id: str
    action_type: str  # approve, reject, modify, escalate
    reason: Optional[str] = None
    modified_payload: Optional[Dict[str, Any]] = None
    approver_id: Optional[str] = None

class ApprovalRecord(BaseModel):
    """Record of approval decision"""
    request_id: str
    task_id: str
    execution_id: str
    status: str  # pending, approved, rejected, modified, escalated
    action_type: str
    reason: Optional[str]
    approver_id: Optional[str]
    created_at: datetime
    resolved_at: Optional[datetime]

class HumanApprovalEngine:
    """Manages human-in-the-loop approval workflows"""

    async def request_approval(self, db: AsyncSession, task_id: str,
                             execution_id: str,
                             context: Optional[Dict] = None) -> str:
        """Create approval request for task"""
        request_id = str(uuid.uuid4())

        # Create event
        event = EventRecord(
            id=str(uuid.uuid4()),
            event_type="approval_requested",
            source="human_approval",
            target="approval_queue",
            payload={
                "request_id": request_id,
                "task_id": task_id,
                "execution_id": execution_id,
                "context": context or {},
                "status": "pending",
                "created_at": datetime.utcnow().isoformat()
            },
            priority=1
        )
        db.add(event)

        # Update task status
        task = await db.get(TaskRecord, task_id)
        if task:
            task.status = TaskStatus.PENDING
            await db.commit()

        # Store in Redis for quick lookup
        await redis_client.hset(
            f"approval:{request_id}",
            "status", "pending"
        )
        await redis_client.hset(
            f"approval:{request_id}",
            "task_id", task_id
        )

        logger.info(f"Approval requested: {request_id} for task {task_id}")
        return request_id

    async def process_approval(self, db: AsyncSession, 
                               request: ApprovalRequest) -> ApprovalRecord:
        """Process approval decision"""
        # Get approval record from Redis
        status = await redis_client.hget(f"approval:{request.request_id}", "status")
        if not status:
            raise HTTPException(status_code=404, detail="Approval request not found")

        if status != "pending":
            raise HTTPException(status_code=400, detail="Approval request already processed")

        # Update status
        await redis_client.hset(
            f"approval:{request.request_id}",
            "status", request.action_type
        )
        await redis_client.hset(
            f"approval:{request.request_id}",
            "resolved_at", datetime.utcnow().isoformat()
        )

        # Update task based on decision
        task = await db.get(TaskRecord, request.task_id)
        if task:
            if request.action_type == "approve":
                task.status = TaskStatus.RUNNING
            elif request.action_type == "reject":
                task.status = TaskStatus.FAILED
                task.error_data = {"reason": request.reason or "Rejected by human"}
            elif request.action_type == "modify":
                task.status = TaskStatus.RUNNING
                if request.modified_payload:
                    task.input_data = {**task.input_data, **request.modified_payload}
            elif request.action_type == "escalate":
                task.status = TaskStatus.PENDING
                # Create escalation event
                event = EventRecord(
                    id=str(uuid.uuid4()),
                    event_type="approval_escalated",
                    source="human_approval",
                    target="escalation_queue",
                    payload={
                        "request_id": request.request_id,
                        "task_id": request.task_id,
                        "reason": request.reason
                    },
                    priority=1
                )
                db.add(event)

        await db.commit()

        # Create resolution event
        event = EventRecord(
            id=str(uuid.uuid4()),
            event_type=f"approval_{request.action_type}",
            source="human_approval",
            target="workflow_engine",
            payload={
                "request_id": request.request_id,
                "task_id": request.task_id,
                "action": request.action_type,
                "reason": request.reason
            },
            correlation_id=request.execution_id
        )
        db.add(event)
        await db.commit()

        logger.info(f"Approval {request.action_type}: {request.request_id}")

        return ApprovalRecord(
            request_id=request.request_id,
            task_id=request.task_id,
            execution_id=request.execution_id,
            status=request.action_type,
            action_type=request.action_type,
            reason=request.reason,
            approver_id=request.approver_id,
            created_at=datetime.utcnow(),
            resolved_at=datetime.utcnow()
        )

    async def get_pending_approvals(self, db: AsyncSession) -> List[Dict[str, Any]]:
        """Get all pending approval requests"""
        result = await db.execute(
            select(EventRecord)
            .where(EventRecord.event_type == "approval_requested")
            .where(EventRecord.processed == False)
            .order_by(EventRecord.created_at.desc())
        )
        events = result.scalars().all()

        return [
            {
                "request_id": e.payload.get("request_id"),
                "task_id": e.payload.get("task_id"),
                "execution_id": e.payload.get("execution_id"),
                "context": e.payload.get("context"),
                "created_at": e.created_at.isoformat() if e.created_at else None
            }
            for e in events
        ]

    async def get_approval_status(self, request_id: str) -> Dict[str, Any]:
        """Get status of approval request"""
        data = await redis_client.hgetall(f"approval:{request_id}")
        if not data:
            return {"status": "not_found"}
        return {
            "request_id": request_id,
            "status": data.get("status", "unknown"),
            "task_id": data.get("task_id"),
            "resolved_at": data.get("resolved_at")
        }

human_approval_engine = HumanApprovalEngine()

@router.post("/request/{task_id}")
async def request_approval(
    task_id: str,
    execution_id: str,
    context: Optional[Dict] = None,
    db: AsyncSession = Depends(get_db)
):
    """Request human approval for task"""
    request_id = await human_approval_engine.request_approval(db, task_id, execution_id, context)
    return {"request_id": request_id, "status": "pending"}

@router.post("/process")
async def process_approval(request: ApprovalRequest, db: AsyncSession = Depends(get_db)):
    """Process approval decision"""
    result = await human_approval_engine.process_approval(db, request)
    return result.dict()

@router.get("/pending")
async def get_pending_approvals(db: AsyncSession = Depends(get_db)):
    """Get pending approvals"""
    return await human_approval_engine.get_pending_approvals(db)

@router.get("/status/{request_id}")
async def get_approval_status(request_id: str):
    """Get approval status"""
    return await human_approval_engine.get_approval_status(request_id)
