#!/usr/bin/env python3
"""
Nexus Core v2 - Governance Layer
Production-ready implementation for policy enforcement, access control, and audit logging.
"""

import asyncio
import logging
import time
import hashlib
import json
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, Union
from datetime import datetime, timedelta
import threading
import re

logger = logging.getLogger(__name__)


class Permission(Enum):
    READ = auto()
    WRITE = auto()
    EXECUTE = auto()
    DELETE = auto()
    ADMIN = auto()
    AUDIT = auto()
    CONFIGURE = auto()


class PolicyType(Enum):
    ACCESS_CONTROL = auto()
    RATE_LIMIT = auto()
    DATA_PROTECTION = auto()
    COMPLIANCE = auto()
    RESOURCE_QUOTA = auto()
    AUDIT = auto()
    CUSTOM = auto()


class PolicyDecision(Enum):
    ALLOW = auto()
    DENY = auto()
    CONDITIONAL = auto()
    ESCALATE = auto()


@dataclass
class Identity:
    identity_id: str
    identity_type: str  # user, service, agent, system
    name: str
    roles: List[str] = field(default_factory=list)
    attributes: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    expires_at: Optional[float] = None


@dataclass
class Resource:
    resource_id: str
    resource_type: str
    owner: str
    permissions: Dict[str, List[Permission]] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    tags: List[str] = field(default_factory=list)


@dataclass
class Policy:
    policy_id: str
    name: str
    policy_type: PolicyType
    description: str
    rules: List[Dict[str, Any]] = field(default_factory=list)
    priority: int = 0
    enabled: bool = True
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    expires_at: Optional[float] = None
    tags: List[str] = field(default_factory=list)


@dataclass
class PolicyEvaluation:
    evaluation_id: str
    policy_id: str
    identity: Identity
    resource: Resource
    action: Permission
    decision: PolicyDecision
    context: Dict[str, Any] = field(default_factory=dict)
    evaluated_at: float = field(default_factory=time.time)
    reason: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class AuditLog:
    log_id: str
    timestamp: float
    event_type: str
    identity_id: str
    resource_id: str
    action: str
    result: str
    context: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    severity: str = "INFO"
    compliance_tags: List[str] = field(default_factory=list)


class GovernanceLayer:
    """
    Core governance layer managing policies, access control, identity management,
    and comprehensive audit logging.
    """

    def __init__(self, max_audit_logs: int = 100000):
        self.max_audit_logs = max_audit_logs

        self._policies: Dict[str, Policy] = {}
        self._identities: Dict[str, Identity] = {}
        self._resources: Dict[str, Resource] = {}
        self._role_permissions: Dict[str, Set[Permission]] = {}
        self._audit_logs: List[AuditLog] = []
        self._evaluation_cache: Dict[str, PolicyEvaluation] = {}
        self._cache_ttl: Dict[str, float] = {}
        self._cache_duration = 300.0

        self._lock = threading.RLock()
        self._running = False
        self._monitor_task: Optional[asyncio.Task] = None
        self._custom_evaluators: Dict[str, Callable] = {}
        self._notification_handlers: Dict[str, Callable] = {}

        # Initialize default roles
        self._init_default_roles()

        logger.info("GovernanceLayer initialized")

    def _init_default_roles(self):
        """Initialize default role permissions."""
        self._role_permissions["admin"] = {Permission.READ, Permission.WRITE, Permission.EXECUTE, 
                                          Permission.DELETE, Permission.ADMIN, Permission.AUDIT, 
                                          Permission.CONFIGURE}
        self._role_permissions["operator"] = {Permission.READ, Permission.WRITE, Permission.EXECUTE, 
                                             Permission.AUDIT}
        self._role_permissions["viewer"] = {Permission.READ, Permission.AUDIT}
        self._role_permissions["service"] = {Permission.READ, Permission.WRITE, Permission.EXECUTE}
        self._role_permissions["agent"] = {Permission.READ, Permission.EXECUTE}
        self._role_permissions["guest"] = {Permission.READ}

    async def start(self):
        """Start the governance layer."""
        self._running = True
        self._monitor_task = asyncio.create_task(self._monitor_loop())
        logger.info("GovernanceLayer started")

    async def stop(self):
        """Stop the governance layer."""
        self._running = False
        if self._monitor_task:
            self._monitor_task.cancel()
            try:
                await self._monitor_task
            except asyncio.CancelledError:
                pass
        logger.info("GovernanceLayer stopped")

    def register_policy(self, policy: Policy) -> str:
        """Register a new policy."""
        with self._lock:
            self._policies[policy.policy_id] = policy

        logger.info("Registered policy: %s (%s)", policy.policy_id, policy.name)
        return policy.policy_id

    def unregister_policy(self, policy_id: str) -> bool:
        """Remove a policy."""
        with self._lock:
            if policy_id not in self._policies:
                return False
            del self._policies[policy_id]

        logger.info("Unregistered policy: %s", policy_id)
        return True

    def register_identity(self, identity: Identity) -> str:
        """Register a new identity."""
        with self._lock:
            self._identities[identity.identity_id] = identity

        logger.info("Registered identity: %s (%s)", identity.identity_id, identity.name)
        return identity.identity_id

    def unregister_identity(self, identity_id: str) -> bool:
        """Remove an identity."""
        with self._lock:
            if identity_id not in self._identities:
                return False
            del self._identities[identity_id]

        logger.info("Unregistered identity: %s", identity_id)
        return True

    def register_resource(self, resource: Resource) -> str:
        """Register a new resource."""
        with self._lock:
            self._resources[resource.resource_id] = resource

        logger.info("Registered resource: %s (%s)", resource.resource_id, resource.resource_type)
        return resource.resource_id

    def unregister_resource(self, resource_id: str) -> bool:
        """Remove a resource."""
        with self._lock:
            if resource_id not in self._resources:
                return False
            del self._resources[resource_id]

        logger.info("Unregistered resource: %s", resource_id)
        return True

    def define_role_permissions(self, role: str, permissions: Set[Permission]):
        """Define permissions for a role."""
        with self._lock:
            self._role_permissions[role] = permissions

        logger.info("Defined permissions for role: %s", role)

    def register_custom_evaluator(self, evaluator_id: str, evaluator: Callable):
        """Register a custom policy evaluator."""
        self._custom_evaluators[evaluator_id] = evaluator
        logger.info("Registered custom evaluator: %s", evaluator_id)

    def register_notification_handler(self, channel: str, handler: Callable):
        """Register a notification handler."""
        self._notification_handlers[channel] = handler
        logger.info("Registered notification handler for channel: %s", channel)

    async def evaluate(self, identity_id: str, resource_id: str, 
                      action: Permission, context: Optional[Dict[str, Any]] = None) -> PolicyEvaluation:
        """
        Evaluate access request against all applicable policies.
        Returns PolicyEvaluation with decision.
        """
        context = context or {}

        with self._lock:
            identity = self._identities.get(identity_id)
            resource = self._resources.get(resource_id)

        if not identity:
            return PolicyEvaluation(
                evaluation_id=str(hashlib.sha256(f"{identity_id}:{resource_id}:{action.name}:{time.time()}".encode()).hexdigest())[:16],
                policy_id="default",
                identity=Identity(identity_id=identity_id, identity_type="unknown", name="unknown"),
                resource=resource or Resource(resource_id=resource_id, resource_type="unknown", owner=""),
                action=action,
                decision=PolicyDecision.DENY,
                reason="Identity not found"
            )

        if not resource:
            return PolicyEvaluation(
                evaluation_id=str(hashlib.sha256(f"{identity_id}:{resource_id}:{action.name}:{time.time()}".encode()).hexdigest())[:16],
                policy_id="default",
                identity=identity,
                resource=Resource(resource_id=resource_id, resource_type="unknown", owner=""),
                action=action,
                decision=PolicyDecision.DENY,
                reason="Resource not found"
            )

        # Check cache
        cache_key = f"{identity_id}:{resource_id}:{action.name}:{json.dumps(context, sort_keys=True, default=str)}"
        cached = self._get_cached_evaluation(cache_key)
        if cached:
            return cached

        # Evaluate all applicable policies
        final_decision = PolicyDecision.ALLOW
        reasons = []

        with self._lock:
            applicable_policies = [
                p for p in self._policies.values()
                if p.enabled and (p.expires_at is None or p.expires_at > time.time())
            ]

            # Sort by priority (highest first)
            applicable_policies.sort(key=lambda p: p.priority, reverse=True)

        for policy in applicable_policies:
            decision = await self._evaluate_policy(policy, identity, resource, action, context)

            if decision.decision == PolicyDecision.DENY:
                final_decision = PolicyDecision.DENY
                reasons.append(f"Policy {policy.policy_id}: {decision.reason}")
                break
            elif decision.decision == PolicyDecision.ESCALATE:
                final_decision = PolicyDecision.ESCALATE
                reasons.append(f"Policy {policy.policy_id}: {decision.reason}")
            elif decision.decision == PolicyDecision.CONDITIONAL:
                if final_decision == PolicyDecision.ALLOW:
                    final_decision = PolicyDecision.CONDITIONAL
                    reasons.append(f"Policy {policy.policy_id}: {decision.reason}")

        # Check role-based permissions
        if final_decision == PolicyDecision.ALLOW:
            role_allowed = self._check_role_permissions(identity, action)
            if not role_allowed:
                final_decision = PolicyDecision.DENY
                reasons.append("Role-based access denied")

        # Check resource-specific permissions
        if final_decision == PolicyDecision.ALLOW:
            resource_allowed = self._check_resource_permissions(resource, identity_id, action)
            if not resource_allowed:
                final_decision = PolicyDecision.DENY
                reasons.append("Resource-specific access denied")

        evaluation = PolicyEvaluation(
            evaluation_id=str(hashlib.sha256(f"{identity_id}:{resource_id}:{action.name}:{time.time()}".encode()).hexdigest())[:16],
            policy_id="composite",
            identity=identity,
            resource=resource,
            action=action,
            decision=final_decision,
            context=context,
            reason="; ".join(reasons) if reasons else "Access granted",
            metadata={"policies_evaluated": len(applicable_policies)}
        )

        # Cache evaluation
        self._cache_evaluation(cache_key, evaluation)

        # Log audit
        await self._log_audit(
            event_type="ACCESS_EVALUATION",
            identity_id=identity_id,
            resource_id=resource_id,
            action=action.name,
            result=final_decision.name,
            context=context,
            severity="WARNING" if final_decision == PolicyDecision.DENY else "INFO"
        )

        return evaluation

    async def _evaluate_policy(self, policy: Policy, identity: Identity, 
                              resource: Resource, action: Permission,
                              context: Dict[str, Any]) -> PolicyEvaluation:
        """Evaluate a single policy against the request."""
        for rule in policy.rules:
            rule_type = rule.get("type", "allow")

            if rule_type == "allow":
                if self._match_rule(rule, identity, resource, action, context):
                    return PolicyEvaluation(
                        evaluation_id="",
                        policy_id=policy.policy_id,
                        identity=identity,
                        resource=resource,
                        action=action,
                        decision=PolicyDecision.ALLOW,
                        reason=rule.get("reason", "Rule matched")
                    )

            elif rule_type == "deny":
                if self._match_rule(rule, identity, resource, action, context):
                    return PolicyEvaluation(
                        evaluation_id="",
                        policy_id=policy.policy_id,
                        identity=identity,
                        resource=resource,
                        action=action,
                        decision=PolicyDecision.DENY,
                        reason=rule.get("reason", "Rule matched")
                    )

            elif rule_type == "conditional":
                if self._match_rule(rule, identity, resource, action, context):
                    condition = rule.get("condition")
                    if condition and self._evaluate_condition(condition, context):
                        return PolicyEvaluation(
                            evaluation_id="",
                            policy_id=policy.policy_id,
                            identity=identity,
                            resource=resource,
                            action=action,
                            decision=PolicyDecision.ALLOW,
                            reason=rule.get("reason", "Condition met")
                        )

            elif rule_type == "custom":
                evaluator_id = rule.get("evaluator_id")
                if evaluator_id and evaluator_id in self._custom_evaluators:
                    evaluator = self._custom_evaluators[evaluator_id]
                    result = evaluator(identity, resource, action, context)
                    if asyncio.iscoroutinefunction(evaluator):
                        result = await result

                    return PolicyEvaluation(
                        evaluation_id="",
                        policy_id=policy.policy_id,
                        identity=identity,
                        resource=resource,
                        action=action,
                        decision=PolicyDecision.ALLOW if result else PolicyDecision.DENY,
                        reason=rule.get("reason", "Custom evaluation")
                    )

        return PolicyEvaluation(
            evaluation_id="",
            policy_id=policy.policy_id,
            identity=identity,
            resource=resource,
            action=action,
            decision=PolicyDecision.ALLOW,
            reason="No matching rules"
        )

    def _match_rule(self, rule: Dict[str, Any], identity: Identity, 
                   resource: Resource, action: Permission, context: Dict[str, Any]) -> bool:
        """Check if a rule matches the request."""
        # Check identity patterns
        identity_patterns = rule.get("identities", [])
        if identity_patterns and identity.identity_id not in identity_patterns:
            if not any(re.match(pattern, identity.identity_id) for pattern in identity_patterns):
                return False

        # Check identity types
        identity_types = rule.get("identity_types", [])
        if identity_types and identity.identity_type not in identity_types:
            return False

        # Check roles
        roles = rule.get("roles", [])
        if roles and not any(role in identity.roles for role in roles):
            return False

        # Check resource patterns
        resource_patterns = rule.get("resources", [])
        if resource_patterns and resource.resource_id not in resource_patterns:
            if not any(re.match(pattern, resource.resource_id) for pattern in resource_patterns):
                return False

        # Check resource types
        resource_types = rule.get("resource_types", [])
        if resource_types and resource.resource_type not in resource_types:
            return False

        # Check actions
        actions = rule.get("actions", [])
        if actions and action.name not in actions:
            return False

        # Check tags
        identity_tags = rule.get("identity_tags", [])
        if identity_tags and not any(tag in identity.tags for tag in identity_tags):
            return False

        resource_tags = rule.get("resource_tags", [])
        if resource_tags and not any(tag in resource.tags for tag in resource_tags):
            return False

        # Check context conditions
        context_conditions = rule.get("context_conditions", {})
        for key, expected_value in context_conditions.items():
            if context.get(key) != expected_value:
                return False

        return True

    def _evaluate_condition(self, condition: str, context: Dict[str, Any]) -> bool:
        """Evaluate a condition string with context variables."""
        try:
            # Simple condition evaluation - in production, use a proper expression engine
            for key, value in context.items():
                condition = condition.replace(f"${{{key}}}", str(value))

            return eval(condition, {"__builtins__": {}}, {})
        except Exception:
            return False

    def _check_role_permissions(self, identity: Identity, action: Permission) -> bool:
        """Check if identity's roles allow the action."""
        for role in identity.roles:
            permissions = self._role_permissions.get(role, set())
            if action in permissions or Permission.ADMIN in permissions:
                return True
        return False

    def _check_resource_permissions(self, resource: Resource, identity_id: str, action: Permission) -> bool:
        """Check resource-specific permissions."""
        # Resource owner has full access
        if resource.owner == identity_id:
            return True

        # Check specific permissions
        perms = resource.permissions.get(identity_id, [])
        if action in perms or Permission.ADMIN in perms:
            return True

        return True  # Default allow if no specific restrictions

    def _get_cached_evaluation(self, cache_key: str) -> Optional[PolicyEvaluation]:
        """Get cached policy evaluation if not expired."""
        with self._lock:
            if cache_key in self._evaluation_cache:
                ttl = self._cache_ttl.get(cache_key, 0)
                if time.time() < ttl:
                    return self._evaluation_cache[cache_key]
                else:
                    del self._evaluation_cache[cache_key]
                    del self._cache_ttl[cache_key]
        return None

    def _cache_evaluation(self, cache_key: str, evaluation: PolicyEvaluation):
        """Cache a policy evaluation."""
        with self._lock:
            self._evaluation_cache[cache_key] = evaluation
            self._cache_ttl[cache_key] = time.time() + self._cache_duration

    async def _log_audit(self, event_type: str, identity_id: str, resource_id: str,
                        action: str, result: str, context: Dict[str, Any],
                        severity: str = "INFO"):
        """Log an audit event."""
        log_id = str(hashlib.sha256(f"{event_type}:{identity_id}:{time.time()}".encode()).hexdigest())[:16]

        audit_log = AuditLog(
            log_id=log_id,
            timestamp=time.time(),
            event_type=event_type,
            identity_id=identity_id,
            resource_id=resource_id,
            action=action,
            result=result,
            context=context,
            severity=severity
        )

        with self._lock:
            self._audit_logs.append(audit_log)
            if len(self._audit_logs) > self.max_audit_logs:
                self._audit_logs = self._audit_logs[-self.max_audit_logs:]

        # Log to system logger
        log_method = getattr(logger, severity.lower(), logger.info)
        log_method("AUDIT: %s by %s on %s: %s", action, identity_id, resource_id, result)

    def query_audit_logs(self, identity_id: Optional[str] = None,
                        resource_id: Optional[str] = None,
                        event_type: Optional[str] = None,
                        severity: Optional[str] = None,
                        time_range: Optional[Tuple[float, float]] = None,
                        max_results: int = 100) -> List[AuditLog]:
        """Query audit logs with filters."""
        with self._lock:
            results = []
            for log in reversed(self._audit_logs):
                if identity_id and log.identity_id != identity_id:
                    continue
                if resource_id and log.resource_id != resource_id:
                    continue
                if event_type and log.event_type != event_type:
                    continue
                if severity and log.severity != severity:
                    continue
                if time_range and not (time_range[0] <= log.timestamp <= time_range[1]):
                    continue
                results.append(log)
                if len(results) >= max_results:
                    break
            return results

    def export_audit_logs(self, format_type: str = "json", 
                         time_range: Optional[Tuple[float, float]] = None) -> str:
        """Export audit logs in specified format."""
        logs = self.query_audit_logs(time_range=time_range, max_results=self.max_audit_logs)

        if format_type == "json":
            data = [{
                "log_id": log.log_id,
                "timestamp": log.timestamp,
                "event_type": log.event_type,
                "identity_id": log.identity_id,
                "resource_id": log.resource_id,
                "action": log.action,
                "result": log.result,
                "severity": log.severity,
                "context": log.context
            } for log in logs]
            return json.dumps(data, indent=2, default=str)

        elif format_type == "csv":
            lines = ["log_id,timestamp,event_type,identity_id,resource_id,action,result,severity"]
            for log in logs:
                lines.append(f"{log.log_id},{log.timestamp},{log.event_type},{log.identity_id},{log.resource_id},{log.action},{log.result},{log.severity}")
            return "
".join(lines)

        else:
            raise ValueError(f"Unsupported format: {format_type}")

    def get_stats(self) -> Dict[str, Any]:
        """Get governance layer statistics."""
        with self._lock:
            total_policies = len(self._policies)
            enabled_policies = sum(1 for p in self._policies.values() if p.enabled)
            total_identities = len(self._identities)
            total_resources = len(self._resources)
            total_audit_logs = len(self._audit_logs)

            policy_types = {}
            for p in self._policies.values():
                pt = p.policy_type.name
                policy_types[pt] = policy_types.get(pt, 0) + 1

        return {
            "total_policies": total_policies,
            "enabled_policies": enabled_policies,
            "total_identities": total_identities,
            "total_resources": total_resources,
            "total_audit_logs": total_audit_logs,
            "policy_types": policy_types,
            "defined_roles": list(self._role_permissions.keys())
        }

    async def _monitor_loop(self):
        """Background monitoring loop for policy expiration and cache cleanup."""
        while self._running:
            try:
                await asyncio.sleep(60)

                current_time = time.time()

                with self._lock:
                    # Clean expired policies
                    expired_policies = [
                        pid for pid, p in self._policies.items()
                        if p.expires_at and p.expires_at < current_time
                    ]
                    for pid in expired_policies:
                        del self._policies[pid]

                    # Clean expired cache entries
                    expired_cache = [
                        key for key, ttl in self._cache_ttl.items()
                        if ttl < current_time
                    ]
                    for key in expired_cache:
                        self._evaluation_cache.pop(key, None)
                        self._cache_ttl.pop(key, None)

                if expired_policies:
                    logger.info("Cleaned %d expired policies", len(expired_policies))

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.exception("Monitor loop error: %s", e)
