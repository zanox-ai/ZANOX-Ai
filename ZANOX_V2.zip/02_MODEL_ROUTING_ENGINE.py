#!/usr/bin/env python3
"""
Nexus Core v2 - Model Routing Engine
Production-ready implementation for intelligent model selection and routing.
"""

import asyncio
import logging
import time
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Dict, List, Optional, Tuple, Callable
from collections import defaultdict
import threading
import json

logger = logging.getLogger(__name__)


class ModelCapability(Enum):
    TEXT_GENERATION = auto()
    CODE_GENERATION = auto()
    IMAGE_ANALYSIS = auto()
    VISION = auto()
    REASONING = auto()
    SUMMARIZATION = auto()
    TRANSLATION = auto()
    EMBEDDINGS = auto()
    FUNCTION_CALLING = auto()
    AGENT_EXECUTION = auto()


class RoutingStrategy(Enum):
    CAPABILITY_MATCH = auto()
    COST_OPTIMIZED = auto()
    LATENCY_OPTIMIZED = auto()
    QUALITY_OPTIMIZED = auto()
    LOAD_BALANCED = auto()
    FALLBACK_CHAIN = auto()


@dataclass
class ModelEndpoint:
    model_id: str
    provider: str
    endpoint_url: str
    api_key: Optional[str] = None
    capabilities: List[ModelCapability] = field(default_factory=list)
    cost_per_1k_tokens: float = 0.0
    avg_latency_ms: float = 0.0
    success_rate: float = 1.0
    rate_limit_rpm: int = 60
    rate_limit_tpm: int = 100000
    current_load: int = 0
    max_concurrent: int = 10
    priority: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)
    last_used: float = 0.0
    total_requests: int = 0
    failed_requests: int = 0


@dataclass
class RoutingRequest:
    request_id: str
    capabilities_required: List[ModelCapability]
    input_tokens: int = 0
    expected_output_tokens: int = 0
    priority: int = 0
    timeout_ms: float = 30000.0
    strategy: RoutingStrategy = RoutingStrategy.CAPABILITY_MATCH
    fallback_accepted: bool = True
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class RoutingResult:
    request_id: str
    selected_model: ModelEndpoint
    routing_strategy: RoutingStrategy
    estimated_cost: float
    estimated_latency_ms: float
    confidence_score: float
    fallback_used: bool = False
    routing_metadata: Dict[str, Any] = field(default_factory=dict)


class RateLimiter:
    """Token bucket rate limiter for model endpoints."""

    def __init__(self, rpm: int, tpm: int):
        self.rpm = rpm
        self.tpm = tpm
        self._tokens_per_minute = rpm
        self._token_bucket = rpm
        self._last_refill = time.time()
        self._lock = threading.Lock()
        self._token_size = 1.0

    def acquire(self, tokens: int = 1) -> bool:
        """Attempt to acquire tokens from the bucket."""
        with self._lock:
            now = time.time()
            elapsed = now - self._last_refill
            self._token_bucket = min(self.rpm, self._token_bucket + elapsed * (self.rpm / 60.0))
            self._last_refill = now

            if self._token_bucket >= tokens:
                self._token_bucket -= tokens
                return True
            return False

    def get_wait_time(self, tokens: int = 1) -> float:
        """Calculate wait time until enough tokens are available."""
        with self._lock:
            if self._token_bucket >= tokens:
                return 0.0
            needed = tokens - self._token_bucket
            return (needed / self.rpm) * 60.0


class ModelRoutingEngine:
    """
    Intelligent routing engine that selects optimal model endpoints based on
    capabilities, cost, latency, and load balancing strategies.
    """

    def __init__(self, default_timeout: float = 30.0):
        self.models: Dict[str, ModelEndpoint] = {}
        self.rate_limiters: Dict[str, RateLimiter] = {}
        self._lock = threading.RLock()
        self.default_timeout = default_timeout
        self._routing_history: List[Dict[str, Any]] = []
        self._history_limit = 10000
        self._load_balancer_index: Dict[str, int] = defaultdict(int)
        self._custom_routers: Dict[RoutingStrategy, Callable] = {}
        self._circuit_breakers: Dict[str, Dict[str, Any]] = {}
        self._circuit_threshold = 5
        self._circuit_timeout = 60.0
        logger.info("ModelRoutingEngine initialized")

    def register_model(self, endpoint: ModelEndpoint) -> bool:
        """Register a new model endpoint."""
        with self._lock:
            if endpoint.model_id in self.models:
                logger.warning("Model %s already registered, updating", endpoint.model_id)

            self.models[endpoint.model_id] = endpoint
            self.rate_limiters[endpoint.model_id] = RateLimiter(
                endpoint.rate_limit_rpm,
                endpoint.rate_limit_tpm
            )
            self._circuit_breakers[endpoint.model_id] = {
                "failures": 0,
                "last_failure": 0,
                "open": False
            }

        logger.info("Registered model: %s (%s)", endpoint.model_id, endpoint.provider)
        return True

    def unregister_model(self, model_id: str) -> bool:
        """Remove a model endpoint."""
        with self._lock:
            if model_id not in self.models:
                return False
            del self.models[model_id]
            del self.rate_limiters[model_id]
            del self._circuit_breakers[model_id]
        logger.info("Unregistered model: %s", model_id)
        return True

    def update_model_metrics(self, model_id: str, latency_ms: float, success: bool, tokens_used: int = 0):
        """Update model performance metrics after a request."""
        with self._lock:
            model = self.models.get(model_id)
            if not model:
                return

            model.total_requests += 1
            model.last_used = time.time()

            if success:
                # Exponential moving average for latency
                alpha = 0.3
                model.avg_latency_ms = (alpha * latency_ms) + ((1 - alpha) * model.avg_latency_ms)
                model.success_rate = (model.total_requests - model.failed_requests) / model.total_requests
                self._circuit_breakers[model_id]["failures"] = 0
                self._circuit_breakers[model_id]["open"] = False
            else:
                model.failed_requests += 1
                model.success_rate = (model.total_requests - model.failed_requests) / model.total_requests
                cb = self._circuit_breakers[model_id]
                cb["failures"] += 1
                cb["last_failure"] = time.time()
                if cb["failures"] >= self._circuit_threshold:
                    cb["open"] = True
                    logger.warning("Circuit breaker opened for model %s", model_id)

    def get_model(self, model_id: str) -> Optional[ModelEndpoint]:
        """Get model endpoint by ID."""
        with self._lock:
            return self.models.get(model_id)

    def list_models(self, capability: Optional[ModelCapability] = None) -> List[str]:
        """List all model IDs, optionally filtered by capability."""
        with self._lock:
            if capability:
                return [
                    mid for mid, model in self.models.items()
                    if capability in model.capabilities
                ]
            return list(self.models.keys())

    async def route(self, request: RoutingRequest) -> Optional[RoutingResult]:
        """
        Route a request to the optimal model endpoint based on the specified strategy.
        Returns RoutingResult or None if no suitable model found.
        """
        start_time = time.time()

        with self._lock:
            eligible_models = self._get_eligible_models(request)

        if not eligible_models:
            logger.warning("No eligible models found for request %s", request.request_id)
            return None

        # Apply routing strategy
        if request.strategy in self._custom_routers:
            selected = await self._custom_routers[request.strategy](request, eligible_models)
        else:
            selected = self._apply_strategy(request, eligible_models)

        if not selected:
            if request.fallback_accepted:
                selected = self._fallback_selection(request, eligible_models)
            if not selected:
                return None

        # Check rate limiting
        rate_limiter = self.rate_limiters.get(selected.model_id)
        if rate_limiter and not rate_limiter.acquire():
            wait_time = rate_limiter.get_wait_time()
            if wait_time < request.timeout_ms / 1000.0:
                await asyncio.sleep(wait_time)
                if not rate_limiter.acquire():
                    return None
            else:
                return None

        # Update load
        with self._lock:
            selected.current_load += 1

        estimated_cost = self._estimate_cost(selected, request)
        estimated_latency = self._estimate_latency(selected, request)

        result = RoutingResult(
            request_id=request.request_id,
            selected_model=selected,
            routing_strategy=request.strategy,
            estimated_cost=estimated_cost,
            estimated_latency_ms=estimated_latency,
            confidence_score=self._calculate_confidence(selected, request),
            fallback_used=selected != eligible_models[0] if eligible_models else False
        )

        # Record routing decision
        self._record_routing(result, time.time() - start_time)

        return result

    def _get_eligible_models(self, request: RoutingRequest) -> List[ModelEndpoint]:
        """Filter models that meet capability requirements and are healthy."""
        eligible = []

        for model in self.models.values():
            # Check circuit breaker
            cb = self._circuit_breakers.get(model.model_id, {})
            if cb.get("open", False):
                if time.time() - cb.get("last_failure", 0) < self._circuit_timeout:
                    continue
                cb["open"] = False
                cb["failures"] = 0

            # Check capability requirements
            if not all(cap in model.capabilities for cap in request.capabilities_required):
                continue

            # Check load capacity
            if model.current_load >= model.max_concurrent:
                continue

            # Check success rate threshold
            if model.success_rate < 0.5:
                continue

            eligible.append(model)

        return eligible

    def _apply_strategy(self, request: RoutingRequest, models: List[ModelEndpoint]) -> Optional[ModelEndpoint]:
        """Apply the specified routing strategy."""
        if not models:
            return None

        if request.strategy == RoutingStrategy.CAPABILITY_MATCH:
            return models[0]

        elif request.strategy == RoutingStrategy.COST_OPTIMIZED:
            return min(models, key=lambda m: m.cost_per_1k_tokens)

        elif request.strategy == RoutingStrategy.LATENCY_OPTIMIZED:
            return min(models, key=lambda m: m.avg_latency_ms)

        elif request.strategy == RoutingStrategy.QUALITY_OPTIMIZED:
            return max(models, key=lambda m: m.success_rate)

        elif request.strategy == RoutingStrategy.LOAD_BALANCED:
            return min(models, key=lambda m: m.current_load / m.max_concurrent if m.max_concurrent > 0 else 1.0)

        elif request.strategy == RoutingStrategy.FALLBACK_CHAIN:
            return models[0] if models else None

        return models[0]

    def _fallback_selection(self, request: RoutingRequest, models: List[ModelEndpoint]) -> Optional[ModelEndpoint]:
        """Select fallback model with relaxed constraints."""
        if not models:
            return None

        # Try models with lower success rate threshold
        for model in models:
            if model.success_rate >= 0.3:
                return model

        return models[0] if models else None

    def _estimate_cost(self, model: ModelEndpoint, request: RoutingRequest) -> float:
        """Estimate cost for a request."""
        total_tokens = request.input_tokens + request.expected_output_tokens
        return (total_tokens / 1000.0) * model.cost_per_1k_tokens

    def _estimate_latency(self, model: ModelEndpoint, request: RoutingRequest) -> float:
        """Estimate latency for a request."""
        base_latency = model.avg_latency_ms
        load_factor = 1.0 + (model.current_load / model.max_concurrent if model.max_concurrent > 0 else 0)
        return base_latency * load_factor

    def _calculate_confidence(self, model: ModelEndpoint, request: RoutingRequest) -> float:
        """Calculate confidence score for routing decision."""
        confidence = model.success_rate

        # Capability match bonus
        required_caps = set(request.capabilities_required)
        available_caps = set(model.capabilities)
        match_ratio = len(required_caps & available_caps) / len(required_caps) if required_caps else 1.0
        confidence *= (0.5 + 0.5 * match_ratio)

        # Load penalty
        load_ratio = model.current_load / model.max_concurrent if model.max_concurrent > 0 else 0
        confidence *= (1.0 - 0.3 * load_ratio)

        return max(0.0, min(1.0, confidence))

    def _record_routing(self, result: RoutingResult, routing_time: float):
        """Record routing decision for analytics."""
        record = {
            "timestamp": time.time(),
            "request_id": result.request_id,
            "model_id": result.selected_model.model_id,
            "strategy": result.routing_strategy.name,
            "confidence": result.confidence_score,
            "estimated_cost": result.estimated_cost,
            "estimated_latency": result.estimated_latency_ms,
            "routing_time_ms": routing_time * 1000,
            "fallback_used": result.fallback_used
        }

        self._routing_history.append(record)
        if len(self._routing_history) > self._history_limit:
            self._routing_history = self._routing_history[-self._history_limit:]

    def register_custom_router(self, strategy: RoutingStrategy, router: Callable):
        """Register a custom routing function for a strategy."""
        self._custom_routers[strategy] = router
        logger.info("Registered custom router for strategy: %s", strategy.name)

    def get_routing_stats(self) -> Dict[str, Any]:
        """Get routing engine statistics."""
        with self._lock:
            total_models = len(self.models)
            healthy_models = sum(1 for m in self.models.values() if m.success_rate >= 0.8)
            total_routes = len(self._routing_history)

            avg_confidence = 0.0
            if self._routing_history:
                avg_confidence = sum(r["confidence"] for r in self._routing_history) / len(self._routing_history)

        return {
            "total_models": total_models,
            "healthy_models": healthy_models,
            "total_routes": total_routes,
            "average_confidence": avg_confidence,
            "strategies": [s.name for s in RoutingStrategy]
        }

    def get_model_health(self, model_id: str) -> Optional[Dict[str, Any]]:
        """Get health status for a specific model."""
        with self._lock:
            model = self.models.get(model_id)
            if not model:
                return None

            cb = self._circuit_breakers.get(model_id, {})

            return {
                "model_id": model_id,
                "success_rate": model.success_rate,
                "avg_latency_ms": model.avg_latency_ms,
                "current_load": model.current_load,
                "total_requests": model.total_requests,
                "failed_requests": model.failed_requests,
                "circuit_breaker_open": cb.get("open", False),
                "last_used": model.last_used
            }

    def release_model(self, model_id: str):
        """Release model after request completion (decrement load)."""
        with self._lock:
            model = self.models.get(model_id)
            if model and model.current_load > 0:
                model.current_load -= 1

    async def batch_route(self, requests: List[RoutingRequest]) -> List[Optional[RoutingResult]]:
        """Route multiple requests concurrently."""
        tasks = [self.route(req) for req in requests]
        return await asyncio.gather(*tasks, return_exceptions=True)

    def export_routing_history(self, limit: int = 1000) -> str:
        """Export routing history as JSON."""
        history = self._routing_history[-limit:]
        return json.dumps(history, indent=2, default=str)

    def reset_circuit_breaker(self, model_id: str) -> bool:
        """Manually reset circuit breaker for a model."""
        with self._lock:
            if model_id not in self._circuit_breakers:
                return False
            self._circuit_breakers[model_id] = {"failures": 0, "last_failure": 0, "open": False}
        logger.info("Circuit breaker reset for model: %s", model_id)
        return True
