#!/usr/bin/env python3
"""
Nexus Core v2 - Task Execution Layer
Production-ready implementation for task scheduling, execution, and lifecycle management.
"""

import asyncio
import logging
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, Union
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
import threading
import traceback
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)


class TaskStatus(Enum):
    PENDING = auto()
    QUEUED = auto()
    RUNNING = auto()
    PAUSED = auto()
    COMPLETED = auto()
    FAILED = auto()
    CANCELLED = auto()
    TIMEOUT = auto()
    RETRYING = auto()


class TaskPriority(Enum):
    CRITICAL = 0
    HIGH = 1
    NORMAL = 2
    LOW = 3
    BACKGROUND = 4


class ExecutionMode(Enum):
    ASYNC = auto()
    THREAD = auto()
    PROCESS = auto()
    COROUTINE = auto()


@dataclass
class TaskDefinition:
    task_id: str
    name: str
    task_type: str
    payload: Any
    priority: TaskPriority = TaskPriority.NORMAL
    execution_mode: ExecutionMode = ExecutionMode.COROUTINE
    timeout_seconds: float = 60.0
    max_retries: int = 3
    retry_delay_seconds: float = 1.0
    dependencies: List[str] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    scheduled_at: Optional[float] = None
    deadline: Optional[float] = None
    resource_requirements: Dict[str, Any] = field(default_factory=dict)


@dataclass
class TaskResult:
    task_id: str
    status: TaskStatus
    output: Any = None
    error: Optional[str] = None
    execution_time_ms: float = 0.0
    retry_count: int = 0
    started_at: Optional[float] = None
    completed_at: Optional[float] = None
    resource_usage: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class TaskContext:
    task_id: str
    execution_id: str
    start_time: float
    deadline: Optional[float] = None
    checkpoint_data: Dict[str, Any] = field(default_factory=dict)
    cancellation_event: asyncio.Event = field(default_factory=asyncio.Event)
    _lock: threading.RLock = field(default_factory=threading.RLock)

    def is_cancelled(self) -> bool:
        return self.cancellation_event.is_set()

    def cancel(self):
        self.cancellation_event.set()

    def checkpoint(self, data: Dict[str, Any]):
        with self._lock:
            self.checkpoint_data.update(data)

    def get_checkpoint(self) -> Dict[str, Any]:
        with self._lock:
            return self.checkpoint_data.copy()


class TaskExecutionLayer:
    """
    Core task execution layer managing task queues, scheduling, execution,
    retry logic, and resource allocation.
    """

    def __init__(self, max_concurrent_tasks: int = 50, 
                 thread_pool_size: int = 20,
                 process_pool_size: int = 4):
        self.max_concurrent = max_concurrent_tasks
        self.thread_pool = ThreadPoolExecutor(max_workers=thread_pool_size)
        self.process_pool = ProcessPoolExecutor(max_workers=process_pool_size)

        self._task_queue: asyncio.PriorityQueue = asyncio.PriorityQueue()
        self._running_tasks: Dict[str, asyncio.Task] = {}
        self._task_results: Dict[str, TaskResult] = {}
        self._task_definitions: Dict[str, TaskDefinition] = {}
        self._task_contexts: Dict[str, TaskContext] = {}
        self._dependency_graph: Dict[str, Set[str]] = {}
        self._completed_dependencies: Dict[str, Set[str]] = {}

        self._semaphore = asyncio.Semaphore(max_concurrent_tasks)
        self._lock = threading.RLock()
        self._running = False
        self._scheduler_task: Optional[asyncio.Task] = None
        self._handlers: Dict[str, Callable] = {}
        self._pre_execution_hooks: List[Callable] = []
        self._post_execution_hooks: List[Callable] = []

        logger.info("TaskExecutionLayer initialized")

    async def start(self):
        """Start the task execution layer."""
        self._running = True
        self._scheduler_task = asyncio.create_task(self._scheduler_loop())
        logger.info("TaskExecutionLayer started")

    async def stop(self):
        """Gracefully stop all tasks and the execution layer."""
        self._running = False

        # Cancel all running tasks
        with self._lock:
            running_copy = dict(self._running_tasks)

        for task_id, task in running_copy.items():
            context = self._task_contexts.get(task_id)
            if context:
                context.cancel()
            task.cancel()

        if self._scheduler_task:
            self._scheduler_task.cancel()
            try:
                await self._scheduler_task
            except asyncio.CancelledError:
                pass

        self.thread_pool.shutdown(wait=True)
        self.process_pool.shutdown(wait=True)
        logger.info("TaskExecutionLayer stopped")

    def register_handler(self, task_type: str, handler: Callable):
        """Register a handler function for a task type."""
        self._handlers[task_type] = handler
        logger.info("Registered handler for task type: %s", task_type)

    def register_pre_execution_hook(self, hook: Callable):
        """Register a hook to run before task execution."""
        self._pre_execution_hooks.append(hook)

    def register_post_execution_hook(self, hook: Callable):
        """Register a hook to run after task execution."""
        self._post_execution_hooks.append(hook)

    async def submit_task(self, definition: TaskDefinition) -> str:
        """Submit a task for execution."""
        task_id = definition.task_id or str(uuid.uuid4())
        definition.task_id = task_id

        with self._lock:
            self._task_definitions[task_id] = definition
            self._dependency_graph[task_id] = set(definition.dependencies)
            self._completed_dependencies[task_id] = set()

        # Check if dependencies are already satisfied
        if not definition.dependencies:
            await self._enqueue_task(definition)
        else:
            await self._check_dependencies(task_id)

        logger.info("Task submitted: %s (%s)", task_id, definition.name)
        return task_id

    async def cancel_task(self, task_id: str) -> bool:
        """Cancel a pending or running task."""
        with self._lock:
            definition = self._task_definitions.get(task_id)
            if not definition:
                return False

            context = self._task_contexts.get(task_id)
            if context:
                context.cancel()

            running_task = self._running_tasks.get(task_id)
            if running_task:
                running_task.cancel()

        logger.info("Task cancelled: %s", task_id)
        return True

    async def pause_task(self, task_id: str) -> bool:
        """Pause a running task."""
        with self._lock:
            result = self._task_results.get(task_id)
            if result and result.status == TaskStatus.RUNNING:
                result.status = TaskStatus.PAUSED
                return True
        return False

    async def resume_task(self, task_id: str) -> bool:
        """Resume a paused task."""
        with self._lock:
            result = self._task_results.get(task_id)
            definition = self._task_definitions.get(task_id)
            if result and result.status == TaskStatus.PAUSED and definition:
                result.status = TaskStatus.QUEUED
                await self._enqueue_task(definition)
                return True
        return False

    def get_task_status(self, task_id: str) -> Optional[TaskStatus]:
        """Get current status of a task."""
        with self._lock:
            result = self._task_results.get(task_id)
            if result:
                return result.status

            if task_id in self._task_definitions and task_id not in self._task_results:
                return TaskStatus.PENDING

            return None

    def get_task_result(self, task_id: str) -> Optional[TaskResult]:
        """Get result of a completed task."""
        with self._lock:
            return self._task_results.get(task_id)

    def list_tasks(self, status_filter: Optional[TaskStatus] = None) -> List[str]:
        """List all task IDs, optionally filtered by status."""
        with self._lock:
            if status_filter:
                return [tid for tid, result in self._task_results.items() 
                        if result.status == status_filter]
            return list(self._task_definitions.keys())

    async def _enqueue_task(self, definition: TaskDefinition):
        """Add task to the execution queue."""
        priority_value = (definition.priority.value, definition.scheduled_at or time.time())
        await self._task_queue.put((priority_value, definition.task_id))

        with self._lock:
            if definition.task_id not in self._task_results:
                self._task_results[definition.task_id] = TaskResult(
                    task_id=definition.task_id,
                    status=TaskStatus.QUEUED
                )

    async def _check_dependencies(self, task_id: str):
        """Check if task dependencies are satisfied."""
        with self._lock:
            definition = self._task_definitions.get(task_id)
            if not definition:
                return

            completed = self._completed_dependencies.get(task_id, set())
            remaining = self._dependency_graph.get(task_id, set()) - completed

            if not remaining:
                await self._enqueue_task(definition)

    async def _scheduler_loop(self):
        """Main scheduler loop processing tasks from the queue."""
        while self._running:
            try:
                priority_value, task_id = await asyncio.wait_for(
                    self._task_queue.get(), timeout=1.0
                )

                async with self._semaphore:
                    asyncio.create_task(self._execute_task(task_id))

            except asyncio.TimeoutError:
                continue
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.exception("Scheduler error: %s", e)

    async def _execute_task(self, task_id: str):
        """Execute a single task with retry logic and monitoring."""
        with self._lock:
            definition = self._task_definitions.get(task_id)
            if not definition:
                return

            result = self._task_results.get(task_id)
            if not result:
                result = TaskResult(task_id=task_id, status=TaskStatus.RUNNING)
                self._task_results[task_id] = result
            else:
                result.status = TaskStatus.RUNNING

            result.started_at = time.time()

            execution_id = str(uuid.uuid4())
            context = TaskContext(
                task_id=task_id,
                execution_id=execution_id,
                start_time=time.time(),
                deadline=definition.deadline
            )
            self._task_contexts[task_id] = context

        retry_count = 0
        last_error = None

        while retry_count <= definition.max_retries:
            if context.is_cancelled():
                result.status = TaskStatus.CANCELLED
                break

            try:
                # Run pre-execution hooks
                for hook in self._pre_execution_hooks:
                    if asyncio.iscoroutinefunction(hook):
                        await hook(definition, context)
                    else:
                        hook(definition, context)

                # Execute task
                output = await self._run_handler(definition, context)

                # Run post-execution hooks
                for hook in self._post_execution_hooks:
                    if asyncio.iscoroutinefunction(hook):
                        await hook(definition, context, output)
                    else:
                        hook(definition, context, output)

                result.status = TaskStatus.COMPLETED
                result.output = output
                result.execution_time_ms = (time.time() - result.started_at) * 1000
                result.retry_count = retry_count
                result.completed_at = time.time()

                logger.info("Task completed: %s (%.2fms)", task_id, result.execution_time_ms)
                break

            except asyncio.TimeoutError:
                last_error = "Task timeout"
                result.status = TaskStatus.TIMEOUT
                retry_count += 1

            except asyncio.CancelledError:
                result.status = TaskStatus.CANCELLED
                break

            except Exception as e:
                last_error = str(e)
                traceback_str = traceback.format_exc()
                logger.exception("Task execution failed: %s", task_id)

                retry_count += 1
                if retry_count <= definition.max_retries:
                    result.status = TaskStatus.RETRYING
                    await asyncio.sleep(definition.retry_delay_seconds * retry_count)
                else:
                    result.status = TaskStatus.FAILED
                    result.error = f"{last_error}\n{traceback_str}"

        with self._lock:
            result.completed_at = result.completed_at or time.time()
            self._running_tasks.pop(task_id, None)
            self._task_contexts.pop(task_id, None)

            # Notify dependent tasks
            self._notify_dependents(task_id)

    async def _run_handler(self, definition: TaskDefinition, context: TaskContext) -> Any:
        """Execute the task handler based on execution mode."""
        handler = self._handlers.get(definition.task_type)
        if not handler:
            raise ValueError(f"No handler registered for task type: {definition.task_type}")

        timeout = definition.timeout_seconds

        if definition.execution_mode == ExecutionMode.COROUTINE:
            if asyncio.iscoroutinefunction(handler):
                return await asyncio.wait_for(handler(definition.payload, context), timeout=timeout)
            else:
                loop = asyncio.get_event_loop()
                return await asyncio.wait_for(
                    loop.run_in_executor(self.thread_pool, handler, definition.payload, context),
                    timeout=timeout
                )

        elif definition.execution_mode == ExecutionMode.ASYNC:
            return await asyncio.wait_for(handler(definition.payload, context), timeout=timeout)

        elif definition.execution_mode == ExecutionMode.THREAD:
            loop = asyncio.get_event_loop()
            return await asyncio.wait_for(
                loop.run_in_executor(self.thread_pool, handler, definition.payload, context),
                timeout=timeout
            )

        elif definition.execution_mode == ExecutionMode.PROCESS:
            loop = asyncio.get_event_loop()
            return await asyncio.wait_for(
                loop.run_in_executor(self.process_pool, handler, definition.payload, context),
                timeout=timeout
            )

        else:
            raise ValueError(f"Unknown execution mode: {definition.execution_mode}")

    def _notify_dependents(self, completed_task_id: str):
        """Notify tasks that depend on the completed task."""
        with self._lock:
            for task_id, dependencies in self._dependency_graph.items():
                if completed_task_id in dependencies:
                    completed = self._completed_dependencies.get(task_id, set())
                    completed.add(completed_task_id)
                    self._completed_dependencies[task_id] = completed

                    remaining = dependencies - completed
                    if not remaining:
                        definition = self._task_definitions.get(task_id)
                        if definition:
                            asyncio.create_task(self._enqueue_task(definition))

    def get_stats(self) -> Dict[str, Any]:
        """Get execution layer statistics."""
        with self._lock:
            total = len(self._task_definitions)
            completed = sum(1 for r in self._task_results.values() if r.status == TaskStatus.COMPLETED)
            failed = sum(1 for r in self._task_results.values() if r.status == TaskStatus.FAILED)
            running = len(self._running_tasks)
            queued = self._task_queue.qsize()

        return {
            "total_tasks": total,
            "completed": completed,
            "failed": failed,
            "running": running,
            "queued": queued,
            "success_rate": completed / max(total, 1),
            "max_concurrent": self.max_concurrent,
            "registered_handlers": list(self._handlers.keys())
        }

    async def wait_for_task(self, task_id: str, timeout: Optional[float] = None) -> Optional[TaskResult]:
        """Wait for a task to complete."""
        start = time.time()
        while True:
            result = self.get_task_result(task_id)
            if result and result.status in [TaskStatus.COMPLETED, TaskStatus.FAILED, 
                                            TaskStatus.CANCELLED, TaskStatus.TIMEOUT]:
                return result

            if timeout and time.time() - start > timeout:
                return None

            await asyncio.sleep(0.1)

    async def batch_submit(self, definitions: List[TaskDefinition]) -> List[str]:
        """Submit multiple tasks concurrently."""
        tasks = [self.submit_task(d) for d in definitions]
        return await asyncio.gather(*tasks)
