#!/usr/bin/env python3
"""
Nexus Core v2 - Tool Execution Layer
Production-ready implementation for tool discovery, validation, execution, and sandboxing.
"""

import asyncio
import logging
import time
import json
import inspect
import hashlib
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, Union, Type
from concurrent.futures import ThreadPoolExecutor
import threading
import traceback
from contextlib import contextmanager
import re

logger = logging.getLogger(__name__)


class ToolCategory(Enum):
    WEB = auto()
    FILE = auto()
    DATABASE = auto()
    API = auto()
    SYSTEM = auto()
    CODE = auto()
    DATA = auto()
    COMMUNICATION = auto()
    CUSTOM = auto()


class ToolPermission(Enum):
    READ = auto()
    WRITE = auto()
    EXECUTE = auto()
    NETWORK = auto()
    FILESYSTEM = auto()
    SYSTEM = auto()


@dataclass
class ToolParameter:
    name: str
    param_type: Type
    description: str
    required: bool = True
    default: Any = None
    constraints: Dict[str, Any] = field(default_factory=dict)
    enum_values: Optional[List[Any]] = None


@dataclass
class ToolSchema:
    tool_id: str
    name: str
    description: str
    category: ToolCategory
    parameters: List[ToolParameter]
    returns: Type
    return_description: str = ""
    permissions: List[ToolPermission] = field(default_factory=list)
    timeout_seconds: float = 30.0
    retry_count: int = 1
    rate_limit_rpm: int = 60
    examples: List[Dict[str, Any]] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ToolExecution:
    execution_id: str
    tool_id: str
    parameters: Dict[str, Any]
    context: Dict[str, Any] = field(default_factory=dict)
    timeout_seconds: float = 30.0
    retry_count: int = 0
    trace_id: Optional[str] = None


@dataclass
class ToolResult:
    execution_id: str
    tool_id: str
    success: bool
    output: Any = None
    error: Optional[str] = None
    execution_time_ms: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)
    logs: List[str] = field(default_factory=list)


class ToolSandbox:
    """Sandbox environment for tool execution with resource limits."""

    def __init__(self, max_memory_mb: int = 512, max_cpu_time: float = 30.0,
                 allowed_paths: Optional[List[str]] = None,
                 blocked_paths: Optional[List[str]] = None):
        self.max_memory_mb = max_memory_mb
        self.max_cpu_time = max_cpu_time
        self.allowed_paths = allowed_paths or []
        self.blocked_paths = blocked_paths or ["/etc", "/sys", "/proc", "/dev", "/root"]
        self._execution_count = 0
        self._lock = threading.Lock()

    def validate_path(self, path: str) -> bool:
        """Validate if a path is allowed for access."""
        for blocked in self.blocked_paths:
            if path.startswith(blocked):
                return False
        if self.allowed_paths:
            return any(path.startswith(allowed) for allowed in self.allowed_paths)
        return True

    def validate_command(self, command: str) -> bool:
        """Validate if a command is safe to execute."""
        dangerous_patterns = [
            r"rm\s+-rf\s+/",
            r"dd\s+if=.*of=/dev",
            r">\s*/dev",
            r"mkfs",
            r"fdisk",
            r"format",
            r":(){ :|:& };:"
        ]
        for pattern in dangerous_patterns:
            if re.search(pattern, command, re.IGNORECASE):
                return False
        return True

    def check_resource_limits(self) -> bool:
        """Check if resource limits are exceeded."""
        with self._lock:
            self._execution_count += 1
            return True

    @contextmanager
    def execution_context(self):
        """Context manager for sandboxed execution."""
        start_time = time.time()
        try:
            yield self
        finally:
            elapsed = time.time() - start_time
            if elapsed > self.max_cpu_time:
                logger.warning("Tool execution exceeded CPU time limit: %.2fs", elapsed)


class ToolExecutionLayer:
    """
    Core tool execution layer managing tool registration, validation,
    sandboxed execution, and result caching.
    """

    def __init__(self, max_concurrent_tools: int = 20, 
                 default_sandbox: Optional[ToolSandbox] = None):
        self.max_concurrent = max_concurrent_tools
        self.default_sandbox = default_sandbox or ToolSandbox()

        self._tools: Dict[str, ToolSchema] = {}
        self._handlers: Dict[str, Callable] = {}
        self._tool_cache: Dict[str, Any] = {}
        self._cache_ttl: Dict[str, float] = {}
        self._execution_history: List[Dict[str, Any]] = []
        self._history_limit = 10000
        self._rate_limiters: Dict[str, Dict[str, Any]] = {}

        self._semaphore = asyncio.Semaphore(max_concurrent_tools)
        self._lock = threading.RLock()
        self._thread_pool = ThreadPoolExecutor(max_workers=max_concurrent_tools)
        self._running = False

        logger.info("ToolExecutionLayer initialized")

    async def start(self):
        """Start the tool execution layer."""
        self._running = True
        logger.info("ToolExecutionLayer started")

    async def stop(self):
        """Stop the tool execution layer."""
        self._running = False
        self._thread_pool.shutdown(wait=True)
        logger.info("ToolExecutionLayer stopped")

    def register_tool(self, schema: ToolSchema, handler: Callable) -> bool:
        """Register a tool with its schema and handler."""
        with self._lock:
            if schema.tool_id in self._tools:
                logger.warning("Tool %s already registered, updating", schema.tool_id)

            self._tools[schema.tool_id] = schema
            self._handlers[schema.tool_id] = handler
            self._rate_limiters[schema.tool_id] = {
                "requests": 0,
                "window_start": time.time(),
                "rpm": schema.rate_limit_rpm
            }

        logger.info("Registered tool: %s (%s)", schema.tool_id, schema.name)
        return True

    def unregister_tool(self, tool_id: str) -> bool:
        """Unregister a tool."""
        with self._lock:
            if tool_id not in self._tools:
                return False
            del self._tools[tool_id]
            del self._handlers[tool_id]
            del self._rate_limiters[tool_id]

        logger.info("Unregistered tool: %s", tool_id)
        return True

    def get_tool_schema(self, tool_id: str) -> Optional[ToolSchema]:
        """Get schema for a registered tool."""
        with self._lock:
            return self._tools.get(tool_id)

    def list_tools(self, category: Optional[ToolCategory] = None) -> List[ToolSchema]:
        """List all registered tools, optionally filtered by category."""
        with self._lock:
            tools = list(self._tools.values())
            if category:
                tools = [t for t in tools if t.category == category]
            return tools

    def get_tool_schemas_json(self) -> str:
        """Export all tool schemas as JSON for LLM function calling."""
        schemas = []
        with self._lock:
            for tool in self._tools.values():
                schema = {
                    "type": "function",
                    "function": {
                        "name": tool.name,
                        "description": tool.description,
                        "parameters": {
                            "type": "object",
                            "properties": {},
                            "required": []
                        }
                    }
                }

                for param in tool.parameters:
                    param_schema = {
                        "type": self._python_type_to_json(param.param_type),
                        "description": param.description
                    }
                    if param.enum_values:
                        param_schema["enum"] = param.enum_values
                    if param.default is not None:
                        param_schema["default"] = param.default

                    schema["function"]["parameters"]["properties"][param.name] = param_schema
                    if param.required:
                        schema["function"]["parameters"]["required"].append(param.name)

                schemas.append(schema)

        return json.dumps(schemas, indent=2)

    def _python_type_to_json(self, py_type: Type) -> str:
        """Convert Python type to JSON schema type."""
        type_map = {
            str: "string",
            int: "integer",
            float: "number",
            bool: "boolean",
            list: "array",
            dict: "object",
            Any: "string"
        }
        return type_map.get(py_type, "string")

    async def execute(self, execution: ToolExecution) -> ToolResult:
        """Execute a tool with validation, sandboxing, and caching."""
        start_time = time.time()

        with self._lock:
            schema = self._tools.get(execution.tool_id)
            handler = self._handlers.get(execution.tool_id)

        if not schema or not handler:
            return ToolResult(
                execution_id=execution.execution_id,
                tool_id=execution.tool_id,
                success=False,
                error=f"Tool not found: {execution.tool_id}",
                execution_time_ms=(time.time() - start_time) * 1000
            )

        # Check rate limiting
        if not self._check_rate_limit(execution.tool_id):
            return ToolResult(
                execution_id=execution.execution_id,
                tool_id=execution.tool_id,
                success=False,
                error="Rate limit exceeded",
                execution_time_ms=(time.time() - start_time) * 1000
            )

        # Validate parameters
        validation_error = self._validate_parameters(schema, execution.parameters)
        if validation_error:
            return ToolResult(
                execution_id=execution.execution_id,
                tool_id=execution.tool_id,
                success=False,
                error=validation_error,
                execution_time_ms=(time.time() - start_time) * 1000
            )

        # Check cache
        cache_key = self._generate_cache_key(execution)
        cached_result = self._get_cached_result(cache_key)
        if cached_result is not None:
            return ToolResult(
                execution_id=execution.execution_id,
                tool_id=execution.tool_id,
                success=True,
                output=cached_result,
                execution_time_ms=(time.time() - start_time) * 1000,
                metadata={"cached": True}
            )

        # Execute with sandbox
        async with self._semaphore:
            try:
                with self.default_sandbox.execution_context():
                    if asyncio.iscoroutinefunction(handler):
                        output = await asyncio.wait_for(
                            handler(execution.parameters, execution.context),
                            timeout=execution.timeout_seconds
                        )
                    else:
                        loop = asyncio.get_event_loop()
                        output = await asyncio.wait_for(
                            loop.run_in_executor(
                                self._thread_pool, 
                                handler, 
                                execution.parameters, 
                                execution.context
                            ),
                            timeout=execution.timeout_seconds
                        )

                execution_time = (time.time() - start_time) * 1000

                # Cache result if applicable
                self._cache_result(cache_key, output)

                result = ToolResult(
                    execution_id=execution.execution_id,
                    tool_id=execution.tool_id,
                    success=True,
                    output=output,
                    execution_time_ms=execution_time,
                    metadata={"cached": False, "sandboxed": True}
                )

                self._record_execution(execution, result)
                return result

            except asyncio.TimeoutError:
                error_msg = f"Tool execution timeout after {execution.timeout_seconds}s"
                logger.error(error_msg)
                return ToolResult(
                    execution_id=execution.execution_id,
                    tool_id=execution.tool_id,
                    success=False,
                    error=error_msg,
                    execution_time_ms=(time.time() - start_time) * 1000
                )

            except Exception as e:
                error_msg = f"Tool execution failed: {str(e)}"
                traceback_str = traceback.format_exc()
                logger.exception("Tool execution error: %s", execution.tool_id)

                # Retry logic
                if execution.retry_count < schema.retry_count:
                    execution.retry_count += 1
                    await asyncio.sleep(1.0 * execution.retry_count)
                    return await self.execute(execution)

                return ToolResult(
                    execution_id=execution.execution_id,
                    tool_id=execution.tool_id,
                    success=False,
                    error=f"{error_msg}\n{traceback_str}",
                    execution_time_ms=(time.time() - start_time) * 1000
                )

    def _validate_parameters(self, schema: ToolSchema, parameters: Dict[str, Any]) -> Optional[str]:
        """Validate parameters against tool schema."""
        provided_params = set(parameters.keys())
        required_params = {p.name for p in schema.parameters if p.required}

        # Check missing required parameters
        missing = required_params - provided_params
        if missing:
            return f"Missing required parameters: {', '.join(missing)}"

        # Validate each parameter
        for param in schema.parameters:
            if param.name in parameters:
                value = parameters[param.name]

                # Type validation
                if param.param_type != Any and not isinstance(value, param.param_type):
                    return f"Parameter '{param.name}' must be of type {param.param_type.__name__}"

                # Enum validation
                if param.enum_values and value not in param.enum_values:
                    return f"Parameter '{param.name}' must be one of: {param.enum_values}"

                # Constraint validation
                if "min" in param.constraints and value < param.constraints["min"]:
                    return f"Parameter '{param.name}' must be >= {param.constraints['min']}"
                if "max" in param.constraints and value > param.constraints["max"]:
                    return f"Parameter '{param.name}' must be <= {param.constraints['max']}"
                if "pattern" in param.constraints:
                    if not re.match(param.constraints["pattern"], str(value)):
                        return f"Parameter '{param.name}' does not match pattern {param.constraints['pattern']}"

        return None

    def _check_rate_limit(self, tool_id: str) -> bool:
        """Check if tool is within rate limits."""
        with self._lock:
            limiter = self._rate_limiters.get(tool_id)
            if not limiter:
                return True

            now = time.time()
            if now - limiter["window_start"] >= 60:
                limiter["window_start"] = now
                limiter["requests"] = 0

            if limiter["requests"] >= limiter["rpm"]:
                return False

            limiter["requests"] += 1
            return True

    def _generate_cache_key(self, execution: ToolExecution) -> str:
        """Generate cache key for tool execution."""
        key_data = f"{execution.tool_id}:{json.dumps(execution.parameters, sort_keys=True, default=str)}"
        return hashlib.sha256(key_data.encode()).hexdigest()

    def _get_cached_result(self, cache_key: str) -> Optional[Any]:
        """Get cached result if available and not expired."""
        with self._lock:
            if cache_key in self._tool_cache:
                ttl = self._cache_ttl.get(cache_key, 0)
                if time.time() < ttl:
                    return self._tool_cache[cache_key]
                else:
                    del self._tool_cache[cache_key]
                    del self._cache_ttl[cache_key]
        return None

    def _cache_result(self, cache_key: str, result: Any, ttl_seconds: float = 300.0):
        """Cache tool execution result."""
        with self._lock:
            self._tool_cache[cache_key] = result
            self._cache_ttl[cache_key] = time.time() + ttl_seconds

    def _record_execution(self, execution: ToolExecution, result: ToolResult):
        """Record execution for analytics."""
        record = {
            "timestamp": time.time(),
            "execution_id": execution.execution_id,
            "tool_id": execution.tool_id,
            "success": result.success,
            "execution_time_ms": result.execution_time_ms,
            "cached": result.metadata.get("cached", False)
        }

        self._execution_history.append(record)
        if len(self._execution_history) > self._history_limit:
            self._execution_history = self._execution_history[-self._history_limit:]

    def get_execution_stats(self) -> Dict[str, Any]:
        """Get tool execution statistics."""
        with self._lock:
            total_tools = len(self._tools)
            total_executions = len(self._execution_history)

            if total_executions > 0:
                success_count = sum(1 for e in self._execution_history if e["success"])
                avg_time = sum(e["execution_time_ms"] for e in self._execution_history) / total_executions
                success_rate = success_count / total_executions
            else:
                avg_time = 0.0
                success_rate = 0.0

        return {
            "total_tools": total_tools,
            "total_executions": total_executions,
            "success_rate": success_rate,
            "average_execution_time_ms": avg_time,
            "categories": list(set(t.category.name for t in self._tools.values()))
        }

    def clear_cache(self):
        """Clear all cached results."""
        with self._lock:
            self._tool_cache.clear()
            self._cache_ttl.clear()
        logger.info("Tool cache cleared")

    async def batch_execute(self, executions: List[ToolExecution]) -> List[ToolResult]:
        """Execute multiple tools concurrently."""
        tasks = [self.execute(e) for e in executions]
        return await asyncio.gather(*tasks, return_exceptions=True)
