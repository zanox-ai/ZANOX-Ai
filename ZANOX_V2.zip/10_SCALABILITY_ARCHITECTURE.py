#!/usr/bin/env python3
"""
Nexus Core v2 - Scalability Architecture
Production-ready implementation for horizontal scaling, load balancing, and resource management.
"""

import asyncio
import logging
import time
import hashlib
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, Union
from collections import defaultdict
import threading
import json

logger = logging.getLogger(__name__)


class NodeStatus(Enum):
    HEALTHY = auto()
    DEGRADED = auto()
    UNHEALTHY = auto()
    OFFLINE = auto()
    MAINTENANCE = auto()


class ScalingStrategy(Enum):
    HORIZONTAL = auto()
    VERTICAL = auto()
    AUTO = auto()
    MANUAL = auto()


class LoadBalanceAlgorithm(Enum):
    ROUND_ROBIN = auto()
    LEAST_CONNECTIONS = auto()
    WEIGHTED = auto()
    IP_HASH = auto()
    RANDOM = auto()
    LATENCY_BASED = auto()


@dataclass
class Node:
    node_id: str
    host: str
    port: int
    status: NodeStatus = NodeStatus.HEALTHY
    weight: float = 1.0
    current_load: int = 0
    max_capacity: int = 100
    cpu_percent: float = 0.0
    memory_percent: float = 0.0
    network_latency_ms: float = 0.0
    last_heartbeat: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)
    tags: List[str] = field(default_factory=list)
    region: str = "default"
    zone: str = "default"


@dataclass
class Shard:
    shard_id: str
    key_range_start: str
    key_range_end: str
    primary_node: str
    replica_nodes: List[str] = field(default_factory=list)
    status: str = "active"
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ResourcePool:
    pool_id: str
    resource_type: str
    total_capacity: int
    allocated: int = 0
    reserved: int = 0
    nodes: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ScalingRule:
    rule_id: str
    metric: str
    threshold_high: float
    threshold_low: float
    scale_up_factor: float = 1.5
    scale_down_factor: float = 0.5
    cooldown_seconds: float = 300.0
    min_instances: int = 1
    max_instances: int = 100
    last_scaled: float = 0.0
    enabled: bool = True


class ScalabilityArchitecture:
    """
    Core scalability architecture managing node cluster, load balancing,
    sharding, resource pools, and auto-scaling.
    """

    def __init__(self, heartbeat_interval: float = 30.0,
                 node_timeout: float = 90.0,
                 default_algorithm: LoadBalanceAlgorithm = LoadBalanceAlgorithm.LEAST_CONNECTIONS):
        self.heartbeat_interval = heartbeat_interval
        self.node_timeout = node_timeout
        self.default_algorithm = default_algorithm

        self._nodes: Dict[str, Node] = {}
        self._shards: Dict[str, Shard] = {}
        self._resource_pools: Dict[str, ResourcePool] = {}
        self._scaling_rules: Dict[str, ScalingRule] = {}
        self._load_balancer_index: Dict[str, int] = defaultdict(int)
        self._node_weights: Dict[str, float] = {}

        self._lock = threading.RLock()
        self._running = False
        self._monitor_task: Optional[asyncio.Task] = None
        self._scaling_task: Optional[asyncio.Task] = None
        self._health_check_handlers: Dict[str, Callable] = {}
        self._scaling_handlers: Dict[str, Callable] = {}

        logger.info("ScalabilityArchitecture initialized")

    async def start(self):
        """Start the scalability architecture."""
        self._running = True
        self._monitor_task = asyncio.create_task(self._monitor_loop())
        self._scaling_task = asyncio.create_task(self._scaling_loop())
        logger.info("ScalabilityArchitecture started")

    async def stop(self):
        """Stop the scalability architecture."""
        self._running = False

        if self._monitor_task:
            self._monitor_task.cancel()
            try:
                await self._monitor_task
            except asyncio.CancelledError:
                pass

        if self._scaling_task:
            self._scaling_task.cancel()
            try:
                await self._scaling_task
            except asyncio.CancelledError:
                pass

        logger.info("ScalabilityArchitecture stopped")

    def register_node(self, node: Node) -> str:
        """Register a new node in the cluster."""
        with self._lock:
            self._nodes[node.node_id] = node
            self._node_weights[node.node_id] = node.weight

        logger.info("Registered node: %s (%s:%d)", node.node_id, node.host, node.port)
        return node.node_id

    def unregister_node(self, node_id: str) -> bool:
        """Remove a node from the cluster."""
        with self._lock:
            if node_id not in self._nodes:
                return False
            del self._nodes[node_id]
            del self._node_weights[node_id]

        logger.info("Unregistered node: %s", node_id)
        return True

    def update_node_heartbeat(self, node_id: str, metrics: Optional[Dict[str, Any]] = None) -> bool:
        """Update node heartbeat and metrics."""
        with self._lock:
            node = self._nodes.get(node_id)
            if not node:
                return False

            node.last_heartbeat = time.time()

            if metrics:
                node.cpu_percent = metrics.get("cpu_percent", node.cpu_percent)
                node.memory_percent = metrics.get("memory_percent", node.memory_percent)
                node.network_latency_ms = metrics.get("network_latency_ms", node.network_latency_ms)
                node.current_load = metrics.get("current_load", node.current_load)

        return True

    def get_node(self, node_id: str) -> Optional[Node]:
        """Get node by ID."""
        with self._lock:
            return self._nodes.get(node_id)

    def list_nodes(self, status_filter: Optional[NodeStatus] = None,
                   region: Optional[str] = None,
                   tags: Optional[List[str]] = None) -> List[str]:
        """List nodes with optional filters."""
        with self._lock:
            results = []
            for node_id, node in self._nodes.items():
                if status_filter and node.status != status_filter:
                    continue
                if region and node.region != region:
                    continue
                if tags and not any(tag in node.tags for tag in tags):
                    continue
                results.append(node_id)
            return results

    def get_healthy_nodes(self) -> List[Node]:
        """Get all healthy nodes."""
        with self._lock:
            current_time = time.time()
            return [
                node for node in self._nodes.values()
                if node.status == NodeStatus.HEALTHY
                and current_time - node.last_heartbeat < self.node_timeout
            ]

    def select_node(self, algorithm: Optional[LoadBalanceAlgorithm] = None,
                   key: Optional[str] = None,
                   region: Optional[str] = None) -> Optional[Node]:
        """Select a node using the specified load balancing algorithm."""
        algorithm = algorithm or self.default_algorithm

        healthy_nodes = self.get_healthy_nodes()

        if region:
            healthy_nodes = [n for n in healthy_nodes if n.region == region]

        if not healthy_nodes:
            return None

        if algorithm == LoadBalanceAlgorithm.ROUND_ROBIN:
            return self._round_robin(healthy_nodes)
        elif algorithm == LoadBalanceAlgorithm.LEAST_CONNECTIONS:
            return self._least_connections(healthy_nodes)
        elif algorithm == LoadBalanceAlgorithm.WEIGHTED:
            return self._weighted(healthy_nodes)
        elif algorithm == LoadBalanceAlgorithm.IP_HASH:
            return self._ip_hash(healthy_nodes, key or "")
        elif algorithm == LoadBalanceAlgorithm.RANDOM:
            return self._random(healthy_nodes)
        elif algorithm == LoadBalanceAlgorithm.LATENCY_BASED:
            return self._latency_based(healthy_nodes)
        else:
            return healthy_nodes[0]

    def _round_robin(self, nodes: List[Node]) -> Node:
        """Round-robin selection."""
        with self._lock:
            if not nodes:
                return None
            index = self._load_balancer_index["round_robin"] % len(nodes)
            self._load_balancer_index["round_robin"] += 1
            return nodes[index]

    def _least_connections(self, nodes: List[Node]) -> Node:
        """Select node with least connections."""
        return min(nodes, key=lambda n: (n.current_load / n.max_capacity if n.max_capacity > 0 else float('inf')))

    def _weighted(self, nodes: List[Node]) -> Node:
        """Weighted random selection."""
        import random
        weights = [self._node_weights.get(n.node_id, 1.0) for n in nodes]
        total = sum(weights)
        if total == 0:
            return random.choice(nodes)

        r = random.uniform(0, total)
        cumulative = 0
        for node, weight in zip(nodes, weights):
            cumulative += weight
            if r <= cumulative:
                return node
        return nodes[-1]

    def _ip_hash(self, nodes: List[Node], key: str) -> Node:
        """IP hash selection."""
        if not key or not nodes:
            return nodes[0] if nodes else None

        hash_val = int(hashlib.md5(key.encode()).hexdigest(), 16)
        return nodes[hash_val % len(nodes)]

    def _random(self, nodes: List[Node]) -> Node:
        """Random selection."""
        import random
        return random.choice(nodes)

    def _latency_based(self, nodes: List[Node]) -> Node:
        """Select node with lowest latency."""
        return min(nodes, key=lambda n: n.network_latency_ms)

    def create_shard(self, shard_id: str, key_range_start: str, key_range_end: str,
                    primary_node: str, replica_nodes: Optional[List[str]] = None) -> str:
        """Create a new data shard."""
        shard = Shard(
            shard_id=shard_id,
            key_range_start=key_range_start,
            key_range_end=key_range_end,
            primary_node=primary_node,
            replica_nodes=replica_nodes or []
        )

        with self._lock:
            self._shards[shard_id] = shard

        logger.info("Created shard: %s (primary: %s)", shard_id, primary_node)
        return shard_id

    def get_shard_for_key(self, key: str) -> Optional[Shard]:
        """Find shard responsible for a given key."""
        with self._lock:
            for shard in self._shards.values():
                if shard.key_range_start <= key <= shard.key_range_end:
                    return shard
        return None

    def list_shards(self) -> List[str]:
        """List all shard IDs."""
        with self._lock:
            return list(self._shards.keys())

    def create_resource_pool(self, pool_id: str, resource_type: str,
                          total_capacity: int, nodes: Optional[List[str]] = None) -> str:
        """Create a resource pool."""
        pool = ResourcePool(
            pool_id=pool_id,
            resource_type=resource_type,
            total_capacity=total_capacity,
            nodes=nodes or []
        )

        with self._lock:
            self._resource_pools[pool_id] = pool

        logger.info("Created resource pool: %s (%s, capacity: %d)", 
                   pool_id, resource_type, total_capacity)
        return pool_id

    def allocate_resource(self, pool_id: str, amount: int, 
                         reservation: bool = False) -> Tuple[bool, int]:
        """Allocate resources from a pool. Returns (success, allocated_amount)."""
        with self._lock:
            pool = self._resource_pools.get(pool_id)
            if not pool:
                return False, 0

            available = pool.total_capacity - pool.allocated - pool.reserved

            if reservation:
                if available >= amount:
                    pool.reserved += amount
                    return True, amount
                else:
                    return False, 0
            else:
                allocatable = min(amount, available)
                if allocatable > 0:
                    pool.allocated += allocatable
                    return True, allocatable
                return False, 0

    def release_resource(self, pool_id: str, amount: int,
                        reservation: bool = False) -> bool:
        """Release resources back to a pool."""
        with self._lock:
            pool = self._resource_pools.get(pool_id)
            if not pool:
                return False

            if reservation:
                pool.reserved = max(0, pool.reserved - amount)
            else:
                pool.allocated = max(0, pool.allocated - amount)

            return True

    def get_pool_stats(self, pool_id: str) -> Optional[Dict[str, Any]]:
        """Get resource pool statistics."""
        with self._lock:
            pool = self._resource_pools.get(pool_id)
            if not pool:
                return None

            return {
                "pool_id": pool_id,
                "resource_type": pool.resource_type,
                "total_capacity": pool.total_capacity,
                "allocated": pool.allocated,
                "reserved": pool.reserved,
                "available": pool.total_capacity - pool.allocated - pool.reserved,
                "utilization": (pool.allocated + pool.reserved) / pool.total_capacity if pool.total_capacity > 0 else 0,
                "nodes": pool.nodes
            }

    def register_scaling_rule(self, rule: ScalingRule) -> str:
        """Register an auto-scaling rule."""
        with self._lock:
            self._scaling_rules[rule.rule_id] = rule

        logger.info("Registered scaling rule: %s (%s)", rule.rule_id, rule.metric)
        return rule.rule_id

    def unregister_scaling_rule(self, rule_id: str) -> bool:
        """Remove a scaling rule."""
        with self._lock:
            if rule_id not in self._scaling_rules:
                return False
            del self._scaling_rules[rule_id]

        logger.info("Unregistered scaling rule: %s", rule_id)
        return True

    def register_health_check_handler(self, node_type: str, handler: Callable):
        """Register a health check handler for a node type."""
        self._health_check_handlers[node_type] = handler
        logger.info("Registered health check handler for: %s", node_type)

    def register_scaling_handler(self, resource_type: str, handler: Callable):
        """Register a scaling handler for a resource type."""
        self._scaling_handlers[resource_type] = handler
        logger.info("Registered scaling handler for: %s", resource_type)

    async def _monitor_loop(self):
        """Monitor node health and update status."""
        while self._running:
            try:
                current_time = time.time()

                with self._lock:
                    for node_id, node in self._nodes.items():
                        # Check heartbeat timeout
                        if current_time - node.last_heartbeat > self.node_timeout:
                            if node.status != NodeStatus.OFFLINE:
                                node.status = NodeStatus.OFFLINE
                                logger.warning("Node %s marked OFFLINE (heartbeat timeout)", node_id)

                        # Check health metrics
                        elif node.status in [NodeStatus.HEALTHY, NodeStatus.DEGRADED]:
                            if node.cpu_percent > 90 or node.memory_percent > 95:
                                node.status = NodeStatus.DEGRADED
                                logger.warning("Node %s marked DEGRADED (high resource usage)", node_id)
                            elif node.cpu_percent < 80 and node.memory_percent < 85:
                                if node.status == NodeStatus.DEGRADED:
                                    node.status = NodeStatus.HEALTHY
                                    logger.info("Node %s recovered to HEALTHY", node_id)

                        # Run custom health check if available
                        handler = self._health_check_handlers.get(node.metadata.get("node_type", "default"))
                        if handler:
                            try:
                                healthy = handler(node)
                                if not healthy and node.status == NodeStatus.HEALTHY:
                                    node.status = NodeStatus.UNHEALTHY
                                    logger.warning("Node %s marked UNHEALTHY (health check failed)", node_id)
                            except Exception as e:
                                logger.exception("Health check error for node %s: %s", node_id, e)

                await asyncio.sleep(self.heartbeat_interval)

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.exception("Monitor loop error: %s", e)
                await asyncio.sleep(5)

    async def _scaling_loop(self):
        """Auto-scaling loop based on metrics and rules."""
        while self._running:
            try:
                await asyncio.sleep(60)

                with self._lock:
                    for rule_id, rule in self._scaling_rules.items():
                        if not rule.enabled:
                            continue

                        # Check cooldown
                        if time.time() - rule.last_scaled < rule.cooldown_seconds:
                            continue

                        # Get metric value
                        metric_value = self._get_metric(rule.metric)

                        if metric_value is None:
                            continue

                        # Check scale up
                        if metric_value > rule.threshold_high:
                            current_nodes = len([n for n in self._nodes.values() 
                                               if n.status == NodeStatus.HEALTHY])

                            if current_nodes < rule.max_instances:
                                target = min(int(current_nodes * rule.scale_up_factor), rule.max_instances)
                                scale_up_count = target - current_nodes

                                if scale_up_count > 0:
                                    handler = self._scaling_handlers.get(rule.metric)
                                    if handler:
                                        try:
                                            if asyncio.iscoroutinefunction(handler):
                                                await handler("scale_up", scale_up_count)
                                            else:
                                                handler("scale_up", scale_up_count)

                                            rule.last_scaled = time.time()
                                            logger.info("Scaling up %s by %d instances (metric: %.2f)", 
                                                       rule.metric, scale_up_count, metric_value)
                                        except Exception as e:
                                            logger.exception("Scale up failed: %s", e)

                        # Check scale down
                        elif metric_value < rule.threshold_low:
                            current_nodes = len([n for n in self._nodes.values() 
                                               if n.status == NodeStatus.HEALTHY])

                            if current_nodes > rule.min_instances:
                                target = max(int(current_nodes * rule.scale_down_factor), rule.min_instances)
                                scale_down_count = current_nodes - target

                                if scale_down_count > 0:
                                    handler = self._scaling_handlers.get(rule.metric)
                                    if handler:
                                        try:
                                            if asyncio.iscoroutinefunction(handler):
                                                await handler("scale_down", scale_down_count)
                                            else:
                                                handler("scale_down", scale_down_count)

                                            rule.last_scaled = time.time()
                                            logger.info("Scaling down %s by %d instances (metric: %.2f)", 
                                                       rule.metric, scale_down_count, metric_value)
                                        except Exception as e:
                                            logger.exception("Scale down failed: %s", e)

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.exception("Scaling loop error: %s", e)

    def _get_metric(self, metric_name: str) -> Optional[float]:
        """Get current value of a metric."""
        with self._lock:
            if metric_name == "cpu_avg":
                healthy_nodes = [n for n in self._nodes.values() if n.status == NodeStatus.HEALTHY]
                if not healthy_nodes:
                    return None
                return sum(n.cpu_percent for n in healthy_nodes) / len(healthy_nodes)

            elif metric_name == "memory_avg":
                healthy_nodes = [n for n in self._nodes.values() if n.status == NodeStatus.HEALTHY]
                if not healthy_nodes:
                    return None
                return sum(n.memory_percent for n in healthy_nodes) / len(healthy_nodes)

            elif metric_name == "load_avg":
                healthy_nodes = [n for n in self._nodes.values() if n.status == NodeStatus.HEALTHY]
                if not healthy_nodes:
                    return None
                return sum(n.current_load / n.max_capacity for n in healthy_nodes) / len(healthy_nodes)

            elif metric_name == "node_count":
                return len([n for n in self._nodes.values() if n.status == NodeStatus.HEALTHY])

            return None

    def get_cluster_stats(self) -> Dict[str, Any]:
        """Get cluster-wide statistics."""
        with self._lock:
            total_nodes = len(self._nodes)
            healthy_nodes = sum(1 for n in self._nodes.values() if n.status == NodeStatus.HEALTHY)
            degraded_nodes = sum(1 for n in self._nodes.values() if n.status == NodeStatus.DEGRADED)
            unhealthy_nodes = sum(1 for n in self._nodes.values() if n.status == NodeStatus.UNHEALTHY)
            offline_nodes = sum(1 for n in self._nodes.values() if n.status == NodeStatus.OFFLINE)

            total_shards = len(self._shards)
            total_pools = len(self._resource_pools)
            total_rules = len(self._scaling_rules)

            regions = defaultdict(int)
            for node in self._nodes.values():
                regions[node.region] += 1

        return {
            "total_nodes": total_nodes,
            "healthy_nodes": healthy_nodes,
            "degraded_nodes": degraded_nodes,
            "unhealthy_nodes": unhealthy_nodes,
            "offline_nodes": offline_nodes,
            "total_shards": total_shards,
            "total_resource_pools": total_pools,
            "total_scaling_rules": total_rules,
            "regions": dict(regions),
            "load_balance_algorithm": self.default_algorithm.name
        }

    def get_node_stats(self, node_id: str) -> Optional[Dict[str, Any]]:
        """Get statistics for a specific node."""
        with self._lock:
            node = self._nodes.get(node_id)
            if not node:
                return None

            return {
                "node_id": node_id,
                "host": node.host,
                "port": node.port,
                "status": node.status.name,
                "current_load": node.current_load,
                "max_capacity": node.max_capacity,
                "cpu_percent": node.cpu_percent,
                "memory_percent": node.memory_percent,
                "network_latency_ms": node.network_latency_ms,
                "last_heartbeat": node.last_heartbeat,
                "region": node.region,
                "zone": node.zone,
                "weight": node.weight
            }
