#!/usr/bin/env python3
"""
Nexus Core v2 - Human Intervention Engine
Production-ready implementation for human-in-the-loop approval, escalation, and feedback.
"""

import asyncio
import logging
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, Union
from datetime import datetime, timedelta
import threading
import json

logger = logging.getLogger(__name__)


class InterventionType(Enum):
    APPROVAL = auto()
    REJECTION = auto()
    ESCALATION = auto()
    FEEDBACK = auto()
    CLARIFICATION = auto()
    OVERRIDE = auto()
    REVIEW = auto()
    AUDIT = auto()


class InterventionPriority(Enum):
    CRITICAL = 0
    HIGH = 1
    NORMAL = 2
    LOW = 3


class InterventionStatus(Enum):
    PENDING = auto()
    ASSIGNED = auto()
    IN_PROGRESS = auto()
    RESOLVED = auto()
    EXPIRED = auto()
    CANCELLED = auto()


@dataclass
class InterventionRequest:
    request_id: str
    intervention_type: InterventionType
    priority: InterventionPriority
    title: str
    description: str
    context: Dict[str, Any] = field(default_factory=dict)
    requested_by: str = "system"
    assigned_to: Optional[str] = None
    status: InterventionStatus = InterventionStatus.PENDING
    created_at: float = field(default_factory=time.time)
    expires_at: Optional[float] = None
    resolved_at: Optional[float] = None
    resolution: Optional[str] = None
    resolution_data: Dict[str, Any] = field(default_factory=dict)
    tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    escalation_level: int = 0
    max_escalation: int = 3
    auto_approve_after_seconds: Optional[float] = None


@dataclass
class HumanOperator:
    operator_id: str
    name: str
    email: str
    roles: List[str] = field(default_factory=list)
    permissions: List[str] = field(default_factory=list)
    availability_status: str = "available"
    current_load: int = 0
    max_concurrent: int = 5
    expertise_areas: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    last_active: float = field(default_factory=time.time)


@dataclass
class EscalationPolicy:
    policy_id: str
    name: str
    trigger_conditions: List[Dict[str, Any]] = field(default_factory=list)
    escalation_levels: List[Dict[str, Any]] = field(default_factory=list)
    auto_approve_after_seconds: Optional[float] = None
    notify_channels: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


class HumanInterventionEngine:
    """
    Core engine managing human-in-the-loop interactions, approval workflows,
    escalation chains, and operator assignment.
    """

    def __init__(self, default_timeout_seconds: float = 3600.0,
                 max_concurrent_interventions: int = 100):
        self.default_timeout = default_timeout_seconds
        self.max_concurrent = max_concurrent_interventions

        self._requests: Dict[str, InterventionRequest] = {}
        self._operators: Dict[str, HumanOperator] = {}
        self._policies: Dict[str, EscalationPolicy] = {}
        self._operator_queues: Dict[str, asyncio.Queue] = {}
        self._request_callbacks: Dict[str, List[Callable]] = {}
        self._resolution_callbacks: Dict[str, List[Callable]] = {}

        self._lock = threading.RLock()
        self._running = False
        self._monitor_task: Optional[asyncio.Task] = None
        self._assignment_task: Optional[asyncio.Task] = None
        self._notification_handlers: Dict[str, Callable] = {}

        logger.info("HumanInterventionEngine initialized")

    async def start(self):
        """Start the intervention engine."""
        self._running = True
        self._monitor_task = asyncio.create_task(self._monitor_loop())
        self._assignment_task = asyncio.create_task(self._assignment_loop())
        logger.info("HumanInterventionEngine started")

    async def stop(self):
        """Stop the intervention engine."""
        self._running = False

        if self._monitor_task:
            self._monitor_task.cancel()
            try:
                await self._monitor_task
            except asyncio.CancelledError:
                pass

        if self._assignment_task:
            self._assignment_task.cancel()
            try:
                await self._assignment_task
            except asyncio.CancelledError:
                pass

        logger.info("HumanInterventionEngine stopped")

    def register_operator(self, operator: HumanOperator) -> str:
        """Register a human operator."""
        with self._lock:
            self._operators[operator.operator_id] = operator
            self._operator_queues[operator.operator_id] = asyncio.Queue()

        logger.info("Registered operator: %s (%s)", operator.operator_id, operator.name)
        return operator.operator_id

    def unregister_operator(self, operator_id: str) -> bool:
        """Remove an operator."""
        with self._lock:
            if operator_id not in self._operators:
                return False
            del self._operators[operator_id]
            del self._operator_queues[operator_id]

        logger.info("Unregistered operator: %s", operator_id)
        return True

    def register_policy(self, policy: EscalationPolicy) -> str:
        """Register an escalation policy."""
        with self._lock:
            self._policies[policy.policy_id] = policy

        logger.info("Registered policy: %s", policy.policy_id)
        return policy.policy_id

    def register_notification_handler(self, channel: str, handler: Callable):
        """Register a notification handler for a channel."""
        self._notification_handlers[channel] = handler
        logger.info("Registered notification handler for channel: %s", channel)

    def on_request_created(self, intervention_type: InterventionType, callback: Callable):
        """Register callback for new intervention requests."""
        if intervention_type not in self._request_callbacks:
            self._request_callbacks[intervention_type] = []
        self._request_callbacks[intervention_type].append(callback)

    def on_request_resolved(self, intervention_type: InterventionType, callback: Callable):
        """Register callback for resolved interventions."""
        if intervention_type not in self._resolution_callbacks:
            self._resolution_callbacks[intervention_type] = []
        self._resolution_callbacks[intervention_type].append(callback)

    async def create_request(self, intervention_type: InterventionType,
                            priority: InterventionPriority,
                            title: str,
                            description: str,
                            context: Optional[Dict[str, Any]] = None,
                            requested_by: str = "system",
                            assigned_to: Optional[str] = None,
                            expires_at: Optional[float] = None,
                            auto_approve_after: Optional[float] = None,
                            tags: Optional[List[str]] = None,
                            policy_id: Optional[str] = None) -> str:
        """Create a new intervention request."""
        request_id = str(uuid.uuid4())

        if expires_at is None and self.default_timeout > 0:
            expires_at = time.time() + self.default_timeout

        request = InterventionRequest(
            request_id=request_id,
            intervention_type=intervention_type,
            priority=priority,
            title=title,
            description=description,
            context=context or {},
            requested_by=requested_by,
            assigned_to=assigned_to,
            expires_at=expires_at,
            auto_approve_after_seconds=auto_approve_after,
            tags=tags or []
        )

        with self._lock:
            self._requests[request_id] = request

        # Trigger callbacks
        callbacks = self._request_callbacks.get(intervention_type, [])
        for callback in callbacks:
            try:
                if asyncio.iscoroutinefunction(callback):
                    await callback(request)
                else:
                    callback(request)
            except Exception as e:
                logger.exception("Request callback error: %s", e)

        # Send notifications
        if policy_id:
            policy = self._policies.get(policy_id)
            if policy:
                for channel in policy.notify_channels:
                    await self._send_notification(channel, request)

        # Auto-assign if operator specified
        if assigned_to:
            await self._assign_request(request_id, assigned_to)
        else:
            # Auto-assign to best available operator
            await self._auto_assign(request)

        logger.info("Created intervention request: %s (%s)", request_id, title)
        return request_id

    async def resolve_request(self, request_id: str, resolution: str,
                              resolution_data: Optional[Dict[str, Any]] = None,
                              operator_id: Optional[str] = None) -> bool:
        """Resolve an intervention request."""
        with self._lock:
            request = self._requests.get(request_id)
            if not request:
                return False

            if request.status in [InterventionStatus.RESOLVED, InterventionStatus.CANCELLED, InterventionStatus.EXPIRED]:
                return False

            request.status = InterventionStatus.RESOLVED
            request.resolved_at = time.time()
            request.resolution = resolution
            request.resolution_data = resolution_data or {}

            if operator_id:
                operator = self._operators.get(operator_id)
                if operator and operator.current_load > 0:
                    operator.current_load -= 1

        # Trigger callbacks
        callbacks = self._resolution_callbacks.get(request.intervention_type, [])
        for callback in callbacks:
            try:
                if asyncio.iscoroutinefunction(callback):
                    await callback(request)
                else:
                    callback(request)
            except Exception as e:
                logger.exception("Resolution callback error: %s", e)

        logger.info("Resolved intervention request: %s", request_id)
        return True

    async def reject_request(self, request_id: str, reason: str,
                            operator_id: Optional[str] = None) -> bool:
        """Reject an intervention request."""
        return await self.resolve_request(
            request_id,
            f"REJECTED: {reason}",
            {"rejected": True, "reason": reason},
            operator_id
        )

    async def escalate_request(self, request_id: str, reason: str) -> bool:
        """Escalate an intervention request to higher level."""
        with self._lock:
            request = self._requests.get(request_id)
            if not request:
                return False

            if request.escalation_level >= request.max_escalation:
                logger.warning("Request %s reached max escalation level", request_id)
                return False

            request.escalation_level += 1
            request.status = InterventionStatus.PENDING
            request.assigned_to = None

            # Increase priority
            if request.priority != InterventionPriority.CRITICAL:
                priorities = [InterventionPriority.LOW, InterventionPriority.NORMAL,
                             InterventionPriority.HIGH, InterventionPriority.CRITICAL]
                current_idx = priorities.index(request.priority)
                if current_idx < len(priorities) - 1:
                    request.priority = priorities[current_idx + 1]

        # Re-assign to higher-level operator
        await self._auto_assign(request, min_level=request.escalation_level)

        logger.info("Escalated request %s to level %d", request_id, request.escalation_level)
        return True

    async def cancel_request(self, request_id: str, reason: str = "") -> bool:
        """Cancel a pending intervention request."""
        with self._lock:
            request = self._requests.get(request_id)
            if not request or request.status != InterventionStatus.PENDING:
                return False

            request.status = InterventionStatus.CANCELLED
            request.resolution = f"CANCELLED: {reason}"
            request.resolved_at = time.time()

            if request.assigned_to:
                operator = self._operators.get(request.assigned_to)
                if operator and operator.current_load > 0:
                    operator.current_load -= 1

        logger.info("Cancelled intervention request: %s", request_id)
        return True

    def get_request(self, request_id: str) -> Optional[InterventionRequest]:
        """Get intervention request details."""
        with self._lock:
            return self._requests.get(request_id)

    def list_requests(self, status_filter: Optional[InterventionStatus] = None,
                     operator_filter: Optional[str] = None,
                     priority_filter: Optional[InterventionPriority] = None) -> List[str]:
        """List intervention request IDs with optional filters."""
        with self._lock:
            results = []
            for request_id, request in self._requests.items():
                if status_filter and request.status != status_filter:
                    continue
                if operator_filter and request.assigned_to != operator_filter:
                    continue
                if priority_filter and request.priority != priority_filter:
                    continue
                results.append(request_id)
            return results

    def get_operator_stats(self, operator_id: str) -> Optional[Dict[str, Any]]:
        """Get operator statistics."""
        with self._lock:
            operator = self._operators.get(operator_id)
            if not operator:
                return None

            assigned_requests = [
                r for r in self._requests.values()
                if r.assigned_to == operator_id and r.status == InterventionStatus.ASSIGNED
            ]

            resolved_requests = [
                r for r in self._requests.values()
                if r.assigned_to == operator_id and r.status == InterventionStatus.RESOLVED
            ]

            return {
                "operator_id": operator_id,
                "name": operator.name,
                "availability": operator.availability_status,
                "current_load": operator.current_load,
                "max_concurrent": operator.max_concurrent,
                "assigned_requests": len(assigned_requests),
                "resolved_requests": len(resolved_requests),
                "expertise": operator.expertise_areas
            }

    async def _assign_request(self, request_id: str, operator_id: str) -> bool:
        """Assign a request to a specific operator."""
        with self._lock:
            request = self._requests.get(request_id)
            operator = self._operators.get(operator_id)

            if not request or not operator:
                return False

            if operator.current_load >= operator.max_concurrent:
                return False

            if operator.availability_status != "available":
                return False

            request.assigned_to = operator_id
            request.status = InterventionStatus.ASSIGNED
            operator.current_load += 1
            operator.last_active = time.time()

        # Add to operator queue
        queue = self._operator_queues.get(operator_id)
        if queue:
            await queue.put(request_id)

        logger.info("Assigned request %s to operator %s", request_id, operator_id)
        return True

    async def _auto_assign(self, request: InterventionRequest, min_level: int = 0) -> bool:
        """Automatically assign request to best available operator."""
        with self._lock:
            available_operators = []

            for operator_id, operator in self._operators.items():
                if operator.availability_status != "available":
                    continue
                if operator.current_load >= operator.max_concurrent:
                    continue

                # Check expertise match
                expertise_match = any(
                    tag in operator.expertise_areas for tag in request.tags
                ) if request.tags else True

                if expertise_match:
                    available_operators.append((operator_id, operator))

            if not available_operators:
                return False

            # Sort by load (lowest first) and expertise match
            available_operators.sort(key=lambda x: (x[1].current_load, -len(x[1].expertise_areas)))

            selected_id, selected_op = available_operators[0]

        return await self._assign_request(request.request_id, selected_id)

    async def _send_notification(self, channel: str, request: InterventionRequest):
        """Send notification through specified channel."""
        handler = self._notification_handlers.get(channel)
        if handler:
            try:
                if asyncio.iscoroutinefunction(handler):
                    await handler(request)
                else:
                    handler(request)
            except Exception as e:
                logger.exception("Notification error on channel %s: %s", channel, e)

    async def _monitor_loop(self):
        """Monitor for expired requests and auto-approvals."""
        while self._running:
            try:
                current_time = time.time()
                expired_requests = []
                auto_approve_requests = []

                with self._lock:
                    for request_id, request in self._requests.items():
                        if request.status not in [InterventionStatus.PENDING, InterventionStatus.ASSIGNED]:
                            continue

                        # Check expiration
                        if request.expires_at and current_time > request.expires_at:
                            expired_requests.append(request_id)

                        # Check auto-approval
                        elif (request.auto_approve_after_seconds and 
                              request.created_at + request.auto_approve_after_seconds < current_time):
                            auto_approve_requests.append(request_id)

                # Process expired requests
                for request_id in expired_requests:
                    with self._lock:
                        request = self._requests.get(request_id)
                        if request:
                            request.status = InterventionStatus.EXPIRED
                            request.resolution = "EXPIRED: No response within timeout"
                            request.resolved_at = current_time

                    logger.info("Request expired: %s", request_id)

                # Process auto-approvals
                for request_id in auto_approve_requests:
                    await self.resolve_request(request_id, "AUTO_APPROVED: Timeout exceeded")

                await asyncio.sleep(10)

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.exception("Monitor loop error: %s", e)
                await asyncio.sleep(30)

    async def _assignment_loop(self):
        """Background loop for request assignment monitoring."""
        while self._running:
            try:
                await asyncio.sleep(5)

                # Re-assign unassigned pending requests
                with self._lock:
                    for request in self._requests.values():
                        if request.status == InterventionStatus.PENDING and not request.assigned_to:
                            await self._auto_assign(request)

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.exception("Assignment loop error: %s", e)

    def get_stats(self) -> Dict[str, Any]:
        """Get intervention engine statistics."""
        with self._lock:
            total_requests = len(self._requests)
            pending = sum(1 for r in self._requests.values() if r.status == InterventionStatus.PENDING)
            assigned = sum(1 for r in self._requests.values() if r.status == InterventionStatus.ASSIGNED)
            resolved = sum(1 for r in self._requests.values() if r.status == InterventionStatus.RESOLVED)
            expired = sum(1 for r in self._requests.values() if r.status == InterventionStatus.EXPIRED)

            total_operators = len(self._operators)
            available_operators = sum(1 for o in self._operators.values() if o.availability_status == "available")

        return {
            "total_requests": total_requests,
            "pending": pending,
            "assigned": assigned,
            "resolved": resolved,
            "expired": expired,
            "total_operators": total_operators,
            "available_operators": available_operators,
            "resolution_rate": resolved / max(total_requests, 1)
        }
