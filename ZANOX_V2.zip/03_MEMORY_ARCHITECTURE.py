#!/usr/bin/env python3
"""
Nexus Core v2 - Memory Architecture
Production-ready implementation for hierarchical memory management with persistence.
"""

import asyncio
import logging
import time
import hashlib
import json
from dataclasses import dataclass, field, asdict
from enum import Enum, auto
from typing import Any, Dict, List, Optional, Set, Tuple, Union
from collections import OrderedDict, defaultdict
import threading
import pickle
import sqlite3
from pathlib import Path

logger = logging.getLogger(__name__)


class MemoryTier(Enum):
    WORKING = auto()      # Short-term, fast access, limited capacity
    EPISODIC = auto()     # Medium-term, event-based memories
    SEMANTIC = auto()     # Long-term, knowledge and facts
    PROCEDURAL = auto()   # Skills and learned procedures
    ARCHIVAL = auto()     # Cold storage, compressed, slow access


class MemoryPriority(Enum):
    CRITICAL = 0
    HIGH = 1
    NORMAL = 2
    LOW = 3
    EPHEMERAL = 4


@dataclass
class MemoryEntry:
    memory_id: str
    content: Any
    tier: MemoryTier
    priority: MemoryPriority
    tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    accessed_at: float = field(default_factory=time.time)
    access_count: int = 0
    ttl_seconds: Optional[float] = None
    embedding: Optional[List[float]] = None
    compression_level: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "memory_id": self.memory_id,
            "content": self.content,
            "tier": self.tier.name,
            "priority": self.priority.name,
            "tags": self.tags,
            "metadata": self.metadata,
            "created_at": self.created_at,
            "accessed_at": self.accessed_at,
            "access_count": self.access_count,
            "ttl_seconds": self.ttl_seconds,
            "embedding": self.embedding,
            "compression_level": self.compression_level
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'MemoryEntry':
        return cls(
            memory_id=data["memory_id"],
            content=data["content"],
            tier=MemoryTier[data["tier"]],
            priority=MemoryPriority[data["priority"]],
            tags=data.get("tags", []),
            metadata=data.get("metadata", {}),
            created_at=data.get("created_at", time.time()),
            accessed_at=data.get("accessed_at", time.time()),
            access_count=data.get("access_count", 0),
            ttl_seconds=data.get("ttl_seconds"),
            embedding=data.get("embedding"),
            compression_level=data.get("compression_level", 0)
        )


@dataclass
class MemoryQuery:
    query_id: str
    tags: Optional[List[str]] = None
    tier_filter: Optional[MemoryTier] = None
    priority_filter: Optional[MemoryPriority] = None
    time_range: Optional[Tuple[float, float]] = None
    content_pattern: Optional[str] = None
    embedding_query: Optional[List[float]] = None
    similarity_threshold: float = 0.7
    max_results: int = 10
    metadata_filters: Dict[str, Any] = field(default_factory=dict)


class MemoryStore:
    """Abstract base for memory storage backends."""

    async def store(self, entry: MemoryEntry) -> bool:
        raise NotImplementedError

    async def retrieve(self, memory_id: str) -> Optional[MemoryEntry]:
        raise NotImplementedError

    async def search(self, query: MemoryQuery) -> List[MemoryEntry]:
        raise NotImplementedError

    async def delete(self, memory_id: str) -> bool:
        raise NotImplementedError

    async def update(self, entry: MemoryEntry) -> bool:
        raise NotImplementedError


class InMemoryStore(MemoryStore):
    """In-memory LRU cache with TTL support."""

    def __init__(self, max_size: int = 10000):
        self._cache: OrderedDict[str, MemoryEntry] = OrderedDict()
        self._max_size = max_size
        self._lock = threading.RLock()
        self._tag_index: Dict[str, Set[str]] = defaultdict(set)

    async def store(self, entry: MemoryEntry) -> bool:
        with self._lock:
            if len(self._cache) >= self._max_size and entry.memory_id not in self._cache:
                self._evict_oldest()

            self._cache[entry.memory_id] = entry
            self._cache.move_to_end(entry.memory_id)

            for tag in entry.tags:
                self._tag_index[tag].add(entry.memory_id)

        return True

    async def retrieve(self, memory_id: str) -> Optional[MemoryEntry]:
        with self._lock:
            entry = self._cache.get(memory_id)
            if entry:
                if self._is_expired(entry):
                    self._cache.pop(memory_id, None)
                    for tag in entry.tags:
                        self._tag_index[tag].discard(memory_id)
                    return None

                entry.accessed_at = time.time()
                entry.access_count += 1
                self._cache.move_to_end(memory_id)
                return entry
        return None

    async def search(self, query: MemoryQuery) -> List[MemoryEntry]:
        results = []

        with self._lock:
            candidates = set(self._cache.keys())

            if query.tags:
                tag_matches = set()
                for tag in query.tags:
                    tag_matches.update(self._tag_index.get(tag, set()))
                candidates &= tag_matches

            for memory_id in candidates:
                entry = self._cache.get(memory_id)
                if not entry or self._is_expired(entry):
                    continue

                if query.tier_filter and entry.tier != query.tier_filter:
                    continue
                if query.priority_filter and entry.priority != query.priority_filter:
                    continue
                if query.time_range and not (query.time_range[0] <= entry.created_at <= query.time_range[1]):
                    continue
                if query.content_pattern and query.content_pattern not in str(entry.content):
                    continue
                if query.metadata_filters:
                    if not all(entry.metadata.get(k) == v for k, v in query.metadata_filters.items()):
                        continue

                results.append(entry)

            results.sort(key=lambda e: (e.priority.value, -e.access_count, -e.accessed_at))

        return results[:query.max_results]

    async def delete(self, memory_id: str) -> bool:
        with self._lock:
            entry = self._cache.pop(memory_id, None)
            if entry:
                for tag in entry.tags:
                    self._tag_index[tag].discard(memory_id)
                return True
        return False

    async def update(self, entry: MemoryEntry) -> bool:
        with self._lock:
            if entry.memory_id not in self._cache:
                return False
            old_entry = self._cache[entry.memory_id]
            for tag in old_entry.tags:
                self._tag_index[tag].discard(entry.memory_id)

            self._cache[entry.memory_id] = entry
            for tag in entry.tags:
                self._tag_index[tag].add(entry.memory_id)
        return True

    def _is_expired(self, entry: MemoryEntry) -> bool:
        if entry.ttl_seconds is None:
            return False
        return time.time() - entry.created_at > entry.ttl_seconds

    def _evict_oldest(self):
        if self._cache:
            oldest_id, oldest_entry = self._cache.popitem(last=False)
            for tag in oldest_entry.tags:
                self._tag_index[tag].discard(oldest_id)


class SQLiteStore(MemoryStore):
    """Persistent SQLite-backed memory store."""

    def __init__(self, db_path: str = ":memory:"):
        self.db_path = db_path
        self._lock = threading.RLock()
        self._init_db()

    def _init_db(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute('''
                CREATE TABLE IF NOT EXISTS memories (
                    memory_id TEXT PRIMARY KEY,
                    content BLOB,
                    tier TEXT,
                    priority TEXT,
                    tags TEXT,
                    metadata TEXT,
                    created_at REAL,
                    accessed_at REAL,
                    access_count INTEGER DEFAULT 0,
                    ttl_seconds REAL,
                    embedding BLOB,
                    compression_level INTEGER DEFAULT 0
                )
            ''')
            conn.execute('''
                CREATE INDEX IF NOT EXISTS idx_tier ON memories(tier)
            ''')
            conn.execute('''
                CREATE INDEX IF NOT EXISTS idx_priority ON memories(priority)
            ''')
            conn.execute('''
                CREATE INDEX IF NOT EXISTS idx_accessed ON memories(accessed_at)
            ''')
            conn.commit()

    async def store(self, entry: MemoryEntry) -> bool:
        with self._lock:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute('''
                    INSERT OR REPLACE INTO memories 
                    (memory_id, content, tier, priority, tags, metadata, created_at, 
                     accessed_at, access_count, ttl_seconds, embedding, compression_level)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    entry.memory_id,
                    pickle.dumps(entry.content),
                    entry.tier.name,
                    entry.priority.name,
                    json.dumps(entry.tags),
                    json.dumps(entry.metadata),
                    entry.created_at,
                    entry.accessed_at,
                    entry.access_count,
                    entry.ttl_seconds,
                    pickle.dumps(entry.embedding) if entry.embedding else None,
                    entry.compression_level
                ))
                conn.commit()
        return True

    async def retrieve(self, memory_id: str) -> Optional[MemoryEntry]:
        with self._lock:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.execute(
                    "SELECT * FROM memories WHERE memory_id = ?", (memory_id,)
                )
                row = cursor.fetchone()

                if row:
                    entry = self._row_to_entry(row)
                    if self._is_expired(entry):
                        conn.execute("DELETE FROM memories WHERE memory_id = ?", (memory_id,))
                        conn.commit()
                        return None

                    conn.execute(
                        "UPDATE memories SET accessed_at = ?, access_count = access_count + 1 WHERE memory_id = ?",
                        (time.time(), memory_id)
                    )
                    conn.commit()
                    entry.accessed_at = time.time()
                    entry.access_count += 1
                    return entry
        return None

    async def search(self, query: MemoryQuery) -> List[MemoryEntry]:
        results = []

        with self._lock:
            with sqlite3.connect(self.db_path) as conn:
                conditions = ["1=1"]
                params = []

                if query.tier_filter:
                    conditions.append("tier = ?")
                    params.append(query.tier_filter.name)
                if query.priority_filter:
                    conditions.append("priority = ?")
                    params.append(query.priority_filter.name)
                if query.time_range:
                    conditions.append("created_at BETWEEN ? AND ?")
                    params.extend([query.time_range[0], query.time_range[1]])
                if query.tags:
                    conditions.append("tags LIKE ?")
                    params.append(f"%{query.tags[0]}%")

                sql = f"SELECT * FROM memories WHERE {' AND '.join(conditions)} ORDER BY priority, access_count DESC, accessed_at DESC LIMIT ?"
                params.append(query.max_results)

                cursor = conn.execute(sql, params)
                rows = cursor.fetchall()

                for row in rows:
                    entry = self._row_to_entry(row)
                    if not self._is_expired(entry):
                        results.append(entry)

        return results

    async def delete(self, memory_id: str) -> bool:
        with self._lock:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.execute("DELETE FROM memories WHERE memory_id = ?", (memory_id,))
                conn.commit()
                return cursor.rowcount > 0

    async def update(self, entry: MemoryEntry) -> bool:
        return await self.store(entry)

    def _row_to_entry(self, row) -> MemoryEntry:
        return MemoryEntry(
            memory_id=row[0],
            content=pickle.loads(row[1]),
            tier=MemoryTier[row[2]],
            priority=MemoryPriority[row[3]],
            tags=json.loads(row[4]),
            metadata=json.loads(row[5]),
            created_at=row[6],
            accessed_at=row[7],
            access_count=row[8],
            ttl_seconds=row[9],
            embedding=pickle.loads(row[10]) if row[10] else None,
            compression_level=row[11]
        )

    def _is_expired(self, entry: MemoryEntry) -> bool:
        if entry.ttl_seconds is None:
            return False
        return time.time() - entry.created_at > entry.ttl_seconds


class MemoryArchitecture:
    """
    Hierarchical memory architecture managing multiple tiers of memory storage
    with automatic promotion/demotion and persistence.
    """

    def __init__(self, 
                 working_capacity: int = 1000,
                 episodic_capacity: int = 5000,
                 semantic_capacity: int = 10000,
                 archival_db_path: Optional[str] = None):

        self.working = InMemoryStore(max_size=working_capacity)
        self.episodic = InMemoryStore(max_size=episodic_capacity)
        self.semantic = InMemoryStore(max_size=semantic_capacity)

        if archival_db_path:
            self.archival = SQLiteStore(db_path=archival_db_path)
        else:
            self.archival = SQLiteStore()

        self._tier_map: Dict[MemoryTier, MemoryStore] = {
            MemoryTier.WORKING: self.working,
            MemoryTier.EPISODIC: self.episodic,
            MemoryTier.SEMANTIC: self.semantic,
            MemoryTier.PROCEDURAL: self.semantic,
            MemoryTier.ARCHIVAL: self.archival
        }

        self._promotion_threshold = 5
        self._demotion_threshold = 3600
        self._lock = threading.RLock()
        self._maintenance_task: Optional[asyncio.Task] = None
        self._running = False

        logger.info("MemoryArchitecture initialized")

    async def start(self):
        """Start background maintenance tasks."""
        self._running = True
        self._maintenance_task = asyncio.create_task(self._maintenance_loop())
        logger.info("MemoryArchitecture started")

    async def stop(self):
        """Stop background maintenance."""
        self._running = False
        if self._maintenance_task:
            self._maintenance_task.cancel()
            try:
                await self._maintenance_task
            except asyncio.CancelledError:
                pass
        logger.info("MemoryArchitecture stopped")

    async def store(self, content: Any, tier: MemoryTier = MemoryTier.WORKING,
                    priority: MemoryPriority = MemoryPriority.NORMAL,
                    tags: Optional[List[str]] = None,
                    ttl_seconds: Optional[float] = None,
                    metadata: Optional[Dict[str, Any]] = None) -> str:
        """Store content in specified memory tier."""
        memory_id = hashlib.sha256(
            f"{content}{time.time()}{tier.name}".encode()
        ).hexdigest()[:16]

        entry = MemoryEntry(
            memory_id=memory_id,
            content=content,
            tier=tier,
            priority=priority,
            tags=tags or [],
            metadata=metadata or {},
            ttl_seconds=ttl_seconds
        )

        store = self._tier_map.get(tier)
        if store:
            await store.store(entry)

        logger.debug("Stored memory %s in tier %s", memory_id, tier.name)
        return memory_id

    async def retrieve(self, memory_id: str) -> Optional[Any]:
        """Retrieve content by memory ID across all tiers."""
        for tier, store in self._tier_map.items():
            entry = await store.retrieve(memory_id)
            if entry:
                logger.debug("Retrieved memory %s from tier %s", memory_id, tier.name)
                return entry.content

        return None

    async def search(self, query: MemoryQuery) -> List[MemoryEntry]:
        """Search memories across all tiers."""
        all_results = []

        for tier, store in self._tier_map.items():
            if query.tier_filter and tier != query.tier_filter:
                continue

            tier_query = MemoryQuery(
                query_id=query.query_id,
                tags=query.tags,
                tier_filter=tier,
                priority_filter=query.priority_filter,
                time_range=query.time_range,
                content_pattern=query.content_pattern,
                max_results=query.max_results
            )

            results = await store.search(tier_query)
            all_results.extend(results)

        all_results.sort(key=lambda e: (e.priority.value, -e.access_count, -e.accessed_at))
        return all_results[:query.max_results]

    async def delete(self, memory_id: str) -> bool:
        """Delete memory across all tiers."""
        deleted = False
        for store in self._tier_map.values():
            if await store.delete(memory_id):
                deleted = True
        return deleted

    async def promote(self, memory_id: str, target_tier: MemoryTier) -> bool:
        """Promote memory to a higher tier."""
        for tier, store in self._tier_map.items():
            entry = await store.retrieve(memory_id)
            if entry:
                await store.delete(memory_id)
                entry.tier = target_tier
                entry.accessed_at = time.time()
                target_store = self._tier_map.get(target_tier)
                if target_store:
                    await target_store.store(entry)
                logger.info("Promoted memory %s from %s to %s", memory_id, tier.name, target_tier.name)
                return True
        return False

    async def consolidate(self, tags: Optional[List[str]] = None,
                          tier: MemoryTier = MemoryTier.WORKING) -> int:
        """Consolidate memories from working to episodic/semantic."""
        query = MemoryQuery(
            query_id=f"consolidate_{time.time()}",
            tags=tags,
            tier_filter=tier,
            max_results=1000
        )

        memories = await self.search(query)
        consolidated = 0

        for entry in memories:
            if entry.access_count >= self._promotion_threshold:
                if entry.tier == MemoryTier.WORKING:
                    await self.promote(entry.memory_id, MemoryTier.EPISODIC)
                    consolidated += 1
                elif entry.tier == MemoryTier.EPISODIC:
                    await self.promote(entry.memory_id, MemoryTier.SEMANTIC)
                    consolidated += 1

        logger.info("Consolidated %d memories", consolidated)
        return consolidated

    async def _maintenance_loop(self):
        """Background maintenance: TTL cleanup, demotion, consolidation."""
        while self._running:
            try:
                await asyncio.sleep(300)  # Run every 5 minutes

                # Cleanup expired memories
                for tier, store in self._tier_map.items():
                    query = MemoryQuery(
                        query_id=f"cleanup_{tier.name}_{time.time()}",
                        tier_filter=tier,
                        max_results=10000
                    )
                    memories = await store.search(query)
                    for entry in memories:
                        if entry.ttl_seconds and time.time() - entry.created_at > entry.ttl_seconds:
                            await store.delete(entry.memory_id)

                # Consolidate frequently accessed working memories
                await self.consolidate(tier=MemoryTier.WORKING)

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.exception("Memory maintenance error: %s", e)

    def get_stats(self) -> Dict[str, Any]:
        """Get memory architecture statistics."""
        return {
            "tiers": {tier.name: type(store).__name__ for tier, store in self._tier_map.items()},
            "promotion_threshold": self._promotion_threshold,
            "demotion_threshold": self._demotion_threshold,
            "running": self._running
        }
