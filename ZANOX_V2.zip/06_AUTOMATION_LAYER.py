#!/usr/bin/env python3
"""
Nexus Core v2 - Automation Layer
Production-ready implementation for workflow automation, triggers, and scheduling.
"""

import asyncio
import logging
import time
import json
import hashlib
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, Union
from datetime import datetime, timedelta
from croniter import croniter
import threading
import traceback

logger = logging.getLogger(__name__)


class TriggerType(Enum):
    SCHEDULE = auto()
    CRON = auto()
    EVENT = auto()
    WEBHOOK = auto()
    MANUAL = auto()
    CONDITION = auto()
    INTERVAL = auto()


class WorkflowStatus(Enum):
    INACTIVE = auto()
    ACTIVE = auto()
    PAUSED = auto()
    RUNNING = auto()
    COMPLETED = auto()
    FAILED = auto()
    CANCELLED = auto()


class ActionType(Enum):
    EXECUTE_TASK = auto()
    CALL_API = auto()
    SEND_NOTIFICATION = auto()
    UPDATE_STATE = auto()
    CONDITIONAL_BRANCH = auto()
    PARALLEL_EXECUTION = auto()
    DELAY = auto()
    LOOP = auto()
    CUSTOM = auto()


@dataclass
class Trigger:
    trigger_id: str
    trigger_type: TriggerType
    name: str
    enabled: bool = True
    config: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    last_fired: Optional[float] = None
    fire_count: int = 0
    max_fires: Optional[int] = None
    tags: List[str] = field(default_factory=list)


@dataclass
class Action:
    action_id: str
    action_type: ActionType
    name: str
    config: Dict[str, Any] = field(default_factory=dict)
    next_actions: List[str] = field(default_factory=list)
    error_action: Optional[str] = None
    retry_count: int = 0
    max_retries: int = 3
    timeout_seconds: float = 60.0
    condition: Optional[str] = None


@dataclass
class Workflow:
    workflow_id: str
    name: str
    description: str
    triggers: List[Trigger]
    actions: Dict[str, Action]
    entry_point: str
    status: WorkflowStatus = WorkflowStatus.INACTIVE
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    last_run: Optional[float] = None
    run_count: int = 0
    tags: List[str] = field(default_factory=list)
    variables: Dict[str, Any] = field(default_factory=dict)


@dataclass
class WorkflowExecution:
    execution_id: str
    workflow_id: str
    trigger_id: str
    context: Dict[str, Any] = field(default_factory=dict)
    status: WorkflowStatus = WorkflowStatus.RUNNING
    started_at: float = field(default_factory=time.time)
    completed_at: Optional[float] = None
    current_action: Optional[str] = None
    action_results: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None
    variables: Dict[str, Any] = field(default_factory=dict)


class AutomationLayer:
    """
    Core automation layer managing workflows, triggers, scheduling,
    and conditional execution with full state tracking.
    """

    def __init__(self, max_concurrent_workflows: int = 10):
        self.max_concurrent = max_concurrent_workflows

        self._workflows: Dict[str, Workflow] = {}
        self._executions: Dict[str, WorkflowExecution] = {}
        self._triggers: Dict[str, Trigger] = {}
        self._handlers: Dict[str, Callable] = {}
        self._scheduled_tasks: Dict[str, asyncio.Task] = {}
        self._event_listeners: Dict[str, List[Callable]] = {}

        self._semaphore = asyncio.Semaphore(max_concurrent_workflows)
        self._lock = threading.RLock()
        self._running = False
        self._scheduler_task: Optional[asyncio.Task] = None
        self._execution_history: List[Dict[str, Any]] = []
        self._history_limit = 10000

        logger.info("AutomationLayer initialized")

    async def start(self):
        """Start the automation layer and all active workflows."""
        self._running = True
        self._scheduler_task = asyncio.create_task(self._scheduler_loop())

        # Activate all enabled workflows
        with self._lock:
            for workflow in self._workflows.values():
                if workflow.status == WorkflowStatus.INACTIVE:
                    await self._activate_workflow(workflow.workflow_id)

        logger.info("AutomationLayer started")

    async def stop(self):
        """Stop all workflows and the automation layer."""
        self._running = False

        # Cancel all scheduled tasks
        with self._lock:
            for task_id, task in self._scheduled_tasks.items():
                task.cancel()

        if self._scheduler_task:
            self._scheduler_task.cancel()
            try:
                await self._scheduler_task
            except asyncio.CancelledError:
                pass

        logger.info("AutomationLayer stopped")

    def register_workflow(self, workflow: Workflow) -> str:
        """Register a new workflow."""
        with self._lock:
            self._workflows[workflow.workflow_id] = workflow
            for trigger in workflow.triggers:
                self._triggers[trigger.trigger_id] = trigger

        logger.info("Registered workflow: %s (%s)", workflow.workflow_id, workflow.name)
        return workflow.workflow_id

    def unregister_workflow(self, workflow_id: str) -> bool:
        """Remove a workflow."""
        with self._lock:
            workflow = self._workflows.pop(workflow_id, None)
            if not workflow:
                return False

            for trigger in workflow.triggers:
                self._triggers.pop(trigger.trigger_id, None)

            # Cancel any scheduled tasks for this workflow
            for task_id in list(self._scheduled_tasks.keys()):
                if task_id.startswith(workflow_id):
                    task = self._scheduled_tasks.pop(task_id)
                    task.cancel()

        logger.info("Unregistered workflow: %s", workflow_id)
        return True

    def register_action_handler(self, action_type: ActionType, handler: Callable):
        """Register a handler for an action type."""
        self._handlers[action_type] = handler
        logger.info("Registered handler for action type: %s", action_type.name)

    def register_event_listener(self, event_type: str, listener: Callable):
        """Register an event listener."""
        if event_type not in self._event_listeners:
            self._event_listeners[event_type] = []
        self._event_listeners[event_type].append(listener)

    async def activate_workflow(self, workflow_id: str) -> bool:
        """Activate a workflow (enable triggers)."""
        return await self._activate_workflow(workflow_id)

    async def _activate_workflow(self, workflow_id: str) -> bool:
        """Internal workflow activation."""
        with self._lock:
            workflow = self._workflows.get(workflow_id)
            if not workflow:
                return False

            workflow.status = WorkflowStatus.ACTIVE

            # Setup triggers
            for trigger in workflow.triggers:
                if not trigger.enabled:
                    continue

                if trigger.trigger_type in [TriggerType.SCHEDULE, TriggerType.CRON, TriggerType.INTERVAL]:
                    task_id = f"{workflow_id}:{trigger.trigger_id}"
                    task = asyncio.create_task(self._schedule_trigger_loop(workflow_id, trigger))
                    self._scheduled_tasks[task_id] = task

        logger.info("Activated workflow: %s", workflow_id)
        return True

    async def deactivate_workflow(self, workflow_id: str) -> bool:
        """Deactivate a workflow (disable triggers)."""
        with self._lock:
            workflow = self._workflows.get(workflow_id)
            if not workflow:
                return False

            workflow.status = WorkflowStatus.INACTIVE

            # Cancel scheduled tasks for this workflow
            for task_id in list(self._scheduled_tasks.keys()):
                if task_id.startswith(workflow_id):
                    task = self._scheduled_tasks.pop(task_id)
                    task.cancel()

        logger.info("Deactivated workflow: %s", workflow_id)
        return True

    async def trigger_workflow(self, workflow_id: str, trigger_id: str,
                               context: Optional[Dict[str, Any]] = None) -> Optional[str]:
        """Manually trigger a workflow execution."""
        with self._lock:
            workflow = self._workflows.get(workflow_id)
            if not workflow or workflow.status != WorkflowStatus.ACTIVE:
                return None

            trigger = self._triggers.get(trigger_id)
            if not trigger:
                return None

        execution_id = hashlib.sha256(
            f"{workflow_id}:{trigger_id}:{time.time()}".encode()
        ).hexdigest()[:16]

        execution = WorkflowExecution(
            execution_id=execution_id,
            workflow_id=workflow_id,
            trigger_id=trigger_id,
            context=context or {},
            variables=workflow.variables.copy()
        )

        with self._lock:
            self._executions[execution_id] = execution
            workflow.run_count += 1
            workflow.last_run = time.time()

        # Start execution
        asyncio.create_task(self._execute_workflow(execution))

        logger.info("Triggered workflow execution: %s for workflow %s", execution_id, workflow_id)
        return execution_id

    async def _execute_workflow(self, execution: WorkflowExecution):
        """Execute a workflow from entry point through all actions."""
        async with self._semaphore:
            workflow = self._workflows.get(execution.workflow_id)
            if not workflow:
                execution.status = WorkflowStatus.FAILED
                execution.error = "Workflow not found"
                return

            try:
                execution.status = WorkflowStatus.RUNNING
                current_action_id = workflow.entry_point

                while current_action_id and current_action_id in workflow.actions:
                    if not self._running:
                        execution.status = WorkflowStatus.CANCELLED
                        break

                    execution.current_action = current_action_id
                    action = workflow.actions[current_action_id]

                    # Evaluate condition if present
                    if action.condition:
                        if not self._evaluate_condition(action.condition, execution):
                            break

                    # Execute action
                    result = await self._execute_action(action, execution)
                    execution.action_results[action.action_id] = result

                    if result.get("success", False):
                        # Move to next action
                        if action.next_actions:
                            current_action_id = action.next_actions[0]
                        else:
                            current_action_id = None
                    else:
                        # Handle error
                        if action.error_action and action.error_action in workflow.actions:
                            current_action_id = action.error_action
                        else:
                            execution.status = WorkflowStatus.FAILED
                            execution.error = result.get("error", "Action failed")
                            break

                if execution.status == WorkflowStatus.RUNNING:
                    execution.status = WorkflowStatus.COMPLETED

                execution.completed_at = time.time()

            except Exception as e:
                logger.exception("Workflow execution failed: %s", execution.execution_id)
                execution.status = WorkflowStatus.FAILED
                execution.error = str(e)
                execution.completed_at = time.time()

            self._record_execution(execution)

    async def _execute_action(self, action: Action, execution: WorkflowExecution) -> Dict[str, Any]:
        """Execute a single workflow action."""
        handler = self._handlers.get(action.action_type)

        if not handler:
            return {
                "success": False,
                "error": f"No handler for action type: {action.action_type.name}"
            }

        retry_count = 0
        while retry_count <= action.max_retries:
            try:
                # Merge action config with execution context
                config = {**action.config, **execution.context}

                if asyncio.iscoroutinefunction(handler):
                    result = await asyncio.wait_for(
                        handler(config, execution),
                        timeout=action.timeout_seconds
                    )
                else:
                    loop = asyncio.get_event_loop()
                    result = await asyncio.wait_for(
                        loop.run_in_executor(None, handler, config, execution),
                        timeout=action.timeout_seconds
                    )

                return {"success": True, "output": result}

            except asyncio.TimeoutError:
                retry_count += 1
                if retry_count > action.max_retries:
                    return {"success": False, "error": f"Action timeout after {action.timeout_seconds}s"}
                await asyncio.sleep(1.0 * retry_count)

            except Exception as e:
                retry_count += 1
                if retry_count > action.max_retries:
                    return {"success": False, "error": str(e)}
                await asyncio.sleep(1.0 * retry_count)

        return {"success": False, "error": "Max retries exceeded"}

    def _evaluate_condition(self, condition: str, execution: WorkflowExecution) -> bool:
        """Evaluate a workflow condition."""
        try:
            # Simple variable substitution and evaluation
            # In production, use a proper expression evaluator
            variables = {**execution.variables, **execution.context}

            # Replace variables in condition
            for key, value in variables.items():
                condition = condition.replace(f"${{{key}}}", str(value))

            # Evaluate (use with caution - sandbox in production)
            return eval(condition, {"__builtins__": {}}, {})
        except Exception as e:
            logger.error("Condition evaluation failed: %s - %s", condition, e)
            return False

    async def _schedule_trigger_loop(self, workflow_id: str, trigger: Trigger):
        """Background loop for scheduled triggers."""
        while self._running and trigger.enabled:
            try:
                next_fire = self._calculate_next_fire(trigger)
                if next_fire:
                    wait_seconds = next_fire - time.time()
                    if wait_seconds > 0:
                        await asyncio.sleep(wait_seconds)

                    # Check if still enabled and within fire limits
                    if trigger.enabled and (trigger.max_fires is None or trigger.fire_count < trigger.max_fires):
                        await self.trigger_workflow(workflow_id, trigger.trigger_id)
                        trigger.fire_count += 1
                        trigger.last_fired = time.time()
                else:
                    break

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.exception("Schedule trigger error: %s", e)
                await asyncio.sleep(60)

    def _calculate_next_fire(self, trigger: Trigger) -> Optional[float]:
        """Calculate next fire time for a trigger."""
        if trigger.trigger_type == TriggerType.INTERVAL:
            interval = trigger.config.get("interval_seconds", 60)
            if trigger.last_fired:
                return trigger.last_fired + interval
            return time.time()

        elif trigger.trigger_type == TriggerType.CRON:
            cron_expr = trigger.config.get("cron_expression", "* * * * *")
            try:
                itr = croniter(cron_expr, datetime.now())
                next_time = itr.get_next(datetime)
                return next_time.timestamp()
            except Exception:
                return None

        elif trigger.trigger_type == TriggerType.SCHEDULE:
            schedule_time = trigger.config.get("timestamp")
            if schedule_time and schedule_time > time.time():
                return schedule_time
            return None

        return None

    async def _scheduler_loop(self):
        """Main scheduler loop for event-based triggers."""
        while self._running:
            try:
                await asyncio.sleep(1)
            except asyncio.CancelledError:
                break

    async def fire_event(self, event_type: str, event_data: Dict[str, Any]):
        """Fire an event to trigger workflows."""
        listeners = self._event_listeners.get(event_type, [])

        for listener in listeners:
            try:
                if asyncio.iscoroutinefunction(listener):
                    await listener(event_data)
                else:
                    listener(event_data)
            except Exception as e:
                logger.exception("Event listener error: %s", e)

        # Check for event-based triggers
        with self._lock:
            for workflow in self._workflows.values():
                if workflow.status != WorkflowStatus.ACTIVE:
                    continue

                for trigger in workflow.triggers:
                    if trigger.trigger_type == TriggerType.EVENT:
                        if trigger.config.get("event_type") == event_type:
                            await self.trigger_workflow(
                                workflow.workflow_id,
                                trigger.trigger_id,
                                event_data
                            )

    def get_workflow_status(self, workflow_id: str) -> Optional[WorkflowStatus]:
        """Get status of a workflow."""
        with self._lock:
            workflow = self._workflows.get(workflow_id)
            return workflow.status if workflow else None

    def get_execution_status(self, execution_id: str) -> Optional[WorkflowExecution]:
        """Get execution details."""
        with self._lock:
            return self._executions.get(execution_id)

    def list_workflows(self, status_filter: Optional[WorkflowStatus] = None) -> List[str]:
        """List all workflow IDs."""
        with self._lock:
            if status_filter:
                return [wid for wid, w in self._workflows.items() if w.status == status_filter]
            return list(self._workflows.keys())

    def _record_execution(self, execution: WorkflowExecution):
        """Record execution for analytics."""
        record = {
            "timestamp": time.time(),
            "execution_id": execution.execution_id,
            "workflow_id": execution.workflow_id,
            "status": execution.status.name,
            "duration_ms": (execution.completed_at - execution.started_at) * 1000 if execution.completed_at else 0
        }

        self._execution_history.append(record)
        if len(self._execution_history) > self._history_limit:
            self._execution_history = self._execution_history[-self._history_limit:]

    def get_stats(self) -> Dict[str, Any]:
        """Get automation layer statistics."""
        with self._lock:
            total_workflows = len(self._workflows)
            active_workflows = sum(1 for w in self._workflows.values() if w.status == WorkflowStatus.ACTIVE)
            total_executions = len(self._execution_history)

            if total_executions > 0:
                completed = sum(1 for e in self._execution_history if e["status"] == "COMPLETED")
                failed = sum(1 for e in self._execution_history if e["status"] == "FAILED")
                avg_duration = sum(e["duration_ms"] for e in self._execution_history) / total_executions
            else:
                completed = failed = 0
                avg_duration = 0.0

        return {
            "total_workflows": total_workflows,
            "active_workflows": active_workflows,
            "total_executions": total_executions,
            "completed": completed,
            "failed": failed,
            "average_duration_ms": avg_duration,
            "registered_handlers": [h.name for h in self._handlers.keys()]
        }
