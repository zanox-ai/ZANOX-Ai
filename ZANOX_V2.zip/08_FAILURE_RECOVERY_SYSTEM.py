#!/usr/bin/env python3
"""
Nexus Core v2 - Failure Recovery System
Production-ready implementation for error handling, retry logic, circuit breaking, and graceful degradation.
"""

import asyncio
import logging
import time
import traceback
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, Type, Union
from concurrent.futures import ThreadPoolExecutor
import threading
import json
import hashlib

logger = logging.getLogger(__name__)


class FailureType(Enum):
    TRANSIENT = auto()
    PERMANENT = auto()
    TIMEOUT = auto()
    RESOURCE = auto()
    DEPENDENCY = auto()
    VALIDATION = auto()
    SYSTEM = auto()
    NETWORK = auto()
    UNKNOWN = auto()


class RecoveryStrategy(Enum):
    IMMEDIATE_RETRY = auto()
    EXPONENTIAL_BACKOFF = auto()
    LINEAR_BACKOFF = auto()
    CIRCUIT_BREAK = auto()
    FALLBACK = auto()
    DEGRADE = auto()
    NOTIFY = auto()
    ABORT = auto()


class CircuitState(Enum):
    CLOSED = auto()
    OPEN = auto()
    HALF_OPEN = auto()


@dataclass
class FailureRecord:
    failure_id: str
    component: str
    failure_type: FailureType
    error_message: str
    stack_trace: Optional[str] = None
    timestamp: float = field(default_factory=time.time)
    context: Dict[str, Any] = field(default_factory=dict)
    recovery_attempts: int = 0
    recovered: bool = False
    recovery_strategy: RecoveryStrategy = RecoveryStrategy.ABORT
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class RecoveryPolicy:
    policy_id: str
    component: str
    failure_type: FailureType
    strategy: RecoveryStrategy
    max_retries: int = 3
    base_delay_seconds: float = 1.0
    max_delay_seconds: float = 60.0
    circuit_breaker_threshold: int = 5
    circuit_breaker_timeout: float = 60.0
    fallback_handler: Optional[str] = None
    degrade_handler: Optional[str] = None
    notify_channels: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class CircuitBreaker:
    component: str
    state: CircuitState = CircuitState.CLOSED
    failure_count: int = 0
    success_count: int = 0
    last_failure_time: float = 0.0
    threshold: int = 5
    timeout: float = 60.0
    half_open_max_calls: int = 3
    half_open_calls: int = 0


@dataclass
class DegradedService:
    component: str
    original_handler: str
    degraded_handler: str
    active: bool = False
    activation_time: Optional[float] = None
    deactivation_time: Optional[float] = None
    reason: str = ""


class FailureRecoverySystem:
    """
    Core failure recovery system managing error detection, classification,
    retry logic, circuit breaking, and graceful degradation.
    """

    def __init__(self, max_failure_history: int = 10000):
        self.max_history = max_failure_history

        self._failures: Dict[str, FailureRecord] = {}
        self._policies: Dict[str, RecoveryPolicy] = {}
        self._circuit_breakers: Dict[str, CircuitBreaker] = {}
        self._degraded_services: Dict[str, DegradedService] = {}
        self._fallback_handlers: Dict[str, Callable] = {}
        self._degrade_handlers: Dict[str, Callable] = {}
        self._notification_handlers: Dict[str, Callable] = {}
        self._component_health: Dict[str, Dict[str, Any]] = {}

        self._lock = threading.RLock()
        self._running = False
        self._monitor_task: Optional[asyncio.Task] = None
        self._failure_history: List[Dict[str, Any]] = []
        self._recovery_stats: Dict[str, Dict[str, Any]] = {}

        logger.info("FailureRecoverySystem initialized")

    async def start(self):
        """Start the failure recovery system."""
        self._running = True
        self._monitor_task = asyncio.create_task(self._monitor_loop())
        logger.info("FailureRecoverySystem started")

    async def stop(self):
        """Stop the failure recovery system."""
        self._running = False
        if self._monitor_task:
            self._monitor_task.cancel()
            try:
                await self._monitor_task
            except asyncio.CancelledError:
                pass
        logger.info("FailureRecoverySystem stopped")

    def register_policy(self, policy: RecoveryPolicy) -> str:
        """Register a recovery policy for a component."""
        with self._lock:
            self._policies[policy.policy_id] = policy

        logger.info("Registered recovery policy: %s for component %s", 
                   policy.policy_id, policy.component)
        return policy.policy_id

    def register_fallback_handler(self, component: str, handler: Callable):
        """Register a fallback handler for a component."""
        self._fallback_handlers[component] = handler
        logger.info("Registered fallback handler for component: %s", component)

    def register_degrade_handler(self, component: str, handler: Callable):
        """Register a degradation handler for a component."""
        self._degrade_handlers[component] = handler
        logger.info("Registered degrade handler for component: %s", component)

    def register_notification_handler(self, channel: str, handler: Callable):
        """Register a notification handler for a channel."""
        self._notification_handlers[channel] = handler
        logger.info("Registered notification handler for channel: %s", channel)

    async def handle_failure(self, component: str, error: Exception,
                            failure_type: Optional[FailureType] = None,
                            context: Optional[Dict[str, Any]] = None) -> Tuple[bool, Any]:
        """
        Handle a failure for a component. Returns (recovered, result).
        """
        failure_id = hashlib.sha256(
            f"{component}:{time.time()}:{str(error)}".encode()
        ).hexdigest()[:16]

        # Classify failure if not provided
        if failure_type is None:
            failure_type = self._classify_failure(error)

        # Record failure
        record = FailureRecord(
            failure_id=failure_id,
            component=component,
            failure_type=failure_type,
            error_message=str(error),
            stack_trace=traceback.format_exc(),
            context=context or {}
        )

        with self._lock:
            self._failures[failure_id] = record
            self._update_component_health(component, False)

        # Record in history
        self._record_failure(record)

        # Find matching policy
        policy = self._find_policy(component, failure_type)

        if not policy:
            logger.error("No recovery policy for %s failure in %s", failure_type.name, component)
            return False, None

        record.recovery_strategy = policy.strategy

        # Execute recovery strategy
        try:
            if policy.strategy == RecoveryStrategy.IMMEDIATE_RETRY:
                return await self._immediate_retry(component, error, policy, record, context)

            elif policy.strategy == RecoveryStrategy.EXPONENTIAL_BACKOFF:
                return await self._exponential_backoff(component, error, policy, record, context)

            elif policy.strategy == RecoveryStrategy.LINEAR_BACKOFF:
                return await self._linear_backoff(component, error, policy, record, context)

            elif policy.strategy == RecoveryStrategy.CIRCUIT_BREAK:
                return await self._circuit_break_recovery(component, error, policy, record, context)

            elif policy.strategy == RecoveryStrategy.FALLBACK:
                return await self._fallback_recovery(component, error, policy, record, context)

            elif policy.strategy == RecoveryStrategy.DEGRADE:
                return await self._degrade_recovery(component, error, policy, record, context)

            elif policy.strategy == RecoveryStrategy.NOTIFY:
                return await self._notify_recovery(component, error, policy, record, context)

            elif policy.strategy == RecoveryStrategy.ABORT:
                logger.error("Aborting due to failure in %s: %s", component, error)
                return False, None

            else:
                return False, None

        except Exception as recovery_error:
            logger.exception("Recovery failed for %s: %s", component, recovery_error)
            return False, None

    def _classify_failure(self, error: Exception) -> FailureType:
        """Classify an exception into a failure type."""
        error_type = type(error).__name__
        error_msg = str(error).lower()

        if "timeout" in error_msg or "timed out" in error_msg:
            return FailureType.TIMEOUT
        elif "connection" in error_msg or "network" in error_msg or "socket" in error_msg:
            return FailureType.NETWORK
        elif "memory" in error_msg or "resource" in error_msg or "quota" in error_msg:
            return FailureType.RESOURCE
        elif "permission" in error_msg or "unauthorized" in error_msg or "forbidden" in error_msg:
            return FailureType.PERMANENT
        elif "not found" in error_msg or "does not exist" in error_msg:
            return FailureType.DEPENDENCY
        elif "invalid" in error_msg or "validation" in error_msg or "bad request" in error_msg:
            return FailureType.VALIDATION
        elif "system" in error_msg or "internal" in error_msg:
            return FailureType.SYSTEM
        else:
            return FailureType.UNKNOWN

    def _find_policy(self, component: str, failure_type: FailureType) -> Optional[RecoveryPolicy]:
        """Find the best matching recovery policy."""
        with self._lock:
            # Exact match
            for policy in self._policies.values():
                if policy.component == component and policy.failure_type == failure_type:
                    return policy

            # Component match with UNKNOWN type
            for policy in self._policies.values():
                if policy.component == component and policy.failure_type == FailureType.UNKNOWN:
                    return policy

            # Generic policy for failure type
            for policy in self._policies.values():
                if policy.component == "*" and policy.failure_type == failure_type:
                    return policy

            # Default catch-all
            for policy in self._policies.values():
                if policy.component == "*" and policy.failure_type == FailureType.UNKNOWN:
                    return policy

        return None

    async def _immediate_retry(self, component: str, error: Exception,
                            policy: RecoveryPolicy, record: FailureRecord,
                            context: Optional[Dict[str, Any]]) -> Tuple[bool, Any]:
        """Retry immediately without delay."""
        for attempt in range(policy.max_retries):
            try:
                record.recovery_attempts += 1
                # Attempt recovery by re-executing the original operation
                result = await self._attempt_recovery(component, context)

                with self._lock:
                    record.recovered = True
                    self._update_component_health(component, True)

                logger.info("Immediate retry succeeded for %s on attempt %d", component, attempt + 1)
                return True, result

            except Exception as retry_error:
                logger.warning("Immediate retry %d failed for %s: %s", attempt + 1, component, retry_error)
                if attempt == policy.max_retries - 1:
                    return False, None

        return False, None

    async def _exponential_backoff(self, component: str, error: Exception,
                                  policy: RecoveryPolicy, record: FailureRecord,
                                  context: Optional[Dict[str, Any]]) -> Tuple[bool, Any]:
        """Retry with exponential backoff."""
        for attempt in range(policy.max_retries):
            try:
                record.recovery_attempts += 1

                # Calculate delay
                delay = min(policy.base_delay_seconds * (2 ** attempt), policy.max_delay_seconds)
                logger.info("Exponential backoff: waiting %.2fs before retry %d for %s", 
                           delay, attempt + 1, component)
                await asyncio.sleep(delay)

                result = await self._attempt_recovery(component, context)

                with self._lock:
                    record.recovered = True
                    self._update_component_health(component, True)

                logger.info("Exponential backoff retry succeeded for %s on attempt %d", 
                           component, attempt + 1)
                return True, result

            except Exception as retry_error:
                logger.warning("Backoff retry %d failed for %s: %s", attempt + 1, component, retry_error)
                if attempt == policy.max_retries - 1:
                    return False, None

        return False, None

    async def _linear_backoff(self, component: str, error: Exception,
                             policy: RecoveryPolicy, record: FailureRecord,
                             context: Optional[Dict[str, Any]]) -> Tuple[bool, Any]:
        """Retry with linear backoff."""
        for attempt in range(policy.max_retries):
            try:
                record.recovery_attempts += 1

                delay = min(policy.base_delay_seconds * (attempt + 1), policy.max_delay_seconds)
                logger.info("Linear backoff: waiting %.2fs before retry %d for %s", 
                           delay, attempt + 1, component)
                await asyncio.sleep(delay)

                result = await self._attempt_recovery(component, context)

                with self._lock:
                    record.recovered = True
                    self._update_component_health(component, True)

                logger.info("Linear backoff retry succeeded for %s on attempt %d", 
                           component, attempt + 1)
                return True, result

            except Exception as retry_error:
                logger.warning("Linear retry %d failed for %s: %s", attempt + 1, component, retry_error)
                if attempt == policy.max_retries - 1:
                    return False, None

        return False, None

    async def _circuit_break_recovery(self, component: str, error: Exception,
                                     policy: RecoveryPolicy, record: FailureRecord,
                                     context: Optional[Dict[str, Any]]) -> Tuple[bool, Any]:
        """Handle failure with circuit breaker pattern."""
        with self._lock:
            cb = self._circuit_breakers.get(component)
            if not cb:
                cb = CircuitBreaker(
                    component=component,
                    threshold=policy.circuit_breaker_threshold,
                    timeout=policy.circuit_breaker_timeout
                )
                self._circuit_breakers[component] = cb

            cb.failure_count += 1
            cb.last_failure_time = time.time()

            # Check if circuit should open
            if cb.state == CircuitState.CLOSED and cb.failure_count >= cb.threshold:
                cb.state = CircuitState.OPEN
                logger.warning("Circuit breaker OPENED for component: %s", component)

                # Send notifications
                for channel in policy.notify_channels:
                    await self._send_notification(channel, {
                        "type": "circuit_breaker_opened",
                        "component": component,
                        "failure_count": cb.failure_count,
                        "timestamp": time.time()
                    })

            if cb.state == CircuitState.OPEN:
                # Check if timeout has passed
                if time.time() - cb.last_failure_time > cb.timeout:
                    cb.state = CircuitState.HALF_OPEN
                    cb.half_open_calls = 0
                    cb.failure_count = 0
                    logger.info("Circuit breaker HALF_OPEN for component: %s", component)
                else:
                    logger.warning("Circuit breaker OPEN for %s, rejecting request", component)
                    return False, None

            if cb.state == CircuitState.HALF_OPEN:
                if cb.half_open_calls >= cb.half_open_max_calls:
                    logger.warning("Circuit breaker HALF_OPEN limit reached for %s", component)
                    return False, None
                cb.half_open_calls += 1

        # Attempt recovery
        try:
            record.recovery_attempts += 1
            result = await self._attempt_recovery(component, context)

            with self._lock:
                cb.success_count += 1
                if cb.state == CircuitState.HALF_OPEN and cb.success_count >= cb.half_open_max_calls:
                    cb.state = CircuitState.CLOSED
                    cb.failure_count = 0
                    cb.success_count = 0
                    logger.info("Circuit breaker CLOSED for component: %s", component)

                record.recovered = True
                self._update_component_health(component, True)

            return True, result

        except Exception as retry_error:
            with self._lock:
                cb.failure_count += 1
            return False, None

    async def _fallback_recovery(self, component: str, error: Exception,
                                policy: RecoveryPolicy, record: FailureRecord,
                                context: Optional[Dict[str, Any]]) -> Tuple[bool, Any]:
        """Execute fallback handler for recovery."""
        fallback_handler = self._fallback_handlers.get(component)
        if not fallback_handler:
            logger.error("No fallback handler registered for component: %s", component)
            return False, None

        try:
            record.recovery_attempts += 1

            if asyncio.iscoroutinefunction(fallback_handler):
                result = await fallback_handler(context or {})
            else:
                loop = asyncio.get_event_loop()
                result = await loop.run_in_executor(None, fallback_handler, context or {})

            with self._lock:
                record.recovered = True

            logger.info("Fallback recovery succeeded for component: %s", component)
            return True, result

        except Exception as fallback_error:
            logger.exception("Fallback recovery failed for %s: %s", component, fallback_error)
            return False, None

    async def _degrade_recovery(self, component: str, error: Exception,
                                policy: RecoveryPolicy, record: FailureRecord,
                                context: Optional[Dict[str, Any]]) -> Tuple[bool, Any]:
        """Activate degraded service mode."""
        degrade_handler = self._degrade_handlers.get(component)
        if not degrade_handler:
            logger.error("No degrade handler registered for component: %s", component)
            return False, None

        try:
            record.recovery_attempts += 1

            # Activate degraded service
            with self._lock:
                degraded = self._degraded_services.get(component)
                if not degraded:
                    degraded = DegradedService(
                        component=component,
                        original_handler=policy.fallback_handler or "",
                        degraded_handler=policy.degrade_handler or "",
                        active=True,
                        activation_time=time.time(),
                        reason=str(error)
                    )
                    self._degraded_services[component] = degraded
                else:
                    degraded.active = True
                    degraded.activation_time = time.time()
                    degraded.reason = str(error)

            if asyncio.iscoroutinefunction(degrade_handler):
                result = await degrade_handler(context or {})
            else:
                loop = asyncio.get_event_loop()
                result = await loop.run_in_executor(None, degrade_handler, context or {})

            with self._lock:
                record.recovered = True

            logger.info("Degraded service activated for component: %s", component)
            return True, result

        except Exception as degrade_error:
            logger.exception("Degraded recovery failed for %s: %s", component, degrade_error)
            return False, None

    async def _notify_recovery(self, component: str, error: Exception,
                              policy: RecoveryPolicy, record: FailureRecord,
                              context: Optional[Dict[str, Any]]) -> Tuple[bool, Any]:
        """Send notifications without retrying."""
        for channel in policy.notify_channels:
            await self._send_notification(channel, {
                "type": "failure_notification",
                "component": component,
                "failure_type": record.failure_type.name,
                "error": str(error),
                "timestamp": time.time(),
                "context": context or {}
            })

        return False, None

    async def _attempt_recovery(self, component: str, context: Optional[Dict[str, Any]]) -> Any:
        """Attempt to recover by re-executing the original operation."""
        # This is a placeholder - in production, the original operation would be passed
        # For now, we assume the caller handles re-execution
        raise NotImplementedError("Recovery re-execution requires original operation context")

    async def _send_notification(self, channel: str, message: Dict[str, Any]):
        """Send notification through specified channel."""
        handler = self._notification_handlers.get(channel)
        if handler:
            try:
                if asyncio.iscoroutinefunction(handler):
                    await handler(message)
                else:
                    handler(message)
            except Exception as e:
                logger.exception("Notification error on channel %s: %s", channel, e)

    def _update_component_health(self, component: str, healthy: bool):
        """Update component health status."""
        if component not in self._component_health:
            self._component_health[component] = {
                "healthy": True,
                "failure_count": 0,
                "success_count": 0,
                "last_failure": None,
                "last_success": time.time()
            }

        health = self._component_health[component]
        if healthy:
            health["healthy"] = True
            health["success_count"] += 1
            health["last_success"] = time.time()
        else:
            health["failure_count"] += 1
            health["last_failure"] = time.time()
            if health["failure_count"] >= 5:
                health["healthy"] = False

    def _record_failure(self, record: FailureRecord):
        """Record failure in history."""
        history_entry = {
            "timestamp": record.timestamp,
            "failure_id": record.failure_id,
            "component": record.component,
            "failure_type": record.failure_type.name,
            "error": record.error_message,
            "recovered": record.recovered,
            "recovery_attempts": record.recovery_attempts
        }

        self._failure_history.append(history_entry)
        if len(self._failure_history) > self.max_history:
            self._failure_history = self._failure_history[-self.max_history:]

    def get_component_health(self, component: str) -> Optional[Dict[str, Any]]:
        """Get health status for a component."""
        with self._lock:
            health = self._component_health.get(component)
            if not health:
                return None

            cb = self._circuit_breakers.get(component)
            degraded = self._degraded_services.get(component)

            return {
                "component": component,
                "healthy": health["healthy"],
                "failure_count": health["failure_count"],
                "success_count": health["success_count"],
                "circuit_breaker_state": cb.state.name if cb else "N/A",
                "degraded_mode": degraded.active if degraded else False,
                "last_failure": health["last_failure"],
                "last_success": health["last_success"]
            }

    def get_failure_stats(self) -> Dict[str, Any]:
        """Get failure recovery statistics."""
        with self._lock:
            total_failures = len(self._failures)
            recovered = sum(1 for f in self._failures.values() if f.recovered)

            failure_types = {}
            for f in self._failures.values():
                ft = f.failure_type.name
                failure_types[ft] = failure_types.get(ft, 0) + 1

            components = {}
            for f in self._failures.values():
                comp = f.component
                components[comp] = components.get(comp, 0) + 1

        return {
            "total_failures": total_failures,
            "recovered": recovered,
            "recovery_rate": recovered / max(total_failures, 1),
            "failure_types": failure_types,
            "component_failures": components,
            "active_circuit_breakers": sum(1 for cb in self._circuit_breakers.values() if cb.state != CircuitState.CLOSED),
            "degraded_services": sum(1 for d in self._degraded_services.values() if d.active)
        }

    async def reset_circuit_breaker(self, component: str) -> bool:
        """Manually reset circuit breaker for a component."""
        with self._lock:
            cb = self._circuit_breakers.get(component)
            if not cb:
                return False

            cb.state = CircuitState.CLOSED
            cb.failure_count = 0
            cb.success_count = 0
            cb.half_open_calls = 0

        logger.info("Circuit breaker manually reset for component: %s", component)
        return True

    async def restore_service(self, component: str) -> bool:
        """Restore a degraded service to normal operation."""
        with self._lock:
            degraded = self._degraded_services.get(component)
            if not degraded or not degraded.active:
                return False

            degraded.active = False
            degraded.deactivation_time = time.time()

        logger.info("Service restored for component: %s", component)
        return True

    async def _monitor_loop(self):
        """Background monitoring loop for circuit breakers and degraded services."""
        while self._running:
            try:
                await asyncio.sleep(30)

                current_time = time.time()

                with self._lock:
                    # Check circuit breakers for timeout
                    for component, cb in self._circuit_breakers.items():
                        if cb.state == CircuitState.OPEN:
                            if current_time - cb.last_failure_time > cb.timeout:
                                cb.state = CircuitState.HALF_OPEN
                                cb.half_open_calls = 0
                                cb.failure_count = 0
                                logger.info("Circuit breaker auto-transition to HALF_OPEN for %s", component)

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.exception("Monitor loop error: %s", e)
