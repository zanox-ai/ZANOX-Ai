#!/usr/bin/env python3
"""
Nexus Core v2 - Agent Activation Engine
Production-ready implementation for autonomous agent lifecycle management.
"""

import asyncio
import logging
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Callable, Dict, List, Optional, Set, Type
from concurrent.futures import ThreadPoolExecutor
import threading

logger = logging.getLogger(__name__)


class AgentState(Enum):
    INACTIVE = auto()
    INITIALIZING = auto()
    ACTIVE = auto()
    PAUSED = auto()
    TERMINATING = auto()
    TERMINATED = auto()
    ERROR = auto()


class AgentPriority(Enum):
    CRITICAL = 0
    HIGH = 1
    NORMAL = 2
    LOW = 3
    BACKGROUND = 4


@dataclass
class AgentProfile:
    agent_id: str
    name: str
    agent_type: str
    priority: AgentPriority = AgentPriority.NORMAL
    capabilities: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    max_retries: int = 3
    timeout_seconds: float = 300.0


@dataclass
class AgentInstance:
    profile: AgentProfile
    state: AgentState = AgentState.INACTIVE
    task_queue: asyncio.Queue = field(default_factory=asyncio.Queue)
    active_task: Optional[Any] = None
    last_heartbeat: float = 0.0
    error_count: int = 0
    success_count: int = 0
    thread_pool: Optional[ThreadPoolExecutor] = None
    _lock: threading.RLock = field(default_factory=threading.RLock)
    _task_event: asyncio.Event = field(default_factory=asyncio.Event)


class AgentActivationEngine:
    """
    Core engine responsible for agent registration, activation, lifecycle management,
    and state transitions. Handles concurrent agent execution with thread safety.
    """

    def __init__(self, max_concurrent_agents: int = 100, heartbeat_interval: float = 30.0):
        self.agents: Dict[str, AgentInstance] = {}
        self.agent_types: Dict[str, Type] = {}
        self._lock = threading.RLock()
        self._executor = ThreadPoolExecutor(max_workers=max_concurrent_agents)
        self.heartbeat_interval = heartbeat_interval
        self._running = False
        self._heartbeat_task: Optional[asyncio.Task] = None
        self._state_callbacks: Dict[AgentState, List[Callable]] = {
            state: [] for state in AgentState
        }
        self._activation_queue: asyncio.PriorityQueue = asyncio.PriorityQueue()
        self._semaphore = asyncio.Semaphore(max_concurrent_agents)
        logger.info("AgentActivationEngine initialized with max_concurrent=%d", max_concurrent_agents)

    async def start(self):
        """Start the activation engine and heartbeat monitor."""
        self._running = True
        self._heartbeat_task = asyncio.create_task(self._heartbeat_monitor())
        logger.info("AgentActivationEngine started")

    async def stop(self):
        """Gracefully stop all agents and the engine."""
        self._running = False

        with self._lock:
            agents_to_stop = list(self.agents.values())

        for agent in agents_to_stop:
            await self.deactivate_agent(agent.profile.agent_id)

        if self._heartbeat_task:
            self._heartbeat_task.cancel()
            try:
                await self._heartbeat_task
            except asyncio.CancelledError:
                pass

        self._executor.shutdown(wait=True)
        logger.info("AgentActivationEngine stopped")

    def register_agent_type(self, agent_type: str, agent_class: Type):
        """Register an agent class for a given type string."""
        with self._lock:
            self.agent_types[agent_type] = agent_class
        logger.info("Registered agent type: %s", agent_type)

    async def register_agent(self, profile: AgentProfile) -> str:
        """Register a new agent with the engine."""
        agent_id = profile.agent_id or str(uuid.uuid4())
        profile.agent_id = agent_id

        instance = AgentInstance(
            profile=profile,
            thread_pool=self._executor
        )

        with self._lock:
            if agent_id in self.agents:
                raise ValueError(f"Agent {agent_id} already registered")
            self.agents[agent_id] = instance

        logger.info("Agent registered: %s (%s)", agent_id, profile.name)
        return agent_id

    async def activate_agent(self, agent_id: str, context: Optional[Dict[str, Any]] = None) -> bool:
        """Activate a registered agent and begin its execution loop."""
        with self._lock:
            agent = self.agents.get(agent_id)
            if not agent:
                logger.error("Agent not found: %s", agent_id)
                return False

            if agent.state not in [AgentState.INACTIVE, AgentState.ERROR, AgentState.PAUSED]:
                logger.warning("Agent %s cannot be activated from state %s", agent_id, agent.state)
                return False

            agent.state = AgentState.INITIALIZING

        await self._trigger_state_callbacks(agent, AgentState.INITIALIZING, context)

        try:
            # Initialize agent resources
            await self._initialize_agent(agent, context)

            with self._lock:
                agent.state = AgentState.ACTIVE
                agent.last_heartbeat = time.time()

            await self._trigger_state_callbacks(agent, AgentState.ACTIVE, context)

            # Start agent execution loop
            asyncio.create_task(self._agent_execution_loop(agent))

            logger.info("Agent activated: %s", agent_id)
            return True

        except Exception as e:
            logger.exception("Failed to activate agent %s: %s", agent_id, e)
            with self._lock:
                agent.state = AgentState.ERROR
                agent.error_count += 1
            await self._trigger_state_callbacks(agent, AgentState.ERROR, {"error": str(e)})
            return False

    async def deactivate_agent(self, agent_id: str, force: bool = False) -> bool:
        """Deactivate an active agent gracefully."""
        with self._lock:
            agent = self.agents.get(agent_id)
            if not agent:
                return False

            if agent.state == AgentState.TERMINATED:
                return True

            previous_state = agent.state
            agent.state = AgentState.TERMINATING

        await self._trigger_state_callbacks(agent, AgentState.TERMINATING, None)

        try:
            # Allow graceful shutdown unless forced
            if not force and previous_state == AgentState.ACTIVE:
                await asyncio.wait_for(agent._task_event.wait(), timeout=5.0)

            # Cleanup resources
            await self._cleanup_agent(agent)

            with self._lock:
                agent.state = AgentState.TERMINATED

            await self._trigger_state_callbacks(agent, AgentState.TERMINATED, None)
            logger.info("Agent deactivated: %s", agent_id)
            return True

        except Exception as e:
            logger.exception("Error deactivating agent %s: %s", agent_id, e)
            with self._lock:
                agent.state = AgentState.ERROR
            return False

    async def pause_agent(self, agent_id: str) -> bool:
        """Pause an active agent."""
        with self._lock:
            agent = self.agents.get(agent_id)
            if not agent or agent.state != AgentState.ACTIVE:
                return False
            agent.state = AgentState.PAUSED

        await self._trigger_state_callbacks(agent, AgentState.PAUSED, None)
        logger.info("Agent paused: %s", agent_id)
        return True

    async def resume_agent(self, agent_id: str) -> bool:
        """Resume a paused agent."""
        with self._lock:
            agent = self.agents.get(agent_id)
            if not agent or agent.state != AgentState.PAUSED:
                return False
            agent.state = AgentState.ACTIVE
            agent._task_event.set()

        await self._trigger_state_callbacks(agent, AgentState.ACTIVE, None)
        logger.info("Agent resumed: %s", agent_id)
        return True

    def get_agent_state(self, agent_id: str) -> Optional[AgentState]:
        """Get current state of an agent."""
        with self._lock:
            agent = self.agents.get(agent_id)
            return agent.state if agent else None

    def get_agent_stats(self, agent_id: str) -> Optional[Dict[str, Any]]:
        """Get statistics for an agent."""
        with self._lock:
            agent = self.agents.get(agent_id)
            if not agent:
                return None
            return {
                "agent_id": agent_id,
                "state": agent.state.name,
                "success_count": agent.success_count,
                "error_count": agent.error_count,
                "last_heartbeat": agent.last_heartbeat,
                "profile": {
                    "name": agent.profile.name,
                    "type": agent.profile.agent_type,
                    "priority": agent.profile.priority.name
                }
            }

    def list_agents(self, state_filter: Optional[AgentState] = None) -> List[str]:
        """List all agent IDs, optionally filtered by state."""
        with self._lock:
            if state_filter:
                return [aid for aid, agent in self.agents.items() if agent.state == state_filter]
            return list(self.agents.keys())

    def on_state_change(self, state: AgentState, callback: Callable):
        """Register a callback for state changes."""
        self._state_callbacks[state].append(callback)

    async def _initialize_agent(self, agent: AgentInstance, context: Optional[Dict[str, Any]]):
        """Initialize agent-specific resources."""
        agent_class = self.agent_types.get(agent.profile.agent_type)
        if agent_class and hasattr(agent_class, 'initialize'):
            if asyncio.iscoroutinefunction(agent_class.initialize):
                await agent_class.initialize(agent, context)
            else:
                loop = asyncio.get_event_loop()
                await loop.run_in_executor(self._executor, agent_class.initialize, agent, context)

    async def _cleanup_agent(self, agent: AgentInstance):
        """Cleanup agent resources."""
        agent_class = self.agent_types.get(agent.profile.agent_type)
        if agent_class and hasattr(agent_class, 'cleanup'):
            if asyncio.iscoroutinefunction(agent_class.cleanup):
                await agent_class.cleanup(agent)
            else:
                loop = asyncio.get_event_loop()
                await loop.run_in_executor(self._executor, agent_class.cleanup, agent)

    async def _agent_execution_loop(self, agent: AgentInstance):
        """Main execution loop for an active agent."""
        while self._running and agent.state in [AgentState.ACTIVE, AgentState.PAUSED]:
            try:
                if agent.state == AgentState.PAUSED:
                    agent._task_event.clear()
                    await agent._task_event.wait()
                    continue

                # Process tasks from queue with timeout
                try:
                    task = await asyncio.wait_for(
                        agent.task_queue.get(), 
                        timeout=agent.profile.timeout_seconds
                    )
                except asyncio.TimeoutError:
                    continue

                agent.active_task = task
                agent.last_heartbeat = time.time()

                # Execute task
                success = await self._execute_task(agent, task)

                with self._lock:
                    if success:
                        agent.success_count += 1
                    else:
                        agent.error_count += 1

                agent.active_task = None
                agent.task_queue.task_done()

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.exception("Error in agent execution loop %s: %s", agent.profile.agent_id, e)
                with self._lock:
                    agent.error_count += 1
                await asyncio.sleep(1)

    async def _execute_task(self, agent: AgentInstance, task: Any) -> bool:
        """Execute a single task for an agent."""
        agent_class = self.agent_types.get(agent.profile.agent_type)
        if not agent_class or not hasattr(agent_class, 'execute'):
            return False

        try:
            if asyncio.iscoroutinefunction(agent_class.execute):
                result = await agent_class.execute(agent, task)
            else:
                loop = asyncio.get_event_loop()
                result = await loop.run_in_executor(self._executor, agent_class.execute, agent, task)
            return result is not False
        except Exception as e:
            logger.exception("Task execution failed for agent %s: %s", agent.profile.agent_id, e)
            return False

    async def _heartbeat_monitor(self):
        """Monitor agent health via heartbeats."""
        while self._running:
            try:
                current_time = time.time()
                with self._lock:
                    agents_snapshot = list(self.agents.items())

                for agent_id, agent in agents_snapshot:
                    if agent.state == AgentState.ACTIVE:
                        time_since_heartbeat = current_time - agent.last_heartbeat
                        if time_since_heartbeat > self.heartbeat_interval * 3:
                            logger.warning("Agent %s heartbeat timeout (%.1fs)", agent_id, time_since_heartbeat)
                            await self.deactivate_agent(agent_id, force=True)

                await asyncio.sleep(self.heartbeat_interval)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.exception("Heartbeat monitor error: %s", e)
                await asyncio.sleep(5)

    async def _trigger_state_callbacks(self, agent: AgentInstance, state: AgentState, context: Optional[Dict]):
        """Trigger registered callbacks for state changes."""
        callbacks = self._state_callbacks.get(state, [])
        for callback in callbacks:
            try:
                if asyncio.iscoroutinefunction(callback):
                    await callback(agent, state, context)
                else:
                    callback(agent, state, context)
            except Exception as e:
                logger.exception("State callback error: %s", e)

    async def submit_task(self, agent_id: str, task: Any, priority: int = 0) -> bool:
        """Submit a task to an agent's queue."""
        with self._lock:
            agent = self.agents.get(agent_id)
            if not agent or agent.state not in [AgentState.ACTIVE, AgentState.PAUSED]:
                return False

        await agent.task_queue.put(task)
        return True

    def get_active_agent_count(self) -> int:
        """Get count of currently active agents."""
        with self._lock:
            return sum(1 for agent in self.agents.values() if agent.state == AgentState.ACTIVE)

    async def health_check(self) -> Dict[str, Any]:
        """Perform comprehensive health check of the engine."""
        with self._lock:
            total = len(self.agents)
            active = sum(1 for a in self.agents.values() if a.state == AgentState.ACTIVE)
            errors = sum(a.error_count for a in self.agents.values())

        return {
            "engine_status": "healthy" if self._running else "stopped",
            "total_agents": total,
            "active_agents": active,
            "total_errors": errors,
            "heartbeat_interval": self.heartbeat_interval,
            "registered_types": list(self.agent_types.keys())
        }
