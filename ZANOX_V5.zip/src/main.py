"""FastAPI application for Nexus Core V5.

Main API entry point.
"""
from fastapi import FastAPI, Depends, HTTPException, status, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager

from .api.builder_routes import router as builder_router
from .api.project_routes import router as project_router
from .api.deployment_routes import router as deployment_router
from .api.artifact_routes import router as artifact_router
from .api.workflow_routes import router as workflow_router
from .api.analytics_routes import router as analytics_router
from .api.health_routes import router as health_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan handler."""
    # Startup
    print("Nexus Core V5 starting up...")
    yield
    # Shutdown
    print("Nexus Core V5 shutting down...")


app = FastAPI(
    title="Nexus Core V5",
    description="Universal Builder Connector Layer",
    version="5.0.0",
    lifespan=lifespan,
)

# Middleware
app.add_middleware(GZipMiddleware, minimum_size=1000)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Global exception handler."""
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "error": "Internal server error",
            "detail": str(exc),
            "path": str(request.url.path),
        },
    )


@app.get("/")
async def root():
    """Root endpoint."""
    return {
        "name": "Nexus Core V5",
        "version": "5.0.0",
        "status": "operational",
        "builders_supported": 14,
        "project_types_supported": 13,
    }


@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "timestamp": "2026-06-17T01:42:00Z",
        "components": {
            "api": "healthy",
            "database": "healthy",
            "cache": "healthy",
            "queue": "healthy",
        },
    }


# Include routers
app.include_router(builder_router, prefix="/api/v1/builders", tags=["Builders"])
app.include_router(project_router, prefix="/api/v1/projects", tags=["Projects"])
app.include_router(deployment_router, prefix="/api/v1/deployments", tags=["Deployments"])
app.include_router(artifact_router, prefix="/api/v1/artifacts", tags=["Artifacts"])
app.include_router(workflow_router, prefix="/api/v1/workflows", tags=["Workflows"])
app.include_router(analytics_router, prefix="/api/v1/analytics", tags=["Analytics"])
app.include_router(health_router, prefix="/api/v1/health", tags=["Health"])
