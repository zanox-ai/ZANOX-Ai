"""Builder Workflow Engine for Nexus Core V5.

Manages and executes builder workflows.
"""
import uuid
import asyncio
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.orm import Session

from ..schemas.workflow import (
    WorkflowCreate, WorkflowUpdate, WorkflowResponse,
    WorkflowExecutionCreate, WorkflowExecutionResponse,
    WorkflowStep, WorkflowTrigger
)
from database.models import WorkflowModel, WorkflowExecutionModel


class WorkflowEngine:
    """Executes builder workflows."""

    def __init__(self, db_session: Session, connector_factory):
        self.db = db_session
        self.connectors = connector_factory
        self._executions: Dict[str, asyncio.Task] = {}

    def create_workflow(self, workflow_data: WorkflowCreate) -> WorkflowResponse:
        """Create a new workflow."""
        workflow_id = str(uuid.uuid4())

        workflow = WorkflowModel(
            id=workflow_id,
            name=workflow_data.name,
            description=workflow_data.description,
            workflow_type=workflow_data.workflow_type,
            steps=[step.model_dump() for step in workflow_data.steps],
            triggers=[trigger.model_dump() for trigger in workflow_data.triggers],
            conditions=workflow_data.conditions,
            status="active",
            is_template=workflow_data.is_template,
            metadata=workflow_data.metadata,
            tags=workflow_data.tags,
            created_at=datetime.utcnow(),
        )

        self.db.add(workflow)
        self.db.commit()
        self.db.refresh(workflow)

        return self._to_response(workflow)

    def get_workflow(self, workflow_id: str) -> Optional[WorkflowResponse]:
        """Get workflow by ID."""
        workflow = self.db.query(WorkflowModel).filter(WorkflowModel.id == workflow_id).first()
        if not workflow:
            return None
        return self._to_response(workflow)

    def list_workflows(
        self,
        workflow_type: Optional[str] = None,
        status: Optional[str] = None,
        is_template: Optional[bool] = None,
        skip: int = 0,
        limit: int = 100,
    ) -> List[WorkflowResponse]:
        """List workflows."""
        query = self.db.query(WorkflowModel)

        if workflow_type:
            query = query.filter(WorkflowModel.workflow_type == workflow_type)
        if status:
            query = query.filter(WorkflowModel.status == status)
        if is_template is not None:
            query = query.filter(WorkflowModel.is_template == is_template)

        workflows = query.offset(skip).limit(limit).all()
        return [self._to_response(w) for w in workflows]

    async def execute_workflow(self, execution_data: WorkflowExecutionCreate) -> WorkflowExecutionResponse:
        """Execute a workflow."""
        execution_id = str(uuid.uuid4())

        workflow = self.db.query(WorkflowModel).filter(WorkflowModel.id == execution_data.workflow_id).first()
        if not workflow:
            raise ValueError("Workflow not found")

        steps = workflow.steps or []

        execution = WorkflowExecutionModel(
            id=execution_id,
            workflow_id=execution_data.workflow_id,
            project_id=execution_data.project_id,
            status="pending",
            current_step=0,
            total_steps=len(steps),
            results={},
            created_at=datetime.utcnow(),
        )

        self.db.add(execution)
        self.db.commit()
        self.db.refresh(execution)

        # Start execution asynchronously
        task = asyncio.create_task(self._run_execution(execution_id, steps, execution_data.input_data))
        self._executions[execution_id] = task

        return self._to_execution_response(execution)

    async def _run_execution(self, execution_id: str, steps: List[Dict], input_data: Dict):
        """Run workflow execution."""
        execution = self.db.query(WorkflowExecutionModel).filter(
            WorkflowExecutionModel.id == execution_id
        ).first()

        if not execution:
            return

        execution.status = "running"
        execution.started_at = datetime.utcnow()
        self.db.commit()

        results = {}

        try:
            for i, step in enumerate(steps):
                execution.current_step = i + 1
                self.db.commit()

                # Execute step
                step_result = await self._execute_step(step, input_data, results)
                results[step.get("id", f"step_{i}")] = step_result

                # Check conditions
                if not self._check_conditions(step, step_result):
                    raise ValueError(f"Step {step.get('name', i)} conditions failed")

            execution.status = "completed"
            execution.results = results
            execution.completed_at = datetime.utcnow()

        except Exception as e:
            execution.status = "failed"
            execution.error_message = str(e)
            execution.results = results

        finally:
            execution.duration_ms = int((datetime.utcnow() - execution.started_at).total_seconds() * 1000) if execution.started_at else None
            self.db.commit()
            self._executions.pop(execution_id, None)

    async def _execute_step(self, step: Dict, input_data: Dict, previous_results: Dict) -> Dict:
        """Execute a single workflow step."""
        step_type = step.get("step_type", "default")
        action = step.get("action", "")
        parameters = step.get("parameters", {})

        # Merge input data with parameters
        context = {**input_data, **previous_results, **parameters}

        # Execute based on step type
        if step_type == "builder_api":
            builder_id = step.get("builder_id")
            if builder_id:
                # Call builder API
                return {"status": "success", "builder_id": builder_id, "action": action}

        elif step_type == "deployment":
            return {"status": "success", "action": "deployment", "parameters": context}

        elif step_type == "notification":
            return {"status": "success", "action": "notification", "message": action}

        elif step_type == "condition":
            return {"status": "success", "action": "condition", "result": True}

        return {"status": "success", "step_type": step_type, "action": action}

    def _check_conditions(self, step: Dict, result: Dict) -> bool:
        """Check step conditions."""
        conditions = step.get("conditions", {})
        if not conditions:
            return True

        # Simple condition checking
        expected_status = conditions.get("status", "success")
        return result.get("status") == expected_status

    def get_execution(self, execution_id: str) -> Optional[WorkflowExecutionResponse]:
        """Get workflow execution."""
        execution = self.db.query(WorkflowExecutionModel).filter(
            WorkflowExecutionModel.id == execution_id
        ).first()
        if not execution:
            return None
        return self._to_execution_response(execution)

    def _to_response(self, workflow: WorkflowModel) -> WorkflowResponse:
        """Convert DB model to response."""
        return WorkflowResponse(
            workflow_id=workflow.id,
            name=workflow.name,
            description=workflow.description,
            workflow_type=workflow.workflow_type,
            steps=[WorkflowStep(**step) for step in (workflow.steps or [])],
            triggers=[WorkflowTrigger(**trigger) for trigger in (workflow.triggers or [])],
            conditions=workflow.conditions,
            status=workflow.status,
            is_template=workflow.is_template,
            metadata=workflow.metadata,
            tags=workflow.tags,
            created_at=workflow.created_at,
            updated_at=workflow.updated_at,
            created_by=workflow.created_by,
        )

    def _to_execution_response(self, execution: WorkflowExecutionModel) -> WorkflowExecutionResponse:
        """Convert execution DB model to response."""
        return WorkflowExecutionResponse(
            execution_id=execution.id,
            workflow_id=execution.workflow_id,
            project_id=execution.project_id,
            status=execution.status,
            current_step=execution.current_step,
            total_steps=execution.total_steps,
            results=execution.results,
            error_message=execution.error_message,
            duration_ms=execution.duration_ms,
            started_at=execution.started_at,
            completed_at=execution.completed_at,
            created_at=execution.created_at,
            created_by=execution.created_by,
        )
