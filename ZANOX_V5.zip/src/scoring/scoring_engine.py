"""Builder Performance Scoring for Nexus Core V5.

Scores and ranks builders based on performance metrics.
"""
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
from sqlalchemy.orm import Session
from sqlalchemy import func

from ..schemas.builder import BuilderRanking, BuilderResponse, BuilderStatus
from database.models import BuilderRankingHistory, BuilderModel


class BuilderScoringEngine:
    """Scores and ranks builders."""

    def __init__(self, db_session: Session):
        self.db = db_session
        self.weights = {
            "latency_p50": 0.15,
            "latency_p95": 0.20,
            "latency_p99": 0.15,
            "success_rate": 0.30,
            "cost_per_request": 0.20,
        }

    def calculate_rankings(self) -> List[BuilderRanking]:
        """Calculate builder rankings."""
        builders = self.db.query(BuilderModel).filter(
            BuilderModel.status == BuilderStatus.ACTIVE.value
        ).all()

        scored_builders = []
        for builder in builders:
            scores = self._calculate_scores(builder)
            overall_score = self._calculate_overall_score(scores)

            scored_builders.append({
                "builder": builder,
                "scores": scores,
                "overall_score": overall_score,
            })

        # Sort by overall score descending
        scored_builders.sort(key=lambda x: x["overall_score"], reverse=True)

        rankings = []
        for rank, entry in enumerate(scored_builders, 1):
            builder = entry["builder"]
            scores = entry["scores"]

            # Get previous ranking
            prev_rank = self._get_previous_rank(builder.id)
            change = prev_rank - rank if prev_rank else 0
            trend = "up" if change > 0 else "down" if change < 0 else "stable"

            ranking = BuilderRanking(
                builder_id=builder.id,
                builder_name=builder.name,
                rank=rank,
                overall_score=round(entry["overall_score"], 4),
                performance_score=round(scores["performance"], 4),
                reliability_score=round(scores["reliability"], 4),
                cost_efficiency_score=round(scores["cost_efficiency"], 4),
                user_feedback_score=round(scores["user_feedback"], 4),
                capability_match_score=round(scores["capability_match"], 4),
                trend=trend,
                change_from_last=change,
            )
            rankings.append(ranking)

            # Save ranking history
            self._save_ranking_history(builder.id, ranking)

        return rankings

    def _calculate_scores(self, builder: BuilderModel) -> Dict[str, float]:
        """Calculate individual scores for a builder."""
        # Performance score based on latency
        latency_score = self._calculate_latency_score(builder.avg_latency_ms)

        # Reliability score
        reliability_score = builder.success_rate * builder.health_score

        # Cost efficiency score
        cost_score = self._calculate_cost_score(
            builder.cost_per_request,
            builder.cost_per_deployment,
        )

        # User feedback score (placeholder for actual feedback system)
        user_feedback_score = 0.85

        # Capability match score
        capability_score = self._calculate_capability_score(builder)

        return {
            "performance": latency_score,
            "reliability": reliability_score,
            "cost_efficiency": cost_score,
            "user_feedback": user_feedback_score,
            "capability_match": capability_score,
        }

    def _calculate_overall_score(self, scores: Dict[str, float]) -> float:
        """Calculate weighted overall score."""
        weights = {
            "performance": 0.35,
            "reliability": 0.25,
            "cost_efficiency": 0.20,
            "user_feedback": 0.10,
            "capability_match": 0.10,
        }

        overall = sum(
            scores[key] * weight for key, weight in weights.items()
        )
        return overall

    def _calculate_latency_score(self, avg_latency_ms: float) -> float:
        """Calculate latency score (lower is better)."""
        if avg_latency_ms <= 0:
            return 1.0

        # Score decreases as latency increases
        if avg_latency_ms < 1000:
            return 1.0
        elif avg_latency_ms < 3000:
            return 0.9
        elif avg_latency_ms < 5000:
            return 0.7
        elif avg_latency_ms < 10000:
            return 0.5
        elif avg_latency_ms < 30000:
            return 0.3
        else:
            return 0.1

    def _calculate_cost_score(self, cost_per_request: float, cost_per_deployment: float) -> float:
        """Calculate cost efficiency score."""
        total_cost = cost_per_request + cost_per_deployment

        if total_cost <= 0:
            return 1.0

        # Lower cost is better
        if total_cost < 0.01:
            return 1.0
        elif total_cost < 0.05:
            return 0.9
        elif total_cost < 0.1:
            return 0.7
        elif total_cost < 0.5:
            return 0.5
        else:
            return 0.3

    def _calculate_capability_score(self, builder: BuilderModel) -> float:
        """Calculate capability score."""
        capabilities = builder.capabilities or []
        if not capabilities:
            return 0.5

        avg_confidence = sum(
            cap.get("confidence_score", 0.5) for cap in capabilities
        ) / len(capabilities)

        return avg_confidence

    def _get_previous_rank(self, builder_id: str) -> Optional[int]:
        """Get previous ranking for a builder."""
        prev = self.db.query(BuilderRankingHistory).filter(
            BuilderRankingHistory.builder_id == builder_id
        ).order_by(BuilderRankingHistory.calculated_at.desc()).first()

        return prev.rank if prev else None

    def _save_ranking_history(self, builder_id: str, ranking: BuilderRanking):
        """Save ranking to history."""
        history = BuilderRankingHistory(
            id=str(datetime.utcnow().timestamp()),
            builder_id=builder_id,
            rank=ranking.rank,
            overall_score=ranking.overall_score,
            performance_score=ranking.performance_score,
            reliability_score=ranking.reliability_score,
            cost_efficiency_score=ranking.cost_efficiency_score,
            user_feedback_score=ranking.user_feedback_score,
            capability_match_score=ranking.capability_match_score,
            trend=ranking.trend,
            change_from_last=ranking.change_from_last,
        )
        self.db.add(history)
        self.db.commit()

        # Update builder rank score
        builder = self.db.query(BuilderModel).filter(BuilderModel.id == builder_id).first()
        if builder:
            builder.rank_score = ranking.overall_score
            self.db.commit()
