"""Builder Cost Tracking for Nexus Core V5.

Tracks and manages costs for all builder usage.
"""
import uuid
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session
from sqlalchemy import func

from database.models import BuilderCostHistory, BuilderModel


class CostTracker:
    """Tracks costs for builder usage."""

    def __init__(self, db_session: Session):
        self.db = db_session

    def record_cost(
        self,
        builder_id: str,
        project_id: Optional[str],
        deployment_id: Optional[str],
        compute_cost: float = 0.0,
        storage_cost: float = 0.0,
        network_cost: float = 0.0,
        request_cost: float = 0.0,
        requests_count: int = 0,
        duration_seconds: float = 0.0,
        storage_bytes: int = 0,
        metadata: Optional[Dict] = None,
    ) -> str:
        """Record cost for a builder operation."""
        cost_id = str(uuid.uuid4())
        total_cost = compute_cost + storage_cost + network_cost + request_cost

        cost_entry = BuilderCostHistory(
            id=cost_id,
            builder_id=builder_id,
            project_id=project_id,
            deployment_id=deployment_id,
            compute_cost=compute_cost,
            storage_cost=storage_cost,
            network_cost=network_cost,
            request_cost=request_cost,
            total_cost=total_cost,
            requests_count=requests_count,
            duration_seconds=duration_seconds,
            storage_bytes=storage_bytes,
            metadata=metadata or {},
        )

        self.db.add(cost_entry)

        # Update builder total cost
        builder = self.db.query(BuilderModel).filter(BuilderModel.id == builder_id).first()
        if builder:
            builder.total_cost += total_cost

        self.db.commit()
        return cost_id

    def get_cost_summary(
        self,
        builder_id: Optional[str] = None,
        project_id: Optional[str] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
    ) -> Dict[str, Any]:
        """Get cost summary."""
        query = self.db.query(BuilderCostHistory)

        if builder_id:
            query = query.filter(BuilderCostHistory.builder_id == builder_id)
        if project_id:
            query = query.filter(BuilderCostHistory.project_id == project_id)
        if start_date:
            query = query.filter(BuilderCostHistory.timestamp >= start_date)
        if end_date:
            query = query.filter(BuilderCostHistory.timestamp <= end_date)

        results = query.all()

        if not results:
            return {
                "total_cost": 0.0,
                "compute_cost": 0.0,
                "storage_cost": 0.0,
                "network_cost": 0.0,
                "request_cost": 0.0,
                "total_requests": 0,
                "total_duration_seconds": 0.0,
                "total_storage_bytes": 0,
                "record_count": 0,
            }

        return {
            "total_cost": sum(r.total_cost for r in results),
            "compute_cost": sum(r.compute_cost for r in results),
            "storage_cost": sum(r.storage_cost for r in results),
            "network_cost": sum(r.network_cost for r in results),
            "request_cost": sum(r.request_cost for r in results),
            "total_requests": sum(r.requests_count for r in results),
            "total_duration_seconds": sum(r.duration_seconds for r in results),
            "total_storage_bytes": sum(r.storage_bytes for r in results),
            "record_count": len(results),
        }

    def get_cost_by_builder(self, days: int = 30) -> List[Dict[str, Any]]:
        """Get cost breakdown by builder."""
        cutoff = datetime.utcnow() - timedelta(days=days)

        results = self.db.query(
            BuilderCostHistory.builder_id,
            func.sum(BuilderCostHistory.total_cost).label("total_cost"),
            func.sum(BuilderCostHistory.requests_count).label("total_requests"),
            func.count(BuilderCostHistory.id).label("record_count"),
        ).filter(
            BuilderCostHistory.timestamp >= cutoff
        ).group_by(
            BuilderCostHistory.builder_id
        ).all()

        return [
            {
                "builder_id": r.builder_id,
                "total_cost": float(r.total_cost),
                "total_requests": r.total_requests,
                "record_count": r.record_count,
            }
            for r in results
        ]

    def get_cost_trend(self, builder_id: str, days: int = 30) -> List[Dict[str, Any]]:
        """Get daily cost trend."""
        cutoff = datetime.utcnow() - timedelta(days=days)

        results = self.db.query(
            func.date(BuilderCostHistory.timestamp).label("date"),
            func.sum(BuilderCostHistory.total_cost).label("daily_cost"),
            func.sum(BuilderCostHistory.requests_count).label("daily_requests"),
        ).filter(
            BuilderCostHistory.builder_id == builder_id,
            BuilderCostHistory.timestamp >= cutoff,
        ).group_by(
            func.date(BuilderCostHistory.timestamp)
        ).order_by(
            func.date(BuilderCostHistory.timestamp)
        ).all()

        return [
            {
                "date": r.date.isoformat(),
                "daily_cost": float(r.daily_cost),
                "daily_requests": r.daily_requests,
            }
            for r in results
        ]

    def check_budget_alert(self, builder_id: str, budget: float) -> bool:
        """Check if builder is approaching budget limit."""
        monthly_cost = self.get_monthly_cost(builder_id)
        return monthly_cost >= budget * 0.8

    def get_monthly_cost(self, builder_id: str) -> float:
        """Get current month cost for a builder."""
        now = datetime.utcnow()
        start_of_month = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)

        result = self.db.query(
            func.sum(BuilderCostHistory.total_cost)
        ).filter(
            BuilderCostHistory.builder_id == builder_id,
            BuilderCostHistory.timestamp >= start_of_month,
        ).scalar()

        return float(result) if result else 0.0
