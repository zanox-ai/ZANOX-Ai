"""Builder Security Layer for Nexus Core V5.

Handles authentication, authorization, and encryption.
"""
import hashlib
import hmac
import secrets
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
import jwt
from passlib.context import CryptContext


class SecurityManager:
    """Manages security for the builder platform."""

    def __init__(self, jwt_secret: str, encryption_key: str):
        self.jwt_secret = jwt_secret
        self.encryption_key = encryption_key
        self.pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
        self.algorithm = "HS256"

    def create_access_token(
        self,
        user_id: str,
        roles: List[str],
        expires_delta: Optional[timedelta] = None,
    ) -> str:
        """Create JWT access token."""
        if expires_delta is None:
            expires_delta = timedelta(hours=1)

        expire = datetime.utcnow() + expires_delta

        payload = {
            "sub": user_id,
            "roles": roles,
            "exp": expire,
            "iat": datetime.utcnow(),
            "type": "access",
        }

        token = jwt.encode(payload, self.jwt_secret, algorithm=self.algorithm)
        return token

    def verify_token(self, token: str) -> Optional[Dict[str, Any]]:
        """Verify JWT token."""
        try:
            payload = jwt.decode(token, self.jwt_secret, algorithms=[self.algorithm])
            return payload
        except jwt.ExpiredSignatureError:
            return None
        except jwt.InvalidTokenError:
            return None

    def check_permission(self, user_roles: List[str], required_role: str) -> bool:
        """Check if user has required permission."""
        role_hierarchy = {
            "admin": ["admin", "builder_manager", "project_manager", "developer", "viewer"],
            "builder_manager": ["builder_manager", "project_manager", "developer", "viewer"],
            "project_manager": ["project_manager", "developer", "viewer"],
            "developer": ["developer", "viewer"],
            "viewer": ["viewer"],
        }

        for role in user_roles:
            if role in role_hierarchy:
                if required_role in role_hierarchy[role]:
                    return True

        return False

    def hash_password(self, password: str) -> str:
        """Hash password."""
        return self.pwd_context.hash(password)

    def verify_password(self, password: str, hashed: str) -> bool:
        """Verify password."""
        return self.pwd_context.verify(password, hashed)

    def generate_api_key(self) -> str:
        """Generate API key."""
        return f"nexus_{secrets.token_urlsafe(32)}"

    def hash_api_key(self, api_key: str) -> str:
        """Hash API key for storage."""
        return hashlib.sha256(api_key.encode()).hexdigest()

    def verify_api_key(self, api_key: str, hashed_key: str) -> bool:
        """Verify API key."""
        return hmac.compare_digest(self.hash_api_key(api_key), hashed_key)

    def encrypt_data(self, data: str) -> str:
        """Encrypt data."""
        from cryptography.fernet import Fernet
        f = Fernet(self.encryption_key.encode())
        return f.encrypt(data.encode()).decode()

    def decrypt_data(self, encrypted: str) -> str:
        """Decrypt data."""
        from cryptography.fernet import Fernet
        f = Fernet(self.encryption_key.encode())
        return f.decrypt(encrypted.encode()).decode()

    def generate_request_signature(
        self,
        method: str,
        path: str,
        body: str,
        timestamp: str,
        secret: str,
    ) -> str:
        """Generate HMAC signature."""
        message = f"{method}:{path}:{body}:{timestamp}"
        signature = hmac.new(
            secret.encode(),
            message.encode(),
            hashlib.sha256,
        ).hexdigest()
        return signature

    def rate_limit_check(self, key: str, max_requests: int, window_seconds: int, redis_client) -> bool:
        """Check rate limit."""
        if not redis_client:
            return True

        current = redis_client.get(f"rate_limit:{key}")
        if current is None:
            redis_client.setex(f"rate_limit:{key}", window_seconds, 1)
            return True

        count = int(current)
        if count >= max_requests:
            return False

        redis_client.incr(f"rate_limit:{key}")
        return True
