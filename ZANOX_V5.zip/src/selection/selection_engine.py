"""Builder Selection Engine for Nexus Core V5.

Intelligently selects the best builder for a given project.
"""
from typing import List, Optional, Dict, Any
from datetime import datetime

from ..schemas.builder import (
    BuilderResponse, BuilderSelectionCriteria, BuilderSelectionResult,
    BuilderCapability, ProjectType, BuilderStatus
)
from ..registry.builder_registry import BuilderRegistry


class BuilderSelectionEngine:
    """Selects optimal builder based on project requirements."""

    def __init__(self, registry: BuilderRegistry):
        self.registry = registry

    def select_builder(
        self,
        criteria: BuilderSelectionCriteria,
    ) -> BuilderSelectionResult:
        """Select best builder for project."""
        # Get candidates
        candidates = self._get_candidates(criteria)
        if not candidates:
            raise ValueError("No builders available for the given criteria")

        # Score candidates
        scored = self._score_candidates(candidates, criteria)

        # Sort by score
        scored.sort(key=lambda x: x["score"], reverse=True)

        # Select top builder
        selected = scored[0]
        builder = selected["builder"]

        # Build fallback chain
        fallback_chain = [
            s["builder"].id for s in scored[1:4]
        ] if criteria.fallback_enabled else []

        return BuilderSelectionResult(
            selected_builder_id=builder.id,
            selected_builder_name=builder.name,
            confidence_score=selected["score"],
            estimated_cost=selected["estimated_cost"],
            estimated_latency_ms=selected["estimated_latency"],
            estimated_duration_minutes=selected["estimated_duration"],
            fallback_chain=fallback_chain,
            selection_reason=selected["reason"],
            capability_match_score=selected["capability_score"],
        )

    def _get_candidates(self, criteria: BuilderSelectionCriteria) -> List[BuilderResponse]:
        """Get candidate builders matching criteria."""
        builders = self.registry.list_builders(
            status=BuilderStatus.ACTIVE,
            project_type=criteria.project_type,
        )

        candidates = []
        for builder in builders:
            # Check if builder supports project type
            if criteria.project_type not in builder.supported_project_types:
                continue

            # Check excluded builders
            if criteria.excluded_builders and builder.id in criteria.excluded_builders:
                continue

            # Check preferred providers
            if criteria.preferred_providers and builder.provider not in criteria.preferred_providers:
                continue

            # Check health score
            if builder.health_score < 0.5:
                continue

            # Check success rate
            if criteria.min_success_rate and builder.success_rate < criteria.min_success_rate:
                continue

            # Check max latency
            if criteria.max_latency_ms and builder.avg_latency_ms > criteria.max_latency_ms:
                continue

            # Check cost
            if criteria.max_cost_per_project:
                estimated_cost = self._estimate_cost(builder, criteria.project_type)
                if estimated_cost > criteria.max_cost_per_project:
                    continue

            # Check required capabilities
            if criteria.required_capabilities:
                builder_caps = [cap.name for cap in builder.capabilities]
                if not all(cap in builder_caps for cap in criteria.required_capabilities):
                    continue

            # Check regions
            if criteria.required_regions:
                if not any(r in builder.deployment_regions for r in criteria.required_regions):
                    continue

            candidates.append(builder)

        return candidates

    def _score_candidates(
        self,
        candidates: List[BuilderResponse],
        criteria: BuilderSelectionCriteria,
    ) -> List[Dict[str, Any]]:
        """Score candidate builders."""
        scored = []

        for builder in candidates:
            # Capability match score (0-1)
            capability_score = self._calculate_capability_score(builder, criteria)

            # Performance score (0-1)
            performance_score = self._calculate_performance_score(builder)

            # Reliability score (0-1)
            reliability_score = builder.success_rate * builder.health_score

            # Cost efficiency score (0-1)
            cost_score = self._calculate_cost_score(builder, criteria)

            # Overall score
            weights = {
                "capability": 0.30,
                "performance": 0.25,
                "reliability": 0.25,
                "cost": 0.20,
            }

            overall_score = (
                weights["capability"] * capability_score +
                weights["performance"] * performance_score +
                weights["reliability"] * reliability_score +
                weights["cost"] * cost_score
            )

            estimated_cost = self._estimate_cost(builder, criteria.project_type)
            estimated_latency = builder.avg_latency_ms if builder.avg_latency_ms > 0 else 5000
            estimated_duration = self._estimate_duration(builder, criteria.project_type)

            scored.append({
                "builder": builder,
                "score": round(overall_score, 4),
                "capability_score": round(capability_score, 4),
                "performance_score": round(performance_score, 4),
                "reliability_score": round(reliability_score, 4),
                "cost_score": round(cost_score, 4),
                "estimated_cost": estimated_cost,
                "estimated_latency": estimated_latency,
                "estimated_duration": estimated_duration,
                "reason": f"Best match: capability={capability_score:.2f}, performance={performance_score:.2f}, reliability={reliability_score:.2f}, cost={cost_score:.2f}",
            })

        return scored

    def _calculate_capability_score(
        self,
        builder: BuilderResponse,
        criteria: BuilderSelectionCriteria,
    ) -> float:
        """Calculate capability match score."""
        if not criteria.required_capabilities:
            return 1.0

        builder_caps = {cap.name: cap.confidence_score for cap in builder.capabilities}

        scores = []
        for req_cap in criteria.required_capabilities:
            if req_cap in builder_caps:
                scores.append(builder_caps[req_cap])
            else:
                scores.append(0.0)

        return sum(scores) / len(scores) if scores else 0.0

    def _calculate_performance_score(self, builder: BuilderResponse) -> float:
        """Calculate performance score."""
        # Lower latency is better
        latency_score = max(0, 1 - (builder.avg_latency_ms / 10000))

        # Higher success rate is better
        success_score = builder.success_rate

        return (latency_score + success_score) / 2

    def _calculate_cost_score(
        self,
        builder: BuilderResponse,
        criteria: BuilderSelectionCriteria,
    ) -> float:
        """Calculate cost efficiency score."""
        if criteria.max_cost_per_project:
            estimated = self._estimate_cost(builder, criteria.project_type)
            if estimated <= 0:
                return 1.0
            return max(0, 1 - (estimated / criteria.max_cost_per_project))
        return 1.0

    def _estimate_cost(self, builder: BuilderResponse, project_type: ProjectType) -> float:
        """Estimate cost for a project type."""
        base_cost = builder.cost_per_deployment

        # Project type multipliers
        multipliers = {
            ProjectType.WEB_APPLICATION: 1.0,
            ProjectType.MOBILE_APPLICATION: 1.5,
            ProjectType.MARKETPLACE_SYSTEM: 2.0,
            ProjectType.TELEGRAM_SYSTEM: 1.2,
            ProjectType.SAAS_PLATFORM: 1.8,
            ProjectType.CRM_SYSTEM: 1.5,
            ProjectType.ERP_SYSTEM: 2.5,
            ProjectType.AI_APPLICATION: 2.0,
            ProjectType.INTERNAL_TOOLS: 0.8,
            ProjectType.AUTOMATION_PLATFORM: 1.2,
            ProjectType.DASHBOARDS: 0.8,
            ProjectType.LANDING_PAGES: 0.5,
            ProjectType.ADMIN_PANELS: 0.8,
        }

        return base_cost * multipliers.get(project_type, 1.0)

    def _estimate_duration(self, builder: BuilderResponse, project_type: ProjectType) -> float:
        """Estimate build duration in minutes."""
        base_duration = 10  # Base 10 minutes

        multipliers = {
            ProjectType.WEB_APPLICATION: 1.0,
            ProjectType.MOBILE_APPLICATION: 1.5,
            ProjectType.MARKETPLACE_SYSTEM: 2.0,
            ProjectType.TELEGRAM_SYSTEM: 1.0,
            ProjectType.SAAS_PLATFORM: 1.8,
            ProjectType.CRM_SYSTEM: 1.5,
            ProjectType.ERP_SYSTEM: 2.5,
            ProjectType.AI_APPLICATION: 1.5,
            ProjectType.INTERNAL_TOOLS: 0.8,
            ProjectType.AUTOMATION_PLATFORM: 1.0,
            ProjectType.DASHBOARDS: 0.6,
            ProjectType.LANDING_PAGES: 0.3,
            ProjectType.ADMIN_PANELS: 0.6,
        }

        return base_duration * multipliers.get(project_type, 1.0)
