"""Builder State Management for Nexus Core V5.

Manages state for builder operations.
"""
import json
from typing import Dict, Any, Optional
from datetime import datetime, timedelta


class StateManager:
    """Manages state for builder operations."""

    def __init__(self, redis_client):
        self.redis = redis_client
        self.default_ttl = 3600  # 1 hour

    async def set_state(self, key: str, value: Any, ttl: Optional[int] = None) -> bool:
        """Set state value."""
        if not self.redis:
            return False

        serialized = json.dumps(value, default=str)
        expiry = ttl or self.default_ttl

        await self.redis.setex(f"state:{key}", expiry, serialized)
        return True

    async def get_state(self, key: str) -> Optional[Any]:
        """Get state value."""
        if not self.redis:
            return None

        value = await self.redis.get(f"state:{key}")
        if value:
            return json.loads(value)
        return None

    async def delete_state(self, key: str) -> bool:
        """Delete state value."""
        if not self.redis:
            return False

        await self.redis.delete(f"state:{key}")
        return True

    async def set_project_state(self, project_id: str, state: Dict[str, Any]) -> bool:
        """Set project state."""
        return await self.set_state(f"project:{project_id}", state, ttl=86400)

    async def get_project_state(self, project_id: str) -> Optional[Dict[str, Any]]:
        """Get project state."""
        return await self.get_state(f"project:{project_id}")

    async def set_builder_state(self, builder_id: str, state: Dict[str, Any]) -> bool:
        """Set builder state."""
        return await self.set_state(f"builder:{builder_id}", state, ttl=300)

    async def get_builder_state(self, builder_id: str) -> Optional[Dict[str, Any]]:
        """Get builder state."""
        return await self.get_state(f"builder:{builder_id}")

    async def set_deployment_state(self, deployment_id: str, state: Dict[str, Any]) -> bool:
        """Set deployment state."""
        return await self.set_state(f"deployment:{deployment_id}", state, ttl=86400)

    async def get_deployment_state(self, deployment_id: str) -> Optional[Dict[str, Any]]:
        """Get deployment state."""
        return await self.get_state(f"deployment:{deployment_id}")

    async def acquire_lock(self, lock_key: str, ttl: int = 30) -> bool:
        """Acquire distributed lock."""
        if not self.redis:
            return False

        acquired = await self.redis.set(f"lock:{lock_key}", "1", nx=True, ex=ttl)
        return bool(acquired)

    async def release_lock(self, lock_key: str) -> bool:
        """Release distributed lock."""
        if not self.redis:
            return False

        await self.redis.delete(f"lock:{lock_key}")
        return True
