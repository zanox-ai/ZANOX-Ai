"""Builder Execution Queue for Nexus Core V5.

Manages execution queue for builder operations.
"""
import uuid
import asyncio
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
from collections import deque

from ..schemas.queue import QueueItemCreate, QueueItemResponse, QueueStats, Priority


class ExecutionQueue:
    """Priority queue for builder execution."""

    def __init__(self, redis_client, max_size: int = 10000):
        self.redis = redis_client
        self.max_size = max_size
        self.priority_weights = {
            Priority.CRITICAL: 10,
            Priority.HIGH: 5,
            Priority.NORMAL: 1,
            Priority.LOW: 0.5,
        }
        self._local_queues: Dict[str, deque] = {}
        self._processing: Dict[str, Dict] = {}
        self._lock = asyncio.Lock()

    async def enqueue(self, item_data: QueueItemCreate) -> QueueItemResponse:
        """Add item to queue."""
        item_id = str(uuid.uuid4())

        item = QueueItemResponse(
            item_id=item_id,
            queue_name=item_data.queue_name,
            item_type=item_data.item_type,
            payload=item_data.payload,
            priority=item_data.priority,
            status="pending",
            attempts=0,
            max_attempts=item_data.max_attempts,
            created_at=datetime.utcnow(),
            scheduled_at=item_data.scheduled_at,
            expires_at=item_data.expires_at,
        )

        async with self._lock:
            queue = self._local_queues.setdefault(item_data.queue_name, deque(maxlen=self.max_size))
            queue.append(item)

        # Also store in Redis for persistence
        if self.redis:
            await self.redis.hset(
                f"queue:{item_data.queue_name}",
                item_id,
                item.model_dump_json()
            )

        return item

    async def dequeue(self, queue_name: str, worker_id: str) -> Optional[QueueItemResponse]:
        """Get next item from queue."""
        async with self._lock:
            queue = self._local_queues.get(queue_name)
            if not queue:
                return None

            # Sort by priority
            sorted_items = sorted(queue, key=lambda x: self.priority_weights.get(x.priority, 1), reverse=True)

            for item in sorted_items:
                if item.status == "pending":
                    # Check expiration
                    if item.expires_at and item.expires_at < datetime.utcnow():
                        item.status = "expired"
                        continue

                    # Check scheduled time
                    if item.scheduled_at and item.scheduled_at > datetime.utcnow():
                        continue

                    item.status = "processing"
                    item.worker_id = worker_id
                    item.started_at = datetime.utcnow()
                    item.attempts += 1

                    self._processing[item.item_id] = {
                        "worker_id": worker_id,
                        "started_at": datetime.utcnow(),
                    }

                    queue.remove(item)
                    return item

            return None

    async def complete(self, item_id: str, queue_name: str, result: Optional[Dict] = None):
        """Mark item as completed."""
        async with self._lock:
            if item_id in self._processing:
                del self._processing[item_id]

        if self.redis:
            await self.redis.hdel(f"queue:{queue_name}", item_id)

    async def fail(self, item_id: str, queue_name: str, error_message: str):
        """Mark item as failed."""
        async with self._lock:
            if item_id in self._processing:
                del self._processing[item_id]

        if self.redis:
            await self.redis.hdel(f"queue:{queue_name}", item_id)

    async def get_stats(self, queue_name: str) -> QueueStats:
        """Get queue statistics."""
        async with self._lock:
            queue = self._local_queues.get(queue_name, deque())

            pending = sum(1 for item in queue if item.status == "pending")
            processing = len(self._processing)

            # Calculate average wait time
            wait_times = []
            for item in queue:
                if item.status == "pending" and item.created_at:
                    wait_times.append((datetime.utcnow() - item.created_at).total_seconds() * 1000)

            avg_wait = sum(wait_times) / len(wait_times) if wait_times else 0.0

            return QueueStats(
                queue_name=queue_name,
                pending=pending,
                processing=processing,
                completed=0,
                failed=0,
                dead_letter=0,
                avg_wait_time_ms=avg_wait,
                avg_processing_time_ms=0.0,
                throughput_per_minute=0.0,
            )

    async def get_all_stats(self) -> List[QueueStats]:
        """Get stats for all queues."""
        async with self._lock:
            queue_names = list(self._local_queues.keys())

        stats = []
        for name in queue_names:
            stat = await self.get_stats(name)
            stats.append(stat)

        return stats
