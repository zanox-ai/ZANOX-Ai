"""Builder Registry System for Nexus Core V5.

Manages builder registration, lifecycle, and metadata.
"""
import uuid
from datetime import datetime
from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, func

from ..schemas.builder import (
    BuilderCreate, BuilderUpdate, BuilderResponse, BuilderProvider,
    BuilderCapability, BuilderCost, BuilderConfig, BuilderAuth,
    BuilderStatus, ProjectType
)
from database.models import BuilderModel as BuilderDB


class BuilderRegistry:
    """Central registry for all external builders."""

    def __init__(self, db_session: Session):
        self.db = db_session

    def register_builder(self, builder_data: BuilderCreate) -> BuilderResponse:
        """Register a new builder in the marketplace."""
        builder_id = str(uuid.uuid4())

        builder = BuilderDB(
            id=builder_id,
            name=builder_data.name,
            provider=builder_data.provider,
            slug=builder_data.slug,
            description=builder_data.description,
            api_base_url=builder_data.api_base_url,
            auth_type=builder_data.auth_type.value,
            auth_config={
                "auth_type": builder_data.auth_config.auth_type.value,
                "scopes": builder_data.auth_config.scopes,
            },
            supported_project_types=[pt.value for pt in builder_data.supported_project_types],
            capabilities=[
                {
                    "name": cap.name,
                    "description": cap.description,
                    "category": cap.category,
                    "confidence_score": cap.confidence_score,
                    "parameters": cap.parameters,
                    "supported_project_types": [pt.value for pt in cap.supported_project_types],
                }
                for cap in builder_data.capabilities
            ],
            deployment_regions=builder_data.deployment_regions,
            cost_per_hour=builder_data.cost.per_hour,
            cost_per_deployment=builder_data.cost.per_deployment,
            cost_per_request=builder_data.cost.per_request,
            max_projects=builder_data.max_projects,
            max_team_size=builder_data.max_team_size,
            timeout=builder_data.config.timeout,
            retry_attempts=builder_data.config.retry_attempts,
            rate_limit_per_minute=builder_data.config.rate_limit_per_minute,
            health_check_endpoint=builder_data.config.health_check_endpoint,
            status=BuilderStatus.ACTIVE.value,
            tags=builder_data.tags,
            metadata=builder_data.metadata,
        )

        self.db.add(builder)
        self.db.commit()
        self.db.refresh(builder)

        return self._to_response(builder)

    def update_builder(self, builder_id: str, builder_data: BuilderUpdate) -> Optional[BuilderResponse]:
        """Update an existing builder."""
        builder = self.db.query(BuilderDB).filter(BuilderDB.id == builder_id).first()
        if not builder:
            return None

        if builder_data.name:
            builder.name = builder_data.name
        if builder_data.description is not None:
            builder.description = builder_data.description
        if builder_data.api_base_url:
            builder.api_base_url = builder_data.api_base_url
        if builder_data.auth_config:
            builder.auth_config["scopes"] = builder_data.auth_config.scopes
        if builder_data.supported_project_types:
            builder.supported_project_types = [pt.value for pt in builder_data.supported_project_types]
        if builder_data.capabilities:
            builder.capabilities = [
                {
                    "name": cap.name,
                    "description": cap.description,
                    "category": cap.category,
                    "confidence_score": cap.confidence_score,
                }
                for cap in builder_data.capabilities
            ]
        if builder_data.deployment_regions:
            builder.deployment_regions = builder_data.deployment_regions
        if builder_data.cost:
            builder.cost_per_hour = builder_data.cost.per_hour
            builder.cost_per_deployment = builder_data.cost.per_deployment
            builder.cost_per_request = builder_data.cost.per_request
        if builder_data.config:
            builder.timeout = builder_data.config.timeout
            builder.retry_attempts = builder_data.config.retry_attempts
            builder.rate_limit_per_minute = builder_data.config.rate_limit_per_minute
        if builder_data.status:
            builder.status = builder_data.status.value
        if builder_data.max_projects:
            builder.max_projects = builder_data.max_projects
        if builder_data.max_team_size:
            builder.max_team_size = builder_data.max_team_size
        if builder_data.tags:
            builder.tags = builder_data.tags
        if builder_data.metadata:
            builder.metadata = builder_data.metadata

        builder.updated_at = datetime.utcnow()
        self.db.commit()
        self.db.refresh(builder)

        return self._to_response(builder)

    def get_builder(self, builder_id: str) -> Optional[BuilderResponse]:
        """Get builder by ID."""
        builder = self.db.query(BuilderDB).filter(BuilderDB.id == builder_id).first()
        if not builder:
            return None
        return self._to_response(builder)

    def get_builder_by_slug(self, slug: str) -> Optional[BuilderResponse]:
        """Get builder by slug."""
        builder = self.db.query(BuilderDB).filter(BuilderDB.slug == slug).first()
        if not builder:
            return None
        return self._to_response(builder)

    def list_builders(
        self,
        status: Optional[BuilderStatus] = None,
        provider: Optional[str] = None,
        project_type: Optional[ProjectType] = None,
        tags: Optional[List[str]] = None,
        search: Optional[str] = None,
        skip: int = 0,
        limit: int = 100,
    ) -> List[BuilderResponse]:
        """List builders with optional filtering."""
        query = self.db.query(BuilderDB)

        if status:
            query = query.filter(BuilderDB.status == status.value)
        if provider:
            query = query.filter(BuilderDB.provider == provider)
        if project_type:
            query = query.filter(BuilderDB.supported_project_types.contains([project_type.value]))
        if tags:
            for tag in tags:
                query = query.filter(BuilderDB.tags.contains([tag]))
        if search:
            query = query.filter(
                or_(
                    BuilderDB.name.ilike(f"%{search}%"),
                    BuilderDB.description.ilike(f"%{search}%"),
                    BuilderDB.slug.ilike(f"%{search}%"),
                )
            )

        builders = query.offset(skip).limit(limit).all()
        return [self._to_response(b) for b in builders]

    def delete_builder(self, builder_id: str) -> bool:
        """Soft delete a builder."""
        builder = self.db.query(BuilderDB).filter(BuilderDB.id == builder_id).first()
        if not builder:
            return False

        builder.status = BuilderStatus.INACTIVE.value
        builder.is_available = False
        builder.updated_at = datetime.utcnow()
        self.db.commit()
        return True

    def update_builder_health_score(self, builder_id: str, health_score: float) -> bool:
        """Update builder health score."""
        builder = self.db.query(BuilderDB).filter(BuilderDB.id == builder_id).first()
        if not builder:
            return False

        builder.health_score = health_score
        builder.last_health_check = datetime.utcnow()
        self.db.commit()
        return True

    def update_builder_metrics(
        self,
        builder_id: str,
        latency_ms: float,
        cost: float,
        error: bool = False,
    ) -> bool:
        """Update builder performance metrics."""
        builder = self.db.query(BuilderDB).filter(BuilderDB.id == builder_id).first()
        if not builder:
            return False

        builder.total_requests += 1
        builder.total_cost += cost

        if builder.total_requests > 1:
            builder.avg_latency_ms = (
                (builder.avg_latency_ms * (builder.total_requests - 1) + latency_ms)
                / builder.total_requests
            )
        else:
            builder.avg_latency_ms = latency_ms

        if error:
            builder.error_rate = (
                (builder.error_rate * (builder.total_requests - 1) + 1)
                / builder.total_requests
            )
        else:
            builder.error_rate = (
                builder.error_rate * (builder.total_requests - 1)
                / builder.total_requests
            )

        builder.success_rate = 1 - builder.error_rate
        builder.updated_at = datetime.utcnow()
        self.db.commit()
        return True

    def _to_response(self, builder: BuilderDB) -> BuilderResponse:
        """Convert DB model to response schema."""
        capabilities = [
            BuilderCapability(
                name=cap["name"],
                description=cap.get("description", ""),
                category=cap.get("category", ""),
                confidence_score=cap.get("confidence_score", 0.0),
                parameters=cap.get("parameters", {}),
                supported_project_types=[
                    ProjectType(pt) for pt in cap.get("supported_project_types", [])
                ],
            )
            for cap in builder.capabilities
        ]

        return BuilderResponse(
            builder_id=builder.id,
            name=builder.name,
            provider=builder.provider,
            slug=builder.slug,
            description=builder.description,
            api_base_url=builder.api_base_url,
            auth_type=AuthType(builder.auth_type),
            supported_project_types=[ProjectType(pt) for pt in builder.supported_project_types],
            capabilities=capabilities,
            deployment_regions=builder.deployment_regions,
            cost=BuilderCost(
                per_hour=builder.cost_per_hour,
                per_deployment=builder.cost_per_deployment,
                per_request=builder.cost_per_request,
            ),
            config=BuilderConfig(
                timeout=builder.timeout,
                retry_attempts=builder.retry_attempts,
                rate_limit_per_minute=builder.rate_limit_per_minute,
                health_check_endpoint=builder.health_check_endpoint,
            ),
            max_projects=builder.max_projects,
            max_team_size=builder.max_team_size,
            status=BuilderStatus(builder.status),
            health_score=builder.health_score,
            rank_score=builder.rank_score,
            is_available=builder.is_available,
            total_projects=builder.total_projects,
            total_deployments=builder.total_deployments,
            total_requests=builder.total_requests,
            total_cost=builder.total_cost,
            avg_latency_ms=builder.avg_latency_ms,
            error_rate=builder.error_rate,
            success_rate=builder.success_rate,
            tags=builder.tags,
            metadata=builder.metadata,
            last_health_check=builder.last_health_check,
            last_deployment=builder.last_deployment,
            created_at=builder.created_at,
            updated_at=builder.updated_at,
        )
