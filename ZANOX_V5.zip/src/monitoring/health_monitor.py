"""Builder Health Monitoring for Nexus Core V5.

Real-time health checks and monitoring for all builders.
"""
import asyncio
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from collections import deque
import aiohttp

from ..schemas.builder import BuilderStatus, BuilderHealth, BuilderResponse
from ..schemas.monitoring import HealthCheckType, HealthCheckResult, AlertSeverity


@dataclass
class HealthMetrics:
    """Health metrics for a builder."""
    builder_id: str
    latency_history: deque = field(default_factory=lambda: deque(maxlen=100))
    error_history: deque = field(default_factory=lambda: deque(maxlen=100))
    check_history: deque = field(default_factory=lambda: deque(maxlen=1000))
    consecutive_failures: int = 0
    last_success: Optional[datetime] = None
    total_checks: int = 0
    failed_checks: int = 0


class BuilderHealthMonitor:
    """Monitors health of all registered builders."""

    def __init__(self, registry, alert_manager=None):
        self.registry = registry
        self.alert_manager = alert_manager
        self.metrics: Dict[str, HealthMetrics] = {}
        self.running = False
        self.check_interval = 30
        self._monitor_task = None

    async def start_monitoring(self):
        """Start the health monitoring loop."""
        self.running = True
        self._monitor_task = asyncio.create_task(self._monitor_loop())

    async def stop_monitoring(self):
        """Stop the health monitoring loop."""
        self.running = False
        if self._monitor_task:
            self._monitor_task.cancel()
            try:
                await self._monitor_task
            except asyncio.CancelledError:
                pass

    async def _monitor_loop(self):
        """Main monitoring loop."""
        while self.running:
            try:
                await self._run_health_checks()
                await asyncio.sleep(self.check_interval)
            except Exception as e:
                print(f"Health monitor error: {e}")
                await asyncio.sleep(5)

    async def _run_health_checks(self):
        """Run health checks for all active builders."""
        builders = self.registry.list_builders(status=BuilderStatus.ACTIVE)

        tasks = []
        for builder in builders:
            tasks.append(self._check_builder_health(builder))

        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

    async def _check_builder_health(self, builder: BuilderResponse):
        """Check health of a single builder."""
        builder_id = builder.id

        if builder_id not in self.metrics:
            self.metrics[builder_id] = HealthMetrics(builder_id=builder_id)

        metrics = self.metrics[builder_id]
        start_time = time.time()

        try:
            health_result = await self._ping_builder(builder)
            latency_ms = (time.time() - start_time) * 1000

            metrics.latency_history.append(latency_ms)
            metrics.total_checks += 1
            metrics.consecutive_failures = 0
            metrics.last_success = datetime.utcnow()

            status = self._determine_status(metrics, latency_ms)
            health_score = self._calculate_health_score(metrics)
            self.registry.update_builder_health_score(builder_id, health_score)

            check_result = HealthCheckResult(
                builder_id=builder_id,
                check_type=HealthCheckType.PING,
                status=status,
                latency_ms=latency_ms,
                details={"health_score": health_score},
            )
            metrics.check_history.append(check_result)

            if status in [BuilderStatus.DEGRADED, BuilderStatus.OFFLINE]:
                await self._handle_degraded_builder(builder, status, latency_ms)

        except Exception as e:
            metrics.error_history.append(str(e))
            metrics.consecutive_failures += 1
            metrics.failed_checks += 1
            metrics.total_checks += 1

            if metrics.consecutive_failures >= 5:
                status = BuilderStatus.OFFLINE
            elif metrics.consecutive_failures >= 3:
                status = BuilderStatus.DEGRADED
            else:
                status = BuilderStatus.ACTIVE

            check_result = HealthCheckResult(
                builder_id=builder_id,
                check_type=HealthCheckType.PING,
                status=status,
                latency_ms=99999,
                error_message=str(e),
            )
            metrics.check_history.append(check_result)

            await self._handle_degraded_builder(builder, status, 99999)

    async def _ping_builder(self, builder: BuilderResponse) -> bool:
        """Ping a builder to check availability."""
        try:
            timeout = aiohttp.ClientTimeout(total=10)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(
                    f"{builder.api_base_url}{builder.config.health_check_endpoint}",
                    headers={"User-Agent": "NexusCoreV5/1.0"},
                ) as response:
                    return response.status < 500
        except Exception:
            return False

    def _determine_status(self, metrics: HealthMetrics, current_latency: float) -> BuilderStatus:
        """Determine builder status based on metrics."""
        if metrics.consecutive_failures >= 5:
            return BuilderStatus.OFFLINE
        elif metrics.consecutive_failures >= 3:
            return BuilderStatus.DEGRADED

        if metrics.latency_history:
            avg_latency = sum(metrics.latency_history) / len(metrics.latency_history)
            if avg_latency > 10000:
                return BuilderStatus.DEGRADED

        if metrics.total_checks > 0:
            error_rate = metrics.failed_checks / metrics.total_checks
            if error_rate > 0.1:
                return BuilderStatus.DEGRADED

        return BuilderStatus.ACTIVE

    def _calculate_health_score(self, metrics: HealthMetrics) -> float:
        """Calculate health score (0-1)."""
        if metrics.total_checks == 0:
            return 1.0

        success_rate = 1 - (metrics.failed_checks / metrics.total_checks)

        latency_penalty = 0.0
        if metrics.latency_history:
            avg_latency = sum(metrics.latency_history) / len(metrics.latency_history)
            if avg_latency > 5000:
                latency_penalty = 0.2
            elif avg_latency > 2000:
                latency_penalty = 0.1

        failure_penalty = min(metrics.consecutive_failures * 0.1, 0.5)

        score = max(0.0, success_rate - latency_penalty - failure_penalty)
        return round(score, 2)

    async def _handle_degraded_builder(self, builder: BuilderResponse, status: BuilderStatus, latency: float):
        """Handle degraded builder."""
        if self.alert_manager:
            severity = AlertSeverity.CRITICAL if status == BuilderStatus.OFFLINE else AlertSeverity.WARNING
            await self.alert_manager.send_alert(
                builder_id=builder.id,
                severity=severity,
                title=f"Builder {builder.name} is {status.value}",
                description=f"Builder health degraded. Latency: {latency:.0f}ms",
                metric_name="builder_status",
                metric_value=0.0 if status == BuilderStatus.OFFLINE else 0.5,
                threshold=0.8,
            )

    def get_health_status(self, builder_id: str) -> Optional[BuilderHealth]:
        """Get current health status for a builder."""
        if builder_id not in self.metrics:
            return None

        metrics = self.metrics[builder_id]

        uptime = 1 - (metrics.failed_checks / metrics.total_checks) if metrics.total_checks > 0 else 1.0
        avg_latency = sum(metrics.latency_history) / len(metrics.latency_history) if metrics.latency_history else 0.0
        latest_status = metrics.check_history[-1].status if metrics.check_history else BuilderStatus.ACTIVE

        return BuilderHealth(
            builder_id=builder_id,
            status=latest_status,
            latency_ms=avg_latency,
            error_rate=metrics.failed_checks / max(metrics.total_checks, 1),
            last_check=datetime.utcnow(),
            uptime_percentage=uptime * 100,
            consecutive_failures=metrics.consecutive_failures,
        )

    def get_all_health_status(self) -> List[BuilderHealth]:
        """Get health status for all builders."""
        return [
            self.get_health_status(builder_id)
            for builder_id in self.metrics.keys()
        ]
