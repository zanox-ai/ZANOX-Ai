"""Builder Failover System for Nexus Core V5.

Automatic failover with circuit breaker pattern.
"""
import asyncio
import time
from typing import Dict, List, Optional, Any, Callable
from enum import Enum
from dataclasses import dataclass, field

from ..schemas.builder import BuilderResponse, BuilderStatus


class CircuitState(Enum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


@dataclass
class CircuitBreaker:
    """Circuit breaker for a builder."""
    builder_id: str
    failure_threshold: int = 5
    recovery_timeout: int = 60
    half_open_max_calls: int = 3
    state: CircuitState = CircuitState.CLOSED
    failures: int = 0
    successes: int = 0
    last_failure_time: float = 0.0
    total_calls: int = 0


class BuilderFailoverSystem:
    """Manages failover between builders."""

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.circuit_breakers: Dict[str, CircuitBreaker] = {}
        self.max_fallback_chain = config.get("max_fallback_chain", 3)
        self.retry_policy = config.get("retry_policy", {})
        self._lock = asyncio.Lock()

    async def execute_with_failover(
        self,
        primary_builder: BuilderResponse,
        fallback_chain: List[str],
        operation: Callable,
        *args,
        **kwargs,
    ) -> Any:
        """Execute operation with failover support."""
        builders_to_try = [primary_builder.id] + fallback_chain[:self.max_fallback_chain]

        last_error = None
        for builder_id in builders_to_try:
            try:
                # Check circuit breaker
                if not await self._can_execute(builder_id):
                    continue

                # Execute with retry
                result = await self._execute_with_retry(builder_id, operation, *args, **kwargs)

                # Record success
                await self._record_success(builder_id)
                return result

            except Exception as e:
                last_error = e
                await self._record_failure(builder_id)

        raise Exception(f"All builders failed. Last error: {last_error}")

    async def _can_execute(self, builder_id: str) -> bool:
        """Check if builder can execute via circuit breaker."""
        async with self._lock:
            cb = self._get_circuit_breaker(builder_id)

            if cb.state == CircuitState.CLOSED:
                return True

            if cb.state == CircuitState.OPEN:
                if time.time() - cb.last_failure_time > cb.recovery_timeout:
                    cb.state = CircuitState.HALF_OPEN
                    cb.successes = 0
                    cb.failures = 0
                    return True
                return False

            if cb.state == CircuitState.HALF_OPEN:
                if cb.total_calls < cb.half_open_max_calls:
                    return True
                return False

            return True

    async def _execute_with_retry(
        self,
        builder_id: str,
        operation: Callable,
        *args,
        **kwargs,
    ) -> Any:
        """Execute operation with retry logic."""
        max_attempts = self.retry_policy.get("max_attempts", 3)
        backoff_multiplier = self.retry_policy.get("backoff_multiplier", 2)
        initial_delay = self.retry_policy.get("initial_delay", 1.0)
        max_delay = self.retry_policy.get("max_delay", 60.0)

        delay = initial_delay
        last_error = None

        for attempt in range(max_attempts):
            try:
                return await operation(*args, **kwargs)
            except Exception as e:
                last_error = e
                if attempt < max_attempts - 1:
                    await asyncio.sleep(min(delay, max_delay))
                    delay *= backoff_multiplier

        raise last_error

    async def _record_success(self, builder_id: str):
        """Record successful execution."""
        async with self._lock:
            cb = self._get_circuit_breaker(builder_id)
            cb.total_calls += 1

            if cb.state == CircuitState.HALF_OPEN:
                cb.successes += 1
                if cb.successes >= cb.half_open_max_calls:
                    cb.state = CircuitState.CLOSED
                    cb.failures = 0
                    cb.successes = 0
            else:
                cb.failures = max(0, cb.failures - 1)

    async def _record_failure(self, builder_id: str):
        """Record failed execution."""
        async with self._lock:
            cb = self._get_circuit_breaker(builder_id)
            cb.total_calls += 1
            cb.failures += 1
            cb.last_failure_time = time.time()

            if cb.state == CircuitState.HALF_OPEN:
                cb.state = CircuitState.OPEN
            elif cb.failures >= cb.failure_threshold:
                cb.state = CircuitState.OPEN

    def _get_circuit_breaker(self, builder_id: str) -> CircuitBreaker:
        """Get or create circuit breaker."""
        if builder_id not in self.circuit_breakers:
            self.circuit_breakers[builder_id] = CircuitBreaker(
                builder_id=builder_id,
                failure_threshold=self.config.get("failure_threshold", 5),
                recovery_timeout=self.config.get("recovery_timeout", 60),
                half_open_max_calls=self.config.get("half_open_max_calls", 3),
            )
        return self.circuit_breakers[builder_id]

    def get_circuit_status(self, builder_id: str) -> Dict[str, Any]:
        """Get circuit breaker status."""
        cb = self.circuit_breakers.get(builder_id)
        if not cb:
            return {"state": "unknown", "builder_id": builder_id}

        return {
            "builder_id": builder_id,
            "state": cb.state.value,
            "failures": cb.failures,
            "successes": cb.successes,
            "total_calls": cb.total_calls,
            "last_failure_time": cb.last_failure_time,
            "failure_threshold": cb.failure_threshold,
            "recovery_timeout": cb.recovery_timeout,
        }

    def get_all_circuit_status(self) -> List[Dict[str, Any]]:
        """Get all circuit breaker statuses."""
        return [self.get_circuit_status(bid) for bid in self.circuit_breakers.keys()]
