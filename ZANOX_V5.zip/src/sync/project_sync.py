"""Builder Project Synchronization Layer for Nexus Core V5.

Synchronizes project state across builders.
"""
import asyncio
from datetime import datetime
from typing import Dict, List, Optional, Any
from sqlalchemy.orm import Session

from database.models import ProjectModel, BuilderModel


class ProjectSyncManager:
    """Manages project synchronization across builders."""

    def __init__(self, db_session: Session, connector_factory):
        self.db = db_session
        self.connectors = connector_factory
        self._sync_interval = 300  # 5 minutes

    async def sync_project(self, project_id: str) -> Dict[str, Any]:
        """Sync project state with builder."""
        project = self.db.query(ProjectModel).filter(ProjectModel.id == project_id).first()
        if not project:
            raise ValueError("Project not found")

        builder = self.db.query(BuilderModel).filter(BuilderModel.id == project.builder_id).first()
        if not builder:
            raise ValueError("Builder not found")

        # Get connector
        from ..schemas.builder import BuilderResponse
        builder_response = self._builder_to_response(builder)
        connector = self.connectors.get_connector(builder_response)

        async with connector:
            # Sync project state
            remote_state = await connector.get(f"/projects/{project.slug}")

            # Update local state
            project.metadata["last_sync"] = datetime.utcnow().isoformat()
            project.metadata["remote_state"] = remote_state
            project.updated_at = datetime.utcnow()
            self.db.commit()

            return {
                "project_id": project_id,
                "synced_at": datetime.utcnow().isoformat(),
                "remote_state": remote_state,
                "status": "success",
            }

    async def sync_all_projects(self) -> List[Dict[str, Any]]:
        """Sync all active projects."""
        projects = self.db.query(ProjectModel).filter(
            ProjectModel.status.in_(["active", "deployed"])
        ).all()

        results = []
        for project in projects:
            try:
                result = await self.sync_project(project.id)
                results.append(result)
            except Exception as e:
                results.append({
                    "project_id": project.id,
                    "status": "error",
                    "error": str(e),
                })

        return results

    async def start_sync_loop(self):
        """Start continuous sync loop."""
        while True:
            try:
                await self.sync_all_projects()
            except Exception as e:
                print(f"Sync loop error: {e}")

            await asyncio.sleep(self._sync_interval)

    def _builder_to_response(self, builder: BuilderModel) -> BuilderResponse:
        """Convert DB model to response."""
        from ..schemas.builder import BuilderResponse, BuilderCost, BuilderConfig, AuthType

        return BuilderResponse(
            builder_id=builder.id,
            name=builder.name,
            provider=builder.provider,
            slug=builder.slug,
            api_base_url=builder.api_base_url,
            auth_type=AuthType(builder.auth_type),
            supported_project_types=[],
            capabilities=[],
            deployment_regions=builder.deployment_regions,
            cost=BuilderCost(),
            config=BuilderConfig(
                timeout=builder.timeout,
                retry_attempts=builder.retry_attempts,
                rate_limit_per_minute=builder.rate_limit_per_minute,
                health_check_endpoint=builder.health_check_endpoint,
            ),
            max_projects=builder.max_projects,
            max_team_size=builder.max_team_size,
            status=builder.status,
            tags=builder.tags,
            metadata=builder.metadata,
        )
