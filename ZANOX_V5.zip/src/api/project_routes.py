"""Project API routes for Nexus Core V5."""
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from ..schemas.project import ProjectCreate, ProjectUpdate, ProjectResponse, ProjectListResponse
from database.models import ProjectModel, BuilderModel

router = APIRouter()


def get_db():
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    engine = create_engine("postgresql://nexus:nexus_secret_2026@postgres:5432/nexus_core_v5")
    SessionLocal = sessionmaker(bind=engine)
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.post("/", response_model=ProjectResponse, status_code=status.HTTP_201_CREATED)
async def create_project(project: ProjectCreate, db: Session = Depends(get_db)):
    """Create a new project."""
    import uuid
    from datetime import datetime

    project_id = str(uuid.uuid4())

    db_project = ProjectModel(
        id=project_id,
        name=project.name,
        slug=project.slug,
        description=project.description,
        project_type=project.project_type.value,
        builder_id=project.builder_id,
        config=project.config,
        environment=project.environment.value,
        deployment_strategy=project.deployment_strategy.value,
        status="draft",
        metadata=project.metadata,
        tags=project.tags,
        created_at=datetime.utcnow(),
    )

    db.add(db_project)
    db.commit()
    db.refresh(db_project)

    # Update builder project count
    builder = db.query(BuilderModel).filter(BuilderModel.id == project.builder_id).first()
    if builder:
        builder.total_projects += 1
        db.commit()

    return ProjectResponse(
        project_id=db_project.id,
        name=db_project.name,
        slug=db_project.slug,
        description=db_project.description,
        project_type=project.project_type,
        builder_id=db_project.builder_id,
        builder_name=builder.name if builder else None,
        config=db_project.config,
        environment=project.environment,
        deployment_strategy=project.deployment_strategy,
        status=db_project.status,
        build_status=db_project.build_status,
        deployment_status=db_project.deployment_status,
        metadata=db_project.metadata,
        tags=db_project.tags,
        created_at=db_project.created_at,
    )


@router.get("/", response_model=ProjectListResponse)
async def list_projects(
    project_type: Optional[str] = None,
    status: Optional[str] = None,
    builder_id: Optional[str] = None,
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    db: Session = Depends(get_db),
):
    """List all projects."""
    query = db.query(ProjectModel)

    if project_type:
        query = query.filter(ProjectModel.project_type == project_type)
    if status:
        query = query.filter(ProjectModel.status == status)
    if builder_id:
        query = query.filter(ProjectModel.builder_id == builder_id)

    projects = query.offset(skip).limit(limit).all()
    total = query.count()

    return ProjectListResponse(
        projects=[
            ProjectResponse(
                project_id=p.id,
                name=p.name,
                slug=p.slug,
                description=p.description,
                project_type=p.project_type,
                builder_id=p.builder_id,
                config=p.config,
                environment=p.environment,
                deployment_strategy=p.deployment_strategy,
                status=p.status,
                build_status=p.build_status,
                deployment_status=p.deployment_status,
                metadata=p.metadata,
                tags=p.tags,
                created_at=p.created_at,
            )
            for p in projects
        ],
        total=total,
    )


@router.get("/{project_id}", response_model=ProjectResponse)
async def get_project(project_id: str, db: Session = Depends(get_db)):
    """Get project by ID."""
    project = db.query(ProjectModel).filter(ProjectModel.id == project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    builder = db.query(BuilderModel).filter(BuilderModel.id == project.builder_id).first()

    return ProjectResponse(
        project_id=project.id,
        name=project.name,
        slug=project.slug,
        description=project.description,
        project_type=project.project_type,
        builder_id=project.builder_id,
        builder_name=builder.name if builder else None,
        config=project.config,
        environment=project.environment,
        deployment_strategy=project.deployment_strategy,
        status=project.status,
        build_status=project.build_status,
        deployment_status=project.deployment_status,
        source_url=project.source_url,
        preview_url=project.preview_url,
        production_url=project.production_url,
        deployment_count=project.deployment_count,
        last_deployment_at=project.last_deployment_at,
        last_build_at=project.last_build_at,
        metadata=project.metadata,
        tags=project.tags,
        created_at=project.created_at,
        created_by=project.created_by,
    )
