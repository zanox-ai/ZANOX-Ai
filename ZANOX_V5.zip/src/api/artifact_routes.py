"""Artifact API routes for Nexus Core V5."""
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, status
from sqlalchemy.orm import Session

from ..schemas.artifact import ArtifactUpload, ArtifactResponse, ArtifactListResponse
from ..artifacts.artifact_manager import ArtifactManager

router = APIRouter()


def get_db():
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    engine = create_engine("postgresql://nexus:nexus_secret_2026@postgres:5432/nexus_core_v5")
    SessionLocal = sessionmaker(bind=engine)
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.post("/upload", response_model=ArtifactResponse, status_code=status.HTTP_201_CREATED)
async def upload_artifact(
    project_id: str,
    name: str,
    type: str,
    mime_type: str,
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    """Upload an artifact."""
    upload_data = ArtifactUpload(
        project_id=project_id,
        name=name,
        type=type,
        mime_type=mime_type,
    )

    # Mock storage client
    class MockStorage:
        async def put_object(self, bucket, key, data, content_type):
            pass
        async def get_presigned_url(self, bucket, key, expiry):
            return f"https://storage.example.com/{key}"
        async def get_object(self, bucket, key):
            return b""
        async def delete_object(self, bucket, key):
            pass

    manager = ArtifactManager(db, MockStorage())
    file_data = await file.read()
    return await manager.upload_artifact(upload_data, file_data)


@router.get("/", response_model=ArtifactListResponse)
async def list_artifacts(
    project_id: Optional[str] = None,
    artifact_type: Optional[str] = None,
    db: Session = Depends(get_db),
):
    """List artifacts."""
    class MockStorage:
        pass

    manager = ArtifactManager(db, MockStorage())
    return manager.list_artifacts(project_id, artifact_type)
