"""Workflow API routes for Nexus Core V5."""
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from ..schemas.workflow import (
    WorkflowCreate, WorkflowResponse, WorkflowListResponse,
    WorkflowExecutionCreate, WorkflowExecutionResponse
)
from ..workflows.workflow_engine import WorkflowEngine
from ..connectors.connector_framework import ConnectorFactory
from ..auth.auth_manager import AuthManager

router = APIRouter()


def get_db():
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    engine = create_engine("postgresql://nexus:nexus_secret_2026@postgres:5432/nexus_core_v5")
    SessionLocal = sessionmaker(bind=engine)
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.post("/", response_model=WorkflowResponse, status_code=status.HTTP_201_CREATED)
async def create_workflow(workflow: WorkflowCreate, db: Session = Depends(get_db)):
    """Create a new workflow."""
    auth_manager = AuthManager()
    connector_factory = ConnectorFactory(auth_manager)
    engine = WorkflowEngine(db, connector_factory)
    return engine.create_workflow(workflow)


@router.get("/", response_model=WorkflowListResponse)
async def list_workflows(
    workflow_type: Optional[str] = None,
    status: Optional[str] = None,
    is_template: Optional[bool] = None,
    db: Session = Depends(get_db),
):
    """List workflows."""
    auth_manager = AuthManager()
    connector_factory = ConnectorFactory(auth_manager)
    engine = WorkflowEngine(db, connector_factory)
    workflows = engine.list_workflows(workflow_type, status, is_template)
    return WorkflowListResponse(workflows=workflows, total=len(workflows))


@router.get("/{workflow_id}", response_model=WorkflowResponse)
async def get_workflow(workflow_id: str, db: Session = Depends(get_db)):
    """Get workflow by ID."""
    auth_manager = AuthManager()
    connector_factory = ConnectorFactory(auth_manager)
    engine = WorkflowEngine(db, connector_factory)
    workflow = engine.get_workflow(workflow_id)
    if not workflow:
        raise HTTPException(status_code=404, detail="Workflow not found")
    return workflow


@router.post("/{workflow_id}/execute", response_model=WorkflowExecutionResponse)
async def execute_workflow(workflow_id: str, execution: WorkflowExecutionCreate, db: Session = Depends(get_db)):
    """Execute a workflow."""
    auth_manager = AuthManager()
    connector_factory = ConnectorFactory(auth_manager)
    engine = WorkflowEngine(db, connector_factory)
    return await engine.execute_workflow(execution)
