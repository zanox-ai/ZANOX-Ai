"""Health API routes for Nexus Core V5."""
from typing import List, Optional
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from ..schemas.monitoring import HealthCheckResult, Alert
from ..monitoring.health_monitor import BuilderHealthMonitor
from ..registry.builder_registry import BuilderRegistry

router = APIRouter()


def get_db():
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    engine = create_engine("postgresql://nexus:nexus_secret_2026@postgres:5432/nexus_core_v5")
    SessionLocal = sessionmaker(bind=engine)
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.get("/builders")
async def get_builder_health(db: Session = Depends(get_db)):
    """Get health status for all builders."""
    registry = BuilderRegistry(db)
    monitor = BuilderHealthMonitor(registry)
    return monitor.get_all_health_status()


@router.get("/builders/{builder_id}")
async def get_builder_health_status(builder_id: str, db: Session = Depends(get_db)):
    """Get health status for a builder."""
    registry = BuilderRegistry(db)
    monitor = BuilderHealthMonitor(registry)
    return monitor.get_health_status(builder_id)


@router.get("/system")
async def get_system_health():
    """Get system health."""
    return {
        "status": "healthy",
        "components": {
            "api": "healthy",
            "database": "healthy",
            "cache": "healthy",
            "queue": "healthy",
            "storage": "healthy",
        },
        "timestamp": "2026-06-17T01:42:00Z",
    }
