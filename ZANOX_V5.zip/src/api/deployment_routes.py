"""Deployment API routes for Nexus Core V5."""
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from ..schemas.deployment import DeploymentCreate, DeploymentResponse, DeploymentListResponse, RollbackRequest, RollbackResponse
from ..deployment.deployment_coordinator import DeploymentCoordinator
from ..connectors.connector_framework import ConnectorFactory
from ..auth.auth_manager import AuthManager
from database.models import DeploymentModel

router = APIRouter()


def get_db():
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    engine = create_engine("postgresql://nexus:nexus_secret_2026@postgres:5432/nexus_core_v5")
    SessionLocal = sessionmaker(bind=engine)
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.post("/", response_model=DeploymentResponse, status_code=status.HTTP_201_CREATED)
async def create_deployment(deployment: DeploymentCreate, db: Session = Depends(get_db)):
    """Create a new deployment."""
    auth_manager = AuthManager()
    connector_factory = ConnectorFactory(auth_manager)
    coordinator = DeploymentCoordinator(db, connector_factory)
    return await coordinator.create_deployment(deployment)


@router.get("/", response_model=DeploymentListResponse)
async def list_deployments(
    project_id: Optional[str] = None,
    builder_id: Optional[str] = None,
    status: Optional[str] = None,
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    db: Session = Depends(get_db),
):
    """List deployments."""
    auth_manager = AuthManager()
    connector_factory = ConnectorFactory(auth_manager)
    coordinator = DeploymentCoordinator(db, connector_factory)
    deployments = coordinator.list_deployments(project_id, builder_id, status, skip, limit)
    return DeploymentListResponse(deployments=deployments, total=len(deployments))


@router.get("/{deployment_id}", response_model=DeploymentResponse)
async def get_deployment(deployment_id: str, db: Session = Depends(get_db)):
    """Get deployment by ID."""
    auth_manager = AuthManager()
    connector_factory = ConnectorFactory(auth_manager)
    coordinator = DeploymentCoordinator(db, connector_factory)
    deployment = coordinator.get_deployment(deployment_id)
    if not deployment:
        raise HTTPException(status_code=404, detail="Deployment not found")
    return deployment


@router.post("/{deployment_id}/rollback", response_model=RollbackResponse)
async def rollback_deployment(deployment_id: str, rollback: RollbackRequest, db: Session = Depends(get_db)):
    """Rollback a deployment."""
    auth_manager = AuthManager()
    connector_factory = ConnectorFactory(auth_manager)
    coordinator = DeploymentCoordinator(db, connector_factory)
    return await coordinator.rollback_deployment(rollback)
