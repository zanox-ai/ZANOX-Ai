"""Builder API routes for Nexus Core V5."""
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from ..schemas.builder import (
    BuilderCreate, BuilderUpdate, BuilderResponse, BuilderListResponse,
    BuilderSelectionCriteria, BuilderSelectionResult, BuilderRanking,
    BuilderDiscoveryFilter, BuilderStatus, ProjectType
)
from ..registry.builder_registry import BuilderRegistry
from ..selection.selection_engine import BuilderSelectionEngine
from ..scoring.scoring_engine import BuilderScoringEngine

router = APIRouter()


def get_db():
    from database.models import Base
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    engine = create_engine("postgresql://nexus:nexus_secret_2026@postgres:5432/nexus_core_v5")
    SessionLocal = sessionmaker(bind=engine)
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.post("/", response_model=BuilderResponse, status_code=status.HTTP_201_CREATED)
async def create_builder(builder: BuilderCreate, db: Session = Depends(get_db)):
    """Register a new builder."""
    registry = BuilderRegistry(db)
    return registry.register_builder(builder)


@router.get("/", response_model=BuilderListResponse)
async def list_builders(
    status: Optional[BuilderStatus] = None,
    provider: Optional[str] = None,
    project_type: Optional[ProjectType] = None,
    search: Optional[str] = None,
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    db: Session = Depends(get_db),
):
    """List all builders."""
    registry = BuilderRegistry(db)
    builders = registry.list_builders(
        status=status, provider=provider, project_type=project_type,
        search=search, skip=skip, limit=limit,
    )
    return BuilderListResponse(builders=builders, total=len(builders))


@router.get("/{builder_id}", response_model=BuilderResponse)
async def get_builder(builder_id: str, db: Session = Depends(get_db)):
    """Get builder by ID."""
    registry = BuilderRegistry(db)
    builder = registry.get_builder(builder_id)
    if not builder:
        raise HTTPException(status_code=404, detail="Builder not found")
    return builder


@router.put("/{builder_id}", response_model=BuilderResponse)
async def update_builder(builder_id: str, builder: BuilderUpdate, db: Session = Depends(get_db)):
    """Update builder."""
    registry = BuilderRegistry(db)
    updated = registry.update_builder(builder_id, builder)
    if not updated:
        raise HTTPException(status_code=404, detail="Builder not found")
    return updated


@router.delete("/{builder_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_builder(builder_id: str, db: Session = Depends(get_db)):
    """Delete builder."""
    registry = BuilderRegistry(db)
    if not registry.delete_builder(builder_id):
        raise HTTPException(status_code=404, detail="Builder not found")
    return None


@router.post("/select", response_model=BuilderSelectionResult)
async def select_builder(criteria: BuilderSelectionCriteria, db: Session = Depends(get_db)):
    """Select best builder for project."""
    registry = BuilderRegistry(db)
    engine = BuilderSelectionEngine(registry)
    return engine.select_builder(criteria)


@router.get("/rankings", response_model=List[BuilderRanking])
async def get_builder_rankings(db: Session = Depends(get_db)):
    """Get builder rankings."""
    engine = BuilderScoringEngine(db)
    return engine.calculate_rankings()


@router.get("/discover", response_model=BuilderListResponse)
async def discover_builders(
    filter: BuilderDiscoveryFilter = Depends(),
    db: Session = Depends(get_db),
):
    """Discover builders with filters."""
    registry = BuilderRegistry(db)
    builders = registry.list_builders(
        status=filter.status,
        search=filter.search_query,
    )
    return BuilderListResponse(builders=builders, total=len(builders))
