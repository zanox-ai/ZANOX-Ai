"""Analytics API routes for Nexus Core V5."""
from typing import Dict, Any, Optional
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from ..analytics.analytics_engine import AnalyticsEngine

router = APIRouter()


def get_db():
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    engine = create_engine("postgresql://nexus:nexus_secret_2026@postgres:5432/nexus_core_v5")
    SessionLocal = sessionmaker(bind=engine)
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.get("/dashboard")
async def get_dashboard_metrics(db: Session = Depends(get_db)):
    """Get dashboard metrics."""
    engine = AnalyticsEngine(db)
    return engine.get_dashboard_metrics()


@router.get("/builders/{builder_id}")
async def get_builder_analytics(
    builder_id: str,
    days: int = Query(30, ge=1, le=365),
    db: Session = Depends(get_db),
):
    """Get builder analytics."""
    engine = AnalyticsEngine(db)
    return engine.get_builder_analytics(builder_id, days)


@router.get("/projects/{project_id}")
async def get_project_analytics(project_id: str, db: Session = Depends(get_db)):
    """Get project analytics."""
    engine = AnalyticsEngine(db)
    return engine.get_project_analytics(project_id)


@router.get("/cost")
async def get_cost_analytics(
    days: int = Query(30, ge=1, le=365),
    db: Session = Depends(get_db),
):
    """Get cost analytics."""
    engine = AnalyticsEngine(db)
    return engine.get_cost_analytics(days)
