"""Builder Routing Engine for Nexus Core V5.

Routes requests to selected builders with load balancing.
"""
import random
from typing import List, Dict, Any, Optional
from collections import defaultdict

from ..schemas.builder import BuilderResponse, BuilderStatus


class BuilderRoutingEngine:
    """Routes requests to builders with intelligent load balancing."""

    def __init__(self):
        self._connection_counts: Dict[str, int] = defaultdict(int)
        self._session_map: Dict[str, str] = {}

    def route_request(
        self,
        builder: BuilderResponse,
        request_data: Dict[str, Any],
        session_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Route request to builder with session affinity."""
        # Session affinity
        if session_id and session_id in self._session_map:
            sticky_builder = self._session_map[session_id]
            if sticky_builder == builder.id:
                return {"builder_id": builder.id, "sticky": True}

        # Update connection count
        self._connection_counts[builder.id] += 1

        # Set session affinity
        if session_id:
            self._session_map[session_id] = builder.id

        return {
            "builder_id": builder.id,
            "builder_url": builder.api_base_url,
            "sticky": False,
            "connection_count": self._connection_counts[builder.id],
        }

    def weighted_round_robin(
        self,
        builders: List[BuilderResponse],
        weights: Optional[Dict[str, float]] = None,
    ) -> BuilderResponse:
        """Select builder using weighted round robin."""
        if not builders:
            raise ValueError("No builders available")

        if weights is None:
            weights = {b.id: b.health_score for b in builders}

        # Calculate weighted probabilities
        total_weight = sum(weights.get(b.id, 1.0) for b in builders)
        probabilities = [
            weights.get(b.id, 1.0) / total_weight for b in builders
        ]

        # Select based on probability
        r = random.random()
        cumulative = 0.0
        for builder, prob in zip(builders, probabilities):
            cumulative += prob
            if r <= cumulative:
                return builder

        return builders[-1]

    def least_connections(self, builders: List[BuilderResponse]) -> BuilderResponse:
        """Select builder with least connections."""
        if not builders:
            raise ValueError("No builders available")

        min_connections = float("inf")
        selected = builders[0]

        for builder in builders:
            connections = self._connection_counts[builder.id]
            if connections < min_connections:
                min_connections = connections
                selected = builder

        return selected

    def health_aware_routing(
        self,
        builders: List[BuilderResponse],
        min_health_score: float = 0.7,
    ) -> BuilderResponse:
        """Route to healthiest builder."""
        healthy = [
            b for b in builders
            if b.health_score >= min_health_score and b.status == BuilderStatus.ACTIVE
        ]

        if not healthy:
            raise ValueError("No healthy builders available")

        # Sort by health score descending
        healthy.sort(key=lambda b: b.health_score, reverse=True)
        return healthy[0]

    def release_connection(self, builder_id: str, session_id: Optional[str] = None):
        """Release connection count."""
        self._connection_counts[builder_id] = max(0, self._connection_counts[builder_id] - 1)

        if session_id and session_id in self._session_map:
            del self._session_map[session_id]

    def get_routing_stats(self) -> Dict[str, Any]:
        """Get routing statistics."""
        return {
            "connection_counts": dict(self._connection_counts),
            "active_sessions": len(self._session_map),
            "total_connections": sum(self._connection_counts.values()),
        }
