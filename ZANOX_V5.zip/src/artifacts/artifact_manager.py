"""Builder Artifact Manager for Nexus Core V5.

Manages build artifacts across all builders.
"""
import uuid
import hashlib
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session

from ..schemas.artifact import ArtifactUpload, ArtifactResponse, ArtifactListResponse
from database.models import ArtifactModel as ArtifactDB


class ArtifactManager:
    """Manages build artifacts."""

    def __init__(self, db_session: Session, storage_client):
        self.db = db_session
        self.storage = storage_client
        self.retention_days = 90
        self.max_size_mb = 500

    async def upload_artifact(self, upload_data: ArtifactUpload, file_data: bytes) -> ArtifactResponse:
        """Upload an artifact."""
        artifact_id = str(uuid.uuid4())

        # Validate size
        size_mb = len(file_data) / (1024 * 1024)
        if size_mb > self.max_size_mb:
            raise ValueError(f"Artifact size {size_mb:.2f}MB exceeds maximum {self.max_size_mb}MB")

        # Calculate checksum
        checksum = hashlib.sha256(file_data).hexdigest()

        # Store in storage
        storage_path = f"projects/{upload_data.project_id}/artifacts/{artifact_id}"
        await self.storage.put_object(
            bucket="builder-artifacts",
            key=storage_path,
            data=file_data,
            content_type=upload_data.mime_type,
        )

        # Generate URL
        storage_url = await self.storage.get_presigned_url(
            bucket="builder-artifacts",
            key=storage_path,
            expiry=timedelta(days=7),
        )

        # Calculate expiration
        expires_at = None
        if upload_data.expires_in_days:
            expires_at = datetime.utcnow() + timedelta(days=upload_data.expires_in_days)
        else:
            expires_at = datetime.utcnow() + timedelta(days=self.retention_days)

        artifact = ArtifactDB(
            id=artifact_id,
            project_id=upload_data.project_id,
            name=upload_data.name,
            type=upload_data.type,
            mime_type=upload_data.mime_type,
            size_bytes=len(file_data),
            checksum=checksum,
            storage_provider="minio",
            storage_path=storage_path,
            storage_url=storage_url,
            metadata=upload_data.metadata,
            tags=upload_data.tags,
            expires_at=expires_at,
            created_at=datetime.utcnow(),
        )

        self.db.add(artifact)
        self.db.commit()
        self.db.refresh(artifact)

        return self._to_response(artifact)

    async def get_artifact(self, artifact_id: str) -> Optional[ArtifactResponse]:
        """Get artifact by ID."""
        artifact = self.db.query(ArtifactDB).filter(ArtifactDB.id == artifact_id).first()
        if not artifact:
            return None
        return self._to_response(artifact)

    async def download_artifact(self, artifact_id: str) -> bytes:
        """Download artifact data."""
        artifact = self.db.query(ArtifactDB).filter(ArtifactDB.id == artifact_id).first()
        if not artifact:
            raise ValueError("Artifact not found")

        data = await self.storage.get_object(
            bucket="builder-artifacts",
            key=artifact.storage_path,
        )
        return data

    def list_artifacts(
        self,
        project_id: Optional[str] = None,
        artifact_type: Optional[str] = None,
        skip: int = 0,
        limit: int = 100,
    ) -> ArtifactListResponse:
        """List artifacts."""
        query = self.db.query(ArtifactDB)

        if project_id:
            query = query.filter(ArtifactDB.project_id == project_id)
        if artifact_type:
            query = query.filter(ArtifactDB.type == artifact_type)

        artifacts = query.order_by(ArtifactDB.created_at.desc()).offset(skip).limit(limit).all()
        total = query.count()

        return ArtifactListResponse(
            artifacts=[self._to_response(a) for a in artifacts],
            total=total,
        )

    async def delete_artifact(self, artifact_id: str) -> bool:
        """Delete an artifact."""
        artifact = self.db.query(ArtifactDB).filter(ArtifactDB.id == artifact_id).first()
        if not artifact:
            return False

        # Delete from storage
        await self.storage.delete_object(
            bucket="builder-artifacts",
            key=artifact.storage_path,
        )

        # Delete from database
        self.db.delete(artifact)
        self.db.commit()
        return True

    async def cleanup_expired(self) -> int:
        """Clean up expired artifacts."""
        expired = self.db.query(ArtifactDB).filter(
            ArtifactDB.expires_at < datetime.utcnow()
        ).all()

        count = 0
        for artifact in expired:
            await self.delete_artifact(artifact.id)
            count += 1

        return count

    def _to_response(self, artifact: ArtifactDB) -> ArtifactResponse:
        """Convert DB model to response."""
        return ArtifactResponse(
            artifact_id=artifact.id,
            project_id=artifact.project_id,
            name=artifact.name,
            type=artifact.type,
            mime_type=artifact.mime_type,
            size_bytes=artifact.size_bytes,
            checksum=artifact.checksum,
            storage_provider=artifact.storage_provider,
            storage_path=artifact.storage_path,
            storage_url=artifact.storage_url,
            metadata=artifact.metadata,
            tags=artifact.tags,
            expires_at=artifact.expires_at,
            created_at=artifact.created_at,
            created_by=artifact.created_by,
        )
