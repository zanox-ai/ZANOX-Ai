"""Builder Governance Layer for Nexus Core V5.

Manages policies, approvals, and compliance.
"""
import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.orm import Session

from ..schemas.governance import PolicyCreate, PolicyResponse, PolicyRule, ApprovalRequest, ComplianceCheck
from database.models import GovernancePolicyModel, AuditLogModel


class GovernanceEngine:
    """Manages governance policies and compliance."""

    def __init__(self, db_session: Session, security_manager):
        self.db = db_session
        self.security = security_manager

    def create_policy(self, policy_data: PolicyCreate) -> PolicyResponse:
        """Create a governance policy."""
        policy_id = str(uuid.uuid4())

        policy = GovernancePolicyModel(
            id=policy_id,
            name=policy_data.name,
            description=policy_data.description,
            policy_type=policy_data.policy_type,
            rules=[rule.model_dump() for rule in policy_data.rules],
            conditions=policy_data.conditions,
            actions=policy_data.actions,
            priority=policy_data.priority,
            status="active",
            metadata=policy_data.metadata,
            created_at=datetime.utcnow(),
        )

        self.db.add(policy)
        self.db.commit()
        self.db.refresh(policy)

        return self._to_response(policy)

    def get_policy(self, policy_id: str) -> Optional[PolicyResponse]:
        """Get policy by ID."""
        policy = self.db.query(GovernancePolicyModel).filter(GovernancePolicyModel.id == policy_id).first()
        if not policy:
            return None
        return self._to_response(policy)

    def list_policies(
        self,
        policy_type: Optional[str] = None,
        status: Optional[str] = None,
        skip: int = 0,
        limit: int = 100,
    ) -> List[PolicyResponse]:
        """List policies."""
        query = self.db.query(GovernancePolicyModel)

        if policy_type:
            query = query.filter(GovernancePolicyModel.policy_type == policy_type)
        if status:
            query = query.filter(GovernancePolicyModel.status == status)

        policies = query.order_by(GovernancePolicyModel.priority.desc()).offset(skip).limit(limit).all()
        return [self._to_response(p) for p in policies]

    def evaluate_policy(
        self,
        policy_id: str,
        context: Dict[str, Any],
    ) -> ComplianceCheck:
        """Evaluate a policy against context."""
        policy = self.db.query(GovernancePolicyModel).filter(GovernancePolicyModel.id == policy_id).first()
        if not policy:
            return ComplianceCheck(
                check_id=str(uuid.uuid4()),
                policy_id=policy_id,
                resource_type="unknown",
                resource_id="",
                compliant=False,
                violations=["Policy not found"],
            )

        violations = []
        rules = policy.rules or []

        for rule in rules:
            if not rule.get("enabled", True):
                continue

            condition = rule.get("condition", {})
            if not self._evaluate_condition(condition, context):
                violations.append(rule.get("name", "Unknown rule"))

        return ComplianceCheck(
            check_id=str(uuid.uuid4()),
            policy_id=policy_id,
            resource_type=context.get("resource_type", "unknown"),
            resource_id=context.get("resource_id", ""),
            compliant=len(violations) == 0,
            violations=violations,
            details={"policy_name": policy.name, "rules_evaluated": len(rules)},
        )

    def evaluate_all_policies(self, context: Dict[str, Any]) -> List[ComplianceCheck]:
        """Evaluate all active policies."""
        policies = self.db.query(GovernancePolicyModel).filter(
            GovernancePolicyModel.status == "active"
        ).all()

        results = []
        for policy in policies:
            result = self.evaluate_policy(policy.id, context)
            results.append(result)

        return results

    def request_approval(self, request_data: ApprovalRequest) -> ApprovalRequest:
        """Request approval for an action."""
        request_id = str(uuid.uuid4())

        approval = ApprovalRequest(
            request_id=request_id,
            request_type=request_data.request_type,
            resource_type=request_data.resource_type,
            resource_id=request_data.resource_id,
            requested_by=request_data.requested_by,
            requested_at=datetime.utcnow(),
            reason=request_data.reason,
            details=request_data.details,
            status="pending",
        )

        # Store in database
        # Implementation would store in an approvals table

        return approval

    def approve_request(self, request_id: str, approved_by: str, notes: Optional[str] = None) -> ApprovalRequest:
        """Approve a request."""
        # Implementation would update the approval record
        return ApprovalRequest(
            request_id=request_id,
            request_type="",
            resource_type="",
            resource_id="",
            requested_by="",
            status="approved",
            approved_by=approved_by,
            approved_at=datetime.utcnow(),
        )

    def reject_request(self, request_id: str, rejected_by: str, reason: str) -> ApprovalRequest:
        """Reject a request."""
        return ApprovalRequest(
            request_id=request_id,
            request_type="",
            resource_type="",
            resource_id="",
            requested_by="",
            status="rejected",
            approved_by=rejected_by,
            rejection_reason=reason,
        )

    def _evaluate_condition(self, condition: Dict, context: Dict) -> bool:
        """Evaluate a condition against context."""
        operator = condition.get("operator", "eq")
        field = condition.get("field", "")
        value = condition.get("value")

        context_value = context.get(field)

        if operator == "eq":
            return context_value == value
        elif operator == "ne":
            return context_value != value
        elif operator == "gt":
            return context_value is not None and value is not None and context_value > value
        elif operator == "gte":
            return context_value is not None and value is not None and context_value >= value
        elif operator == "lt":
            return context_value is not None and value is not None and context_value < value
        elif operator == "lte":
            return context_value is not None and value is not None and context_value <= value
        elif operator == "in":
            return context_value in value if isinstance(value, list) else False
        elif operator == "contains":
            return value in context_value if isinstance(context_value, (list, str)) else False

        return True

    def _to_response(self, policy: GovernancePolicyModel) -> PolicyResponse:
        """Convert DB model to response."""
        return PolicyResponse(
            policy_id=policy.id,
            name=policy.name,
            description=policy.description,
            policy_type=policy.policy_type,
            rules=[PolicyRule(**rule) for rule in (policy.rules or [])],
            conditions=policy.conditions,
            actions=policy.actions,
            status=policy.status,
            priority=policy.priority,
            metadata=policy.metadata,
            created_at=policy.created_at,
            updated_at=policy.updated_at,
            created_by=policy.created_by,
        )
