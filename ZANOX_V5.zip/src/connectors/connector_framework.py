"""Builder API Connector Framework for Nexus Core V5.

Provides unified interface to all external builders.
"""
import asyncio
import json
from typing import Dict, Any, Optional, AsyncGenerator
import aiohttp

from ..schemas.builder import BuilderResponse, BuilderConfig
from ..auth.auth_manager import AuthManager


class BuilderConnector:
    """Base connector for external builders."""

    def __init__(self, builder: BuilderResponse, auth_manager: AuthManager):
        self.builder = builder
        self.auth = auth_manager
        self.config = builder.config
        self.session: Optional[aiohttp.ClientSession] = None

    async def __aenter__(self):
        timeout = aiohttp.ClientTimeout(total=self.config.timeout)
        self.session = aiohttp.ClientSession(timeout=timeout)
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            await self.session.close()

    async def _get_auth_headers(self) -> Dict[str, str]:
        """Get authentication headers."""
        from ..schemas.builder import BuilderAuth, AuthType
        auth_config = BuilderAuth(
            auth_type=AuthType(self.builder.auth_type),
            api_key=self.builder.config.custom_headers.get("api_key"),
            client_id=self.builder.config.custom_headers.get("client_id"),
            client_secret=self.builder.config.custom_headers.get("client_secret"),
        )
        return await self.auth.authenticate(self.builder.id, auth_config)

    async def get(self, path: str, params: Optional[Dict] = None) -> Dict[str, Any]:
        """Make GET request."""
        headers = await self._get_auth_headers()
        url = f"{self.builder.api_base_url}{path}"

        async with self.session.get(url, headers=headers, params=params) as response:
            response.raise_for_status()
            return await response.json()

    async def post(self, path: str, data: Optional[Dict] = None) -> Dict[str, Any]:
        """Make POST request."""
        headers = await self._get_auth_headers()
        headers["Content-Type"] = "application/json"
        url = f"{self.builder.api_base_url}{path}"

        async with self.session.post(url, headers=headers, json=data) as response:
            response.raise_for_status()
            return await response.json()

    async def put(self, path: str, data: Optional[Dict] = None) -> Dict[str, Any]:
        """Make PUT request."""
        headers = await self._get_auth_headers()
        headers["Content-Type"] = "application/json"
        url = f"{self.builder.api_base_url}{path}"

        async with self.session.put(url, headers=headers, json=data) as response:
            response.raise_for_status()
            return await response.json()

    async def delete(self, path: str) -> Dict[str, Any]:
        """Make DELETE request."""
        headers = await self._get_auth_headers()
        url = f"{self.builder.api_base_url}{path}"

        async with self.session.delete(url, headers=headers) as response:
            response.raise_for_status()
            return await response.json()

    async def stream_post(self, path: str, data: Optional[Dict] = None) -> AsyncGenerator[str, None]:
        """Make streaming POST request."""
        headers = await self._get_auth_headers()
        headers["Content-Type"] = "application/json"
        headers["Accept"] = "text/event-stream"
        url = f"{self.builder.api_base_url}{path}"

        async with self.session.post(url, headers=headers, json=data) as response:
            response.raise_for_status()
            async for line in response.content:
                line = line.decode("utf-8").strip()
                if line.startswith("data: "):
                    yield line[6:]


class ConnectorFactory:
    """Factory for creating builder connectors."""

    def __init__(self, auth_manager: AuthManager):
        self.auth_manager = auth_manager
        self._connectors: Dict[str, Any] = {}

    def get_connector(self, builder: BuilderResponse) -> BuilderConnector:
        """Get connector for a builder."""
        if builder.id not in self._connectors:
            self._connectors[builder.id] = BuilderConnector(builder, self.auth_manager)
        return self._connectors[builder.id]

    def remove_connector(self, builder_id: str):
        """Remove connector from cache."""
        self._connectors.pop(builder_id, None)
