"""Builder Analytics Dashboard Backend for Nexus Core V5.

Provides analytics data for the dashboard.
"""
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
from sqlalchemy.orm import Session
from sqlalchemy import func

from database.models import (
    BuilderModel, ProjectModel, DeploymentModel, BuilderCostHistory,
    BuilderHealthCheck, BuilderRankingHistory
)


class AnalyticsEngine:
    """Generates analytics for the dashboard."""

    def __init__(self, db_session: Session):
        self.db = db_session

    def get_dashboard_metrics(self) -> Dict[str, Any]:
        """Get main dashboard metrics."""
        total_builders = self.db.query(BuilderModel).count()
        active_builders = self.db.query(BuilderModel).filter(
            BuilderModel.status == "active"
        ).count()
        degraded_builders = self.db.query(BuilderModel).filter(
            BuilderModel.status == "degraded"
        ).count()
        offline_builders = self.db.query(BuilderModel).filter(
            BuilderModel.status == "offline"
        ).count()

        total_projects = self.db.query(ProjectModel).count()

        # 24h deployments
        cutoff_24h = datetime.utcnow() - timedelta(hours=24)
        deployments_24h = self.db.query(DeploymentModel).filter(
            DeploymentModel.created_at >= cutoff_24h
        ).count()

        # 24h cost
        cost_24h = self.db.query(
            func.sum(BuilderCostHistory.total_cost)
        ).filter(
            BuilderCostHistory.timestamp >= cutoff_24h
        ).scalar() or 0.0

        # Average deployment duration
        avg_duration = self.db.query(
            func.avg(DeploymentModel.duration_ms)
        ).filter(
            DeploymentModel.status == "completed",
            DeploymentModel.created_at >= cutoff_24h,
        ).scalar() or 0.0

        # Success rate
        total_deployments_24h = self.db.query(DeploymentModel).filter(
            DeploymentModel.created_at >= cutoff_24h
        ).count()
        successful_deployments_24h = self.db.query(DeploymentModel).filter(
            DeploymentModel.status == "completed",
            DeploymentModel.created_at >= cutoff_24h,
        ).count()

        success_rate = (
            successful_deployments_24h / total_deployments_24h
            if total_deployments_24h > 0 else 1.0
        )

        # Top builders
        top_builders = self.db.query(BuilderModel).order_by(
            BuilderModel.rank_score.desc()
        ).limit(5).all()

        return {
            "total_builders": total_builders,
            "active_builders": active_builders,
            "degraded_builders": degraded_builders,
            "offline_builders": offline_builders,
            "total_projects": total_projects,
            "total_deployments_24h": deployments_24h,
            "total_cost_24h": float(cost_24h),
            "avg_deployment_duration_ms": float(avg_duration) if avg_duration else 0.0,
            "success_rate": round(success_rate, 4),
            "top_builders": [
                {
                    "id": b.id,
                    "name": b.name,
                    "rank_score": b.rank_score,
                    "health_score": b.health_score,
                    "total_projects": b.total_projects,
                }
                for b in top_builders
            ],
            "timestamp": datetime.utcnow().isoformat(),
        }

    def get_builder_analytics(self, builder_id: str, days: int = 30) -> Dict[str, Any]:
        """Get analytics for a specific builder."""
        builder = self.db.query(BuilderModel).filter(BuilderModel.id == builder_id).first()
        if not builder:
            return {}

        cutoff = datetime.utcnow() - timedelta(days=days)

        # Deployment stats
        deployments = self.db.query(DeploymentModel).filter(
            DeploymentModel.builder_id == builder_id,
            DeploymentModel.created_at >= cutoff,
        ).all()

        deployment_stats = {
            "total": len(deployments),
            "successful": sum(1 for d in deployments if d.status == "completed"),
            "failed": sum(1 for d in deployments if d.status == "failed"),
            "avg_duration_ms": sum(d.duration_ms for d in deployments if d.duration_ms) / len(deployments) if deployments else 0,
        }

        # Cost stats
        cost_summary = self.db.query(
            func.sum(BuilderCostHistory.total_cost).label("total"),
            func.avg(BuilderCostHistory.total_cost).label("avg"),
            func.count(BuilderCostHistory.id).label("count"),
        ).filter(
            BuilderCostHistory.builder_id == builder_id,
            BuilderCostHistory.timestamp >= cutoff,
        ).first()

        # Health trend
        health_checks = self.db.query(BuilderHealthCheck).filter(
            BuilderHealthCheck.builder_id == builder_id,
            BuilderHealthCheck.timestamp >= cutoff,
        ).order_by(BuilderHealthCheck.timestamp).all()

        health_trend = [
            {
                "timestamp": h.timestamp.isoformat(),
                "status": h.status,
                "latency_ms": h.latency_ms,
            }
            for h in health_checks
        ]

        # Ranking history
        rankings = self.db.query(BuilderRankingHistory).filter(
            BuilderRankingHistory.builder_id == builder_id,
            BuilderRankingHistory.calculated_at >= cutoff,
        ).order_by(BuilderRankingHistory.calculated_at).all()

        ranking_trend = [
            {
                "timestamp": r.calculated_at.isoformat(),
                "rank": r.rank,
                "overall_score": r.overall_score,
            }
            for r in rankings
        ]

        return {
            "builder_id": builder_id,
            "builder_name": builder.name,
            "period_days": days,
            "deployment_stats": deployment_stats,
            "cost_stats": {
                "total_cost": float(cost_summary.total) if cost_summary and cost_summary.total else 0.0,
                "avg_cost": float(cost_summary.avg) if cost_summary and cost_summary.avg else 0.0,
                "record_count": cost_summary.count if cost_summary else 0,
            },
            "health_trend": health_trend,
            "ranking_trend": ranking_trend,
            "current_health_score": builder.health_score,
            "current_rank_score": builder.rank_score,
        }

    def get_project_analytics(self, project_id: str) -> Dict[str, Any]:
        """Get analytics for a specific project."""
        project = self.db.query(ProjectModel).filter(ProjectModel.id == project_id).first()
        if not project:
            return {}

        deployments = self.db.query(DeploymentModel).filter(
            DeploymentModel.project_id == project_id
        ).order_by(DeploymentModel.created_at.desc()).all()

        costs = self.db.query(BuilderCostHistory).filter(
            BuilderCostHistory.project_id == project_id
        ).all()

        return {
            "project_id": project_id,
            "project_name": project.name,
            "total_deployments": len(deployments),
            "successful_deployments": sum(1 for d in deployments if d.status == "completed"),
            "failed_deployments": sum(1 for d in deployments if d.status == "failed"),
            "total_cost": sum(c.total_cost for c in costs),
            "last_deployment": project.last_deployment_at.isoformat() if project.last_deployment_at else None,
            "deployment_history": [
                {
                    "id": d.id,
                    "version": d.version,
                    "status": d.status,
                    "duration_ms": d.duration_ms,
                    "created_at": d.created_at.isoformat(),
                }
                for d in deployments[:10]
            ],
        }

    def get_cost_analytics(self, days: int = 30) -> Dict[str, Any]:
        """Get cost analytics."""
        cutoff = datetime.utcnow() - timedelta(days=days)

        # Total cost
        total_cost = self.db.query(
            func.sum(BuilderCostHistory.total_cost)
        ).filter(
            BuilderCostHistory.timestamp >= cutoff
        ).scalar() or 0.0

        # Cost by builder
        cost_by_builder = self.db.query(
            BuilderCostHistory.builder_id,
            func.sum(BuilderCostHistory.total_cost).label("total"),
        ).filter(
            BuilderCostHistory.timestamp >= cutoff
        ).group_by(BuilderCostHistory.builder_id).all()

        # Daily cost
        daily_cost = self.db.query(
            func.date(BuilderCostHistory.timestamp).label("date"),
            func.sum(BuilderCostHistory.total_cost).label("daily"),
        ).filter(
            BuilderCostHistory.timestamp >= cutoff
        ).group_by(
            func.date(BuilderCostHistory.timestamp)
        ).order_by(
            func.date(BuilderCostHistory.timestamp)
        ).all()

        return {
            "period_days": days,
            "total_cost": float(total_cost),
            "cost_by_builder": [
                {"builder_id": c.builder_id, "total_cost": float(c.total)}
                for c in cost_by_builder
            ],
            "daily_cost": [
                {"date": c.date.isoformat(), "cost": float(c.daily)}
                for c in daily_cost
            ],
        }
