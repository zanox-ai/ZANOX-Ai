"""Builder schemas for Nexus Core V5."""
from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field

from .base import BaseSchema, TimestampSchema, BuilderStatus, ProjectType, AuthType


class BuilderCapability(BaseModel):
    """Builder capability definition."""
    name: str
    description: str
    category: str
    confidence_score: float = Field(default=0.0, ge=0.0, le=1.0)
    parameters: Dict[str, Any] = Field(default_factory=dict)
    supported_project_types: List[ProjectType] = Field(default_factory=list)


class BuilderCost(BaseModel):
    """Builder cost structure."""
    per_hour: float = Field(default=0.0, ge=0.0)
    per_deployment: float = Field(default=0.0, ge=0.0)
    per_request: float = Field(default=0.0, ge=0.0)
    per_user: float = Field(default=0.0, ge=0.0)
    per_project: float = Field(default=0.0, ge=0.0)
    currency: str = "USD"


class BuilderConfig(BaseModel):
    """Builder configuration."""
    timeout: int = Field(default=60, ge=1)
    retry_attempts: int = Field(default=3, ge=0, le=10)
    retry_delay: float = Field(default=1.0, ge=0.0)
    max_concurrent_requests: int = Field(default=100, ge=1)
    rate_limit_per_minute: int = Field(default=100, ge=1)
    health_check_endpoint: str = "/health"
    custom_headers: Dict[str, str] = Field(default_factory=dict)
    custom_parameters: Dict[str, Any] = Field(default_factory=dict)


class BuilderAuth(BaseModel):
    """Builder authentication configuration."""
    auth_type: AuthType
    api_key: Optional[str] = None
    client_id: Optional[str] = None
    client_secret: Optional[str] = None
    access_token: Optional[str] = None
    refresh_token: Optional[str] = None
    token_expiry: Optional[datetime] = None
    scopes: List[str] = Field(default_factory=list)


class BuilderCreate(BaseSchema):
    """Builder creation schema."""
    name: str = Field(..., min_length=1, max_length=100)
    provider: str = Field(..., min_length=1, max_length=50)
    slug: str = Field(..., min_length=1, max_length=50)
    description: Optional[str] = None
    api_base_url: str
    auth_type: AuthType
    auth_config: BuilderAuth
    supported_project_types: List[ProjectType]
    capabilities: List[BuilderCapability]
    deployment_regions: List[str] = Field(default_factory=list)
    cost: BuilderCost = Field(default_factory=BuilderCost)
    config: BuilderConfig = Field(default_factory=BuilderConfig)
    max_projects: int = Field(default=100, ge=1)
    max_team_size: int = Field(default=50, ge=1)
    tags: List[str] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class BuilderUpdate(BaseSchema):
    """Builder update schema."""
    name: Optional[str] = Field(None, min_length=1, max_length=100)
    description: Optional[str] = None
    api_base_url: Optional[str] = None
    auth_config: Optional[BuilderAuth] = None
    supported_project_types: Optional[List[ProjectType]] = None
    capabilities: Optional[List[BuilderCapability]] = None
    deployment_regions: Optional[List[str]] = None
    cost: Optional[BuilderCost] = None
    config: Optional[BuilderConfig] = None
    status: Optional[BuilderStatus] = None
    max_projects: Optional[int] = Field(None, ge=1)
    max_team_size: Optional[int] = Field(None, ge=1)
    tags: Optional[List[str]] = None
    metadata: Optional[Dict[str, Any]] = None


class BuilderResponse(TimestampSchema):
    """Builder response schema."""
    id: str = Field(..., alias="builder_id")
    name: str
    provider: str
    slug: str
    description: Optional[str] = None
    api_base_url: str
    auth_type: AuthType
    supported_project_types: List[ProjectType]
    capabilities: List[BuilderCapability]
    deployment_regions: List[str]
    cost: BuilderCost
    config: BuilderConfig
    max_projects: int
    max_team_size: int
    status: BuilderStatus = BuilderStatus.ACTIVE
    health_score: float = Field(default=1.0, ge=0.0, le=1.0)
    rank_score: float = Field(default=0.0, ge=0.0, le=1.0)
    is_available: bool = True
    total_projects: int = Field(default=0, ge=0)
    total_deployments: int = Field(default=0, ge=0)
    total_requests: int = Field(default=0, ge=0)
    total_cost: float = Field(default=0.0, ge=0.0)
    avg_latency_ms: float = Field(default=0.0, ge=0.0)
    error_rate: float = Field(default=0.0, ge=0.0, le=1.0)
    success_rate: float = Field(default=1.0, ge=0.0, le=1.0)
    tags: List[str] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)
    last_health_check: Optional[datetime] = None
    last_deployment: Optional[datetime] = None


class BuilderListResponse(BaseSchema):
    """Builder list response."""
    builders: List[BuilderResponse]
    total: int


class BuilderHealth(BaseSchema):
    """Builder health status."""
    builder_id: str
    status: BuilderStatus
    latency_ms: float
    error_rate: float
    last_check: datetime
    uptime_percentage: float
    consecutive_failures: int
    message: Optional[str] = None


class BuilderMetrics(BaseSchema):
    """Builder performance metrics."""
    builder_id: str
    timestamp: datetime
    requests_count: int
    deployments_count: int
    projects_count: int
    total_cost: float
    avg_latency_ms: float
    p50_latency_ms: float
    p95_latency_ms: float
    p99_latency_ms: float
    error_count: int
    error_rate: float
    success_rate: float
    concurrent_requests: int
    queue_depth: int


class BuilderSelectionCriteria(BaseSchema):
    """Criteria for builder selection."""
    project_type: ProjectType
    required_capabilities: List[str] = Field(default_factory=list)
    preferred_providers: Optional[List[str]] = None
    excluded_builders: Optional[List[str]] = None
    max_cost_per_project: Optional[float] = None
    max_latency_ms: Optional[float] = None
    min_success_rate: Optional[float] = Field(None, ge=0.0, le=1.0)
    required_regions: Optional[List[str]] = None
    priority: str = "normal"
    fallback_enabled: bool = True


class BuilderSelectionResult(BaseSchema):
    """Builder selection result."""
    selected_builder_id: str
    selected_builder_name: str
    confidence_score: float
    estimated_cost: float
    estimated_latency_ms: float
    estimated_duration_minutes: float
    fallback_chain: List[str] = Field(default_factory=list)
    selection_reason: str
    capability_match_score: float


class BuilderRanking(BaseSchema):
    """Builder ranking entry."""
    builder_id: str
    builder_name: str
    rank: int
    overall_score: float
    performance_score: float
    reliability_score: float
    cost_efficiency_score: float
    user_feedback_score: float
    capability_match_score: float
    trend: str = "stable"
    change_from_last: int = 0


class BuilderDiscoveryFilter(BaseSchema):
    """Filter for builder discovery."""
    providers: Optional[List[str]] = None
    project_types: Optional[List[ProjectType]] = None
    capabilities: Optional[List[str]] = None
    min_health_score: Optional[float] = Field(None, ge=0.0, le=1.0)
    max_cost_per_project: Optional[float] = None
    status: Optional[BuilderStatus] = None
    regions: Optional[List[str]] = None
    tags: Optional[List[str]] = None
    search_query: Optional[str] = None
    sort_by: str = "rank_score"
    sort_order: str = "desc"
