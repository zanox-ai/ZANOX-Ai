"""Governance schemas for Nexus Core V5."""
from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field

from .base import BaseSchema, TimestampSchema


class PolicyRule(BaseModel):
    """Policy rule definition."""
    rule_id: str
    name: str
    description: Optional[str] = None
    condition: Dict[str, Any]
    action: str
    parameters: Dict[str, Any] = Field(default_factory=dict)
    priority: int = Field(default=1, ge=1)
    enabled: bool = True


class PolicyCreate(BaseSchema):
    """Policy creation schema."""
    name: str = Field(..., min_length=1, max_length=200)
    description: Optional[str] = None
    policy_type: str = Field(..., min_length=1, max_length=100)
    rules: List[PolicyRule]
    conditions: Dict[str, Any] = Field(default_factory=dict)
    actions: List[str] = Field(default_factory=list)
    priority: int = Field(default=1, ge=1)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class PolicyResponse(TimestampSchema):
    """Policy response schema."""
    id: str = Field(..., alias="policy_id")
    name: str
    description: Optional[str] = None
    policy_type: str
    rules: List[PolicyRule]
    conditions: Dict[str, Any] = Field(default_factory=dict)
    actions: List[str] = Field(default_factory=list)
    status: str = "active"
    priority: int
    metadata: Dict[str, Any] = Field(default_factory=dict)
    created_by: Optional[str] = None


class ApprovalRequest(BaseSchema):
    """Approval request schema."""
    request_id: str
    request_type: str
    resource_type: str
    resource_id: str
    requested_by: str
    requested_at: datetime = Field(default_factory=datetime.utcnow)
    reason: Optional[str] = None
    details: Dict[str, Any] = Field(default_factory=dict)
    status: str = "pending"
    approved_by: Optional[str] = None
    approved_at: Optional[datetime] = None
    rejection_reason: Optional[str] = None


class ComplianceCheck(BaseSchema):
    """Compliance check schema."""
    check_id: str
    policy_id: str
    resource_type: str
    resource_id: str
    compliant: bool
    violations: List[str] = Field(default_factory=list)
    details: Dict[str, Any] = Field(default_factory=dict)
    checked_at: datetime = Field(default_factory=datetime.utcnow)
