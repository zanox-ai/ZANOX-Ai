"""Artifact schemas for Nexus Core V5."""
from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field

from .base import BaseSchema, TimestampSchema


class ArtifactUpload(BaseSchema):
    """Artifact upload schema."""
    project_id: str
    name: str = Field(..., min_length=1, max_length=200)
    type: str = Field(..., min_length=1, max_length=100)
    mime_type: str = Field(..., min_length=1, max_length=100)
    metadata: Dict[str, Any] = Field(default_factory=dict)
    tags: List[str] = Field(default_factory=list)
    expires_in_days: Optional[int] = Field(None, ge=1, le=365)


class ArtifactResponse(TimestampSchema):
    """Artifact response schema."""
    id: str = Field(..., alias="artifact_id")
    project_id: str
    name: str
    type: str
    mime_type: str
    size_bytes: Optional[int] = None
    checksum: Optional[str] = None
    storage_provider: str
    storage_path: str
    storage_url: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)
    tags: List[str] = Field(default_factory=list)
    expires_at: Optional[datetime] = None
    created_by: Optional[str] = None


class ArtifactListResponse(BaseSchema):
    """Artifact list response."""
    artifacts: List[ArtifactResponse]
    total: int
