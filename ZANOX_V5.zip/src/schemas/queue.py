"""Queue schemas for Nexus Core V5."""
from datetime import datetime
from typing import Optional, Dict, Any
from pydantic import BaseModel, Field

from .base import BaseSchema, Priority


class QueueItemCreate(BaseSchema):
    """Queue item creation schema."""
    queue_name: str = Field(..., min_length=1, max_length=100)
    item_type: str = Field(..., min_length=1, max_length=100)
    payload: Dict[str, Any]
    priority: Priority = Priority.NORMAL
    max_attempts: int = Field(default=3, ge=1, le=10)
    scheduled_at: Optional[datetime] = None
    expires_at: Optional[datetime] = None


class QueueItemResponse(BaseSchema):
    """Queue item response schema."""
    id: str = Field(..., alias="item_id")
    queue_name: str
    item_type: str
    payload: Dict[str, Any]
    priority: Priority
    status: str = "pending"
    attempts: int = 0
    max_attempts: int
    worker_id: Optional[str] = None
    error_message: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    scheduled_at: Optional[datetime] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    expires_at: Optional[datetime] = None


class QueueStats(BaseSchema):
    """Queue statistics schema."""
    queue_name: str
    pending: int
    processing: int
    completed: int
    failed: int
    dead_letter: int
    avg_wait_time_ms: float
    avg_processing_time_ms: float
    throughput_per_minute: float
    timestamp: datetime = Field(default_factory=datetime.utcnow)
