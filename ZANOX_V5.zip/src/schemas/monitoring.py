"""Monitoring schemas for Nexus Core V5."""
from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from enum import Enum

from .base import BaseSchema, BuilderStatus


class HealthCheckType(str, Enum):
    PING = "ping"
    API_TEST = "api_test"
    DEPLOYMENT_TEST = "deployment_test"
    CAPABILITY_TEST = "capability_test"
    FULL_DIAGNOSTIC = "full_diagnostic"


class HealthCheckResult(BaseSchema):
    builder_id: str
    check_type: HealthCheckType
    status: BuilderStatus
    latency_ms: float
    error_message: Optional[str] = None
    details: Dict[str, Any] = Field(default_factory=dict)
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class AlertSeverity(str, Enum):
    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"
    EMERGENCY = "emergency"


class Alert(BaseSchema):
    alert_id: str
    builder_id: Optional[str] = None
    severity: AlertSeverity
    title: str
    description: str
    metric_name: str
    metric_value: float
    threshold: float
    triggered_at: datetime = Field(default_factory=datetime.utcnow)
    resolved_at: Optional[datetime] = None
    acknowledged: bool = False
    acknowledged_by: Optional[str] = None
    resolution_notes: Optional[str] = None


class DashboardMetrics(BaseSchema):
    total_builders: int
    active_builders: int
    degraded_builders: int
    offline_builders: int
    total_projects: int
    total_deployments_24h: int
    total_cost_24h: float
    avg_deployment_duration_ms: float
    success_rate: float
    top_builders: List[Dict[str, Any]]
    recent_alerts: List[Alert]
    queue_depth: int
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class SystemMetrics(BaseSchema):
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    cpu_usage: float
    memory_usage: float
    disk_usage: float
    network_io: Dict[str, float]
    active_connections: int
    queue_depth: int
    request_rate: float
    error_rate: float
    latency_histogram: Dict[str, float]
