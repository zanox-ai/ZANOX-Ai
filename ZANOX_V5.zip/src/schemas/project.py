"""Project schemas for Nexus Core V5."""
from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field

from .base import BaseSchema, TimestampSchema, ProjectType, Environment, DeploymentStrategy


class ProjectCreate(BaseSchema):
    """Project creation schema."""
    name: str = Field(..., min_length=1, max_length=200)
    slug: str = Field(..., min_length=1, max_length=200)
    description: Optional[str] = None
    project_type: ProjectType
    builder_id: str
    config: Dict[str, Any] = Field(default_factory=dict)
    environment: Environment = Environment.DEVELOPMENT
    deployment_strategy: DeploymentStrategy = DeploymentStrategy.ROLLING
    metadata: Dict[str, Any] = Field(default_factory=dict)
    tags: List[str] = Field(default_factory=list)


class ProjectUpdate(BaseSchema):
    """Project update schema."""
    name: Optional[str] = Field(None, min_length=1, max_length=200)
    description: Optional[str] = None
    config: Optional[Dict[str, Any]] = None
    environment: Optional[Environment] = None
    deployment_strategy: Optional[DeploymentStrategy] = None
    status: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    tags: Optional[List[str]] = None


class ProjectResponse(TimestampSchema):
    """Project response schema."""
    id: str = Field(..., alias="project_id")
    name: str
    slug: str
    description: Optional[str] = None
    project_type: ProjectType
    builder_id: str
    builder_name: Optional[str] = None
    config: Dict[str, Any] = Field(default_factory=dict)
    environment: Environment
    deployment_strategy: DeploymentStrategy
    status: str = "draft"
    build_status: str = "pending"
    deployment_status: str = "pending"
    source_url: Optional[str] = None
    preview_url: Optional[str] = None
    production_url: Optional[str] = None
    deployment_count: int = Field(default=0, ge=0)
    last_deployment_at: Optional[datetime] = None
    last_build_at: Optional[datetime] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)
    tags: List[str] = Field(default_factory=list)
    created_by: Optional[str] = None


class ProjectListResponse(BaseSchema):
    """Project list response."""
    projects: List[ProjectResponse]
    total: int
