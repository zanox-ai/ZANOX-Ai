"""Deployment schemas for Nexus Core V5."""
from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field

from .base import BaseSchema, TimestampSchema, Environment, DeploymentStrategy


class DeploymentCreate(BaseSchema):
    """Deployment creation schema."""
    project_id: str
    builder_id: str
    version: str = Field(..., min_length=1, max_length=50)
    environment: Environment
    strategy: DeploymentStrategy = DeploymentStrategy.ROLLING
    artifact_id: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)


class DeploymentUpdate(BaseSchema):
    """Deployment update schema."""
    status: Optional[str] = None
    stage: Optional[str] = None
    artifact_id: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


class DeploymentResponse(TimestampSchema):
    """Deployment response schema."""
    id: str = Field(..., alias="deployment_id")
    project_id: str
    builder_id: str
    builder_name: Optional[str] = None
    version: str
    environment: Environment
    strategy: DeploymentStrategy
    status: str = "pending"
    stage: str = "initiated"
    artifact_id: Optional[str] = None
    artifact_url: Optional[str] = None
    duration_ms: Optional[int] = None
    cost: float = Field(default=0.0, ge=0.0)
    error_message: Optional[str] = None
    rollback_available: bool = False
    rollback_to: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    created_by: Optional[str] = None


class DeploymentListResponse(BaseSchema):
    """Deployment list response."""
    deployments: List[DeploymentResponse]
    total: int


class RollbackRequest(BaseSchema):
    """Rollback request schema."""
    deployment_id: str
    reason: Optional[str] = None
    force: bool = False


class RollbackResponse(BaseSchema):
    """Rollback response schema."""
    rollback_deployment_id: str
    target_deployment_id: str
    status: str
    message: str
    started_at: datetime = Field(default_factory=datetime.utcnow)
