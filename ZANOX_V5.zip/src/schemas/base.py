"""Base schemas for Nexus Core V5."""
from datetime import datetime
from typing import Optional, List, Dict, Any, Union
from pydantic import BaseModel, Field, ConfigDict
from enum import Enum


class BuilderStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    DEGRADED = "degraded"
    MAINTENANCE = "maintenance"
    OFFLINE = "offline"
    SUSPENDED = "suspended"


class ProjectType(str, Enum):
    WEB_APPLICATION = "web_application"
    MOBILE_APPLICATION = "mobile_application"
    MARKETPLACE_SYSTEM = "marketplace_system"
    TELEGRAM_SYSTEM = "telegram_system"
    SAAS_PLATFORM = "saas_platform"
    CRM_SYSTEM = "crm_system"
    ERP_SYSTEM = "erp_system"
    AI_APPLICATION = "ai_application"
    INTERNAL_TOOLS = "internal_tools"
    AUTOMATION_PLATFORM = "automation_platform"
    DASHBOARDS = "dashboards"
    LANDING_PAGES = "landing_pages"
    ADMIN_PANELS = "admin_panels"


class AuthType(str, Enum):
    API_KEY = "api_key"
    OAUTH2 = "oauth2"
    BASIC = "basic"
    BEARER = "bearer"
    MTLS = "mtls"


class DeploymentStrategy(str, Enum):
    ROLLING = "rolling"
    BLUE_GREEN = "blue_green"
    CANARY = "canary"
    RECREATE = "recreate"


class Environment(str, Enum):
    DEVELOPMENT = "development"
    STAGING = "staging"
    PRODUCTION = "production"


class Priority(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    NORMAL = "normal"
    LOW = "low"


class BaseSchema(BaseModel):
    """Base schema with common configuration."""
    model_config = ConfigDict(
        populate_by_name=True,
        json_schema_extra={"protected_namespaces": ()}
    )


class TimestampSchema(BaseSchema):
    """Schema with timestamp fields."""
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: Optional[datetime] = None


class PaginationParams(BaseSchema):
    """Pagination parameters."""
    page: int = Field(default=1, ge=1)
    page_size: int = Field(default=20, ge=1, le=100)
    sort_by: str = "created_at"
    sort_order: str = "desc"


class PaginatedResponse(BaseSchema):
    """Paginated response wrapper."""
    items: List[Any]
    total: int
    page: int
    page_size: int
    total_pages: int
    has_next: bool
    has_prev: bool
