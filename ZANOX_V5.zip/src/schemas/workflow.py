"""Workflow schemas for Nexus Core V5."""
from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field

from .base import BaseSchema, TimestampSchema


class WorkflowStep(BaseModel):
    """Workflow step definition."""
    id: str
    name: str
    description: Optional[str] = None
    step_type: str
    builder_id: Optional[str] = None
    action: str
    parameters: Dict[str, Any] = Field(default_factory=dict)
    conditions: Dict[str, Any] = Field(default_factory=dict)
    retry_count: int = Field(default=3, ge=0)
    timeout_seconds: int = Field(default=300, ge=1)
    depends_on: List[str] = Field(default_factory=list)


class WorkflowTrigger(BaseModel):
    """Workflow trigger definition."""
    trigger_type: str
    event: str
    conditions: Dict[str, Any] = Field(default_factory=dict)
    schedule: Optional[str] = None


class WorkflowCreate(BaseSchema):
    """Workflow creation schema."""
    name: str = Field(..., min_length=1, max_length=200)
    description: Optional[str] = None
    workflow_type: str = Field(..., min_length=1, max_length=100)
    steps: List[WorkflowStep]
    triggers: List[WorkflowTrigger] = Field(default_factory=list)
    conditions: Dict[str, Any] = Field(default_factory=dict)
    is_template: bool = False
    metadata: Dict[str, Any] = Field(default_factory=dict)
    tags: List[str] = Field(default_factory=list)


class WorkflowUpdate(BaseSchema):
    """Workflow update schema."""
    name: Optional[str] = Field(None, min_length=1, max_length=200)
    description: Optional[str] = None
    steps: Optional[List[WorkflowStep]] = None
    triggers: Optional[List[WorkflowTrigger]] = None
    conditions: Optional[Dict[str, Any]] = None
    status: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    tags: Optional[List[str]] = None


class WorkflowResponse(TimestampSchema):
    """Workflow response schema."""
    id: str = Field(..., alias="workflow_id")
    name: str
    description: Optional[str] = None
    workflow_type: str
    steps: List[WorkflowStep]
    triggers: List[WorkflowTrigger]
    conditions: Dict[str, Any] = Field(default_factory=dict)
    status: str = "active"
    is_template: bool = False
    metadata: Dict[str, Any] = Field(default_factory=dict)
    tags: List[str] = Field(default_factory=list)
    created_by: Optional[str] = None


class WorkflowExecutionCreate(BaseSchema):
    """Workflow execution creation schema."""
    workflow_id: str
    project_id: Optional[str] = None
    input_data: Dict[str, Any] = Field(default_factory=dict)
    priority: str = "normal"


class WorkflowExecutionResponse(TimestampSchema):
    """Workflow execution response schema."""
    id: str = Field(..., alias="execution_id")
    workflow_id: str
    project_id: Optional[str] = None
    status: str = "pending"
    current_step: int = 0
    total_steps: int = 0
    results: Dict[str, Any] = Field(default_factory=dict)
    error_message: Optional[str] = None
    duration_ms: Optional[int] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    created_by: Optional[str] = None


class WorkflowListResponse(BaseSchema):
    """Workflow list response."""
    workflows: List[WorkflowResponse]
    total: int
