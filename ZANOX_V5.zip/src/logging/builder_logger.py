"""Builder Logging System for Nexus Core V5.

Structured logging for all builder operations.
"""
import json
import logging
import sys
from datetime import datetime
from typing import Dict, Any, Optional
from pythonjsonlogger import jsonlogger


class BuilderLogger:
    """Structured logger for builder operations."""

    def __init__(self, name: str = "nexus_core_v5"):
        self.logger = logging.getLogger(name)
        self.logger.setLevel(logging.INFO)

        # JSON formatter
        formatter = jsonlogger.JsonFormatter(
            "%(asctime)s %(name)s %(levelname)s %(message)s %(builder_id)s %(project_id)s %(operation)s %(duration_ms)s %(status)s"
        )

        # Console handler
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(formatter)
        self.logger.addHandler(console_handler)

    def log_operation(
        self,
        operation: str,
        builder_id: Optional[str] = None,
        project_id: Optional[str] = None,
        deployment_id: Optional[str] = None,
        status: str = "success",
        duration_ms: Optional[float] = None,
        metadata: Optional[Dict[str, Any]] = None,
        level: str = "info",
    ):
        """Log a builder operation."""
        extra = {
            "builder_id": builder_id or "",
            "project_id": project_id or "",
            "deployment_id": deployment_id or "",
            "operation": operation,
            "status": status,
            "duration_ms": duration_ms or 0,
            "metadata": metadata or {},
        }

        if level == "error":
            self.logger.error(f"Operation {operation} {status}", extra=extra)
        elif level == "warning":
            self.logger.warning(f"Operation {operation} {status}", extra=extra)
        elif level == "debug":
            self.logger.debug(f"Operation {operation} {status}", extra=extra)
        else:
            self.logger.info(f"Operation {operation} {status}", extra=extra)

    def log_deployment(
        self,
        deployment_id: str,
        builder_id: str,
        project_id: str,
        version: str,
        status: str,
        duration_ms: Optional[float] = None,
        error: Optional[str] = None,
    ):
        """Log deployment event."""
        extra = {
            "deployment_id": deployment_id,
            "builder_id": builder_id,
            "project_id": project_id,
            "version": version,
            "operation": "deployment",
            "status": status,
            "duration_ms": duration_ms or 0,
            "error": error or "",
        }

        if error:
            self.logger.error(f"Deployment {deployment_id} failed: {error}", extra=extra)
        else:
            self.logger.info(f"Deployment {deployment_id} {status}", extra=extra)

    def log_health_check(
        self,
        builder_id: str,
        status: str,
        latency_ms: float,
        error: Optional[str] = None,
    ):
        """Log health check event."""
        extra = {
            "builder_id": builder_id,
            "operation": "health_check",
            "status": status,
            "duration_ms": latency_ms,
            "error": error or "",
        }

        if error:
            self.logger.warning(f"Health check failed for {builder_id}: {error}", extra=extra)
        else:
            self.logger.info(f"Health check {builder_id} {status} ({latency_ms}ms)", extra=extra)

    def log_cost(
        self,
        builder_id: str,
        project_id: str,
        operation: str,
        cost: float,
        currency: str = "USD",
    ):
        """Log cost event."""
        extra = {
            "builder_id": builder_id,
            "project_id": project_id,
            "operation": operation,
            "cost": cost,
            "currency": currency,
        }

        self.logger.info(f"Cost {cost} {currency} for {operation}", extra=extra)
