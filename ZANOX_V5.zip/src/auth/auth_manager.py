"""Builder Authentication Layer for Nexus Core V5.

Handles authentication for all external builders.
"""
import asyncio
import base64
import hashlib
import hmac
import time
from datetime import datetime, timedelta
from typing import Dict, Optional, Any
import aiohttp
import jwt

from ..schemas.builder import BuilderAuth, AuthType


class AuthManager:
    """Manages authentication for all builders."""

    def __init__(self, vault_client=None):
        self.vault = vault_client
        self._token_cache: Dict[str, Dict[str, Any]] = {}
        self._cache_lock = asyncio.Lock()

    async def authenticate(self, builder_id: str, auth_config: BuilderAuth) -> Dict[str, str]:
        """Authenticate with a builder and return headers."""
        if auth_config.auth_type == AuthType.API_KEY:
            return await self._api_key_auth(builder_id, auth_config)
        elif auth_config.auth_type == AuthType.OAUTH2:
            return await self._oauth2_auth(builder_id, auth_config)
        elif auth_config.auth_type == AuthType.BASIC:
            return await self._basic_auth(builder_id, auth_config)
        elif auth_config.auth_type == AuthType.BEARER:
            return await self._bearer_auth(builder_id, auth_config)
        elif auth_config.auth_type == AuthType.MTLS:
            return await self._mtls_auth(builder_id, auth_config)
        else:
            raise ValueError(f"Unsupported auth type: {auth_config.auth_type}")

    async def _api_key_auth(self, builder_id: str, auth_config: BuilderAuth) -> Dict[str, str]:
        """API Key authentication."""
        api_key = auth_config.api_key or await self._get_secret(builder_id, "api_key")
        return {
            "Authorization": f"Bearer {api_key}",
            "X-API-Key": api_key,
        }

    async def _oauth2_auth(self, builder_id: str, auth_config: BuilderAuth) -> Dict[str, str]:
        """OAuth2 authentication with token refresh."""
        async with self._cache_lock:
            cached = self._token_cache.get(builder_id)
            if cached and cached["expires_at"] > datetime.utcnow() + timedelta(minutes=5):
                return {"Authorization": f"Bearer {cached['access_token']}"}

        client_id = auth_config.client_id or await self._get_secret(builder_id, "client_id")
        client_secret = auth_config.client_secret or await self._get_secret(builder_id, "client_secret")

        token_data = await self._refresh_oauth2_token(
            builder_id, client_id, client_secret, auth_config.scopes
        )

        async with self._cache_lock:
            self._token_cache[builder_id] = {
                "access_token": token_data["access_token"],
                "refresh_token": token_data.get("refresh_token"),
                "expires_at": datetime.utcnow() + timedelta(seconds=token_data.get("expires_in", 3600)),
            }

        return {"Authorization": f"Bearer {token_data['access_token']}"}

    async def _basic_auth(self, builder_id: str, auth_config: BuilderAuth) -> Dict[str, str]:
        """Basic authentication."""
        username = auth_config.client_id or await self._get_secret(builder_id, "username")
        password = auth_config.client_secret or await self._get_secret(builder_id, "password")
        credentials = base64.b64encode(f"{username}:{password}".encode()).decode()
        return {"Authorization": f"Basic {credentials}"}

    async def _bearer_auth(self, builder_id: str, auth_config: BuilderAuth) -> Dict[str, str]:
        """Bearer token authentication."""
        token = auth_config.access_token or await self._get_secret(builder_id, "bearer_token")
        return {"Authorization": f"Bearer {token}"}

    async def _mtls_auth(self, builder_id: str, auth_config: BuilderAuth) -> Dict[str, str]:
        """mTLS authentication."""
        return {
            "X-Client-Cert": "mtls",
        }

    async def _refresh_oauth2_token(
        self,
        builder_id: str,
        client_id: str,
        client_secret: str,
        scopes: list,
    ) -> Dict[str, Any]:
        """Refresh OAuth2 token."""
        # Implementation would call the builder's token endpoint
        # This is a placeholder for the actual implementation
        return {
            "access_token": "refreshed_token",
            "refresh_token": "refresh_token",
            "expires_in": 3600,
            "token_type": "Bearer",
        }

    async def _get_secret(self, builder_id: str, key: str) -> str:
        """Get secret from Vault or environment."""
        if self.vault:
            return await self.vault.get_secret(f"builders/{builder_id}/{key}")
        # Fallback to environment variable
        import os
        env_var = f"{builder_id.upper()}_{key.upper()}"
        return os.environ.get(env_var, "")

    def generate_request_signature(
        self,
        method: str,
        path: str,
        body: str,
        timestamp: str,
        secret: str,
    ) -> str:
        """Generate HMAC signature for request."""
        message = f"{method}:{path}:{body}:{timestamp}"
        signature = hmac.new(
            secret.encode(),
            message.encode(),
            hashlib.sha256,
        ).hexdigest()
        return signature

    def verify_webhook_signature(
        self,
        payload: bytes,
        signature: str,
        secret: str,
    ) -> bool:
        """Verify webhook signature."""
        expected = hmac.new(
            secret.encode(),
            payload,
            hashlib.sha256,
        ).hexdigest()
        return hmac.compare_digest(expected, signature)
