"""Builder Deployment Coordinator for Nexus Core V5.

Manages deployments to external builders.
"""
import uuid
import asyncio
from datetime import datetime
from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session

from ..schemas.deployment import (
    DeploymentCreate, DeploymentUpdate, DeploymentResponse,
    RollbackRequest, RollbackResponse, Environment, DeploymentStrategy
)
from ..schemas.builder import BuilderResponse
from database.models import DeploymentModel as DeploymentDB, ProjectModel, BuilderModel


class DeploymentCoordinator:
    """Coordinates deployments to builders."""

    def __init__(self, db_session: Session, connector_factory):
        self.db = db_session
        self.connectors = connector_factory

    async def create_deployment(self, deployment_data: DeploymentCreate) -> DeploymentResponse:
        """Create a new deployment."""
        deployment_id = str(uuid.uuid4())

        deployment = DeploymentDB(
            id=deployment_id,
            project_id=deployment_data.project_id,
            builder_id=deployment_data.builder_id,
            version=deployment_data.version,
            environment=deployment_data.environment.value,
            strategy=deployment_data.strategy.value,
            artifact_id=deployment_data.artifact_id,
            status="pending",
            stage="initiated",
            metadata=deployment_data.metadata,
            created_at=datetime.utcnow(),
        )

        self.db.add(deployment)
        self.db.commit()
        self.db.refresh(deployment)

        # Start deployment asynchronously
        asyncio.create_task(self._execute_deployment(deployment_id))

        return self._to_response(deployment)

    async def _execute_deployment(self, deployment_id: str):
        """Execute deployment stages."""
        deployment = self.db.query(DeploymentDB).filter(DeploymentDB.id == deployment_id).first()
        if not deployment:
            return

        try:
            deployment.status = "in_progress"
            deployment.started_at = datetime.utcnow()
            deployment.stage = "preparing"
            self.db.commit()

            # Get builder and project
            builder = self.db.query(BuilderModel).filter(BuilderModel.id == deployment.builder_id).first()
            project = self.db.query(ProjectModel).filter(ProjectModel.id == deployment.project_id).first()

            if not builder or not project:
                raise ValueError("Builder or project not found")

            # Execute based on strategy
            if deployment.strategy == DeploymentStrategy.ROLLING.value:
                await self._rolling_deployment(deployment, builder, project)
            elif deployment.strategy == DeploymentStrategy.BLUE_GREEN.value:
                await self._blue_green_deployment(deployment, builder, project)
            elif deployment.strategy == DeploymentStrategy.CANARY.value:
                await self._canary_deployment(deployment, builder, project)
            else:
                await self._standard_deployment(deployment, builder, project)

            deployment.status = "completed"
            deployment.stage = "finished"
            deployment.completed_at = datetime.utcnow()

            # Update project
            project.deployment_count += 1
            project.last_deployment_at = datetime.utcnow()
            project.deployment_status = "deployed"

            # Update builder
            builder.total_deployments += 1
            builder.last_deployment = datetime.utcnow()

        except Exception as e:
            deployment.status = "failed"
            deployment.stage = "error"
            deployment.error_message = str(e)

            # Check if rollback is available
            prev_deployment = self.db.query(DeploymentDB).filter(
                DeploymentDB.project_id == deployment.project_id,
                DeploymentDB.status == "completed",
            ).order_by(DeploymentDB.completed_at.desc()).first()

            if prev_deployment:
                deployment.rollback_available = True
                deployment.rollback_to = prev_deployment.id

        finally:
            deployment.completed_at = datetime.utcnow()
            self.db.commit()

    async def _standard_deployment(self, deployment, builder, project):
        """Standard deployment."""
        deployment.stage = "deploying"
        self.db.commit()

        # Simulate deployment (in production, call builder API)
        await asyncio.sleep(2)

        deployment.stage = "verifying"
        self.db.commit()

        await asyncio.sleep(1)

    async def _rolling_deployment(self, deployment, builder, project):
        """Rolling deployment."""
        deployment.stage = "rolling_update"
        self.db.commit()

        await asyncio.sleep(3)

        deployment.stage = "verifying"
        self.db.commit()

        await asyncio.sleep(1)

    async def _blue_green_deployment(self, deployment, builder, project):
        """Blue-green deployment."""
        deployment.stage = "deploying_green"
        self.db.commit()

        await asyncio.sleep(2)

        deployment.stage = "switching_traffic"
        self.db.commit()

        await asyncio.sleep(1)

        deployment.stage = "verifying"
        self.db.commit()

        await asyncio.sleep(1)

    async def _canary_deployment(self, deployment, builder, project):
        """Canary deployment."""
        deployment.stage = "deploying_canary"
        self.db.commit()

        await asyncio.sleep(2)

        deployment.stage = "monitoring_canary"
        self.db.commit()

        await asyncio.sleep(2)

        deployment.stage = "promoting_canary"
        self.db.commit()

        await asyncio.sleep(1)

    async def rollback_deployment(self, rollback_data: RollbackRequest) -> RollbackResponse:
        """Rollback a deployment."""
        deployment = self.db.query(DeploymentDB).filter(
            DeploymentDB.id == rollback_data.deployment_id
        ).first()

        if not deployment:
            raise ValueError("Deployment not found")

        if not deployment.rollback_available or not deployment.rollback_to:
            raise ValueError("Rollback not available for this deployment")

        # Create rollback deployment
        rollback_id = str(uuid.uuid4())
        rollback_deployment = DeploymentDB(
            id=rollback_id,
            project_id=deployment.project_id,
            builder_id=deployment.builder_id,
            version=f"rollback-{deployment.version}",
            environment=deployment.environment,
            strategy=DeploymentStrategy.RECREATE.value,
            status="in_progress",
            stage="rollback",
            rollback_to=deployment.rollback_to,
            started_at=datetime.utcnow(),
        )

        self.db.add(rollback_deployment)
        self.db.commit()

        # Execute rollback
        asyncio.create_task(self._execute_rollback(rollback_id, deployment.rollback_to))

        return RollbackResponse(
            rollback_deployment_id=rollback_id,
            target_deployment_id=deployment.rollback_to,
            status="in_progress",
            message=f"Rolling back to deployment {deployment.rollback_to}",
        )

    async def _execute_rollback(self, rollback_id: str, target_id: str):
        """Execute rollback."""
        rollback = self.db.query(DeploymentDB).filter(DeploymentDB.id == rollback_id).first()
        if not rollback:
            return

        try:
            await asyncio.sleep(2)
            rollback.status = "completed"
            rollback.stage = "rollback_complete"
            rollback.completed_at = datetime.utcnow()
        except Exception as e:
            rollback.status = "failed"
            rollback.error_message = str(e)
        finally:
            self.db.commit()

    def get_deployment(self, deployment_id: str) -> Optional[DeploymentResponse]:
        """Get deployment by ID."""
        deployment = self.db.query(DeploymentDB).filter(DeploymentDB.id == deployment_id).first()
        if not deployment:
            return None
        return self._to_response(deployment)

    def list_deployments(
        self,
        project_id: Optional[str] = None,
        builder_id: Optional[str] = None,
        status: Optional[str] = None,
        skip: int = 0,
        limit: int = 100,
    ) -> List[DeploymentResponse]:
        """List deployments."""
        query = self.db.query(DeploymentDB)

        if project_id:
            query = query.filter(DeploymentDB.project_id == project_id)
        if builder_id:
            query = query.filter(DeploymentDB.builder_id == builder_id)
        if status:
            query = query.filter(DeploymentDB.status == status)

        deployments = query.order_by(DeploymentDB.created_at.desc()).offset(skip).limit(limit).all()
        return [self._to_response(d) for d in deployments]

    def _to_response(self, deployment: DeploymentDB) -> DeploymentResponse:
        """Convert DB model to response."""
        builder = self.db.query(BuilderModel).filter(BuilderModel.id == deployment.builder_id).first()
        builder_name = builder.name if builder else None

        return DeploymentResponse(
            deployment_id=deployment.id,
            project_id=deployment.project_id,
            builder_id=deployment.builder_id,
            builder_name=builder_name,
            version=deployment.version,
            environment=Environment(deployment.environment),
            strategy=DeploymentStrategy(deployment.strategy),
            status=deployment.status,
            stage=deployment.stage,
            artifact_id=deployment.artifact_id,
            artifact_url=deployment.artifact_url,
            duration_ms=deployment.duration_ms,
            cost=deployment.cost,
            error_message=deployment.error_message,
            rollback_available=deployment.rollback_available,
            rollback_to=deployment.rollback_to,
            metadata=deployment.metadata,
            started_at=deployment.started_at,
            completed_at=deployment.completed_at,
            created_at=deployment.created_at,
            created_by=deployment.created_by,
        )
