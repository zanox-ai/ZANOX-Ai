"""SQLAlchemy database models for Nexus Core V5."""
from datetime import datetime
from sqlalchemy import (
    Column, String, DateTime, Boolean, Float, Integer, 
    JSON, Text, ForeignKey, Enum, Index, BigInteger, ARRAY
)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
import enum

Base = declarative_base()


class BuilderStatus(str, enum.Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    DEGRADED = "degraded"
    MAINTENANCE = "maintenance"
    OFFLINE = "offline"
    SUSPENDED = "suspended"


class ProjectType(str, enum.Enum):
    WEB_APPLICATION = "web_application"
    MOBILE_APPLICATION = "mobile_application"
    MARKETPLACE_SYSTEM = "marketplace_system"
    TELEGRAM_SYSTEM = "telegram_system"
    SAAS_PLATFORM = "saas_platform"
    CRM_SYSTEM = "crm_system"
    ERP_SYSTEM = "erp_system"
    AI_APPLICATION = "ai_application"
    INTERNAL_TOOLS = "internal_tools"
    AUTOMATION_PLATFORM = "automation_platform"
    DASHBOARDS = "dashboards"
    LANDING_PAGES = "landing_pages"
    ADMIN_PANELS = "admin_panels"


class AuthType(str, enum.Enum):
    API_KEY = "api_key"
    OAUTH2 = "oauth2"
    BASIC = "basic"
    BEARER = "bearer"
    MTLS = "mtls"


class DeploymentStrategy(str, enum.Enum):
    ROLLING = "rolling"
    BLUE_GREEN = "blue_green"
    CANARY = "canary"
    RECREATE = "recreate"


class Environment(str, enum.Enum):
    DEVELOPMENT = "development"
    STAGING = "staging"
    PRODUCTION = "production"


class Priority(str, enum.Enum):
    CRITICAL = "critical"
    HIGH = "high"
    NORMAL = "normal"
    LOW = "low"


class BuilderModel(Base):
    """Builder registry model."""
    __tablename__ = "builders"

    id = Column(String(36), primary_key=True)
    name = Column(String(100), nullable=False)
    provider = Column(String(50), nullable=False)
    slug = Column(String(50), nullable=False, unique=True)
    description = Column(Text)
    api_base_url = Column(String(500), nullable=False)
    auth_type = Column(Enum(AuthType), nullable=False)
    auth_config = Column(JSON, default=dict)
    supported_project_types = Column(ARRAY(String), default=list)
    capabilities = Column(ARRAY(String), default=list)
    deployment_regions = Column(ARRAY(String), default=list)

    # Cost structure
    cost_per_hour = Column(Float, default=0.0)
    cost_per_deployment = Column(Float, default=0.0)
    cost_per_request = Column(Float, default=0.0)

    # Limits
    max_projects = Column(Integer, default=100)
    max_team_size = Column(Integer, default=50)

    # Configuration
    timeout = Column(Integer, default=60)
    retry_attempts = Column(Integer, default=3)
    rate_limit_per_minute = Column(Integer, default=100)
    health_check_endpoint = Column(String(200))

    # Status
    status = Column(Enum(BuilderStatus), default=BuilderStatus.ACTIVE)
    health_score = Column(Float, default=1.0)
    rank_score = Column(Float, default=0.0)
    is_available = Column(Boolean, default=True)

    # Metrics
    total_projects = Column(Integer, default=0)
    total_deployments = Column(Integer, default=0)
    total_requests = Column(BigInteger, default=0)
    total_cost = Column(Float, default=0.0)
    avg_latency_ms = Column(Float, default=0.0)
    error_rate = Column(Float, default=0.0)
    success_rate = Column(Float, default=1.0)

    # Metadata
    metadata = Column(JSON, default=dict)
    tags = Column(ARRAY(String), default=list)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, onupdate=datetime.utcnow)
    last_health_check = Column(DateTime)
    last_deployment = Column(DateTime)

    # Relationships
    projects = relationship("ProjectModel", back_populates="builder")
    health_checks = relationship("BuilderHealthCheck", back_populates="builder", cascade="all, delete-orphan")
    cost_history = relationship("BuilderCostHistory", back_populates="builder", cascade="all, delete-orphan")
    deployments = relationship("DeploymentModel", back_populates="builder")

    __table_args__ = (
        Index("idx_builder_status", "status"),
        Index("idx_builder_provider", "provider"),
        Index("idx_builder_rank", "rank_score"),
        Index("idx_builder_slug", "slug"),
    )


class ProjectModel(Base):
    """Project model."""
    __tablename__ = "projects"

    id = Column(String(36), primary_key=True)
    name = Column(String(200), nullable=False)
    slug = Column(String(200), nullable=False, unique=True)
    description = Column(Text)
    project_type = Column(Enum(ProjectType), nullable=False)
    builder_id = Column(String(36), ForeignKey("builders.id"), nullable=False)

    # Configuration
    config = Column(JSON, default=dict)
    environment = Column(Enum(Environment), default=Environment.DEVELOPMENT)
    deployment_strategy = Column(Enum(DeploymentStrategy), default=DeploymentStrategy.ROLLING)

    # Status
    status = Column(String(50), default="draft")
    build_status = Column(String(50), default="pending")
    deployment_status = Column(String(50), default="pending")

    # URLs
    source_url = Column(String(500))
    preview_url = Column(String(500))
    production_url = Column(String(500))

    # Metrics
    deployment_count = Column(Integer, default=0)
    last_deployment_at = Column(DateTime)
    last_build_at = Column(DateTime)

    # Metadata
    metadata = Column(JSON, default=dict)
    tags = Column(ARRAY(String), default=list)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, onupdate=datetime.utcnow)
    created_by = Column(String(36))

    builder = relationship("BuilderModel", back_populates="projects")
    deployments = relationship("DeploymentModel", back_populates="project")
    artifacts = relationship("ArtifactModel", back_populates="project")

    __table_args__ = (
        Index("idx_project_type", "project_type"),
        Index("idx_project_status", "status"),
        Index("idx_project_builder", "builder_id"),
    )


class DeploymentModel(Base):
    """Deployment model."""
    __tablename__ = "deployments"

    id = Column(String(36), primary_key=True)
    project_id = Column(String(36), ForeignKey("projects.id"), nullable=False)
    builder_id = Column(String(36), ForeignKey("builders.id"), nullable=False)

    # Deployment info
    version = Column(String(50), nullable=False)
    environment = Column(Enum(Environment), nullable=False)
    strategy = Column(Enum(DeploymentStrategy), nullable=False)

    # Status
    status = Column(String(50), default="pending")
    stage = Column(String(50), default="initiated")

    # Artifacts
    artifact_id = Column(String(36), ForeignKey("artifacts.id"))
    artifact_url = Column(String(500))

    # Metrics
    duration_ms = Column(BigInteger)
    cost = Column(Float, default=0.0)

    # Error handling
    error_message = Column(Text)
    rollback_available = Column(Boolean, default=False)
    rollback_to = Column(String(36), ForeignKey("deployments.id"))

    # Metadata
    metadata = Column(JSON, default=dict)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    started_at = Column(DateTime)
    completed_at = Column(DateTime)
    created_by = Column(String(36))

    project = relationship("ProjectModel", back_populates="deployments")
    builder = relationship("BuilderModel", back_populates="deployments")
    artifact = relationship("ArtifactModel", back_populates="deployments")

    __table_args__ = (
        Index("idx_deployment_project", "project_id"),
        Index("idx_deployment_status", "status"),
        Index("idx_deployment_created", "created_at"),
    )


class ArtifactModel(Base):
    """Artifact model."""
    __tablename__ = "artifacts"

    id = Column(String(36), primary_key=True)
    project_id = Column(String(36), ForeignKey("projects.id"), nullable=False)

    # Artifact info
    name = Column(String(200), nullable=False)
    type = Column(String(100), nullable=False)
    mime_type = Column(String(100))
    size_bytes = Column(BigInteger)
    checksum = Column(String(128))

    # Storage
    storage_provider = Column(String(50), default="minio")
    storage_path = Column(String(500))
    storage_url = Column(String(500))

    # Metadata
    metadata = Column(JSON, default=dict)
    tags = Column(ARRAY(String), default=list)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime)
    created_by = Column(String(36))

    project = relationship("ProjectModel", back_populates="artifacts")
    deployments = relationship("DeploymentModel", back_populates="artifact")

    __table_args__ = (
        Index("idx_artifact_project", "project_id"),
        Index("idx_artifact_type", "type"),
    )


class BuilderHealthCheck(Base):
    """Builder health check history."""
    __tablename__ = "builder_health_checks"

    id = Column(String(36), primary_key=True)
    builder_id = Column(String(36), ForeignKey("builders.id"), nullable=False)
    check_type = Column(String(50), nullable=False)
    status = Column(Enum(BuilderStatus), nullable=False)
    latency_ms = Column(Float, default=0.0)
    error_message = Column(Text)
    details = Column(JSON, default=dict)
    timestamp = Column(DateTime, default=datetime.utcnow)

    builder = relationship("BuilderModel", back_populates="health_checks")

    __table_args__ = (
        Index("idx_health_builder", "builder_id"),
        Index("idx_health_timestamp", "timestamp"),
    )


class BuilderCostHistory(Base):
    """Builder cost history."""
    __tablename__ = "builder_cost_history"

    id = Column(String(36), primary_key=True)
    builder_id = Column(String(36), ForeignKey("builders.id"), nullable=False)
    project_id = Column(String(36), ForeignKey("projects.id"))
    deployment_id = Column(String(36), ForeignKey("deployments.id"))

    # Cost breakdown
    compute_cost = Column(Float, default=0.0)
    storage_cost = Column(Float, default=0.0)
    network_cost = Column(Float, default=0.0)
    request_cost = Column(Float, default=0.0)
    total_cost = Column(Float, default=0.0)
    currency = Column(String(3), default="USD")

    # Usage metrics
    requests_count = Column(Integer, default=0)
    duration_seconds = Column(Float, default=0.0)
    storage_bytes = Column(BigInteger, default=0)

    # Metadata
    metadata = Column(JSON, default=dict)
    timestamp = Column(DateTime, default=datetime.utcnow)

    builder = relationship("BuilderModel", back_populates="cost_history")

    __table_args__ = (
        Index("idx_cost_builder", "builder_id"),
        Index("idx_cost_project", "project_id"),
        Index("idx_cost_timestamp", "timestamp"),
    )


class BuilderRankingHistory(Base):
    """Builder ranking history."""
    __tablename__ = "builder_ranking_history"

    id = Column(String(36), primary_key=True)
    builder_id = Column(String(36), nullable=False)
    rank = Column(Integer, nullable=False)
    overall_score = Column(Float, default=0.0)
    performance_score = Column(Float, default=0.0)
    reliability_score = Column(Float, default=0.0)
    cost_efficiency_score = Column(Float, default=0.0)
    user_feedback_score = Column(Float, default=0.0)
    capability_match_score = Column(Float, default=0.0)
    trend = Column(String(20), default="stable")
    change_from_last = Column(Integer, default=0)
    calculated_at = Column(DateTime, default=datetime.utcnow)

    __table_args__ = (
        Index("idx_ranking_builder", "builder_id"),
        Index("idx_ranking_calculated", "calculated_at"),
    )


class WorkflowModel(Base):
    """Workflow model."""
    __tablename__ = "workflows"

    id = Column(String(36), primary_key=True)
    name = Column(String(200), nullable=False)
    description = Column(Text)
    workflow_type = Column(String(100), nullable=False)

    # Configuration
    steps = Column(JSON, default=list)
    triggers = Column(JSON, default=list)
    conditions = Column(JSON, default=dict)

    # Status
    status = Column(String(50), default="active")
    is_template = Column(Boolean, default=False)

    # Metadata
    metadata = Column(JSON, default=dict)
    tags = Column(ARRAY(String), default=list)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, onupdate=datetime.utcnow)
    created_by = Column(String(36))

    __table_args__ = (
        Index("idx_workflow_type", "workflow_type"),
        Index("idx_workflow_status", "status"),
    )


class WorkflowExecutionModel(Base):
    """Workflow execution model."""
    __tablename__ = "workflow_executions"

    id = Column(String(36), primary_key=True)
    workflow_id = Column(String(36), ForeignKey("workflows.id"), nullable=False)
    project_id = Column(String(36), ForeignKey("projects.id"))

    # Execution info
    status = Column(String(50), default="pending")
    current_step = Column(Integer, default=0)
    total_steps = Column(Integer, default=0)

    # Results
    results = Column(JSON, default=dict)
    error_message = Column(Text)

    # Metrics
    duration_ms = Column(BigInteger)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    started_at = Column(DateTime)
    completed_at = Column(DateTime)
    created_by = Column(String(36))

    __table_args__ = (
        Index("idx_execution_workflow", "workflow_id"),
        Index("idx_execution_status", "status"),
    )


class QueueItemModel(Base):
    """Queue item model."""
    __tablename__ = "queue_items"

    id = Column(String(36), primary_key=True)
    queue_name = Column(String(100), nullable=False)
    item_type = Column(String(100), nullable=False)
    payload = Column(JSON, nullable=False)
    priority = Column(Enum(Priority), default=Priority.NORMAL)

    # Status
    status = Column(String(50), default="pending")
    attempts = Column(Integer, default=0)
    max_attempts = Column(Integer, default=3)

    # Processing
    worker_id = Column(String(36))
    started_at = Column(DateTime)
    completed_at = Column(DateTime)
    error_message = Column(Text)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    scheduled_at = Column(DateTime)
    expires_at = Column(DateTime)

    __table_args__ = (
        Index("idx_queue_name", "queue_name"),
        Index("idx_queue_status", "status"),
        Index("idx_queue_priority", "priority"),
    )


class AuditLogModel(Base):
    """Audit log model."""
    __tablename__ = "audit_logs"

    id = Column(String(36), primary_key=True)
    user_id = Column(String(36))
    action = Column(String(100), nullable=False)
    resource_type = Column(String(100), nullable=False)
    resource_id = Column(String(36))

    # Details
    request_data = Column(JSON)
    response_data = Column(JSON)
    ip_address = Column(String(45))
    user_agent = Column(String(500))

    # Result
    success = Column(Boolean, default=True)
    error_message = Column(Text)

    # Timestamps
    timestamp = Column(DateTime, default=datetime.utcnow)

    __table_args__ = (
        Index("idx_audit_user", "user_id"),
        Index("idx_audit_resource", "resource_type", "resource_id"),
        Index("idx_audit_timestamp", "timestamp"),
    )


class GovernancePolicyModel(Base):
    """Governance policy model."""
    __tablename__ = "governance_policies"

    id = Column(String(36), primary_key=True)
    name = Column(String(200), nullable=False)
    description = Column(Text)
    policy_type = Column(String(100), nullable=False)

    # Rules
    rules = Column(JSON, default=list)
    conditions = Column(JSON, default=dict)
    actions = Column(JSON, default=list)

    # Status
    status = Column(String(50), default="active")
    priority = Column(Integer, default=1)

    # Metadata
    metadata = Column(JSON, default=dict)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, onupdate=datetime.utcnow)
    created_by = Column(String(36))

    __table_args__ = (
        Index("idx_policy_type", "policy_type"),
        Index("idx_policy_status", "status"),
    )
