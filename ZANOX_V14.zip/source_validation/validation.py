"""
ZANOX V14 - Source Validation Engine
Validates source credibility and reliability
"""

import logging
from typing import Dict, List, Any
from shared.models import Source, SourceReliability
from shared.utils import ZANOXUtils
from shared.config import ZANOXConfig
from shared.database import DatabaseManager

logger = logging.getLogger('zanox.source_validation')

class SourceValidationEngine:
    def __init__(self):
        self.trusted_domains = ZANOXConfig.TRUSTED_DOMAINS
        self.blocked_domains = ZANOXConfig.BLOCKED_DOMAINS
    
    async def validate(self, source: Source) -> Source:
        domain = ZANOXUtils.extract_domain(source.url or '')
        if any(domain.endswith(bd) for bd in self.blocked_domains):
            source.reliability = SourceReliability.LOW
            source.credibility_score = 0.0
            return source
        has_author = bool(source.author)
        has_date = bool(source.publish_date)
        content_length = len(source.content or '')
        score = ZANOXUtils.calculate_reliability_score(domain, content_length, has_author, has_date)
        source.credibility_score = score
        if score >= 0.8: source.reliability = SourceReliability.HIGH
        elif score >= 0.5: source.reliability = SourceReliability.MEDIUM
        else: source.reliability = SourceReliability.LOW
        return source
    async def validate_batch(self, research_id: str, config: Dict) -> List[Source]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            rows = await conn.fetch('SELECT * FROM sources WHERE reliability = $1', 'unverified')
            sources = [Source(**dict(row)) for row in rows]
            validated = []
            for src in sources:
                validated.append(await self.validate(src))
                await conn.execute('UPDATE sources SET reliability = $1, credibility_score = $2 WHERE id = $3', src.reliability.value, src.credibility_score, src.id)
            return validated