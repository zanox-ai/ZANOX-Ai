"""
ZANOX V14 - Research Engine
Core research execution and management
"""

import logging
from typing import Dict, List, Optional, Any
from datetime import datetime

from shared.models import ResearchObjective, ResearchPlan, ResearchStatus, Source, Fact
from shared.database import DatabaseManager
from shared.utils import ZANOXUtils

from source_discovery.discovery import SourceDiscoveryEngine
from source_validation.validation import SourceValidationEngine
from fact_verification.verification import FactVerificationEngine
from data_collection.collector import DataCollectionEngine
from data_extraction.extractor import DataExtractionEngine
from data_normalization.normalizer import DataNormalizationEngine
from data_enrichment.enrichment import DataEnrichmentEngine
from data_quality.quality import DataQualityEngine
from knowledge_synthesis.synthesis import KnowledgeSynthesisEngine
from insight_generation.insights import InsightGenerationEngine
from hypothesis_engine.hypothesis import HypothesisEngine
from recommendations.recommendations import RecommendationEngine

logger = logging.getLogger('zanox.research_engine')

class ResearchEngine:
    def __init__(self):
        self.discovery = SourceDiscoveryEngine()
        self.validation = SourceValidationEngine()
        self.verification = FactVerificationEngine()
        self.collector = DataCollectionEngine()
        self.extractor = DataExtractionEngine()
        self.normalizer = DataNormalizationEngine()
        self.enrichment = DataEnrichmentEngine()
        self.quality = DataQualityEngine()
        self.synthesis = KnowledgeSynthesisEngine()
        self.insights = InsightGenerationEngine()
        self.hypothesis = HypothesisEngine()
        self.recommendations = RecommendationEngine()
        self.active_research: Dict[str, Any] = {}
    
    async def create_research(self, objective: ResearchObjective, plan: ResearchPlan) -> Any:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            research_id = ZANOXUtils.generate_id('research')
            await conn.execute('''
                INSERT INTO research (id, objective_id, research_type, status, title, description, plan, metadata)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
            ''', research_id, objective.id, objective.research_type.value, ResearchStatus.PLANNING.value,
            objective.title, objective.description, plan.model_dump_json(), objective.metadata)
            self.active_research[research_id] = {'objective': objective, 'plan': plan, 'status': ResearchStatus.PLANNING}
            return type('Research', (), {'id': research_id, 'objective': objective, 'plan': plan, 'status': ResearchStatus.PLANNING})()
    
    async def get_research(self, research_id: str) -> Optional[Dict]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            row = await conn.fetchrow('SELECT * FROM research WHERE id = $1', research_id)
            if row:
                return dict(row)
            return None
    
    async def get_status(self, research_id: str) -> str:
        if research_id in self.active_research:
            return self.active_research[research_id]['status'].value
        research = await self.get_research(research_id)
        return research.get('status', 'unknown') if research else 'unknown'
    
    async def update_status(self, research_id: str, status: ResearchStatus):
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            await conn.execute('UPDATE research SET status = $1, updated_at = NOW() WHERE id = $2', status.value, research_id)
        if research_id in self.active_research:
            self.active_research[research_id]['status'] = status
    
    async def get_sources(self, research_id: str, validated_only: bool = False) -> List[Dict]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            if validated_only:
                rows = await conn.fetch('SELECT * FROM sources WHERE reliability IN ($1, $2) ORDER BY credibility_score DESC', 'high', 'medium')
            else:
                rows = await conn.fetch('SELECT * FROM sources ORDER BY created_at DESC')
            return [dict(row) for row in rows]
    
    async def get_facts(self, research_id: str, verified_only: bool = False) -> List[Dict]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            if verified_only:
                rows = await conn.fetch('SELECT * FROM facts WHERE status = $1 ORDER BY confidence DESC', 'verified')
            else:
                rows = await conn.fetch('SELECT * FROM facts ORDER BY created_at DESC')
            return [dict(row) for row in rows]
    
    async def execute_phase(self, research_id: str, phase_name: str, phase_config: Dict):
        logger.info(f'Executing phase {phase_name} for research {research_id}')
        try:
            if phase_name == 'discovery':
                sources = await self.discovery.discover(research_id, phase_config)
                return {'sources_discovered': len(sources), 'sources': sources}
            elif phase_name == 'collection':
                data = await self.collector.collect(research_id, phase_config)
                return {'collected': len(data), 'data': data}
            elif phase_name == 'extraction':
                extracted = await self.extractor.extract(research_id, phase_config)
                return {'extracted': len(extracted), 'data': extracted}
            elif phase_name == 'validation':
                validated = await self.validation.validate_batch(research_id, phase_config)
                return {'validated': len(validated), 'sources': validated}
            elif phase_name == 'verification':
                facts = await self.verification.verify_facts(research_id, phase_config)
                return {'facts_verified': len(facts), 'facts': facts}
            elif phase_name == 'synthesis':
                knowledge = await self.synthesis.synthesize(research_id, phase_config)
                return {'synthesized': True, 'knowledge': knowledge}
            elif phase_name == 'insights':
                insights = await self.insights.generate(research_id, phase_config)
                return {'insights_generated': len(insights), 'insights': insights}
            elif phase_name == 'recommendations':
                recs = await self.recommendations.generate(research_id, phase_config)
                return {'recommendations': len(recs), 'data': recs}
            else:
                return {'status': 'skipped', 'reason': 'Unknown phase'}
        except Exception as e:
            logger.error(f'Phase {phase_name} failed: {e}')
            return {'status': 'failed', 'error': str(e)}