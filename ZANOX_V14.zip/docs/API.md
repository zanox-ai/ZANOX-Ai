# ZANOX V14 API Documentation

## Research Management
### POST /research
Create a new research objective. Returns research_id and plan.

### GET /research/{research_id}
Retrieve full research data including status and results.

### GET /research/{research_id}/status
Get current research execution status.

## Outputs
### GET /research/{research_id}/report
Generate and retrieve research report.

### GET /research/{research_id}/presentation
Generate presentation slides.

### GET /research/{research_id}/dashboard
Generate analytics dashboard.

## Monitoring
### POST /research/{research_id}/monitor
Start continuous monitoring.

### DELETE /research/{research_id}/monitor
Stop monitoring.

## Analytics
### GET /analytics/overview
System-wide analytics overview.

## Knowledge Graph
### GET /knowledge-graph/query
Query the knowledge graph.
