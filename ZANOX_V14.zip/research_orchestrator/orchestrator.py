"""
ZANOX V14 - Research Orchestrator
Coordinates multi-phase research execution
"""

import logging
import asyncio
from typing import Dict, List, Any, Optional
from datetime import datetime

from shared.models import ResearchStatus
from shared.database import DatabaseManager
from shared.config import ZANOXConfig

from research_engine.engine import ResearchEngine
from research_agents.agent_system import ResearchAgentSystem
from multi_agent_teams.teams import MultiAgentTeam
from workflow_engine.workflow import WorkflowEngine

logger = logging.getLogger('zanox.orchestrator')

class ResearchOrchestrator:
    def __init__(self):
        self.engine = ResearchEngine()
        self.agent_system = ResearchAgentSystem()
        self.teams = MultiAgentTeam()
        self.workflow = WorkflowEngine()
        self.active_executions: Dict[str, Any] = {}
    
    async def execute_research(self, research_id: str):
        logger.info(f'Starting research execution: {research_id}')
        try:
            await self.engine.update_status(research_id, ResearchStatus.IN_PROGRESS)
            research = await self.engine.get_research(research_id)
            if not research:
                logger.error(f'Research {research_id} not found')
                return
            plan = research.get('plan', {})
            phases = plan.get('phases', []) if isinstance(plan, dict) else []
            if not phases and isinstance(plan, str):
                import json
                try:
                    plan_data = json.loads(plan)
                    phases = plan_data.get('phases', [])
                except:
                    phases = []
            
            self.active_executions[research_id] = {'start_time': datetime.utcnow(), 'phases': phases, 'current_phase': 0}
            
            for i, phase in enumerate(phases):
                phase_name = phase.get('name', 'unknown') if isinstance(phase, dict) else str(phase)
                self.active_executions[research_id]['current_phase'] = i
                logger.info(f'Executing phase {i+1}/{len(phases)}: {phase_name}')
                
                await self._update_phase_status(research_id, i, 'in_progress')
                result = await self.engine.execute_phase(research_id, phase_name, phase.get('config', {}) if isinstance(phase, dict) else {})
                
                if result.get('status') == 'failed':
                    logger.error(f'Phase {phase_name} failed: {result.get("error")}')
                    await self._update_phase_status(research_id, i, 'failed')
                    await self.engine.update_status(research_id, ResearchStatus.FAILED)
                    return
                
                await self._update_phase_status(research_id, i, 'completed')
                logger.info(f'Phase {phase_name} completed successfully')
            
            await self.engine.update_status(research_id, ResearchStatus.SYNTHESIZING)
            await self._generate_outputs(research_id)
            await self.engine.update_status(research_id, ResearchStatus.COMPLETED)
            
            self.active_executions[research_id]['end_time'] = datetime.utcnow()
            duration = (self.active_executions[research_id]['end_time'] - self.active_executions[research_id]['start_time']).total_seconds()
            logger.info(f'Research {research_id} completed in {duration}s')
            
        except Exception as e:
            logger.error(f'Research execution failed: {e}')
            await self.engine.update_status(research_id, ResearchStatus.FAILED)
    
    async def _update_phase_status(self, research_id: str, phase_index: int, status: str):
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            research = await conn.fetchrow('SELECT plan FROM research WHERE id = $1', research_id)
            if research and research['plan']:
                import json
                plan = json.loads(research['plan']) if isinstance(research['plan'], str) else research['plan']
                if 'phases' in plan and phase_index < len(plan['phases']):
                    plan['phases'][phase_index]['status'] = status
                    await conn.execute('UPDATE research SET plan = $1, updated_at = NOW() WHERE id = $2', json.dumps(plan), research_id)
    
    async def _generate_outputs(self, research_id: str):
        from report_generator.generator import ReportGenerator
        from presentation_generator.generator import PresentationGenerator
        from dashboard_generator.generator import DashboardGenerator
        report_gen = ReportGenerator()
        presentation_gen = PresentationGenerator()
        dashboard_gen = DashboardGenerator()
        await report_gen.generate(research_id)
        await presentation_gen.generate(research_id)
        await dashboard_gen.generate(research_id)
    
    async def get_execution_status(self, research_id: str) -> Optional[Dict]:
        return self.active_executions.get(research_id)
    
    async def cancel_research(self, research_id: str) -> bool:
        if research_id in self.active_executions:
            self.active_executions[research_id]['cancelled'] = True
            await self.engine.update_status(research_id, ResearchStatus.FAILED)
            return True
        return False