"""
ZANOX V14 - Database Layer
Research Intelligence Layer
"""

import asyncpg
import redis.asyncio as redis
from neo4j import AsyncGraphDatabase
from elasticsearch import AsyncElasticsearch
from shared.config import ZANOXConfig

class DatabaseManager:
    _postgres = None
    _redis = None
    _neo4j = None
    _es = None
    @classmethod
    async def get_postgres(cls):
        if cls._postgres is None:
            cls._postgres = await asyncpg.create_pool(ZANOXConfig.POSTGRES_URL, min_size=5, max_size=20)
        return cls._postgres
    @classmethod
    async def get_redis(cls):
        if cls._redis is None:
            cls._redis = redis.from_url(ZANOXConfig.REDIS_URL, decode_responses=True)
        return cls._redis
    @classmethod
    async def get_neo4j(cls):
        if cls._neo4j is None:
            cls._neo4j = AsyncGraphDatabase.driver(ZANOXConfig.NEO4J_URL, auth=(ZANOXConfig.NEO4J_USER, ZANOXConfig.NEO4J_PASSWORD))
        return cls._neo4j
    @classmethod
    async def get_elasticsearch(cls):
        if cls._es is None:
            cls._es = AsyncElasticsearch([ZANOXConfig.ELASTICSEARCH_URL])
        return cls._es
    @classmethod
    async def close_all(cls):
        if cls._postgres: await cls._postgres.close()
        if cls._redis: await cls._redis.close()
        if cls._neo4j: await cls._neo4j.close()
        if cls._es: await cls._es.close()

class PostgresSchema:
    RESEARCH_TABLE = '''CREATE TABLE IF NOT EXISTS research (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), objective_id TEXT NOT NULL, research_type TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending', title TEXT NOT NULL, description TEXT, plan JSONB, results JSONB, metadata JSONB, created_at TIMESTAMP DEFAULT NOW(), updated_at TIMESTAMP DEFAULT NOW(), completed_at TIMESTAMP, version TEXT DEFAULT 'V14'); CREATE INDEX IF NOT EXISTS idx_research_status ON research(status); CREATE INDEX IF NOT EXISTS idx_research_type ON research(research_type);'''
    SOURCES_TABLE = '''CREATE TABLE IF NOT EXISTS sources (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), url TEXT, title TEXT NOT NULL, content TEXT, summary TEXT, source_type TEXT NOT NULL, reliability TEXT DEFAULT 'unverified', credibility_score FLOAT DEFAULT 0.0, domain_authority FLOAT, author TEXT, publish_date TIMESTAMP, access_date TIMESTAMP DEFAULT NOW(), metadata JSONB, tags TEXT[], language TEXT DEFAULT 'en', created_at TIMESTAMP DEFAULT NOW()); CREATE INDEX IF NOT EXISTS idx_sources_type ON sources(source_type); CREATE INDEX IF NOT EXISTS idx_sources_reliability ON sources(reliability);'''
    FACTS_TABLE = '''CREATE TABLE IF NOT EXISTS facts (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), statement TEXT NOT NULL, status TEXT DEFAULT 'unverified', confidence FLOAT DEFAULT 0.0, sources UUID[], verification_method TEXT, verified_at TIMESTAMP, verified_by TEXT, contradictions UUID[], metadata JSONB, created_at TIMESTAMP DEFAULT NOW()); CREATE INDEX IF NOT EXISTS idx_facts_status ON facts(status); CREATE INDEX IF NOT EXISTS idx_facts_confidence ON facts(confidence);'''
    CITATIONS_TABLE = '''CREATE TABLE IF NOT EXISTS citations (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), source_id UUID REFERENCES sources(id), fact_id UUID REFERENCES facts(id), context TEXT, page_number INT, paragraph INT, quote TEXT, citation_style TEXT DEFAULT 'apa', formatted_citation TEXT NOT NULL, created_at TIMESTAMP DEFAULT NOW());'''
    INSIGHTS_TABLE = '''CREATE TABLE IF NOT EXISTS insights (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), research_id TEXT NOT NULL, title TEXT NOT NULL, description TEXT, category TEXT, confidence FLOAT DEFAULT 0.0, supporting_facts UUID[], related_insights UUID[], impact_score FLOAT DEFAULT 0.0, action_items TEXT[], created_at TIMESTAMP DEFAULT NOW());'''
    RECOMMENDATIONS_TABLE = '''CREATE TABLE IF NOT EXISTS recommendations (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), research_id TEXT NOT NULL, title TEXT NOT NULL, description TEXT, priority INT DEFAULT 5, expected_outcome TEXT, implementation_steps TEXT[], risks TEXT[], resources_needed TEXT[], timeline TEXT, created_at TIMESTAMP DEFAULT NOW());'''
    ALERTS_TABLE = '''CREATE TABLE IF NOT EXISTS alerts (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), research_id TEXT NOT NULL, alert_type TEXT NOT NULL, severity TEXT NOT NULL, message TEXT NOT NULL, detected_change TEXT, previous_value TEXT, current_value TEXT, source_id UUID, acknowledged BOOLEAN DEFAULT FALSE, acknowledged_by TEXT, acknowledged_at TIMESTAMP, created_at TIMESTAMP DEFAULT NOW()); CREATE INDEX IF NOT EXISTS idx_alerts_research ON alerts(research_id); CREATE INDEX IF NOT EXISTS idx_alerts_acknowledged ON alerts(acknowledged);'''
    CHANGE_RECORDS_TABLE = '''CREATE TABLE IF NOT EXISTS change_records (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), research_id TEXT NOT NULL, entity_type TEXT NOT NULL, entity_id TEXT NOT NULL, change_type TEXT NOT NULL, field_name TEXT, old_value TEXT, new_value TEXT, significance FLOAT DEFAULT 0.0, detected_by TEXT, detection_method TEXT, created_at TIMESTAMP DEFAULT NOW());'''
    REPORTS_TABLE = '''CREATE TABLE IF NOT EXISTS reports (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), research_id TEXT NOT NULL, title TEXT NOT NULL, executive_summary TEXT, sections JSONB, sources_used UUID[], facts_presented UUID[], insights UUID[], recommendations UUID[], appendices JSONB, format TEXT DEFAULT 'markdown', word_count INT DEFAULT 0, reading_time INT DEFAULT 0, created_at TIMESTAMP DEFAULT NOW());'''
    @classmethod
    async def initialize(cls):
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            for table_sql in [cls.RESEARCH_TABLE, cls.SOURCES_TABLE, cls.FACTS_TABLE, cls.CITATIONS_TABLE, cls.INSIGHTS_TABLE, cls.RECOMMENDATIONS_TABLE, cls.ALERTS_TABLE, cls.CHANGE_RECORDS_TABLE, cls.REPORTS_TABLE]:
                await conn.execute(table_sql)