"""
ZANOX V14 - Shared Utilities
Research Intelligence Layer
"""

import hashlib
import json
import re
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Union
from urllib.parse import urlparse
import aiohttp
import asyncio


class ZANOXUtils:
    @staticmethod
    def generate_id(prefix: str = 'zanox') -> str:
        timestamp = datetime.utcnow().strftime('%Y%m%d%H%M%S')
        hash_suffix = hashlib.sha256(str(datetime.utcnow().timestamp()).encode()).hexdigest()[:8]
        return f'{prefix}_{timestamp}_{hash_suffix}'
    
    @staticmethod
    def sanitize_text(text: str, max_length: int = 10000) -> str:
        if not text:
            return ''
        text = re.sub(r'\s+', ' ', text)
        text = re.sub(r'[^\w\s.,;:!?()-]', '', text)
        return text[:max_length].strip()
    
    @staticmethod
    def extract_domain(url: str) -> str:
        try:
            parsed = urlparse(url)
            return parsed.netloc.lower()
        except:
            return ''
    
    @staticmethod
    def calculate_reliability_score(domain: str, content_length: int, has_author: bool, has_date: bool) -> float:
        score = 0.5
        trusted_domains = ['.edu', '.gov', 'reuters.com', 'bloomberg.com', 'nature.com', 'science.org', 'arxiv.org', 'ieee.org']
        if any(domain.endswith(td) for td in trusted_domains):
            score += 0.3
        if content_length > 1000:
            score += 0.1
        if has_author:
            score += 0.05
        if has_date:
            score += 0.05
        return min(score, 1.0)
    
    @staticmethod
    def chunk_text(text: str, chunk_size: int = 1000, overlap: int = 100) -> List[str]:
        chunks = []
        start = 0
        while start < len(text):
            end = start + chunk_size
            chunk = text[start:end]
            chunks.append(chunk)
            start = end - overlap
        return chunks
    
    @staticmethod
    def fuzzy_match(str1: str, str2: str) -> float:
        if not str1 or not str2:
            return 0.0
        str1, str2 = str1.lower(), str2.lower()
        if str1 == str2:
            return 1.0
        set1, set2 = set(str1.split()), set(str2.split())
        intersection = set1.intersection(set2)
        union = set1.union(set2)
        return len(intersection) / len(union) if union else 0.0
    
    @staticmethod
    async def fetch_url(session: aiohttp.ClientSession, url: str, timeout: int = 30, headers: Optional[Dict] = None) -> Optional[str]:
        default_headers = {'User-Agent': 'ZANOX-Research-Bot/14.0 (Research Intelligence Platform)'}
        if headers:
            default_headers.update(headers)
        try:
            async with session.get(url, headers=default_headers, timeout=aiohttp.ClientTimeout(total=timeout)) as response:
                if response.status == 200:
                    return await response.text()
                return None
        except Exception as e:
            return None
    
    @staticmethod
    def parse_date(date_str: str) -> Optional[datetime]:
        formats = ['%Y-%m-%d', '%Y-%m-%dT%H:%M:%S', '%Y-%m-%d %H:%M:%S', '%d/%m/%Y', '%m/%d/%Y', '%B %d, %Y', '%b %d, %Y']
        for fmt in formats:
            try:
                return datetime.strptime(date_str, fmt)
            except:
                continue
        return None
    
    @staticmethod
    def compute_similarity(vec1: List[float], vec2: List[float]) -> float:
        if len(vec1) != len(vec2) or not vec1:
            return 0.0
        dot = sum(a * b for a, b in zip(vec1, vec2))
        norm1 = sum(a * a for a in vec1) ** 0.5
        norm2 = sum(b * b for b in vec2) ** 0.5
        return dot / (norm1 * norm2) if norm1 and norm2 else 0.0


class RateLimiter:
    def __init__(self, max_requests: int, time_window: int):
        self.max_requests = max_requests
        self.time_window = time_window
        self.requests = []
        self._lock = asyncio.Lock()
    
    async def acquire(self):
        async with self._lock:
            now = datetime.utcnow()
            self.requests = [r for r in self.requests if now - r < timedelta(seconds=self.time_window)]
            if len(self.requests) >= self.max_requests:
                sleep_time = (self.requests[0] + timedelta(seconds=self.time_window) - now).total_seconds()
                if sleep_time > 0:
                    await asyncio.sleep(sleep_time)
            self.requests.append(now)