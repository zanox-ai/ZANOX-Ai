"""
ZANOX V14 - Shared Models and Base Classes
Research Intelligence Layer
"""

from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Union
from pydantic import BaseModel, Field
from uuid import uuid4


class ResearchType(str, Enum):
    DEEP_RESEARCH = "deep_research"
    MARKET_RESEARCH = "market_research"
    BUSINESS_RESEARCH = "business_research"
    COMPETITOR_RESEARCH = "competitor_research"
    PRODUCT_RESEARCH = "product_research"
    STARTUP_RESEARCH = "startup_research"
    INDUSTRY_RESEARCH = "industry_research"
    TECHNOLOGY_RESEARCH = "technology_research"
    AI_RESEARCH = "ai_research"
    ACADEMIC_RESEARCH = "academic_research"
    SCIENTIFIC_RESEARCH = "scientific_research"
    INVESTMENT_RESEARCH = "investment_research"
    TREND_RESEARCH = "trend_research"
    KEYWORD_RESEARCH = "keyword_research"
    SEO_RESEARCH = "seo_research"
    CUSTOMER_RESEARCH = "customer_research"
    PRICING_RESEARCH = "pricing_research"
    RISK_RESEARCH = "risk_research"
    DUE_DILIGENCE = "due_diligence"


class ResearchStatus(str, Enum):
    PENDING = "pending"
    PLANNING = "planning"
    IN_PROGRESS = "in_progress"
    VALIDATING = "validating"
    SYNTHESIZING = "synthesizing"
    GENERATING = "generating"
    COMPLETED = "completed"
    FAILED = "failed"
    ARCHIVED = "archived"


class SourceType(str, Enum):
    WEB = "web"
    API = "api"
    DATABASE = "database"
    DOCUMENT = "document"
    NEWS = "news"
    SOCIAL = "social"
    ACADEMIC = "academic"
    MARKET = "market"
    INTERNAL = "internal"


class SourceReliability(str, Enum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    UNVERIFIED = "unverified"


class FactStatus(str, Enum):
    VERIFIED = "verified"
    PARTIALLY_VERIFIED = "partially_verified"
    DISPUTED = "disputed"
    UNVERIFIED = "unverified"
    FALSE = "false"


class BaseZANOXModel(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid4()))
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    version: str = "V14"

    class Config:
        json_encoders = {datetime: lambda v: v.isoformat()}


class ResearchObjective(BaseZANOXModel):
    title: str
    description: str
    research_type: ResearchType
    scope: Optional[str] = None
    constraints: Optional[List[str]] = None
    target_audience: Optional[str] = None
    deliverables: List[str] = Field(default_factory=list)
    priority: int = 5
    deadline: Optional[datetime] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)


class ResearchPlan(BaseZANOXModel):
    objective_id: str
    phases: List[Dict[str, Any]] = Field(default_factory=list)
    estimated_duration: int = 0
    required_sources: List[str] = Field(default_factory=list)
    required_agents: List[str] = Field(default_factory=list)
    dependencies: List[str] = Field(default_factory=list)
    risk_factors: List[str] = Field(default_factory=list)
    status: ResearchStatus = ResearchStatus.PENDING


class Source(BaseZANOXModel):
    url: Optional[str] = None
    title: str
    content: Optional[str] = None
    summary: Optional[str] = None
    source_type: SourceType
    reliability: SourceReliability = SourceReliability.UNVERIFIED
    credibility_score: float = 0.0
    domain_authority: Optional[float] = None
    author: Optional[str] = None
    publish_date: Optional[datetime] = None
    access_date: datetime = Field(default_factory=datetime.utcnow)
    metadata: Dict[str, Any] = Field(default_factory=dict)
    tags: List[str] = Field(default_factory=list)
    language: str = "en"


class Fact(BaseZANOXModel):
    statement: str
    status: FactStatus = FactStatus.UNVERIFIED
    confidence: float = 0.0
    sources: List[str] = Field(default_factory=list)
    verification_method: Optional[str] = None
    verified_at: Optional[datetime] = None
    verified_by: Optional[str] = None
    contradictions: List[str] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class Citation(BaseZANOXModel):
    source_id: str
    fact_id: str
    context: str
    page_number: Optional[int] = None
    paragraph: Optional[int] = None
    quote: Optional[str] = None
    citation_style: str = "apa"
    formatted_citation: str


class Evidence(BaseZANOXModel):
    fact_id: str
    evidence_type: str
    content: str
    strength: float = 0.0
    source_ids: List[str] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class Insight(BaseZANOXModel):
    research_id: str
    title: str
    description: str
    category: str
    confidence: float = 0.0
    supporting_facts: List[str] = Field(default_factory=list)
    related_insights: List[str] = Field(default_factory=list)
    impact_score: float = 0.0
    action_items: List[str] = Field(default_factory=list)


class Recommendation(BaseZANOXModel):
    research_id: str
    title: str
    description: str
    priority: int = 5
    expected_outcome: Optional[str] = None
    implementation_steps: List[str] = Field(default_factory=list)
    risks: List[str] = Field(default_factory=list)
    resources_needed: List[str] = Field(default_factory=list)
    timeline: Optional[str] = None


class ResearchReport(BaseZANOXModel):
    research_id: str
    title: str
    executive_summary: str
    sections: List[Dict[str, Any]] = Field(default_factory=list)
    sources_used: List[str] = Field(default_factory=list)
    facts_presented: List[str] = Field(default_factory=list)
    insights: List[str] = Field(default_factory=list)
    recommendations: List[str] = Field(default_factory=list)
    appendices: List[Dict[str, Any]] = Field(default_factory=list)
    format: str = "markdown"
    word_count: int = 0
    reading_time: int = 0


class Alert(BaseZANOXModel):
    research_id: str
    alert_type: str
    severity: str
    message: str
    detected_change: Optional[str] = None
    previous_value: Optional[str] = None
    current_value: Optional[str] = None
    source_id: Optional[str] = None
    acknowledged: bool = False
    acknowledged_by: Optional[str] = None
    acknowledged_at: Optional[datetime] = None


class ChangeRecord(BaseZANOXModel):
    research_id: str
    entity_type: str
    entity_id: str
    change_type: str
    field_name: Optional[str] = None
    old_value: Optional[str] = None
    new_value: Optional[str] = None
    significance: float = 0.0
    detected_by: str
    detection_method: str
