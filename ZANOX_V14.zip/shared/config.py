"""
ZANOX V14 - Configuration
Research Intelligence Layer
"""

import os
from typing import Dict, List

class ZANOXConfig:
    POSTGRES_URL = os.getenv('ZANOX_POSTGRES_URL', 'postgresql://zanox:zanox@localhost:5432/zanox_research')
    REDIS_URL = os.getenv('ZANOX_REDIS_URL', 'redis://localhost:6379/0')
    NEO4J_URL = os.getenv('ZANOX_NEO4J_URL', 'bolt://localhost:7687')
    NEO4J_USER = os.getenv('ZANOX_NEO4J_USER', 'neo4j')
    NEO4J_PASSWORD = os.getenv('ZANOX_NEO4J_PASSWORD', 'zanox')
    ELASTICSEARCH_URL = os.getenv('ZANOX_ES_URL', 'http://localhost:9200')
    KAFKA_BOOTSTRAP = os.getenv('ZANOX_KAFKA', 'localhost:9092')
    GOOGLE_API_KEY = os.getenv('GOOGLE_API_KEY', '')
    BING_API_KEY = os.getenv('BING_API_KEY', '')
    BRAVE_API_KEY = os.getenv('BRAVE_API_KEY', '')
    PERPLEXITY_API_KEY = os.getenv('PERPLEXITY_API_KEY', '')
    CRUNCHBASE_API_KEY = os.getenv('CRUNCHBASE_API_KEY', '')
    GITHUB_TOKEN = os.getenv('GITHUB_TOKEN', '')
    LINKEDIN_TOKEN = os.getenv('LINKEDIN_TOKEN', '')
    X_BEARER_TOKEN = os.getenv('X_BEARER_TOKEN', '')
    MAX_SOURCES_PER_QUERY = int(os.getenv('MAX_SOURCES', '50'))
    MAX_RESEARCH_DEPTH = int(os.getenv('MAX_DEPTH', '5'))
    FACT_CONFIDENCE_THRESHOLD = float(os.getenv('FACT_THRESHOLD', '0.7'))
    SOURCE_RELIABILITY_THRESHOLD = float(os.getenv('RELIABILITY_THRESHOLD', '0.5'))
    RATE_LIMITS: Dict[str, Dict[str, int]] = {
        'google_search': {'max': 100, 'window': 60},
        'bing_search': {'max': 100, 'window': 60},
        'brave_search': {'max': 100, 'window': 60},
        'github_api': {'max': 60, 'window': 60},
        'crunchbase': {'max': 100, 'window': 60},
    }
    TRUSTED_DOMAINS: List[str] = ['.edu', '.gov', 'reuters.com', 'bloomberg.com', 'ft.com', 'nature.com', 'science.org', 'arxiv.org', 'ieee.org', 'acm.org', 'who.int', 'worldbank.org', 'imf.org', 'oecd.org']
    BLOCKED_DOMAINS: List[str] = ['spam.com', 'fake-news.com', 'clickbait.net']
    MAX_CONCURRENT_AGENTS = int(os.getenv('MAX_AGENTS', '10'))
    AGENT_TIMEOUT = int(os.getenv('AGENT_TIMEOUT', '300'))
    ALERT_WEBHOOK = os.getenv('ALERT_WEBHOOK', '')
    LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
    @classmethod
    def get_kafka_topics(cls) -> List[str]:
        return ['research.requests', 'research.updates', 'research.completed', 'source.discovered', 'source.validated', 'fact.verified', 'alert.generated', 'change.detected', 'report.generated']