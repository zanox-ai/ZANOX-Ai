"""
ZANOX V14 - Change Detection Engine
Detects changes in monitored entities
"""

import logging
from typing import Dict, List, Any
from shared.database import DatabaseManager
from shared.utils import ZANOXUtils

logger = logging.getLogger('zanox.change_detection')

class ChangeDetectionEngine:
    def __init__(self): pass
    async def detect_changes(self, research_id: str, current_data: Dict, previous_data: Dict) -> List[Dict]:
        changes = []
        for key in set(current_data.keys()).union(previous_data.keys()):
            old = previous_data.get(key); new = current_data.get(key)
            if old != new:
                significance = self._calculate_significance(old, new)
                changes.append({'research_id': research_id, 'entity_type': 'data', 'entity_id': key, 'change_type': 'modified', 'old_value': str(old), 'new_value': str(new), 'significance': significance, 'detected_by': 'change_detection_engine', 'detection_method': 'diff'})
        return changes
    def _calculate_significance(self, old: Any, new: Any) -> float:
        if isinstance(old, (int, float)) and isinstance(new, (int, float)):
            if old == 0: return 1.0
            return min(abs(new - old) / abs(old), 1.0)
        return 0.5 if old != new else 0.0