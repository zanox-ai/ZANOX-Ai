"""
ZANOX V14 - Insight Generation Engine
Generates actionable insights from research
"""

import logging
from typing import Dict, List, Any
from shared.models import Insight
from shared.database import DatabaseManager

logger = logging.getLogger('zanox.insight_generation')

class InsightGenerationEngine:
    def __init__(self): pass
    async def generate(self, research_id: str, config: Dict) -> List[Insight]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            facts = await conn.fetch('SELECT * FROM facts WHERE status = $1 ORDER BY confidence DESC', 'verified')
            insights = []
            for i, fact in enumerate(facts[:20]):
                insight = Insight(research_id=research_id, title=f"Insight: {fact['statement'][:80]}...", description=fact['statement'], category='fact_based', confidence=fact['confidence'], supporting_facts=[str(fact['id'])], impact_score=fact['confidence'] * 0.9)
                await conn.execute('INSERT INTO insights (research_id, title, description, category, confidence, supporting_facts, impact_score) VALUES ($1, $2, $3, $4, $5, $6, $7)', insight.research_id, insight.title, insight.description, insight.category, insight.confidence, insight.supporting_facts, insight.impact_score)
                insights.append(insight)
            return insights