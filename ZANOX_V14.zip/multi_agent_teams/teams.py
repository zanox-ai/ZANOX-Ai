"""
ZANOX V14 - Multi-Agent Teams
Coordinated team-based research execution
"""

import logging
import asyncio
from typing import Dict, List, Any, Optional

from research_agents.agent_system import ResearchAgentSystem
from shared.config import ZANOXConfig

logger = logging.getLogger('zanox.multi_agent_teams')

class AgentTeam:
    def __init__(self, name: str, agents: List[str], strategy: str = 'parallel'):
        self.name = name
        self.agents = agents
        self.strategy = strategy
        self.results = {}
        self.system = ResearchAgentSystem()

    async def execute(self, context: Dict) -> Dict:
        logger.info(f'Team {self.name} executing with strategy {self.strategy}')
        if self.strategy == 'parallel':
            self.results = await self.system.execute_parallel(self.agents, context)
        elif self.strategy == 'sequential':
            self.results = {}
            for agent_name in self.agents:
                result = await self.system.execute_agent(agent_name, context)
                self.results[agent_name] = result
                context['previous_results'] = self.results
        elif self.strategy == 'hierarchical':
            self.results = await self._execute_hierarchical(context)
        return {'team': self.name, 'strategy': self.strategy, 'results': self.results}
    
    async def _execute_hierarchical(self, context: Dict) -> Dict:
        # First agent is coordinator, rest are workers
        if not self.agents:
            return {}
        coordinator = self.agents[0]
        workers = self.agents[1:]
        plan = await self.system.execute_agent(coordinator, context)
        worker_results = await self.system.execute_parallel(workers, {**context, 'plan': plan})
        return {'coordinator': plan, 'workers': worker_results}

class MultiAgentTeam:
    def __init__(self):
        self.teams: Dict[str, AgentTeam] = {}
        self._create_default_teams()
    
    def _create_default_teams(self):
        self.teams['deep_research'] = AgentTeam('deep_research', ['search_agent', 'web_crawler', 'news_agent', 'academic_agent', 'fact_checker'], 'parallel')
        self.teams['market_analysis'] = AgentTeam('market_analysis', ['market_agent', 'competitor_agent', 'trend_agent'], 'parallel')
        self.teams['competitor_intelligence'] = AgentTeam('competitor_intelligence', ['competitor_agent', 'web_crawler', 'social_agent', 'news_agent'], 'parallel')
        self.teams['technology_scan'] = AgentTeam('technology_scan', ['academic_agent', 'search_agent', 'trend_agent', 'web_crawler'], 'sequential')
        self.teams['social_monitoring'] = AgentTeam('social_monitoring', ['social_agent', 'news_agent', 'trend_agent'], 'parallel')
        self.teams['investigation'] = AgentTeam('investigation', ['search_agent', 'web_crawler', 'fact_checker', 'academic_agent', 'social_agent'], 'hierarchical')
    
    def create_team(self, name: str, agents: List[str], strategy: str = 'parallel') -> AgentTeam:
        team = AgentTeam(name, agents, strategy)
        self.teams[name] = team
        return team
    
    async def execute_team(self, name: str, context: Dict) -> Dict:
        team = self.teams.get(name)
        if not team:
            raise ValueError(f'Team {name} not found')
        return await team.execute(context)
    
    def list_teams(self) -> List[Dict]:
        return [{'name': name, 'agents': team.agents, 'strategy': team.strategy} for name, team in self.teams.items()]
    
    async def execute_all_teams(self, context: Dict) -> Dict[str, Dict]:
        tasks = [team.execute(context) for team in self.teams.values()]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        return {name: result for name, result in zip(self.teams.keys(), results)}