"""
ZANOX V14 - Research Planner
Intelligent research planning and strategy
"""

import logging
from typing import Dict, List, Any
from datetime import datetime

from shared.models import ResearchObjective, ResearchPlan, ResearchType, ResearchStatus
from shared.utils import ZANOXUtils
from shared.database import DatabaseManager

logger = logging.getLogger('zanox.research_planner')

class ResearchPlanner:
    def __init__(self):
        self.plan_templates = self._load_templates()
    
    def _load_templates(self) -> Dict[ResearchType, Dict]:
        return {
            ResearchType.DEEP_RESEARCH: {
                'phases': ['discovery', 'collection', 'extraction', 'validation', 'verification', 'synthesis', 'insights', 'recommendations'],
                'estimated_duration': 480, 'required_sources': ['web', 'academic', 'news', 'social']
            },
            ResearchType.MARKET_RESEARCH: {
                'phases': ['discovery', 'collection', 'extraction', 'validation', 'synthesis', 'insights', 'recommendations'],
                'estimated_duration': 240, 'required_sources': ['market', 'web', 'news']
            },
            ResearchType.COMPETITOR_RESEARCH: {
                'phases': ['discovery', 'collection', 'extraction', 'validation', 'verification', 'synthesis', 'insights'],
                'estimated_duration': 180, 'required_sources': ['web', 'news', 'social', 'market']
            },
            ResearchType.PRODUCT_RESEARCH: {
                'phases': ['discovery', 'collection', 'extraction', 'validation', 'synthesis', 'insights', 'recommendations'],
                'estimated_duration': 120, 'required_sources': ['web', 'market', 'social']
            },
            ResearchType.TECHNOLOGY_RESEARCH: {
                'phases': ['discovery', 'collection', 'extraction', 'validation', 'verification', 'synthesis', 'insights'],
                'estimated_duration': 300, 'required_sources': ['academic', 'web', 'news', 'api']
            },
            ResearchType.ACADEMIC_RESEARCH: {
                'phases': ['discovery', 'collection', 'extraction', 'validation', 'verification', 'synthesis', 'insights'],
                'estimated_duration': 360, 'required_sources': ['academic', 'web']
            },
            ResearchType.INVESTMENT_RESEARCH: {
                'phases': ['discovery', 'collection', 'extraction', 'validation', 'verification', 'synthesis', 'insights', 'recommendations'],
                'estimated_duration': 240, 'required_sources': ['market', 'web', 'news', 'api']
            },
            ResearchType.TREND_RESEARCH: {
                'phases': ['discovery', 'collection', 'extraction', 'validation', 'synthesis', 'insights'],
                'estimated_duration': 180, 'required_sources': ['web', 'news', 'social', 'market']
            },
            ResearchType.SEO_RESEARCH: {
                'phases': ['discovery', 'collection', 'extraction', 'validation', 'synthesis', 'insights', 'recommendations'],
                'estimated_duration': 120, 'required_sources': ['web', 'api']
            },
            ResearchType.CUSTOMER_RESEARCH: {
                'phases': ['discovery', 'collection', 'extraction', 'validation', 'synthesis', 'insights', 'recommendations'],
                'estimated_duration': 200, 'required_sources': ['web', 'social', 'market']
            },
            ResearchType.RISK_RESEARCH: {
                'phases': ['discovery', 'collection', 'extraction', 'validation', 'verification', 'synthesis', 'insights', 'recommendations'],
                'estimated_duration': 300, 'required_sources': ['web', 'news', 'market', 'api']
            },
            ResearchType.DUE_DILIGENCE: {
                'phases': ['discovery', 'collection', 'extraction', 'validation', 'verification', 'synthesis', 'insights', 'recommendations'],
                'estimated_duration': 480, 'required_sources': ['web', 'news', 'market', 'api', 'academic']
            },
        }
    
    async def create_plan(self, objective: ResearchObjective) -> ResearchPlan:
        template = self.plan_templates.get(objective.research_type, self.plan_templates[ResearchType.DEEP_RESEARCH])
        plan = ResearchPlan(
            objective_id=objective.id,
            phases=[{'name': phase, 'status': 'pending', 'config': {}} for phase in template['phases']],
            estimated_duration=template['estimated_duration'],
            required_sources=template['required_sources'],
            required_agents=self._determine_agents(objective.research_type),
            dependencies=[],
            risk_factors=self._identify_risks(objective),
            status=ResearchStatus.PENDING
        )
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            await conn.execute('''
                INSERT INTO research (id, objective_id, research_type, status, title, description, plan, metadata)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
            ''', plan.id, objective.id, objective.research_type.value, ResearchStatus.PENDING.value,
            f'Plan for {objective.title}', objective.description, plan.model_dump_json(), {})
        logger.info(f'Created plan {plan.id} for objective {objective.id}')
        return plan
    
    def _determine_agents(self, research_type: ResearchType) -> List[str]:
        agent_map = {
            ResearchType.DEEP_RESEARCH: ['web_crawler', 'analyst', 'synthesizer', 'fact_checker'],
            ResearchType.MARKET_RESEARCH: ['market_analyst', 'data_collector', 'trend_analyzer'],
            ResearchType.COMPETITOR_RESEARCH: ['competitor_analyst', 'web_crawler', 'social_monitor'],
            ResearchType.TECHNOLOGY_RESEARCH: ['tech_analyst', 'academic_searcher', 'patent_analyzer'],
            ResearchType.ACADEMIC_RESEARCH: ['academic_searcher', 'citation_analyst', 'peer_review_analyzer'],
            ResearchType.INVESTMENT_RESEARCH: ['financial_analyst', 'risk_assessor', 'market_researcher'],
            ResearchType.TREND_RESEARCH: ['trend_analyzer', 'social_monitor', 'news_analyzer'],
            ResearchType.SEO_RESEARCH: ['seo_analyst', 'keyword_researcher', 'competitor_analyzer'],
            ResearchType.CUSTOMER_RESEARCH: ['customer_analyst', 'survey_analyzer', 'social_monitor'],
            ResearchType.RISK_RESEARCH: ['risk_analyst', 'compliance_checker', 'financial_analyst'],
            ResearchType.DUE_DILIGENCE: ['legal_analyst', 'financial_analyst', 'background_checker', 'risk_assessor'],
        }
        return agent_map.get(research_type, ['general_researcher'])
    
    def _identify_risks(self, objective: ResearchObjective) -> List[str]:
        risks = ['data_availability', 'source_reliability']
        if objective.deadline and (objective.deadline - datetime.utcnow()).days < 3:
            risks.append('time_constraint')
        if objective.research_type in [ResearchType.INVESTMENT_RESEARCH, ResearchType.DUE_DILIGENCE]:
            risks.append('regulatory_compliance')
        return risks