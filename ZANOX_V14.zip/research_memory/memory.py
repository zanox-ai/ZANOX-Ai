"""
ZANOX V14 - Research Memory
Persistent and ephemeral research memory management
"""

import logging
import json
from typing import Dict, List, Any, Optional
from datetime import datetime

from shared.database import DatabaseManager
from shared.config import ZANOXConfig

logger = logging.getLogger('zanox.research_memory')

class ResearchMemory:
    def __init__(self):
        self.cache_prefix = 'zanox:memory:'
    
    async def store(self, key: str, value: Any, ttl: int = 86400):
        redis = await DatabaseManager.get_redis()
        serialized = json.dumps(value, default=str)
        await redis.setex(f'{self.cache_prefix}{key}', ttl, serialized)
    
    async def retrieve(self, key: str) -> Optional[Any]:
        redis = await DatabaseManager.get_redis()
        data = await redis.get(f'{self.cache_prefix}{key}')
        if data:
            return json.loads(data)
        return None
    
    async def delete(self, key: str):
        redis = await DatabaseManager.get_redis()
        await redis.delete(f'{self.cache_prefix}{key}')
    
    async def store_research_context(self, research_id: str, context: Dict):
        await self.store(f'context:{research_id}', context, ttl=604800)
    
    async def get_research_context(self, research_id: str) -> Optional[Dict]:
        return await self.retrieve(f'context:{research_id}')
    
    async def store_intermediate_results(self, research_id: str, phase: str, results: Any):
        await self.store(f'results:{research_id}:{phase}', results, ttl=259200)
    
    async def get_intermediate_results(self, research_id: str, phase: str) -> Optional[Any]:
        return await self.retrieve(f'results:{research_id}:{phase}')
    
    async def append_to_session(self, research_id: str, entry: Dict):
        redis = await DatabaseManager.get_redis()
        key = f'{self.cache_prefix}session:{research_id}'
        serialized = json.dumps(entry, default=str)
        await redis.lpush(key, serialized)
        await redis.expire(key, 604800)
    
    async def get_session_history(self, research_id: str, limit: int = 100) -> List[Dict]:
        redis = await DatabaseManager.get_redis()
        key = f'{self.cache_prefix}session:{research_id}'
        entries = await redis.lrange(key, 0, limit - 1)
        return [json.loads(e) for e in entries]
    
    async def store_embedding(self, research_id: str, text: str, embedding: List[float]):
        await self.store(f'embedding:{research_id}:{hash(text)}', {'text': text, 'embedding': embedding}, ttl=604800)
    
    async def search_similar(self, research_id: str, query_embedding: List[float], top_k: int = 5) -> List[Dict]:
        # Simplified similarity search - in production use vector DB
        return []
    
    async def clear_research_memory(self, research_id: str):
        redis = await DatabaseManager.get_redis()
        pattern = f'{self.cache_prefix}*{research_id}*'
        keys = await redis.keys(pattern)
        if keys:
            await redis.delete(*keys)
        logger.info(f'Cleared memory for research {research_id}')