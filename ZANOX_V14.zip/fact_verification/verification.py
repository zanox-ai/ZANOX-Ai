"""
ZANOX V14 - Fact Verification Engine
Verifies facts against multiple sources
"""

import logging
from typing import Dict, List, Any
from shared.models import Fact, FactStatus
from shared.database import DatabaseManager
from shared.config import ZANOXConfig

logger = logging.getLogger('zanox.fact_verification')

class FactVerificationEngine:
    def __init__(self):
        self.threshold = ZANOXConfig.FACT_CONFIDENCE_THRESHOLD
    async def verify(self, fact: Fact, sources: List[Dict]) -> Fact:
        if not sources: fact.status = FactStatus.UNVERIFIED; return fact
        supporting = 0
        for src in sources:
            content = (src.get('content') or '').lower()
            if fact.statement.lower() in content: supporting += 1
        ratio = supporting / len(sources) if sources else 0
        fact.confidence = min(ratio, 1.0)
        if fact.confidence >= self.threshold and supporting >= 2: fact.status = FactStatus.VERIFIED
        elif fact.confidence >= 0.4: fact.status = FactStatus.PARTIALLY_VERIFIED
        else: fact.status = FactStatus.UNVERIFIED
        return fact
    async def verify_facts(self, research_id: str, config: Dict) -> List[Fact]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            rows = await conn.fetch('SELECT * FROM facts WHERE status = $1', 'unverified')
            facts = []
            for row in rows:
                fact = Fact(**dict(row))
                source_rows = await conn.fetch('SELECT * FROM sources WHERE id = ANY($1)', row.get('sources', []))
                verified = await self.verify(fact, [dict(r) for r in source_rows])
                await conn.execute('UPDATE facts SET status = $1, confidence = $2 WHERE id = $3', verified.status.value, verified.confidence, verified.id)
                facts.append(verified)
            return facts
    async def verify_batch(self, facts: List[Dict]) -> List[Dict]:
        results = []
        for f in facts:
            fact = Fact(statement=f.get('statement', ''))
            verified = await self.verify(fact, f.get('sources', []))
            results.append({'statement': fact.statement, 'status': verified.status.value, 'confidence': verified.confidence})
        return results