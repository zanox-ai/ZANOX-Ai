"""
ZANOX V14 - Research Intelligence Layer
Main FastAPI Application
"""

from fastapi import FastAPI, HTTPException, BackgroundTasks, Depends
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
from typing import List, Optional
import logging

from shared.config import ZANOXConfig
from shared.database import DatabaseManager, PostgresSchema
from shared.models import ResearchObjective, ResearchStatus

from research_engine.engine import ResearchEngine
from research_planner.planner import ResearchPlanner
from research_orchestrator.orchestrator import ResearchOrchestrator
from research_memory.memory import ResearchMemory
from knowledge_graph.graph import KnowledgeGraph
from workflow_engine.workflow import WorkflowEngine

from report_generator.generator import ReportGenerator
from presentation_generator.generator import PresentationGenerator
from dashboard_generator.generator import DashboardGenerator

from monitoring.monitor import ResearchMonitor
from alerts.alert_system import AlertSystem
from analytics.analytics import ResearchAnalytics

from security.security_layer import SecurityLayer
from governance.governance import GovernanceLayer
from compliance.compliance import ComplianceLayer

logging.basicConfig(level=getattr(logging, ZANOXConfig.LOG_LEVEL))
logger = logging.getLogger('zanox.v14')

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info('ZANOX V14 Research Intelligence Layer starting...')
    await PostgresSchema.initialize()
    yield
    await DatabaseManager.close_all()
    logger.info('ZANOX V14 shutting down...')

app = FastAPI(
    title='ZANOX V14 - Research Intelligence Layer',
    description='Autonomous research platform for discovery, analysis, and synthesis',
    version='14.0.0',
    lifespan=lifespan
)

app.add_middleware(CORSMiddleware, allow_origins=['*'], allow_credentials=True, allow_methods=['*'], allow_headers=['*'])

# Initialize core systems
research_engine = ResearchEngine()
research_planner = ResearchPlanner()
orchestrator = ResearchOrchestrator()
memory = ResearchMemory()
kg = KnowledgeGraph()
workflow = WorkflowEngine()

report_gen = ReportGenerator()
presentation_gen = PresentationGenerator()
dashboard_gen = DashboardGenerator()

monitor = ResearchMonitor()
alerts = AlertSystem()
analytics = ResearchAnalytics()

security = SecurityLayer()
governance = GovernanceLayer()
compliance = ComplianceLayer()

# API Endpoints

@app.get('/health')
async def health_check():
    return {'status': 'healthy', 'version': 'V14', 'layer': 'Research Intelligence'}

@app.post('/research')
async def create_research(objective: ResearchObjective, background_tasks: BackgroundTasks):
    try:
        plan = await research_planner.create_plan(objective)
        research = await research_engine.create_research(objective, plan)
        background_tasks.add_task(orchestrator.execute_research, research.id)
        return {'research_id': research.id, 'status': ResearchStatus.PLANNING, 'plan_id': plan.id}
    except Exception as e:
        logger.error(f'Failed to create research: {e}')
        raise HTTPException(status_code=500, detail=str(e))

@app.get('/research/{research_id}')
async def get_research(research_id: str):
    research = await research_engine.get_research(research_id)
    if not research:
        raise HTTPException(status_code=404, detail='Research not found')
    return research

@app.get('/research/{research_id}/status')
async def get_research_status(research_id: str):
    status = await research_engine.get_status(research_id)
    return {'research_id': research_id, 'status': status}

@app.get('/research/{research_id}/report')
async def get_report(research_id: str, format: str = 'markdown'):
    report = await report_gen.generate(research_id, format)
    return report

@app.get('/research/{research_id}/presentation')
async def get_presentation(research_id: str):
    presentation = await presentation_gen.generate(research_id)
    return presentation

@app.get('/research/{research_id}/dashboard')
async def get_dashboard(research_id: str):
    dashboard = await dashboard_gen.generate(research_id)
    return dashboard

@app.get('/research/{research_id}/insights')
async def get_insights(research_id: str):
    insights = await analytics.get_insights(research_id)
    return {'insights': insights}

@app.get('/research/{research_id}/recommendations')
async def get_recommendations(research_id: str):
    recommendations = await analytics.get_recommendations(research_id)
    return {'recommendations': recommendations}

@app.get('/research/{research_id}/alerts')
async def get_alerts(research_id: str, acknowledged: Optional[bool] = None):
    alert_list = await alerts.get_alerts(research_id, acknowledged)
    return {'alerts': alert_list}

@app.post('/research/{research_id}/alerts/{alert_id}/acknowledge')
async def acknowledge_alert(research_id: str, alert_id: str, user: str):
    result = await alerts.acknowledge(alert_id, user)
    return {'acknowledged': result}

@app.get('/research/{research_id}/sources')
async def get_sources(research_id: str, validated_only: bool = False):
    sources = await research_engine.get_sources(research_id, validated_only)
    return {'sources': sources}

@app.get('/research/{research_id}/facts')
async def get_facts(research_id: str, verified_only: bool = False):
    facts = await research_engine.get_facts(research_id, verified_only)
    return {'facts': facts}

@app.get('/research/{research_id}/changes')
async def get_changes(research_id: str, significant_only: bool = False):
    changes = await monitor.get_changes(research_id, significant_only)
    return {'changes': changes}

@app.post('/research/{research_id}/monitor')
async def start_monitoring(research_id: str, interval: int = 3600):
    await monitor.start_monitoring(research_id, interval)
    return {'research_id': research_id, 'monitoring': True, 'interval': interval}

@app.delete('/research/{research_id}/monitor')
async def stop_monitoring(research_id: str):
    await monitor.stop_monitoring(research_id)
    return {'research_id': research_id, 'monitoring': False}

@app.get('/analytics/overview')
async def get_analytics_overview():
    overview = await analytics.get_overview()
    return overview

@app.get('/knowledge-graph/query')
async def query_knowledge_graph(query: str, depth: int = 2):
    results = await kg.query(query, depth)
    return {'results': results}

if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host='0.0.0.0', port=8000)