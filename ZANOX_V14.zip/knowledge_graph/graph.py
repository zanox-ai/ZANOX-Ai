"""
ZANOX V14 - Knowledge Graph
Neo4j-based knowledge graph for research entities
"""

import logging
from typing import Dict, List, Any, Optional

from shared.database import DatabaseManager

logger = logging.getLogger('zanox.knowledge_graph')

class KnowledgeGraph:
    def __init__(self):
        self.driver = None
    
    async def _get_driver(self):
        if self.driver is None:
            self.driver = await DatabaseManager.get_neo4j()
        return self.driver
    
    async def create_entity(self, entity_type: str, entity_id: str, properties: Dict) -> bool:
        driver = await self._get_driver()
        async with driver.session() as session:
            query = f"""
                MERGE (e:{entity_type} {{id: $id}})
                SET e += $properties
                RETURN e
            """
            result = await session.run(query, id=entity_id, properties=properties)
            record = await result.single()
            return record is not None
    
    async def create_relationship(self, from_type: str, from_id: str, rel_type: str, to_type: str, to_id: str, properties: Dict = None) -> bool:
        driver = await self._get_driver()
        async with driver.session() as session:
            query = f"""
                MATCH (a:{from_type} {{id: $from_id}}), (b:{to_type} {{id: $to_id}})
                MERGE (a)-[r:{rel_type}]->(b)
                SET r += $properties
                RETURN r
            """
            result = await session.run(query, from_id=from_id, to_id=to_id, properties=properties or {})
            record = await result.single()
            return record is not None
    
    async def query(self, query_text: str, depth: int = 2) -> List[Dict]:
        driver = await self._get_driver()
        async with driver.session() as session:
            cypher = f"""
                MATCH path = (n)-[*1..{depth}]-(m)
                WHERE n.name CONTAINS $query OR n.title CONTAINS $query
                RETURN path
                LIMIT 50
            """
            result = await session.run(cypher, query=query_text)
            records = []
            async for record in result:
                records.append({'path': str(record['path'])})
            return records
    
    async def get_entity(self, entity_type: str, entity_id: str) -> Optional[Dict]:
        driver = await self._get_driver()
        async with driver.session() as session:
            query = f"""
                MATCH (e:{entity_type} {{id: $id}})
                RETURN e
            """
            result = await session.run(query, id=entity_id)
            record = await result.single()
            return dict(record['e']) if record else None
    
    async def find_related(self, entity_type: str, entity_id: str, rel_type: Optional[str] = None, depth: int = 1) -> List[Dict]:
        driver = await self._get_driver()
        async with driver.session() as session:
            rel_filter = f'[:{rel_type}]' if rel_type else ''
            query = f"""
                MATCH (e:{entity_type} {{id: $id}})-{rel_filter}-(related)
                RETURN related
                LIMIT 100
            """
            result = await session.run(query, id=entity_id)
            records = []
            async for record in result:
                records.append(dict(record['related']))
            return records
    
    async def add_research_to_graph(self, research_id: str, sources: List[Dict], facts: List[Dict], insights: List[Dict]):
        await self.create_entity('Research', research_id, {'id': research_id, 'created_at': str(__import__('datetime').datetime.utcnow())})
        for source in sources:
            source_id = source.get('id', source.get('url', 'unknown'))
            await self.create_entity('Source', source_id, {'title': source.get('title', ''), 'url': source.get('url', ''), 'type': source.get('source_type', 'web')})
            await self.create_relationship('Research', research_id, 'CITES', 'Source', source_id)
        for fact in facts:
            fact_id = fact.get('id', 'unknown')
            await self.create_entity('Fact', fact_id, {'statement': fact.get('statement', ''), 'confidence': fact.get('confidence', 0)})
            await self.create_relationship('Research', research_id, 'CONTAINS', 'Fact', fact_id)
        for insight in insights:
            insight_id = insight.get('id', 'unknown')
            await self.create_entity('Insight', insight_id, {'title': insight.get('title', ''), 'category': insight.get('category', '')})
            await self.create_relationship('Research', research_id, 'GENERATES', 'Insight', insight_id)
        logger.info(f'Added research {research_id} to knowledge graph')
    
    async def get_subgraph(self, research_id: str) -> Dict:
        driver = await self._get_driver()
        async with driver.session() as session:
            query = """
                MATCH path = (r:Research {id: $id})-[:CITES|CONTAINS|GENERATES*1..3]-(n)
                RETURN path
            """
            result = await session.run(query, id=research_id)
            nodes = set()
            edges = []
            async for record in result:
                path = record['path']
                for node in path.nodes:
                    nodes.add((node.id, dict(node)))
                for rel in path.relationships:
                    edges.append({'from': rel.start_node.id, 'to': rel.end_node.id, 'type': rel.type})
            return {'nodes': [n[1] for n in nodes], 'edges': edges}