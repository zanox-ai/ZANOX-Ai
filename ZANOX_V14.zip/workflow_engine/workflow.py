"""
ZANOX V14 - Workflow Engine
Manages research workflows and state transitions
"""

import logging
from typing import Dict, List, Any, Optional, Callable
from enum import Enum
import asyncio

logger = logging.getLogger('zanox.workflow')

class WorkflowState(str, Enum):
    IDLE = 'idle'
    RUNNING = 'running'
    PAUSED = 'paused'
    COMPLETED = 'completed'
    FAILED = 'failed'
    CANCELLED = 'cancelled'

class WorkflowStep:
    def __init__(self, name: str, action: Callable, dependencies: List[str] = None, retries: int = 3):
        self.name = name
        self.action = action
        self.dependencies = dependencies or []
        self.retries = retries
        self.status = 'pending'
        self.result = None
        self.error = None

class WorkflowEngine:
    def __init__(self):
        self.workflows: Dict[str, Dict] = {}
        self.step_registry: Dict[str, WorkflowStep] = {}
    
    def register_step(self, name: str, action: Callable, dependencies: List[str] = None, retries: int = 3):
        self.step_registry[name] = WorkflowStep(name, action, dependencies, retries)
        logger.info(f'Registered workflow step: {name}')
    
    def create_workflow(self, workflow_id: str, steps: List[str], context: Dict = None) -> str:
        workflow_steps = []
        for step_name in steps:
            if step_name in self.step_registry:
                workflow_steps.append(self.step_registry[step_name])
            else:
                logger.warning(f'Step {step_name} not registered, skipping')
        self.workflows[workflow_id] = {'steps': workflow_steps, 'state': WorkflowState.IDLE, 'context': context or {}, 'current_step': 0}
        return workflow_id
    
    async def execute_workflow(self, workflow_id: str) -> Dict:
        workflow = self.workflows.get(workflow_id)
        if not workflow:
            return {'status': 'error', 'message': 'Workflow not found'}
        workflow['state'] = WorkflowState.RUNNING
        try:
            for i, step in enumerate(workflow['steps']):
                workflow['current_step'] = i
                logger.info(f'Executing step {i+1}/{len(workflow["steps"])}: {step.name}')
                
                # Check dependencies
                for dep in step.dependencies:
                    dep_step = next((s for s in workflow['steps'] if s.name == dep), None)
                    if dep_step and dep_step.status != 'completed':
                        logger.error(f'Dependency {dep} not completed for step {step.name}')
                        workflow['state'] = WorkflowState.FAILED
                        return {'status': 'failed', 'failed_step': step.name, 'reason': f'Dependency {dep} not met'}
                
                # Execute with retries
                for attempt in range(step.retries):
                    try:
                        step.result = await step.action(workflow['context'])
                        step.status = 'completed'
                        break
                    except Exception as e:
                        step.error = str(e)
                        logger.warning(f'Step {step.name} attempt {attempt+1} failed: {e}')
                        if attempt == step.retries - 1:
                            step.status = 'failed'
                            workflow['state'] = WorkflowState.FAILED
                            return {'status': 'failed', 'failed_step': step.name, 'error': str(e)}
                        await asyncio.sleep(2 ** attempt)
            
            workflow['state'] = WorkflowState.COMPLETED
            return {'status': 'completed', 'steps_executed': len(workflow['steps'])}
        except Exception as e:
            logger.error(f'Workflow {workflow_id} failed: {e}')
            workflow['state'] = WorkflowState.FAILED
            return {'status': 'failed', 'error': str(e)}
    
    async def pause_workflow(self, workflow_id: str):
        if workflow_id in self.workflows:
            self.workflows[workflow_id]['state'] = WorkflowState.PAUSED
    
    async def resume_workflow(self, workflow_id: str):
        if workflow_id in self.workflows and self.workflows[workflow_id]['state'] == WorkflowState.PAUSED:
            return await self.execute_workflow(workflow_id)
    
    def get_workflow_status(self, workflow_id: str) -> Dict:
        workflow = self.workflows.get(workflow_id)
        if not workflow:
            return {'status': 'not_found'}
        return {'state': workflow['state'].value, 'current_step': workflow['current_step'], 'total_steps': len(workflow['steps'])}