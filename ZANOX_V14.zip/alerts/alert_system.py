"""
ZANOX V14 - Alert System
Manages research alerts and notifications
"""

import logging
from typing import Dict, List, Any, Optional
from shared.models import Alert
from shared.database import DatabaseManager

logger = logging.getLogger('zanox.alerts')

class AlertSystem:
    def __init__(self): pass
    async def create_alert(self, research_id: str, alert_type: str, severity: str, message: str, **kwargs) -> Alert:
        alert = Alert(research_id=research_id, alert_type=alert_type, severity=severity, message=message, **kwargs)
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            await conn.execute('INSERT INTO alerts (research_id, alert_type, severity, message, detected_change, previous_value, current_value, source_id) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)', alert.research_id, alert.alert_type, alert.severity, alert.message, alert.detected_change, alert.previous_value, alert.current_value, alert.source_id)
        return alert
    async def get_alerts(self, research_id: str, acknowledged: Optional[bool] = None) -> List[Dict]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            if acknowledged is not None: rows = await conn.fetch('SELECT * FROM alerts WHERE research_id = $1 AND acknowledged = $2 ORDER BY created_at DESC', research_id, acknowledged)
            else: rows = await conn.fetch('SELECT * FROM alerts WHERE research_id = $1 ORDER BY created_at DESC', research_id)
            return [dict(row) for row in rows]
    async def acknowledge(self, alert_id: str, user: str) -> bool:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            await conn.execute('UPDATE alerts SET acknowledged = TRUE, acknowledged_by = $1, acknowledged_at = NOW() WHERE id = $2', user, alert_id)
            return True