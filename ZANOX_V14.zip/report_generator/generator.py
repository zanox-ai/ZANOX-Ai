"""
ZANOX V14 - Report Generator
Generates comprehensive research reports
"""

import logging
from typing import Dict, List, Any
from shared.models import ResearchReport
from shared.database import DatabaseManager

logger = logging.getLogger('zanox.report_generator')

class ReportGenerator:
    def __init__(self): pass
    async def generate(self, research_id: str, format: str = 'markdown') -> ResearchReport:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            research = await conn.fetchrow('SELECT * FROM research WHERE id = $1', research_id)
            facts = await conn.fetch('SELECT * FROM facts WHERE status = $1', 'verified')
            insights = await conn.fetch('SELECT * FROM insights WHERE research_id = $1', research_id)
            recommendations = await conn.fetch('SELECT * FROM recommendations WHERE research_id = $1', research_id)
            sources = await conn.fetch('SELECT * FROM sources WHERE reliability IN ($1, $2)', 'high', 'medium')
            sections = [{'title': 'Methodology', 'content': 'Automated research using ZANOX V14'}, {'title': 'Findings', 'content': f'{len(facts)} verified facts discovered'}, {'title': 'Analysis', 'content': f'{len(insights)} insights generated'}, {'title': 'Recommendations', 'content': f'{len(recommendations)} recommendations'}]
            exec_summary = f"Research completed with {len(facts)} facts, {len(insights)} insights, {len(recommendations)} recommendations."
            word_count = sum(len(s.get('content', '')) for s in sections)
            report = ResearchReport(research_id=research_id, title=research.get('title', 'Research Report'), executive_summary=exec_summary, sections=sections, sources_used=[str(s['id']) for s in sources], facts_presented=[str(f['id']) for f in facts], insights=[str(i['id']) for i in insights], recommendations=[str(r['id']) for r in recommendations], format=format, word_count=word_count, reading_time=word_count // 200)
            await conn.execute('INSERT INTO reports (research_id, title, executive_summary, sections, sources_used, facts_presented, insights, recommendations, format, word_count, reading_time) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)', report.research_id, report.title, report.executive_summary, str(report.sections), report.sources_used, report.facts_presented, report.insights, report.recommendations, format, word_count, report.reading_time)
            return report