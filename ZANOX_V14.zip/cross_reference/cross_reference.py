"""
ZANOX V14 - Cross Reference Engine
Cross-references facts and detects contradictions
"""

import logging
from typing import Dict, List, Any
from shared.utils import ZANOXUtils

logger = logging.getLogger('zanox.cross_reference')

class CrossReferenceEngine:
    def __init__(self):
        self.similarity_threshold = 0.85
    async def cross_reference_facts(self, facts: List[Dict]) -> Dict[str, List[Dict]]:
        groups = {}
        for i, fact in enumerate(facts):
            matched = False
            for key, group in groups.items():
                if ZANOXUtils.fuzzy_match(fact.get('statement', ''), group[0].get('statement', '')) > self.similarity_threshold:
                    groups[key].append(fact); matched = True; break
            if not matched:
                groups[fact.get('id', f'fact_{i}')] = [fact]
        return groups
    async def find_contradictions(self, facts: List[Dict]) -> List[Dict]:
        contradictions = []
        for i, f1 in enumerate(facts):
            for f2 in facts[i+1:]:
                if f1.get('status') == 'verified' and f2.get('status') == 'verified':
                    sim = ZANOXUtils.fuzzy_match(f1.get('statement', ''), f2.get('statement', ''))
                    if sim < 0.3 and self._same_topic(f1, f2):
                        contradictions.append({'fact_1': f1['id'], 'fact_2': f2['id'], 'severity': 'high'})
        return contradictions
    def _same_topic(self, f1: Dict, f2: Dict) -> bool:
        t1 = set(f1.get('metadata', {}).get('topics', []))
        t2 = set(f2.get('metadata', {}).get('topics', []))
        return bool(t1.intersection(t2))