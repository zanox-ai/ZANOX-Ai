"""
ZANOX V14 - Research Monitoring Engine
Monitors research subjects for changes
"""

import logging
import asyncio
from typing import Dict, List, Any
from datetime import datetime
from shared.database import DatabaseManager

logger = logging.getLogger('zanox.monitoring')

class ResearchMonitor:
    def __init__(self):
        self.monitored: Dict[str, Any] = {}
    async def start_monitoring(self, research_id: str, interval: int = 3600):
        self.monitored[research_id] = {'interval': interval, 'last_check': datetime.utcnow(), 'active': True}
        logger.info(f'Started monitoring research {research_id} every {interval}s')
    async def stop_monitoring(self, research_id: str):
        if research_id in self.monitored: self.monitored[research_id]['active'] = False; logger.info(f'Stopped monitoring research {research_id}')
    async def get_changes(self, research_id: str, significant_only: bool = False) -> List[Dict]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            query = 'SELECT * FROM change_records WHERE research_id = $1'
            if significant_only: query += ' AND significance > 0.7'
            rows = await conn.fetch(query, research_id)
            return [dict(row) for row in rows]