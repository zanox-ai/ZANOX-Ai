"""
ZANOX V14 - Data Enrichment Engine
Enriches data with additional metadata
"""

import logging
from typing import Dict, List, Any
from shared.utils import ZANOXUtils

logger = logging.getLogger('zanox.data_enrichment')

class DataEnrichmentEngine:
    def __init__(self): pass
    async def enrich(self, sources: List[Dict]) -> List[Dict]:
        enriched = []
        for src in sources:
            domain = ZANOXUtils.extract_domain(src.get('url', ''))
            src['domain'] = domain
            src['word_count'] = len(src.get('content', '').split())
            src['reading_time'] = src['word_count'] // 200
            enriched.append(src)
        return enriched