"""
ZANOX V14 - Citation Engine
Generates and manages academic citations
"""
import logging
from datetime import datetime
from typing import Dict, List, Any
from shared.models import Citation
from shared.database import DatabaseManager

logger = logging.getLogger('zanox.citation_engine')

class CitationEngine:
    def __init__(self):
        self.styles = {'apa': self._apa, 'mla': self._mla, 'chicago': self._chicago}
    def _apa(self, source: Dict, context: str) -> str:
        author = source.get('author', 'Unknown')
        year = source.get('publish_date', datetime.utcnow()).year if source.get('publish_date') else 'n.d.'
        return f"{author} ({year}). {source.get('title', '')}. Retrieved from {source.get('url', '')}"
    def _mla(self, source: Dict, context: str) -> str:
        return f"\"{source.get('title', '')}\". {source.get('author', 'Unknown')}, {source.get('url', '')}"
    def _chicago(self, source: Dict, context: str) -> str:
        return f"{source.get('author', 'Unknown')}. \"{source.get('title', '')}\". {source.get('url', '')}"
    async def generate_citation(self, source_id: str, fact_id: str, style: str = 'apa') -> Citation:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            source = await conn.fetchrow('SELECT * FROM sources WHERE id = $1', source_id)
            fact = await conn.fetchrow('SELECT * FROM facts WHERE id = $1', fact_id)
            if not source or not fact: raise ValueError('Source or fact not found')
            formatted = self.styles.get(style, self._apa)(dict(source), fact.get('statement', ''))
            citation = Citation(source_id=source_id, fact_id=fact_id, context=fact.get('statement', ''), citation_style=style, formatted_citation=formatted)
            await conn.execute('INSERT INTO citations (source_id, fact_id, context, citation_style, formatted_citation) VALUES ($1, $2, $3, $4, $5)', source_id, fact_id, citation.context, style, formatted)
            return citation
