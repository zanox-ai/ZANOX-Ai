"""
ZANOX V14 - Evidence Engine
Collects and evaluates evidence for facts
"""

import logging
from typing import Dict, List, Any
from shared.models import Evidence
from shared.database import DatabaseManager

logger = logging.getLogger('zanox.evidence_engine')

class EvidenceEngine:
    def __init__(self):
        self.evidence_types = ['direct', 'circumstantial', 'statistical', 'expert', 'documentary']
    async def collect_evidence(self, fact_id: str, sources: List[Dict]) -> List[Evidence]:
        evidence_list = []
        for src in sources:
            content = src.get('content', '')
            strength = min(len(content) / 5000, 1.0) if content else 0.0
            ev = Evidence(fact_id=fact_id, evidence_type='documentary', content=content[:1000], strength=strength, source_ids=[src.get('id')])
            evidence_list.append(ev)
        return evidence_list
    async def evaluate_strength(self, evidence_list: List[Evidence]) -> float:
        if not evidence_list: return 0.0
        return sum(e.strength for e in evidence_list) / len(evidence_list)