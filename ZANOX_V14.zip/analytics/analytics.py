"""
ZANOX V14 - Research Analytics
Analytics and metrics for research operations
"""

import logging
from typing import Dict, List, Any
from shared.database import DatabaseManager

logger = logging.getLogger('zanox.analytics')

class ResearchAnalytics:
    def __init__(self): pass
    async def get_insights(self, research_id: str) -> List[Dict]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            rows = await conn.fetch('SELECT * FROM insights WHERE research_id = $1 ORDER BY impact_score DESC', research_id)
            return [dict(row) for row in rows]
    async def get_recommendations(self, research_id: str) -> List[Dict]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            rows = await conn.fetch('SELECT * FROM recommendations WHERE research_id = $1 ORDER BY priority ASC', research_id)
            return [dict(row) for row in rows]
    async def get_overview(self) -> Dict:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            research_count = await conn.fetchval('SELECT COUNT(*) FROM research')
            source_count = await conn.fetchval('SELECT COUNT(*) FROM sources')
            fact_count = await conn.fetchval('SELECT COUNT(*) FROM facts')
            report_count = await conn.fetchval('SELECT COUNT(*) FROM reports')
            return {'total_research': research_count, 'total_sources': source_count, 'total_facts': fact_count, 'total_reports': report_count, 'version': 'V14'}