"""
ZANOX V14 - Research Agent System
Individual agent management and execution
"""

import logging
import asyncio
from typing import Dict, List, Any, Optional
from abc import ABC, abstractmethod

from shared.config import ZANOXConfig
from shared.utils import ZANOXUtils

logger = logging.getLogger('zanox.research_agents')

class ResearchAgent(ABC):
    def __init__(self, name: str, agent_type: str):
        self.name = name
        self.agent_type = agent_type
        self.status = 'idle'
        self.results = []
    
    @abstractmethod
    async def execute(self, context: Dict) -> Any:
        pass
    
    async def run(self, context: Dict) -> Any:
        self.status = 'running'
        try:
            result = await self.execute(context)
            self.status = 'completed'
            return result
        except Exception as e:
            self.status = 'failed'
            logger.error(f'Agent {self.name} failed: {e}')
            raise

class WebCrawlerAgent(ResearchAgent):
    def __init__(self):
        super().__init__('web_crawler', 'crawler')
    
    async def execute(self, context: Dict) -> List[Dict]:
        from web_intelligence.engine import WebIntelligenceEngine
        engine = WebIntelligenceEngine()
        query = context.get('query', '')
        sources = await engine.crawl(query, context.get('max_results', 20))
        return sources

class SearchAgent(ResearchAgent):
    def __init__(self):
        super().__init__('search_agent', 'search')
    
    async def execute(self, context: Dict) -> List[Dict]:
        from search_intelligence.engine import SearchIntelligenceEngine
        engine = SearchIntelligenceEngine()
        query = context.get('query', '')
        results = await engine.search(query, context.get('engines', ['google', 'bing']))
        return results

class NewsAgent(ResearchAgent):
    def __init__(self):
        super().__init__('news_agent', 'news')
    
    async def execute(self, context: Dict) -> List[Dict]:
        from news_intelligence.engine import NewsIntelligenceEngine
        engine = NewsIntelligenceEngine()
        query = context.get('query', '')
        articles = await engine.fetch_news(query, context.get('days', 7))
        return articles

class MarketAgent(ResearchAgent):
    def __init__(self):
        super().__init__('market_agent', 'market')
    
    async def execute(self, context: Dict) -> List[Dict]:
        from market_intelligence.engine import MarketIntelligenceEngine
        engine = MarketIntelligenceEngine()
        query = context.get('query', '')
        data = await engine.fetch_market_data(query, context.get('indicators', []))
        return data

class CompetitorAgent(ResearchAgent):
    def __init__(self):
        super().__init__('competitor_agent', 'competitor')
    
    async def execute(self, context: Dict) -> List[Dict]:
        from competitive_intelligence.engine import CompetitiveIntelligenceEngine
        engine = CompetitiveIntelligenceEngine()
        competitors = context.get('competitors', [])
        data = await engine.analyze_competitors(competitors, context.get('metrics', []))
        return data

class SocialAgent(ResearchAgent):
    def __init__(self):
        super().__init__('social_agent', 'social')
    
    async def execute(self, context: Dict) -> List[Dict]:
        from social_intelligence.engine import SocialIntelligenceEngine
        engine = SocialIntelligenceEngine()
        query = context.get('query', '')
        platforms = context.get('platforms', ['twitter', 'reddit', 'linkedin'])
        data = await engine.fetch_social_data(query, platforms)
        return data

class TrendAgent(ResearchAgent):
    def __init__(self):
        super().__init__('trend_agent', 'trend')
    
    async def execute(self, context: Dict) -> List[Dict]:
        from trend_intelligence.engine import TrendIntelligenceEngine
        engine = TrendIntelligenceEngine()
        query = context.get('query', '')
        trends = await engine.analyze_trends(query, context.get('timeframe', '1y'))
        return trends

class AcademicAgent(ResearchAgent):
    def __init__(self):
        super().__init__('academic_agent', 'academic')
    
    async def execute(self, context: Dict) -> List[Dict]:
        from search_intelligence.engine import SearchIntelligenceEngine
        engine = SearchIntelligenceEngine()
        query = context.get('query', '')
        papers = await engine.search_academic(query, context.get('databases', ['arxiv', 'semantic_scholar']))
        return papers

class FactCheckAgent(ResearchAgent):
    def __init__(self):
        super().__init__('fact_checker', 'fact_check')
    
    async def execute(self, context: Dict) -> List[Dict]:
        from fact_verification.verification import FactVerificationEngine
        engine = FactVerificationEngine()
        facts = context.get('facts', [])
        results = await engine.verify_batch(facts)
        return results

class ResearchAgentSystem:
    def __init__(self):
        self.agents: Dict[str, ResearchAgent] = {}
        self._register_default_agents()
    
    def _register_default_agents(self):
        self.register('web_crawler', WebCrawlerAgent())
        self.register('search_agent', SearchAgent())
        self.register('news_agent', NewsAgent())
        self.register('market_agent', MarketAgent())
        self.register('competitor_agent', CompetitorAgent())
        self.register('social_agent', SocialAgent())
        self.register('trend_agent', TrendAgent())
        self.register('academic_agent', AcademicAgent())
        self.register('fact_checker', FactCheckAgent())
    
    def register(self, name: str, agent: ResearchAgent):
        self.agents[name] = agent
        logger.info(f'Registered agent: {name}')
    
    async def execute_agent(self, name: str, context: Dict) -> Any:
        agent = self.agents.get(name)
        if not agent:
            raise ValueError(f'Agent {name} not found')
        return await agent.run(context)
    
    async def execute_parallel(self, agent_names: List[str], context: Dict) -> Dict[str, Any]:
        tasks = [self.execute_agent(name, context) for name in agent_names if name in self.agents]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        return {name: result for name, result in zip(agent_names, results)}
    
    def get_agent_status(self, name: str) -> Optional[str]:
        agent = self.agents.get(name)
        return agent.status if agent else None
    
    def list_agents(self) -> List[Dict]:
        return [{'name': name, 'type': agent.agent_type, 'status': agent.status} for name, agent in self.agents.items()]