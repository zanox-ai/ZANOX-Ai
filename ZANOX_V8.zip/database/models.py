"""SQLAlchemy models for Nexus Core V8."""
from datetime import datetime
from sqlalchemy import (
    Column, String, DateTime, Boolean, Float, Integer, BigInteger,
    JSON, Text, ForeignKey, Enum, Index, ARRAY
)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
import enum

Base = declarative_base()


class LeadStatus(str, enum.Enum):
    NEW = "new"
    CONTACTED = "contacted"
    QUALIFIED = "qualified"
    PROPOSAL = "proposal"
    NEGOTIATION = "negotiation"
    CLOSED_WON = "closed_won"
    CLOSED_LOST = "closed_lost"
    NURTURING = "nurturing"


class CampaignStatus(str, enum.Enum):
    DRAFT = "draft"
    SCHEDULED = "scheduled"
    ACTIVE = "active"
    PAUSED = "paused"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


class TicketStatus(str, enum.Enum):
    OPEN = "open"
    IN_PROGRESS = "in_progress"
    WAITING = "waiting"
    RESOLVED = "resolved"
    CLOSED = "closed"
    ESCALATED = "escalated"


class Priority(str, enum.Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class AIAgentModel(Base):
    """AI Agent model."""
    __tablename__ = "ai_agents"

    id = Column(String(36), primary_key=True)
    name = Column(String(100), nullable=False)
    agent_type = Column(String(50), nullable=False)
    provider = Column(String(50), nullable=False)
    model = Column(String(100), nullable=False)
    capabilities = Column(ARRAY(String), default=list)
    cost_per_1k_tokens = Column(Float, default=0.0)
    max_tokens = Column(Integer, default=128000)
    timeout = Column(Integer, default=30)
    status = Column(String(20), default="active")
    health_score = Column(Float, default=1.0)
    total_requests = Column(BigInteger, default=0)
    total_cost = Column(Float, default=0.0)
    avg_latency_ms = Column(Float, default=0.0)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, onupdate=datetime.utcnow)


class ContactModel(Base):
    """CRM Contact model."""
    __tablename__ = "contacts"

    id = Column(String(36), primary_key=True)
    email = Column(String(255), nullable=False, index=True)
    first_name = Column(String(100))
    last_name = Column(String(100))
    phone = Column(String(50))
    company = Column(String(200))
    title = Column(String(100))
    source = Column(String(50))
    status = Column(String(50), default="lead")
    score = Column(Float, default=0.0)
    tags = Column(ARRAY(String), default=list)
    custom_fields = Column(JSON, default=dict)
    last_activity = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, onupdate=datetime.utcnow)


class DealModel(Base):
    """Sales Deal model."""
    __tablename__ = "deals"

    id = Column(String(36), primary_key=True)
    name = Column(String(200), nullable=False)
    contact_id = Column(String(36), ForeignKey("contacts.id"))
    company_id = Column(String(36))
    stage = Column(String(50), default="prospect")
    status = Column(Enum(LeadStatus), default=LeadStatus.NEW)
    value = Column(Float, default=0.0)
    currency = Column(String(3), default="USD")
    probability = Column(Float, default=0.0)
    expected_close_date = Column(DateTime)
    actual_close_date = Column(DateTime)
    source = Column(String(50))
    owner_id = Column(String(36))
    tags = Column(ARRAY(String), default=list)
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, onupdate=datetime.utcnow)


class CampaignModel(Base):
    """Marketing Campaign model."""
    __tablename__ = "campaigns"

    id = Column(String(36), primary_key=True)
    name = Column(String(200), nullable=False)
    campaign_type = Column(String(50), nullable=False)
    channel = Column(String(50))
    status = Column(Enum(CampaignStatus), default=CampaignStatus.DRAFT)
    budget = Column(Float, default=0.0)
    spent = Column(Float, default=0.0)
    target_audience = Column(JSON, default=dict)
    content = Column(JSON, default=dict)
    schedule = Column(JSON, default=dict)
    metrics = Column(JSON, default=dict)
    ai_agent_id = Column(String(36), ForeignKey("ai_agents.id"))
    tags = Column(ARRAY(String), default=list)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, onupdate=datetime.utcnow)


class TicketModel(Base):
    """Support Ticket model."""
    __tablename__ = "tickets"

    id = Column(String(36), primary_key=True)
    subject = Column(String(500), nullable=False)
    description = Column(Text)
    contact_id = Column(String(36), ForeignKey("contacts.id"))
    status = Column(Enum(TicketStatus), default=TicketStatus.OPEN)
    priority = Column(Enum(Priority), default=Priority.MEDIUM)
    category = Column(String(50))
    assigned_to = Column(String(36))
    ai_resolution = Column(Boolean, default=False)
    sentiment_score = Column(Float)
    resolution_time_minutes = Column(Integer)
    satisfaction_score = Column(Float)
    tags = Column(ARRAY(String), default=list)
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, onupdate=datetime.utcnow)
    resolved_at = Column(DateTime)


class KpiModel(Base):
    """KPI model."""
    __tablename__ = "kpis"

    id = Column(String(36), primary_key=True)
    name = Column(String(100), nullable=False)
    category = Column(String(50), nullable=False)
    value = Column(Float)
    target = Column(Float)
    unit = Column(String(20))
    period = Column(String(20))
    trend = Column(String(20), default="stable")
    change_percent = Column(Float, default=0.0)
    metadata = Column(JSON, default=dict)
    timestamp = Column(DateTime, default=datetime.utcnow)


class RevenueModel(Base):
    """Revenue model."""
    __tablename__ = "revenue"

    id = Column(String(36), primary_key=True)
    source = Column(String(100), nullable=False)
    amount = Column(Float, default=0.0)
    currency = Column(String(3), default="USD")
    category = Column(String(50))
    period = Column(String(20))
    deal_id = Column(String(36), ForeignKey("deals.id"))
    campaign_id = Column(String(36), ForeignKey("campaigns.id"))
    metadata = Column(JSON, default=dict)
    timestamp = Column(DateTime, default=datetime.utcnow)


class ReportModel(Base):
    """Report model."""
    __tablename__ = "reports"

    id = Column(String(36), primary_key=True)
    name = Column(String(200), nullable=False)
    report_type = Column(String(50), nullable=False)
    format = Column(String(20), default="pdf")
    config = Column(JSON, default=dict)
    data = Column(JSON, default=dict)
    status = Column(String(20), default="pending")
    scheduled = Column(Boolean, default=False)
    schedule_config = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime)


class ForecastModel(Base):
    """Forecast model."""
    __tablename__ = "forecasts"

    id = Column(String(36), primary_key=True)
    name = Column(String(200), nullable=False)
    forecast_type = Column(String(50), nullable=False)
    model = Column(String(50), default="ensemble")
    horizon_days = Column(Integer, default=30)
    predictions = Column(JSON, default=list)
    confidence_intervals = Column(JSON, default=dict)
    accuracy = Column(Float)
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)


class ExperimentModel(Base):
    """Growth Experiment model."""
    __tablename__ = "experiments"

    id = Column(String(36), primary_key=True)
    name = Column(String(200), nullable=False)
    hypothesis = Column(Text)
    variant_a = Column(JSON, default=dict)
    variant_b = Column(JSON, default=dict)
    status = Column(String(20), default="draft")
    traffic_split = Column(Float, default=0.5)
    sample_size = Column(Integer)
    start_date = Column(DateTime)
    end_date = Column(DateTime)
    results = Column(JSON, default=dict)
    winner = Column(String(10))
    confidence_level = Column(Float)
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, onupdate=datetime.utcnow)
