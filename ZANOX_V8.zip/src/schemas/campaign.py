"""Campaign schemas for Nexus Core V8."""
from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field

from .base import BaseSchema, TimestampSchema, CampaignStatus


class CampaignCreate(BaseSchema):
    name: str = Field(..., max_length=200)
    campaign_type: str = Field(..., max_length=50)
    channel: Optional[str] = Field(None, max_length=50)
    budget: float = Field(default=0.0, ge=0)
    target_audience: Dict[str, Any] = Field(default_factory=dict)
    content: Dict[str, Any] = Field(default_factory=dict)
    schedule: Dict[str, Any] = Field(default_factory=dict)
    ai_agent_id: Optional[str] = None
    tags: List[str] = Field(default_factory=list)


class CampaignUpdate(BaseSchema):
    name: Optional[str] = Field(None, max_length=200)
    status: Optional[CampaignStatus] = None
    budget: Optional[float] = Field(None, ge=0)
    target_audience: Optional[Dict[str, Any]] = None
    content: Optional[Dict[str, Any]] = None
    schedule: Optional[Dict[str, Any]] = None
    tags: Optional[List[str]] = None


class CampaignResponse(TimestampSchema):
    id: str = Field(..., alias="campaign_id")
    name: str
    campaign_type: str
    channel: Optional[str] = None
    status: CampaignStatus
    budget: float
    spent: float
    target_audience: Dict[str, Any] = Field(default_factory=dict)
    content: Dict[str, Any] = Field(default_factory=dict)
    schedule: Dict[str, Any] = Field(default_factory=dict)
    metrics: Dict[str, Any] = Field(default_factory=dict)
    ai_agent_id: Optional[str] = None
    tags: List[str] = Field(default_factory=list)
    roi: float = 0.0


class CampaignListResponse(BaseSchema):
    campaigns: List[CampaignResponse]
    total: int
    total_budget: float
    total_spent: float
