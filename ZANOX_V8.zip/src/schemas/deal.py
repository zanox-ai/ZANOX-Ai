"""Deal/Sales schemas for Nexus Core V8."""
from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field

from .base import BaseSchema, TimestampSchema, LeadStatus


class DealCreate(BaseSchema):
    name: str = Field(..., max_length=200)
    contact_id: str
    company_id: Optional[str] = None
    stage: str = "prospect"
    value: float = Field(default=0.0, ge=0)
    currency: str = "USD"
    probability: float = Field(default=0.0, ge=0, le=100)
    expected_close_date: Optional[datetime] = None
    source: Optional[str] = None
    owner_id: Optional[str] = None
    tags: List[str] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class DealUpdate(BaseSchema):
    name: Optional[str] = Field(None, max_length=200)
    stage: Optional[str] = None
    status: Optional[LeadStatus] = None
    value: Optional[float] = Field(None, ge=0)
    probability: Optional[float] = Field(None, ge=0, le=100)
    expected_close_date: Optional[datetime] = None
    owner_id: Optional[str] = None
    tags: Optional[List[str]] = None
    metadata: Optional[Dict[str, Any]] = None


class DealResponse(TimestampSchema):
    id: str = Field(..., alias="deal_id")
    name: str
    contact_id: str
    company_id: Optional[str] = None
    stage: str
    status: LeadStatus
    value: float
    currency: str
    probability: float
    expected_close_date: Optional[datetime] = None
    actual_close_date: Optional[datetime] = None
    source: Optional[str] = None
    owner_id: Optional[str] = None
    tags: List[str] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class DealListResponse(BaseSchema):
    deals: List[DealResponse]
    total: int
    total_value: float
    avg_probability: float
