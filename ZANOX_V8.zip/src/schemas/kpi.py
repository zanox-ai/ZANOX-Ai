"""KPI schemas for Nexus Core V8."""
from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field

from .base import BaseSchema


class KpiCreate(BaseSchema):
    name: str = Field(..., max_length=100)
    category: str = Field(..., max_length=50)
    value: Optional[float] = None
    target: Optional[float] = None
    unit: Optional[str] = Field(None, max_length=20)
    period: str = "daily"
    metadata: Dict[str, Any] = Field(default_factory=dict)


class KpiResponse(BaseSchema):
    id: str = Field(..., alias="kpi_id")
    name: str
    category: str
    value: Optional[float] = None
    target: Optional[float] = None
    unit: Optional[str] = None
    period: str
    trend: str = "stable"
    change_percent: float = 0.0
    metadata: Dict[str, Any] = Field(default_factory=dict)
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class KpiListResponse(BaseSchema):
    kpis: List[KpiResponse]
    total: int
    categories: List[str]
