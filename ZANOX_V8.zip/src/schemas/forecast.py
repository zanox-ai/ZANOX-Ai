"""Forecast schemas for Nexus Core V8."""
from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field

from .base import BaseSchema, TimestampSchema


class ForecastCreate(BaseSchema):
    name: str = Field(..., max_length=200)
    forecast_type: str = Field(..., max_length=50)
    model: str = "ensemble"
    horizon_days: int = Field(default=30, ge=1, le=365)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class ForecastResponse(TimestampSchema):
    id: str = Field(..., alias="forecast_id")
    name: str
    forecast_type: str
    model: str
    horizon_days: int
    predictions: List[Dict[str, Any]] = Field(default_factory=list)
    confidence_intervals: Dict[str, Any] = Field(default_factory=dict)
    accuracy: Optional[float] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)


class ForecastListResponse(BaseSchema):
    forecasts: List[ForecastResponse]
    total: int
