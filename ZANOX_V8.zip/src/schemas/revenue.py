"""Revenue schemas for Nexus Core V8."""
from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field

from .base import BaseSchema


class RevenueCreate(BaseSchema):
    source: str = Field(..., max_length=100)
    amount: float = Field(..., ge=0)
    currency: str = "USD"
    category: Optional[str] = Field(None, max_length=50)
    period: str = "daily"
    deal_id: Optional[str] = None
    campaign_id: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)


class RevenueResponse(BaseSchema):
    id: str = Field(..., alias="revenue_id")
    source: str
    amount: float
    currency: str
    category: Optional[str] = None
    period: str
    deal_id: Optional[str] = None
    campaign_id: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class RevenueSummary(BaseSchema):
    total_revenue: float
    total_deals: int
    total_campaigns: int
    avg_deal_size: float
    mrr: float
    arr: float
    period: str
    currency: str = "USD"
    by_source: List[Dict[str, Any]]
    by_category: List[Dict[str, Any]]
    trend: List[Dict[str, Any]]
