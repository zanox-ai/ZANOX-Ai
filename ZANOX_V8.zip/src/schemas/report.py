"""Report schemas for Nexus Core V8."""
from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field

from .base import BaseSchema, TimestampSchema


class ReportCreate(BaseSchema):
    name: str = Field(..., max_length=200)
    report_type: str = Field(..., max_length=50)
    format: str = "pdf"
    config: Dict[str, Any] = Field(default_factory=dict)
    scheduled: bool = False
    schedule_config: Dict[str, Any] = Field(default_factory=dict)


class ReportResponse(TimestampSchema):
    id: str = Field(..., alias="report_id")
    name: str
    report_type: str
    format: str
    config: Dict[str, Any] = Field(default_factory=dict)
    data: Dict[str, Any] = Field(default_factory=dict)
    status: str = "pending"
    scheduled: bool = False
    schedule_config: Dict[str, Any] = Field(default_factory=dict)
    completed_at: Optional[datetime] = None


class ReportListResponse(BaseSchema):
    reports: List[ReportResponse]
    total: int
