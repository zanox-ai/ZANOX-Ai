"""Growth Experiment schemas for Nexus Core V8."""
from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field

from .base import BaseSchema, TimestampSchema


class ExperimentCreate(BaseSchema):
    name: str = Field(..., max_length=200)
    hypothesis: Optional[str] = None
    variant_a: Dict[str, Any] = Field(default_factory=dict)
    variant_b: Dict[str, Any] = Field(default_factory=dict)
    traffic_split: float = Field(default=0.5, ge=0, le=1)
    sample_size: Optional[int] = None
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)


class ExperimentResponse(TimestampSchema):
    id: str = Field(..., alias="experiment_id")
    name: str
    hypothesis: Optional[str] = None
    variant_a: Dict[str, Any] = Field(default_factory=dict)
    variant_b: Dict[str, Any] = Field(default_factory=dict)
    status: str = "draft"
    traffic_split: float
    sample_size: Optional[int] = None
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    results: Dict[str, Any] = Field(default_factory=dict)
    winner: Optional[str] = None
    confidence_level: Optional[float] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)


class ExperimentListResponse(BaseSchema):
    experiments: List[ExperimentResponse]
    total: int
