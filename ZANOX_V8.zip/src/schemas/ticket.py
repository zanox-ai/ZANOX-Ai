"""Support Ticket schemas for Nexus Core V8."""
from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field

from .base import BaseSchema, TimestampSchema, TicketStatus, Priority


class TicketCreate(BaseSchema):
    subject: str = Field(..., max_length=500)
    description: Optional[str] = None
    contact_id: str
    priority: Priority = Priority.MEDIUM
    category: Optional[str] = Field(None, max_length=50)
    tags: List[str] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class TicketUpdate(BaseSchema):
    subject: Optional[str] = Field(None, max_length=500)
    description: Optional[str] = None
    status: Optional[TicketStatus] = None
    priority: Optional[Priority] = None
    category: Optional[str] = Field(None, max_length=50)
    assigned_to: Optional[str] = None
    ai_resolution: Optional[bool] = None
    satisfaction_score: Optional[float] = Field(None, ge=0, le=10)
    tags: Optional[List[str]] = None


class TicketResponse(TimestampSchema):
    id: str = Field(..., alias="ticket_id")
    subject: str
    description: Optional[str] = None
    contact_id: str
    status: TicketStatus
    priority: Priority
    category: Optional[str] = None
    assigned_to: Optional[str] = None
    ai_resolution: bool = False
    sentiment_score: Optional[float] = None
    resolution_time_minutes: Optional[int] = None
    satisfaction_score: Optional[float] = None
    tags: List[str] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)
    resolved_at: Optional[datetime] = None


class TicketListResponse(BaseSchema):
    tickets: List[TicketResponse]
    total: int
    avg_resolution_time: Optional[float] = None
    satisfaction_avg: Optional[float] = None
