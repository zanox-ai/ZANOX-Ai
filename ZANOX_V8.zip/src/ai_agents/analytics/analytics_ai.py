"""Analytics AI Agent for Nexus Core V8.

Handles data processing, insight generation, and anomaly detection.
"""
from typing import List, Dict, Any, Optional
import statistics


class AnalyticsAIAgent:
    """AI agent for analytics operations."""

    def __init__(self, model_client, config: Dict[str, Any]):
        self.client = model_client
        self.config = config
        self.capabilities = [
            "data_processing",
            "insight_generation",
            "anomaly_detection",
            "trend_analysis",
            "predictive_modeling",
        ]

    async def detect_anomalies(self, data: List[float], threshold: float = 2.0) -> List[Dict[str, Any]]:
        """Detect anomalies in time series data."""
        if len(data) < 3:
            return []

        mean = statistics.mean(data)
        std_dev = statistics.stdev(data) if len(data) > 1 else 0

        anomalies = []
        for i, value in enumerate(data):
            if std_dev > 0 and abs(value - mean) > threshold * std_dev:
                anomalies.append({
                    "index": i,
                    "value": value,
                    "expected": mean,
                    "deviation": abs(value - mean) / std_dev,
                })

        return anomalies

    async def generate_insights(self, metrics: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Generate insights from metrics."""
        insights = []

        if metrics.get("revenue_growth", 0) > 0.1:
            insights.append({
                "type": "positive",
                "message": "Revenue growth is strong at 10%+",
                "recommendation": "Invest in scaling sales team",
            })

        if metrics.get("churn_rate", 0) > 0.05:
            insights.append({
                "type": "warning",
                "message": "Churn rate is above 5%",
                "recommendation": "Implement retention program",
            })

        if metrics.get("support_tickets", 0) > 100:
            insights.append({
                "type": "alert",
                "message": "Support ticket volume is high",
                "recommendation": "Review product stability",
            })

        return insights

    async def predict_trend(self, historical: List[float], horizon: int = 30) -> List[float]:
        """Predict future trend."""
        if not historical:
            return [0] * horizon

        avg = sum(historical) / len(historical)
        trend = (historical[-1] - historical[0]) / len(historical) if len(historical) > 1 else 0

        predictions = []
        for i in range(1, horizon + 1):
            predictions.append(avg + trend * i)

        return predictions
