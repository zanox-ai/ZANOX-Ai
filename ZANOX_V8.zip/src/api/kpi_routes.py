"""KPI API routes for Nexus Core V8."""
from typing import List
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from ..schemas.kpi import KpiCreate, KpiResponse, KpiListResponse
from ..engines.kpi.kpi_engine import KPITrackingEngine

router = APIRouter()


def get_db():
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    engine = create_engine("postgresql://nexus:nexus_secret_2026@postgres:5432/nexus_core_v8")
    SessionLocal = sessionmaker(bind=engine)
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.post("/", response_model=KpiResponse)
async def create_kpi(kpi: KpiCreate, db: Session = Depends(get_db)):
    engine = KPITrackingEngine(db)
    return engine.create_kpi(kpi)


@router.get("/")
async def get_kpis(period: str = "daily", db: Session = Depends(get_db)):
    engine = KPITrackingEngine(db)
    kpis = engine.calculate_kpis(period)
    return KpiListResponse(kpis=kpis, total=len(kpis), categories=list(set(k.category for k in kpis)))


@router.get("/{kpi_name}/trend")
async def get_kpi_trend(kpi_name: str, days: int = 30, db: Session = Depends(get_db)):
    engine = KPITrackingEngine(db)
    return engine.get_kpi_trend(kpi_name, days)
