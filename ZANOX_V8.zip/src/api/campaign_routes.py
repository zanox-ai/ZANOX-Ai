"""Campaign API routes for Nexus Core V8."""
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from ..schemas.campaign import CampaignCreate, CampaignUpdate, CampaignResponse, CampaignListResponse, CampaignStatus
from ..engines.marketing.marketing_engine import MarketingAutomationEngine

router = APIRouter()


def get_db():
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    engine = create_engine("postgresql://nexus:nexus_secret_2026@postgres:5432/nexus_core_v8")
    SessionLocal = sessionmaker(bind=engine)
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.post("/", response_model=CampaignResponse, status_code=status.HTTP_201_CREATED)
async def create_campaign(campaign: CampaignCreate, db: Session = Depends(get_db)):
    engine = MarketingAutomationEngine(db)
    return engine.create_campaign(campaign)


@router.get("/", response_model=CampaignListResponse)
async def list_campaigns(
    status: Optional[CampaignStatus] = None,
    db: Session = Depends(get_db),
):
    engine = MarketingAutomationEngine(db)
    return engine.list_campaigns(status=status)


@router.post("/{campaign_id}/launch", response_model=CampaignResponse)
async def launch_campaign(campaign_id: str, db: Session = Depends(get_db)):
    engine = MarketingAutomationEngine(db)
    return engine.launch_campaign(campaign_id)


@router.get("/{campaign_id}/roi")
async def get_campaign_roi(campaign_id: str, db: Session = Depends(get_db)):
    engine = MarketingAutomationEngine(db)
    return {"campaign_id": campaign_id, "roi": engine.calculate_roi(campaign_id)}
