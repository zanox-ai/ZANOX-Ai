"""Experiment API routes for Nexus Core V8."""
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from ..schemas.experiment import ExperimentCreate, ExperimentResponse, ExperimentListResponse
from ..engines.growth.growth_optimizer import GrowthOptimizationLayer

router = APIRouter()


def get_db():
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    engine = create_engine("postgresql://nexus:nexus_secret_2026@postgres:5432/nexus_core_v8")
    SessionLocal = sessionmaker(bind=engine)
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.post("/", response_model=ExperimentResponse, status_code=status.HTTP_201_CREATED)
async def create_experiment(experiment: ExperimentCreate, db: Session = Depends(get_db)):
    engine = GrowthOptimizationLayer(db)
    return engine.create_experiment(experiment)


@router.post("/{experiment_id}/start", response_model=ExperimentResponse)
async def start_experiment(experiment_id: str, db: Session = Depends(get_db)):
    engine = GrowthOptimizationLayer(db)
    return engine.start_experiment(experiment_id)


@router.post("/{experiment_id}/stop", response_model=ExperimentResponse)
async def stop_experiment(experiment_id: str, db: Session = Depends(get_db)):
    engine = GrowthOptimizationLayer(db)
    return engine.stop_experiment(experiment_id)


@router.get("/metrics")
async def get_growth_metrics(db: Session = Depends(get_db)):
    engine = GrowthOptimizationLayer(db)
    return engine.get_growth_metrics()
