"""Forecast API routes for Nexus Core V8."""
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from ..schemas.forecast import ForecastCreate, ForecastResponse, ForecastListResponse
from ..engines.forecasting.forecasting_engine import ForecastingEngine

router = APIRouter()


def get_db():
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    engine = create_engine("postgresql://nexus:nexus_secret_2026@postgres:5432/nexus_core_v8")
    SessionLocal = sessionmaker(bind=engine)
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.post("/", response_model=ForecastResponse, status_code=status.HTTP_201_CREATED)
async def create_forecast(forecast: ForecastCreate, db: Session = Depends(get_db)):
    engine = ForecastingEngine(db)
    return engine.create_forecast(forecast)


@router.get("/", response_model=ForecastListResponse)
async def list_forecasts(
    forecast_type: Optional[str] = None,
    db: Session = Depends(get_db),
):
    engine = ForecastingEngine(db)
    return engine.list_forecasts(forecast_type=forecast_type)
