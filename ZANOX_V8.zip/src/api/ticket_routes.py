"""Ticket API routes for Nexus Core V8."""
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from ..schemas.ticket import TicketCreate, TicketUpdate, TicketResponse, TicketListResponse, TicketStatus, Priority
from ..engines.support.support_system import CustomerSupportSystem

router = APIRouter()


def get_db():
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    engine = create_engine("postgresql://nexus:nexus_secret_2026@postgres:5432/nexus_core_v8")
    SessionLocal = sessionmaker(bind=engine)
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.post("/", response_model=TicketResponse, status_code=status.HTTP_201_CREATED)
async def create_ticket(ticket: TicketCreate, db: Session = Depends(get_db)):
    engine = CustomerSupportSystem(db)
    return engine.create_ticket(ticket)


@router.get("/", response_model=TicketListResponse)
async def list_tickets(
    status: Optional[TicketStatus] = None,
    priority: Optional[Priority] = None,
    db: Session = Depends(get_db),
):
    engine = CustomerSupportSystem(db)
    return engine.list_tickets(status=status, priority=priority)


@router.get("/metrics")
async def get_support_metrics(days: int = 30, db: Session = Depends(get_db)):
    engine = CustomerSupportSystem(db)
    return engine.get_support_metrics(days)
