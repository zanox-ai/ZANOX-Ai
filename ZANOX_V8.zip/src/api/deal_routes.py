"""Deal API routes for Nexus Core V8."""
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from ..schemas.deal import DealCreate, DealUpdate, DealResponse, DealListResponse
from ..engines.sales.sales_pipeline import SalesPipelineEngine

router = APIRouter()


def get_db():
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    engine = create_engine("postgresql://nexus:nexus_secret_2026@postgres:5432/nexus_core_v8")
    SessionLocal = sessionmaker(bind=engine)
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.post("/", response_model=DealResponse, status_code=status.HTTP_201_CREATED)
async def create_deal(deal: DealCreate, db: Session = Depends(get_db)):
    engine = SalesPipelineEngine(db)
    return engine.create_deal(deal)


@router.get("/", response_model=DealListResponse)
async def list_deals(
    stage: Optional[str] = None,
    status: Optional[str] = None,
    db: Session = Depends(get_db),
):
    from ..schemas.base import LeadStatus
    s = LeadStatus(status) if status else None
    engine = SalesPipelineEngine(db)
    return engine.list_deals(stage=stage, status=s)


@router.get("/{deal_id}", response_model=DealResponse)
async def get_deal(deal_id: str, db: Session = Depends(get_db)):
    engine = SalesPipelineEngine(db)
    deal = engine.get_deal(deal_id)
    if not deal:
        raise HTTPException(status_code=404, detail="Deal not found")
    return deal


@router.post("/{deal_id}/move")
async def move_deal(deal_id: str, new_stage: str, db: Session = Depends(get_db)):
    engine = SalesPipelineEngine(db)
    return engine.move_deal(deal_id, new_stage)


@router.get("/pipeline/summary")
async def get_pipeline_summary(db: Session = Depends(get_db)):
    engine = SalesPipelineEngine(db)
    return engine.get_pipeline_summary()


@router.get("/pipeline/forecast")
async def forecast_pipeline(days: int = 90, db: Session = Depends(get_db)):
    engine = SalesPipelineEngine(db)
    return engine.forecast_pipeline(days)
