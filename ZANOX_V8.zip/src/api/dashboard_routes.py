"""Dashboard API routes for Nexus Core V8."""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from ..engines.bi.bi_dashboard import BIDashboardEngine

router = APIRouter()


def get_db():
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    engine = create_engine("postgresql://nexus:nexus_secret_2026@postgres:5432/nexus_core_v8")
    SessionLocal = sessionmaker(bind=engine)
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.get("/{dashboard_type}")
async def get_dashboard(dashboard_type: str = "executive", db: Session = Depends(get_db)):
    engine = BIDashboardEngine(db)
    return engine.generate_dashboard(dashboard_type)
