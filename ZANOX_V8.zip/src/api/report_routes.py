"""Report API routes for Nexus Core V8."""
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from ..schemas.report import ReportCreate, ReportResponse, ReportListResponse
from ..engines.reporting.reporting_system import ReportingSystem

router = APIRouter()


def get_db():
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    engine = create_engine("postgresql://nexus:nexus_secret_2026@postgres:5432/nexus_core_v8")
    SessionLocal = sessionmaker(bind=engine)
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.post("/", response_model=ReportResponse, status_code=status.HTTP_201_CREATED)
async def create_report(report: ReportCreate, db: Session = Depends(get_db)):
    engine = ReportingSystem(db)
    return engine.create_report(report)


@router.get("/", response_model=ReportListResponse)
async def list_reports(
    report_type: Optional[str] = None,
    db: Session = Depends(get_db),
):
    engine = ReportingSystem(db)
    return engine.list_reports(report_type=report_type)
