"""Revenue API routes for Nexus Core V8."""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from ..schemas.revenue import RevenueCreate, RevenueSummary
from ..engines.revenue.revenue_analytics import RevenueAnalyticsEngine

router = APIRouter()


def get_db():
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    engine = create_engine("postgresql://nexus:nexus_secret_2026@postgres:5432/nexus_core_v8")
    SessionLocal = sessionmaker(bind=engine)
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.post("/", response_model=RevenueSummary)
async def record_revenue(revenue: RevenueCreate, db: Session = Depends(get_db)):
    engine = RevenueAnalyticsEngine(db)
    engine.record_revenue(revenue)
    return engine.get_revenue_summary()


@router.get("/summary")
async def get_revenue_summary(period: str = "monthly", days: int = 30, db: Session = Depends(get_db)):
    engine = RevenueAnalyticsEngine(db)
    return engine.get_revenue_summary(period, days)


@router.get("/forecast")
async def get_revenue_forecast(days: int = 90, db: Session = Depends(get_db)):
    engine = RevenueAnalyticsEngine(db)
    return engine.get_revenue_forecast(days)
