"""Contact API routes for Nexus Core V8."""
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from ..schemas.contact import ContactCreate, ContactUpdate, ContactResponse, ContactListResponse
from ..engines.crm.crm_engine import CRMManagementLayer
from database.models import ContactModel

router = APIRouter()


def get_db():
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    engine = create_engine("postgresql://nexus:nexus_secret_2026@postgres:5432/nexus_core_v8")
    SessionLocal = sessionmaker(bind=engine)
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.post("/", response_model=ContactResponse, status_code=status.HTTP_201_CREATED)
async def create_contact(contact: ContactCreate, db: Session = Depends(get_db)):
    engine = CRMManagementLayer(db)
    return engine.create_contact(contact)


@router.get("/", response_model=ContactListResponse)
async def list_contacts(
    status: Optional[str] = None,
    company: Optional[str] = None,
    min_score: Optional[float] = None,
    db: Session = Depends(get_db),
):
    engine = CRMManagementLayer(db)
    return engine.list_contacts(status=status, company=company, min_score=min_score)


@router.get("/{contact_id}", response_model=ContactResponse)
async def get_contact(contact_id: str, db: Session = Depends(get_db)):
    engine = CRMManagementLayer(db)
    contact = engine.get_contact(contact_id)
    if not contact:
        raise HTTPException(status_code=404, detail="Contact not found")
    return contact


@router.put("/{contact_id}", response_model=ContactResponse)
async def update_contact(contact_id: str, contact: ContactUpdate, db: Session = Depends(get_db)):
    engine = CRMManagementLayer(db)
    updated = engine.update_contact(contact_id, contact)
    if not updated:
        raise HTTPException(status_code=404, detail="Contact not found")
    return updated
