"""Growth Optimization Layer for Nexus Core V8.

Manages growth experiments and optimization.
"""
import uuid
from datetime import datetime
from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session

from ..schemas.experiment import ExperimentCreate, ExperimentResponse, ExperimentListResponse
from database.models import ExperimentModel


class GrowthOptimizationLayer:
    """Manages growth experiments and A/B tests."""

    def __init__(self, db_session: Session):
        self.db = db_session

    def create_experiment(self, experiment_data: ExperimentCreate) -> ExperimentResponse:
        """Create a new growth experiment."""
        experiment_id = str(uuid.uuid4())

        experiment = ExperimentModel(
            id=experiment_id,
            name=experiment_data.name,
            hypothesis=experiment_data.hypothesis,
            variant_a=experiment_data.variant_a,
            variant_b=experiment_data.variant_b,
            traffic_split=experiment_data.traffic_split,
            sample_size=experiment_data.sample_size,
            start_date=experiment_data.start_date,
            end_date=experiment_data.end_date,
            status="draft",
            metadata=experiment_data.metadata,
            created_at=datetime.utcnow(),
        )

        self.db.add(experiment)
        self.db.commit()
        self.db.refresh(experiment)

        return self._to_response(experiment)

    def start_experiment(self, experiment_id: str) -> ExperimentResponse:
        """Start an experiment."""
        experiment = self.db.query(ExperimentModel).filter(ExperimentModel.id == experiment_id).first()
        if not experiment:
            raise ValueError("Experiment not found")

        experiment.status = "running"
        experiment.start_date = datetime.utcnow()
        experiment.updated_at = datetime.utcnow()
        self.db.commit()

        return self._to_response(experiment)

    def stop_experiment(self, experiment_id: str) -> ExperimentResponse:
        """Stop an experiment and determine winner."""
        experiment = self.db.query(ExperimentModel).filter(ExperimentModel.id == experiment_id).first()
        if not experiment:
            raise ValueError("Experiment not found")

        experiment.status = "completed"
        experiment.end_date = datetime.utcnow()

        # Determine winner
        winner = self._determine_winner(experiment)
        experiment.winner = winner
        experiment.confidence_level = self._calculate_confidence(experiment)

        experiment.updated_at = datetime.utcnow()
        self.db.commit()

        return self._to_response(experiment)

    def record_result(self, experiment_id: str, variant: str, metric: str, value: float):
        """Record experiment result."""
        experiment = self.db.query(ExperimentModel).filter(ExperimentModel.id == experiment_id).first()
        if not experiment:
            raise ValueError("Experiment not found")

        results = experiment.results or {}
        if variant not in results:
            results[variant] = {}
        results[variant][metric] = value
        experiment.results = results

        self.db.commit()

    def _determine_winner(self, experiment: ExperimentModel) -> Optional[str]:
        """Determine winning variant."""
        results = experiment.results or {}

        if not results or "a" not in results or "b" not in results:
            return None

        # Compare conversion rates
        a_rate = results["a"].get("conversion_rate", 0)
        b_rate = results["b"].get("conversion_rate", 0)

        if b_rate > a_rate:
            return "b"
        elif a_rate > b_rate:
            return "a"
        else:
            return "tie"

    def _calculate_confidence(self, experiment: ExperimentModel) -> Optional[float]:
        """Calculate statistical confidence."""
        # Simplified confidence calculation
        return 0.95

    def get_experiment(self, experiment_id: str) -> Optional[ExperimentResponse]:
        """Get experiment by ID."""
        experiment = self.db.query(ExperimentModel).filter(ExperimentModel.id == experiment_id).first()
        if not experiment:
            return None
        return self._to_response(experiment)

    def list_experiments(
        self,
        status: Optional[str] = None,
        skip: int = 0,
        limit: int = 100,
    ) -> ExperimentListResponse:
        """List experiments."""
        query = self.db.query(ExperimentModel)

        if status:
            query = query.filter(ExperimentModel.status == status)

        experiments = query.order_by(ExperimentModel.created_at.desc()).offset(skip).limit(limit).all()
        total = query.count()

        return ExperimentListResponse(
            experiments=[self._to_response(e) for e in experiments],
            total=total,
        )

    def get_growth_metrics(self) -> Dict[str, Any]:
        """Get overall growth metrics."""
        total_experiments = self.db.query(ExperimentModel).count()
        running = self.db.query(ExperimentModel).filter(ExperimentModel.status == "running").count()
        completed = self.db.query(ExperimentModel).filter(ExperimentModel.status == "completed").count()

        winners = self.db.query(ExperimentModel).filter(
            ExperimentModel.status == "completed",
            ExperimentModel.winner.isnot(None),
        ).count()

        return {
            "total_experiments": total_experiments,
            "running": running,
            "completed": completed,
            "winners": winners,
            "success_rate": winners / completed if completed > 0 else 0,
        }

    def _to_response(self, experiment: ExperimentModel) -> ExperimentResponse:
        """Convert DB model to response."""
        return ExperimentResponse(
            experiment_id=experiment.id,
            name=experiment.name,
            hypothesis=experiment.hypothesis,
            variant_a=experiment.variant_a or {},
            variant_b=experiment.variant_b or {},
            status=experiment.status,
            traffic_split=experiment.traffic_split,
            sample_size=experiment.sample_size,
            start_date=experiment.start_date,
            end_date=experiment.end_date,
            results=experiment.results or {},
            winner=experiment.winner,
            confidence_level=experiment.confidence_level,
            metadata=experiment.metadata or {},
            created_at=experiment.created_at,
            updated_at=experiment.updated_at,
        )
