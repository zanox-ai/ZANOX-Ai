"""Customer Support System for Nexus Core V8.

Manages support tickets with AI-powered resolution.
"""
import uuid
from datetime import datetime
from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session
from sqlalchemy import func

from ..schemas.ticket import TicketCreate, TicketUpdate, TicketResponse, TicketListResponse, TicketStatus, Priority
from database.models import TicketModel, ContactModel


class CustomerSupportSystem:
    """Manages customer support tickets."""

    def __init__(self, db_session: Session, ai_client=None):
        self.db = db_session
        self.ai = ai_client

    def create_ticket(self, ticket_data: TicketCreate) -> TicketResponse:
        """Create a new support ticket."""
        ticket_id = str(uuid.uuid4())

        # Analyze sentiment if AI available
        sentiment = None
        if self.ai and ticket_data.description:
            sentiment = self._analyze_sentiment(ticket_data.description)

        ticket = TicketModel(
            id=ticket_id,
            subject=ticket_data.subject,
            description=ticket_data.description,
            contact_id=ticket_data.contact_id,
            status=TicketStatus.OPEN.value,
            priority=ticket_data.priority.value,
            category=ticket_data.category,
            assigned_to=None,
            ai_resolution=False,
            sentiment_score=sentiment,
            tags=ticket_data.tags,
            metadata=ticket_data.metadata,
            created_at=datetime.utcnow(),
        )

        self.db.add(ticket)
        self.db.commit()
        self.db.refresh(ticket)

        # Auto-route ticket
        self._route_ticket(ticket)

        # Try AI resolution for low priority tickets
        if ticket.priority in [Priority.LOW.value, Priority.MEDIUM.value] and self.ai:
            self._attempt_ai_resolution(ticket)

        return self._to_response(ticket)

    def update_ticket(self, ticket_id: str, ticket_data: TicketUpdate) -> Optional[TicketResponse]:
        """Update a ticket."""
        ticket = self.db.query(TicketModel).filter(TicketModel.id == ticket_id).first()
        if not ticket:
            return None

        if ticket_data.subject is not None:
            ticket.subject = ticket_data.subject
        if ticket_data.description is not None:
            ticket.description = ticket_data.description
        if ticket_data.status is not None:
            ticket.status = ticket_data.status.value
            if ticket_data.status == TicketStatus.RESOLVED:
                ticket.resolved_at = datetime.utcnow()
                if ticket.created_at:
                    ticket.resolution_time_minutes = int((datetime.utcnow() - ticket.created_at).total_seconds() / 60)
        if ticket_data.priority is not None:
            ticket.priority = ticket_data.priority.value
        if ticket_data.category is not None:
            ticket.category = ticket_data.category
        if ticket_data.assigned_to is not None:
            ticket.assigned_to = ticket_data.assigned_to
        if ticket_data.ai_resolution is not None:
            ticket.ai_resolution = ticket_data.ai_resolution
        if ticket_data.satisfaction_score is not None:
            ticket.satisfaction_score = ticket_data.satisfaction_score
        if ticket_data.tags is not None:
            ticket.tags = ticket_data.tags

        ticket.updated_at = datetime.utcnow()
        self.db.commit()
        self.db.refresh(ticket)

        return self._to_response(ticket)

    def get_ticket(self, ticket_id: str) -> Optional[TicketResponse]:
        """Get ticket by ID."""
        ticket = self.db.query(TicketModel).filter(TicketModel.id == ticket_id).first()
        if not ticket:
            return None
        return self._to_response(ticket)

    def list_tickets(
        self,
        status: Optional[TicketStatus] = None,
        priority: Optional[Priority] = None,
        assigned_to: Optional[str] = None,
        category: Optional[str] = None,
        skip: int = 0,
        limit: int = 100,
    ) -> TicketListResponse:
        """List tickets."""
        query = self.db.query(TicketModel)

        if status:
            query = query.filter(TicketModel.status == status.value)
        if priority:
            query = query.filter(TicketModel.priority == priority.value)
        if assigned_to:
            query = query.filter(TicketModel.assigned_to == assigned_to)
        if category:
            query = query.filter(TicketModel.category == category)

        tickets = query.order_by(TicketModel.created_at.desc()).offset(skip).limit(limit).all()
        total = query.count()

        # Calculate averages
        resolved_tickets = [t for t in tickets if t.resolution_time_minutes]
        avg_resolution = sum(t.resolution_time_minutes for t in resolved_tickets) / len(resolved_tickets) if resolved_tickets else None

        scored_tickets = [t for t in tickets if t.satisfaction_score]
        satisfaction_avg = sum(t.satisfaction_score for t in scored_tickets) / len(scored_tickets) if scored_tickets else None

        return TicketListResponse(
            tickets=[self._to_response(t) for t in tickets],
            total=total,
            avg_resolution_time=avg_resolution,
            satisfaction_avg=satisfaction_avg,
        )

    def get_support_metrics(self, days: int = 30) -> Dict[str, Any]:
        """Get support metrics."""
        cutoff = datetime.utcnow() - __import__("datetime").timedelta(days=days)

        total_tickets = self.db.query(TicketModel).filter(TicketModel.created_at >= cutoff).count()

        resolved = self.db.query(TicketModel).filter(
            TicketModel.created_at >= cutoff,
            TicketModel.status == TicketStatus.RESOLVED.value,
        ).count()

        ai_resolved = self.db.query(TicketModel).filter(
            TicketModel.created_at >= cutoff,
            TicketModel.ai_resolution == True,
        ).count()

        escalated = self.db.query(TicketModel).filter(
            TicketModel.created_at >= cutoff,
            TicketModel.status == TicketStatus.ESCALATED.value,
        ).count()

        avg_resolution = self.db.query(
            func.avg(TicketModel.resolution_time_minutes)
        ).filter(
            TicketModel.created_at >= cutoff,
            TicketModel.resolution_time_minutes.isnot(None),
        ).scalar()

        avg_satisfaction = self.db.query(
            func.avg(TicketModel.satisfaction_score)
        ).filter(
            TicketModel.created_at >= cutoff,
            TicketModel.satisfaction_score.isnot(None),
        ).scalar()

        return {
            "total_tickets": total_tickets,
            "resolved": resolved,
            "ai_resolved": ai_resolved,
            "escalated": escalated,
            "resolution_rate": resolved / total_tickets if total_tickets > 0 else 0,
            "ai_resolution_rate": ai_resolved / total_tickets if total_tickets > 0 else 0,
            "escalation_rate": escalated / total_tickets if total_tickets > 0 else 0,
            "avg_resolution_time_minutes": float(avg_resolution) if avg_resolution else 0,
            "avg_satisfaction_score": float(avg_satisfaction) if avg_satisfaction else 0,
            "period_days": days,
        }

    def _analyze_sentiment(self, text: str) -> float:
        """Analyze sentiment of ticket text."""
        # Simple keyword-based sentiment
        positive_words = ["good", "great", "excellent", "happy", "satisfied", "thanks", "love"]
        negative_words = ["bad", "terrible", "awful", "angry", "frustrated", "disappointed", "hate", "problem", "issue", "broken"]

        text_lower = text.lower()
        positive_count = sum(1 for word in positive_words if word in text_lower)
        negative_count = sum(1 for word in negative_words if word in text_lower)

        if positive_count + negative_count == 0:
            return 0.5

        return positive_count / (positive_count + negative_count)

    def _route_ticket(self, ticket: TicketModel):
        """Route ticket to appropriate agent."""
        # Simple routing based on category
        category_agents = {
            "technical": "tech_team",
            "billing": "billing_team",
            "sales": "sales_team",
            "general": "support_team",
        }

        if ticket.category and ticket.category in category_agents:
            ticket.assigned_to = category_agents[ticket.category]
            self.db.commit()

    def _attempt_ai_resolution(self, ticket: TicketModel):
        """Attempt AI auto-resolution."""
        # In production, this would query knowledge base and attempt resolution
        # For now, mark as AI-assisted
        ticket.metadata = ticket.metadata or {}
        ticket.metadata["ai_assisted"] = True
        self.db.commit()

    def _to_response(self, ticket: TicketModel) -> TicketResponse:
        """Convert DB model to response."""
        return TicketResponse(
            ticket_id=ticket.id,
            subject=ticket.subject,
            description=ticket.description,
            contact_id=ticket.contact_id,
            status=TicketStatus(ticket.status),
            priority=Priority(ticket.priority),
            category=ticket.category,
            assigned_to=ticket.assigned_to,
            ai_resolution=ticket.ai_resolution,
            sentiment_score=ticket.sentiment_score,
            resolution_time_minutes=ticket.resolution_time_minutes,
            satisfaction_score=ticket.satisfaction_score,
            tags=ticket.tags or [],
            metadata=ticket.metadata or {},
            created_at=ticket.created_at,
            updated_at=ticket.updated_at,
            resolved_at=ticket.resolved_at,
        )
