"""Sales Pipeline Engine for Nexus Core V8.

Manages sales pipeline and deal flow.
"""
import uuid
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session
from sqlalchemy import func

from ..schemas.deal import DealCreate, DealUpdate, DealResponse, DealListResponse, LeadStatus
from database.models import DealModel, ContactModel


class SalesPipelineEngine:
    """Manages sales pipeline."""

    def __init__(self, db_session: Session, ai_client=None):
        self.db = db_session
        self.ai = ai_client
        self.stages = ["prospect", "qualified", "proposal", "negotiation", "closed_won", "closed_lost"]

    def create_deal(self, deal_data: DealCreate) -> DealResponse:
        """Create a new deal."""
        deal_id = str(uuid.uuid4())

        deal = DealModel(
            id=deal_id,
            name=deal_data.name,
            contact_id=deal_data.contact_id,
            company_id=deal_data.company_id,
            stage=deal_data.stage,
            status=LeadStatus.NEW.value,
            value=deal_data.value,
            currency=deal_data.currency,
            probability=deal_data.probability,
            expected_close_date=deal_data.expected_close_date,
            source=deal_data.source,
            owner_id=deal_data.owner_id,
            tags=deal_data.tags,
            metadata=deal_data.metadata,
            created_at=datetime.utcnow(),
        )

        self.db.add(deal)
        self.db.commit()
        self.db.refresh(deal)

        return self._to_response(deal)

    def move_deal(self, deal_id: str, new_stage: str) -> DealResponse:
        """Move deal to new stage."""
        deal = self.db.query(DealModel).filter(DealModel.id == deal_id).first()
        if not deal:
            raise ValueError("Deal not found")

        old_stage = deal.stage
        deal.stage = new_stage

        # Update probability based on stage
        stage_probabilities = {
            "prospect": 10,
            "qualified": 25,
            "proposal": 50,
            "negotiation": 75,
            "closed_won": 100,
            "closed_lost": 0,
        }
        deal.probability = stage_probabilities.get(new_stage, deal.probability)

        # Update status for closed deals
        if new_stage == "closed_won":
            deal.status = LeadStatus.CLOSED_WON.value
            deal.actual_close_date = datetime.utcnow()
        elif new_stage == "closed_lost":
            deal.status = LeadStatus.CLOSED_LOST.value
            deal.actual_close_date = datetime.utcnow()

        deal.updated_at = datetime.utcnow()
        self.db.commit()

        return self._to_response(deal)

    def update_deal(self, deal_id: str, deal_data: DealUpdate) -> Optional[DealResponse]:
        """Update a deal."""
        deal = self.db.query(DealModel).filter(DealModel.id == deal_id).first()
        if not deal:
            return None

        if deal_data.name is not None:
            deal.name = deal_data.name
        if deal_data.stage is not None:
            deal.stage = deal_data.stage
        if deal_data.status is not None:
            deal.status = deal_data.status.value
        if deal_data.value is not None:
            deal.value = deal_data.value
        if deal_data.probability is not None:
            deal.probability = deal_data.probability
        if deal_data.expected_close_date is not None:
            deal.expected_close_date = deal_data.expected_close_date
        if deal_data.owner_id is not None:
            deal.owner_id = deal_data.owner_id
        if deal_data.tags is not None:
            deal.tags = deal_data.tags
        if deal_data.metadata is not None:
            deal.metadata = deal_data.metadata

        deal.updated_at = datetime.utcnow()
        self.db.commit()
        self.db.refresh(deal)

        return self._to_response(deal)

    def get_deal(self, deal_id: str) -> Optional[DealResponse]:
        """Get deal by ID."""
        deal = self.db.query(DealModel).filter(DealModel.id == deal_id).first()
        if not deal:
            return None
        return self._to_response(deal)

    def list_deals(
        self,
        stage: Optional[str] = None,
        status: Optional[LeadStatus] = None,
        owner_id: Optional[str] = None,
        min_value: Optional[float] = None,
        skip: int = 0,
        limit: int = 100,
    ) -> DealListResponse:
        """List deals."""
        query = self.db.query(DealModel)

        if stage:
            query = query.filter(DealModel.stage == stage)
        if status:
            query = query.filter(DealModel.status == status.value)
        if owner_id:
            query = query.filter(DealModel.owner_id == owner_id)
        if min_value is not None:
            query = query.filter(DealModel.value >= min_value)

        deals = query.offset(skip).limit(limit).all()
        total = query.count()

        total_value = sum(d.value for d in deals)
        avg_probability = sum(d.probability for d in deals) / len(deals) if deals else 0

        return DealListResponse(
            deals=[self._to_response(d) for d in deals],
            total=total,
            total_value=total_value,
            avg_probability=avg_probability,
        )

    def get_pipeline_summary(self) -> Dict[str, Any]:
        """Get pipeline summary."""
        results = self.db.query(
            DealModel.stage,
            func.count(DealModel.id).label("count"),
            func.sum(DealModel.value).label("total_value"),
            func.avg(DealModel.probability).label("avg_probability"),
        ).group_by(DealModel.stage).all()

        stages = {}
        for r in results:
            stages[r.stage] = {
                "count": r.count,
                "total_value": float(r.total_value) if r.total_value else 0,
                "avg_probability": float(r.avg_probability) if r.avg_probability else 0,
                "weighted_value": float(r.total_value) * float(r.avg_probability) / 100 if r.total_value and r.avg_probability else 0,
            }

        # Calculate totals
        total_deals = sum(s["count"] for s in stages.values())
        total_value = sum(s["total_value"] for s in stages.values())
        total_weighted = sum(s["weighted_value"] for s in stages.values())

        return {
            "stages": stages,
            "total_deals": total_deals,
            "total_pipeline_value": total_value,
            "weighted_pipeline_value": total_weighted,
            "forecasted_revenue": total_weighted,
        }

    def forecast_pipeline(self, days: int = 90) -> Dict[str, Any]:
        """Forecast pipeline revenue."""
        summary = self.get_pipeline_summary()

        # Simple forecast based on historical close rates
        cutoff = datetime.utcnow() - timedelta(days=days)

        closed_deals = self.db.query(DealModel).filter(
            DealModel.status == LeadStatus.CLOSED_WON.value,
            DealModel.actual_close_date >= cutoff,
        ).all()

        total_closed_value = sum(d.value for d in closed_deals)
        avg_cycle_days = 0

        if closed_deals:
            cycle_days = []
            for deal in closed_deals:
                if deal.created_at and deal.actual_close_date:
                    delta = (deal.actual_close_date - deal.created_at).days
                    cycle_days.append(delta)
            avg_cycle_days = sum(cycle_days) / len(cycle_days) if cycle_days else 0

        return {
            "current_pipeline_value": summary["total_pipeline_value"],
            "weighted_pipeline_value": summary["weighted_pipeline_value"],
            "forecasted_revenue_90d": summary["weighted_pipeline_value"] * 0.7,
            "historical_close_rate": len(closed_deals) / self.db.query(DealModel).count() if self.db.query(DealModel).count() > 0 else 0,
            "avg_sales_cycle_days": avg_cycle_days,
            "period_days": days,
        }

    def _to_response(self, deal: DealModel) -> DealResponse:
        """Convert DB model to response."""
        return DealResponse(
            deal_id=deal.id,
            name=deal.name,
            contact_id=deal.contact_id,
            company_id=deal.company_id,
            stage=deal.stage,
            status=LeadStatus(deal.status),
            value=deal.value,
            currency=deal.currency,
            probability=deal.probability,
            expected_close_date=deal.expected_close_date,
            actual_close_date=deal.actual_close_date,
            source=deal.source,
            owner_id=deal.owner_id,
            tags=deal.tags or [],
            metadata=deal.metadata or {},
            created_at=deal.created_at,
            updated_at=deal.updated_at,
        )
