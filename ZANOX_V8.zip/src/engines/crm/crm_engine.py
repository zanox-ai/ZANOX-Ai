"""CRM Management Layer for Nexus Core V8.

Manages contacts, companies, and relationships.
"""
import uuid
from datetime import datetime
from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session

from ..schemas.contact import ContactCreate, ContactUpdate, ContactResponse, ContactListResponse
from database.models import ContactModel


class CRMManagementLayer:
    """Manages CRM data and operations."""

    def __init__(self, db_session: Session, ai_client=None):
        self.db = db_session
        self.ai = ai_client

    def create_contact(self, contact_data: ContactCreate) -> ContactResponse:
        """Create a new contact."""
        contact_id = str(uuid.uuid4())

        contact = ContactModel(
            id=contact_id,
            email=contact_data.email,
            first_name=contact_data.first_name,
            last_name=contact_data.last_name,
            phone=contact_data.phone,
            company=contact_data.company,
            title=contact_data.title,
            source=contact_data.source,
            tags=contact_data.tags,
            custom_fields=contact_data.custom_fields,
            created_at=datetime.utcnow(),
        )

        self.db.add(contact)
        self.db.commit()
        self.db.refresh(contact)

        # Score the lead using AI
        if self.ai:
            score = self._score_lead(contact)
            contact.score = score
            self.db.commit()

        return self._to_response(contact)

    def update_contact(self, contact_id: str, contact_data: ContactUpdate) -> Optional[ContactResponse]:
        """Update a contact."""
        contact = self.db.query(ContactModel).filter(ContactModel.id == contact_id).first()
        if not contact:
            return None

        if contact_data.first_name is not None:
            contact.first_name = contact_data.first_name
        if contact_data.last_name is not None:
            contact.last_name = contact_data.last_name
        if contact_data.phone is not None:
            contact.phone = contact_data.phone
        if contact_data.company is not None:
            contact.company = contact_data.company
        if contact_data.title is not None:
            contact.title = contact_data.title
        if contact_data.status is not None:
            contact.status = contact_data.status
        if contact_data.score is not None:
            contact.score = contact_data.score
        if contact_data.tags is not None:
            contact.tags = contact_data.tags
        if contact_data.custom_fields is not None:
            contact.custom_fields = contact_data.custom_fields

        contact.updated_at = datetime.utcnow()
        contact.last_activity = datetime.utcnow()
        self.db.commit()
        self.db.refresh(contact)

        return self._to_response(contact)

    def get_contact(self, contact_id: str) -> Optional[ContactResponse]:
        """Get contact by ID."""
        contact = self.db.query(ContactModel).filter(ContactModel.id == contact_id).first()
        if not contact:
            return None
        return self._to_response(contact)

    def get_contact_by_email(self, email: str) -> Optional[ContactResponse]:
        """Get contact by email."""
        contact = self.db.query(ContactModel).filter(ContactModel.email == email).first()
        if not contact:
            return None
        return self._to_response(contact)

    def list_contacts(
        self,
        status: Optional[str] = None,
        company: Optional[str] = None,
        source: Optional[str] = None,
        min_score: Optional[float] = None,
        skip: int = 0,
        limit: int = 100,
    ) -> ContactListResponse:
        """List contacts."""
        query = self.db.query(ContactModel)

        if status:
            query = query.filter(ContactModel.status == status)
        if company:
            query = query.filter(ContactModel.company.ilike(f"%{company}%"))
        if source:
            query = query.filter(ContactModel.source == source)
        if min_score is not None:
            query = query.filter(ContactModel.score >= min_score)

        contacts = query.offset(skip).limit(limit).all()
        total = query.count()

        return ContactListResponse(
            contacts=[self._to_response(c) for c in contacts],
            total=total,
        )

    def delete_contact(self, contact_id: str) -> bool:
        """Delete a contact."""
        contact = self.db.query(ContactModel).filter(ContactModel.id == contact_id).first()
        if not contact:
            return False

        self.db.delete(contact)
        self.db.commit()
        return True

    def _score_lead(self, contact: ContactModel) -> float:
        """Score a lead using AI."""
        # Base score from contact data
        score = 0.0

        if contact.company:
            score += 10
        if contact.title:
            score += 5
        if contact.phone:
            score += 5
        if contact.source == "referral":
            score += 20
        elif contact.source == "organic":
            score += 15
        elif contact.source == "paid":
            score += 10

        return min(score, 100)

    def _to_response(self, contact: ContactModel) -> ContactResponse:
        """Convert DB model to response."""
        return ContactResponse(
            contact_id=contact.id,
            email=contact.email,
            first_name=contact.first_name,
            last_name=contact.last_name,
            phone=contact.phone,
            company=contact.company,
            title=contact.title,
            source=contact.source,
            status=contact.status,
            score=contact.score,
            tags=contact.tags or [],
            custom_fields=contact.custom_fields or {},
            last_activity=contact.last_activity,
            created_at=contact.created_at,
            updated_at=contact.updated_at,
        )
