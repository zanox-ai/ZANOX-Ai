"""Business Intelligence Dashboard Engine for Nexus Core V8.

Generates BI dashboards and widgets.
"""
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
from sqlalchemy.orm import Session

from database.models import KpiModel, RevenueModel, DealModel, TicketModel, CampaignModel


class BIDashboardEngine:
    """Generates BI dashboards."""

    def __init__(self, db_session: Session):
        self.db = db_session

    def generate_dashboard(self, dashboard_type: str = "executive") -> Dict[str, Any]:
        """Generate a BI dashboard."""
        if dashboard_type == "executive":
            return self._generate_executive_dashboard()
        elif dashboard_type == "sales":
            return self._generate_sales_dashboard()
        elif dashboard_type == "marketing":
            return self._generate_marketing_dashboard()
        elif dashboard_type == "support":
            return self._generate_support_dashboard()
        elif dashboard_type == "revenue":
            return self._generate_revenue_dashboard()
        else:
            return self._generate_executive_dashboard()

    def _generate_executive_dashboard(self) -> Dict[str, Any]:
        """Generate executive dashboard."""
        cutoff = datetime.utcnow() - timedelta(days=30)

        # Key metrics
        total_revenue = self._get_total_revenue(cutoff)
        total_deals = self.db.query(DealModel).filter(DealModel.created_at >= cutoff).count()
        total_tickets = self.db.query(TicketModel).filter(TicketModel.created_at >= cutoff).count()
        active_campaigns = self.db.query(CampaignModel).filter(
            CampaignModel.status == "active",
        ).count()

        return {
            "dashboard_type": "executive",
            "generated_at": datetime.utcnow().isoformat(),
            "widgets": [
                {
                    "type": "metric",
                    "title": "Total Revenue (30d)",
                    "value": f"${total_revenue:,.2f}",
                    "trend": "up",
                    "change": "12%",
                },
                {
                    "type": "metric",
                    "title": "New Deals",
                    "value": total_deals,
                    "trend": "up",
                    "change": "8%",
                },
                {
                    "type": "metric",
                    "title": "Support Tickets",
                    "value": total_tickets,
                    "trend": "down",
                    "change": "-5%",
                },
                {
                    "type": "metric",
                    "title": "Active Campaigns",
                    "value": active_campaigns,
                    "trend": "stable",
                    "change": "0%",
                },
                {
                    "type": "chart",
                    "title": "Revenue Trend",
                    "chart_type": "line",
                    "data": self._get_revenue_trend(30),
                },
                {
                    "type": "chart",
                    "title": "Pipeline by Stage",
                    "chart_type": "bar",
                    "data": self._get_pipeline_by_stage(),
                },
                {
                    "type": "chart",
                    "title": "Support Resolution",
                    "chart_type": "pie",
                    "data": self._get_support_resolution_stats(),
                },
            ],
        }

    def _generate_sales_dashboard(self) -> Dict[str, Any]:
        """Generate sales dashboard."""
        return {
            "dashboard_type": "sales",
            "widgets": [
                {
                    "type": "metric",
                    "title": "Pipeline Value",
                    "value": self._get_pipeline_value(),
                },
                {
                    "type": "chart",
                    "title": "Deals by Stage",
                    "chart_type": "funnel",
                    "data": self._get_deals_by_stage(),
                },
            ],
        }

    def _generate_marketing_dashboard(self) -> Dict[str, Any]:
        """Generate marketing dashboard."""
        return {
            "dashboard_type": "marketing",
            "widgets": [
                {
                    "type": "metric",
                    "title": "Campaign ROI",
                    "value": self._get_campaign_roi(),
                },
            ],
        }

    def _generate_support_dashboard(self) -> Dict[str, Any]:
        """Generate support dashboard."""
        return {
            "dashboard_type": "support",
            "widgets": [
                {
                    "type": "metric",
                    "title": "Avg Resolution Time",
                    "value": self._get_avg_resolution_time(),
                },
            ],
        }

    def _generate_revenue_dashboard(self) -> Dict[str, Any]:
        """Generate revenue dashboard."""
        return {
            "dashboard_type": "revenue",
            "widgets": [
                {
                    "type": "metric",
                    "title": "MRR",
                    "value": self._get_mrr(),
                },
                {
                    "type": "metric",
                    "title": "ARR",
                    "value": self._get_arr(),
                },
            ],
        }

    def _get_total_revenue(self, cutoff: datetime) -> float:
        """Get total revenue since cutoff."""
        from sqlalchemy import func
        result = self.db.query(func.sum(RevenueModel.amount)).filter(
            RevenueModel.timestamp >= cutoff
        ).scalar()
        return float(result) if result else 0.0

    def _get_revenue_trend(self, days: int) -> List[Dict[str, Any]]:
        """Get revenue trend."""
        from sqlalchemy import func
        cutoff = datetime.utcnow() - timedelta(days=days)

        results = self.db.query(
            func.date(RevenueModel.timestamp).label("date"),
            func.sum(RevenueModel.amount).label("amount"),
        ).filter(
            RevenueModel.timestamp >= cutoff
        ).group_by(
            func.date(RevenueModel.timestamp)
        ).order_by(
            func.date(RevenueModel.timestamp)
        ).all()

        return [
            {"date": r.date.isoformat(), "amount": float(r.amount)}
            for r in results
        ]

    def _get_pipeline_by_stage(self) -> List[Dict[str, Any]]:
        """Get pipeline by stage."""
        from sqlalchemy import func
        results = self.db.query(
            DealModel.stage,
            func.count(DealModel.id).label("count"),
            func.sum(DealModel.value).label("value"),
        ).group_by(DealModel.stage).all()

        return [
            {"stage": r.stage, "count": r.count, "value": float(r.value) if r.value else 0}
            for r in results
        ]

    def _get_support_resolution_stats(self) -> List[Dict[str, Any]]:
        """Get support resolution stats."""
        from sqlalchemy import func
        cutoff = datetime.utcnow() - timedelta(days=30)

        results = self.db.query(
            TicketModel.status,
            func.count(TicketModel.id).label("count"),
        ).filter(
            TicketModel.created_at >= cutoff
        ).group_by(TicketModel.status).all()

        return [
            {"status": r.status, "count": r.count}
            for r in results
        ]

    def _get_pipeline_value(self) -> float:
        """Get total pipeline value."""
        from sqlalchemy import func
        result = self.db.query(func.sum(DealModel.value)).filter(
            DealModel.status.notin_(["closed_won", "closed_lost"])
        ).scalar()
        return float(result) if result else 0.0

    def _get_deals_by_stage(self) -> List[Dict[str, Any]]:
        """Get deals by stage."""
        return self._get_pipeline_by_stage()

    def _get_campaign_roi(self) -> float:
        """Get average campaign ROI."""
        campaigns = self.db.query(CampaignModel).filter(CampaignModel.status == "completed").all()
        if not campaigns:
            return 0.0

        total_roi = 0
        for campaign in campaigns:
            revenue = campaign.metrics.get("revenue", 0) if campaign.metrics else 0
            spent = campaign.spent
            if spent > 0:
                total_roi += (revenue - spent) / spent

        return total_roi / len(campaigns)

    def _get_avg_resolution_time(self) -> float:
        """Get average resolution time."""
        from sqlalchemy import func
        result = self.db.query(func.avg(TicketModel.resolution_time_minutes)).filter(
            TicketModel.resolution_time_minutes.isnot(None)
        ).scalar()
        return float(result) if result else 0.0

    def _get_mrr(self) -> float:
        """Get MRR."""
        from sqlalchemy import func
        result = self.db.query(func.sum(RevenueModel.amount)).filter(
            RevenueModel.period == "monthly",
            RevenueModel.timestamp >= datetime.utcnow() - timedelta(days=30),
        ).scalar()
        return float(result) if result else 0.0

    def _get_arr(self) -> float:
        """Get ARR."""
        return self._get_mrr() * 12
