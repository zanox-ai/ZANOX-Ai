"""KPI Tracking Engine for Nexus Core V8.

Tracks and analyzes business KPIs.
"""
import uuid
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session
from sqlalchemy import func

from ..schemas.kpi import KpiCreate, KpiResponse, KpiListResponse
from database.models import KpiModel, DealModel, RevenueModel, TicketModel


class KPITrackingEngine:
    """Tracks and analyzes KPIs."""

    def __init__(self, db_session: Session):
        self.db = db_session
        self.default_kpis = [
            "revenue", "mrr", "arr", "churn_rate", "conversion_rate",
            "cac", "ltv", "nps", "ticket_volume", "avg_deal_size",
        ]

    def create_kpi(self, kpi_data: KpiCreate) -> KpiResponse:
        """Create a new KPI."""
        kpi_id = str(uuid.uuid4())

        kpi = KpiModel(
            id=kpi_id,
            name=kpi_data.name,
            category=kpi_data.category,
            value=kpi_data.value,
            target=kpi_data.target,
            unit=kpi_data.unit,
            period=kpi_data.period,
            metadata=kpi_data.metadata,
            timestamp=datetime.utcnow(),
        )

        self.db.add(kpi)
        self.db.commit()
        self.db.refresh(kpi)

        return self._to_response(kpi)

    def calculate_kpis(self, period: str = "daily") -> List[KpiResponse]:
        """Calculate all KPIs for the period."""
        kpis = []

        # Revenue KPIs
        revenue_kpis = self._calculate_revenue_kpis(period)
        kpis.extend(revenue_kpis)

        # Sales KPIs
        sales_kpis = self._calculate_sales_kpis(period)
        kpis.extend(sales_kpis)

        # Support KPIs
        support_kpis = self._calculate_support_kpis(period)
        kpis.extend(support_kpis)

        # Store calculated KPIs
        for kpi in kpis:
            self.create_kpi(KpiCreate(
                name=kpi.name,
                category=kpi.category,
                value=kpi.value,
                target=kpi.target,
                unit=kpi.unit,
                period=period,
            ))

        return kpis

    def _calculate_revenue_kpis(self, period: str) -> List[KpiResponse]:
        """Calculate revenue KPIs."""
        cutoff = self._get_period_cutoff(period)

        total_revenue = self.db.query(
            func.sum(RevenueModel.amount)
        ).filter(RevenueModel.timestamp >= cutoff).scalar() or 0.0

        # MRR (Monthly Recurring Revenue)
        mrr = self.db.query(
            func.sum(RevenueModel.amount)
        ).filter(
            RevenueModel.timestamp >= datetime.utcnow() - timedelta(days=30),
            RevenueModel.period == "monthly",
        ).scalar() or 0.0

        # ARR (Annual Recurring Revenue)
        arr = mrr * 12

        return [
            KpiResponse(
                kpi_id=str(uuid.uuid4()),
                name="total_revenue",
                category="revenue",
                value=float(total_revenue),
                target=None,
                unit="USD",
                period=period,
            ),
            KpiResponse(
                kpi_id=str(uuid.uuid4()),
                name="mrr",
                category="revenue",
                value=float(mrr),
                target=None,
                unit="USD",
                period="monthly",
            ),
            KpiResponse(
                kpi_id=str(uuid.uuid4()),
                name="arr",
                category="revenue",
                value=float(arr),
                target=None,
                unit="USD",
                period="yearly",
            ),
        ]

    def _calculate_sales_kpis(self, period: str) -> List[KpiResponse]:
        """Calculate sales KPIs."""
        cutoff = self._get_period_cutoff(period)

        # Conversion rate
        total_deals = self.db.query(DealModel).filter(DealModel.created_at >= cutoff).count()
        closed_won = self.db.query(DealModel).filter(
            DealModel.created_at >= cutoff,
            DealModel.status == "closed_won",
        ).count()

        conversion_rate = (closed_won / total_deals * 100) if total_deals > 0 else 0

        # Average deal size
        avg_deal = self.db.query(
            func.avg(DealModel.value)
        ).filter(
            DealModel.created_at >= cutoff,
            DealModel.status == "closed_won",
        ).scalar() or 0.0

        return [
            KpiResponse(
                kpi_id=str(uuid.uuid4()),
                name="conversion_rate",
                category="sales",
                value=round(conversion_rate, 2),
                target=25.0,
                unit="percent",
                period=period,
            ),
            KpiResponse(
                kpi_id=str(uuid.uuid4()),
                name="avg_deal_size",
                category="sales",
                value=float(avg_deal),
                target=None,
                unit="USD",
                period=period,
            ),
        ]

    def _calculate_support_kpis(self, period: str) -> List[KpiResponse]:
        """Calculate support KPIs."""
        cutoff = self._get_period_cutoff(period)

        total_tickets = self.db.query(TicketModel).filter(TicketModel.created_at >= cutoff).count()

        resolved = self.db.query(TicketModel).filter(
            TicketModel.created_at >= cutoff,
            TicketModel.status == "resolved",
        ).count()

        resolution_rate = (resolved / total_tickets * 100) if total_tickets > 0 else 0

        avg_resolution = self.db.query(
            func.avg(TicketModel.resolution_time_minutes)
        ).filter(
            TicketModel.created_at >= cutoff,
            TicketModel.resolution_time_minutes.isnot(None),
        ).scalar() or 0.0

        return [
            KpiResponse(
                kpi_id=str(uuid.uuid4()),
                name="ticket_volume",
                category="support",
                value=float(total_tickets),
                target=None,
                unit="count",
                period=period,
            ),
            KpiResponse(
                kpi_id=str(uuid.uuid4()),
                name="resolution_rate",
                category="support",
                value=round(resolution_rate, 2),
                target=90.0,
                unit="percent",
                period=period,
            ),
            KpiResponse(
                kpi_id=str(uuid.uuid4()),
                name="avg_resolution_time",
                category="support",
                value=float(avg_resolution),
                target=60.0,
                unit="minutes",
                period=period,
            ),
        ]

    def _get_period_cutoff(self, period: str) -> datetime:
        """Get cutoff datetime for period."""
        now = datetime.utcnow()

        if period == "daily":
            return now - timedelta(days=1)
        elif period == "weekly":
            return now - timedelta(weeks=1)
        elif period == "monthly":
            return now - timedelta(days=30)
        elif period == "quarterly":
            return now - timedelta(days=90)
        elif period == "yearly":
            return now - timedelta(days=365)
        else:
            return now - timedelta(days=1)

    def get_kpi_trend(self, kpi_name: str, days: int = 30) -> List[Dict[str, Any]]:
        """Get KPI trend over time."""
        cutoff = datetime.utcnow() - timedelta(days=days)

        kpis = self.db.query(KpiModel).filter(
            KpiModel.name == kpi_name,
            KpiModel.timestamp >= cutoff,
        ).order_by(KpiModel.timestamp).all()

        return [
            {
                "timestamp": k.timestamp.isoformat(),
                "value": k.value,
                "target": k.target,
                "change_percent": k.change_percent,
            }
            for k in kpis
        ]

    def _to_response(self, kpi: KpiModel) -> KpiResponse:
        """Convert DB model to response."""
        return KpiResponse(
            kpi_id=kpi.id,
            name=kpi.name,
            category=kpi.category,
            value=kpi.value,
            target=kpi.target,
            unit=kpi.unit,
            period=kpi.period,
            trend=kpi.trend,
            change_percent=kpi.change_percent,
            metadata=kpi.metadata or {},
            timestamp=kpi.timestamp,
        )
