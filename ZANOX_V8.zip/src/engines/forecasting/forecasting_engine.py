"""Forecasting Engine for Nexus Core V8.

Generates business forecasts using multiple models.
"""
import uuid
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session

from ..schemas.forecast import ForecastCreate, ForecastResponse, ForecastListResponse
from database.models import ForecastModel, RevenueModel, DealModel


class ForecastingEngine:
    """Generates business forecasts."""

    def __init__(self, db_session: Session):
        self.db = db_session

    def create_forecast(self, forecast_data: ForecastCreate) -> ForecastResponse:
        """Create a new forecast."""
        forecast_id = str(uuid.uuid4())

        forecast = ForecastModel(
            id=forecast_id,
            name=forecast_data.name,
            forecast_type=forecast_data.forecast_type,
            model=forecast_data.model,
            horizon_days=forecast_data.horizon_days,
            metadata=forecast_data.metadata,
            created_at=datetime.utcnow(),
        )

        self.db.add(forecast)
        self.db.commit()
        self.db.refresh(forecast)

        # Generate predictions
        predictions = self._generate_predictions(forecast)
        forecast.predictions = predictions
        forecast.accuracy = self._calculate_accuracy(forecast)
        self.db.commit()

        return self._to_response(forecast)

    def _generate_predictions(self, forecast: ForecastModel) -> List[Dict[str, Any]]:
        """Generate predictions based on forecast type."""
        if forecast.forecast_type == "revenue":
            return self._forecast_revenue(forecast.horizon_days)
        elif forecast.forecast_type == "sales":
            return self._forecast_sales(forecast.horizon_days)
        elif forecast.forecast_type == "support":
            return self._forecast_support(forecast.horizon_days)
        else:
            return []

    def _forecast_revenue(self, horizon_days: int) -> List[Dict[str, Any]]:
        """Forecast revenue."""
        # Get historical data
        cutoff = datetime.utcnow() - timedelta(days=180)

        from sqlalchemy import func
        historical = self.db.query(
            func.date(RevenueModel.timestamp).label("date"),
            func.sum(RevenueModel.amount).label("daily"),
        ).filter(
            RevenueModel.timestamp >= cutoff
        ).group_by(
            func.date(RevenueModel.timestamp)
        ).order_by(
            func.date(RevenueModel.timestamp)
        ).all()

        if not historical:
            return []

        values = [float(h.daily) for h in historical]
        avg = sum(values) / len(values)

        # Add trend
        trend = 0.02  # 2% daily growth assumption

        predictions = []
        for i in range(1, horizon_days + 1):
            date = datetime.utcnow() + timedelta(days=i)
            predicted = avg * (1 + trend) ** i

            predictions.append({
                "date": date.date().isoformat(),
                "predicted": round(predicted, 2),
                "lower_bound": round(predicted * 0.85, 2),
                "upper_bound": round(predicted * 1.15, 2),
            })

        return predictions

    def _forecast_sales(self, horizon_days: int) -> List[Dict[str, Any]]:
        """Forecast sales."""
        cutoff = datetime.utcnow() - timedelta(days=90)

        historical = self.db.query(DealModel).filter(
            DealModel.created_at >= cutoff,
            DealModel.status == "closed_won",
        ).all()

        if not historical:
            return []

        avg_daily = len(historical) / 90

        predictions = []
        for i in range(1, horizon_days + 1):
            date = datetime.utcnow() + timedelta(days=i)
            predictions.append({
                "date": date.date().isoformat(),
                "predicted_deals": round(avg_daily, 1),
                "predicted_value": round(avg_daily * 5000, 2),  # Assume $5k avg deal
            })

        return predictions

    def _forecast_support(self, horizon_days: int) -> List[Dict[str, Any]]:
        """Forecast support volume."""
        cutoff = datetime.utcnow() - timedelta(days=30)

        from sqlalchemy import func
        total = self.db.query(func.count(DealModel.id)).filter(
            DealModel.created_at >= cutoff
        ).scalar() or 0

        avg_daily = total / 30

        predictions = []
        for i in range(1, horizon_days + 1):
            date = datetime.utcnow() + timedelta(days=i)
            predictions.append({
                "date": date.date().isoformat(),
                "predicted_tickets": round(avg_daily, 1),
            })

        return predictions

    def _calculate_accuracy(self, forecast: ForecastModel) -> Optional[float]:
        """Calculate forecast accuracy."""
        # In production, compare with actuals
        return 0.85  # Placeholder

    def get_forecast(self, forecast_id: str) -> Optional[ForecastResponse]:
        """Get forecast by ID."""
        forecast = self.db.query(ForecastModel).filter(ForecastModel.id == forecast_id).first()
        if not forecast:
            return None
        return self._to_response(forecast)

    def list_forecasts(
        self,
        forecast_type: Optional[str] = None,
        skip: int = 0,
        limit: int = 100,
    ) -> ForecastListResponse:
        """List forecasts."""
        query = self.db.query(ForecastModel)

        if forecast_type:
            query = query.filter(ForecastModel.forecast_type == forecast_type)

        forecasts = query.order_by(ForecastModel.created_at.desc()).offset(skip).limit(limit).all()
        total = query.count()

        return ForecastListResponse(
            forecasts=[self._to_response(f) for f in forecasts],
            total=total,
        )

    def _to_response(self, forecast: ForecastModel) -> ForecastResponse:
        """Convert DB model to response."""
        return ForecastResponse(
            forecast_id=forecast.id,
            name=forecast.name,
            forecast_type=forecast.forecast_type,
            model=forecast.model,
            horizon_days=forecast.horizon_days,
            predictions=forecast.predictions or [],
            confidence_intervals=forecast.confidence_intervals or {},
            accuracy=forecast.accuracy,
            metadata=forecast.metadata or {},
            created_at=forecast.created_at,
        )
