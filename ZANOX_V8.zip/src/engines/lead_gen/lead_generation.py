"""Lead Generation System for Nexus Core V8.

Generates and qualifies leads from multiple sources.
"""
import uuid
from datetime import datetime
from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session

from database.models import ContactModel


class LeadGenerationSystem:
    """Generates and qualifies leads."""

    def __init__(self, db_session: Session, ai_client=None):
        self.db = db_session
        self.ai = ai_client
        self.sources = ["web", "social", "ads", "referral", "events", "content"]

    def generate_lead(
        self,
        source: str,
        email: str,
        first_name: Optional[str] = None,
        last_name: Optional[str] = None,
        company: Optional[str] = None,
        metadata: Optional[Dict] = None,
    ) -> Dict[str, Any]:
        """Generate a new lead."""
        contact_id = str(uuid.uuid4())

        contact = ContactModel(
            id=contact_id,
            email=email,
            first_name=first_name,
            last_name=last_name,
            company=company,
            source=source,
            status="lead",
            score=0.0,
            tags=[source, "auto-generated"],
            custom_fields=metadata or {},
            created_at=datetime.utcnow(),
        )

        self.db.add(contact)
        self.db.commit()
        self.db.refresh(contact)

        # Qualify the lead
        qualification = self._qualify_lead(contact)
        contact.score = qualification["score"]
        contact.status = qualification["status"]
        self.db.commit()

        return {
            "lead_id": contact_id,
            "email": email,
            "score": contact.score,
            "status": contact.status,
            "source": source,
            "qualification": qualification,
        }

    def qualify_lead(self, contact_id: str) -> Dict[str, Any]:
        """Qualify an existing lead."""
        contact = self.db.query(ContactModel).filter(ContactModel.id == contact_id).first()
        if not contact:
            raise ValueError("Contact not found")

        qualification = self._qualify_lead(contact)
        contact.score = qualification["score"]
        contact.status = qualification["status"]
        self.db.commit()

        return qualification

    def _qualify_lead(self, contact: ContactModel) -> Dict[str, Any]:
        """Qualify a lead based on BANT criteria."""
        score = 0
        reasons = []

        # Budget indicators
        if contact.company:
            score += 25
            reasons.append("Has company association")

        # Authority indicators
        if contact.title:
            score += 25
            reasons.append("Has job title")

        # Need indicators
        if contact.source == "referral":
            score += 30
            reasons.append("High-intent referral source")
        elif contact.source == "organic":
            score += 20
            reasons.append("Organic discovery")

        # Timeline indicators
        if contact.custom_fields and contact.custom_fields.get("urgency"):
            score += 20
            reasons.append("Expressed urgency")

        # Determine status
        if score >= 80:
            status = "hot"
        elif score >= 50:
            status = "warm"
        elif score >= 25:
            status = "cold"
        else:
            status = "nurture"

        return {
            "score": min(score, 100),
            "status": status,
            "reasons": reasons,
            "bant_analysis": {
                "budget": contact.company is not None,
                "authority": contact.title is not None,
                "need": contact.source in ["referral", "organic"],
                "timeline": contact.custom_fields.get("urgency") is not None if contact.custom_fields else False,
            },
        }

    def get_leads_by_source(self, days: int = 30) -> List[Dict[str, Any]]:
        """Get leads grouped by source."""
        from sqlalchemy import func

        cutoff = datetime.utcnow() - __import__("datetime").timedelta(days=days)

        results = self.db.query(
            ContactModel.source,
            func.count(ContactModel.id).label("count"),
            func.avg(ContactModel.score).label("avg_score"),
        ).filter(
            ContactModel.created_at >= cutoff
        ).group_by(
            ContactModel.source
        ).all()

        return [
            {
                "source": r.source,
                "count": r.count,
                "avg_score": float(r.avg_score) if r.avg_score else 0.0,
            }
            for r in results
        ]

    def get_lead_funnel(self, days: int = 30) -> Dict[str, Any]:
        """Get lead funnel analytics."""
        from sqlalchemy import func

        cutoff = datetime.utcnow() - __import__("datetime").timedelta(days=days)

        total_leads = self.db.query(ContactModel).filter(
            ContactModel.created_at >= cutoff
        ).count()

        qualified = self.db.query(ContactModel).filter(
            ContactModel.created_at >= cutoff,
            ContactModel.score >= 50,
        ).count()

        converted = self.db.query(ContactModel).filter(
            ContactModel.created_at >= cutoff,
            ContactModel.status.in_(["customer", "closed_won"]),
        ).count()

        return {
            "total_leads": total_leads,
            "qualified_leads": qualified,
            "converted_leads": converted,
            "qualification_rate": qualified / total_leads if total_leads > 0 else 0,
            "conversion_rate": converted / total_leads if total_leads > 0 else 0,
            "period_days": days,
        }
