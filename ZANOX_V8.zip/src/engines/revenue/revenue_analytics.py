"""Revenue Analytics Engine for Nexus Core V8.

Analyzes revenue data and trends.
"""
import uuid
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session
from sqlalchemy import func

from ..schemas.revenue import RevenueCreate, RevenueResponse, RevenueSummary
from database.models import RevenueModel, DealModel, CampaignModel


class RevenueAnalyticsEngine:
    """Analyzes revenue data."""

    def __init__(self, db_session: Session):
        self.db = db_session

    def record_revenue(self, revenue_data: RevenueCreate) -> RevenueResponse:
        """Record revenue."""
        revenue_id = str(uuid.uuid4())

        revenue = RevenueModel(
            id=revenue_id,
            source=revenue_data.source,
            amount=revenue_data.amount,
            currency=revenue_data.currency,
            category=revenue_data.category,
            period=revenue_data.period,
            deal_id=revenue_data.deal_id,
            campaign_id=revenue_data.campaign_id,
            metadata=revenue_data.metadata,
            timestamp=datetime.utcnow(),
        )

        self.db.add(revenue)
        self.db.commit()
        self.db.refresh(revenue)

        return RevenueResponse(
            revenue_id=revenue.id,
            source=revenue.source,
            amount=revenue.amount,
            currency=revenue.currency,
            category=revenue.category,
            period=revenue.period,
            deal_id=revenue.deal_id,
            campaign_id=revenue.campaign_id,
            metadata=revenue.metadata or {},
            timestamp=revenue.timestamp,
        )

    def get_revenue_summary(self, period: str = "monthly", days: int = 30) -> RevenueSummary:
        """Get revenue summary."""
        cutoff = datetime.utcnow() - timedelta(days=days)

        # Total revenue
        total = self.db.query(
            func.sum(RevenueModel.amount)
        ).filter(RevenueModel.timestamp >= cutoff).scalar() or 0.0

        # Count by source
        by_source = self.db.query(
            RevenueModel.source,
            func.sum(RevenueModel.amount).label("total"),
            func.count(RevenueModel.id).label("count"),
        ).filter(
            RevenueModel.timestamp >= cutoff
        ).group_by(RevenueModel.source).all()

        # Count by category
        by_category = self.db.query(
            RevenueModel.category,
            func.sum(RevenueModel.amount).label("total"),
        ).filter(
            RevenueModel.timestamp >= cutoff
        ).group_by(RevenueModel.category).all()

        # Daily trend
        trend = self.db.query(
            func.date(RevenueModel.timestamp).label("date"),
            func.sum(RevenueModel.amount).label("daily"),
        ).filter(
            RevenueModel.timestamp >= cutoff
        ).group_by(
            func.date(RevenueModel.timestamp)
        ).order_by(
            func.date(RevenueModel.timestamp)
        ).all()

        # MRR calculation
        mrr = self.db.query(
            func.sum(RevenueModel.amount)
        ).filter(
            RevenueModel.timestamp >= datetime.utcnow() - timedelta(days=30),
            RevenueModel.period == "monthly",
        ).scalar() or 0.0

        return RevenueSummary(
            total_revenue=float(total),
            total_deals=self.db.query(DealModel).filter(DealModel.created_at >= cutoff).count(),
            total_campaigns=self.db.query(CampaignModel).filter(CampaignModel.created_at >= cutoff).count(),
            avg_deal_size=float(total) / self.db.query(DealModel).filter(DealModel.created_at >= cutoff).count() if self.db.query(DealModel).filter(DealModel.created_at >= cutoff).count() > 0 else 0,
            mrr=float(mrr),
            arr=float(mrr) * 12,
            period=period,
            currency="USD",
            by_source=[
                {"source": s.source, "total": float(s.total), "count": s.count}
                for s in by_source
            ],
            by_category=[
                {"category": c.category, "total": float(c.total)}
                for c in by_category
            ],
            trend=[
                {"date": t.date.isoformat(), "amount": float(t.daily)}
                for t in trend
            ],
        )

    def get_revenue_forecast(self, days: int = 90) -> Dict[str, Any]:
        """Forecast revenue."""
        # Get historical data
        cutoff = datetime.utcnow() - timedelta(days=180)

        historical = self.db.query(
            func.date(RevenueModel.timestamp).label("date"),
            func.sum(RevenueModel.amount).label("daily"),
        ).filter(
            RevenueModel.timestamp >= cutoff
        ).group_by(
            func.date(RevenueModel.timestamp)
        ).order_by(
            func.date(RevenueModel.timestamp)
        ).all()

        if not historical:
            return {
                "forecast": [],
                "confidence": 0,
                "message": "Insufficient historical data",
            }

        # Simple moving average forecast
        values = [float(h.daily) for h in historical]
        avg_daily = sum(values) / len(values)

        forecast = []
        for i in range(1, days + 1):
            date = datetime.utcnow() + timedelta(days=i)
            forecast.append({
                "date": date.date().isoformat(),
                "predicted": round(avg_daily, 2),
                "lower_bound": round(avg_daily * 0.8, 2),
                "upper_bound": round(avg_daily * 1.2, 2),
            })

        return {
            "forecast": forecast,
            "avg_daily": round(avg_daily, 2),
            "confidence": 0.7,
            "horizon_days": days,
        }
