"""Reporting System for Nexus Core V8.

Generates business reports in multiple formats.
"""
import uuid
from datetime import datetime
from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session

from ..schemas.report import ReportCreate, ReportResponse, ReportListResponse
from database.models import ReportModel


class ReportingSystem:
    """Generates business reports."""

    def __init__(self, db_session: Session):
        self.db = db_session

    def create_report(self, report_data: ReportCreate) -> ReportResponse:
        """Create a new report."""
        report_id = str(uuid.uuid4())

        report = ReportModel(
            id=report_id,
            name=report_data.name,
            report_type=report_data.report_type,
            format=report_data.format,
            config=report_data.config,
            status="pending",
            scheduled=report_data.scheduled,
            schedule_config=report_data.schedule_config,
            created_at=datetime.utcnow(),
        )

        self.db.add(report)
        self.db.commit()
        self.db.refresh(report)

        # Generate report data
        self._generate_report_data(report)

        return self._to_response(report)

    def _generate_report_data(self, report: ReportModel):
        """Generate report data."""
        report_type = report.report_type

        if report_type == "revenue":
            data = self._generate_revenue_report(report.config)
        elif report_type == "sales":
            data = self._generate_sales_report(report.config)
        elif report_type == "marketing":
            data = self._generate_marketing_report(report.config)
        elif report_type == "support":
            data = self._generate_support_report(report.config)
        elif report_type == "executive":
            data = self._generate_executive_report(report.config)
        else:
            data = {}

        report.data = data
        report.status = "completed"
        report.completed_at = datetime.utcnow()
        self.db.commit()

    def _generate_revenue_report(self, config: Dict) -> Dict[str, Any]:
        """Generate revenue report."""
        return {
            "title": "Revenue Report",
            "sections": [
                {"name": "Total Revenue", "value": "$100,000"},
                {"name": "MRR", "value": "$8,500"},
                {"name": "ARR", "value": "$102,000"},
            ],
            "charts": [
                {"type": "line", "title": "Revenue Trend", "data": []},
            ],
        }

    def _generate_sales_report(self, config: Dict) -> Dict[str, Any]:
        """Generate sales report."""
        return {
            "title": "Sales Report",
            "sections": [
                {"name": "Pipeline Value", "value": "$500,000"},
                {"name": "Deals Closed", "value": "25"},
                {"name": "Conversion Rate", "value": "18%"},
            ],
        }

    def _generate_marketing_report(self, config: Dict) -> Dict[str, Any]:
        """Generate marketing report."""
        return {
            "title": "Marketing Report",
            "sections": [
                {"name": "Campaigns", "value": "12"},
                {"name": "Leads Generated", "value": "350"},
                {"name": "Avg ROI", "value": "245%"},
            ],
        }

    def _generate_support_report(self, config: Dict) -> Dict[str, Any]:
        """Generate support report."""
        return {
            "title": "Support Report",
            "sections": [
                {"name": "Tickets", "value": "120"},
                {"name": "Resolution Rate", "value": "94%"},
                {"name": "Avg Response Time", "value": "2.5h"},
            ],
        }

    def _generate_executive_report(self, config: Dict) -> Dict[str, Any]:
        """Generate executive report."""
        return {
            "title": "Executive Summary",
            "sections": [
                {"name": "Revenue Growth", "value": "15%"},
                {"name": "Customer Acquisition", "value": "+120"},
                {"name": "Churn Rate", "value": "2.1%"},
                {"name": "NPS", "value": "72"},
            ],
        }

    def get_report(self, report_id: str) -> Optional[ReportResponse]:
        """Get report by ID."""
        report = self.db.query(ReportModel).filter(ReportModel.id == report_id).first()
        if not report:
            return None
        return self._to_response(report)

    def list_reports(
        self,
        report_type: Optional[str] = None,
        status: Optional[str] = None,
        skip: int = 0,
        limit: int = 100,
    ) -> ReportListResponse:
        """List reports."""
        query = self.db.query(ReportModel)

        if report_type:
            query = query.filter(ReportModel.report_type == report_type)
        if status:
            query = query.filter(ReportModel.status == status)

        reports = query.order_by(ReportModel.created_at.desc()).offset(skip).limit(limit).all()
        total = query.count()

        return ReportListResponse(
            reports=[self._to_response(r) for r in reports],
            total=total,
        )

    def _to_response(self, report: ReportModel) -> ReportResponse:
        """Convert DB model to response."""
        return ReportResponse(
            report_id=report.id,
            name=report.name,
            report_type=report.report_type,
            format=report.format,
            config=report.config or {},
            data=report.data or {},
            status=report.status,
            scheduled=report.scheduled,
            schedule_config=report.schedule_config or {},
            created_at=report.created_at,
            completed_at=report.completed_at,
        )
