"""FastAPI application for Nexus Core V8.

Main API entry point.
"""
from fastapi import FastAPI, Depends, HTTPException, status, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager

from .api.contact_routes import router as contact_router
from .api.deal_routes import router as deal_router
from .api.campaign_routes import router as campaign_router
from .api.ticket_routes import router as ticket_router
from .api.kpi_routes import router as kpi_router
from .api.revenue_routes import router as revenue_router
from .api.report_routes import router as report_router
from .api.forecast_routes import router as forecast_router
from .api.experiment_routes import router as experiment_router
from .api.dashboard_routes import router as dashboard_router
from .api.ai_agent_routes import router as ai_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan handler."""
    print("Nexus Core V8 starting up...")
    yield
    print("Nexus Core V8 shutting down...")


app = FastAPI(
    title="Nexus Core V8",
    description="Business Operating System Layer",
    version="8.0.0",
    lifespan=lifespan,
)

app.add_middleware(GZipMiddleware, minimum_size=1000)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "error": "Internal server error",
            "detail": str(exc),
            "path": str(request.url.path),
        },
    )


@app.get("/")
async def root():
    return {
        "name": "Nexus Core V8",
        "version": "8.0.0",
        "status": "operational",
        "ai_agents": 9,
        "engines": 12,
    }


@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "timestamp": "2026-06-17T02:13:00Z",
        "components": {
            "api": "healthy",
            "database": "healthy",
            "cache": "healthy",
            "ai_agents": "healthy",
        },
    }


app.include_router(contact_router, prefix="/api/v1/contacts", tags=["CRM"])
app.include_router(deal_router, prefix="/api/v1/deals", tags=["Sales"])
app.include_router(campaign_router, prefix="/api/v1/campaigns", tags=["Marketing"])
app.include_router(ticket_router, prefix="/api/v1/tickets", tags=["Support"])
app.include_router(kpi_router, prefix="/api/v1/kpis", tags=["KPIs"])
app.include_router(revenue_router, prefix="/api/v1/revenue", tags=["Revenue"])
app.include_router(report_router, prefix="/api/v1/reports", tags=["Reports"])
app.include_router(forecast_router, prefix="/api/v1/forecasts", tags=["Forecasts"])
app.include_router(experiment_router, prefix="/api/v1/experiments", tags=["Growth"])
app.include_router(dashboard_router, prefix="/api/v1/dashboard", tags=["BI"])
app.include_router(ai_router, prefix="/api/v1/ai", tags=["AI Agents"])
