terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = var.aws_region
}

resource "aws_vpc" "nexus_vpc" {
  cidr_block = "10.0.0.0/16"
  tags = {
    Name = "nexus-core-v8-vpc"
  }
}

resource "aws_subnet" "nexus_subnet" {
  vpc_id     = aws_vpc.nexus_vpc.id
  cidr_block = "10.0.1.0/24"
  tags = {
    Name = "nexus-core-v8-subnet"
  }
}

resource "aws_instance" "nexus_server" {
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = "t3.large"
  subnet_id     = aws_subnet.nexus_subnet.id
  tags = {
    Name = "nexus-core-v8-server"
  }
}

variable "aws_region" {
  default = "us-east-1"
}

output "instance_ip" {
  value = aws_instance.nexus_server.public_ip
}
