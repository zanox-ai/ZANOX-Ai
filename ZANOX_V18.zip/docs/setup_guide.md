# ZANOX V18 Setup Guide

## Prerequisites
- Python 3.11+
- PostgreSQL 15+
- Redis 7+
- Docker (optional)

## Installation

### 1. Clone Repository
```bash
git clone https://github.com/zanox/v18-finance.git
cd v18-finance
```

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. Configure Environment
```bash
cp .env.example .env
# Edit .env with your database and API credentials
```

### 4. Initialize Database
```bash
python -m migrations.001_initial
```

### 5. Run Application
```bash
uvicorn main:app --host 0.0.0.0 --port 8000
```

## Docker Deployment
```bash
docker-compose up -d
```

## Kubernetes Deployment
```bash
kubectl apply -f deployment/k8s/
```

## API Keys Setup
Configure the following integration API keys in `.env`:
- Stripe
- PayPal
- Plaid
- Binance / Coinbase
- Alpha Vantage / Polygon
- QuickBooks / Xero

## Testing
```bash
pytest tests/ -v
```
