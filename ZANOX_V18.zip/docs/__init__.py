"""
ZANOX V18 Documentation Module
Project documentation and guides.
"""
