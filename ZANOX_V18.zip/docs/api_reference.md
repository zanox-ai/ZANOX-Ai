# ZANOX V18 API Reference

## Base URL
`/api/v18/`

## Authentication
All endpoints require Bearer token authentication.

## Endpoints

### Finance Engine
- `POST /transactions` - Create transaction
- `GET /transactions/{id}` - Get transaction
- `GET /cash-flow/{user_id}` - Cash flow analysis

### Accounting
- `POST /accounts` - Create account
- `GET /accounts/{id}` - Get account
- `GET /trial-balance/{user_id}` - Trial balance

### Budget
- `POST /budgets` - Create budget
- `GET /budgets/{id}/status` - Budget status

### Investments
- `POST /investments/trade` - Execute trade
- `GET /investments/portfolio/{user_id}` - Portfolio view

### Tax
- `POST /tax/calculate` - Calculate tax
- `GET /tax/summary/{user_id}/{year}` - Tax summary

### Reporting
- `POST /reports/generate` - Generate report
- `GET /reports/{user_id}` - List reports

## Response Format
All responses follow JSON format with `success` boolean and `data` object.
