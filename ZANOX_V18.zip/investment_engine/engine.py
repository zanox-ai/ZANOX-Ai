"""
ZANOX V18 Investment Engine Core
"""
from typing import Dict, Any, List, Optional
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("investment_engine")


class InvestmentEngine:
    def __init__(self):
        self._processor = None

    async def initialize(self):
        from .processor import InvestmentProcessor
        self._processor = InvestmentProcessor()
        logger.info("InvestmentEngine initialized")

    async def execute_trade(self, data: Dict[str, Any]) -> Dict[str, Any]:
        if not self._processor:
            raise RuntimeError("Engine not initialized")
        return await self._processor.execute_trade(data)

    async def get_portfolio(self, user_id: UUID) -> Dict[str, Any]:
        if not self._processor:
            raise RuntimeError("Engine not initialized")
        return await self._processor.get_portfolio(user_id)

    async def rebalance_portfolio(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        if not self._processor:
            raise RuntimeError("Engine not initialized")
        return await self._processor.rebalance(payload)

    async def get_investment_summary(self, user_id: UUID) -> Dict[str, Any]:
        if not self._processor:
            raise RuntimeError("Engine not initialized")
        return await self._processor.get_summary(user_id)

    async def shutdown(self):
        logger.info("InvestmentEngine shut down")
