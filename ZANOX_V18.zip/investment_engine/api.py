"""
ZANOX V18 Investment Engine API
"""
from fastapi import APIRouter
from uuid import UUID

from .engine import InvestmentEngine

router = APIRouter(prefix="/investments", tags=["investments"])
engine = InvestmentEngine()


@router.post("/trade")
async def execute_trade(data: dict):
    return await engine.execute_trade(data)


@router.get("/portfolio/{user_id}")
async def get_portfolio(user_id: UUID):
    return await engine.get_portfolio(user_id)


@router.post("/rebalance")
async def rebalance_portfolio(payload: dict):
    return await engine.rebalance_portfolio(payload)


@router.get("/summary/{user_id}")
async def get_summary(user_id: UUID):
    return await engine.get_investment_summary(user_id)
