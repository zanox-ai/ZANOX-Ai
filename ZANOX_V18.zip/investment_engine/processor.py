"""
ZANOX V18 Investment Processor
Handles investment trades and portfolio updates.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.database import get_db_context
from shared.exceptions import ValidationError, InsufficientFundsError
from shared.utils import generate_reference, calculate_roi
from shared.kafka_client import produce_event
from shared.logger import get_logger

logger = get_logger("investment_processor")


class InvestmentProcessor:
    async def execute_trade(self, data: Dict[str, Any]) -> Dict[str, Any]:
        required = ["user_id", "symbol", "action", "quantity", "price"]
        for field in required:
            if field not in data:
                raise ValidationError(f"Missing required field: {field}")

        quantity = Decimal(str(data["quantity"]))
        price = Decimal(str(data["price"]))
        total = quantity * price
        fees = Decimal(str(data.get("fees", 0)))
        total_with_fees = total + fees

        reference = generate_reference("TRD")
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                INSERT INTO investment_trades (
                    id, user_id, reference, symbol, action, quantity, price, total_amount,
                    fees, currency, trade_date, status, exchange, metadata, created_at
                ) VALUES (
                    gen_random_uuid(), :user_id, :reference, :symbol, :action, :quantity, :price, :total_amount,
                    :fees, :currency, :trade_date, 'completed', :exchange, :metadata, NOW()
                ) RETURNING id
            """)
            result = await session.execute(query, {
                "user_id": data["user_id"],
                "reference": reference,
                "symbol": data["symbol"],
                "action": data["action"],
                "quantity": str(quantity),
                "price": str(price),
                "total_amount": str(total),
                "fees": str(fees),
                "currency": data.get("currency", "USD"),
                "trade_date": data.get("trade_date", date.today()),
                "exchange": data.get("exchange", ""),
                "metadata": str(data.get("metadata", {})),
            })
            trade_id = str(result.fetchone()[0])

            produce_event("zanox.finance.investments", {
                "event": "trade_executed",
                "trade_id": trade_id,
                "symbol": data["symbol"],
                "action": data["action"],
                "total": float(total),
            })
            logger.info(f"Trade executed: {reference} - {data['action']} {data['symbol']}")
            return {"trade_id": trade_id, "reference": reference, "total": float(total), "status": "completed"}

    async def get_portfolio(self, user_id: UUID) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT symbol, asset_type, SUM(CASE WHEN action = 'buy' THEN quantity ELSE -quantity END) as total_quantity,
                       AVG(CASE WHEN action = 'buy' THEN price END) as avg_buy_price
                FROM investment_trades
                WHERE user_id = :user_id AND status = 'completed'
                GROUP BY symbol, asset_type
                HAVING SUM(CASE WHEN action = 'buy' THEN quantity ELSE -quantity END) > 0
            """)
            result = await session.execute(query, {"user_id": str(user_id)})
            holdings = [dict(row) for row in result.mappings()]
            total_value = sum(Decimal(str(h["total_quantity"])) * Decimal(str(h.get("avg_buy_price", 0))) for h in holdings)
            return {
                "user_id": str(user_id),
                "holdings": holdings,
                "total_holdings": len(holdings),
                "estimated_value": float(total_value.quantize(Decimal("0.01"))),
            }

    async def rebalance(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        from portfolio_management.manager import PortfolioManager
        manager = PortfolioManager()
        portfolio_id = payload.get("portfolio_id")
        targets = {k: Decimal(str(v)) for k, v in payload.get("targets", {}).items()}
        return await manager.rebalance(portfolio_id, targets)

    async def get_summary(self, user_id: UUID) -> Dict[str, Any]:
        portfolio = await self.get_portfolio(user_id)
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT COALESCE(SUM(total_amount), 0) as total_invested,
                       COUNT(*) as trade_count
                FROM investment_trades
                WHERE user_id = :user_id AND status = 'completed'
            """)
            result = await session.execute(query, {"user_id": str(user_id)})
            row = result.mappings().fetchone()
            total_invested = Decimal(str(row["total_invested"]))
            trade_count = row["trade_count"]
        return {
            "user_id": str(user_id),
            "total_invested": float(total_invested.quantize(Decimal("0.01"))),
            "trade_count": trade_count,
            "holdings": portfolio["holdings"],
            "estimated_value": portfolio["estimated_value"],
        }
