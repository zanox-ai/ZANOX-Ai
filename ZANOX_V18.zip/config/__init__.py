"""
ZANOX V18 Configuration Module
Application configuration management.
"""
