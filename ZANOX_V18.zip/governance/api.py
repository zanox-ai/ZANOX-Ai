"""
ZANOX V18 Governance API
"""
from fastapi import APIRouter
from uuid import UUID

from .engine import GovernanceEngine

router = APIRouter(prefix="/governance", tags=["governance"])
engine = GovernanceEngine()


@router.get("/policies")
async def get_policies():
    return await engine.get_policies()


@router.post("/enforce/{user_id}/{policy_id}")
async def enforce_policy(user_id: UUID, policy_id: str, context: dict):
    return await engine.enforce_policy(user_id, policy_id, context)


@router.get("/violations/{user_id}")
async def get_violations(user_id: UUID):
    return await engine.get_policy_violations(user_id)
