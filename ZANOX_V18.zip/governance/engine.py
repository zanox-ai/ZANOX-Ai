"""
ZANOX V18 Governance Engine Core
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("governance_engine")


class GovernanceEngine:
    def __init__(self):
        self._manager = None

    async def initialize(self):
        from .manager import GovernanceManager
        self._manager = GovernanceManager()
        logger.info("GovernanceEngine initialized")

    async def get_policies(self) -> List[Dict[str, Any]]:
        if not self._manager:
            raise RuntimeError("Engine not initialized")
        return await self._manager.get_policies()

    async def enforce_policy(self, user_id: UUID, policy_id: str, context: Dict[str, Any]) -> Dict[str, Any]:
        if not self._manager:
            raise RuntimeError("Engine not initialized")
        return await self._manager.enforce(user_id, policy_id, context)

    async def get_policy_violations(self, user_id: UUID) -> List[Dict[str, Any]]:
        if not self._manager:
            raise RuntimeError("Engine not initialized")
        return await self._manager.get_violations(user_id)

    async def shutdown(self):
        logger.info("GovernanceEngine shut down")
