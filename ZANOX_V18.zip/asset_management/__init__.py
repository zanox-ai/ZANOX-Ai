"""
ZANOX V18 Asset Management Engine
Tracks physical and digital assets with depreciation.
"""
from .engine import AssetManagementEngine
from .manager import AssetManager
from .api import router

__all__ = ["AssetManagementEngine", "AssetManager", "router"]
