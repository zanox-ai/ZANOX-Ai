"""
ZANOX V18 Asset Management Engine Core
"""
from typing import Dict, Any, List, Optional
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("asset_management_engine")


class AssetManagementEngine:
    def __init__(self):
        self._manager = None

    async def initialize(self):
        from .manager import AssetManager
        self._manager = AssetManager()
        logger.info("AssetManagementEngine initialized")

    async def create_asset(self, data: Dict[str, Any]) -> Dict[str, Any]:
        if not self._manager:
            raise RuntimeError("Engine not initialized")
        return await self._manager.create(data)

    async def get_asset(self, asset_id: UUID) -> Dict[str, Any]:
        if not self._manager:
            raise RuntimeError("Engine not initialized")
        return await self._manager.get(asset_id)

    async def list_assets(self, user_id: UUID, asset_type: Optional[str] = None) -> List[Dict[str, Any]]:
        if not self._manager:
            raise RuntimeError("Engine not initialized")
        return await self._manager.list(user_id, asset_type)

    async def calculate_depreciation(self, asset_id: UUID, as_of: date) -> Dict[str, Any]:
        if not self._manager:
            raise RuntimeError("Engine not initialized")
        return await self._manager.calculate_depreciation(asset_id, as_of)

    async def get_asset_summary(self, user_id: UUID) -> Dict[str, Any]:
        if not self._manager:
            raise RuntimeError("Engine not initialized")
        return await self._manager.get_summary(user_id)

    async def shutdown(self):
        logger.info("AssetManagementEngine shut down")
