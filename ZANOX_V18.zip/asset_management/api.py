"""
ZANOX V18 Asset Management API
"""
from fastapi import APIRouter
from typing import Optional
from uuid import UUID
from datetime import date

from .engine import AssetManagementEngine

router = APIRouter(prefix="/assets", tags=["assets"])
engine = AssetManagementEngine()


@router.post("/")
async def create_asset(data: dict):
    return await engine.create_asset(data)


@router.get("/{asset_id}")
async def get_asset(asset_id: UUID):
    return await engine.get_asset(asset_id)


@router.get("/")
async def list_assets(user_id: UUID, asset_type: Optional[str] = None):
    return await engine.list_assets(user_id, asset_type)


@router.get("/{asset_id}/depreciation")
async def calculate_depreciation(asset_id: UUID, as_of: date = date.today()):
    return await engine.calculate_depreciation(asset_id, as_of)


@router.get("/summary/{user_id}")
async def get_asset_summary(user_id: UUID):
    return await engine.get_asset_summary(user_id)
