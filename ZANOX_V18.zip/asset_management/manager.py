"""
ZANOX V18 Asset Manager
Manages asset lifecycle, valuation, and depreciation.
"""
from typing import Dict, Any, List, Optional
from decimal import Decimal
from datetime import date, timedelta
from uuid import UUID

from shared.database import get_db_context
from shared.exceptions import ValidationError
from shared.logger import get_logger

logger = get_logger("asset_manager")


class AssetManager:
    async def create(self, data: Dict[str, Any]) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                INSERT INTO assets (
                    id, user_id, name, asset_type, category, purchase_date, purchase_price,
                    current_value, currency, location, description, depreciation_method,
                    useful_life_years, salvage_value, status, created_at, updated_at
                ) VALUES (
                    gen_random_uuid(), :user_id, :name, :asset_type, :category, :purchase_date, :purchase_price,
                    :current_value, :currency, :location, :description, :depreciation_method,
                    :useful_life_years, :salvage_value, 'active', NOW(), NOW()
                ) RETURNING id
            """)
            result = await session.execute(query, {
                "user_id": data["user_id"],
                "name": data["name"],
                "asset_type": data.get("asset_type", "tangible"),
                "category": data.get("category", "other"),
                "purchase_date": data.get("purchase_date", date.today()),
                "purchase_price": str(data.get("purchase_price", 0)),
                "current_value": str(data.get("current_value", data.get("purchase_price", 0))),
                "currency": data.get("currency", "USD"),
                "location": data.get("location", ""),
                "description": data.get("description", ""),
                "depreciation_method": data.get("depreciation_method", "straight_line"),
                "useful_life_years": data.get("useful_life_years", 5),
                "salvage_value": str(data.get("salvage_value", 0)),
            })
            asset_id = str(result.fetchone()[0])
            logger.info(f"Created asset: {asset_id} - {data['name']}")
            return {"asset_id": asset_id, "name": data["name"], "purchase_price": data.get("purchase_price")}

    async def get(self, asset_id: UUID) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("SELECT * FROM assets WHERE id = :id")
            result = await session.execute(query, {"id": str(asset_id)})
            row = result.mappings().fetchone()
            if not row:
                raise ValidationError("Asset not found")
            return dict(row)

    async def list(self, user_id: UUID, asset_type: Optional[str] = None) -> List[Dict[str, Any]]:
        async with get_db_context() as session:
            from sqlalchemy import text
            if asset_type:
                query = text("SELECT * FROM assets WHERE user_id = :user_id AND asset_type = :type AND status = 'active' ORDER BY created_at DESC")
                result = await session.execute(query, {"user_id": str(user_id), "type": asset_type})
            else:
                query = text("SELECT * FROM assets WHERE user_id = :user_id AND status = 'active' ORDER BY created_at DESC")
                result = await session.execute(query, {"user_id": str(user_id)})
            return [dict(row) for row in result.mappings()]

    async def calculate_depreciation(self, asset_id: UUID, as_of: date) -> Dict[str, Any]:
        asset = await self.get(asset_id)
        purchase_price = Decimal(str(asset["purchase_price"]))
        salvage = Decimal(str(asset["salvage_value"]))
        life_years = asset["useful_life_years"]
        purchase_date = asset["purchase_date"]
        method = asset["depreciation_method"]

        if method == "straight_line":
            annual_depreciation = (purchase_price - salvage) / life_years
            years_elapsed = (as_of - purchase_date).days / 365.25
            accumulated = annual_depreciation * Decimal(str(years_elapsed))
            accumulated = min(accumulated, purchase_price - salvage)
            book_value = purchase_price - accumulated
        elif method == "declining_balance":
            rate = Decimal("2") / life_years
            years_elapsed = int((as_of - purchase_date).days / 365.25)
            book_value = purchase_price
            for _ in range(years_elapsed):
                book_value = book_value * (1 - rate)
            book_value = max(book_value, salvage)
            accumulated = purchase_price - book_value
        else:
            annual_depreciation = (purchase_price - salvage) / life_years
            accumulated = annual_depreciation
            book_value = purchase_price - accumulated

        return {
            "asset_id": str(asset_id),
            "method": method,
            "purchase_price": float(purchase_price),
            "salvage_value": float(salvage),
            "useful_life_years": life_years,
            "as_of": as_of.isoformat(),
            "accumulated_depreciation": float(accumulated.quantize(Decimal("0.01"))),
            "book_value": float(book_value.quantize(Decimal("0.01"))),
            "annual_depreciation": float(annual_depreciation.quantize(Decimal("0.01"))) if 'annual_depreciation' in dir() else 0,
        }

    async def get_summary(self, user_id: UUID) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT asset_type, COUNT(*) as count, COALESCE(SUM(current_value), 0) as total_value
                FROM assets WHERE user_id = :user_id AND status = 'active'
                GROUP BY asset_type
            """)
            result = await session.execute(query, {"user_id": str(user_id)})
            by_type = [dict(row) for row in result.mappings()]
            total_value = sum(Decimal(str(t["total_value"])) for t in by_type)
            return {
                "total_assets": sum(t["count"] for t in by_type),
                "total_value": float(total_value.quantize(Decimal("0.01"))),
                "by_type": by_type,
            }
