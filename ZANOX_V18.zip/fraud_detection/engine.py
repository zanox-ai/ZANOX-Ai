"""
ZANOX V18 Fraud Detection Engine Core
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import datetime
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("fraud_engine")


class FraudEngine:
    def __init__(self):
        self._detector = None

    async def initialize(self):
        from .detector import FraudDetector
        self._detector = FraudDetector()
        logger.info("FraudEngine initialized")

    async def scan_transaction(self, transaction_data: Dict[str, Any]) -> Dict[str, Any]:
        if not self._detector:
            raise RuntimeError("Engine not initialized")
        return await self._detector.scan(transaction_data)

    async def scan_user_activity(self, user_id: UUID) -> List[Dict[str, Any]]:
        if not self._detector:
            raise RuntimeError("Engine not initialized")
        return await self._detector.scan_user(user_id)

    async def get_fraud_alerts(self, user_id: UUID) -> List[Dict[str, Any]]:
        if not self._detector:
            raise RuntimeError("Engine not initialized")
        return await self._detector.get_alerts(user_id)

    async def shutdown(self):
        logger.info("FraudEngine shut down")
