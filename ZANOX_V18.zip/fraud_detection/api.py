"""
ZANOX V18 Fraud Detection API
"""
from fastapi import APIRouter
from uuid import UUID

from .engine import FraudEngine

router = APIRouter(prefix="/fraud", tags=["fraud"])
engine = FraudEngine()


@router.post("/scan")
async def scan_transaction(data: dict):
    return await engine.scan_transaction(data)


@router.get("/scan-user/{user_id}")
async def scan_user(user_id: UUID):
    return await engine.scan_user_activity(user_id)


@router.get("/alerts/{user_id}")
async def get_alerts(user_id: UUID):
    return await engine.get_fraud_alerts(user_id)
