"""
ZANOX V18 Fraud Detector
Rule-based and heuristic fraud detection.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import datetime, timedelta
from uuid import UUID

from shared.database import get_db_context
from shared.exceptions import FraudDetectedError
from shared.logger import get_logger

logger = get_logger("fraud_detector")


class FraudDetector:
    async def scan(self, transaction_data: Dict[str, Any]) -> Dict[str, Any]:
        alerts = []
        amount = Decimal(str(transaction_data.get("amount", 0)))
        user_id = transaction_data.get("user_id")

        if amount > 10000:
            alerts.append({"rule": "large_amount", "severity": "medium", "message": f"Transaction amount ${amount} exceeds threshold"})

        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT COUNT(*) as count FROM transactions
                WHERE user_id = :user_id AND created_at >= NOW() - INTERVAL '1 hour'
            """)
            result = await session.execute(query, {"user_id": user_id})
            recent_count = result.fetchone()[0]
            if recent_count > 10:
                alerts.append({"rule": "velocity", "severity": "high", "message": f"{recent_count} transactions in last hour"})

        if Decimal(str(transaction_data.get("amount", 0))) > Decimal(str(transaction_data.get("average_amount", 0))) * 5:
            alerts.append({"rule": "unusual_amount", "severity": "high", "message": "Amount significantly above average"})

        is_fraud = any(a["severity"] == "high" for a in alerts)
        return {
            "transaction_id": transaction_data.get("id"),
            "alerts": alerts,
            "alert_count": len(alerts),
            "is_fraudulent": is_fraud,
            "action": "block" if is_fraud else "allow",
        }

    async def scan_user(self, user_id: UUID) -> List[Dict[str, Any]]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT * FROM transactions
                WHERE user_id = :user_id AND created_at >= NOW() - INTERVAL '24 hours'
                ORDER BY amount DESC
            """)
            result = await session.execute(query, {"user_id": str(user_id)})
            transactions = [dict(row) for row in result.mappings()]

        suspicious = []
        for txn in transactions:
            scan = await self.scan(txn)
            if scan["alert_count"] > 0:
                suspicious.append({"transaction_id": txn["id"], "alerts": scan["alerts"]})
        return suspicious

    async def get_alerts(self, user_id: UUID) -> List[Dict[str, Any]]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("SELECT * FROM fraud_alerts WHERE user_id = :user_id ORDER BY created_at DESC")
            result = await session.execute(query, {"user_id": str(user_id)})
            return [dict(row) for row in result.mappings()]
