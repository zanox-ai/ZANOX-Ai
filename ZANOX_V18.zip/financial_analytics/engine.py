"""
ZANOX V18 Financial Analytics Engine Core
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("financial_analytics_engine")


class FinancialAnalyticsEngine:
    def __init__(self):
        self._analyzer = None

    async def initialize(self):
        from .analyzer import FinancialAnalyzer
        self._analyzer = FinancialAnalyzer()
        logger.info("FinancialAnalyticsEngine initialized")

    async def query_transactions(self, params: Dict[str, Any]) -> Dict[str, Any]:
        if not self._analyzer:
            raise RuntimeError("Engine not initialized")
        return await self._analyzer.query_transactions(params)

    async def get_financial_summary(self, user_id: UUID, start: date, end: date) -> Dict[str, Any]:
        if not self._analyzer:
            raise RuntimeError("Engine not initialized")
        return await self._analyzer.get_summary(user_id, start, end)

    async def get_trend_analysis(self, user_id: UUID, metric: str, periods: int = 12) -> List[Dict[str, Any]]:
        if not self._analyzer:
            raise RuntimeError("Engine not initialized")
        return await self._analyzer.get_trends(user_id, metric, periods)

    async def shutdown(self):
        logger.info("FinancialAnalyticsEngine shut down")
