"""
ZANOX V18 Financial Analytics API
"""
from fastapi import APIRouter
from uuid import UUID
from datetime import date

from .engine import FinancialAnalyticsEngine

router = APIRouter(prefix="/analytics", tags=["analytics"])
engine = FinancialAnalyticsEngine()


@router.post("/transactions")
async def query_transactions(params: dict):
    return await engine.query_transactions(params)


@router.get("/summary/{user_id}")
async def get_summary(user_id: UUID, start: date, end: date):
    return await engine.get_financial_summary(user_id, start, end)


@router.get("/trends/{user_id}")
async def get_trends(user_id: UUID, metric: str, periods: int = 12):
    return await engine.get_trend_analysis(user_id, metric, periods)
