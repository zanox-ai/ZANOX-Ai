"""
ZANOX V18 Financial Analyzer
Comprehensive analytics across all financial dimensions.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date, timedelta
from uuid import UUID

from shared.database import get_db_context
from shared.utils import calculate_growth_rate, safe_divide
from shared.logger import get_logger

logger = get_logger("financial_analyzer")


class FinancialAnalyzer:
    async def query_transactions(self, params: Dict[str, Any]) -> Dict[str, Any]:
        user_id = params.get("user_id")
        start = params.get("start_date")
        end = params.get("end_date")
        tx_type = params.get("type")
        async with get_db_context() as session:
            from sqlalchemy import text
            if tx_type:
                query = text("""
                    SELECT * FROM transactions WHERE user_id = :user_id AND type = :type
                    AND transaction_date BETWEEN :start AND :end ORDER BY transaction_date DESC
                """)
                result = await session.execute(query, {"user_id": str(user_id), "type": tx_type, "start": start, "end": end})
            else:
                query = text("""
                    SELECT * FROM transactions WHERE user_id = :user_id
                    AND transaction_date BETWEEN :start AND :end ORDER BY transaction_date DESC
                """)
                result = await session.execute(query, {"user_id": str(user_id), "start": start, "end": end})
            transactions = [dict(row) for row in result.mappings()]
        return {"count": len(transactions), "transactions": transactions}

    async def get_summary(self, user_id: UUID, start: date, end: date) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            income = await session.execute(text("""
                SELECT COALESCE(SUM(amount), 0) as total FROM transactions
                WHERE user_id = :user_id AND type = 'income' AND transaction_date BETWEEN :start AND :end AND status = 'completed'
            """), {"user_id": str(user_id), "start": start, "end": end})
            expenses = await session.execute(text("""
                SELECT COALESCE(SUM(amount), 0) as total FROM transactions
                WHERE user_id = :user_id AND type = 'expense' AND transaction_date BETWEEN :start AND :end AND status = 'completed'
            """), {"user_id": str(user_id), "start": start, "end": end})
            total_income = Decimal(str(income.fetchone()[0]))
            total_expenses = Decimal(str(expenses.fetchone()[0]))
        return {
            "period": {"start": start.isoformat(), "end": end.isoformat()},
            "total_income": float(total_income),
            "total_expenses": float(total_expenses),
            "net": float(total_income - total_expenses),
            "savings_rate": float(safe_divide(total_income - total_expenses, total_income, Decimal("0")) * 100),
        }

    async def get_trends(self, user_id: UUID, metric: str, periods: int = 12) -> List[Dict[str, Any]]:
        today = date.today()
        trends = []
        for i in range(periods - 1, -1, -1):
            month_date = today - timedelta(days=i * 30)
            start = date(month_date.year, month_date.month, 1)
            if month_date.month == 12:
                end = date(month_date.year + 1, 1, 1) - timedelta(days=1)
            else:
                end = date(month_date.year, month_date.month + 1, 1) - timedelta(days=1)
            summary = await self.get_summary(user_id, start, end)
            trends.append({"month": start.strftime("%Y-%m"), "value": summary.get(metric, 0)})
        return trends
