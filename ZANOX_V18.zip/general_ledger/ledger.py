"""
ZANOX V18 Ledger
Account-level ledger with running balance computation.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.database import get_db_context
from shared.logger import get_logger

logger = get_logger("ledger")


class Ledger:
    async def get_balance(self, account_id: UUID, as_of: date) -> Decimal:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT COALESCE(SUM(debit - credit), 0) as balance
                FROM general_ledger_entries
                WHERE account_id = :account_id AND entry_date <= :as_of
            """)
            result = await session.execute(query, {"account_id": str(account_id), "as_of": as_of})
            balance = Decimal(str(result.fetchone()[0]))
            return balance

    async def get_entries(self, account_id: UUID, start: date, end: date) -> List[Dict[str, Any]]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT gle.*, a.name as account_name, a.account_type
                FROM general_ledger_entries gle
                JOIN accounts a ON a.id = gle.account_id
                WHERE gle.account_id = :account_id
                AND gle.entry_date BETWEEN :start AND :end
                ORDER BY gle.entry_date, gle.created_at
            """)
            result = await session.execute(query, {
                "account_id": str(account_id), "start": start, "end": end
            })
            entries = []
            running_balance = Decimal("0")
            for row in result.mappings():
                entry = dict(row)
                running_balance += Decimal(str(entry.get("debit", 0))) - Decimal(str(entry.get("credit", 0)))
                entry["running_balance"] = float(running_balance)
                entries.append(entry)
            return entries

    async def get_account_summary(self, user_id: UUID, as_of: date) -> List[Dict[str, Any]]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT a.id, a.name, a.account_type, a.category,
                       COALESCE(SUM(gle.debit - gle.credit), 0) as balance
                FROM accounts a
                LEFT JOIN general_ledger_entries gle ON gle.account_id = a.id AND gle.entry_date <= :as_of
                WHERE a.user_id = :user_id AND a.is_active = true
                GROUP BY a.id, a.name, a.account_type, a.category
                ORDER BY a.account_type, a.name
            """)
            result = await session.execute(query, {"user_id": str(user_id), "as_of": as_of})
            return [dict(row) for row in result.mappings()]
