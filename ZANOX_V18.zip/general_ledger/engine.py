"""
ZANOX V18 General Ledger Engine Core
Manages the general ledger lifecycle and posting rules.
"""
from typing import Dict, Any, List, Optional
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.exceptions import ValidationError, InvalidTransactionError
from shared.database import get_db_context
from shared.logger import get_logger

logger = get_logger("general_ledger_engine")


class GeneralLedgerEngine:
    def __init__(self):
        self._ledger = None
        self._posting = None

    async def initialize(self):
        from .ledger import Ledger
        from .posting import PostingManager
        self._ledger = Ledger()
        self._posting = PostingManager()
        logger.info("GeneralLedgerEngine initialized")

    async def post_transaction(self, data: Dict[str, Any]) -> Dict[str, Any]:
        if not self._posting:
            raise RuntimeError("Engine not initialized")
        return await self._posting.post(data)

    async def get_account_balance(self, account_id: UUID, as_of: date) -> Decimal:
        if not self._ledger:
            raise RuntimeError("Engine not initialized")
        return await self._ledger.get_balance(account_id, as_of)

    async def get_ledger_entries(self, account_id: UUID, start: date, end: date) -> List[Dict[str, Any]]:
        if not self._ledger:
            raise RuntimeError("Engine not initialized")
        return await self._ledger.get_entries(account_id, start, end)

    async def close_period(self, user_id: UUID, period_end: date) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                INSERT INTO period_closures (id, user_id, period_end, closed_at, status)
                VALUES (gen_random_uuid(), :user_id, :period_end, NOW(), 'closed')
                RETURNING id
            """)
            result = await session.execute(query, {"user_id": str(user_id), "period_end": period_end})
            closure_id = str(result.fetchone()[0])
            logger.info(f"Closed period {period_end} for user {user_id}")
            return {"closure_id": closure_id, "period_end": period_end.isoformat(), "status": "closed"}

    async def reopen_period(self, closure_id: UUID) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                UPDATE period_closures SET status = 'reopened', reopened_at = NOW()
                WHERE id = :id RETURNING id, period_end, status
            """)
            result = await session.execute(query, {"id": str(closure_id)})
            row = result.mappings().fetchone()
            if not row:
                raise ValidationError("Period closure not found")
            logger.info(f"Reopened period {row['period_end']}")
            return dict(row)

    async def get_period_status(self, user_id: UUID, period_end: date) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT * FROM period_closures
                WHERE user_id = :user_id AND period_end = :period_end
                ORDER BY closed_at DESC LIMIT 1
            """)
            result = await session.execute(query, {"user_id": str(user_id), "period_end": period_end})
            row = result.mappings().fetchone()
            if row:
                return {"closed": True, "closure_id": str(row["id"]), "closed_at": row["closed_at"].isoformat()}
            return {"closed": False}

    async def shutdown(self):
        logger.info("GeneralLedgerEngine shut down")
