"""
ZANOX V18 Posting Manager
Handles posting of transactions to the general ledger.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.exceptions import ValidationError, InvalidTransactionError
from shared.database import get_db_context
from shared.utils import generate_reference
from shared.kafka_client import produce_event
from shared.logger import get_logger

logger = get_logger("posting_manager")


class PostingManager:
    async def post(self, data: Dict[str, Any]) -> Dict[str, Any]:
        required = ["user_id", "account_id", "amount", "entry_type", "entry_date"]
        for field in required:
            if field not in data:
                raise ValidationError(f"Missing required field: {field}")

        entry_type = data["entry_type"]
        if entry_type not in ["debit", "credit"]:
            raise InvalidTransactionError(f"Invalid entry type: {entry_type}")

        amount = Decimal(str(data["amount"]))
        if amount <= 0:
            raise InvalidTransactionError("Amount must be positive")

        reference = generate_reference("GL")
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                INSERT INTO general_ledger_entries (
                    id, user_id, account_id, reference, entry_type, amount,
                    debit, credit, description, source_id, source_type,
                    entry_date, created_at
                ) VALUES (
                    gen_random_uuid(), :user_id, :account_id, :reference, :entry_type, :amount,
                    :debit, :credit, :description, :source_id, :source_type,
                    :entry_date, NOW()
                ) RETURNING id
            """)
            debit = amount if entry_type == "debit" else Decimal("0")
            credit = amount if entry_type == "credit" else Decimal("0")
            result = await session.execute(query, {
                "user_id": data["user_id"],
                "account_id": data["account_id"],
                "reference": reference,
                "entry_type": entry_type,
                "amount": str(amount),
                "debit": str(debit),
                "credit": str(credit),
                "description": data.get("description", ""),
                "source_id": data.get("source_id"),
                "source_type": data.get("source_type", ""),
                "entry_date": data["entry_date"],
            })
            entry_id = str(result.fetchone()[0])

            await self._update_account_balance(data["account_id"], debit, credit)

            produce_event("zanox.finance.ledger", {
                "event": "ledger_posted",
                "reference": reference,
                "account_id": data["account_id"],
                "amount": float(amount),
                "entry_type": entry_type,
            })

            logger.info(f"Posted to ledger: {reference} - {entry_type} {amount}")
            return {
                "entry_id": entry_id,
                "reference": reference,
                "account_id": data["account_id"],
                "amount": float(amount),
                "entry_type": entry_type,
            }

    async def _update_account_balance(self, account_id: str, debit: Decimal, credit: Decimal) -> None:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                UPDATE accounts SET balance = balance + :debit - :credit, updated_at = NOW()
                WHERE id = :account_id
            """)
            await session.execute(query, {"account_id": account_id, "debit": str(debit), "credit": str(credit)})

    async def bulk_post(self, entries: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        results = []
        for entry in entries:
            try:
                result = await self.post(entry)
                results.append({"success": True, "data": result})
            except Exception as e:
                results.append({"success": False, "error": str(e), "entry": entry})
        return results
