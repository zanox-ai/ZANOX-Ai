-- ZANOX V18 Database Indexes

CREATE INDEX IF NOT EXISTS idx_transactions_user_id ON transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_transactions_type ON transactions(type);
CREATE INDEX IF NOT EXISTS idx_transactions_date ON transactions(transaction_date);
CREATE INDEX IF NOT EXISTS idx_transactions_status ON transactions(status);
CREATE INDEX IF NOT EXISTS idx_transactions_user_date ON transactions(user_id, transaction_date);

CREATE INDEX IF NOT EXISTS idx_accounts_user_id ON accounts(user_id);
CREATE INDEX IF NOT EXISTS idx_accounts_type ON accounts(account_type);
CREATE INDEX IF NOT EXISTS idx_accounts_active ON accounts(is_active);

CREATE INDEX IF NOT EXISTS idx_journal_entries_header ON journal_entries(header_id);
CREATE INDEX IF NOT EXISTS idx_journal_entries_account ON journal_entries(account_id);
CREATE INDEX IF NOT EXISTS idx_journal_entries_date ON journal_entries(entry_date);

CREATE INDEX IF NOT EXISTS idx_ledger_entries_user ON general_ledger_entries(user_id);
CREATE INDEX IF NOT EXISTS idx_ledger_entries_account ON general_ledger_entries(account_id);
CREATE INDEX IF NOT EXISTS idx_ledger_entries_date ON general_ledger_entries(entry_date);

CREATE INDEX IF NOT EXISTS idx_budgets_user_id ON budgets(user_id);
CREATE INDEX IF NOT EXISTS idx_budgets_status ON budgets(status);
CREATE INDEX IF NOT EXISTS idx_budget_categories_budget ON budget_categories(budget_id);

CREATE INDEX IF NOT EXISTS idx_invoices_user_id ON invoices(user_id);
CREATE INDEX IF NOT EXISTS idx_invoices_status ON invoices(status);
CREATE INDEX IF NOT EXISTS idx_invoices_due_date ON invoices(due_date);

CREATE INDEX IF NOT EXISTS idx_payments_user_id ON payments(user_id);
CREATE INDEX IF NOT EXISTS idx_payments_direction ON payments(direction);

CREATE INDEX IF NOT EXISTS idx_subscriptions_user_id ON subscriptions(user_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_status ON subscriptions(status);
CREATE INDEX IF NOT EXISTS idx_subscriptions_next_billing ON subscriptions(next_billing_date);

CREATE INDEX IF NOT EXISTS idx_expense_records_user ON expense_records(user_id);
CREATE INDEX IF NOT EXISTS idx_expense_records_category ON expense_records(category);
CREATE INDEX IF NOT EXISTS idx_expense_records_date ON expense_records(transaction_date);

CREATE INDEX IF NOT EXISTS idx_revenue_records_user ON revenue_records(user_id);
CREATE INDEX IF NOT EXISTS idx_revenue_records_date ON revenue_records(transaction_date);

CREATE INDEX IF NOT EXISTS idx_investment_trades_user ON investment_trades(user_id);
CREATE INDEX IF NOT EXISTS idx_investment_trades_symbol ON investment_trades(symbol);

CREATE INDEX IF NOT EXISTS idx_alerts_user_id ON alerts(user_id);
CREATE INDEX IF NOT EXISTS idx_alerts_status ON alerts(status);
CREATE INDEX IF NOT EXISTS idx_alerts_type ON alerts(alert_type);

CREATE INDEX IF NOT EXISTS idx_audit_logs_entity ON audit_logs(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_performed ON audit_logs(performed_at);

CREATE INDEX IF NOT EXISTS idx_fraud_alerts_user ON fraud_alerts(user_id);
CREATE INDEX IF NOT EXISTS idx_fraud_alerts_status ON fraud_alerts(status);
