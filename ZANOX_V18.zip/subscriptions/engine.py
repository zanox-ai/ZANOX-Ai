"""
ZANOX V18 Subscription Management Engine Core
"""
from typing import Dict, Any, List, Optional
from decimal import Decimal
from datetime import date, datetime
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("subscription_engine")


class SubscriptionEngine:
    def __init__(self):
        self._tracker = None
        self._optimizer = None

    async def initialize(self):
        from .tracker import SubscriptionTracker
        from .optimizer import SubscriptionOptimizer
        self._tracker = SubscriptionTracker()
        self._optimizer = SubscriptionOptimizer()
        logger.info("SubscriptionEngine initialized")

    async def create_subscription(self, data: Dict[str, Any]) -> Dict[str, Any]:
        if not self._tracker:
            raise RuntimeError("Engine not initialized")
        return await self._tracker.create(data)

    async def list_subscriptions(self, user_id: UUID) -> List[Dict[str, Any]]:
        if not self._tracker:
            raise RuntimeError("Engine not initialized")
        return await self._tracker.list(user_id)

    async def cancel_subscription(self, subscription_id: UUID, reason: str) -> Dict[str, Any]:
        if not self._tracker:
            raise RuntimeError("Engine not initialized")
        return await self._tracker.cancel(subscription_id, reason)

    async def get_subscription_summary(self, user_id: UUID) -> Dict[str, Any]:
        if not self._tracker:
            raise RuntimeError("Engine not initialized")
        return await self._tracker.get_summary(user_id)

    async def find_duplicate_subscriptions(self, user_id: UUID) -> List[Dict[str, Any]]:
        if not self._optimizer:
            raise RuntimeError("Engine not initialized")
        return await self._optimizer.find_duplicates(user_id)

    async def get_optimization_recommendations(self, user_id: UUID) -> List[Dict[str, Any]]:
        if not self._optimizer:
            raise RuntimeError("Engine not initialized")
        return await self._optimizer.get_recommendations(user_id)

    async def shutdown(self):
        logger.info("SubscriptionEngine shut down")
