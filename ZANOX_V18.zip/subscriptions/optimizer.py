"""
ZANOX V18 Subscription Optimizer
Finds duplicate subscriptions and recommends optimizations.
"""
from typing import Dict, Any, List
from decimal import Decimal
from uuid import UUID

from shared.database import get_db_context
from shared.logger import get_logger

logger = get_logger("subscription_optimizer")


class SubscriptionOptimizer:
    async def find_duplicates(self, user_id: UUID) -> List[Dict[str, Any]]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT s1.id as id1, s1.name as name1, s1.amount as amount1,
                       s2.id as id2, s2.name as name2, s2.amount as amount2
                FROM subscriptions s1
                JOIN subscriptions s2 ON s1.user_id = s2.user_id
                AND s1.id < s2.id
                AND (LOWER(s1.name) = LOWER(s2.name)
                     OR LOWER(s1.provider) = LOWER(s2.provider)
                     OR similarity(s1.name, s2.name) > 0.7)
                WHERE s1.user_id = :user_id AND s1.status = 'active' AND s2.status = 'active'
            """)
            result = await session.execute(query, {"user_id": str(user_id)})
            duplicates = []
            for row in result.mappings():
                duplicates.append({
                    "subscription_1": {"id": str(row["id1"]), "name": row["name1"], "amount": float(row["amount1"])},
                    "subscription_2": {"id": str(row["id2"]), "name": row["name2"], "amount": float(row["amount2"])},
                    "potential_savings": float(row["amount1"]) + float(row["amount2"]),
                })
            return duplicates

    async def get_recommendations(self, user_id: UUID) -> List[Dict[str, Any]]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT category, COUNT(*) as count, COALESCE(SUM(amount), 0) as total
                FROM subscriptions
                WHERE user_id = :user_id AND status = 'active'
                GROUP BY category
                ORDER BY total DESC
            """)
            result = await session.execute(query, {"user_id": str(user_id)})
            categories = [dict(row) for row in result.mappings()]

        recommendations = []
        for cat in categories:
            if cat["category"] == "entertainment" and cat["count"] > 3:
                recommendations.append({
                    "type": "consolidate",
                    "category": cat["category"],
                    "message": f"You have {cat['count']} entertainment subscriptions. Consider bundling or consolidating.",
                    "potential_savings": float(cat["total"]) * 0.2,
                })
            if cat["category"] == "software" and cat["count"] > 5:
                recommendations.append({
                    "type": "audit",
                    "category": cat["category"],
                    "message": f"You have {cat['count']} software subscriptions. Audit for unused licenses.",
                    "potential_savings": float(cat["total"]) * 0.15,
                })

        unused_query = text("""
            SELECT * FROM subscriptions
            WHERE user_id = :user_id AND status = 'active'
            AND last_used_date < CURRENT_DATE - INTERVAL '3 months'
        """)
        async with get_db_context() as session:
            result = await session.execute(unused_query, {"user_id": str(user_id)})
            unused = [dict(row) for row in result.mappings()]
        for u in unused:
            recommendations.append({
                "type": "cancel_unused",
                "subscription_id": str(u["id"]),
                "name": u["name"],
                "message": f"'{u['name']}' hasn't been used in 3+ months. Consider cancelling.",
                "annual_savings": float(u["amount"]) * 12 if u.get("frequency") == "monthly" else float(u["amount"]),
            })

        return recommendations
