"""
ZANOX V18 Subscription Tracker
Manages subscription lifecycle and billing tracking.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date, datetime, timedelta
from uuid import UUID

from shared.database import get_db_context
from shared.exceptions import ValidationError
from shared.logger import get_logger

logger = get_logger("subscription_tracker")


class SubscriptionTracker:
    FREQUENCY_MULTIPLIERS = {
        "daily": 365, "weekly": 52, "biweekly": 26, "monthly": 12,
        "quarterly": 4, "semiannually": 2, "annually": 1,
    }

    async def create(self, data: Dict[str, Any]) -> Dict[str, Any]:
        required = ["user_id", "name", "amount", "currency", "frequency", "next_billing_date"]
        for field in required:
            if field not in data:
                raise ValidationError(f"Missing required field: {field}")

        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                INSERT INTO subscriptions (
                    id, user_id, name, provider, amount, currency, frequency,
                    next_billing_date, billing_day, category, description, status,
                    auto_renew, payment_method, created_at, updated_at
                ) VALUES (
                    gen_random_uuid(), :user_id, :name, :provider, :amount, :currency, :frequency,
                    :next_billing_date, :billing_day, :category, :description, 'active',
                    :auto_renew, :payment_method, NOW(), NOW()
                ) RETURNING id
            """)
            result = await session.execute(query, {
                "user_id": data["user_id"],
                "name": data["name"],
                "provider": data.get("provider", ""),
                "amount": str(data["amount"]),
                "currency": data["currency"],
                "frequency": data["frequency"],
                "next_billing_date": data["next_billing_date"],
                "billing_day": data.get("billing_day", data["next_billing_date"].day if hasattr(data["next_billing_date"], 'day') else 1),
                "category": data.get("category", "other"),
                "description": data.get("description", ""),
                "auto_renew": data.get("auto_renew", True),
                "payment_method": data.get("payment_method", ""),
            })
            subscription_id = str(result.fetchone()[0])
            logger.info(f"Created subscription: {subscription_id} - {data['name']}")
            return {"id": subscription_id, "name": data["name"], "amount": data["amount"]}

    async def list(self, user_id: UUID) -> List[Dict[str, Any]]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT * FROM subscriptions
                WHERE user_id = :user_id AND status = 'active'
                ORDER BY next_billing_date
            """)
            result = await session.execute(query, {"user_id": str(user_id)})
            return [dict(row) for row in result.mappings()]

    async def cancel(self, subscription_id: UUID, reason: str) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                UPDATE subscriptions SET status = 'cancelled', cancelled_at = NOW(),
                cancellation_reason = :reason, updated_at = NOW()
                WHERE id = :id RETURNING id, name, status
            """)
            result = await session.execute(query, {"id": str(subscription_id), "reason": reason})
            row = result.mappings().fetchone()
            if not row:
                raise ValidationError("Subscription not found")
            logger.info(f"Cancelled subscription: {subscription_id}")
            return dict(row)

    async def get_summary(self, user_id: UUID) -> Dict[str, Any]:
        subscriptions = await self.list(user_id)
        total_monthly = Decimal("0")
        total_annual = Decimal("0")
        for sub in subscriptions:
            amount = Decimal(str(sub["amount"]))
            freq = sub.get("frequency", "monthly")
            multiplier = self.FREQUENCY_MULTIPLIERS.get(freq, 12)
            annual = amount * multiplier
            monthly = annual / 12
            total_monthly += monthly
            total_annual += annual

        upcoming = [s for s in subscriptions if s["next_billing_date"] and s["next_billing_date"] <= (date.today() + timedelta(days=7))]

        return {
            "total_active": len(subscriptions),
            "total_monthly_cost": float(total_monthly.quantize(Decimal("0.01"))),
            "total_annual_cost": float(total_annual.quantize(Decimal("0.01"))),
            "upcoming_bills_count": len(upcoming),
            "upcoming_bills": upcoming[:5],
            "subscriptions": subscriptions,
        }

    async def update_next_billing(self, subscription_id: UUID) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                UPDATE subscriptions SET next_billing_date =
                CASE frequency
                    WHEN 'daily' THEN next_billing_date + INTERVAL '1 day'
                    WHEN 'weekly' THEN next_billing_date + INTERVAL '1 week'
                    WHEN 'biweekly' THEN next_billing_date + INTERVAL '2 weeks'
                    WHEN 'monthly' THEN next_billing_date + INTERVAL '1 month'
                    WHEN 'quarterly' THEN next_billing_date + INTERVAL '3 months'
                    WHEN 'semiannually' THEN next_billing_date + INTERVAL '6 months'
                    WHEN 'annually' THEN next_billing_date + INTERVAL '1 year'
                    ELSE next_billing_date + INTERVAL '1 month'
                END,
                updated_at = NOW()
                WHERE id = :id RETURNING id, next_billing_date
            """)
            result = await session.execute(query, {"id": str(subscription_id)})
            row = result.mappings().fetchone()
            return dict(row) if row else {}
