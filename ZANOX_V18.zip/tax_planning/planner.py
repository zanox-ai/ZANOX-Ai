"""
ZANOX V18 Tax Planner
Generates tax optimization strategies.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.database import get_db_context
from shared.logger import get_logger

logger = get_logger("tax_planner")


class TaxPlanner:
    async def get_plan(self, user_id: UUID, year: int) -> Dict[str, Any]:
        deductions = await self.get_deductions(user_id, year)
        total_potential = sum(Decimal(str(d.get("potential_savings", 0))) for d in deductions)
        return {
            "year": year,
            "user_id": str(user_id),
            "strategies": [
                {"name": "maximize_retirement_contributions", "description": "Contribute max to 401(k) and IRA", "priority": "high"},
                {"name": "harvest_tax_losses", "description": "Sell losing investments to offset gains", "priority": "medium"},
                {"name": "bunch_deductions", "description": "Combine deductions into single year to exceed standard deduction", "priority": "medium"},
                {"name": "charitable_giving", "description": "Donate appreciated assets instead of cash", "priority": "low"},
            ],
            "deductions": deductions,
            "total_potential_savings": float(total_potential.quantize(Decimal("0.01"))),
        }

    async def get_deductions(self, user_id: UUID, year: int) -> List[Dict[str, Any]]:
        start = date(year, 1, 1)
        end = date(year, 12, 31)
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT category, COALESCE(SUM(amount), 0) as total
                FROM expense_records
                WHERE user_id = :user_id AND category IN ('business', 'healthcare', 'education', 'charity', 'home_office')
                AND transaction_date BETWEEN :start AND :end
                GROUP BY category
            """)
            result = await session.execute(query, {"user_id": str(user_id), "start": start, "end": end})
            deductions = []
            for row in result.mappings():
                cat = row["category"]
                total = Decimal(str(row["total"]))
                rate = Decimal("0.25")
                savings = total * rate
                deductions.append({
                    "category": cat,
                    "amount": float(total),
                    "potential_savings": float(savings.quantize(Decimal("0.01"))),
                    "rate": float(rate * 100),
                })
            return deductions
