"""
ZANOX V18 Tax Planning Engine Core
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("tax_planning_engine")


class TaxPlanningEngine:
    def __init__(self):
        self._planner = None

    async def initialize(self):
        from .planner import TaxPlanner
        self._planner = TaxPlanner()
        logger.info("TaxPlanningEngine initialized")

    async def get_optimization_plan(self, user_id: UUID, year: int) -> Dict[str, Any]:
        if not self._planner:
            raise RuntimeError("Engine not initialized")
        return await self._planner.get_plan(user_id, year)

    async def get_deduction_recommendations(self, user_id: UUID, year: int) -> List[Dict[str, Any]]:
        if not self._planner:
            raise RuntimeError("Engine not initialized")
        return await self._planner.get_deductions(user_id, year)

    async def shutdown(self):
        logger.info("TaxPlanningEngine shut down")
