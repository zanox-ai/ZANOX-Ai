"""
ZANOX V18 Tax Planning API
"""
from fastapi import APIRouter
from uuid import UUID

from .engine import TaxPlanningEngine

router = APIRouter(prefix="/tax-planning", tags=["tax-planning"])
engine = TaxPlanningEngine()


@router.get("/plan/{user_id}/{year}")
async def get_optimization_plan(user_id: UUID, year: int):
    return await engine.get_optimization_plan(user_id, year)


@router.get("/deductions/{user_id}/{year}")
async def get_deductions(user_id: UUID, year: int):
    return await engine.get_deduction_recommendations(user_id, year)
