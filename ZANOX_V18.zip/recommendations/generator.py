"""
ZANOX V18 Recommendation Generator
Creates personalized financial advice based on user data.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.database import get_db_context
from shared.utils import safe_divide
from shared.logger import get_logger

logger = get_logger("recommendation_generator")


class RecommendationGenerator:
    async def generate(self, user_id: UUID) -> List[Dict[str, Any]]:
        recommendations = []
        recommendations.extend(await self.budget_recommendations(user_id))
        recommendations.extend(await self.investment_recommendations(user_id))
        recommendations.extend(await self.savings_recommendations(user_id))
        recommendations.extend(await self.debt_recommendations(user_id))
        return sorted(recommendations, key=lambda x: {"critical": 0, "high": 1, "medium": 2, "low": 3}.get(x.get("priority", "low"), 4))

    async def budget_recommendations(self, user_id: UUID) -> List[Dict[str, Any]]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT category, COALESCE(SUM(amount), 0) as total
                FROM expense_records
                WHERE user_id = :user_id AND transaction_date >= CURRENT_DATE - INTERVAL '1 month'
                GROUP BY category
            """)
            result = await session.execute(query, {"user_id": str(user_id)})
            expenses = {row["category"]: Decimal(str(row["total"])) for row in result.mappings()}

        total = sum(expenses.values())
        recommendations = []
        benchmarks = {"housing": 30, "food": 15, "transportation": 10, "entertainment": 5, "savings": 20}
        for cat, benchmark in benchmarks.items():
            actual = safe_divide(expenses.get(cat, Decimal("0")) * 100, total, Decimal("0"))
            if actual > benchmark + 5:
                recommendations.append({
                    "category": "budget",
                    "priority": "medium" if actual > benchmark + 10 else "low",
                    "message": f"{cat} spending is {float(actual):.1f}% of budget (recommended: {benchmark}%)",
                    "action": f"Reduce {cat} spending by ${float((actual - benchmark) / 100 * total):.2f} monthly",
                    "potential_savings": float((actual - benchmark) / 100 * total),
                })
        return recommendations

    async def investment_recommendations(self, user_id: UUID) -> List[Dict[str, Any]]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT COALESCE(SUM(total_amount), 0) as total FROM investment_trades
                WHERE user_id = :user_id AND status = 'completed'
            """)
            result = await session.execute(query, {"user_id": str(user_id)})
            invested = Decimal(str(result.fetchone()[0]))

            income_query = text("""
                SELECT COALESCE(SUM(amount), 0) as total FROM transactions
                WHERE user_id = :user_id AND type = 'income' AND transaction_date >= CURRENT_DATE - INTERVAL '1 year'
            """)
            income_result = await session.execute(income_query, {"user_id": str(user_id)})
            annual_income = Decimal(str(income_result.fetchone()[0]))

        investment_rate = safe_divide(invested * 100, annual_income, Decimal("0"))
        recommendations = []
        if investment_rate < 10:
            recommendations.append({
                "category": "investment",
                "priority": "high",
                "message": f"Investment rate is {float(investment_rate):.1f}% of income (recommended: 15-20%)",
                "action": "Increase automatic investment contributions",
                "target": float(annual_income * Decimal("0.15")),
            })
        return recommendations

    async def savings_recommendations(self, user_id: UUID) -> List[Dict[str, Any]]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT COALESCE(SUM(balance), 0) as total FROM accounts
                WHERE user_id = :user_id AND account_type = 'asset' AND category = 'current_asset'
            """)
            result = await session.execute(query, {"user_id": str(user_id)})
            cash = Decimal(str(result.fetchone()[0]))

            expense_query = text("""
                SELECT COALESCE(SUM(amount), 0) as total FROM expense_records
                WHERE user_id = :user_id AND transaction_date >= CURRENT_DATE - INTERVAL '1 month'
            """)
            expense_result = await session.execute(expense_query, {"user_id": str(user_id)})
            monthly_expenses = Decimal(str(expense_result.fetchone()[0]))

        months = safe_divide(cash, monthly_expenses, Decimal("0"))
        recommendations = []
        if months < 3:
            recommendations.append({
                "category": "savings",
                "priority": "critical" if months < 1 else "high",
                "message": f"Emergency fund covers {float(months):.1f} months (recommended: 6+)",
                "action": "Build emergency fund before other investments",
                "target": float(monthly_expenses * 6),
            })
        return recommendations

    async def debt_recommendations(self, user_id: UUID) -> List[Dict[str, Any]]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT COALESCE(SUM(balance), 0) as total FROM accounts
                WHERE user_id = :user_id AND account_type = 'liability'
            """)
            result = await session.execute(query, {"user_id": str(user_id)})
            debt = Decimal(str(result.fetchone()[0]))

        recommendations = []
        if debt > 0:
            recommendations.append({
                "category": "debt",
                "priority": "high",
                "message": f"Total debt: ${float(debt):.2f}",
                "action": "Prioritize high-interest debt payoff using avalanche method",
                "strategy": "avalanche",
            })
        return recommendations
