"""
ZANOX V18 Recommendations API
"""
from fastapi import APIRouter
from uuid import UUID

from .engine import RecommendationEngine

router = APIRouter(prefix="/recommendations", tags=["recommendations"])
engine = RecommendationEngine()


@router.get("/{user_id}")
async def get_all(user_id: UUID):
    return await engine.get_recommendations(user_id)


@router.get("/budget/{user_id}")
async def get_budget(user_id: UUID):
    return await engine.get_budget_recommendations(user_id)


@router.get("/investment/{user_id}")
async def get_investment(user_id: UUID):
    return await engine.get_investment_recommendations(user_id)


@router.get("/savings/{user_id}")
async def get_savings(user_id: UUID):
    return await engine.get_savings_recommendations(user_id)
