"""
ZANOX V18 Recommendations Engine Core
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("recommendations_engine")


class RecommendationEngine:
    def __init__(self):
        self._generator = None

    async def initialize(self):
        from .generator import RecommendationGenerator
        self._generator = RecommendationGenerator()
        logger.info("RecommendationEngine initialized")

    async def get_recommendations(self, user_id: UUID) -> List[Dict[str, Any]]:
        if not self._generator:
            raise RuntimeError("Engine not initialized")
        return await self._generator.generate(user_id)

    async def get_budget_recommendations(self, user_id: UUID) -> List[Dict[str, Any]]:
        if not self._generator:
            raise RuntimeError("Engine not initialized")
        return await self._generator.budget_recommendations(user_id)

    async def get_investment_recommendations(self, user_id: UUID) -> List[Dict[str, Any]]:
        if not self._generator:
            raise RuntimeError("Engine not initialized")
        return await self._generator.investment_recommendations(user_id)

    async def get_savings_recommendations(self, user_id: UUID) -> List[Dict[str, Any]]:
        if not self._generator:
            raise RuntimeError("Engine not initialized")
        return await self._generator.savings_recommendations(user_id)

    async def shutdown(self):
        logger.info("RecommendationEngine shut down")
