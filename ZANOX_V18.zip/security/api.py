"""
ZANOX V18 Security API
"""
from fastapi import APIRouter
from uuid import UUID

from .engine import SecurityEngine

router = APIRouter(prefix="/security", tags=["security"])
engine = SecurityEngine()


@router.get("/access/{user_id}")
async def check_access(user_id: UUID, resource: str, action: str):
    return await engine.check_access(user_id, resource, action)


@router.post("/encrypt")
async def encrypt(data: dict):
    return {"encrypted": await engine.encrypt_sensitive(data.get("plaintext", ""))}


@router.post("/decrypt")
async def decrypt(data: dict):
    return {"decrypted": await engine.decrypt_sensitive(data.get("ciphertext", ""))}


@router.get("/logs/{user_id}")
async def get_logs(user_id: UUID):
    return await engine.get_security_log(user_id)
