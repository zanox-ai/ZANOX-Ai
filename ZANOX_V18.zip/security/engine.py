"""
ZANOX V18 Security Engine Core
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import datetime
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("security_engine")


class SecurityEngine:
    def __init__(self):
        self._guard = None

    async def initialize(self):
        from .guard import SecurityGuard
        self._guard = SecurityGuard()
        logger.info("SecurityEngine initialized")

    async def check_access(self, user_id: UUID, resource: str, action: str) -> Dict[str, Any]:
        if not self._guard:
            raise RuntimeError("Engine not initialized")
        return await self._guard.check_access(user_id, resource, action)

    async def encrypt_sensitive(self, data: str) -> str:
        if not self._guard:
            raise RuntimeError("Engine not initialized")
        return await self._guard.encrypt(data)

    async def decrypt_sensitive(self, data: str) -> str:
        if not self._guard:
            raise RuntimeError("Engine not initialized")
        return await self._guard.decrypt(data)

    async def get_security_log(self, user_id: UUID) -> List[Dict[str, Any]]:
        if not self._guard:
            raise RuntimeError("Engine not initialized")
        return await self._guard.get_logs(user_id)

    async def shutdown(self):
        logger.info("SecurityEngine shut down")
