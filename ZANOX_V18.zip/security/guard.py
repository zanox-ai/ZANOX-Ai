"""
ZANOX V18 Security Guard
Access control and encryption for financial data.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import datetime
from uuid import UUID

from shared.encryption import encrypt_data, decrypt_data
from shared.database import get_db_context
from shared.logger import get_logger

logger = get_logger("security_guard")


class SecurityGuard:
    async def check_access(self, user_id: UUID, resource: str, action: str) -> Dict[str, Any]:
        allowed = True
        if resource in ["tax_records", "bank_accounts"] and action == "delete":
            allowed = False
        return {"user_id": str(user_id), "resource": resource, "action": action, "allowed": allowed, "checked_at": datetime.utcnow().isoformat()}

    async def encrypt(self, data: str) -> str:
        return encrypt_data(data)

    async def decrypt(self, data: str) -> str:
        return decrypt_data(data)

    async def get_logs(self, user_id: UUID) -> List[Dict[str, Any]]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("SELECT * FROM security_logs WHERE user_id = :user_id ORDER BY created_at DESC")
            result = await session.execute(query, {"user_id": str(user_id)})
            return [dict(row) for row in result.mappings()]
