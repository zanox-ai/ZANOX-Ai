"""
ZANOX V18 Risk Analysis API
"""
from fastapi import APIRouter
from uuid import UUID

from .engine import RiskEngine

router = APIRouter(prefix="/risk", tags=["risk"])
engine = RiskEngine()


@router.get("/portfolio/{user_id}")
async def assess_portfolio(user_id: UUID):
    return await engine.assess_portfolio_risk(user_id)


@router.get("/credit/{user_id}")
async def assess_credit(user_id: UUID):
    return await engine.assess_credit_risk(user_id)


@router.get("/liquidity/{user_id}")
async def assess_liquidity(user_id: UUID):
    return await engine.assess_liquidity_risk(user_id)


@router.get("/report/{user_id}")
async def get_full_report(user_id: UUID):
    return await engine.get_risk_report(user_id)
