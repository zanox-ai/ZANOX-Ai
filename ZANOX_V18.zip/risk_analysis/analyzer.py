"""
ZANOX V18 Risk Analyzer
Comprehensive risk assessment across financial dimensions.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date, timedelta
from uuid import UUID

from shared.database import get_db_context
from shared.utils import safe_divide
from shared.logger import get_logger

logger = get_logger("risk_analyzer")


class RiskAnalyzer:
    async def assess_portfolio(self, user_id: UUID) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT symbol, SUM(CASE WHEN action = 'buy' THEN quantity ELSE -quantity END) as net_qty
                FROM investment_trades
                WHERE user_id = :user_id AND status = 'completed'
                GROUP BY symbol
                HAVING SUM(CASE WHEN action = 'buy' THEN quantity ELSE -quantity END) > 0
            """)
            result = await session.execute(query, {"user_id": str(user_id)})
            holdings = [dict(row) for row in result.mappings()]

        concentration_risk = Decimal("0")
        if holdings:
            total_qty = sum(Decimal(str(h["net_qty"])) for h in holdings)
            max_pct = max(Decimal(str(h["net_qty"])) / total_qty * 100 for h in holdings) if total_qty > 0 else 0
            concentration_risk = max_pct

        risk_level = "low" if concentration_risk < 30 else "medium" if concentration_risk < 50 else "high"
        return {
            "user_id": str(user_id),
            "concentration_risk": float(concentration_risk.quantize(Decimal("0.01"))),
            "holdings_count": len(holdings),
            "risk_level": risk_level,
            "recommendation": "Diversify holdings" if concentration_risk > 40 else "Portfolio is well diversified",
        }

    async def assess_credit(self, user_id: UUID) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            debt_query = text("SELECT COALESCE(SUM(balance), 0) as total FROM accounts WHERE user_id = :user_id AND account_type = 'liability'")
            income_query = text("SELECT COALESCE(SUM(amount), 0) as total FROM transactions WHERE user_id = :user_id AND type = 'income' AND transaction_date >= CURRENT_DATE - INTERVAL '1 year'")
            debt = Decimal(str((await session.execute(debt_query, {"user_id": str(user_id)})).fetchone()[0]))
            income = Decimal(str((await session.execute(income_query, {"user_id": str(user_id)})).fetchone()[0]))

        dti = safe_divide(debt, income, Decimal("0")) * 100
        risk_level = "low" if dti < 20 else "medium" if dti < 36 else "high" if dti < 50 else "critical"
        return {
            "user_id": str(user_id),
            "total_debt": float(debt),
            "annual_income": float(income),
            "debt_to_income": float(dti.quantize(Decimal("0.01"))),
            "risk_level": risk_level,
            "recommendation": "Reduce debt" if dti > 36 else "Debt levels are manageable",
        }

    async def assess_liquidity(self, user_id: UUID) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            cash_query = text("SELECT COALESCE(SUM(balance), 0) as total FROM accounts WHERE user_id = :user_id AND category = 'current_asset'")
            monthly_expenses = text("SELECT COALESCE(SUM(amount), 0) as total FROM expense_records WHERE user_id = :user_id AND transaction_date >= CURRENT_DATE - INTERVAL '1 month'")
            cash = Decimal(str((await session.execute(cash_query, {"user_id": str(user_id)})).fetchone()[0]))
            expenses = Decimal(str((await session.execute(monthly_expenses, {"user_id": str(user_id)})).fetchone()[0]))

        months = safe_divide(cash, expenses, Decimal("0"))
        risk_level = "low" if months >= 6 else "medium" if months >= 3 else "high"
        return {
            "user_id": str(user_id),
            "cash_reserves": float(cash),
            "monthly_expenses": float(expenses),
            "months_of_coverage": float(months.quantize(Decimal("0.01"))),
            "risk_level": risk_level,
            "recommendation": "Build emergency fund to 6+ months" if months < 6 else "Liquidity is adequate",
        }

    async def full_report(self, user_id: UUID) -> Dict[str, Any]:
        portfolio = await self.assess_portfolio(user_id)
        credit = await self.assess_credit(user_id)
        liquidity = await self.assess_liquidity(user_id)
        overall_risk = max([portfolio["risk_level"], credit["risk_level"], liquidity["risk_level"]],
                          key=lambda x: {"low": 1, "medium": 2, "high": 3, "critical": 4}.get(x, 0))
        return {
            "user_id": str(user_id),
            "assessment_date": date.today().isoformat(),
            "portfolio_risk": portfolio,
            "credit_risk": credit,
            "liquidity_risk": liquidity,
            "overall_risk_level": overall_risk,
            "recommendations": [
                portfolio.get("recommendation", ""),
                credit.get("recommendation", ""),
                liquidity.get("recommendation", ""),
            ],
        }
