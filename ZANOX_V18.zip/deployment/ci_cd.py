"""
ZANOX V18 CI/CD Configuration
GitHub Actions and deployment pipelines.
"""
from typing import Dict, Any


class CICDConfig:
    GITHUB_ACTIONS = """
name: ZANOX V18 CI/CD
on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    - name: Set up Python
      uses: actions/setup-python@v4
      with:
        python-version: '3.11'
    - name: Install dependencies
      run: |
        pip install -r requirements.txt
        pip install pytest pytest-asyncio
    - name: Run tests
      run: pytest tests/ -v
    - name: Run linting
      run: |
        pip install flake8 black
        flake8 . --max-line-length=120
        black --check .

  deploy:
    needs: test
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    steps:
    - uses: actions/checkout@v3
    - name: Build Docker image
      run: docker build -t zanox/finance-v18:${{ github.sha }} .
    - name: Push to registry
      run: |
        echo ${{ secrets.DOCKER_PASSWORD }} | docker login -u ${{ secrets.DOCKER_USERNAME }} --password-stdin
        docker push zanox/finance-v18:${{ github.sha }}
    - name: Deploy to Kubernetes
      run: |
        kubectl set image deployment/zanox-finance-v18 api=zanox/finance-v18:${{ github.sha }}
        kubectl rollout status deployment/zanox-finance-v18
"""

    def get_github_actions(self) -> str:
        return self.GITHUB_ACTIONS
