"""
ZANOX V18 Kubernetes Configuration
K8s manifests for deployment.
"""
from typing import Dict, Any


class KubernetesConfig:
    DEPLOYMENT = """
apiVersion: apps/v1
kind: Deployment
metadata:
  name: zanox-finance-v18
spec:
  replicas: 3
  selector:
    matchLabels:
      app: zanox-finance
  template:
    metadata:
      labels:
        app: zanox-finance
    spec:
      containers:
      - name: api
        image: zanox/finance-v18:latest
        ports:
        - containerPort: 8000
        env:
        - name: ZANOX_DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: zanox-secrets
              key: database-url
        - name: ZANOX_REDIS_URL
          value: redis://redis-service:6379/0
        resources:
          requests:
            memory: "256Mi"
            cpu: "250m"
          limits:
            memory: "512Mi"
            cpu: "500m"
"""

    SERVICE = """
apiVersion: v1
kind: Service
metadata:
  name: zanox-finance-service
spec:
  selector:
    app: zanox-finance
  ports:
  - port: 80
    targetPort: 8000
  type: ClusterIP
"""

    INGRESS = """
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: zanox-finance-ingress
  annotations:
    nginx.ingress.kubernetes.io/rewrite-target: /
spec:
  rules:
  - host: finance.zanox.io
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: zanox-finance-service
            port:
              number: 80
"""

    def get_deployment(self) -> str:
        return self.DEPLOYMENT

    def get_service(self) -> str:
        return self.SERVICE

    def get_ingress(self) -> str:
        return self.INGRESS
