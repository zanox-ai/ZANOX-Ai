"""
ZANOX V18 Docker Configuration
Docker and Docker Compose setup.
"""
from typing import Dict, Any


class DockerConfig:
    DOCKERFILE = """
FROM python:3.11-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .
EXPOSE 8000
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
"""

    COMPOSE = """
version: '3.8'
services:
  api:
    build: .
    ports:
      - "8000:8000"
    environment:
      - ZANOX_DATABASE_URL=postgresql+asyncpg://zanox:zanox@db:5432/zanox_finance
      - ZANOX_REDIS_URL=redis://redis:6379/0
      - ZANOX_KAFKA_BOOTSTRAP=kafka:9092
    depends_on:
      - db
      - redis
      - kafka
  db:
    image: postgres:15
    environment:
      - POSTGRES_USER=zanox
      - POSTGRES_PASSWORD=zanox
      - POSTGRES_DB=zanox_finance
    volumes:
      - postgres_data:/var/lib/postgresql/data
  redis:
    image: redis:7-alpine
  kafka:
    image: confluentinc/cp-kafka:latest
    environment:
      KAFKA_ZOOKEEPER_CONNECT: zookeeper:2181
      KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://kafka:9092
  zookeeper:
    image: confluentinc/cp-zookeeper:latest
    environment:
      ZOOKEEPER_CLIENT_PORT: 2181
volumes:
  postgres_data:
"""

    def get_dockerfile(self) -> str:
        return self.DOCKERFILE

    def get_compose(self) -> str:
        return self.COMPOSE
