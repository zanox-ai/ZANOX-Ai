"""
ZANOX V18 Invoice Generator
Creates and manages invoice lifecycle.
"""
from typing import Dict, Any, List, Optional
from decimal import Decimal
from datetime import date, timedelta
from uuid import UUID

from shared.database import get_db_context
from shared.exceptions import ValidationError
from shared.utils import generate_reference
from shared.kafka_client import produce_event
from shared.logger import get_logger

logger = get_logger("invoice_generator")


class InvoiceGenerator:
    async def create(self, data: Dict[str, Any]) -> Dict[str, Any]:
        required = ["user_id", "customer_id", "items"]
        for field in required:
            if field not in data:
                raise ValidationError(f"Missing required field: {field}")

        items = data["items"]
        subtotal = sum(Decimal(str(item.get("quantity", 1))) * Decimal(str(item.get("unit_price", 0))) for item in items)
        tax_rate = Decimal(str(data.get("tax_rate", 0)))
        tax_amount = subtotal * tax_rate / 100
        discount = Decimal(str(data.get("discount", 0)))
        total = subtotal + tax_amount - discount

        invoice_number = generate_reference("INV")
        due_date = data.get("due_date", date.today() + timedelta(days=30))

        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                INSERT INTO invoices (
                    id, user_id, customer_id, invoice_number, issue_date, due_date,
                    subtotal, tax_amount, discount, total, currency, status, notes,
                    terms, metadata, created_at, updated_at
                ) VALUES (
                    gen_random_uuid(), :user_id, :customer_id, :invoice_number, :issue_date, :due_date,
                    :subtotal, :tax_amount, :discount, :total, :currency, 'draft', :notes,
                    :terms, :metadata, NOW(), NOW()
                ) RETURNING id
            """)
            result = await session.execute(query, {
                "user_id": data["user_id"],
                "customer_id": data["customer_id"],
                "invoice_number": invoice_number,
                "issue_date": data.get("issue_date", date.today()),
                "due_date": due_date,
                "subtotal": str(subtotal),
                "tax_amount": str(tax_amount),
                "discount": str(discount),
                "total": str(total),
                "currency": data.get("currency", "USD"),
                "notes": data.get("notes", ""),
                "terms": data.get("terms", "Net 30"),
                "metadata": str(data.get("metadata", {})),
            })
            invoice_id = str(result.fetchone()[0])

            line_query = text("""
                INSERT INTO invoice_lines (
                    id, invoice_id, description, quantity, unit_price, amount, created_at
                ) VALUES (gen_random_uuid(), :invoice_id, :description, :quantity, :unit_price, :amount, NOW())
            """)
            for item in items:
                line_amount = Decimal(str(item.get("quantity", 1))) * Decimal(str(item.get("unit_price", 0)))
                await session.execute(line_query, {
                    "invoice_id": invoice_id,
                    "description": item.get("description", ""),
                    "quantity": item.get("quantity", 1),
                    "unit_price": str(item.get("unit_price", 0)),
                    "amount": str(line_amount),
                })

            produce_event("zanox.finance.invoices", {
                "event": "invoice_created", "invoice_id": invoice_id, "number": invoice_number, "total": float(total)
            })
            logger.info(f"Created invoice: {invoice_number} - ${float(total):.2f}")
            return {"invoice_id": invoice_id, "invoice_number": invoice_number, "total": float(total), "status": "draft"}

    async def get(self, invoice_id: UUID) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("SELECT * FROM invoices WHERE id = :id")
            result = await session.execute(query, {"id": str(invoice_id)})
            row = result.mappings().fetchone()
            if not row:
                raise ValidationError("Invoice not found")
            invoice = dict(row)
            line_query = text("SELECT * FROM invoice_lines WHERE invoice_id = :id")
            line_result = await session.execute(line_query, {"id": str(invoice_id)})
            invoice["lines"] = [dict(r) for r in line_result.mappings()]
            return invoice

    async def list(self, user_id: UUID, status: Optional[str] = None) -> List[Dict[str, Any]]:
        async with get_db_context() as session:
            from sqlalchemy import text
            if status:
                query = text("SELECT * FROM invoices WHERE user_id = :user_id AND status = :status ORDER BY created_at DESC")
                result = await session.execute(query, {"user_id": str(user_id), "status": status})
            else:
                query = text("SELECT * FROM invoices WHERE user_id = :user_id ORDER BY created_at DESC")
                result = await session.execute(query, {"user_id": str(user_id)})
            return [dict(row) for row in result.mappings()]

    async def mark_paid(self, invoice_id: UUID, payment_data: Dict[str, Any]) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                UPDATE invoices SET status = 'paid', paid_date = :paid_date, paid_amount = :paid_amount,
                payment_method = :payment_method, updated_at = NOW()
                WHERE id = :id RETURNING id, invoice_number, status, total
            """)
            result = await session.execute(query, {
                "id": str(invoice_id),
                "paid_date": payment_data.get("paid_date", date.today()),
                "paid_amount": str(payment_data.get("amount", 0)),
                "payment_method": payment_data.get("payment_method", ""),
            })
            row = result.mappings().fetchone()
            if not row:
                raise ValidationError("Invoice not found")
            produce_event("zanox.finance.invoices", {
                "event": "invoice_paid", "invoice_id": str(invoice_id), "amount": float(payment_data.get("amount", 0))
            })
            logger.info(f"Invoice {invoice_id} marked as paid")
            return dict(row)

    async def send_reminder(self, invoice_id: UUID) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                UPDATE invoices SET reminder_sent = true, last_reminder_date = NOW(), updated_at = NOW()
                WHERE id = :id AND status != 'paid' RETURNING id, invoice_number, customer_id, due_date, total
            """)
            result = await session.execute(query, {"id": str(invoice_id)})
            row = result.mappings().fetchone()
            if not row:
                raise ValidationError("Invoice not found or already paid")
            produce_event("zanox.finance.invoices", {
                "event": "invoice_reminder_sent", "invoice_id": str(invoice_id)
            })
            logger.info(f"Reminder sent for invoice {invoice_id}")
            return {"invoice_id": str(invoice_id), "reminder_sent": True, "due_date": row["due_date"].isoformat()}
