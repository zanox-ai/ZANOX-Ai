"""
ZANOX V18 Invoice API
FastAPI routes for invoice management.
"""
from fastapi import APIRouter, HTTPException, Depends
from typing import List, Optional
from uuid import UUID
from datetime import date

from .engine import InvoiceEngine
from shared.database import get_db_session
from shared.models import PaginatedResponse, PaginationParams

router = APIRouter(prefix="/invoices", tags=["invoices"])

engine = InvoiceEngine()


@router.post("/")
async def create_invoice(data: dict):
    return await engine.create_invoice(data)


@router.get("/{invoice_id}")
async def get_invoice(invoice_id: UUID):
    return await engine.get_invoice(invoice_id)


@router.get("/")
async def list_invoices(user_id: UUID, status: Optional[str] = None):
    return await engine.list_invoices(user_id, status)


@router.post("/{invoice_id}/pay")
async def mark_invoice_paid(invoice_id: UUID, payment: dict):
    return await engine.mark_paid(invoice_id, payment)


@router.post("/{invoice_id}/remind")
async def send_reminder(invoice_id: UUID):
    return await engine.send_reminder(invoice_id)
