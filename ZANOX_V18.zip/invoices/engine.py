"""
ZANOX V18 Invoice Engine Core
"""
from typing import Dict, Any, List, Optional
from decimal import Decimal
from datetime import date, timedelta
from uuid import UUID

from shared.logger import get_logger
from shared.exceptions import ValidationError

logger = get_logger("invoice_engine")


class InvoiceEngine:
    def __init__(self):
        self._generator = None

    async def initialize(self):
        from .generator import InvoiceGenerator
        self._generator = InvoiceGenerator()
        logger.info("InvoiceEngine initialized")

    async def create_invoice(self, data: Dict[str, Any]) -> Dict[str, Any]:
        if not self._generator:
            raise RuntimeError("Engine not initialized")
        return await self._generator.create(data)

    async def get_invoice(self, invoice_id: UUID) -> Dict[str, Any]:
        if not self._generator:
            raise RuntimeError("Engine not initialized")
        return await self._generator.get(invoice_id)

    async def list_invoices(self, user_id: UUID, status: Optional[str] = None) -> List[Dict[str, Any]]:
        if not self._generator:
            raise RuntimeError("Engine not initialized")
        return await self._generator.list(user_id, status)

    async def mark_paid(self, invoice_id: UUID, payment_data: Dict[str, Any]) -> Dict[str, Any]:
        if not self._generator:
            raise RuntimeError("Engine not initialized")
        return await self._generator.mark_paid(invoice_id, payment_data)

    async def send_reminder(self, invoice_id: UUID) -> Dict[str, Any]:
        if not self._generator:
            raise RuntimeError("Engine not initialized")
        return await self._generator.send_reminder(invoice_id)

    async def shutdown(self):
        logger.info("InvoiceEngine shut down")
