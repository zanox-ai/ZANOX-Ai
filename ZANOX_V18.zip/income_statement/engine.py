"""
ZANOX V18 Income Statement Engine Core
"""
from typing import Dict, Any
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("income_statement_engine")


class IncomeStatementEngine:
    def __init__(self):
        self._generator = None

    async def initialize(self):
        from .generator import IncomeStatementGenerator
        self._generator = IncomeStatementGenerator()
        logger.info("IncomeStatementEngine initialized")

    async def generate(self, user_id: UUID, start: date, end: date) -> Dict[str, Any]:
        if not self._generator:
            raise RuntimeError("Engine not initialized")
        return await self._generator.generate(user_id, start, end)

    async def shutdown(self):
        logger.info("IncomeStatementEngine shut down")
