"""
ZANOX V18 Income Statement Generator
Builds detailed income statements with multi-level breakdown.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.database import get_db_context
from shared.utils import safe_divide
from shared.logger import get_logger

logger = get_logger("income_statement_generator")


class IncomeStatementGenerator:
    async def generate(self, user_id: UUID, start: date, end: date) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            revenue_query = text("""
                SELECT source, category, COALESCE(SUM(amount), 0) as total
                FROM revenue_records
                WHERE user_id = :user_id AND transaction_date BETWEEN :start AND :end
                GROUP BY source, category
                ORDER BY total DESC
            """)
            revenue_result = await session.execute(revenue_query, {
                "user_id": str(user_id), "start": start, "end": end
            })
            revenue_items = [dict(row) for row in revenue_result.mappings()]
            total_revenue = sum(Decimal(str(r["total"])) for r in revenue_items)

            expense_query = text("""
                SELECT category, subcategory, COALESCE(SUM(amount), 0) as total
                FROM expense_records
                WHERE user_id = :user_id AND transaction_date BETWEEN :start AND :end
                GROUP BY category, subcategory
                ORDER BY total DESC
            """)
            expense_result = await session.execute(expense_query, {
                "user_id": str(user_id), "start": start, "end": end
            })
            expense_items = [dict(row) for row in expense_result.mappings()]
            total_expenses = sum(Decimal(str(e["total"])) for e in expense_items)

            other_income_query = text("""
                SELECT COALESCE(SUM(amount), 0) as total
                FROM transactions
                WHERE user_id = :user_id AND type = 'income' AND category IN ('interest', 'dividend')
                AND transaction_date BETWEEN :start AND :end AND status = 'completed'
            """)
            other_income_result = await session.execute(other_income_query, {
                "user_id": str(user_id), "start": start, "end": end
            })
            other_income = Decimal(str(other_income_result.fetchone()[0]))

            other_expense_query = text("""
                SELECT COALESCE(SUM(amount), 0) as total
                FROM transactions
                WHERE user_id = :user_id AND type = 'expense' AND category IN ('interest', 'fee')
                AND transaction_date BETWEEN :start AND :end AND status = 'completed'
            """)
            other_expense_result = await session.execute(other_expense_query, {
                "user_id": str(user_id), "start": start, "end": end
            })
            other_expense = Decimal(str(other_expense_result.fetchone()[0]))

            ebt = total_revenue - total_expenses + other_income - other_expense
            tax = ebt * Decimal("0.25") if ebt > 0 else Decimal("0")
            net_income = ebt - tax

            return {
                "period": {"start": start.isoformat(), "end": end.isoformat()},
                "revenue": {
                    "items": revenue_items,
                    "total": float(total_revenue),
                },
                "operating_expenses": {
                    "items": expense_items,
                    "total": float(total_expenses),
                },
                "other_income": float(other_income),
                "other_expenses": float(other_expense),
                "earnings_before_tax": float(ebt),
                "tax": float(tax),
                "net_income": float(net_income),
                "net_margin_pct": float(safe_divide(net_income, total_revenue, Decimal("0")) * 100),
                "ebitda_margin_pct": float(safe_divide(ebt + total_expenses * Decimal("0.3"), total_revenue, Decimal("0")) * 100),
            }
