"""
ZANOX V18 Budget Analytics Engine Core
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("budget_analytics_engine")


class BudgetAnalyticsEngine:
    def __init__(self):
        self._insights = None
        self._trends = None

    async def initialize(self):
        from .insights import BudgetInsights
        from .trends import BudgetTrends
        self._insights = BudgetInsights()
        self._trends = BudgetTrends()
        logger.info("BudgetAnalyticsEngine initialized")

    async def get_insights(self, user_id: UUID, budget_id: UUID) -> Dict[str, Any]:
        if not self._insights:
            raise RuntimeError("Engine not initialized")
        return await self._insights.generate(user_id, budget_id)

    async def get_trends(self, user_id: UUID, months: int = 6) -> List[Dict[str, Any]]:
        if not self._trends:
            raise RuntimeError("Engine not initialized")
        return await self._trends.analyze(user_id, months)

    async def shutdown(self):
        logger.info("BudgetAnalyticsEngine shut down")
