"""
ZANOX V18 Budget Trends
Analyzes spending trends over time.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date, timedelta
from uuid import UUID

from shared.database import get_db_context
from shared.utils import get_month_start, get_month_end, calculate_growth_rate
from shared.logger import get_logger

logger = get_logger("budget_trends")


class BudgetTrends:
    async def analyze(self, user_id: UUID, months: int = 6) -> List[Dict[str, Any]]:
        today = date.today()
        trends = []
        for i in range(months - 1, -1, -1):
            month_date = today - timedelta(days=i * 30)
            start = get_month_start(month_date)
            end = get_month_end(month_date)
            async with get_db_context() as session:
                from sqlalchemy import text
                query = text("""
                    SELECT category, COALESCE(SUM(amount), 0) as total
                    FROM expense_records
                    WHERE user_id = :user_id AND transaction_date BETWEEN :start AND :end
                    GROUP BY category
                    ORDER BY total DESC
                """)
                result = await session.execute(query, {
                    "user_id": str(user_id), "start": start, "end": end
                })
                categories = [dict(row) for row in result.mappings()]
            trends.append({
                "month": start.strftime("%Y-%m"),
                "total_spent": sum(float(c["total"]) for c in categories),
                "categories": categories,
                "category_count": len(categories),
            })

        if len(trends) >= 2:
            for i in range(1, len(trends)):
                prev = Decimal(str(trends[i-1]["total_spent"]))
                curr = Decimal(str(trends[i]["total_spent"]))
                trends[i]["month_over_month_change"] = float(calculate_growth_rate(curr, prev))
        return trends
