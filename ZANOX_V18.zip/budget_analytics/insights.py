"""
ZANOX V18 Budget Insights
Generates actionable insights from budget data.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.database import get_db_context
from shared.logger import get_logger

logger = get_logger("budget_insights")


class BudgetInsights:
    async def generate(self, user_id: UUID, budget_id: UUID) -> Dict[str, Any]:
        from budget_engine.enforcer import BudgetEnforcer
        enforcer = BudgetEnforcer()
        status = await enforcer.get_status(budget_id)

        insights = []
        if status.get("status") == "over_budget":
            insights.append({
                "type": "critical",
                "message": "Budget is over limit. Immediate action required.",
                "action": "Review largest spending categories and cut non-essential expenses.",
            })
        for cat in status.get("categories", []):
            if cat.get("exceeded"):
                insights.append({
                    "type": "warning",
                    "message": f"{cat['category']} exceeded by ${cat['spent'] - cat['limit_amount']:.2f}",
                    "action": f"Reduce {cat['category']} spending next month.",
                })
            elif cat.get("alert"):
                insights.append({
                    "type": "info",
                    "message": f"{cat['category']} is at {cat['pct_used']}% of budget.",
                    "action": f"Monitor {cat['category']} spending closely.",
                })

        return {
            "budget_id": str(budget_id),
            "insights": insights,
            "insight_count": len(insights),
            "health_score": max(0, 100 - sum(1 for i in insights if i["type"] == "critical") * 30
                                     - sum(1 for i in insights if i["type"] == "warning") * 10),
        }
