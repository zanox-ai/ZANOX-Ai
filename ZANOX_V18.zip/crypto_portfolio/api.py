"""
ZANOX V18 Crypto Portfolio API
"""
from fastapi import APIRouter
from uuid import UUID

from .engine import CryptoPortfolioEngine

router = APIRouter(prefix="/crypto", tags=["crypto"])
engine = CryptoPortfolioEngine()


@router.post("/")
async def add_crypto(data: dict):
    return await engine.add_crypto(data)


@router.get("/holdings/{user_id}")
async def get_holdings(user_id: UUID):
    return await engine.get_holdings(user_id)


@router.get("/summary/{user_id}")
async def get_summary(user_id: UUID):
    return await engine.get_crypto_summary(user_id)
