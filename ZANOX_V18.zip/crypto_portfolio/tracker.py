"""
ZANOX V18 Crypto Tracker
Tracks cryptocurrency holdings with exchange integration.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.database import get_db_context
from shared.exceptions import ValidationError
from shared.logger import get_logger

logger = get_logger("crypto_tracker")


class CryptoTracker:
    async def add(self, data: Dict[str, Any]) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                INSERT INTO crypto_holdings (
                    id, user_id, symbol, quantity, purchase_price, current_price,
                    currency, exchange, wallet_address, purchase_date, created_at, updated_at
                ) VALUES (
                    gen_random_uuid(), :user_id, :symbol, :quantity, :purchase_price, :current_price,
                    :currency, :exchange, :wallet_address, :purchase_date, NOW(), NOW()
                ) RETURNING id
            """)
            result = await session.execute(query, {
                "user_id": data["user_id"],
                "symbol": data["symbol"].upper(),
                "quantity": str(data["quantity"]),
                "purchase_price": str(data["purchase_price"]),
                "current_price": str(data.get("current_price", data["purchase_price"])),
                "currency": data.get("currency", "USD"),
                "exchange": data.get("exchange", ""),
                "wallet_address": data.get("wallet_address", ""),
                "purchase_date": data.get("purchase_date", date.today()),
            })
            holding_id = str(result.fetchone()[0])
            logger.info(f"Added crypto holding: {holding_id} - {data['symbol']}")
            return {"holding_id": holding_id, "symbol": data["symbol"], "quantity": data["quantity"]}

    async def get_holdings(self, user_id: UUID) -> List[Dict[str, Any]]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT * FROM crypto_holdings WHERE user_id = :user_id ORDER BY symbol
            """)
            result = await session.execute(query, {"user_id": str(user_id)})
            return [dict(row) for row in result.mappings()]

    async def get_summary(self, user_id: UUID) -> Dict[str, Any]:
        holdings = await self.get_holdings(user_id)
        total_cost = Decimal("0")
        total_value = Decimal("0")
        by_symbol = {}
        for h in holdings:
            cost = Decimal(str(h["quantity"])) * Decimal(str(h["purchase_price"]))
            value = Decimal(str(h["quantity"])) * Decimal(str(h["current_price"]))
            total_cost += cost
            total_value += value
            sym = h["symbol"]
            if sym not in by_symbol:
                by_symbol[sym] = {"quantity": Decimal("0"), "cost": Decimal("0"), "value": Decimal("0")}
            by_symbol[sym]["quantity"] += Decimal(str(h["quantity"]))
            by_symbol[sym]["cost"] += cost
            by_symbol[sym]["value"] += value

        summary = []
        for sym, data in by_symbol.items():
            gain = data["value"] - data["cost"]
            summary.append({
                "symbol": sym,
                "quantity": float(data["quantity"]),
                "cost_basis": float(data["cost"].quantize(Decimal("0.01"))),
                "current_value": float(data["value"].quantize(Decimal("0.01"))),
                "unrealized_gain": float(gain.quantize(Decimal("0.01"))),
                "roi_pct": float((gain / data["cost"] * 100).quantize(Decimal("0.01"))) if data["cost"] > 0 else 0,
            })

        return {
            "user_id": str(user_id),
            "holdings_count": len(holdings),
            "total_cost_basis": float(total_cost.quantize(Decimal("0.01"))),
            "total_current_value": float(total_value.quantize(Decimal("0.01"))),
            "total_unrealized_gain": float((total_value - total_cost).quantize(Decimal("0.01"))),
            "by_symbol": summary,
        }
