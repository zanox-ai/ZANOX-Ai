"""
ZANOX V18 Crypto Portfolio Engine Core
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("crypto_portfolio_engine")


class CryptoPortfolioEngine:
    def __init__(self):
        self._tracker = None

    async def initialize(self):
        from .tracker import CryptoTracker
        self._tracker = CryptoTracker()
        logger.info("CryptoPortfolioEngine initialized")

    async def add_crypto(self, data: Dict[str, Any]) -> Dict[str, Any]:
        if not self._tracker:
            raise RuntimeError("Engine not initialized")
        return await self._tracker.add(data)

    async def get_holdings(self, user_id: UUID) -> Dict[str, Any]:
        if not self._tracker:
            raise RuntimeError("Engine not initialized")
        return await self._tracker.get_holdings(user_id)

    async def get_crypto_summary(self, user_id: UUID) -> Dict[str, Any]:
        if not self._tracker:
            raise RuntimeError("Engine not initialized")
        return await self._tracker.get_summary(user_id)

    async def shutdown(self):
        logger.info("CryptoPortfolioEngine shut down")
