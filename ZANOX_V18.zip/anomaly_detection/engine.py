"""
ZANOX V18 Anomaly Detection Engine Core
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("anomaly_engine")


class AnomalyEngine:
    def __init__(self):
        self._detector = None

    async def initialize(self):
        from .detector import AnomalyDetector
        self._detector = AnomalyDetector()
        logger.info("AnomalyEngine initialized")

    async def detect_spending_anomalies(self, user_id: UUID) -> List[Dict[str, Any]]:
        if not self._detector:
            raise RuntimeError("Engine not initialized")
        return await self._detector.detect_spending(user_id)

    async def detect_income_anomalies(self, user_id: UUID) -> List[Dict[str, Any]]:
        if not self._detector:
            raise RuntimeError("Engine not initialized")
        return await self._detector.detect_income(user_id)

    async def detect_balance_anomalies(self, user_id: UUID) -> List[Dict[str, Any]]:
        if not self._detector:
            raise RuntimeError("Engine not initialized")
        return await self._detector.detect_balance(user_id)

    async def shutdown(self):
        logger.info("AnomalyEngine shut down")
