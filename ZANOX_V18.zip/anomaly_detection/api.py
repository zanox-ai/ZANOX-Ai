"""
ZANOX V18 Anomaly Detection API
"""
from fastapi import APIRouter
from uuid import UUID

from .engine import AnomalyEngine

router = APIRouter(prefix="/anomalies", tags=["anomalies"])
engine = AnomalyEngine()


@router.get("/spending/{user_id}")
async def detect_spending(user_id: UUID):
    return await engine.detect_spending_anomalies(user_id)


@router.get("/income/{user_id}")
async def detect_income(user_id: UUID):
    return await engine.detect_income_anomalies(user_id)


@router.get("/balance/{user_id}")
async def detect_balance(user_id: UUID):
    return await engine.detect_balance_anomalies(user_id)
