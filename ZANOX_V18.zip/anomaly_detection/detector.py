"""
ZANOX V18 Anomaly Detector
Statistical anomaly detection using Z-score and IQR methods.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date, timedelta
from uuid import UUID
import statistics

from shared.database import get_db_context
from shared.logger import get_logger

logger = get_logger("anomaly_detector")


class AnomalyDetector:
    async def detect_spending(self, user_id: UUID) -> List[Dict[str, Any]]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT category, amount, transaction_date, description, id
                FROM expense_records
                WHERE user_id = :user_id AND transaction_date >= CURRENT_DATE - INTERVAL '90 days'
                ORDER BY category, transaction_date
            """)
            result = await session.execute(query, {"user_id": str(user_id)})
            expenses = [dict(row) for row in result.mappings()]

        by_category = {}
        for e in expenses:
            cat = e["category"]
            if cat not in by_category:
                by_category[cat] = []
            by_category[cat].append(e)

        anomalies = []
        for cat, items in by_category.items():
            if len(items) < 3:
                continue
            amounts = [float(i["amount"]) for i in items]
            try:
                mean = statistics.mean(amounts)
                std = statistics.stdev(amounts)
            except statistics.StatisticsError:
                continue
            for item in items:
                z_score = (float(item["amount"]) - mean) / std if std > 0 else 0
                if abs(z_score) > 2.5:
                    anomalies.append({
                        "transaction_id": item["id"],
                        "category": cat,
                        "amount": float(item["amount"]),
                        "z_score": round(z_score, 2),
                        "expected_range": [round(mean - 2*std, 2), round(mean + 2*std, 2)],
                        "severity": "high" if abs(z_score) > 3 else "medium",
                    })
        return anomalies

    async def detect_income(self, user_id: UUID) -> List[Dict[str, Any]]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT source, amount, transaction_date, id
                FROM revenue_records
                WHERE user_id = :user_id AND transaction_date >= CURRENT_DATE - INTERVAL '90 days'
                ORDER BY source, transaction_date
            """)
            result = await session.execute(query, {"user_id": str(user_id)})
            income = [dict(row) for row in result.mappings()]

        by_source = {}
        for i in income:
            src = i["source"]
            if src not in by_source:
                by_source[src] = []
            by_source[src].append(i)

        anomalies = []
        for src, items in by_source.items():
            if len(items) < 3:
                continue
            amounts = [float(i["amount"]) for i in items]
            try:
                mean = statistics.mean(amounts)
                std = statistics.stdev(amounts)
            except statistics.StatisticsError:
                continue
            for item in items:
                z_score = (float(item["amount"]) - mean) / std if std > 0 else 0
                if abs(z_score) > 2.5:
                    anomalies.append({
                        "transaction_id": item["id"],
                        "source": src,
                        "amount": float(item["amount"]),
                        "z_score": round(z_score, 2),
                        "severity": "high" if abs(z_score) > 3 else "medium",
                    })
        return anomalies

    async def detect_balance(self, user_id: UUID) -> List[Dict[str, Any]]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT name, balance, category
                FROM accounts
                WHERE user_id = :user_id AND account_type = 'asset' AND is_active = true
            """)
            result = await session.execute(query, {"user_id": str(user_id)})
            accounts = [dict(row) for row in result.mappings()]

        balances = [float(a["balance"]) for a in accounts]
        if len(balances) < 2:
            return []
        try:
            mean = statistics.mean(balances)
            std = statistics.stdev(balances)
        except statistics.StatisticsError:
            return []

        anomalies = []
        for account in accounts:
            z_score = (float(account["balance"]) - mean) / std if std > 0 else 0
            if abs(z_score) > 2.5:
                anomalies.append({
                    "account_id": account.get("id"),
                    "account_name": account["name"],
                    "balance": float(account["balance"]),
                    "z_score": round(z_score, 2),
                    "severity": "high" if abs(z_score) > 3 else "medium",
                })
        return anomalies
