"""
ZANOX V18 Tax Reporter
Generates tax form data and reports.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.database import get_db_context
from shared.logger import get_logger

logger = get_logger("tax_reporter")


class TaxReporter:
    async def generate_1099(self, user_id: UUID, year: int) -> Dict[str, Any]:
        start = date(year, 1, 1)
        end = date(year, 12, 31)
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT source, COALESCE(SUM(amount), 0) as total
                FROM revenue_records
                WHERE user_id = :user_id AND category = 'freelance'
                AND transaction_date BETWEEN :start AND :end
                GROUP BY source
            """)
            result = await session.execute(query, {"user_id": str(user_id), "start": start, "end": end})
            sources = [dict(row) for row in result.mappings()]
            total = sum(Decimal(str(s["total"])) for s in sources)
            return {
                "form": "1099-NEC",
                "year": year,
                "nonemployee_compensation": float(total.quantize(Decimal("0.01"))),
                "sources": sources,
            }

    async def generate_schedule_c(self, user_id: UUID, year: int) -> Dict[str, Any]:
        start = date(year, 1, 1)
        end = date(year, 12, 31)
        async with get_db_context() as session:
            from sqlalchemy import text
            income_query = text("""
                SELECT COALESCE(SUM(amount), 0) as total FROM revenue_records
                WHERE user_id = :user_id AND category = 'business'
                AND transaction_date BETWEEN :start AND :end
            """)
            expense_query = text("""
                SELECT category, COALESCE(SUM(amount), 0) as total
                FROM expense_records
                WHERE user_id = :user_id AND category IN ('business', 'office', 'marketing', 'travel')
                AND transaction_date BETWEEN :start AND :end
                GROUP BY category
            """)
            income_result = await session.execute(income_query, {"user_id": str(user_id), "start": start, "end": end})
            expense_result = await session.execute(expense_query, {"user_id": str(user_id), "start": start, "end": end})
            gross_income = Decimal(str(income_result.fetchone()[0]))
            expenses = [dict(row) for row in expense_result.mappings()]
            total_expenses = sum(Decimal(str(e["total"])) for e in expenses)
            net_profit = gross_income - total_expenses
            return {
                "form": "Schedule C",
                "year": year,
                "gross_income": float(gross_income),
                "expenses": expenses,
                "total_expenses": float(total_expenses),
                "net_profit": float(net_profit),
            }

    async def generate_summary(self, user_id: UUID, year: int) -> Dict[str, Any]:
        from tax_engine.calculator import TaxCalculator
        calc = TaxCalculator()
        tax_summary = await calc.get_summary(user_id, year)
        return {
            "year": year,
            "tax_summary": tax_summary,
            "forms": ["1040", "Schedule C", "1099-NEC"],
            "filing_deadline": date(year + 1, 4, 15).isoformat(),
            "estimated_payment_dates": [
                date(year, 4, 15).isoformat(),
                date(year, 6, 15).isoformat(),
                date(year, 9, 15).isoformat(),
                date(year + 1, 1, 15).isoformat(),
            ],
        }
