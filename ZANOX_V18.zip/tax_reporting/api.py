"""
ZANOX V18 Tax Reporting API
"""
from fastapi import APIRouter
from uuid import UUID

from .engine import TaxReportingEngine

router = APIRouter(prefix="/tax-reporting", tags=["tax-reporting"])
engine = TaxReportingEngine()


@router.get("/1099/{user_id}/{year}")
async def generate_1099(user_id: UUID, year: int):
    return await engine.generate_1099(user_id, year)


@router.get("/schedule-c/{user_id}/{year}")
async def generate_schedule_c(user_id: UUID, year: int):
    return await engine.generate_schedule_c(user_id, year)


@router.get("/summary/{user_id}/{year}")
async def generate_summary(user_id: UUID, year: int):
    return await engine.generate_tax_summary_report(user_id, year)
