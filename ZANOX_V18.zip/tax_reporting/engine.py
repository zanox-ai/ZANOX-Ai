"""
ZANOX V18 Tax Reporting Engine Core
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("tax_reporting_engine")


class TaxReportingEngine:
    def __init__(self):
        self._reporter = None

    async def initialize(self):
        from .reporter import TaxReporter
        self._reporter = TaxReporter()
        logger.info("TaxReportingEngine initialized")

    async def generate_1099(self, user_id: UUID, year: int) -> Dict[str, Any]:
        if not self._reporter:
            raise RuntimeError("Engine not initialized")
        return await self._reporter.generate_1099(user_id, year)

    async def generate_schedule_c(self, user_id: UUID, year: int) -> Dict[str, Any]:
        if not self._reporter:
            raise RuntimeError("Engine not initialized")
        return await self._reporter.generate_schedule_c(user_id, year)

    async def generate_tax_summary_report(self, user_id: UUID, year: int) -> Dict[str, Any]:
        if not self._reporter:
            raise RuntimeError("Engine not initialized")
        return await self._reporter.generate_summary(user_id, year)

    async def shutdown(self):
        logger.info("TaxReportingEngine shut down")
