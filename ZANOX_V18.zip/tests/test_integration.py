"""
ZANOX V18 Integration Tests
End-to-end testing across modules.
"""
import pytest
from decimal import Decimal
from datetime import date
from uuid import uuid4

from financial_os.os_core import FinancialOS


@pytest.fixture
async def financial_os():
    os = FinancialOS()
    await os.initialize()
    return os


@pytest.mark.asyncio
async def test_os_initialization():
    os = FinancialOS()
    await os.initialize()
    assert os._initialized is True


@pytest.mark.asyncio
async def test_os_query_net_worth():
    os = FinancialOS()
    await os.initialize()
    result = await os.query("net_worth", {"user_id": uuid4()})
    assert "data" in result


@pytest.mark.asyncio
async def test_os_query_cash_flow():
    os = FinancialOS()
    await os.initialize()
    result = await os.query("cash_flow", {"user_id": uuid4(), "start_date": date.today(), "end_date": date.today()})
    assert "data" in result


@pytest.mark.asyncio
async def test_os_shutdown():
    os = FinancialOS()
    await os.initialize()
    await os.shutdown()
    assert os._initialized is False
