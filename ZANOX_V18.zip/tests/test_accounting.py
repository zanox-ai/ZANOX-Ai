"""
ZANOX V18 Accounting Tests
"""
import pytest
from decimal import Decimal
from datetime import date
from uuid import uuid4

from accounting.chart_of_accounts import ChartOfAccounts
from accounting.journal import JournalEntryManager


@pytest.fixture
async def chart():
    return ChartOfAccounts()


@pytest.fixture
async def journal():
    return JournalEntryManager()


@pytest.mark.asyncio
async def test_chart_default_accounts():
    chart = ChartOfAccounts()
    assert len(chart.DEFAULT_ACCOUNTS) == 18


@pytest.mark.asyncio
async def test_journal_validate_entries():
    journal = JournalEntryManager()
    with pytest.raises(Exception):
        await journal.create_entry({
            "user_id": str(uuid4()),
            "entries": [{"account_id": str(uuid4()), "debit": 100, "credit": 0}],
            "entry_date": date.today()
        })


@pytest.mark.asyncio
async def test_journal_balance_check():
    journal = JournalEntryManager()
    with pytest.raises(Exception):
        await journal.create_entry({
            "user_id": str(uuid4()),
            "entries": [
                {"account_id": str(uuid4()), "debit": 100, "credit": 0},
                {"account_id": str(uuid4()), "debit": 0, "credit": 50}
            ],
            "entry_date": date.today()
        })
