"""
ZANOX V18 Finance Engine Tests
"""
import pytest
from decimal import Decimal
from datetime import date
from uuid import uuid4

from finance_engine.engine import FinanceEngine
from finance_engine.calculator import FinancialCalculator
from finance_engine.processor import TransactionProcessor


@pytest.fixture
async def engine():
    e = FinanceEngine()
    await e.initialize()
    return e


@pytest.fixture
async def calculator():
    return FinancialCalculator()


@pytest.fixture
async def processor():
    return TransactionProcessor()


@pytest.mark.asyncio
async def test_calculator_loan_payment():
    calc = FinancialCalculator()
    payment = calc.calculate_loan_payment(Decimal("100000"), Decimal("5"), 30)
    assert payment > 0
    assert payment < Decimal("1000")


@pytest.mark.asyncio
async def test_calculator_roi():
    calc = FinancialCalculator()
    roi = calc.calculate_roi(Decimal("1200"), Decimal("1000"))
    assert roi == Decimal("20")


@pytest.mark.asyncio
async def test_calculator_npv():
    calc = FinancialCalculator()
    npv = calc.calculate_npv(Decimal("1000"), [Decimal("500"), Decimal("500"), Decimal("500")], Decimal("10"))
    assert npv > Decimal("0")


@pytest.mark.asyncio
async def test_processor_validate_transaction():
    proc = TransactionProcessor()
    with pytest.raises(Exception):
        proc._validate_transaction({"user_id": str(uuid4())})


@pytest.mark.asyncio
async def test_processor_validate_valid_transaction():
    proc = TransactionProcessor()
    proc._validate_transaction({"user_id": str(uuid4()), "amount": "100", "type": "income"})
