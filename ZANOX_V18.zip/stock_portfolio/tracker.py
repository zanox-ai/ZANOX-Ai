"""
ZANOX V18 Stock Tracker
Tracks stock holdings with market data integration.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.database import get_db_context
from shared.exceptions import ValidationError
from shared.logger import get_logger

logger = get_logger("stock_tracker")


class StockTracker:
    async def add(self, data: Dict[str, Any]) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                INSERT INTO stock_holdings (
                    id, user_id, symbol, company_name, quantity, purchase_price, current_price,
                    currency, exchange, purchase_date, sector, created_at, updated_at
                ) VALUES (
                    gen_random_uuid(), :user_id, :symbol, :company_name, :quantity, :purchase_price, :current_price,
                    :currency, :exchange, :purchase_date, :sector, NOW(), NOW()
                ) RETURNING id
            """)
            result = await session.execute(query, {
                "user_id": data["user_id"],
                "symbol": data["symbol"].upper(),
                "company_name": data.get("company_name", ""),
                "quantity": str(data["quantity"]),
                "purchase_price": str(data["purchase_price"]),
                "current_price": str(data.get("current_price", data["purchase_price"])),
                "currency": data.get("currency", "USD"),
                "exchange": data.get("exchange", "NYSE"),
                "purchase_date": data.get("purchase_date", date.today()),
                "sector": data.get("sector", ""),
            })
            holding_id = str(result.fetchone()[0])
            logger.info(f"Added stock holding: {holding_id} - {data['symbol']}")
            return {"holding_id": holding_id, "symbol": data["symbol"], "quantity": data["quantity"]}

    async def get_holdings(self, user_id: UUID) -> List[Dict[str, Any]]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("SELECT * FROM stock_holdings WHERE user_id = :user_id ORDER BY symbol")
            result = await session.execute(query, {"user_id": str(user_id)})
            return [dict(row) for row in result.mappings()]

    async def get_summary(self, user_id: UUID) -> Dict[str, Any]:
        holdings = await self.get_holdings(user_id)
        total_cost = Decimal("0")
        total_value = Decimal("0")
        by_sector = {}
        for h in holdings:
            cost = Decimal(str(h["quantity"])) * Decimal(str(h["purchase_price"]))
            value = Decimal(str(h["quantity"])) * Decimal(str(h["current_price"]))
            total_cost += cost
            total_value += value
            sector = h.get("sector", "unknown")
            if sector not in by_sector:
                by_sector[sector] = {"cost": Decimal("0"), "value": Decimal("0")}
            by_sector[sector]["cost"] += cost
            by_sector[sector]["value"] += value

        sector_summary = []
        for sector, data in by_sector.items():
            sector_summary.append({
                "sector": sector,
                "cost": float(data["cost"].quantize(Decimal("0.01"))),
                "value": float(data["value"].quantize(Decimal("0.01"))),
            })

        return {
            "user_id": str(user_id),
            "holdings_count": len(holdings),
            "total_cost_basis": float(total_cost.quantize(Decimal("0.01"))),
            "total_current_value": float(total_value.quantize(Decimal("0.01"))),
            "total_unrealized_gain": float((total_value - total_cost).quantize(Decimal("0.01"))),
            "by_sector": sector_summary,
        }

    async def get_dividends(self, user_id: UUID, year: int) -> List[Dict[str, Any]]:
        start = date(year, 1, 1)
        end = date(year, 12, 31)
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT symbol, COALESCE(SUM(amount), 0) as total, COUNT(*) as count
                FROM dividend_records
                WHERE user_id = :user_id AND payment_date BETWEEN :start AND :end
                GROUP BY symbol
                ORDER BY total DESC
            """)
            result = await session.execute(query, {"user_id": str(user_id), "start": start, "end": end})
            return [dict(row) for row in result.mappings()]
