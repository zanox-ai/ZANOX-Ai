"""
ZANOX V18 Stock Portfolio API
"""
from fastapi import APIRouter
from uuid import UUID

from .engine import StockPortfolioEngine

router = APIRouter(prefix="/stocks", tags=["stocks"])
engine = StockPortfolioEngine()


@router.post("/")
async def add_stock(data: dict):
    return await engine.add_stock(data)


@router.get("/holdings/{user_id}")
async def get_holdings(user_id: UUID):
    return await engine.get_holdings(user_id)


@router.get("/summary/{user_id}")
async def get_summary(user_id: UUID):
    return await engine.get_stock_summary(user_id)


@router.get("/dividends/{user_id}/{year}")
async def get_dividends(user_id: UUID, year: int):
    return await engine.get_dividends(user_id, year)
