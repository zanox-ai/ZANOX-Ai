"""
ZANOX V18 Stock Portfolio Engine Core
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("stock_portfolio_engine")


class StockPortfolioEngine:
    def __init__(self):
        self._tracker = None

    async def initialize(self):
        from .tracker import StockTracker
        self._tracker = StockTracker()
        logger.info("StockPortfolioEngine initialized")

    async def add_stock(self, data: Dict[str, Any]) -> Dict[str, Any]:
        if not self._tracker:
            raise RuntimeError("Engine not initialized")
        return await self._tracker.add(data)

    async def get_holdings(self, user_id: UUID) -> Dict[str, Any]:
        if not self._tracker:
            raise RuntimeError("Engine not initialized")
        return await self._tracker.get_holdings(user_id)

    async def get_stock_summary(self, user_id: UUID) -> Dict[str, Any]:
        if not self._tracker:
            raise RuntimeError("Engine not initialized")
        return await self._tracker.get_summary(user_id)

    async def get_dividends(self, user_id: UUID, year: int) -> List[Dict[str, Any]]:
        if not self._tracker:
            raise RuntimeError("Engine not initialized")
        return await self._tracker.get_dividends(user_id, year)

    async def shutdown(self):
        logger.info("StockPortfolioEngine shut down")
