"""
ZANOX V18 Financial Query Bus
Handles all financial queries with caching and optimization.
"""
from typing import Dict, Any, Callable, Awaitable, Optional
from shared.redis_client import cache_get, cache_set
from shared.logger import get_logger

logger = get_logger("query_bus")

QueryHandler = Callable[[Dict[str, Any]], Awaitable[Dict[str, Any]]]


class FinancialQueryBus:
    def __init__(self):
        self._handlers: Dict[str, QueryHandler] = {}
        self._cache_enabled = True

    def register(self, query: str, handler: QueryHandler) -> None:
        self._handlers[query] = handler
        logger.info(f"Registered handler for query: {query}")

    async def execute(self, query: str, params: Dict[str, Any], use_cache: bool = True) -> Dict[str, Any]:
        if query not in self._handlers:
            return {"success": False, "error": f"No handler for query: {query}"}
        cache_key = None
        if use_cache and self._cache_enabled:
            cache_key = f"query:{query}:{hash(str(sorted(params.items())))}"
            cached = await cache_get(cache_key)
            if cached:
                return {"success": True, "data": cached, "cached": True}
        try:
            result = await self._handlers[query](params)
            if cache_key:
                await cache_set(cache_key, result, ttl=300)
            return {"success": True, "data": result, "cached": False}
        except Exception as e:
            logger.error(f"Query '{query}' failed: {e}")
            return {"success": False, "error": str(e), "query": query}
