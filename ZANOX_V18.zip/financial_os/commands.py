"""
ZANOX V18 Financial Command Bus
Handles all financial commands with validation and routing.
"""
from typing import Dict, Any, Callable, Awaitable
from functools import wraps
from shared.exceptions import ValidationError, UnauthorizedAccessError
from shared.logger import get_logger

logger = get_logger("command_bus")

CommandHandler = Callable[[Dict[str, Any]], Awaitable[Dict[str, Any]]]


class FinancialCommandBus:
    def __init__(self):
        self._handlers: Dict[str, CommandHandler] = {}
        self._middleware: list = []

    def register(self, command: str, handler: CommandHandler) -> None:
        self._handlers[command] = handler
        logger.info(f"Registered handler for command: {command}")

    def add_middleware(self, middleware: Callable) -> None:
        self._middleware.append(middleware)

    async def execute(self, command: str, payload: Dict[str, Any], context: Dict[str, Any] = None) -> Dict[str, Any]:
        if command not in self._handlers:
            raise ValidationError(f"No handler registered for command: {command}")
        handler = self._handlers[command]
        for mw in self._middleware:
            payload = await mw(payload, context)
        try:
            result = await handler(payload)
            logger.info(f"Command '{command}' executed successfully")
            return {"success": True, "data": result}
        except Exception as e:
            logger.error(f"Command '{command}' failed: {e}")
            return {"success": False, "error": str(e), "command": command}

    def _auth_middleware(self, payload: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
        if context and not context.get("authenticated"):
            raise UnauthorizedAccessError("Authentication required")
        return payload
