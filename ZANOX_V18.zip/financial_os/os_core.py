"""
ZANOX V18 Financial Operating System Core
Manages the lifecycle of all financial operations and integrations.
"""
from typing import Dict, Any, Optional, List
from uuid import UUID
from datetime import date

from shared.models import Money, FinancialHealthScore
from shared.logger import get_logger
from shared.exceptions import ResourceNotFoundError

logger = get_logger("financial_os")


class FinancialOS:
    def __init__(self):
        self._engines = {}
        self._integrations = {}
        self._initialized = False

    async def initialize(self) -> None:
        from finance_engine.engine import FinanceEngine
        from accounting.engine import AccountingEngine
        from bookkeeping.engine import BookkeepingEngine
        from revenue_management.engine import RevenueEngine
        from expense_management.engine import ExpenseEngine
        from cashflow.engine import CashFlowEngine
        from budget_engine.engine import BudgetEngine
        from forecasting.engine import ForecastingEngine
        from investment_engine.engine import InvestmentEngine
        from tax_engine.engine import TaxEngine
        from wealth_management.engine import WealthEngine
        from risk_analysis.engine import RiskEngine
        from fraud_detection.engine import FraudEngine
        from anomaly_detection.engine import AnomalyEngine
        from recommendations.engine import RecommendationEngine

        self._engines = {
            "finance": FinanceEngine(),
            "accounting": AccountingEngine(),
            "bookkeeping": BookkeepingEngine(),
            "revenue": RevenueEngine(),
            "expense": ExpenseEngine(),
            "cashflow": CashFlowEngine(),
            "budget": BudgetEngine(),
            "forecasting": ForecastingEngine(),
            "investment": InvestmentEngine(),
            "tax": TaxEngine(),
            "wealth": WealthEngine(),
            "risk": RiskEngine(),
            "fraud": FraudEngine(),
            "anomaly": AnomalyEngine(),
            "recommendations": RecommendationEngine(),
        }
        for name, engine in self._engines.items():
            try:
                await engine.initialize()
                logger.info(f"Engine '{name}' initialized")
            except Exception as e:
                logger.error(f"Failed to initialize engine '{name}': {e}")
        self._initialized = True
        logger.info("FinancialOS fully initialized")

    async def execute_command(self, command: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        if not self._initialized:
            raise RuntimeError("FinancialOS not initialized")
        handlers = {
            "create_transaction": self._handle_create_transaction,
            "create_account": self._handle_create_account,
            "create_budget": self._handle_create_budget,
            "create_invoice": self._handle_create_invoice,
            "process_payment": self._handle_process_payment,
            "generate_report": self._handle_generate_report,
            "forecast_cashflow": self._handle_forecast_cashflow,
            "reconcile": self._handle_reconcile,
            "audit": self._handle_audit,
            "tax_calculate": self._handle_tax_calculate,
            "investment_rebalance": self._handle_investment_rebalance,
        }
        handler = handlers.get(command)
        if not handler:
            raise ResourceNotFoundError(f"Unknown command: {command}")
        return await handler(payload)

    async def query(self, query_type: str, params: Dict[str, Any]) -> Dict[str, Any]:
        if not self._initialized:
            raise RuntimeError("FinancialOS not initialized")
        handlers = {
            "net_worth": self._query_net_worth,
            "cash_flow": self._query_cash_flow,
            "transactions": self._query_transactions,
            "budget_status": self._query_budget_status,
            "portfolio": self._query_portfolio,
            "tax_summary": self._query_tax_summary,
            "financial_health": self._query_financial_health,
            "alerts": self._query_alerts,
            "reports": self._query_reports,
        }
        handler = handlers.get(query_type)
        if not handler:
            raise ResourceNotFoundError(f"Unknown query: {query_type}")
        return await handler(params)

    async def _handle_create_transaction(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        return await self._engines["finance"].process_transaction(payload)

    async def _handle_create_account(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        return await self._engines["accounting"].create_account(payload)

    async def _handle_create_budget(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        return await self._engines["budget"].create_budget(payload)

    async def _handle_create_invoice(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        from invoices.engine import InvoiceEngine
        engine = InvoiceEngine()
        return await engine.create_invoice(payload)

    async def _handle_process_payment(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        from payment_tracking.engine import PaymentEngine
        engine = PaymentEngine()
        return await engine.process_payment(payload)

    async def _handle_generate_report(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        from reporting.engine import ReportingEngine
        engine = ReportingEngine()
        return await engine.generate_report(payload)

    async def _handle_forecast_cashflow(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        return await self._engines["forecasting"].forecast_cashflow(payload)

    async def _handle_reconcile(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        return await self._engines["finance"].reconcile_accounts(payload.get("user_id"))

    async def _handle_audit(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        from audit.engine import AuditEngine
        engine = AuditEngine()
        return await engine.run_audit(payload)

    async def _handle_tax_calculate(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        return await self._engines["tax"].calculate_tax(payload)

    async def _handle_investment_rebalance(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        return await self._engines["investment"].rebalance_portfolio(payload)

    async def _query_net_worth(self, params: Dict[str, Any]) -> Dict[str, Any]:
        user_id = params.get("user_id")
        as_of = params.get("as_of")
        net_worth = await self._engines["finance"].calculate_net_worth(user_id, as_of)
        return {"net_worth": net_worth.to_dict()}

    async def _query_cash_flow(self, params: Dict[str, Any]) -> Dict[str, Any]:
        user_id = params.get("user_id")
        start = params.get("start_date")
        end = params.get("end_date")
        return await self._engines["finance"].calculate_cash_flow(user_id, start, end)

    async def _query_transactions(self, params: Dict[str, Any]) -> Dict[str, Any]:
        from financial_analytics.engine import AnalyticsEngine
        engine = AnalyticsEngine()
        return await engine.query_transactions(params)

    async def _query_budget_status(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return await self._engines["budget"].get_budget_status(params.get("budget_id"))

    async def _query_portfolio(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return await self._engines["investment"].get_portfolio(params.get("user_id"))

    async def _query_tax_summary(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return await self._engines["tax"].get_tax_summary(params.get("user_id"), params.get("year"))

    async def _query_financial_health(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return await self._engines["finance"].get_financial_health(params.get("user_id"))

    async def _query_alerts(self, params: Dict[str, Any]) -> Dict[str, Any]:
        from alerts.engine import AlertEngine
        engine = AlertEngine()
        return await engine.get_alerts(params.get("user_id"))

    async def _query_reports(self, params: Dict[str, Any]) -> Dict[str, Any]:
        from reporting.engine import ReportingEngine
        engine = ReportingEngine()
        return await engine.list_reports(params.get("user_id"))

    async def shutdown(self) -> None:
        for name, engine in self._engines.items():
            try:
                await engine.shutdown()
                logger.info(f"Engine '{name}' shut down")
            except Exception as e:
                logger.error(f"Error shutting down engine '{name}': {e}")
        self._initialized = False
        logger.info("FinancialOS shut down")
