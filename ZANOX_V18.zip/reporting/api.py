"""
ZANOX V18 Reporting API
"""
from fastapi import APIRouter
from uuid import UUID
from datetime import date

from .engine import ReportingEngine

router = APIRouter(prefix="/reports", tags=["reports"])
engine = ReportingEngine()


@router.post("/generate")
async def generate_report(payload: dict):
    return await engine.generate_report(payload)


@router.get("/{user_id}")
async def list_reports(user_id: UUID):
    return await engine.list_reports(user_id)


@router.get("/detail/{report_id}")
async def get_report(report_id: UUID):
    return await engine.get_report(report_id)
