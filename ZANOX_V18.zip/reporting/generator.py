"""
ZANOX V18 Report Generator
Creates multi-format financial reports.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.database import get_db_context
from shared.logger import get_logger

logger = get_logger("report_generator")


class ReportGenerator:
    async def generate(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        report_type = payload.get("type", "summary")
        user_id = payload.get("user_id")
        start = payload.get("start_date", date.today().replace(day=1))
        end = payload.get("end_date", date.today())

        if report_type == "summary":
            return await self._generate_summary(user_id, start, end)
        elif report_type == "income_statement":
            from income_statement.generator import IncomeStatementGenerator
            gen = IncomeStatementGenerator()
            return await gen.generate(user_id, start, end)
        elif report_type == "balance_sheet":
            from balance_sheet.generator import BalanceSheetGenerator
            gen = BalanceSheetGenerator()
            return await gen.generate(user_id, end)
        elif report_type == "cash_flow":
            from cashflow.tracker import CashFlowTracker
            tracker = CashFlowTracker()
            return await tracker.get_statement(user_id, start, end)
        elif report_type == "pnl":
            from profit_loss.generator import PnLGenerator
            gen = PnLGenerator()
            return await gen.generate(user_id, start, end)
        return {"error": f"Unknown report type: {report_type}"}

    async def _generate_summary(self, user_id: UUID, start: date, end: date) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            income = await session.execute(text("SELECT COALESCE(SUM(amount), 0) as total FROM transactions WHERE user_id = :user_id AND type = 'income' AND transaction_date BETWEEN :start AND :end AND status = 'completed'"), {"user_id": str(user_id), "start": start, "end": end})
            expenses = await session.execute(text("SELECT COALESCE(SUM(amount), 0) as total FROM transactions WHERE user_id = :user_id AND type = 'expense' AND transaction_date BETWEEN :start AND :end AND status = 'completed'"), {"user_id": str(user_id), "start": start, "end": end})
            total_income = Decimal(str(income.fetchone()[0]))
            total_expenses = Decimal(str(expenses.fetchone()[0]))
        return {
            "report_type": "summary",
            "period": {"start": start.isoformat(), "end": end.isoformat()},
            "total_income": float(total_income),
            "total_expenses": float(total_expenses),
            "net": float(total_income - total_expenses),
            "generated_at": date.today().isoformat(),
        }

    async def list(self, user_id: UUID) -> List[Dict[str, Any]]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("SELECT * FROM reports WHERE user_id = :user_id ORDER BY created_at DESC")
            result = await session.execute(query, {"user_id": str(user_id)})
            return [dict(row) for row in result.mappings()]

    async def get(self, report_id: UUID) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("SELECT * FROM reports WHERE id = :id")
            result = await session.execute(query, {"id": str(report_id)})
            row = result.mappings().fetchone()
            if not row:
                return {"error": "Report not found"}
            return dict(row)
