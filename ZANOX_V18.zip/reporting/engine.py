"""
ZANOX V18 Reporting Engine Core
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("reporting_engine")


class ReportingEngine:
    def __init__(self):
        self._generator = None

    async def initialize(self):
        from .generator import ReportGenerator
        self._generator = ReportGenerator()
        logger.info("ReportingEngine initialized")

    async def generate_report(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        if not self._generator:
            raise RuntimeError("Engine not initialized")
        return await self._generator.generate(payload)

    async def list_reports(self, user_id: UUID) -> List[Dict[str, Any]]:
        if not self._generator:
            raise RuntimeError("Engine not initialized")
        return await self._generator.list(user_id)

    async def get_report(self, report_id: UUID) -> Dict[str, Any]:
        if not self._generator:
            raise RuntimeError("Engine not initialized")
        return await self._generator.get(report_id)

    async def shutdown(self):
        logger.info("ReportingEngine shut down")
