"""
ZANOX V18 Audit API
"""
from fastapi import APIRouter
from uuid import UUID
from datetime import date

from .engine import AuditEngine

router = APIRouter(prefix="/audit", tags=["audit"])
engine = AuditEngine()


@router.post("/run")
async def run_audit(payload: dict):
    return await engine.run_audit(payload)


@router.get("/logs/{entity_type}")
async def get_logs(entity_type: str, start: date, end: date):
    return await engine.get_audit_log(None, entity_type, start, end)


@router.get("/verify/{user_id}")
async def verify_integrity(user_id: UUID):
    return await engine.verify_integrity(user_id)
