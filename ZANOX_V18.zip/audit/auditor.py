"""
ZANOX V18 Financial Auditor
Performs audit trails and integrity checks.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.database import get_db_context
from shared.logger import get_logger

logger = get_logger("financial_auditor")


class FinancialAuditor:
    async def audit(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        user_id = payload.get("user_id")
        start = payload.get("start_date", date.today().replace(day=1))
        end = payload.get("end_date", date.today())
        async with get_db_context() as session:
            from sqlalchemy import text
            txn_count = await session.execute(text("SELECT COUNT(*) as total FROM transactions WHERE user_id = :user_id AND created_at BETWEEN :start AND :end"), {"user_id": str(user_id), "start": start, "end": end})
            journal_count = await session.execute(text("SELECT COUNT(*) as total FROM journal_entries WHERE created_at BETWEEN :start AND :end"), {"start": start, "end": end})
            ledger_count = await session.execute(text("SELECT COUNT(*) as total FROM general_ledger_entries WHERE entry_date BETWEEN :start AND :end"), {"start": start, "end": end})
        return {
            "audit_period": {"start": start.isoformat(), "end": end.isoformat()},
            "transactions_audited": txn_count.fetchone()[0],
            "journal_entries_audited": journal_count.fetchone()[0],
            "ledger_entries_audited": ledger_count.fetchone()[0],
            "status": "completed",
        }

    async def get_logs(self, user_id: UUID, entity_type: str, start: date, end: date) -> List[Dict[str, Any]]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("SELECT * FROM audit_logs WHERE entity_type = :entity_type AND performed_at BETWEEN :start AND :end ORDER BY performed_at DESC")
            result = await session.execute(query, {"entity_type": entity_type, "start": start, "end": end})
            return [dict(row) for row in result.mappings()]

    async def verify(self, user_id: UUID) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            assets = await session.execute(text("SELECT COALESCE(SUM(balance), 0) as total FROM accounts WHERE user_id = :user_id AND account_type = 'asset'"), {"user_id": str(user_id)})
            liabilities = await session.execute(text("SELECT COALESCE(SUM(balance), 0) as total FROM accounts WHERE user_id = :user_id AND account_type = 'liability'"), {"user_id": str(user_id)})
            equity = await session.execute(text("SELECT COALESCE(SUM(balance), 0) as total FROM accounts WHERE user_id = :user_id AND account_type = 'equity'"), {"user_id": str(user_id)})
            a = Decimal(str(assets.fetchone()[0]))
            l = Decimal(str(liabilities.fetchone()[0]))
            e = Decimal(str(equity.fetchone()[0]))
            balanced = abs(a - l - e) < Decimal("0.01")
        return {"user_id": str(user_id), "assets": float(a), "liabilities": float(l), "equity": float(e), "balanced": balanced, "integrity": "verified" if balanced else "failed"}
