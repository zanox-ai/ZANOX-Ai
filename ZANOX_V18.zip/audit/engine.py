"""
ZANOX V18 Audit Engine Core
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("audit_engine")


class AuditEngine:
    def __init__(self):
        self._auditor = None

    async def initialize(self):
        from .auditor import FinancialAuditor
        self._auditor = FinancialAuditor()
        logger.info("AuditEngine initialized")

    async def run_audit(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        if not self._auditor:
            raise RuntimeError("Engine not initialized")
        return await self._auditor.audit(payload)

    async def get_audit_log(self, user_id: UUID, entity_type: str, start: date, end: date) -> List[Dict[str, Any]]:
        if not self._auditor:
            raise RuntimeError("Engine not initialized")
        return await self._auditor.get_logs(user_id, entity_type, start, end)

    async def verify_integrity(self, user_id: UUID) -> Dict[str, Any]:
        if not self._auditor:
            raise RuntimeError("Engine not initialized")
        return await self._auditor.verify(user_id)

    async def shutdown(self):
        logger.info("AuditEngine shut down")
