"""
ZANOX V18 Budget Engine Core
"""
from typing import Dict, Any, List, Optional
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("budget_engine")


class BudgetEngine:
    def __init__(self):
        self._planner = None
        self._enforcer = None

    async def initialize(self):
        from .planner import BudgetPlanner
        from .enforcer import BudgetEnforcer
        self._planner = BudgetPlanner()
        self._enforcer = BudgetEnforcer()
        logger.info("BudgetEngine initialized")

    async def create_budget(self, data: Dict[str, Any]) -> Dict[str, Any]:
        if not self._planner:
            raise RuntimeError("Engine not initialized")
        return await self._planner.create(data)

    async def get_budget_status(self, budget_id: UUID) -> Dict[str, Any]:
        if not self._enforcer:
            raise RuntimeError("Engine not initialized")
        return await self._enforcer.get_status(budget_id)

    async def check_spending(self, user_id: UUID, category: str, amount: Decimal) -> Dict[str, Any]:
        if not self._enforcer:
            raise RuntimeError("Engine not initialized")
        return await self._enforcer.check_spending(user_id, category, amount)

    async def list_budgets(self, user_id: UUID) -> List[Dict[str, Any]]:
        if not self._planner:
            raise RuntimeError("Engine not initialized")
        return await self._planner.list_budgets(user_id)

    async def shutdown(self):
        logger.info("BudgetEngine shut down")
