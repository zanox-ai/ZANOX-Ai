"""
ZANOX V18 Budget Enforcer
Monitors spending against budgets and triggers alerts.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.database import get_db_context
from shared.logger import get_logger

logger = get_logger("budget_enforcer")


class BudgetEnforcer:
    async def get_status(self, budget_id: UUID) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            budget_query = text("SELECT * FROM budgets WHERE id = :id")
            budget_result = await session.execute(budget_query, {"id": str(budget_id)})
            budget = budget_result.mappings().fetchone()
            if not budget:
                return {"error": "Budget not found"}

            cat_query = text("""
                SELECT bc.*, COALESCE(SUM(e.amount), 0) as spent
                FROM budget_categories bc
                LEFT JOIN expense_records e ON e.category = bc.category
                AND e.user_id = :user_id AND e.transaction_date BETWEEN :start AND :end
                WHERE bc.budget_id = :budget_id
                GROUP BY bc.id
            """)
            cat_result = await session.execute(cat_query, {
                "budget_id": str(budget_id),
                "user_id": budget["user_id"],
                "start": budget["start_date"],
                "end": budget["end_date"],
            })
            categories = []
            total_spent = Decimal("0")
            for row in cat_result.mappings():
                cat = dict(row)
                limit_amount = Decimal(str(cat["limit_amount"]))
                spent = Decimal(str(cat.get("spent", 0)))
                total_spent += spent
                remaining = limit_amount - spent
                pct_used = (spent / limit_amount * 100) if limit_amount > 0 else Decimal("0")
                cat["spent"] = float(spent)
                cat["remaining"] = float(remaining)
                cat["pct_used"] = float(pct_used.quantize(Decimal("0.01")))
                cat["alert"] = pct_used >= Decimal("80")
                cat["exceeded"] = pct_used > Decimal("100")
                categories.append(cat)

            total_limit = Decimal(str(budget["total_amount"]))
            total_remaining = total_limit - total_spent
            total_pct = (total_spent / total_limit * 100) if total_limit > 0 else Decimal("0")

            return {
                "budget_id": str(budget_id),
                "name": budget["name"],
                "total_limit": float(total_limit),
                "total_spent": float(total_spent),
                "total_remaining": float(total_remaining),
                "total_pct_used": float(total_pct.quantize(Decimal("0.01"))),
                "status": "active" if total_pct <= 100 else "over_budget",
                "categories": categories,
                "period": {
                    "start": budget["start_date"].isoformat(),
                    "end": budget["end_date"].isoformat(),
                },
            }

    async def check_spending(self, user_id: UUID, category: str, amount: Decimal) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT bc.*, b.name as budget_name, b.start_date, b.end_date
                FROM budget_categories bc
                JOIN budgets b ON b.id = bc.budget_id
                WHERE b.user_id = :user_id AND bc.category = :category AND b.status = 'active'
                ORDER BY b.created_at DESC LIMIT 1
            """)
            result = await session.execute(query, {"user_id": str(user_id), "category": category})
            row = result.mappings().fetchone()
            if not row:
                return {"has_budget": False, "allowed": True}

            limit_amount = Decimal(str(row["limit_amount"]))
            spent_query = text("""
                SELECT COALESCE(SUM(amount), 0) as spent
                FROM expense_records
                WHERE user_id = :user_id AND category = :category
                AND transaction_date BETWEEN :start AND :end
            """)
            spent_result = await session.execute(spent_query, {
                "user_id": str(user_id), "category": category,
                "start": row["start_date"], "end": row["end_date"],
            })
            spent = Decimal(str(spent_result.fetchone()[0]))
            projected = spent + amount

            return {
                "has_budget": True,
                "budget_name": row["budget_name"],
                "limit": float(limit_amount),
                "spent": float(spent),
                "projected": float(projected),
                "remaining": float(limit_amount - projected),
                "allowed": projected <= limit_amount,
                "overage": float(projected - limit_amount) if projected > limit_amount else 0,
                "alert": (spent / limit_amount * 100) >= 80 if limit_amount > 0 else False,
            }
