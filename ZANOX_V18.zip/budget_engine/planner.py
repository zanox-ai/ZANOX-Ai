"""
ZANOX V18 Budget Planner
Creates and manages budget plans with category allocation.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.database import get_db_context
from shared.exceptions import ValidationError
from shared.logger import get_logger

logger = get_logger("budget_planner")


class BudgetPlanner:
    DEFAULT_ALLOCATIONS = {
        "housing": 30,
        "food": 15,
        "transportation": 10,
        "utilities": 10,
        "healthcare": 5,
        "entertainment": 5,
        "savings": 10,
        "debt": 5,
        "other": 10,
    }

    async def create(self, data: Dict[str, Any]) -> Dict[str, Any]:
        required = ["user_id", "name", "total_amount", "start_date", "end_date"]
        for field in required:
            if field not in data:
                raise ValidationError(f"Missing required field: {field}")

        async with get_db_context() as session:
            from sqlalchemy import text
            budget_query = text("""
                INSERT INTO budgets (
                    id, user_id, name, total_amount, currency, start_date, end_date,
                    status, type, created_at, updated_at
                ) VALUES (
                    gen_random_uuid(), :user_id, :name, :total_amount, :currency,
                    :start_date, :end_date, 'active', :type, NOW(), NOW()
                ) RETURNING id
            """)
            result = await session.execute(budget_query, {
                "user_id": data["user_id"],
                "name": data["name"],
                "total_amount": str(data["total_amount"]),
                "currency": data.get("currency", "USD"),
                "start_date": data["start_date"],
                "end_date": data["end_date"],
                "type": data.get("type", "monthly"),
            })
            budget_id = str(result.fetchone()[0])

            categories = data.get("categories", self.DEFAULT_ALLOCATIONS)
            total_amount = Decimal(str(data["total_amount"]))
            for cat, pct in categories.items():
                cat_amount = total_amount * Decimal(str(pct)) / 100
                cat_query = text("""
                    INSERT INTO budget_categories (
                        id, budget_id, category, limit_amount, alert_threshold, created_at
                    ) VALUES (gen_random_uuid(), :budget_id, :category, :limit_amount, :alert_threshold, NOW())
                """)
                await session.execute(cat_query, {
                    "budget_id": budget_id,
                    "category": cat,
                    "limit_amount": str(cat_amount),
                    "alert_threshold": str(cat_amount * Decimal("0.8")),
                })

            logger.info(f"Created budget: {budget_id} - {data['name']}")
            return {"budget_id": budget_id, "name": data["name"], "total_amount": float(total_amount)}

    async def list_budgets(self, user_id: UUID) -> List[Dict[str, Any]]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT b.*, COUNT(bc.id) as category_count
                FROM budgets b
                LEFT JOIN budget_categories bc ON bc.budget_id = b.id
                WHERE b.user_id = :user_id
                GROUP BY b.id
                ORDER BY b.created_at DESC
            """)
            result = await session.execute(query, {"user_id": str(user_id)})
            return [dict(row) for row in result.mappings()]

    async def get_budget(self, budget_id: UUID) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("SELECT * FROM budgets WHERE id = :id")
            result = await session.execute(query, {"id": str(budget_id)})
            row = result.mappings().fetchone()
            if not row:
                raise ValidationError("Budget not found")
            return dict(row)

    async def update_budget(self, budget_id: UUID, data: Dict[str, Any]) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                UPDATE budgets SET name = :name, total_amount = :total_amount, updated_at = NOW()
                WHERE id = :id RETURNING id, name, total_amount
            """)
            result = await session.execute(query, {
                "id": str(budget_id),
                "name": data.get("name"),
                "total_amount": str(data.get("total_amount", 0)),
            })
            row = result.mappings().fetchone()
            if not row:
                raise ValidationError("Budget not found")
            return dict(row)
