"""
ZANOX V18 Financial Dashboard Engine
Builds real-time financial dashboards and widgets.
"""
from .engine import DashboardEngine
from .builder import DashboardBuilder
from .api import router

__all__ = ["DashboardEngine", "DashboardBuilder", "router"]
