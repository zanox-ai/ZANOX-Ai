"""
ZANOX V18 Financial Dashboard API
"""
from fastapi import APIRouter
from uuid import UUID

from .engine import DashboardEngine

router = APIRouter(prefix="/dashboard", tags=["dashboard"])
engine = DashboardEngine()


@router.get("/{user_id}")
async def build_dashboard(user_id: UUID):
    return await engine.build_dashboard(user_id)


@router.get("/{user_id}/widget/{widget}")
async def get_widget(user_id: UUID, widget: str):
    return await engine.get_widget_data(user_id, widget)
