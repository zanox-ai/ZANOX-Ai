"""
ZANOX V18 Financial Dashboard Engine Core
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("dashboard_engine")


class DashboardEngine:
    def __init__(self):
        self._builder = None

    async def initialize(self):
        from .builder import DashboardBuilder
        self._builder = DashboardBuilder()
        logger.info("DashboardEngine initialized")

    async def build_dashboard(self, user_id: UUID) -> Dict[str, Any]:
        if not self._builder:
            raise RuntimeError("Engine not initialized")
        return await self._builder.build(user_id)

    async def get_widget_data(self, user_id: UUID, widget: str) -> Dict[str, Any]:
        if not self._builder:
            raise RuntimeError("Engine not initialized")
        return await self._builder.get_widget(user_id, widget)

    async def shutdown(self):
        logger.info("DashboardEngine shut down")
