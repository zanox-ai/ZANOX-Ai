"""
ZANOX V18 Dashboard Builder
Constructs dashboard widgets with real-time data.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date, timedelta
from uuid import UUID

from shared.database import get_db_context
from shared.logger import get_logger

logger = get_logger("dashboard_builder")


class DashboardBuilder:
    async def build(self, user_id: UUID) -> Dict[str, Any]:
        widgets = {
            "net_worth": await self._net_worth_widget(user_id),
            "cash_flow": await self._cash_flow_widget(user_id),
            "budget_status": await self._budget_widget(user_id),
            "investments": await self._investment_widget(user_id),
            "alerts": await self._alerts_widget(user_id),
            "recent_transactions": await self._transactions_widget(user_id),
        }
        return {"user_id": str(user_id), "as_of": date.today().isoformat(), "widgets": widgets}

    async def get_widget(self, user_id: UUID, widget: str) -> Dict[str, Any]:
        widgets = {
            "net_worth": self._net_worth_widget,
            "cash_flow": self._cash_flow_widget,
            "budget_status": self._budget_widget,
            "investments": self._investment_widget,
            "alerts": self._alerts_widget,
            "recent_transactions": self._transactions_widget,
        }
        fn = widgets.get(widget)
        if fn:
            return await fn(user_id)
        return {"error": f"Unknown widget: {widget}"}

    async def _net_worth_widget(self, user_id: UUID) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            assets = await session.execute(text("SELECT COALESCE(SUM(balance), 0) as total FROM accounts WHERE user_id = :user_id AND account_type = 'asset'"), {"user_id": str(user_id)})
            liabilities = await session.execute(text("SELECT COALESCE(SUM(balance), 0) as total FROM accounts WHERE user_id = :user_id AND account_type = 'liability'"), {"user_id": str(user_id)})
            a = Decimal(str(assets.fetchone()[0]))
            l = Decimal(str(liabilities.fetchone()[0]))
        return {"type": "net_worth", "assets": float(a), "liabilities": float(l), "net_worth": float(a - l)}

    async def _cash_flow_widget(self, user_id: UUID) -> Dict[str, Any]:
        today = date.today()
        start = date(today.year, today.month, 1)
        async with get_db_context() as session:
            from sqlalchemy import text
            income = await session.execute(text("SELECT COALESCE(SUM(amount), 0) as total FROM transactions WHERE user_id = :user_id AND type = 'income' AND transaction_date >= :start AND status = 'completed'"), {"user_id": str(user_id), "start": start})
            expenses = await session.execute(text("SELECT COALESCE(SUM(amount), 0) as total FROM transactions WHERE user_id = :user_id AND type = 'expense' AND transaction_date >= :start AND status = 'completed'"), {"user_id": str(user_id), "start": start})
            i = Decimal(str(income.fetchone()[0]))
            e = Decimal(str(expenses.fetchone()[0]))
        return {"type": "cash_flow", "income": float(i), "expenses": float(e), "net": float(i - e)}

    async def _budget_widget(self, user_id: UUID) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT b.name, b.total_amount, COALESCE(SUM(e.amount), 0) as spent
                FROM budgets b
                LEFT JOIN expense_records e ON e.user_id = b.user_id AND e.transaction_date BETWEEN b.start_date AND b.end_date
                WHERE b.user_id = :user_id AND b.status = 'active'
                GROUP BY b.id, b.name, b.total_amount
            """)
            result = await session.execute(query, {"user_id": str(user_id)})
            budgets = [dict(row) for row in result.mappings()]
        return {"type": "budget_status", "budgets": budgets}

    async def _investment_widget(self, user_id: UUID) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("SELECT COALESCE(SUM(total_amount), 0) as total FROM investment_trades WHERE user_id = :user_id AND status = 'completed'")
            result = await session.execute(query, {"user_id": str(user_id)})
            total = Decimal(str(result.fetchone()[0]))
        return {"type": "investments", "total_invested": float(total)}

    async def _alerts_widget(self, user_id: UUID) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("SELECT COUNT(*) as count FROM alerts WHERE user_id = :user_id AND status = 'unread'")
            result = await session.execute(query, {"user_id": str(user_id)})
            count = result.fetchone()[0]
        return {"type": "alerts", "unread_count": count}

    async def _transactions_widget(self, user_id: UUID) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("SELECT * FROM transactions WHERE user_id = :user_id ORDER BY created_at DESC LIMIT 10")
            result = await session.execute(query, {"user_id": str(user_id)})
            transactions = [dict(row) for row in result.mappings()]
        return {"type": "recent_transactions", "transactions": transactions}
