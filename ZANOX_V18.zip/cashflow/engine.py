"""
ZANOX V18 Cash Flow Engine Core
"""
from typing import Dict, Any, List, Optional
from decimal import Decimal
from datetime import date, timedelta
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("cashflow_engine")


class CashFlowEngine:
    def __init__(self):
        self._tracker = None
        self._optimizer = None

    async def initialize(self):
        from .tracker import CashFlowTracker
        from .optimizer import CashFlowOptimizer
        self._tracker = CashFlowTracker()
        self._optimizer = CashFlowOptimizer()
        logger.info("CashFlowEngine initialized")

    async def get_cash_flow_statement(self, user_id: UUID, start: date, end: date) -> Dict[str, Any]:
        if not self._tracker:
            raise RuntimeError("Engine not initialized")
        return await self._tracker.get_statement(user_id, start, end)

    async def forecast_cash_flow(self, user_id: UUID, days: int = 90) -> List[Dict[str, Any]]:
        if not self._tracker:
            raise RuntimeError("Engine not initialized")
        return await self._tracker.forecast(user_id, days)

    async def optimize_cash_flow(self, user_id: UUID) -> Dict[str, Any]:
        if not self._optimizer:
            raise RuntimeError("Engine not initialized")
        return await self._optimizer.optimize(user_id)

    async def get_liquidity_ratio(self, user_id: UUID) -> Dict[str, Any]:
        if not self._tracker:
            raise RuntimeError("Engine not initialized")
        return await self._tracker.get_liquidity_ratio(user_id)

    async def shutdown(self):
        logger.info("CashFlowEngine shut down")
