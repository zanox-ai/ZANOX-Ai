"""
ZANOX V18 Cash Flow Tracker
Generates cash flow statements and forecasts.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date, timedelta
from uuid import UUID

from shared.database import get_db_context
from shared.utils import get_month_start, get_month_end, safe_divide
from shared.logger import get_logger

logger = get_logger("cashflow_tracker")


class CashFlowTracker:
    async def get_statement(self, user_id: UUID, start: date, end: date) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            operating_income = await session.execute(text("""
                SELECT COALESCE(SUM(amount), 0) FROM transactions
                WHERE user_id = :user_id AND type = 'income' AND category != 'investment'
                AND transaction_date BETWEEN :start AND :end AND status = 'completed'
            """), {"user_id": str(user_id), "start": start, "end": end})
            operating_expenses = await session.execute(text("""
                SELECT COALESCE(SUM(amount), 0) FROM transactions
                WHERE user_id = :user_id AND type = 'expense' AND category NOT IN ('investment', 'debt_payment')
                AND transaction_date BETWEEN :start AND :end AND status = 'completed'
            """), {"user_id": str(user_id), "start": start, "end": end})
            investing_in = await session.execute(text("""
                SELECT COALESCE(SUM(amount), 0) FROM transactions
                WHERE user_id = :user_id AND type = 'income' AND category = 'investment'
                AND transaction_date BETWEEN :start AND :end AND status = 'completed'
            """), {"user_id": str(user_id), "start": start, "end": end})
            investing_out = await session.execute(text("""
                SELECT COALESCE(SUM(amount), 0) FROM transactions
                WHERE user_id = :user_id AND type = 'expense' AND category = 'investment'
                AND transaction_date BETWEEN :start AND :end AND status = 'completed'
            """), {"user_id": str(user_id), "start": start, "end": end})
            financing_in = await session.execute(text("""
                SELECT COALESCE(SUM(amount), 0) FROM transactions
                WHERE user_id = :user_id AND type = 'income' AND category IN ('loan', 'equity', 'debt')
                AND transaction_date BETWEEN :start AND :end AND status = 'completed'
            """), {"user_id": str(user_id), "start": start, "end": end})
            financing_out = await session.execute(text("""
                SELECT COALESCE(SUM(amount), 0) FROM transactions
                WHERE user_id = :user_id AND type = 'expense' AND category IN ('debt_payment', 'dividend')
                AND transaction_date BETWEEN :start AND :end AND status = 'completed'
            """), {"user_id": str(user_id), "start": start, "end": end})

            oi = Decimal(str(operating_income.fetchone()[0]))
            oe = Decimal(str(operating_expenses.fetchone()[0]))
            ii = Decimal(str(investing_in.fetchone()[0]))
            io = Decimal(str(investing_out.fetchone()[0]))
            fi = Decimal(str(financing_in.fetchone()[0]))
            fo = Decimal(str(financing_out.fetchone()[0]))

            operating = oi - oe
            investing = ii - io
            financing = fi - fo
            net_change = operating + investing + financing

            return {
                "period": {"start": start.isoformat(), "end": end.isoformat()},
                "operating_activities": {
                    "inflows": float(oi),
                    "outflows": float(oe),
                    "net": float(operating),
                },
                "investing_activities": {
                    "inflows": float(ii),
                    "outflows": float(io),
                    "net": float(investing),
                },
                "financing_activities": {
                    "inflows": float(fi),
                    "outflows": float(fo),
                    "net": float(financing),
                },
                "net_cash_change": float(net_change),
            }

    async def forecast(self, user_id: UUID, days: int = 90) -> List[Dict[str, Any]]:
        today = date.today()
        historical = []
        for i in range(30, 0, -1):
            d = today - timedelta(days=i)
            stmt = await self.get_statement(user_id, d, d)
            historical.append(stmt["net_cash_change"])

        avg_daily = sum(historical) / len(historical) if historical else 0
        forecasts = []
        for i in range(1, days + 1):
            forecast_date = today + timedelta(days=i)
            forecasts.append({
                "date": forecast_date.isoformat(),
                "forecasted_net_change": round(avg_daily, 2),
                "cumulative": round(avg_daily * i, 2),
            })
        return forecasts

    async def get_liquidity_ratio(self, user_id: UUID) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            current_assets = await session.execute(text("""
                SELECT COALESCE(SUM(balance), 0) FROM accounts
                WHERE user_id = :user_id AND account_type = 'asset' AND category = 'current_asset'
            """), {"user_id": str(user_id)})
            current_liabilities = await session.execute(text("""
                SELECT COALESCE(SUM(balance), 0) FROM accounts
                WHERE user_id = :user_id AND account_type = 'liability' AND category = 'current_liability'
            """), {"user_id": str(user_id)})
            ca = Decimal(str(current_assets.fetchone()[0]))
            cl = Decimal(str(current_liabilities.fetchone()[0]))
            ratio = safe_divide(ca, cl, Decimal("0"))
            return {
                "current_assets": float(ca),
                "current_liabilities": float(cl),
                "current_ratio": float(ratio.quantize(Decimal("0.01"))),
                "healthy": ratio >= Decimal("1.5"),
            }
