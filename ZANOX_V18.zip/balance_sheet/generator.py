"""
ZANOX V18 Balance Sheet Generator
Builds detailed balance sheets with asset/liability/equity breakdown.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.database import get_db_context
from shared.logger import get_logger

logger = get_logger("balance_sheet_generator")


class BalanceSheetGenerator:
    async def generate(self, user_id: UUID, as_of: date) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            assets_query = text("""
                SELECT name, category, balance, currency
                FROM accounts
                WHERE user_id = :user_id AND account_type = 'asset' AND is_active = true
                AND created_at <= :as_of
                ORDER BY category, name
            """)
            assets_result = await session.execute(assets_query, {
                "user_id": str(user_id), "as_of": as_of
            })
            assets = [dict(row) for row in assets_result.mappings()]
            total_assets = sum(Decimal(str(a["balance"])) for a in assets)

            liabilities_query = text("""
                SELECT name, category, balance, currency
                FROM accounts
                WHERE user_id = :user_id AND account_type = 'liability' AND is_active = true
                AND created_at <= :as_of
                ORDER BY category, name
            """)
            liabilities_result = await session.execute(liabilities_query, {
                "user_id": str(user_id), "as_of": as_of
            })
            liabilities = [dict(row) for row in liabilities_result.mappings()]
            total_liabilities = sum(Decimal(str(l["balance"])) for l in liabilities)

            equity_query = text("""
                SELECT name, category, balance, currency
                FROM accounts
                WHERE user_id = :user_id AND account_type = 'equity' AND is_active = true
                AND created_at <= :as_of
                ORDER BY category, name
            """)
            equity_result = await session.execute(equity_query, {
                "user_id": str(user_id), "as_of": as_of
            })
            equity = [dict(row) for row in equity_result.mappings()]
            total_equity = sum(Decimal(str(e["balance"])) for e in equity)

            net_worth = total_assets - total_liabilities
            balanced = abs(net_worth - total_equity) < Decimal("0.01")

            return {
                "as_of": as_of.isoformat(),
                "assets": {
                    "items": assets,
                    "total": float(total_assets),
                },
                "liabilities": {
                    "items": liabilities,
                    "total": float(total_liabilities),
                },
                "equity": {
                    "items": equity,
                    "total": float(total_equity),
                },
                "total_assets": float(total_assets),
                "total_liabilities": float(total_liabilities),
                "total_equity": float(total_equity),
                "net_worth": float(net_worth),
                "balanced": balanced,
                "debt_to_equity_ratio": float((total_liabilities / total_equity * 100).quantize(Decimal("0.01"))) if total_equity > 0 else 0,
            }
