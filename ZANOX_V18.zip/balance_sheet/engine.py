"""
ZANOX V18 Balance Sheet Engine Core
"""
from typing import Dict, Any
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("balance_sheet_engine")


class BalanceSheetEngine:
    def __init__(self):
        self._generator = None

    async def initialize(self):
        from .generator import BalanceSheetGenerator
        self._generator = BalanceSheetGenerator()
        logger.info("BalanceSheetEngine initialized")

    async def generate(self, user_id: UUID, as_of: date) -> Dict[str, Any]:
        if not self._generator:
            raise RuntimeError("Engine not initialized")
        return await self._generator.generate(user_id, as_of)

    async def shutdown(self):
        logger.info("BalanceSheetEngine shut down")
