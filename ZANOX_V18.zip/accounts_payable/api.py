"""
ZANOX V18 Accounts Payable API
"""
from fastapi import APIRouter
from uuid import UUID
from datetime import date

from .engine import AccountsPayableEngine

router = APIRouter(prefix="/accounts-payable", tags=["accounts-payable"])
engine = AccountsPayableEngine()


@router.post("/")
async def record_payable(data: dict):
    return await engine.record_payable(data)


@router.get("/aging/{user_id}")
async def get_aging_report(user_id: UUID, as_of: date = date.today()):
    return await engine.get_aging_report(user_id, as_of)


@router.post("/{payable_id}/pay")
async def make_payment(payable_id: UUID, payment: dict):
    return await engine.make_payment(payable_id, payment)
