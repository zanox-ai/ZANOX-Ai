"""
ZANOX V18 Accounts Payable Engine Core
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("ap_engine")


class AccountsPayableEngine:
    def __init__(self):
        self._manager = None

    async def initialize(self):
        from .manager import APManager
        self._manager = APManager()
        logger.info("AccountsPayableEngine initialized")

    async def record_payable(self, data: Dict[str, Any]) -> Dict[str, Any]:
        if not self._manager:
            raise RuntimeError("Engine not initialized")
        return await self._manager.record(data)

    async def get_aging_report(self, user_id: UUID, as_of: date) -> Dict[str, Any]:
        if not self._manager:
            raise RuntimeError("Engine not initialized")
        return await self._manager.get_aging_report(user_id, as_of)

    async def make_payment(self, payable_id: UUID, payment_data: Dict[str, Any]) -> Dict[str, Any]:
        if not self._manager:
            raise RuntimeError("Engine not initialized")
        return await self._manager.pay(payable_id, payment_data)

    async def shutdown(self):
        logger.info("AccountsPayableEngine shut down")
