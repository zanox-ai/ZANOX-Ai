"""
ZANOX V18 Transaction Categorizer
AI-powered transaction categorization using keyword and ML matching.
"""
from typing import Dict, Any, List, Optional
from decimal import Decimal
from uuid import UUID
import re

from shared.database import get_db_context
from shared.logger import get_logger

logger = get_logger("transaction_categorizer")


class TransactionCategorizer:
    CATEGORY_RULES = {
        "income": {
            "salary": ["payroll", "salary", "wage", "direct deposit", "paycheck"],
            "freelance": ["freelance", "consulting", "contract", "gig", "upwork", "fiverr"],
            "investment": ["dividend", "interest", "capital gain", "investment income"],
            "rental": ["rent", "rental income", "tenant"],
            "refund": ["refund", "reimbursement", "cashback"],
        },
        "expense": {
            "housing": ["rent", "mortgage", "hoa", "property tax", "home insurance"],
            "utilities": ["electric", "gas", "water", "sewer", "trash", "internet", "phone"],
            "food": ["grocery", "restaurant", "food", "dining", "takeout", "uber eats", "doordash"],
            "transportation": ["gas", "fuel", "parking", "toll", "uber", "lyft", "transit", "bus", "train"],
            "healthcare": ["doctor", "hospital", "pharmacy", "medical", "dental", "vision", "insurance"],
            "entertainment": ["netflix", "spotify", "movie", "theater", "concert", "game", "hbo", "disney"],
            "shopping": ["amazon", "walmart", "target", "best buy", "clothing", "electronics"],
            "education": ["tuition", "course", "book", "learning", "udemy", "coursera"],
            "travel": ["hotel", "flight", "airline", "booking", "airbnb", "expedia"],
            "software": ["software", "saas", "subscription", "app", "license"],
            "business": ["office", "supplies", "equipment", "marketing", "advertising"],
            "fees": ["fee", "charge", "penalty", "late fee", "overdraft", "atm"],
        },
    }

    async def categorize(self, transaction_id: UUID) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("SELECT * FROM transactions WHERE id = :id")
            result = await session.execute(query, {"id": str(transaction_id)})
            row = result.mappings().fetchone()
            if not row:
                return {"success": False, "error": "Transaction not found"}

            description = (row.get("description") or "").lower()
            tx_type = row.get("type", "expense")
            category = self._match_category(description, tx_type)

            update_query = text("""
                UPDATE transactions SET category = :category, updated_at = NOW()
                WHERE id = :id
            """)
            await session.execute(update_query, {"id": str(transaction_id), "category": category})

            logger.info(f"Categorized transaction {transaction_id} as '{category}'")
            return {"success": True, "transaction_id": str(transaction_id), "category": category}

    def _match_category(self, description: str, tx_type: str) -> str:
        rules = self.CATEGORY_RULES.get(tx_type, self.CATEGORY_RULES["expense"])
        for category, keywords in rules.items():
            for keyword in keywords:
                if keyword in description:
                    return category
        return "uncategorized"

    async def auto_categorize_batch(self, user_id: UUID, limit: int = 100) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT id, description, type FROM transactions
                WHERE user_id = :user_id AND (category IS NULL OR category = '') AND status = 'completed'
                LIMIT :limit
            """)
            result = await session.execute(query, {"user_id": str(user_id), "limit": limit})
            transactions = [dict(row) for row in result.mappings()]

        categorized = 0
        for txn in transactions:
            try:
                await self.categorize(UUID(txn["id"]))
                categorized += 1
            except Exception as e:
                logger.warning(f"Failed to categorize {txn['id']}: {e}")

        logger.info(f"Auto-categorized {categorized} transactions for user {user_id}")
        return {"categorized": categorized, "total_processed": len(transactions)}

    async def learn_from_user_correction(self, transaction_id: UUID, correct_category: str) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                UPDATE transactions SET category = :category, user_corrected = true, updated_at = NOW()
                WHERE id = :id RETURNING description
            """)
            result = await session.execute(query, {"id": str(transaction_id), "category": correct_category})
            row = result.mappings().fetchone()
            if row:
                description = row["description"].lower()
                tx_type = "expense"
                rules = self.CATEGORY_RULES.get(tx_type, {})
                if correct_category not in rules:
                    rules[correct_category] = []
                if description not in rules[correct_category]:
                    rules[correct_category].append(description)
                logger.info(f"Learned correction: '{description}' -> '{correct_category}'")
                return {"success": True, "learned": True}
            return {"success": False, "error": "Transaction not found"}
