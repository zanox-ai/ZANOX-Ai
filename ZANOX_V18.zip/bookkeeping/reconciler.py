"""
ZANOX V18 Bank Reconciler
Matches bank statement entries with internal transactions.
"""
from typing import Dict, Any, List, Optional
from decimal import Decimal
from datetime import date, timedelta
from uuid import UUID

from shared.database import get_db_context
from shared.logger import get_logger

logger = get_logger("bank_reconciler")


class BankReconciler:
    async def reconcile(self, user_id: UUID, bank_account_id: UUID, statement_data: List[Dict[str, Any]]) -> Dict[str, Any]:
        matched = []
        unmatched = []
        discrepancies = []

        async with get_db_context() as session:
            from sqlalchemy import text
            for stmt_entry in statement_data:
                stmt_amount = Decimal(str(stmt_entry.get("amount", 0)))
                stmt_date = stmt_entry.get("date")
                stmt_desc = stmt_entry.get("description", "").lower()
                stmt_ref = stmt_entry.get("reference", "")

                query = text("""
                    SELECT id, amount, description, transaction_date, status
                    FROM transactions
                    WHERE account_id = :account_id
                    AND ABS(amount - :amount) < 0.01
                    AND transaction_date BETWEEN :date_start AND :date_end
                    AND status = 'completed'
                    LIMIT 5
                """)
                result = await session.execute(query, {
                    "account_id": str(bank_account_id),
                    "amount": str(stmt_amount),
                    "date_start": stmt_date - timedelta(days=3) if isinstance(stmt_date, date) else stmt_date,
                    "date_end": stmt_date + timedelta(days=3) if isinstance(stmt_date, date) else stmt_date,
                })
                candidates = [dict(row) for row in result.mappings()]

                best_match = None
                best_score = 0
                for candidate in candidates:
                    score = 0
                    if abs(Decimal(str(candidate["amount"])) - stmt_amount) < Decimal("0.01"):
                        score += 50
                    cand_desc = (candidate.get("description") or "").lower()
                    if any(word in cand_desc for word in stmt_desc.split() if len(word) > 3):
                        score += 30
                    if candidate.get("transaction_date") == stmt_date:
                        score += 20
                    if score > best_score:
                        best_score = score
                        best_match = candidate

                if best_match and best_score >= 50:
                    matched.append({
                        "statement_entry": stmt_entry,
                        "transaction_id": best_match["id"],
                        "match_score": best_score,
                    })
                    update_query = text("""
                        UPDATE transactions SET reconciled = true, reconciliation_date = NOW(), updated_at = NOW()
                        WHERE id = :id
                    """)
                    await session.execute(update_query, {"id": best_match["id"]})
                else:
                    unmatched.append(stmt_entry)

            bank_balance_query = text("""
                SELECT balance FROM accounts WHERE id = :account_id
            """)
            bank_result = await session.execute(bank_balance_query, {"account_id": str(bank_account_id)})
            bank_balance = Decimal(str(bank_result.fetchone()[0])) if bank_result.fetchone() else Decimal("0")

            stmt_total = sum(Decimal(str(e.get("amount", 0))) for e in statement_data)
            if abs(bank_balance - stmt_total) > Decimal("0.01"):
                discrepancies.append({
                    "type": "balance_mismatch",
                    "bank_balance": float(bank_balance),
                    "statement_total": float(stmt_total),
                    "difference": float(bank_balance - stmt_total),
                })

        logger.info(f"Reconciliation: {len(matched)} matched, {len(unmatched)} unmatched, {len(discrepancies)} discrepancies")
        return {
            "matched": matched,
            "unmatched": unmatched,
            "discrepancies": discrepancies,
            "reconciled": len(unmatched) == 0 and len(discrepancies) == 0,
        }
