"""
ZANOX V18 Bookkeeping Engine Core
Automates daily bookkeeping tasks and reconciliation.
"""
from typing import Dict, Any, List, Optional
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.exceptions import ValidationError
from shared.database import get_db_context
from shared.logger import get_logger

logger = get_logger("bookkeeping_engine")


class BookkeepingEngine:
    def __init__(self):
        self._categorizer = None
        self._reconciler = None

    async def initialize(self):
        from .categorizer import TransactionCategorizer
        from .reconciler import BankReconciler
        self._categorizer = TransactionCategorizer()
        self._reconciler = BankReconciler()
        logger.info("BookkeepingEngine initialized")

    async def categorize_transaction(self, transaction_id: UUID) -> Dict[str, Any]:
        if not self._categorizer:
            raise RuntimeError("Engine not initialized")
        return await self._categorizer.categorize(transaction_id)

    async def auto_categorize_batch(self, user_id: UUID, limit: int = 100) -> Dict[str, Any]:
        if not self._categorizer:
            raise RuntimeError("Engine not initialized")
        return await self._categorizer.auto_categorize_batch(user_id, limit)

    async def reconcile_bank_statement(self, user_id: UUID, bank_account_id: UUID, statement_data: List[Dict[str, Any]]) -> Dict[str, Any]:
        if not self._reconciler:
            raise RuntimeError("Engine not initialized")
        return await self._reconciler.reconcile(user_id, bank_account_id, statement_data)

    async def import_transactions(self, user_id: UUID, source: str, transactions: List[Dict[str, Any]]) -> Dict[str, Any]:
        imported = 0
        failed = 0
        for txn in transactions:
            try:
                async with get_db_context() as session:
                    from sqlalchemy import text
                    query = text("""
                        INSERT INTO transactions (
                            id, user_id, account_id, type, amount, currency,
                            description, category, status, source, external_id,
                            transaction_date, created_at
                        ) VALUES (
                            gen_random_uuid(), :user_id, :account_id, :type, :amount, :currency,
                            :description, :category, 'pending', :source, :external_id,
                            :transaction_date, NOW()
                        ) ON CONFLICT (user_id, external_id) DO NOTHING
                    """)
                    await session.execute(query, {
                        "user_id": str(user_id),
                        "account_id": txn.get("account_id"),
                        "type": txn.get("type", "expense"),
                        "amount": str(txn.get("amount", 0)),
                        "currency": txn.get("currency", "USD"),
                        "description": txn.get("description", ""),
                        "category": txn.get("category", ""),
                        "source": source,
                        "external_id": txn.get("external_id", ""),
                        "transaction_date": txn.get("transaction_date", date.today()),
                    })
                    imported += 1
            except Exception as e:
                logger.warning(f"Failed to import transaction: {e}")
                failed += 1

        if imported > 0 and self._categorizer:
            await self._categorizer.auto_categorize_batch(user_id, imported)

        logger.info(f"Imported {imported} transactions, {failed} failed from {source}")
        return {"imported": imported, "failed": failed, "source": source}

    async def generate_bookkeeping_report(self, user_id: UUID, start: date, end: date) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT type, category, COUNT(*) as count, COALESCE(SUM(amount), 0) as total
                FROM transactions
                WHERE user_id = :user_id AND transaction_date BETWEEN :start AND :end
                AND status = 'completed'
                GROUP BY type, category
                ORDER BY type, total DESC
            """)
            result = await session.execute(query, {"user_id": str(user_id), "start": start, "end": end})
            categories = [dict(row) for row in result.mappings()]
            return {
                "period": {"start": start.isoformat(), "end": end.isoformat()},
                "categories": categories,
                "total_transactions": sum(c["count"] for c in categories),
            }

    async def shutdown(self):
        logger.info("BookkeepingEngine shut down")
