"""
ZANOX V18 Revenue Management Engine Core
"""
from typing import Dict, Any, List, Optional
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("revenue_engine")


class RevenueEngine:
    def __init__(self):
        self._tracker = None
        self._forecaster = None

    async def initialize(self):
        from .tracker import RevenueTracker
        from .forecaster import RevenueForecaster
        self._tracker = RevenueTracker()
        self._forecaster = RevenueForecaster()
        logger.info("RevenueEngine initialized")

    async def record_revenue(self, data: Dict[str, Any]) -> Dict[str, Any]:
        if not self._tracker:
            raise RuntimeError("Engine not initialized")
        return await self._tracker.record(data)

    async def get_revenue_summary(self, user_id: UUID, start: date, end: date) -> Dict[str, Any]:
        if not self._tracker:
            raise RuntimeError("Engine not initialized")
        return await self._tracker.get_summary(user_id, start, end)

    async def forecast_revenue(self, user_id: UUID, periods: int = 12) -> List[Dict[str, Any]]:
        if not self._forecaster:
            raise RuntimeError("Engine not initialized")
        return await self._forecaster.forecast(user_id, periods)

    async def get_revenue_by_source(self, user_id: UUID, start: date, end: date) -> List[Dict[str, Any]]:
        if not self._tracker:
            raise RuntimeError("Engine not initialized")
        return await self._tracker.by_source(user_id, start, end)

    async def calculate_mrr(self, user_id: UUID) -> Dict[str, Any]:
        if not self._tracker:
            raise RuntimeError("Engine not initialized")
        return await self._tracker.calculate_mrr(user_id)

    async def calculate_arr(self, user_id: UUID) -> Dict[str, Any]:
        mrr = await self.calculate_mrr(user_id)
        return {"arr": mrr.get("mrr", 0) * 12, "currency": mrr.get("currency", "USD")}

    async def shutdown(self):
        logger.info("RevenueEngine shut down")
