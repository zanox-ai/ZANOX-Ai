"""
ZANOX V18 Revenue Forecaster
Predicts future revenue using historical data and trend analysis.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date, timedelta
from uuid import UUID
import statistics

from shared.database import get_db_context
from shared.utils import calculate_growth_rate
from shared.logger import get_logger

logger = get_logger("revenue_forecaster")


class RevenueForecaster:
    async def forecast(self, user_id: UUID, periods: int = 12) -> List[Dict[str, Any]]:
        historical = await self._get_historical_monthly(user_id, periods=24)
        if len(historical) < 3:
            return [{"month": (date.today() + timedelta(days=i*30)).strftime("%Y-%m"),
                     "forecasted": 0, "confidence": 0, "method": "insufficient_data"}
                    for i in range(1, periods + 1)]

        amounts = [Decimal(str(h["total"])) for h in historical]
        avg = sum(amounts) / len(amounts)
        try:
            std_dev = statistics.stdev([float(a) for a in amounts])
        except statistics.StatisticsError:
            std_dev = 0

        growth_rates = []
        for i in range(1, len(amounts)):
            if amounts[i - 1] > 0:
                growth_rates.append(float((amounts[i] - amounts[i - 1]) / amounts[i - 1] * 100))
        avg_growth = sum(growth_rates) / len(growth_rates) if growth_rates else 0

        forecasts = []
        last_amount = amounts[-1]
        for i in range(1, periods + 1):
            forecasted = last_amount * (1 + Decimal(str(avg_growth)) / 100) ** i
            confidence = max(0, min(100, 100 - (std_dev / float(avg) * 10 * i) if avg > 0 else 50))
            forecast_date = date.today() + timedelta(days=i * 30)
            forecasts.append({
                "month": forecast_date.strftime("%Y-%m"),
                "forecasted": float(forecasted.quantize(Decimal("0.01"))),
                "confidence": round(confidence, 2),
                "method": "linear_trend",
                "growth_rate": round(avg_growth, 2),
            })

        logger.info(f"Generated {periods}-month revenue forecast for user {user_id}")
        return forecasts

    async def _get_historical_monthly(self, user_id: UUID, periods: int = 24) -> List[Dict[str, Any]]:
        from revenue_management.tracker import RevenueTracker
        tracker = RevenueTracker()
        today = date.today()
        historical = []
        for i in range(periods - 1, -1, -1):
            month_date = today - timedelta(days=i * 30)
            from shared.utils import get_month_start, get_month_end
            start = get_month_start(month_date)
            end = get_month_end(month_date)
            summary = await tracker.get_summary(user_id, start, end)
            historical.append({
                "month": start.strftime("%Y-%m"),
                "total": summary["total_revenue"],
            })
        return historical
