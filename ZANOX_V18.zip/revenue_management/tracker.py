"""
ZANOX V18 Revenue Tracker
Records and aggregates revenue data.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date, timedelta
from uuid import UUID

from shared.database import get_db_context
from shared.utils import calculate_growth_rate, get_month_start, get_month_end
from shared.logger import get_logger

logger = get_logger("revenue_tracker")


class RevenueTracker:
    async def record(self, data: Dict[str, Any]) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                INSERT INTO revenue_records (
                    id, user_id, source, amount, currency, category,
                    description, transaction_date, metadata, created_at
                ) VALUES (
                    gen_random_uuid(), :user_id, :source, :amount, :currency, :category,
                    :description, :transaction_date, :metadata, NOW()
                ) RETURNING id
            """)
            result = await session.execute(query, {
                "user_id": data.get("user_id"),
                "source": data.get("source", "unknown"),
                "amount": str(data.get("amount", 0)),
                "currency": data.get("currency", "USD"),
                "category": data.get("category", "general"),
                "description": data.get("description", ""),
                "transaction_date": data.get("transaction_date", date.today()),
                "metadata": str(data.get("metadata", {})),
            })
            record_id = str(result.fetchone()[0])
            logger.info(f"Recorded revenue: {record_id}")
            return {"id": record_id, "amount": data.get("amount"), "source": data.get("source")}

    async def get_summary(self, user_id: UUID, start: date, end: date) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT COALESCE(SUM(amount), 0) as total, COUNT(*) as count,
                       AVG(amount) as average, currency
                FROM revenue_records
                WHERE user_id = :user_id AND transaction_date BETWEEN :start AND :end
                GROUP BY currency
            """)
            result = await session.execute(query, {"user_id": str(user_id), "start": start, "end": end})
            rows = [dict(row) for row in result.mappings()]
            total = sum(Decimal(str(r["total"])) for r in rows)
            count = sum(r["count"] for r in rows)
            avg = total / count if count > 0 else Decimal("0")
            return {
                "period": {"start": start.isoformat(), "end": end.isoformat()},
                "total_revenue": float(total),
                "transaction_count": count,
                "average_transaction": float(avg.quantize(Decimal("0.01"))),
                "by_currency": rows,
            }

    async def by_source(self, user_id: UUID, start: date, end: date) -> List[Dict[str, Any]]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT source, COALESCE(SUM(amount), 0) as total, COUNT(*) as count
                FROM revenue_records
                WHERE user_id = :user_id AND transaction_date BETWEEN :start AND :end
                GROUP BY source
                ORDER BY total DESC
            """)
            result = await session.execute(query, {"user_id": str(user_id), "start": start, "end": end})
            return [dict(row) for row in result.mappings()]

    async def calculate_mrr(self, user_id: UUID) -> Dict[str, Any]:
        today = date.today()
        month_start = get_month_start(today)
        month_end = get_month_end(today)
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT COALESCE(SUM(amount), 0) as mrr, currency
                FROM revenue_records
                WHERE user_id = :user_id AND category = 'recurring'
                AND transaction_date BETWEEN :start AND :end
                GROUP BY currency
            """)
            result = await session.execute(query, {
                "user_id": str(user_id), "start": month_start, "end": month_end
            })
            rows = [dict(row) for row in result.mappings()]
            total_mrr = sum(Decimal(str(r["mrr"])) for r in rows)
            return {"mrr": float(total_mrr), "currency": rows[0]["currency"] if rows else "USD"}

    async def get_revenue_trend(self, user_id: UUID, months: int = 6) -> List[Dict[str, Any]]:
        today = date.today()
        trends = []
        for i in range(months - 1, -1, -1):
            month_date = today - timedelta(days=i * 30)
            start = get_month_start(month_date)
            end = get_month_end(month_date)
            summary = await self.get_summary(user_id, start, end)
            trends.append({
                "month": start.strftime("%Y-%m"),
                "total": summary["total_revenue"],
                "count": summary["transaction_count"],
            })
        return trends
