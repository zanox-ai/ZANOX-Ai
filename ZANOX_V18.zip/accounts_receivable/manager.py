"""
ZANOX V18 AR Manager
Manages accounts receivable lifecycle and aging.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date, timedelta
from uuid import UUID

from shared.database import get_db_context
from shared.exceptions import ValidationError
from shared.utils import generate_reference
from shared.logger import get_logger

logger = get_logger("ar_manager")


class ARManager:
    async def record(self, data: Dict[str, Any]) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                INSERT INTO accounts_receivable (
                    id, user_id, customer_id, invoice_id, amount, currency, due_date,
                    status, notes, created_at, updated_at
                ) VALUES (
                    gen_random_uuid(), :user_id, :customer_id, :invoice_id, :amount, :currency, :due_date,
                    'outstanding', :notes, NOW(), NOW()
                ) RETURNING id
            """)
            result = await session.execute(query, {
                "user_id": data["user_id"],
                "customer_id": data.get("customer_id"),
                "invoice_id": data.get("invoice_id"),
                "amount": str(data["amount"]),
                "currency": data.get("currency", "USD"),
                "due_date": data.get("due_date", date.today() + timedelta(days=30)),
                "notes": data.get("notes", ""),
            })
            ar_id = str(result.fetchone()[0])
            logger.info(f"Recorded AR: {ar_id}")
            return {"ar_id": ar_id, "amount": data["amount"], "status": "outstanding"}

    async def get_aging_report(self, user_id: UUID, as_of: date) -> Dict[str, Any]:
        buckets = {
            "current": (as_of - timedelta(days=0), as_of + timedelta(days=30)),
            "1_30": (as_of - timedelta(days=30), as_of - timedelta(days=1)),
            "31_60": (as_of - timedelta(days=60), as_of - timedelta(days=31)),
            "61_90": (as_of - timedelta(days=90), as_of - timedelta(days=61)),
            "over_90": (None, as_of - timedelta(days=91)),
        }
        report = {}
        total = Decimal("0")
        async with get_db_context() as session:
            from sqlalchemy import text
            for bucket_name, (start, end) in buckets.items():
                if start is None:
                    query = text("""
                        SELECT COALESCE(SUM(amount - COALESCE(paid_amount, 0)), 0) as total, COUNT(*) as count
                        FROM accounts_receivable
                        WHERE user_id = :user_id AND status = 'outstanding' AND due_date < :end
                    """)
                    result = await session.execute(query, {"user_id": str(user_id), "end": end})
                else:
                    query = text("""
                        SELECT COALESCE(SUM(amount - COALESCE(paid_amount, 0)), 0) as total, COUNT(*) as count
                        FROM accounts_receivable
                        WHERE user_id = :user_id AND status = 'outstanding'
                        AND due_date BETWEEN :start AND :end
                    """)
                    result = await session.execute(query, {"user_id": str(user_id), "start": start, "end": end})
                row = result.mappings().fetchone()
                report[bucket_name] = {
                    "total": float(row["total"]),
                    "count": row["count"],
                }
                total += Decimal(str(row["total"]))
        report["total_outstanding"] = float(total)
        report["as_of"] = as_of.isoformat()
        return report

    async def collect(self, receivable_id: UUID, payment_data: Dict[str, Any]) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                UPDATE accounts_receivable SET
                    paid_amount = COALESCE(paid_amount, 0) + :amount,
                    status = CASE WHEN (amount - COALESCE(paid_amount, 0) - :amount) <= 0 THEN 'paid' ELSE 'partial' END,
                    last_payment_date = :payment_date,
                    updated_at = NOW()
                WHERE id = :id RETURNING id, status, amount, paid_amount
            """)
            result = await session.execute(query, {
                "id": str(receivable_id),
                "amount": str(payment_data.get("amount", 0)),
                "payment_date": payment_data.get("payment_date", date.today()),
            })
            row = result.mappings().fetchone()
            if not row:
                raise ValidationError("Receivable not found")
            logger.info(f"Collected payment for AR {receivable_id}")
            return dict(row)

    async def write_off(self, receivable_id: UUID, reason: str) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                UPDATE accounts_receivable SET status = 'written_off', write_off_reason = :reason,
                write_off_date = :write_off_date, updated_at = NOW()
                WHERE id = :id RETURNING id, status, amount
            """)
            result = await session.execute(query, {
                "id": str(receivable_id),
                "reason": reason,
                "write_off_date": date.today(),
            })
            row = result.mappings().fetchone()
            if not row:
                raise ValidationError("Receivable not found")
            logger.info(f"Wrote off AR {receivable_id}: {reason}")
            return dict(row)
