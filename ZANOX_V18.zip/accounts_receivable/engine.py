"""
ZANOX V18 Accounts Receivable Engine Core
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("ar_engine")


class AccountsReceivableEngine:
    def __init__(self):
        self._manager = None

    async def initialize(self):
        from .manager import ARManager
        self._manager = ARManager()
        logger.info("AccountsReceivableEngine initialized")

    async def record_receivable(self, data: Dict[str, Any]) -> Dict[str, Any]:
        if not self._manager:
            raise RuntimeError("Engine not initialized")
        return await self._manager.record(data)

    async def get_aging_report(self, user_id: UUID, as_of: date) -> Dict[str, Any]:
        if not self._manager:
            raise RuntimeError("Engine not initialized")
        return await self._manager.get_aging_report(user_id, as_of)

    async def collect_payment(self, receivable_id: UUID, payment_data: Dict[str, Any]) -> Dict[str, Any]:
        if not self._manager:
            raise RuntimeError("Engine not initialized")
        return await self._manager.collect(receivable_id, payment_data)

    async def write_off(self, receivable_id: UUID, reason: str) -> Dict[str, Any]:
        if not self._manager:
            raise RuntimeError("Engine not initialized")
        return await self._manager.write_off(receivable_id, reason)

    async def shutdown(self):
        logger.info("AccountsReceivableEngine shut down")
