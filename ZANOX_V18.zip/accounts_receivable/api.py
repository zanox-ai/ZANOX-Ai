"""
ZANOX V18 Accounts Receivable API
"""
from fastapi import APIRouter
from uuid import UUID
from datetime import date

from .engine import AccountsReceivableEngine

router = APIRouter(prefix="/accounts-receivable", tags=["accounts-receivable"])
engine = AccountsReceivableEngine()


@router.post("/")
async def record_receivable(data: dict):
    return await engine.record_receivable(data)


@router.get("/aging/{user_id}")
async def get_aging_report(user_id: UUID, as_of: date = date.today()):
    return await engine.get_aging_report(user_id, as_of)


@router.post("/{receivable_id}/collect")
async def collect_payment(receivable_id: UUID, payment: dict):
    return await engine.collect_payment(receivable_id, payment)


@router.post("/{receivable_id}/write-off")
async def write_off(receivable_id: UUID, reason: str):
    return await engine.write_off(receivable_id, reason)
