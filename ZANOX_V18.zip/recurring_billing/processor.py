"""
ZANOX V18 Billing Processor
Processes due recurring billing events.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.database import get_db_context
from shared.logger import get_logger

logger = get_logger("billing_processor")


class BillingProcessor:
    async def process_due(self, as_of: date) -> List[Dict[str, Any]]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT bs.*, s.name as subscription_name, s.payment_method
                FROM billing_schedules bs
                JOIN subscriptions s ON s.id = bs.subscription_id
                WHERE bs.status = 'active' AND bs.next_billing_date <= :as_of
            """)
            result = await session.execute(query, {"as_of": as_of})
            schedules = [dict(row) for row in result.mappings()]

        processed = []
        for schedule in schedules:
            try:
                await self._process_single(schedule)
                processed.append({"schedule_id": schedule["id"], "status": "success", "amount": float(schedule["amount"])})
            except Exception as e:
                processed.append({"schedule_id": schedule["id"], "status": "failed", "error": str(e)})
        return processed

    async def _process_single(self, schedule: Dict[str, Any]) -> None:
        async with get_db_context() as session:
            from sqlalchemy import text
            insert_query = text("""
                INSERT INTO billing_events (
                    id, schedule_id, user_id, amount, currency, status, processed_at, created_at
                ) VALUES (gen_random_uuid(), :schedule_id, :user_id, :amount, :currency, 'completed', NOW(), NOW())
            """)
            await session.execute(insert_query, {
                "schedule_id": schedule["id"],
                "user_id": schedule["user_id"],
                "amount": str(schedule["amount"]),
                "currency": schedule["currency"],
            })

            update_query = text("""
                UPDATE billing_schedules SET next_billing_date =
                CASE frequency
                    WHEN 'daily' THEN next_billing_date + INTERVAL '1 day'
                    WHEN 'weekly' THEN next_billing_date + INTERVAL '1 week'
                    WHEN 'monthly' THEN next_billing_date + INTERVAL '1 month'
                    WHEN 'quarterly' THEN next_billing_date + INTERVAL '3 months'
                    WHEN 'annually' THEN next_billing_date + INTERVAL '1 year'
                    ELSE next_billing_date + INTERVAL '1 month'
                END,
                updated_at = NOW()
                WHERE id = :id
            """)
            await session.execute(update_query, {"id": schedule["id"]})
            logger.info(f"Processed billing for schedule {schedule['id']}")
