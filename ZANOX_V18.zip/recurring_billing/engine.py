"""
ZANOX V18 Recurring Billing Engine Core
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("recurring_billing_engine")


class RecurringBillingEngine:
    def __init__(self):
        self._scheduler = None
        self._processor = None

    async def initialize(self):
        from .scheduler import BillingScheduler
        from .processor import BillingProcessor
        self._scheduler = BillingScheduler()
        self._processor = BillingProcessor()
        logger.info("RecurringBillingEngine initialized")

    async def schedule_billing(self, data: Dict[str, Any]) -> Dict[str, Any]:
        if not self._scheduler:
            raise RuntimeError("Engine not initialized")
        return await self._scheduler.schedule(data)

    async def process_due_billings(self, date: date) -> List[Dict[str, Any]]:
        if not self._processor:
            raise RuntimeError("Engine not initialized")
        return await self._processor.process_due(date)

    async def shutdown(self):
        logger.info("RecurringBillingEngine shut down")
