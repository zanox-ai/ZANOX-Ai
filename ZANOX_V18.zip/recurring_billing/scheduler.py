"""
ZANOX V18 Billing Scheduler
Schedules recurring billing events.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date, datetime, timedelta
from uuid import UUID

from shared.database import get_db_context
from shared.exceptions import ValidationError
from shared.logger import get_logger

logger = get_logger("billing_scheduler")


class BillingScheduler:
    async def schedule(self, data: Dict[str, Any]) -> Dict[str, Any]:
        required = ["user_id", "subscription_id", "amount", "currency", "frequency", "start_date"]
        for field in required:
            if field not in data:
                raise ValidationError(f"Missing required field: {field}")

        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                INSERT INTO billing_schedules (
                    id, user_id, subscription_id, amount, currency, frequency,
                    start_date, end_date, next_billing_date, status, created_at
                ) VALUES (
                    gen_random_uuid(), :user_id, :subscription_id, :amount, :currency, :frequency,
                    :start_date, :end_date, :start_date, 'active', NOW()
                ) RETURNING id
            """)
            result = await session.execute(query, {
                "user_id": data["user_id"],
                "subscription_id": data["subscription_id"],
                "amount": str(data["amount"]),
                "currency": data["currency"],
                "frequency": data["frequency"],
                "start_date": data["start_date"],
                "end_date": data.get("end_date"),
            })
            schedule_id = str(result.fetchone()[0])
            logger.info(f"Scheduled billing: {schedule_id}")
            return {"schedule_id": schedule_id, "next_billing": data["start_date"].isoformat()}

    async def get_upcoming(self, user_id: UUID, days: int = 30) -> List[Dict[str, Any]]:
        end_date = date.today() + timedelta(days=days)
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT bs.*, s.name as subscription_name
                FROM billing_schedules bs
                JOIN subscriptions s ON s.id = bs.subscription_id
                WHERE bs.user_id = :user_id AND bs.status = 'active'
                AND bs.next_billing_date <= :end_date
                ORDER BY bs.next_billing_date
            """)
            result = await session.execute(query, {"user_id": str(user_id), "end_date": end_date})
            return [dict(row) for row in result.mappings()]
