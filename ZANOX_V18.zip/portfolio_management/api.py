"""
ZANOX V18 Portfolio Management API
"""
from fastapi import APIRouter
from uuid import UUID
from datetime import date

from .engine import PortfolioEngine

router = APIRouter(prefix="/portfolios", tags=["portfolios"])
engine = PortfolioEngine()


@router.post("/")
async def create_portfolio(data: dict):
    return await engine.create_portfolio(data)


@router.get("/{portfolio_id}")
async def get_portfolio(portfolio_id: UUID):
    return await engine.get_portfolio(portfolio_id)


@router.post("/{portfolio_id}/holdings")
async def add_holding(portfolio_id: UUID, data: dict):
    return await engine.add_holding(portfolio_id, data)


@router.post("/{portfolio_id}/rebalance")
async def rebalance_portfolio(portfolio_id: UUID, allocations: dict):
    return await engine.rebalance(portfolio_id, allocations)


@router.get("/{portfolio_id}/performance")
async def get_performance(portfolio_id: UUID, start: date, end: date):
    return await engine.get_performance(portfolio_id, start, end)
