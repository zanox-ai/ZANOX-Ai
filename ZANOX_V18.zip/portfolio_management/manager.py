"""
ZANOX V18 Portfolio Manager
Manages portfolio composition and rebalancing.
"""
from typing import Dict, Any, List, Optional
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.database import get_db_context
from shared.exceptions import ValidationError
from shared.utils import calculate_growth_rate, calculate_roi
from shared.logger import get_logger

logger = get_logger("portfolio_manager")


class PortfolioManager:
    async def create(self, data: Dict[str, Any]) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                INSERT INTO portfolios (
                    id, user_id, name, description, strategy, risk_profile, currency,
                    total_value, target_allocations, created_at, updated_at
                ) VALUES (
                    gen_random_uuid(), :user_id, :name, :description, :strategy, :risk_profile, :currency,
                    :total_value, :target_allocations, NOW(), NOW()
                ) RETURNING id
            """)
            result = await session.execute(query, {
                "user_id": data["user_id"],
                "name": data["name"],
                "description": data.get("description", ""),
                "strategy": data.get("strategy", "balanced"),
                "risk_profile": data.get("risk_profile", "moderate"),
                "currency": data.get("currency", "USD"),
                "total_value": str(data.get("total_value", 0)),
                "target_allocations": str(data.get("target_allocations", {})),
            })
            portfolio_id = str(result.fetchone()[0])
            logger.info(f"Created portfolio: {portfolio_id}")
            return {"portfolio_id": portfolio_id, "name": data["name"]}

    async def get(self, portfolio_id: UUID) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("SELECT * FROM portfolios WHERE id = :id")
            result = await session.execute(query, {"id": str(portfolio_id)})
            row = result.mappings().fetchone()
            if not row:
                raise ValidationError("Portfolio not found")
            portfolio = dict(row)
            holding_query = text("SELECT * FROM portfolio_holdings WHERE portfolio_id = :id")
            holding_result = await session.execute(holding_query, {"id": str(portfolio_id)})
            portfolio["holdings"] = [dict(r) for r in holding_result.mappings()]
            return portfolio

    async def add_holding(self, portfolio_id: UUID, data: Dict[str, Any]) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                INSERT INTO portfolio_holdings (
                    id, portfolio_id, symbol, asset_type, quantity, purchase_price,
                    current_price, currency, purchase_date, created_at, updated_at
                ) VALUES (
                    gen_random_uuid(), :portfolio_id, :symbol, :asset_type, :quantity, :purchase_price,
                    :current_price, :currency, :purchase_date, NOW(), NOW()
                ) RETURNING id
            """)
            result = await session.execute(query, {
                "portfolio_id": str(portfolio_id),
                "symbol": data["symbol"],
                "asset_type": data.get("asset_type", "stock"),
                "quantity": str(data["quantity"]),
                "purchase_price": str(data["purchase_price"]),
                "current_price": str(data.get("current_price", data["purchase_price"])),
                "currency": data.get("currency", "USD"),
                "purchase_date": data.get("purchase_date", date.today()),
            })
            holding_id = str(result.fetchone()[0])
            logger.info(f"Added holding: {holding_id} to portfolio {portfolio_id}")
            return {"holding_id": holding_id, "symbol": data["symbol"], "quantity": data["quantity"]}

    async def rebalance(self, portfolio_id: UUID, target_allocations: Dict[str, Decimal]) -> Dict[str, Any]:
        portfolio = await self.get(portfolio_id)
        total_value = Decimal(str(portfolio["total_value"]))
        holdings = portfolio.get("holdings", [])
        rebalance_actions = []
        for holding in holdings:
            symbol = holding["symbol"]
            target_pct = target_allocations.get(symbol, Decimal("0"))
            current_value = Decimal(str(holding["quantity"])) * Decimal(str(holding["current_price"]))
            current_pct = current_value / total_value * 100 if total_value > 0 else Decimal("0")
            target_value = total_value * target_pct / 100
            diff = target_value - current_value
            if abs(diff) > total_value * Decimal("0.05"):
                rebalance_actions.append({
                    "symbol": symbol,
                    "current_pct": float(current_pct.quantize(Decimal("0.01"))),
                    "target_pct": float(target_pct),
                    "action": "buy" if diff > 0 else "sell",
                    "amount": float(abs(diff).quantize(Decimal("0.01"))),
                })
        return {
            "portfolio_id": str(portfolio_id),
            "rebalance_actions": rebalance_actions,
            "action_count": len(rebalance_actions),
        }

    async def get_performance(self, portfolio_id: UUID, start: date, end: date) -> Dict[str, Any]:
        portfolio = await self.get(portfolio_id)
        total_cost = Decimal("0")
        total_value = Decimal("0")
        for h in portfolio.get("holdings", []):
            cost = Decimal(str(h["quantity"])) * Decimal(str(h["purchase_price"]))
            value = Decimal(str(h["quantity"])) * Decimal(str(h["current_price"]))
            total_cost += cost
            total_value += value
        gain = total_value - total_cost
        roi = calculate_roi(total_value, total_cost)
        return {
            "portfolio_id": str(portfolio_id),
            "period": {"start": start.isoformat(), "end": end.isoformat()},
            "total_cost": float(total_cost),
            "total_value": float(total_value),
            "unrealized_gain": float(gain),
            "roi_pct": float(roi),
        }
