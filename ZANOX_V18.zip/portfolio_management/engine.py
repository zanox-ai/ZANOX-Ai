"""
ZANOX V18 Portfolio Management Engine Core
"""
from typing import Dict, Any, List, Optional
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("portfolio_engine")


class PortfolioEngine:
    def __init__(self):
        self._manager = None

    async def initialize(self):
        from .manager import PortfolioManager
        self._manager = PortfolioManager()
        logger.info("PortfolioEngine initialized")

    async def create_portfolio(self, data: Dict[str, Any]) -> Dict[str, Any]:
        if not self._manager:
            raise RuntimeError("Engine not initialized")
        return await self._manager.create(data)

    async def get_portfolio(self, portfolio_id: UUID) -> Dict[str, Any]:
        if not self._manager:
            raise RuntimeError("Engine not initialized")
        return await self._manager.get(portfolio_id)

    async def add_holding(self, portfolio_id: UUID, data: Dict[str, Any]) -> Dict[str, Any]:
        if not self._manager:
            raise RuntimeError("Engine not initialized")
        return await self._manager.add_holding(portfolio_id, data)

    async def rebalance(self, portfolio_id: UUID, target_allocations: Dict[str, Decimal]) -> Dict[str, Any]:
        if not self._manager:
            raise RuntimeError("Engine not initialized")
        return await self._manager.rebalance(portfolio_id, target_allocations)

    async def get_performance(self, portfolio_id: UUID, start: date, end: date) -> Dict[str, Any]:
        if not self._manager:
            raise RuntimeError("Engine not initialized")
        return await self._manager.get_performance(portfolio_id, start, end)

    async def shutdown(self):
        logger.info("PortfolioEngine shut down")
