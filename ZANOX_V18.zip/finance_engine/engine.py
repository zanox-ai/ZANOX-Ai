"""
ZANOX V18 Finance Engine Core
Orchestrates all financial computations and transaction flows.
"""
from decimal import Decimal
from typing import List, Dict, Any, Optional
from datetime import datetime, date
from uuid import UUID

from shared.models import Money, TransactionType, TransactionStatus, FinancialEntity
from shared.exceptions import InvalidTransactionError, InsufficientFundsError
from shared.utils import generate_reference, round_decimal
from shared.logger import get_logger

logger = get_logger("finance_engine")


class FinanceEngine:
    def __init__(self, db_session=None, cache=None, event_bus=None):
        self.db = db_session
        self.cache = cache
        self.event_bus = event_bus
        self._calculator = None
        self._processor = None

    async def initialize(self):
        from .calculator import FinancialCalculator
        from .processor import TransactionProcessor
        self._calculator = FinancialCalculator()
        self._processor = TransactionProcessor(self.db, self.event_bus)
        logger.info("FinanceEngine initialized")

    async def process_transaction(self, transaction_data: Dict[str, Any]) -> Dict[str, Any]:
        if not self._processor:
            raise InvalidTransactionError("Engine not initialized")
        result = await self._processor.process(transaction_data)
        return result

    async def calculate_net_worth(self, user_id: UUID, as_of: Optional[date] = None) -> Money:
        if not self._calculator:
            raise InvalidTransactionError("Engine not initialized")
        return await self._calculator.calculate_net_worth(user_id, as_of)

    async def calculate_cash_flow(
        self, user_id: UUID, start: date, end: date
    ) -> Dict[str, Money]:
        if not self._calculator:
            raise InvalidTransactionError("Engine not initialized")
        return await self._calculator.calculate_cash_flow(user_id, start, end)

    async def reconcile_accounts(self, user_id: UUID) -> Dict[str, Any]:
        if not self._processor:
            raise InvalidTransactionError("Engine not initialized")
        return await self._processor.reconcile(user_id)

    async def get_financial_health(self, user_id: UUID) -> Dict[str, Any]:
        if not self._calculator:
            raise InvalidTransactionError("Engine not initialized")
        return await self._calculator.get_financial_health(user_id)

    async def shutdown(self):
        logger.info("FinanceEngine shutting down")
