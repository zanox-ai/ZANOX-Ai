"""
ZANOX V18 Transaction Processor
Handles transaction validation, execution, and ledger updates.
"""
from decimal import Decimal
from typing import Dict, Any, Optional
from datetime import datetime
from uuid import UUID

from shared.models import TransactionType, TransactionStatus, Money
from shared.exceptions import InvalidTransactionError, InsufficientFundsError, DuplicateEntryError
from shared.utils import generate_reference, round_decimal
from shared.kafka_client import produce_event
from shared.logger import get_logger

logger = get_logger("transaction_processor")


class TransactionProcessor:
    def __init__(self, db_session=None, event_bus=None):
        self.db = db_session
        self.event_bus = event_bus

    async def process(self, transaction_data: Dict[str, Any]) -> Dict[str, Any]:
        self._validate_transaction(transaction_data)
        reference = generate_reference("TXN")
        transaction_data["reference"] = reference
        transaction_data["status"] = TransactionStatus.PENDING.value
        transaction_data["created_at"] = datetime.utcnow().isoformat()

        if self.db:
            from sqlalchemy import text
            query = text("""
                INSERT INTO transactions (id, user_id, account_id, type, amount, currency,
                description, category, status, reference, transaction_date, metadata, created_at)
                VALUES (gen_random_uuid(), :user_id, :account_id, :type, :amount, :currency,
                :description, :category, :status, :reference, :transaction_date, :metadata, NOW())
                RETURNING id
            """)
            result = await self.db.execute(query, {
                "user_id": transaction_data.get("user_id"),
                "account_id": transaction_data.get("account_id"),
                "type": transaction_data.get("type"),
                "amount": str(transaction_data.get("amount", 0)),
                "currency": transaction_data.get("currency", "USD"),
                "description": transaction_data.get("description", ""),
                "category": transaction_data.get("category", ""),
                "status": transaction_data.get("status"),
                "reference": reference,
                "transaction_date": transaction_data.get("transaction_date", datetime.utcnow().date()),
                "metadata": str(transaction_data.get("metadata", {})),
            })
            row = result.fetchone()
            transaction_data["id"] = str(row[0]) if row else None

        await self._update_account_balance(transaction_data)
        await self._emit_event("zanox.finance.transactions", {
            "event": "transaction_created",
            "reference": reference,
            "data": transaction_data,
        })

        transaction_data["status"] = TransactionStatus.COMPLETED.value
        logger.info(f"Transaction processed: {reference}")
        return transaction_data

    def _validate_transaction(self, data: Dict[str, Any]) -> None:
        required = ["user_id", "amount", "type"]
        for field in required:
            if field not in data or data[field] is None:
                raise InvalidTransactionError(f"Missing required field: {field}")
        try:
            amount = Decimal(str(data["amount"]))
            if amount <= 0:
                raise InvalidTransactionError("Amount must be positive")
        except (ValueError, TypeError):
            raise InvalidTransactionError("Invalid amount format")
        if data.get("type") not in [t.value for t in TransactionType]:
            raise InvalidTransactionError(f"Invalid transaction type: {data.get('type')}")

    async def _update_account_balance(self, transaction_data: Dict[str, Any]) -> None:
        if not self.db or not transaction_data.get("account_id"):
            return
        from sqlalchemy import text
        amount = Decimal(str(transaction_data["amount"]))
        tx_type = transaction_data.get("type")
        if tx_type in [TransactionType.EXPENSE.value, TransactionType.FEE.value]:
            amount = -amount
        query = text("""
            UPDATE accounts SET balance = balance + :amount, updated_at = NOW()
            WHERE id = :account_id
        """)
        await self.db.execute(query, {
            "amount": amount,
            "account_id": transaction_data["account_id"],
        })

    async def _emit_event(self, topic: str, message: Dict[str, Any]) -> None:
        try:
            produce_event(topic, message)
        except Exception as e:
            logger.warning(f"Failed to emit event: {e}")

    async def reverse_transaction(self, transaction_id: UUID, reason: str) -> Dict[str, Any]:
        if not self.db:
            raise InvalidTransactionError("Database not available")
        from sqlalchemy import text
        query = text("""
            UPDATE transactions SET status = 'cancelled', metadata = jsonb_set(
                COALESCE(metadata, '{}'::jsonb), '{reversal_reason}', :reason
            ), updated_at = NOW()
            WHERE id = :transaction_id
            RETURNING *
        """)
        result = await self.db.execute(query, {
            "transaction_id": str(transaction_id),
            "reason": f'"{reason}"',
        })
        row = result.fetchone()
        if not row:
            raise InvalidTransactionError("Transaction not found")
        return dict(row._mapping)

    async def reconcile(self, user_id: UUID) -> Dict[str, Any]:
        if not self.db:
            return {"status": "skipped", "reason": "no_database"}
        from sqlalchemy import text
        query = text("""
            SELECT a.id as account_id, a.balance as expected_balance,
                   COALESCE(SUM(CASE WHEN t.type IN ('income', 'refund', 'dividend', 'interest') THEN t.amount
                                     WHEN t.type IN ('expense', 'fee', 'investment') THEN -t.amount
                                     ELSE 0 END), 0) as computed_balance
            FROM accounts a
            LEFT JOIN transactions t ON t.account_id = a.id AND t.status = 'completed'
            WHERE a.user_id = :user_id
            GROUP BY a.id, a.balance
        """)
        result = await self.db.execute(query, {"user_id": str(user_id)})
        discrepancies = []
        for row in result.mappings():
            expected = Decimal(str(row["expected_balance"]))
            computed = Decimal(str(row["computed_balance"]))
            if expected != computed:
                discrepancies.append({
                    "account_id": str(row["account_id"]),
                    "expected": float(expected),
                    "computed": float(computed),
                    "difference": float(expected - computed),
                })
        return {
            "status": "completed",
            "discrepancies_count": len(discrepancies),
            "discrepancies": discrepancies,
            "reconciled": len(discrepancies) == 0,
        }
