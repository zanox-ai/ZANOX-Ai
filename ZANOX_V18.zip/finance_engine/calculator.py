"""
ZANOX V18 Financial Calculator
Comprehensive financial computation utilities.
"""
from decimal import Decimal
from typing import Dict, Any, Optional, List
from datetime import date, timedelta
from uuid import UUID

from shared.models import Money, Currency, TransactionType
from shared.utils import (
    calculate_percentage, calculate_growth_rate, calculate_cagr,
    calculate_compound_interest, safe_divide, get_month_start, get_month_end,
    get_quarter_start, get_quarter_end, get_fiscal_year_start, get_fiscal_year_end
)
from shared.database import get_db_context
from shared.logger import get_logger

logger = get_logger("financial_calculator")


class FinancialCalculator:
    def __init__(self):
        self._cache = {}

    async def calculate_net_worth(self, user_id: UUID, as_of: Optional[date] = None) -> Money:
        if as_of is None:
            as_of = date.today()
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT COALESCE(SUM(CASE WHEN account_type = 'asset' THEN balance ELSE -balance END), 0) as net_worth
                FROM accounts WHERE user_id = :user_id AND created_at <= :as_of
            """)
            result = await session.execute(query, {"user_id": str(user_id), "as_of": as_of})
            row = result.fetchone()
            net_worth = Decimal(str(row[0])) if row and row[0] else Decimal("0")
            return Money(amount=net_worth, currency=Currency.USD)

    async def calculate_cash_flow(
        self, user_id: UUID, start: date, end: date
    ) -> Dict[str, Money]:
        async with get_db_context() as session:
            from sqlalchemy import text
            income_query = text("""
                SELECT COALESCE(SUM(amount), 0) as total
                FROM transactions
                WHERE user_id = :user_id AND type = 'income'
                AND transaction_date BETWEEN :start AND :end
                AND status = 'completed'
            """)
            expense_query = text("""
                SELECT COALESCE(SUM(amount), 0) as total
                FROM transactions
                WHERE user_id = :user_id AND type = 'expense'
                AND transaction_date BETWEEN :start AND :end
                AND status = 'completed'
            """)
            income_result = await session.execute(income_query, {
                "user_id": str(user_id), "start": start, "end": end
            })
            expense_result = await session.execute(expense_query, {
                "user_id": str(user_id), "start": start, "end": end
            })
            income = Decimal(str(income_result.fetchone()[0]))
            expenses = Decimal(str(expense_result.fetchone()[0]))
            return {
                "income": Money(amount=income, currency=Currency.USD),
                "expenses": Money(amount=expenses, currency=Currency.USD),
                "net_cash_flow": Money(amount=income - expenses, currency=Currency.USD),
            }

    async def calculate_savings_rate(self, user_id: UUID, period: str = "monthly") -> Decimal:
        from datetime import date
        today = date.today()
        if period == "monthly":
            start = get_month_start(today)
            end = get_month_end(today)
        elif period == "quarterly":
            start = get_quarter_start(today)
            end = get_quarter_end(today)
        elif period == "yearly":
            start = get_fiscal_year_start(today.year)
            end = get_fiscal_year_end(today.year)
        else:
            start = today - timedelta(days=30)
            end = today

        cash_flow = await self.calculate_cash_flow(user_id, start, end)
        income = cash_flow["income"].amount
        net = cash_flow["net_cash_flow"].amount
        return safe_divide(net, income, Decimal("0")) * 100

    async def calculate_debt_to_income_ratio(self, user_id: UUID) -> Decimal:
        async with get_db_context() as session:
            from sqlalchemy import text
            debt_query = text("""
                SELECT COALESCE(SUM(balance), 0) as total_debt
                FROM accounts WHERE user_id = :user_id AND account_type = 'liability'
            """)
            income_query = text("""
                SELECT COALESCE(SUM(amount), 0) as annual_income
                FROM transactions WHERE user_id = :user_id AND type = 'income'
                AND transaction_date >= CURRENT_DATE - INTERVAL '1 year'
                AND status = 'completed'
            """)
            debt_result = await session.execute(debt_query, {"user_id": str(user_id)})
            income_result = await session.execute(income_query, {"user_id": str(user_id)})
            debt = Decimal(str(debt_result.fetchone()[0]))
            income = Decimal(str(income_result.fetchone()[0]))
            return safe_divide(debt, income, Decimal("0")) * 100

    async def get_financial_health(self, user_id: UUID) -> Dict[str, Any]:
        net_worth = await self.calculate_net_worth(user_id)
        savings_rate = await self.calculate_savings_rate(user_id, "monthly")
        dti = await self.calculate_debt_to_income_ratio(user_id)

        score = Decimal("50")
        if net_worth.amount > 0:
            score += Decimal("20")
        if savings_rate > 20:
            score += Decimal("15")
        elif savings_rate > 10:
            score += Decimal("10")
        elif savings_rate > 5:
            score += Decimal("5")
        if dti < 20:
            score += Decimal("15")
        elif dti < 36:
            score += Decimal("10")
        elif dti < 43:
            score += Decimal("5")

        score = min(score, Decimal("100"))
        category = "excellent" if score >= 80 else "good" if score >= 60 else "fair" if score >= 40 else "poor"

        recommendations = []
        if savings_rate < 10:
            recommendations.append("Increase your savings rate to at least 10% of income")
        if dti > 36:
            recommendations.append("Reduce debt-to-income ratio below 36%")
        if net_worth.amount < 0:
            recommendations.append("Focus on building positive net worth")

        return {
            "score": float(score),
            "category": category,
            "net_worth": net_worth.to_dict(),
            "savings_rate": float(savings_rate),
            "debt_to_income_ratio": float(dti),
            "recommendations": recommendations,
        }

    def calculate_loan_payment(
        self, principal: Decimal, annual_rate: Decimal, years: int
    ) -> Decimal:
        monthly_rate = annual_rate / 12 / 100
        num_payments = years * 12
        if monthly_rate == 0:
            return principal / num_payments
        payment = principal * (monthly_rate * (1 + monthly_rate) ** num_payments) /                   ((1 + monthly_rate) ** num_payments - 1)
        return payment.quantize(Decimal("0.01"))

    def calculate_roi(self, gain: Decimal, cost: Decimal) -> Decimal:
        return safe_divide((gain - cost), cost, Decimal("0")) * 100

    def calculate_npv(self, initial_investment: Decimal, cash_flows: List[Decimal], discount_rate: Decimal) -> Decimal:
        npv = -initial_investment
        for i, cf in enumerate(cash_flows, 1):
            npv += cf / ((1 + discount_rate / 100) ** i)
        return npv

    def calculate_irr(self, initial_investment: Decimal, cash_flows: List[Decimal]) -> Optional[Decimal]:
        from decimal import Decimal, getcontext
        getcontext().prec = 28
        rate = Decimal("0.1")
        for _ in range(100):
            npv = self.calculate_npv(initial_investment, cash_flows, rate * 100)
            if abs(npv) < Decimal("0.01"):
                return rate * 100
            derivative = sum(-i * cf / ((1 + rate) ** (i + 1)) for i, cf in enumerate(cash_flows, 1))
            if derivative == 0:
                break
            rate = rate - npv / derivative
        return None
