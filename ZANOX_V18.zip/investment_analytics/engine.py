"""
ZANOX V18 Investment Analytics Engine Core
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("investment_analytics_engine")


class InvestmentAnalyticsEngine:
    def __init__(self):
        self._analyzer = None

    async def initialize(self):
        from .analyzer import InvestmentAnalyzer
        self._analyzer = InvestmentAnalyzer()
        logger.info("InvestmentAnalyticsEngine initialized")

    async def analyze_portfolio(self, user_id: UUID) -> Dict[str, Any]:
        if not self._analyzer:
            raise RuntimeError("Engine not initialized")
        return await self._analyzer.analyze(user_id)

    async def calculate_risk_metrics(self, user_id: UUID) -> Dict[str, Any]:
        if not self._analyzer:
            raise RuntimeError("Engine not initialized")
        return await self._analyzer.risk_metrics(user_id)

    async def get_correlation_matrix(self, user_id: UUID) -> Dict[str, Any]:
        if not self._analyzer:
            raise RuntimeError("Engine not initialized")
        return await self._analyzer.correlations(user_id)

    async def shutdown(self):
        logger.info("InvestmentAnalyticsEngine shut down")
