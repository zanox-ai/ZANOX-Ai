"""
ZANOX V18 Investment Analytics API
"""
from fastapi import APIRouter
from uuid import UUID

from .engine import InvestmentAnalyticsEngine

router = APIRouter(prefix="/investment-analytics", tags=["investment-analytics"])
engine = InvestmentAnalyticsEngine()


@router.get("/portfolio/{user_id}")
async def analyze_portfolio(user_id: UUID):
    return await engine.analyze_portfolio(user_id)


@router.get("/risk/{user_id}")
async def calculate_risk(user_id: UUID):
    return await engine.calculate_risk_metrics(user_id)


@router.get("/correlations/{user_id}")
async def get_correlations(user_id: UUID):
    return await engine.get_correlation_matrix(user_id)
