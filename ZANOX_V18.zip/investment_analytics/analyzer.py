"""
ZANOX V18 Investment Analyzer
Calculates portfolio analytics and risk metrics.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date, timedelta
from uuid import UUID
import statistics

from shared.database import get_db_context
from shared.utils import calculate_roi, safe_divide
from shared.logger import get_logger

logger = get_logger("investment_analyzer")


class InvestmentAnalyzer:
    async def analyze(self, user_id: UUID) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT symbol, action, quantity, price, total_amount, trade_date
                FROM investment_trades
                WHERE user_id = :user_id AND status = 'completed'
                ORDER BY trade_date
            """)
            result = await session.execute(query, {"user_id": str(user_id)})
            trades = [dict(row) for row in result.mappings()]

        if not trades:
            return {"user_id": str(user_id), "trades": 0, "message": "No trades found"}

        by_symbol = {}
        for t in trades:
            sym = t["symbol"]
            if sym not in by_symbol:
                by_symbol[sym] = []
            by_symbol[sym].append(t)

        symbol_analysis = []
        for sym, sym_trades in by_symbol.items():
            buys = [t for t in sym_trades if t["action"] == "buy"]
            sells = [t for t in sym_trades if t["action"] == "sell"]
            total_bought = sum(Decimal(str(t["total_amount"])) for t in buys)
            total_sold = sum(Decimal(str(t["total_amount"])) for t in sells)
            net_quantity = sum(Decimal(str(t["quantity"])) for t in buys) - sum(Decimal(str(t["quantity"])) for t in sells)
            avg_buy = safe_divide(total_bought, sum(Decimal(str(t["quantity"])) for t in buys), Decimal("0"))
            symbol_analysis.append({
                "symbol": sym,
                "total_bought": float(total_bought),
                "total_sold": float(total_sold),
                "net_quantity": float(net_quantity),
                "avg_buy_price": float(avg_buy.quantize(Decimal("0.01"))),
                "trade_count": len(sym_trades),
            })

        return {
            "user_id": str(user_id),
            "total_trades": len(trades),
            "symbols": list(by_symbol.keys()),
            "symbol_analysis": symbol_analysis,
        }

    async def risk_metrics(self, user_id: UUID) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT total_amount, trade_date
                FROM investment_trades
                WHERE user_id = :user_id AND action = 'buy' AND status = 'completed'
                ORDER BY trade_date
            """)
            result = await session.execute(query, {"user_id": str(user_id)})
            amounts = [float(row["total_amount"]) for row in result.mappings()]

        if len(amounts) < 2:
            return {"user_id": str(user_id), "message": "Insufficient data for risk metrics"}

        try:
            mean = statistics.mean(amounts)
            std = statistics.stdev(amounts)
            variance = statistics.variance(amounts)
        except statistics.StatisticsError:
            return {"user_id": str(user_id), "message": "Cannot calculate risk metrics"}

        return {
            "user_id": str(user_id),
            "mean_trade_size": round(mean, 2),
            "std_dev": round(std, 2),
            "variance": round(variance, 2),
            "coefficient_of_variation": round(std / mean, 4) if mean > 0 else 0,
        }

    async def correlations(self, user_id: UUID) -> Dict[str, Any]:
        return {"user_id": str(user_id), "message": "Correlation analysis requires price history data", "status": "pending"}
