"""
ZANOX V18 Tax Engine API
"""
from fastapi import APIRouter
from uuid import UUID

from .engine import TaxEngine

router = APIRouter(prefix="/tax", tags=["tax"])
engine = TaxEngine()


@router.post("/calculate")
async def calculate_tax(payload: dict):
    return await engine.calculate_tax(payload)


@router.get("/summary/{user_id}/{year}")
async def get_tax_summary(user_id: UUID, year: int):
    return await engine.get_tax_summary(user_id, year)


@router.get("/quarterly/{user_id}/{year}/{quarter}")
async def estimate_quarterly(user_id: UUID, year: int, quarter: int):
    return await engine.estimate_quarterly_tax(user_id, quarter, year)
