"""
ZANOX V18 Tax Engine Core
"""
from typing import Dict, Any, List, Optional
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("tax_engine")


class TaxEngine:
    def __init__(self):
        self._calculator = None

    async def initialize(self):
        from .calculator import TaxCalculator
        self._calculator = TaxCalculator()
        logger.info("TaxEngine initialized")

    async def calculate_tax(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        if not self._calculator:
            raise RuntimeError("Engine not initialized")
        return await self._calculator.calculate(payload)

    async def get_tax_summary(self, user_id: UUID, year: int) -> Dict[str, Any]:
        if not self._calculator:
            raise RuntimeError("Engine not initialized")
        return await self._calculator.get_summary(user_id, year)

    async def estimate_quarterly_tax(self, user_id: UUID, quarter: int, year: int) -> Dict[str, Any]:
        if not self._calculator:
            raise RuntimeError("Engine not initialized")
        return await self._calculator.estimate_quarterly(user_id, quarter, year)

    async def shutdown(self):
        logger.info("TaxEngine shut down")
