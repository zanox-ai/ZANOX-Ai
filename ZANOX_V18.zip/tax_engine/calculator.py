"""
ZANOX V18 Tax Calculator
Computes tax obligations for multiple jurisdictions.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.database import get_db_context
from shared.utils import safe_divide
from shared.logger import get_logger

logger = get_logger("tax_calculator")


class TaxCalculator:
    US_BRACKETS = [
        (0, 11600, 10),
        (11600, 47150, 12),
        (47150, 100525, 22),
        (100525, 191950, 24),
        (191950, 243725, 32),
        (243725, 609350, 35),
        (609350, float('inf'), 37),
    ]

    async def calculate(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        jurisdiction = payload.get("jurisdiction", "US")
        taxable_income = Decimal(str(payload.get("taxable_income", 0)))
        if jurisdiction == "US":
            return self._calculate_us_tax(taxable_income)
        elif jurisdiction == "UK":
            return self._calculate_uk_tax(taxable_income)
        elif jurisdiction == "EU":
            return self._calculate_eu_tax(taxable_income, payload.get("country", "DE"))
        return {"error": f"Unsupported jurisdiction: {jurisdiction}"}

    def _calculate_us_tax(self, income: Decimal) -> Dict[str, Any]:
        total_tax = Decimal("0")
        bracket_breakdown = []
        for low, high, rate in self.US_BRACKETS:
            if income > Decimal(str(low)):
                taxable_in_bracket = min(income, Decimal(str(high))) - Decimal(str(low))
                tax_in_bracket = taxable_in_bracket * Decimal(str(rate)) / 100
                total_tax += tax_in_bracket
                bracket_breakdown.append({
                    "bracket": f"${low:,.0f} - ${high:,.0f}",
                    "rate": rate,
                    "taxable_amount": float(taxable_in_bracket),
                    "tax": float(tax_in_bracket),
                })
        effective_rate = safe_divide(total_tax, income, Decimal("0")) * 100
        return {
            "jurisdiction": "US",
            "taxable_income": float(income),
            "total_tax": float(total_tax.quantize(Decimal("0.01"))),
            "effective_rate": float(effective_rate.quantize(Decimal("0.01"))),
            "brackets": bracket_breakdown,
        }

    def _calculate_uk_tax(self, income: Decimal) -> Dict[str, Any]:
        personal_allowance = Decimal("12570")
        taxable = max(income - personal_allowance, Decimal("0"))
        tax = Decimal("0")
        if taxable > 0:
            tax += min(taxable, Decimal("37700")) * Decimal("0.20")
        if taxable > Decimal("37700"):
            tax += min(taxable - Decimal("37700"), Decimal("87540")) * Decimal("0.40")
        if taxable > Decimal("125140"):
            tax += (taxable - Decimal("125140")) * Decimal("0.45")
        return {
            "jurisdiction": "UK",
            "taxable_income": float(income),
            "total_tax": float(tax.quantize(Decimal("0.01"))),
            "effective_rate": float(safe_divide(tax, income, Decimal("0")) * 100),
        }

    def _calculate_eu_tax(self, income: Decimal, country: str) -> Dict[str, Any]:
        rates = {"DE": 42, "FR": 45, "IT": 43, "ES": 37, "NL": 49.5}
        rate = Decimal(str(rates.get(country, 30)))
        tax = income * rate / 100
        return {
            "jurisdiction": f"EU-{country}",
            "taxable_income": float(income),
            "total_tax": float(tax.quantize(Decimal("0.01"))),
            "effective_rate": float(rate),
        }

    async def get_summary(self, user_id: UUID, year: int) -> Dict[str, Any]:
        start = date(year, 1, 1)
        end = date(year, 12, 31)
        async with get_db_context() as session:
            from sqlalchemy import text
            income_query = text("""
                SELECT COALESCE(SUM(amount), 0) as total FROM transactions
                WHERE user_id = :user_id AND type = 'income' AND transaction_date BETWEEN :start AND :end
                AND status = 'completed'
            """)
            expense_query = text("""
                SELECT COALESCE(SUM(amount), 0) as total FROM transactions
                WHERE user_id = :user_id AND type = 'expense' AND category IN ('business', 'deductible')
                AND transaction_date BETWEEN :start AND :end AND status = 'completed'
            """)
            income_result = await session.execute(income_query, {"user_id": str(user_id), "start": start, "end": end})
            expense_result = await session.execute(expense_query, {"user_id": str(user_id), "start": start, "end": end})
            total_income = Decimal(str(income_result.fetchone()[0]))
            deductions = Decimal(str(expense_result.fetchone()[0]))
            taxable = total_income - deductions
            tax_calc = self._calculate_us_tax(taxable)
            return {
                "year": year,
                "total_income": float(total_income),
                "deductions": float(deductions),
                "taxable_income": float(taxable),
                **tax_calc,
            }

    async def estimate_quarterly(self, user_id: UUID, quarter: int, year: int) -> Dict[str, Any]:
        start_month = (quarter - 1) * 3 + 1
        start = date(year, start_month, 1)
        end = date(year, start_month + 2, 31) if start_month < 11 else date(year, 12, 31)
        summary = await self.get_summary(user_id, year)
        quarterly_estimate = Decimal(str(summary["total_tax"])) / 4
        return {
            "year": year,
            "quarter": quarter,
            "estimated_tax": float(quarterly_estimate.quantize(Decimal("0.01"))),
            "due_date": date(year, start_month + 3, 15).isoformat(),
        }
