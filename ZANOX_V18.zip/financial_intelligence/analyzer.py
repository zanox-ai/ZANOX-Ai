"""
ZANOX V18 Intelligence Analyzer
Pattern recognition and predictive analytics for financial data.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date, timedelta
from uuid import UUID
import statistics

from shared.database import get_db_context
from shared.logger import get_logger

logger = get_logger("intelligence_analyzer")


class IntelligenceAnalyzer:
    async def spending_patterns(self, user_id: UUID) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT EXTRACT(DOW FROM transaction_date) as day_of_week, category, COALESCE(SUM(amount), 0) as total
                FROM expense_records
                WHERE user_id = :user_id AND transaction_date >= CURRENT_DATE - INTERVAL '90 days'
                GROUP BY EXTRACT(DOW FROM transaction_date), category
                ORDER BY day_of_week, total DESC
            """)
            result = await session.execute(query, {"user_id": str(user_id)})
            patterns = [dict(row) for row in result.mappings()]

        day_names = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
        by_day = {}
        for p in patterns:
            day = int(p["day_of_week"])
            if day not in by_day:
                by_day[day] = []
            by_day[day].append(p)

        insights = []
        for day, cats in by_day.items():
            top = max(cats, key=lambda x: x["total"])
            insights.append({
                "day": day_names[day],
                "top_category": top["category"],
                "amount": float(top["total"]),
                "insight": f"Highest spending on {day_names[day]} is in {top['category']}",
            })

        return {
            "user_id": str(user_id),
            "patterns": insights,
            "pattern_count": len(insights),
        }

    async def predict_events(self, user_id: UUID) -> List[Dict[str, Any]]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT name, amount, frequency, next_billing_date
                FROM subscriptions
                WHERE user_id = :user_id AND status = 'active'
                AND next_billing_date BETWEEN CURRENT_DATE AND CURRENT_DATE + INTERVAL '30 days'
            """)
            result = await session.execute(query, {"user_id": str(user_id)})
            upcoming = [dict(row) for row in result.mappings()]

        predictions = []
        for sub in upcoming:
            predictions.append({
                "event_type": "subscription_renewal",
                "name": sub["name"],
                "amount": float(sub["amount"]),
                "date": sub["next_billing_date"].isoformat() if hasattr(sub["next_billing_date"], 'isoformat') else str(sub["next_billing_date"]),
                "confidence": 95,
            })
        return predictions

    async def lifestyle_changes(self, user_id: UUID) -> List[Dict[str, Any]]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT category, COALESCE(SUM(amount), 0) as total
                FROM expense_records
                WHERE user_id = :user_id AND transaction_date >= CURRENT_DATE - INTERVAL '30 days'
                GROUP BY category
            """)
            result = await session.execute(query, {"user_id": str(user_id)})
            recent = {row["category"]: Decimal(str(row["total"])) for row in result.mappings()}

            prev_query = text("""
                SELECT category, COALESCE(SUM(amount), 0) as total
                FROM expense_records
                WHERE user_id = :user_id AND transaction_date BETWEEN CURRENT_DATE - INTERVAL '60 days' AND CURRENT_DATE - INTERVAL '30 days'
                GROUP BY category
            """)
            prev_result = await session.execute(prev_query, {"user_id": str(user_id)})
            previous = {row["category"]: Decimal(str(row["total"])) for row in prev_result.mappings()}

        changes = []
        for cat in set(list(recent.keys()) + list(previous.keys())):
            recent_val = recent.get(cat, Decimal("0"))
            prev_val = previous.get(cat, Decimal("0"))
            if prev_val > 0:
                change_pct = ((recent_val - prev_val) / prev_val * 100)
                if abs(change_pct) > 30:
                    changes.append({
                        "category": cat,
                        "previous_month": float(prev_val),
                        "current_month": float(recent_val),
                        "change_pct": float(change_pct.quantize(Decimal("0.01"))),
                        "direction": "increase" if change_pct > 0 else "decrease",
                        "significance": "major" if abs(change_pct) > 50 else "moderate",
                    })
        return changes
