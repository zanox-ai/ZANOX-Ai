"""
ZANOX V18 Financial Intelligence API
"""
from fastapi import APIRouter
from uuid import UUID

from .engine import FinancialIntelligenceEngine

router = APIRouter(prefix="/intelligence", tags=["intelligence"])
engine = FinancialIntelligenceEngine()


@router.get("/patterns/{user_id}")
async def spending_patterns(user_id: UUID):
    return await engine.analyze_spending_patterns(user_id)


@router.get("/predictions/{user_id}")
async def predict_events(user_id: UUID):
    return await engine.predict_financial_events(user_id)


@router.get("/changes/{user_id}")
async def lifestyle_changes(user_id: UUID):
    return await engine.detect_lifestyle_changes(user_id)
