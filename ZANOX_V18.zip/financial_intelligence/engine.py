"""
ZANOX V18 Financial Intelligence Engine Core
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("financial_intelligence_engine")


class FinancialIntelligenceEngine:
    def __init__(self):
        self._analyzer = None

    async def initialize(self):
        from .analyzer import IntelligenceAnalyzer
        self._analyzer = IntelligenceAnalyzer()
        logger.info("FinancialIntelligenceEngine initialized")

    async def analyze_spending_patterns(self, user_id: UUID) -> Dict[str, Any]:
        if not self._analyzer:
            raise RuntimeError("Engine not initialized")
        return await self._analyzer.spending_patterns(user_id)

    async def predict_financial_events(self, user_id: UUID) -> List[Dict[str, Any]]:
        if not self._analyzer:
            raise RuntimeError("Engine not initialized")
        return await self._analyzer.predict_events(user_id)

    async def detect_lifestyle_changes(self, user_id: UUID) -> List[Dict[str, Any]]:
        if not self._analyzer:
            raise RuntimeError("Engine not initialized")
        return await self._analyzer.lifestyle_changes(user_id)

    async def shutdown(self):
        logger.info("FinancialIntelligenceEngine shut down")
