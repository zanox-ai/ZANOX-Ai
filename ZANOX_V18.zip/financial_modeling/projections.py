"""
ZANOX V18 Projection Model
Builds multi-year financial projections.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date

from shared.utils import calculate_compound_interest
from shared.logger import get_logger

logger = get_logger("projection_model")


class ProjectionModel:
    async def build(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        revenue = Decimal(str(payload.get("current_revenue", 0)))
        growth_rate = Decimal(str(payload.get("growth_rate", 5)))
        years = payload.get("years", 5)
        expense_ratio = Decimal(str(payload.get("expense_ratio", 70)))
        tax_rate = Decimal(str(payload.get("tax_rate", 25)))

        projections = []
        for year in range(1, years + 1):
            projected_revenue = revenue * ((1 + growth_rate / 100) ** year)
            projected_expenses = projected_revenue * expense_ratio / 100
            ebitda = projected_revenue - projected_expenses
            tax = ebitda * tax_rate / 100
            net_income = ebitda - tax
            projections.append({
                "year": date.today().year + year,
                "revenue": float(projected_revenue.quantize(Decimal("0.01"))),
                "expenses": float(projected_expenses.quantize(Decimal("0.01"))),
                "ebitda": float(ebitda.quantize(Decimal("0.01"))),
                "tax": float(tax.quantize(Decimal("0.01"))),
                "net_income": float(net_income.quantize(Decimal("0.01"))),
                "margin": float((net_income / projected_revenue * 100).quantize(Decimal("0.01"))),
            })

        return {
            "base_revenue": float(revenue),
            "growth_rate": float(growth_rate),
            "years": years,
            "projections": projections,
            "total_projected_revenue": sum(p["revenue"] for p in projections),
            "total_projected_net_income": sum(p["net_income"] for p in projections),
        }
