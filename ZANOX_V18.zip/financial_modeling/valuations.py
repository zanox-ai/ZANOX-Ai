"""
ZANOX V18 Valuation Model
Calculates business and asset valuations.
"""
from typing import Dict, Any
from decimal import Decimal

from shared.utils import calculate_npv
from shared.logger import get_logger

logger = get_logger("valuation_model")


class ValuationModel:
    async def calculate(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        method = payload.get("method", "dcf")
        if method == "dcf":
            return await self._dcf_valuation(payload)
        elif method == "multiple":
            return await self._multiple_valuation(payload)
        elif method == "asset_based":
            return await self._asset_based_valuation(payload)
        return {"error": f"Unknown valuation method: {method}"}

    async def _dcf_valuation(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        free_cash_flows = [Decimal(str(f)) for f in payload.get("free_cash_flows", [])]
        discount_rate = Decimal(str(payload.get("discount_rate", 10)))
        terminal_growth = Decimal(str(payload.get("terminal_growth", 2)))
        if not free_cash_flows:
            return {"error": "No cash flows provided"}

        npv = Decimal("0")
        for i, fcf in enumerate(free_cash_flows, 1):
            npv += fcf / ((1 + discount_rate / 100) ** i)

        terminal_fcf = free_cash_flows[-1] * (1 + terminal_growth / 100)
        terminal_value = terminal_fcf / (discount_rate / 100 - terminal_growth / 100)
        npv += terminal_value / ((1 + discount_rate / 100) ** len(free_cash_flows))

        return {
            "method": "dcf",
            "discount_rate": float(discount_rate),
            "terminal_growth": float(terminal_growth),
            "present_value_of_cash_flows": float(npv.quantize(Decimal("0.01"))),
            "terminal_value": float(terminal_value.quantize(Decimal("0.01"))),
            "enterprise_value": float((npv + terminal_value).quantize(Decimal("0.01"))),
        }

    async def _multiple_valuation(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        revenue = Decimal(str(payload.get("revenue", 0)))
        ebitda = Decimal(str(payload.get("ebitda", 0)))
        revenue_multiple = Decimal(str(payload.get("revenue_multiple", 3)))
        ebitda_multiple = Decimal(str(payload.get("ebitda_multiple", 8)))
        revenue_valuation = revenue * revenue_multiple
        ebitda_valuation = ebitda * ebitda_multiple
        return {
            "method": "multiple",
            "revenue_valuation": float(revenue_valuation.quantize(Decimal("0.01"))),
            "ebitda_valuation": float(ebitda_valuation.quantize(Decimal("0.01"))),
            "average_valuation": float(((revenue_valuation + ebitda_valuation) / 2).quantize(Decimal("0.01"))),
        }

    async def _asset_based_valuation(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        total_assets = Decimal(str(payload.get("total_assets", 0)))
        total_liabilities = Decimal(str(payload.get("total_liabilities", 0)))
        book_value = total_assets - total_liabilities
        return {
            "method": "asset_based",
            "total_assets": float(total_assets),
            "total_liabilities": float(total_liabilities),
            "book_value": float(book_value),
            "net_asset_value": float(book_value),
        }
