"""
ZANOX V18 System Monitor
Monitors system and financial health metrics.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import datetime, date
from uuid import UUID

from shared.database import get_db_context
from shared.logger import get_logger

logger = get_logger("system_monitor")


class SystemMonitor:
    async def get_health(self) -> Dict[str, Any]:
        return {
            "status": "healthy",
            "timestamp": datetime.utcnow().isoformat(),
            "services": {
                "finance_engine": "up",
                "accounting": "up",
                "database": "up",
                "redis": "up",
                "kafka": "up",
            },
            "version": "18.0.0",
        }

    async def get_user_health(self, user_id: UUID) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            assets = await session.execute(text("SELECT COALESCE(SUM(balance), 0) as total FROM accounts WHERE user_id = :user_id AND account_type = 'asset'"), {"user_id": str(user_id)})
            liabilities = await session.execute(text("SELECT COALESCE(SUM(balance), 0) as total FROM accounts WHERE user_id = :user_id AND account_type = 'liability'"), {"user_id": str(user_id)})
            a = Decimal(str(assets.fetchone()[0]))
            l = Decimal(str(liabilities.fetchone()[0]))
            nw = a - l
        score = 50
        if nw > 0: score += 20
        if a > l * 2: score += 15
        if l == 0: score += 15
        return {
            "user_id": str(user_id),
            "health_score": min(score, 100),
            "net_worth": float(nw),
            "status": "healthy" if score > 70 else "at_risk" if score > 40 else "critical",
        }

    async def get_metrics(self) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            txn_count = await session.execute(text("SELECT COUNT(*) as total FROM transactions"))
            user_count = await session.execute(text("SELECT COUNT(DISTINCT user_id) as total FROM accounts"))
            total_volume = await session.execute(text("SELECT COALESCE(SUM(amount), 0) as total FROM transactions WHERE status = 'completed'"))
        return {
            "total_transactions": txn_count.fetchone()[0],
            "active_users": user_count.fetchone()[0],
            "total_volume": float(total_volume.fetchone()[0]),
            "timestamp": datetime.utcnow().isoformat(),
        }
