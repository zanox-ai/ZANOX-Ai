"""
ZANOX V18 Monitoring Engine Core
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import datetime
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("monitoring_engine")


class MonitoringEngine:
    def __init__(self):
        self._monitor = None

    async def initialize(self):
        from .monitor import SystemMonitor
        self._monitor = SystemMonitor()
        logger.info("MonitoringEngine initialized")

    async def get_system_health(self) -> Dict[str, Any]:
        if not self._monitor:
            raise RuntimeError("Engine not initialized")
        return await self._monitor.get_health()

    async def get_user_health(self, user_id: UUID) -> Dict[str, Any]:
        if not self._monitor:
            raise RuntimeError("Engine not initialized")
        return await self._monitor.get_user_health(user_id)

    async def get_metrics(self) -> Dict[str, Any]:
        if not self._monitor:
            raise RuntimeError("Engine not initialized")
        return await self._monitor.get_metrics()

    async def shutdown(self):
        logger.info("MonitoringEngine shut down")
