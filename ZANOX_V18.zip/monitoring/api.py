"""
ZANOX V18 Monitoring API
"""
from fastapi import APIRouter
from uuid import UUID

from .engine import MonitoringEngine

router = APIRouter(prefix="/monitoring", tags=["monitoring"])
engine = MonitoringEngine()


@router.get("/health")
async def system_health():
    return await engine.get_system_health()


@router.get("/health/{user_id}")
async def user_health(user_id: UUID):
    return await engine.get_user_health(user_id)


@router.get("/metrics")
async def get_metrics():
    return await engine.get_metrics()
