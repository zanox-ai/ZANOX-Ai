"""
ZANOX V18 Budget Allocator
Goal-based budget allocation with smart recommendations.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.database import get_db_context
from shared.utils import safe_divide
from shared.logger import get_logger

logger = get_logger("budget_allocator")


class BudgetAllocator:
    async def allocate_by_goals(self, user_id: UUID, goals: List[Dict[str, Any]], income: Decimal) -> Dict[str, Any]:
        total_weight = sum(g.get("priority", 1) for g in goals)
        allocations = []
        remaining = income
        for goal in goals:
            weight = goal.get("priority", 1)
            target = Decimal(str(goal.get("target_amount", 0)))
            pct = safe_divide(Decimal(str(weight)), Decimal(str(total_weight)), Decimal("0")) * 100
            allocated = income * pct / 100
            if target > 0 and allocated > target:
                allocated = target
            remaining -= allocated
            allocations.append({
                "goal": goal.get("name"),
                "target_amount": float(target),
                "allocated": float(allocated.quantize(Decimal("0.01"))),
                "percentage": float(pct.quantize(Decimal("0.01"))),
                "priority": weight,
            })
        if remaining > 0:
            allocations.append({
                "goal": "discretionary",
                "target_amount": 0,
                "allocated": float(remaining.quantize(Decimal("0.01"))),
                "percentage": float(safe_divide(remaining, income, Decimal("0")) * 100),
                "priority": 0,
            })
        return {
            "user_id": str(user_id),
            "total_income": float(income),
            "allocations": allocations,
            "fully_allocated": remaining >= 0,
        }

    async def get_recommendations(self, user_id: UUID) -> List[Dict[str, Any]]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT category, COALESCE(SUM(amount), 0) as total
                FROM expense_records
                WHERE user_id = :user_id AND transaction_date >= CURRENT_DATE - INTERVAL '3 months'
                GROUP BY category
            """)
            result = await session.execute(query, {"user_id": str(user_id)})
            expenses = {row["category"]: Decimal(str(row["total"])) for row in result.mappings()}

        recommendations = []
        total_expenses = sum(expenses.values())
        benchmarks = {
            "housing": Decimal("30"),
            "food": Decimal("15"),
            "transportation": Decimal("10"),
            "utilities": Decimal("10"),
            "entertainment": Decimal("5"),
            "savings": Decimal("20"),
        }
        for cat, benchmark in benchmarks.items():
            actual_pct = safe_divide(expenses.get(cat, Decimal("0")) * 100, total_expenses, Decimal("0"))
            if actual_pct > benchmark:
                recommendations.append({
                    "category": cat,
                    "current_pct": float(actual_pct.quantize(Decimal("0.01"))),
                    "recommended_pct": float(benchmark),
                    "action": "reduce",
                    "potential_monthly_savings": float((actual_pct - benchmark) / 100 * total_expenses / 3),
                })
            elif actual_pct < benchmark and cat == "savings":
                recommendations.append({
                    "category": cat,
                    "current_pct": float(actual_pct.quantize(Decimal("0.01"))),
                    "recommended_pct": float(benchmark),
                    "action": "increase",
                    "recommended_monthly_increase": float((benchmark - actual_pct) / 100 * total_expenses / 3),
                })
        return recommendations
