"""
ZANOX V18 Scenario Planner
Models different financial scenarios for budget planning.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date, timedelta
from uuid import UUID

from shared.database import get_db_context
from shared.logger import get_logger

logger = get_logger("scenario_planner")


class ScenarioPlanner:
    SCENARIOS = ["increase_income", "reduce_expenses", "emergency_fund", "debt_payoff", "investment_growth"]

    async def run(self, user_id: UUID, scenario: str, parameters: Dict[str, Any]) -> Dict[str, Any]:
        if scenario not in self.SCENARIOS:
            return {"error": f"Unknown scenario: {scenario}", "available": self.SCENARIOS}

        if scenario == "increase_income":
            return await self._scenario_increase_income(user_id, parameters)
        elif scenario == "reduce_expenses":
            return await self._scenario_reduce_expenses(user_id, parameters)
        elif scenario == "emergency_fund":
            return await self._scenario_emergency_fund(user_id, parameters)
        elif scenario == "debt_payoff":
            return await self._scenario_debt_payoff(user_id, parameters)
        elif scenario == "investment_growth":
            return await self._scenario_investment_growth(user_id, parameters)
        return {}

    async def _scenario_increase_income(self, user_id: UUID, params: Dict[str, Any]) -> Dict[str, Any]:
        increase_pct = Decimal(str(params.get("increase_percentage", 10)))
        months = params.get("months", 12)
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT COALESCE(SUM(amount), 0) as avg_monthly
                FROM transactions
                WHERE user_id = :user_id AND type = 'income'
                AND transaction_date >= CURRENT_DATE - INTERVAL '3 months'
                AND status = 'completed'
            """)
            result = await session.execute(query, {"user_id": str(user_id)})
            avg_monthly = Decimal(str(result.fetchone()[0])) / 3
            new_monthly = avg_monthly * (1 + increase_pct / 100)
            additional = (new_monthly - avg_monthly) * months
            return {
                "scenario": "increase_income",
                "current_monthly": float(avg_monthly.quantize(Decimal("0.01"))),
                "new_monthly": float(new_monthly.quantize(Decimal("0.01"))),
                "increase_percentage": float(increase_pct),
                "additional_over_period": float(additional.quantize(Decimal("0.01"))),
                "months": months,
            }

    async def _scenario_reduce_expenses(self, user_id: UUID, params: Dict[str, Any]) -> Dict[str, Any]:
        reduction_pct = Decimal(str(params.get("reduction_percentage", 10)))
        categories = params.get("categories", ["entertainment", "dining", "shopping"])
        months = params.get("months", 12)
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT category, COALESCE(SUM(amount), 0) as total
                FROM expense_records
                WHERE user_id = :user_id AND category = ANY(:categories)
                AND transaction_date >= CURRENT_DATE - INTERVAL '3 months'
                GROUP BY category
            """)
            result = await session.execute(query, {"user_id": str(user_id), "categories": categories})
            savings = Decimal("0")
            breakdown = []
            for row in result.mappings():
                cat_savings = Decimal(str(row["total"])) * reduction_pct / 100
                savings += cat_savings
                breakdown.append({
                    "category": row["category"],
                    "current_3mo": float(row["total"]),
                    "monthly_savings": float(cat_savings / 3),
                })
            total_savings = savings * months / 3
            return {
                "scenario": "reduce_expenses",
                "reduction_percentage": float(reduction_pct),
                "monthly_savings": float(savings / 3),
                "total_savings_over_period": float(total_savings.quantize(Decimal("0.01"))),
                "breakdown": breakdown,
                "months": months,
            }

    async def _scenario_emergency_fund(self, user_id: UUID, params: Dict[str, Any]) -> Dict[str, Any]:
        months_expenses = params.get("months_of_expenses", 6)
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT COALESCE(SUM(amount), 0) as avg_monthly
                FROM expense_records
                WHERE user_id = :user_id
                AND transaction_date >= CURRENT_DATE - INTERVAL '3 months'
            """)
            result = await session.execute(query, {"user_id": str(user_id)})
            avg_monthly = Decimal(str(result.fetchone()[0])) / 3
            target = avg_monthly * months_expenses
            return {
                "scenario": "emergency_fund",
                "target_amount": float(target.quantize(Decimal("0.01"))),
                "months_of_expenses": months_expenses,
                "monthly_expenses": float(avg_monthly.quantize(Decimal("0.01"))),
                "recommendation": f"Save ${float(target):.2f} to cover {months_expenses} months of expenses",
            }

    async def _scenario_debt_payoff(self, user_id: UUID, params: Dict[str, Any]) -> Dict[str, Any]:
        extra_payment = Decimal(str(params.get("extra_payment", 0)))
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT a.name, a.balance, a.interest_rate
                FROM accounts a
                WHERE a.user_id = :user_id AND a.account_type = 'liability'
                AND a.balance > 0
                ORDER BY a.interest_rate DESC
            """)
            result = await session.execute(query, {"user_id": str(user_id)})
            debts = [dict(row) for row in result.mappings()]
            total_debt = sum(Decimal(str(d["balance"])) for d in debts)
            return {
                "scenario": "debt_payoff",
                "total_debt": float(total_debt),
                "debts": debts,
                "extra_payment": float(extra_payment),
                "strategy": "avalanche" if extra_payment > 0 else "minimum",
                "estimated_payoff_months": len(debts) * 12 if extra_payment == 0 else "calculated_with_extra",
            }

    async def _scenario_investment_growth(self, user_id: UUID, params: Dict[str, Any]) -> Dict[str, Any]:
        monthly_contribution = Decimal(str(params.get("monthly_contribution", 500)))
        annual_return = Decimal(str(params.get("annual_return", 7)))
        years = params.get("years", 10)
        from shared.utils import calculate_compound_interest
        future_value = calculate_compound_interest(monthly_contribution * 12, annual_return, years)
        total_contributed = monthly_contribution * 12 * years
        return {
            "scenario": "investment_growth",
            "monthly_contribution": float(monthly_contribution),
            "annual_return": float(annual_return),
            "years": years,
            "future_value": float(future_value.quantize(Decimal("0.01"))),
            "total_contributed": float(total_contributed),
            "growth": float(future_value - total_contributed),
        }
