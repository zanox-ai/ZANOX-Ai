"""
ZANOX V18 Budget Planner Engine Core
Advanced budget planning with goal-based allocation.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("budget_planner_engine")


class BudgetPlannerEngine:
    def __init__(self):
        self._scenarios = None
        self._allocator = None

    async def initialize(self):
        from .scenarios import ScenarioPlanner
        from .allocator import BudgetAllocator
        self._scenarios = ScenarioPlanner()
        self._allocator = BudgetAllocator()
        logger.info("BudgetPlannerEngine initialized")

    async def create_goal_based_budget(self, user_id: UUID, goals: List[Dict[str, Any]], income: Decimal) -> Dict[str, Any]:
        if not self._allocator:
            raise RuntimeError("Engine not initialized")
        return await self._allocator.allocate_by_goals(user_id, goals, income)

    async def run_scenario(self, user_id: UUID, scenario: str, parameters: Dict[str, Any]) -> Dict[str, Any]:
        if not self._scenarios:
            raise RuntimeError("Engine not initialized")
        return await self._scenarios.run(user_id, scenario, parameters)

    async def get_recommendations(self, user_id: UUID) -> List[Dict[str, Any]]:
        if not self._allocator:
            raise RuntimeError("Engine not initialized")
        return await self._allocator.get_recommendations(user_id)

    async def shutdown(self):
        logger.info("BudgetPlannerEngine shut down")
