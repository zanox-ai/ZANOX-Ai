"""
ZANOX V18 Cash Flow Forecaster
Predicts future cash flows using time-series analysis.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date, timedelta
from uuid import UUID
import statistics

from shared.database import get_db_context
from shared.logger import get_logger

logger = get_logger("cashflow_forecaster")


class CashFlowForecaster:
    async def forecast(self, user_id: UUID, days: int = 90) -> List[Dict[str, Any]]:
        historical = await self._get_historical_daily(user_id, days=60)
        if len(historical) < 7:
            return self._generate_naive_forecast(days)

        inflows = [h["inflow"] for h in historical]
        outflows = [h["outflow"] for h in historical]
        avg_inflow = statistics.mean(inflows) if inflows else 0
        avg_outflow = statistics.mean(outflows) if outflows else 0
        std_inflow = statistics.stdev(inflows) if len(inflows) > 1 else 0
        std_outflow = statistics.stdev(outflows) if len(outflows) > 1 else 0

        forecasts = []
        for i in range(1, days + 1):
            forecast_date = date.today() + timedelta(days=i)
            day_of_week = forecast_date.weekday()
            weekend_factor = 0.7 if day_of_week >= 5 else 1.0
            pred_inflow = avg_inflow * weekend_factor
            pred_outflow = avg_outflow * weekend_factor
            net = pred_inflow - pred_outflow
            confidence = max(0, 100 - (i / days * 50) - (std_inflow / max(avg_inflow, 1) * 10))
            forecasts.append({
                "date": forecast_date.isoformat(),
                "predicted_inflow": round(pred_inflow, 2),
                "predicted_outflow": round(pred_outflow, 2),
                "predicted_net": round(net, 2),
                "cumulative_net": round(sum(f["predicted_net"] for f in forecasts) + net, 2) if forecasts else round(net, 2),
                "confidence": round(confidence, 2),
            })
        return forecasts

    async def _get_historical_daily(self, user_id: UUID, days: int = 60) -> List[Dict[str, Any]]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT transaction_date,
                       COALESCE(SUM(CASE WHEN type = 'income' THEN amount ELSE 0 END), 0) as inflow,
                       COALESCE(SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END), 0) as outflow
                FROM transactions
                WHERE user_id = :user_id AND transaction_date >= CURRENT_DATE - :days
                AND status = 'completed'
                GROUP BY transaction_date
                ORDER BY transaction_date
            """)
            result = await session.execute(query, {"user_id": str(user_id), "days": days})
            return [dict(row) for row in result.mappings()]

    def _generate_naive_forecast(self, days: int) -> List[Dict[str, Any]]:
        forecasts = []
        for i in range(1, days + 1):
            forecast_date = date.today() + timedelta(days=i)
            forecasts.append({
                "date": forecast_date.isoformat(),
                "predicted_inflow": 0,
                "predicted_outflow": 0,
                "predicted_net": 0,
                "cumulative_net": 0,
                "confidence": 0,
                "note": "insufficient_historical_data",
            })
        return forecasts
