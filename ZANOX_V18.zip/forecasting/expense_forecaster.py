"""
ZANOX V18 Expense Forecaster
Predicts future expenses using historical patterns.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date, timedelta
from uuid import UUID
import statistics

from shared.database import get_db_context
from shared.utils import get_month_start, get_month_end
from shared.logger import get_logger

logger = get_logger("expense_forecaster")


class ExpenseForecaster:
    async def forecast(self, user_id: UUID, months: int = 6) -> List[Dict[str, Any]]:
        historical = await self._get_historical_monthly(user_id, months=12)
        if len(historical) < 3:
            return [{"month": (date.today() + timedelta(days=i*30)).strftime("%Y-%m"),
                     "forecasted": 0, "confidence": 0, "method": "naive"}
                    for i in range(1, months + 1)]

        totals = [h["total"] for h in historical]
        avg = statistics.mean(totals)
        try:
            std = statistics.stdev(totals)
        except statistics.StatisticsError:
            std = 0

        forecasts = []
        for i in range(1, months + 1):
            forecast_date = date.today() + timedelta(days=i * 30)
            seasonality = self._get_seasonality_factor(forecast_date.month)
            forecasted = avg * seasonality
            confidence = max(0, 100 - (std / max(avg, 1) * 10) - (i * 5))
            forecasts.append({
                "month": forecast_date.strftime("%Y-%m"),
                "forecasted": round(forecasted, 2),
                "confidence": round(confidence, 2),
                "method": "seasonal_average",
                "seasonality_factor": round(seasonality, 2),
            })
        return forecasts

    async def _get_historical_monthly(self, user_id: UUID, months: int = 12) -> List[Dict[str, Any]]:
        today = date.today()
        historical = []
        for i in range(months - 1, -1, -1):
            month_date = today - timedelta(days=i * 30)
            start = get_month_start(month_date)
            end = get_month_end(month_date)
            async with get_db_context() as session:
                from sqlalchemy import text
                query = text("""
                    SELECT COALESCE(SUM(amount), 0) as total
                    FROM expense_records
                    WHERE user_id = :user_id AND transaction_date BETWEEN :start AND :end
                """)
                result = await session.execute(query, {
                    "user_id": str(user_id), "start": start, "end": end
                })
                total = float(result.fetchone()[0])
            historical.append({"month": start.strftime("%Y-%m"), "total": total})
        return historical

    def _get_seasonality_factor(self, month: int) -> float:
        factors = {
            1: 1.1, 2: 0.9, 3: 1.0, 4: 1.0, 5: 1.05, 6: 1.1,
            7: 1.15, 8: 1.0, 9: 1.05, 10: 1.0, 11: 1.1, 12: 1.2,
        }
        return factors.get(month, 1.0)
