"""
ZANOX V18 Forecasting Engine Core
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("forecasting_engine")


class ForecastingEngine:
    def __init__(self):
        self._cashflow_forecaster = None
        self._expense_forecaster = None

    async def initialize(self):
        from .cashflow_forecaster import CashFlowForecaster
        from .expense_forecaster import ExpenseForecaster
        self._cashflow_forecaster = CashFlowForecaster()
        self._expense_forecaster = ExpenseForecaster()
        logger.info("ForecastingEngine initialized")

    async def forecast_cashflow(self, payload: Dict[str, Any]) -> List[Dict[str, Any]]:
        if not self._cashflow_forecaster:
            raise RuntimeError("Engine not initialized")
        user_id = payload.get("user_id")
        days = payload.get("days", 90)
        return await self._cashflow_forecaster.forecast(user_id, days)

    async def forecast_expenses(self, payload: Dict[str, Any]) -> List[Dict[str, Any]]:
        if not self._expense_forecaster:
            raise RuntimeError("Engine not initialized")
        user_id = payload.get("user_id")
        months = payload.get("months", 6)
        return await self._expense_forecaster.forecast(user_id, months)

    async def shutdown(self):
        logger.info("ForecastingEngine shut down")
