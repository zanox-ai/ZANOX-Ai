"""
ZANOX V18 Compliance Engine Core
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("compliance_engine")


class ComplianceEngine:
    def __init__(self):
        self._checker = None

    async def initialize(self):
        from .checker import ComplianceChecker
        self._checker = ComplianceChecker()
        logger.info("ComplianceEngine initialized")

    async def run_compliance_check(self, user_id: UUID) -> Dict[str, Any]:
        if not self._checker:
            raise RuntimeError("Engine not initialized")
        return await self._checker.check(user_id)

    async def get_compliance_rules(self) -> List[Dict[str, Any]]:
        if not self._checker:
            raise RuntimeError("Engine not initialized")
        return await self._checker.get_rules()

    async def shutdown(self):
        logger.info("ComplianceEngine shut down")
