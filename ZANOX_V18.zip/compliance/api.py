"""
ZANOX V18 Compliance API
"""
from fastapi import APIRouter
from uuid import UUID

from .engine import ComplianceEngine

router = APIRouter(prefix="/compliance", tags=["compliance"])
engine = ComplianceEngine()


@router.get("/check/{user_id}")
async def run_check(user_id: UUID):
    return await engine.run_compliance_check(user_id)


@router.get("/rules")
async def get_rules():
    return await engine.get_compliance_rules()
