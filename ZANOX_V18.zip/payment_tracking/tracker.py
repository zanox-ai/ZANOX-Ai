"""
ZANOX V18 Payment Tracker
Records and tracks all payment transactions.
"""
from typing import Dict, Any, List, Optional
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.database import get_db_context
from shared.exceptions import ValidationError
from shared.utils import generate_reference
from shared.kafka_client import produce_event
from shared.logger import get_logger

logger = get_logger("payment_tracker")


class PaymentTracker:
    async def process(self, data: Dict[str, Any]) -> Dict[str, Any]:
        required = ["user_id", "amount", "direction", "currency"]
        for field in required:
            if field not in data:
                raise ValidationError(f"Missing required field: {field}")

        reference = generate_reference("PAY")
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                INSERT INTO payments (
                    id, user_id, reference, amount, currency, direction, status,
                    source, source_id, payment_method, description, metadata,
                    processed_at, created_at
                ) VALUES (
                    gen_random_uuid(), :user_id, :reference, :amount, :currency, :direction, :status,
                    :source, :source_id, :payment_method, :description, :metadata,
                    :processed_at, NOW()
                ) RETURNING id
            """)
            result = await session.execute(query, {
                "user_id": data["user_id"],
                "reference": reference,
                "amount": str(data["amount"]),
                "currency": data["currency"],
                "direction": data["direction"],
                "status": data.get("status", "completed"),
                "source": data.get("source", ""),
                "source_id": data.get("source_id"),
                "payment_method": data.get("payment_method", ""),
                "description": data.get("description", ""),
                "metadata": str(data.get("metadata", {})),
                "processed_at": data.get("processed_at", date.today()),
            })
            payment_id = str(result.fetchone()[0])

            produce_event("zanox.finance.payments", {
                "event": "payment_processed",
                "payment_id": payment_id,
                "reference": reference,
                "amount": float(data["amount"]),
                "direction": data["direction"],
            })
            logger.info(f"Payment processed: {reference} - {data['direction']} ${data['amount']}")
            return {"payment_id": payment_id, "reference": reference, "status": "completed"}

    async def get(self, payment_id: UUID) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("SELECT * FROM payments WHERE id = :id")
            result = await session.execute(query, {"id": str(payment_id)})
            row = result.mappings().fetchone()
            if not row:
                raise ValidationError("Payment not found")
            return dict(row)

    async def list(self, user_id: UUID, direction: Optional[str] = None) -> List[Dict[str, Any]]:
        async with get_db_context() as session:
            from sqlalchemy import text
            if direction:
                query = text("""
                    SELECT * FROM payments WHERE user_id = :user_id AND direction = :direction
                    ORDER BY created_at DESC
                """)
                result = await session.execute(query, {"user_id": str(user_id), "direction": direction})
            else:
                query = text("SELECT * FROM payments WHERE user_id = :user_id ORDER BY created_at DESC")
                result = await session.execute(query, {"user_id": str(user_id)})
            return [dict(row) for row in result.mappings()]

    async def get_summary(self, user_id: UUID, start: date, end: date) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            in_query = text("""
                SELECT COALESCE(SUM(amount), 0) as total FROM payments
                WHERE user_id = :user_id AND direction = 'in' AND processed_at BETWEEN :start AND :end
            """)
            out_query = text("""
                SELECT COALESCE(SUM(amount), 0) as total FROM payments
                WHERE user_id = :user_id AND direction = 'out' AND processed_at BETWEEN :start AND :end
            """)
            in_result = await session.execute(in_query, {"user_id": str(user_id), "start": start, "end": end})
            out_result = await session.execute(out_query, {"user_id": str(user_id), "start": start, "end": end})
            total_in = Decimal(str(in_result.fetchone()[0]))
            total_out = Decimal(str(out_result.fetchone()[0]))
            return {
                "period": {"start": start.isoformat(), "end": end.isoformat()},
                "total_in": float(total_in),
                "total_out": float(total_out),
                "net": float(total_in - total_out),
            }
