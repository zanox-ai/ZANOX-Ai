"""
ZANOX V18 Payment Tracking API
FastAPI routes for payment management.
"""
from fastapi import APIRouter
from typing import List, Optional
from uuid import UUID
from datetime import date

from .engine import PaymentEngine

router = APIRouter(prefix="/payments", tags=["payments"])
engine = PaymentEngine()


@router.post("/")
async def process_payment(data: dict):
    return await engine.process_payment(data)


@router.get("/{payment_id}")
async def get_payment(payment_id: UUID):
    return await engine.get_payment(payment_id)


@router.get("/")
async def list_payments(user_id: UUID, direction: Optional[str] = None):
    return await engine.list_payments(user_id, direction)


@router.get("/summary/{user_id}")
async def payment_summary(user_id: UUID, start: date, end: date):
    return await engine.get_payment_summary(user_id, start, end)
