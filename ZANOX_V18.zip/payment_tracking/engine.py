"""
ZANOX V18 Payment Tracking Engine Core
"""
from typing import Dict, Any, List, Optional
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("payment_engine")


class PaymentEngine:
    def __init__(self):
        self._tracker = None

    async def initialize(self):
        from .tracker import PaymentTracker
        self._tracker = PaymentTracker()
        logger.info("PaymentEngine initialized")

    async def process_payment(self, data: Dict[str, Any]) -> Dict[str, Any]:
        if not self._tracker:
            raise RuntimeError("Engine not initialized")
        return await self._tracker.process(data)

    async def get_payment(self, payment_id: UUID) -> Dict[str, Any]:
        if not self._tracker:
            raise RuntimeError("Engine not initialized")
        return await self._tracker.get(payment_id)

    async def list_payments(self, user_id: UUID, direction: Optional[str] = None) -> List[Dict[str, Any]]:
        if not self._tracker:
            raise RuntimeError("Engine not initialized")
        return await self._tracker.list(user_id, direction)

    async def get_payment_summary(self, user_id: UUID, start: date, end: date) -> Dict[str, Any]:
        if not self._tracker:
            raise RuntimeError("Engine not initialized")
        return await self._tracker.get_summary(user_id, start, end)

    async def shutdown(self):
        logger.info("PaymentEngine shut down")
