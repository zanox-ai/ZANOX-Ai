"""
ZANOX V18 Alerts Engine Core
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import datetime
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("alert_engine")


class AlertEngine:
    def __init__(self):
        self._manager = None

    async def initialize(self):
        from .manager import AlertManager
        self._manager = AlertManager()
        logger.info("AlertEngine initialized")

    async def create_alert(self, data: Dict[str, Any]) -> Dict[str, Any]:
        if not self._manager:
            raise RuntimeError("Engine not initialized")
        return await self._manager.create(data)

    async def get_alerts(self, user_id: UUID) -> List[Dict[str, Any]]:
        if not self._manager:
            raise RuntimeError("Engine not initialized")
        return await self._manager.get(user_id)

    async def mark_read(self, alert_id: UUID) -> Dict[str, Any]:
        if not self._manager:
            raise RuntimeError("Engine not initialized")
        return await self._manager.mark_read(alert_id)

    async def dismiss_alert(self, alert_id: UUID) -> Dict[str, Any]:
        if not self._manager:
            raise RuntimeError("Engine not initialized")
        return await self._manager.dismiss(alert_id)

    async def shutdown(self):
        logger.info("AlertEngine shut down")
