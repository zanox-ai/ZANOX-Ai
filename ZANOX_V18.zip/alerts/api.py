"""
ZANOX V18 Alerts API
"""
from fastapi import APIRouter
from uuid import UUID

from .engine import AlertEngine

router = APIRouter(prefix="/alerts", tags=["alerts"])
engine = AlertEngine()


@router.post("/")
async def create_alert(data: dict):
    return await engine.create_alert(data)


@router.get("/{user_id}")
async def get_alerts(user_id: UUID):
    return await engine.get_alerts(user_id)


@router.post("/{alert_id}/read")
async def mark_read(alert_id: UUID):
    return await engine.mark_read(alert_id)


@router.post("/{alert_id}/dismiss")
async def dismiss_alert(alert_id: UUID):
    return await engine.dismiss_alert(alert_id)
