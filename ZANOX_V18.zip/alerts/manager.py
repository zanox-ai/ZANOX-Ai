"""
ZANOX V18 Alert Manager
Creates and manages financial alerts.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import datetime
from uuid import UUID

from shared.database import get_db_context
from shared.exceptions import ValidationError
from shared.logger import get_logger

logger = get_logger("alert_manager")


class AlertManager:
    async def create(self, data: Dict[str, Any]) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                INSERT INTO alerts (
                    id, user_id, alert_type, severity, title, message, source,
                    source_id, status, created_at, expires_at
                ) VALUES (
                    gen_random_uuid(), :user_id, :alert_type, :severity, :title, :message, :source,
                    :source_id, 'unread', NOW(), :expires_at
                ) RETURNING id
            """)
            result = await session.execute(query, {
                "user_id": data["user_id"],
                "alert_type": data["alert_type"],
                "severity": data.get("severity", "info"),
                "title": data["title"],
                "message": data["message"],
                "source": data.get("source", ""),
                "source_id": data.get("source_id"),
                "expires_at": data.get("expires_at"),
            })
            alert_id = str(result.fetchone()[0])
            logger.info(f"Created alert: {alert_id}")
            return {"alert_id": alert_id, "status": "created"}

    async def get(self, user_id: UUID) -> List[Dict[str, Any]]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("SELECT * FROM alerts WHERE user_id = :user_id ORDER BY created_at DESC")
            result = await session.execute(query, {"user_id": str(user_id)})
            return [dict(row) for row in result.mappings()]

    async def mark_read(self, alert_id: UUID) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("UPDATE alerts SET status = 'read', read_at = NOW(), updated_at = NOW() WHERE id = :id RETURNING id, status")
            result = await session.execute(query, {"id": str(alert_id)})
            row = result.mappings().fetchone()
            if not row:
                raise ValidationError("Alert not found")
            return dict(row)

    async def dismiss(self, alert_id: UUID) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("UPDATE alerts SET status = 'dismissed', updated_at = NOW() WHERE id = :id RETURNING id, status")
            result = await session.execute(query, {"id": str(alert_id)})
            row = result.mappings().fetchone()
            if not row:
                raise ValidationError("Alert not found")
            return dict(row)
