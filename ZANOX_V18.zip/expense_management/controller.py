"""
ZANOX V18 Expense Controller
Budget compliance checking and anomaly detection for expenses.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID
import statistics

from shared.database import get_db_context
from shared.utils import get_month_start, get_month_end
from shared.logger import get_logger

logger = get_logger("expense_controller")


class ExpenseController:
    async def check_budget_compliance(self, user_id: UUID, category: str, amount: Decimal) -> Dict[str, Any]:
        today = date.today()
        start = get_month_start(today)
        end = get_month_end(today)

        async with get_db_context() as session:
            from sqlalchemy import text
            budget_query = text("""
                SELECT COALESCE(SUM(limit_amount), 0) as budget_limit
                FROM budget_categories
                WHERE budget_id IN (
                    SELECT id FROM budgets WHERE user_id = :user_id AND status = 'active'
                ) AND category = :category
            """)
            budget_result = await session.execute(budget_query, {
                "user_id": str(user_id), "category": category
            })
            budget_limit = Decimal(str(budget_result.fetchone()[0]))

            spent_query = text("""
                SELECT COALESCE(SUM(amount), 0) as spent
                FROM expense_records
                WHERE user_id = :user_id AND category = :category
                AND transaction_date BETWEEN :start AND :end
            """)
            spent_result = await session.execute(spent_query, {
                "user_id": str(user_id), "category": category, "start": start, "end": end
            })
            spent = Decimal(str(spent_result.fetchone()[0]))

            projected = spent + amount
            remaining = budget_limit - projected
            compliance = projected <= budget_limit

            return {
                "category": category,
                "budget_limit": float(budget_limit),
                "current_spent": float(spent),
                "projected_total": float(projected),
                "remaining": float(remaining),
                "compliant": compliance,
                "overage": float(projected - budget_limit) if projected > budget_limit else 0,
            }

    async def detect_anomalies(self, user_id: UUID) -> List[Dict[str, Any]]:
        today = date.today()
        start = today - timedelta(days=90)
        end = today

        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT category, amount, transaction_date, description, id
                FROM expense_records
                WHERE user_id = :user_id AND transaction_date BETWEEN :start AND :end
                ORDER BY category, transaction_date
            """)
            result = await session.execute(query, {
                "user_id": str(user_id), "start": start, "end": end
            })
            expenses = [dict(row) for row in result.mappings()]

        anomalies = []
        by_category = {}
        for e in expenses:
            cat = e["category"]
            if cat not in by_category:
                by_category[cat] = []
            by_category[cat].append(e)

        for cat, items in by_category.items():
            if len(items) < 3:
                continue
            amounts = [float(i["amount"]) for i in items]
            try:
                mean = statistics.mean(amounts)
                std = statistics.stdev(amounts)
            except statistics.StatisticsError:
                continue
            for item in items:
                amount = float(item["amount"])
                if std > 0 and abs(amount - mean) > 2.5 * std:
                    anomalies.append({
                        "transaction_id": item["id"],
                        "category": cat,
                        "amount": amount,
                        "expected_range": [round(mean - 2 * std, 2), round(mean + 2 * std, 2)],
                        "deviation": round((amount - mean) / std, 2),
                        "severity": "high" if abs(amount - mean) > 3 * std else "medium",
                    })

        logger.info(f"Detected {len(anomalies)} expense anomalies for user {user_id}")
        return anomalies
