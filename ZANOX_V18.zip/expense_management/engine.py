"""
ZANOX V18 Expense Management Engine Core
"""
from typing import Dict, Any, List, Optional
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("expense_engine")


class ExpenseEngine:
    def __init__(self):
        self._tracker = None
        self._controller = None

    async def initialize(self):
        from .tracker import ExpenseTracker
        from .controller import ExpenseController
        self._tracker = ExpenseTracker()
        self._controller = ExpenseController()
        logger.info("ExpenseEngine initialized")

    async def record_expense(self, data: Dict[str, Any]) -> Dict[str, Any]:
        if not self._tracker:
            raise RuntimeError("Engine not initialized")
        return await self._tracker.record(data)

    async def get_expense_summary(self, user_id: UUID, start: date, end: date) -> Dict[str, Any]:
        if not self._tracker:
            raise RuntimeError("Engine not initialized")
        return await self._tracker.get_summary(user_id, start, end)

    async def get_expenses_by_category(self, user_id: UUID, start: date, end: date) -> List[Dict[str, Any]]:
        if not self._tracker:
            raise RuntimeError("Engine not initialized")
        return await self._tracker.by_category(user_id, start, end)

    async def check_budget_compliance(self, user_id: UUID, category: str, amount: Decimal) -> Dict[str, Any]:
        if not self._controller:
            raise RuntimeError("Engine not initialized")
        return await self._controller.check_budget_compliance(user_id, category, amount)

    async def detect_anomalies(self, user_id: UUID) -> List[Dict[str, Any]]:
        if not self._controller:
            raise RuntimeError("Engine not initialized")
        return await self._controller.detect_anomalies(user_id)

    async def get_top_expenses(self, user_id: UUID, start: date, end: date, limit: int = 10) -> List[Dict[str, Any]]:
        if not self._tracker:
            raise RuntimeError("Engine not initialized")
        return await self._tracker.top_expenses(user_id, start, end, limit)

    async def shutdown(self):
        logger.info("ExpenseEngine shut down")
