"""
ZANOX V18 Expense Tracker
Records and aggregates expense data.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.database import get_db_context
from shared.logger import get_logger

logger = get_logger("expense_tracker")


class ExpenseTracker:
    async def record(self, data: Dict[str, Any]) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                INSERT INTO expense_records (
                    id, user_id, amount, currency, category, subcategory,
                    description, vendor, payment_method, receipt_url,
                    transaction_date, metadata, created_at
                ) VALUES (
                    gen_random_uuid(), :user_id, :amount, :currency, :category, :subcategory,
                    :description, :vendor, :payment_method, :receipt_url,
                    :transaction_date, :metadata, NOW()
                ) RETURNING id
            """)
            result = await session.execute(query, {
                "user_id": data.get("user_id"),
                "amount": str(data.get("amount", 0)),
                "currency": data.get("currency", "USD"),
                "category": data.get("category", "uncategorized"),
                "subcategory": data.get("subcategory", ""),
                "description": data.get("description", ""),
                "vendor": data.get("vendor", ""),
                "payment_method": data.get("payment_method", ""),
                "receipt_url": data.get("receipt_url", ""),
                "transaction_date": data.get("transaction_date", date.today()),
                "metadata": str(data.get("metadata", {})),
            })
            record_id = str(result.fetchone()[0])
            logger.info(f"Recorded expense: {record_id}")
            return {"id": record_id, "amount": data.get("amount"), "category": data.get("category")}

    async def get_summary(self, user_id: UUID, start: date, end: date) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT COALESCE(SUM(amount), 0) as total, COUNT(*) as count,
                       AVG(amount) as average, currency
                FROM expense_records
                WHERE user_id = :user_id AND transaction_date BETWEEN :start AND :end
                GROUP BY currency
            """)
            result = await session.execute(query, {"user_id": str(user_id), "start": start, "end": end})
            rows = [dict(row) for row in result.mappings()]
            total = sum(Decimal(str(r["total"])) for r in rows)
            count = sum(r["count"] for r in rows)
            avg = total / count if count > 0 else Decimal("0")
            return {
                "period": {"start": start.isoformat(), "end": end.isoformat()},
                "total_expenses": float(total),
                "transaction_count": count,
                "average_transaction": float(avg.quantize(Decimal("0.01"))),
                "by_currency": rows,
            }

    async def by_category(self, user_id: UUID, start: date, end: date) -> List[Dict[str, Any]]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT category, COALESCE(SUM(amount), 0) as total, COUNT(*) as count,
                       AVG(amount) as average
                FROM expense_records
                WHERE user_id = :user_id AND transaction_date BETWEEN :start AND :end
                GROUP BY category
                ORDER BY total DESC
            """)
            result = await session.execute(query, {"user_id": str(user_id), "start": start, "end": end})
            return [dict(row) for row in result.mappings()]

    async def top_expenses(self, user_id: UUID, start: date, end: date, limit: int = 10) -> List[Dict[str, Any]]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT * FROM expense_records
                WHERE user_id = :user_id AND transaction_date BETWEEN :start AND :end
                ORDER BY amount DESC
                LIMIT :limit
            """)
            result = await session.execute(query, {
                "user_id": str(user_id), "start": start, "end": end, "limit": limit
            })
            return [dict(row) for row in result.mappings()]
