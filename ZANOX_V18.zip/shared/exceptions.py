"""
ZANOX V18 Shared Exceptions
Custom exception hierarchy for the Finance Layer.
"""


class ZANOXFinanceException(Exception):
    def __init__(self, message: str, code: str = "FINANCE_ERROR", status_code: int = 400):
        self.message = message
        self.code = code
        self.status_code = status_code
        super().__init__(self.message)


class InsufficientFundsError(ZANOXFinanceException):
    def __init__(self, message: str = "Insufficient funds"):
        super().__init__(message, "INSUFFICIENT_FUNDS", 402)


class InvalidTransactionError(ZANOXFinanceException):
    def __init__(self, message: str = "Invalid transaction"):
        super().__init__(message, "INVALID_TRANSACTION", 400)


class DuplicateEntryError(ZANOXFinanceException):
    def __init__(self, message: str = "Duplicate entry detected"):
        super().__init__(message, "DUPLICATE_ENTRY", 409)


class UnauthorizedAccessError(ZANOXFinanceException):
    def __init__(self, message: str = "Unauthorized access"):
        super().__init__(message, "UNAUTHORIZED", 403)


class ResourceNotFoundError(ZANOXFinanceException):
    def __init__(self, message: str = "Resource not found"):
        super().__init__(message, "NOT_FOUND", 404)


class ValidationError(ZANOXFinanceException):
    def __init__(self, message: str = "Validation failed"):
        super().__init__(message, "VALIDATION_ERROR", 400)


class IntegrationError(ZANOXFinanceException):
    def __init__(self, message: str = "External integration failed"):
        super().__init__(message, "INTEGRATION_ERROR", 502)


class ComplianceError(ZANOXFinanceException):
    def __init__(self, message: str = "Compliance check failed"):
        super().__init__(message, "COMPLIANCE_ERROR", 403)


class FraudDetectedError(ZANOXFinanceException):
    def __init__(self, message: str = "Potential fraud detected"):
        super().__init__(message, "FRAUD_DETECTED", 403)
