"""
ZANOX V18 Shared Configuration
Centralized configuration management.
"""
import os
from typing import Optional
from pydantic_settings import BaseSettings


class FinanceConfig(BaseSettings):
    APP_NAME: str = "ZANOX Finance V18"
    APP_VERSION: str = "18.0.0"
    DEBUG: bool = False

    DATABASE_URL: str = "postgresql+asyncpg://zanox:zanox@localhost:5432/zanox_finance"
    REDIS_URL: str = "redis://localhost:6379/0"
    KAFKA_BOOTSTRAP: str = "localhost:9092"
    ELASTICSEARCH_URL: str = "http://localhost:9200"

    STRIPE_API_KEY: Optional[str] = None
    STRIPE_WEBHOOK_SECRET: Optional[str] = None
    PAYPAL_CLIENT_ID: Optional[str] = None
    PAYPAL_CLIENT_SECRET: Optional[str] = None
    WISE_API_KEY: Optional[str] = None
    PAYONEER_API_KEY: Optional[str] = None

    PLAID_CLIENT_ID: Optional[str] = None
    PLAID_SECRET: Optional[str] = None
    PLAID_ENV: str = "sandbox"

    TINK_CLIENT_ID: Optional[str] = None
    TINK_SECRET: Optional[str] = None

    BINANCE_API_KEY: Optional[str] = None
    BINANCE_SECRET: Optional[str] = None
    COINBASE_API_KEY: Optional[str] = None
    COINBASE_SECRET: Optional[str] = None
    KRAKEN_API_KEY: Optional[str] = None
    KRAKEN_SECRET: Optional[str] = None

    ALPHA_VANTAGE_API_KEY: Optional[str] = None
    POLYGON_API_KEY: Optional[str] = None
    YAHOO_FINANCE_API_KEY: Optional[str] = None

    QUICKBOOKS_CLIENT_ID: Optional[str] = None
    QUICKBOOKS_CLIENT_SECRET: Optional[str] = None
    XERO_CLIENT_ID: Optional[str] = None
    XERO_CLIENT_SECRET: Optional[str] = None
    FRESHBOOKS_API_KEY: Optional[str] = None
    ZOHO_BOOKS_API_KEY: Optional[str] = None

    ENCRYPTION_KEY: str = "zanox-finance-encryption-key-2024"
    JWT_SECRET: str = "zanox-jwt-secret-v18"
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRY_HOURS: int = 24

    MAX_TRANSACTION_AMOUNT: float = 100000000.0
    DEFAULT_CURRENCY: str = "USD"
    FISCAL_YEAR_START_MONTH: int = 1

    FRAUD_DETECTION_ENABLED: bool = True
    ANOMALY_DETECTION_ENABLED: bool = True
    AUTO_RECONCILIATION_ENABLED: bool = True
    REAL_TIME_ALERTS_ENABLED: bool = True

    class Config:
        env_prefix = "ZANOX_"
        case_sensitive = False


settings = FinanceConfig()
