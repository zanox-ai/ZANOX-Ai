"""
ZANOX V18 Shared Kafka Client
Event streaming and messaging.
"""
import os
import json
from typing import Optional, Dict, Any
from kafka import KafkaProducer, KafkaConsumer
from kafka.admin import KafkaAdminClient, NewTopic

KAFKA_BOOTSTRAP_SERVERS = os.getenv("ZANOX_KAFKA_BOOTSTRAP", "localhost:9092")

_producer: Optional[KafkaProducer] = None


def get_kafka_producer() -> KafkaProducer:
    global _producer
    if _producer is None:
        _producer = KafkaProducer(
            bootstrap_servers=KAFKA_BOOTSTRAP_SERVERS,
            value_serializer=lambda v: json.dumps(v).encode("utf-8"),
            key_serializer=lambda k: k.encode("utf-8") if k else None,
            acks="all",
            retries=3,
            retry_backoff_ms=1000,
        )
    return _producer


def produce_event(topic: str, message: Dict[str, Any], key: Optional[str] = None) -> None:
    producer = get_kafka_producer()
    producer.send(topic, key=key, value=message)
    producer.flush()


def create_topic(topic_name: str, partitions: int = 3, replication_factor: int = 1) -> None:
    admin = KafkaAdminClient(bootstrap_servers=KAFKA_BOOTSTRAP_SERVERS)
    topic = NewTopic(name=topic_name, num_partitions=partitions, replication_factor=replication_factor)
    try:
        admin.create_topics([topic])
    except Exception:
        pass
    finally:
        admin.close()


ZANOX_FINANCE_TOPICS = [
    "zanox.finance.transactions",
    "zanox.finance.invoices",
    "zanox.finance.payments",
    "zanox.finance.budgets",
    "zanox.finance.alerts",
    "zanox.finance.reports",
    "zanox.finance.investments",
    "zanox.finance.subscriptions",
    "zanox.finance.tax",
    "zanox.finance.audit",
]
