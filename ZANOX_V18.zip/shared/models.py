"""
ZANOX V18 Shared Financial Models
Base models used across all financial modules.
"""
from datetime import datetime, date
from decimal import Decimal
from enum import Enum
from typing import Optional, List, Dict, Any, Union
from uuid import UUID, uuid4
from pydantic import BaseModel, Field, ConfigDict


class Currency(str, Enum):
    USD = "USD"
    EUR = "EUR"
    GBP = "GBP"
    JPY = "JPY"
    CAD = "CAD"
    AUD = "AUD"
    CHF = "CHF"
    CNY = "CNY"
    BTC = "BTC"
    ETH = "ETH"


class TransactionType(str, Enum):
    INCOME = "income"
    EXPENSE = "expense"
    TRANSFER = "transfer"
    REFUND = "refund"
    ADJUSTMENT = "adjustment"
    INVESTMENT = "investment"
    DIVIDEND = "dividend"
    INTEREST = "interest"
    FEE = "fee"


class AccountType(str, Enum):
    ASSET = "asset"
    LIABILITY = "liability"
    EQUITY = "equity"
    REVENUE = "revenue"
    EXPENSE = "expense"


class PaymentMethod(str, Enum):
    CASH = "cash"
    CREDIT_CARD = "credit_card"
    DEBIT_CARD = "debit_card"
    BANK_TRANSFER = "bank_transfer"
    CHECK = "check"
    PAYPAL = "paypal"
    STRIPE = "stripe"
    WISE = "wise"
    PAYONEER = "payoneer"
    CRYPTO = "crypto"
    OTHER = "other"


class TransactionStatus(str, Enum):
    PENDING = "pending"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    REFUNDED = "refunded"
    DISPUTED = "disputed"


class FinancialEntity(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID = Field(default_factory=uuid4)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class Money(BaseModel):
    amount: Decimal = Field(..., ge=0)
    currency: Currency = Currency.USD

    def __add__(self, other: "Money") -> "Money":
        if self.currency != other.currency:
            raise ValueError("Cannot add different currencies without conversion")
        return Money(amount=self.amount + other.amount, currency=self.currency)

    def __sub__(self, other: "Money") -> "Money":
        if self.currency != other.currency:
            raise ValueError("Cannot subtract different currencies without conversion")
        return Money(amount=self.amount - other.amount, currency=self.currency)

    def __mul__(self, factor: Union[int, float, Decimal]) -> "Money":
        return Money(amount=self.amount * Decimal(str(factor)), currency=self.currency)

    def __truediv__(self, divisor: Union[int, float, Decimal]) -> "Money":
        return Money(amount=self.amount / Decimal(str(divisor)), currency=self.currency)

    def __lt__(self, other: "Money") -> bool:
        if self.currency != other.currency:
            raise ValueError("Cannot compare different currencies")
        return self.amount < other.amount

    def __gt__(self, other: "Money") -> bool:
        if self.currency != other.currency:
            raise ValueError("Cannot compare different currencies")
        return self.amount > other.amount

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Money):
            return False
        return self.amount == other.amount and self.currency == other.currency

    def to_dict(self) -> Dict[str, Any]:
        return {"amount": str(self.amount), "currency": self.currency.value}


class Address(BaseModel):
    street: str
    city: str
    state: Optional[str] = None
    postal_code: Optional[str] = None
    country: str


class ContactInfo(BaseModel):
    email: Optional[str] = None
    phone: Optional[str] = None
    address: Optional[Address] = None


class TaxInfo(BaseModel):
    tax_id: Optional[str] = None
    vat_number: Optional[str] = None
    tax_rate: Optional[Decimal] = None
    tax_jurisdiction: Optional[str] = None


class AuditLog(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    entity_type: str
    entity_id: UUID
    action: str
    performed_by: Optional[UUID] = None
    performed_at: datetime = Field(default_factory=datetime.utcnow)
    old_values: Dict[str, Any] = Field(default_factory=dict)
    new_values: Dict[str, Any] = Field(default_factory=dict)
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None


class PeriodFilter(BaseModel):
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    period_type: Optional[str] = None  # daily, weekly, monthly, quarterly, yearly


class PaginationParams(BaseModel):
    page: int = Field(default=1, ge=1)
    page_size: int = Field(default=20, ge=1, le=1000)
    sort_by: Optional[str] = None
    sort_order: str = Field(default="desc", pattern="^(asc|desc)$")


class PaginatedResponse(BaseModel):
    items: List[Any]
    total: int
    page: int
    page_size: int
    total_pages: int


class FinancialHealthScore(BaseModel):
    score: Decimal = Field(..., ge=0, le=100)
    category: str
    description: str
    recommendations: List[str] = Field(default_factory=list)


class RiskLevel(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class AlertSeverity(str, Enum):
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"
