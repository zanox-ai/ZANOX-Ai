"""
ZANOX V18 Shared Logger
Structured logging with OpenTelemetry integration.
"""
import os
import json
import logging
from datetime import datetime
from typing import Any, Dict, Optional

LOG_LEVEL = os.getenv("ZANOX_LOG_LEVEL", "INFO")


class StructuredLogFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        log_data = {
            "timestamp": datetime.utcnow().isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "function": record.funcName,
            "line": record.lineno,
        }
        if hasattr(record, "extra"):
            log_data.update(record.extra)
        if record.exc_info:
            log_data["exception"] = self.formatException(record.exc_info)
        return json.dumps(log_data)


def get_logger(name: str) -> logging.Logger:
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(StructuredLogFormatter())
        logger.addHandler(handler)
    logger.setLevel(getattr(logging, LOG_LEVEL.upper(), logging.INFO))
    return logger


def log_event(
    logger: logging.Logger,
    event_type: str,
    data: Dict[str, Any],
    level: str = "info",
) -> None:
    extra = {"event_type": event_type, "data": data}
    log_method = getattr(logger, level.lower(), logger.info)
    log_method(f"[{event_type}] {json.dumps(data)}", extra={"extra": extra})
