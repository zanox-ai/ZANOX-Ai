"""
ZANOX V18 Shared Utilities
Common helper functions for the Finance Layer.
"""
import uuid
import hashlib
from datetime import datetime, date, timedelta
from decimal import Decimal, ROUND_HALF_UP
from typing import Any, Dict, List, Optional, Union


def generate_uuid() -> uuid.UUID:
    return uuid.uuid4()


def generate_reference(prefix: str = "ZAN") -> str:
    timestamp = datetime.utcnow().strftime("%Y%m%d%H%M%S")
    random_part = hashlib.sha256(str(uuid.uuid4()).encode()).hexdigest()[:8].upper()
    return f"{prefix}-{timestamp}-{random_part}"


def format_currency(amount: Decimal, currency: str = "USD") -> str:
    symbols = {"USD": "$", "EUR": "€", "GBP": "£", "JPY": "¥", "BTC": "₿", "ETH": "Ξ"}
    symbol = symbols.get(currency, currency)
    formatted = f"{amount:,.2f}"
    return f"{symbol}{formatted} {currency}"


def round_decimal(value: Decimal, precision: int = 2) -> Decimal:
    return value.quantize(Decimal("0.01") ** (precision // 2), rounding=ROUND_HALF_UP)


def get_fiscal_year_start(year: Optional[int] = None) -> date:
    if year is None:
        year = datetime.utcnow().year
    return date(year, 1, 1)


def get_fiscal_year_end(year: Optional[int] = None) -> date:
    if year is None:
        year = datetime.utcnow().year
    return date(year, 12, 31)


def get_month_start(d: Optional[date] = None) -> date:
    if d is None:
        d = date.today()
    return date(d.year, d.month, 1)


def get_month_end(d: Optional[date] = None) -> date:
    if d is None:
        d = date.today()
    if d.month == 12:
        return date(d.year + 1, 1, 1) - timedelta(days=1)
    return date(d.year, d.month + 1, 1) - timedelta(days=1)


def get_quarter_start(d: Optional[date] = None) -> date:
    if d is None:
        d = date.today()
    quarter = (d.month - 1) // 3 + 1
    return date(d.year, 3 * quarter - 2, 1)


def get_quarter_end(d: Optional[date] = None) -> date:
    if d is None:
        d = date.today()
    quarter = (d.month - 1) // 3 + 1
    if quarter == 4:
        return date(d.year + 1, 1, 1) - timedelta(days=1)
    return date(d.year, 3 * quarter + 1, 1) - timedelta(days=1)


def days_between(start: date, end: date) -> int:
    return (end - start).days


def calculate_percentage(part: Decimal, whole: Decimal) -> Decimal:
    if whole == 0:
        return Decimal("0")
    return (part / whole) * 100


def calculate_growth_rate(current: Decimal, previous: Decimal) -> Decimal:
    if previous == 0:
        return Decimal("0")
    return ((current - previous) / previous) * 100


def calculate_cagr(beginning_value: Decimal, ending_value: Decimal, periods: int) -> Decimal:
    if beginning_value <= 0 or periods <= 0:
        return Decimal("0")
    return ((ending_value / beginning_value) ** (Decimal("1") / periods) - 1) * 100


def calculate_compound_interest(
    principal: Decimal, rate: Decimal, periods: int, frequency: int = 1
) -> Decimal:
    return principal * ((1 + rate / (100 * frequency)) ** (frequency * periods))


def chunk_list(lst: List[Any], size: int) -> List[List[Any]]:
    return [lst[i : i + size] for i in range(0, len(lst), size)]


def deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    result = base.copy()
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def sanitize_string(value: str, max_length: int = 255) -> str:
    cleaned = value.strip()
    return cleaned[:max_length]


def is_numeric(value: Any) -> bool:
    try:
        Decimal(str(value))
        return True
    except (ValueError, TypeError):
        return False


def safe_divide(numerator: Decimal, denominator: Decimal, default: Decimal = Decimal("0")) -> Decimal:
    try:
        if denominator == 0:
            return default
        return numerator / denominator
    except (ZeroDivisionError, TypeError):
        return default
