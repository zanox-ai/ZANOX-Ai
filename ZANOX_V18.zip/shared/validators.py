"""
ZANOX V18 Shared Validators
Common validation utilities for financial data.
"""
import re
from decimal import Decimal, InvalidOperation
from typing import Optional
from datetime import date


def validate_email(email: str) -> bool:
    pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
    return bool(re.match(pattern, email))


def validate_amount(amount: str) -> Optional[Decimal]:
    try:
        value = Decimal(amount)
        if value < 0:
            return None
        return value
    except (InvalidOperation, ValueError):
        return None


def validate_currency_code(code: str) -> bool:
    valid_codes = {"USD", "EUR", "GBP", "JPY", "CAD", "AUD", "CHF", "CNY", "BTC", "ETH"}
    return code.upper() in valid_codes


def validate_tax_id(tax_id: str, country: str = "US") -> bool:
    if country == "US":
        return bool(re.match(r"^\d{2}-\d{7}$", tax_id) or re.match(r"^\d{9}$", tax_id))
    return len(tax_id) >= 5


def validate_date_range(start: date, end: date) -> bool:
    return start <= end


def validate_iban(iban: str) -> bool:
    iban = iban.replace(" ", "").upper()
    if len(iban) < 15 or len(iban) > 34:
        return False
    country_code = iban[:2]
    if not country_code.isalpha():
        return False
    rearranged = iban[4:] + iban[:4]
    numeric = ""
    for char in rearranged:
        if char.isalpha():
            numeric += str(ord(char) - 55)
        else:
            numeric += char
    try:
        return int(numeric) % 97 == 1
    except ValueError:
        return False
