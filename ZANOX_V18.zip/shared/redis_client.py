"""
ZANOX V18 Shared Redis Client
Caching and pub/sub layer.
"""
import os
import json
from typing import Any, Optional, Union
from redis.asyncio import Redis

REDIS_URL = os.getenv("ZANOX_REDIS_URL", "redis://localhost:6379/0")

redis_client: Optional[Redis] = None


async def get_redis() -> Redis:
    global redis_client
    if redis_client is None:
        redis_client = Redis.from_url(REDIS_URL, decode_responses=True)
    return redis_client


async def cache_set(key: str, value: Any, ttl: int = 3600) -> None:
    r = await get_redis()
    await r.setex(key, ttl, json.dumps(value))


async def cache_get(key: str) -> Optional[Any]:
    r = await get_redis()
    data = await r.get(key)
    if data:
        return json.loads(data)
    return None


async def cache_delete(key: str) -> None:
    r = await get_redis()
    await r.delete(key)


async def cache_exists(key: str) -> bool:
    r = await get_redis()
    return await r.exists(key) > 0


async def publish_event(channel: str, message: dict) -> None:
    r = await get_redis()
    await r.publish(channel, json.dumps(message))
