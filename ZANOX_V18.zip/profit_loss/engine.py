"""
ZANOX V18 Profit & Loss Engine Core
"""
from typing import Dict, Any
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("profit_loss_engine")


class ProfitLossEngine:
    def __init__(self):
        self._generator = None

    async def initialize(self):
        from .generator import PnLGenerator
        self._generator = PnLGenerator()
        logger.info("ProfitLossEngine initialized")

    async def generate(self, user_id: UUID, start: date, end: date) -> Dict[str, Any]:
        if not self._generator:
            raise RuntimeError("Engine not initialized")
        return await self._generator.generate(user_id, start, end)

    async def shutdown(self):
        logger.info("ProfitLossEngine shut down")
