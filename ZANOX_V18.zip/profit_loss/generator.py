"""
ZANOX V18 P&L Generator
Builds detailed profit and loss statements.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.database import get_db_context
from shared.utils import safe_divide
from shared.logger import get_logger

logger = get_logger("pnl_generator")


class PnLGenerator:
    async def generate(self, user_id: UUID, start: date, end: date) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            revenue_query = text("""
                SELECT category, COALESCE(SUM(amount), 0) as total
                FROM revenue_records
                WHERE user_id = :user_id AND transaction_date BETWEEN :start AND :end
                GROUP BY category
                ORDER BY total DESC
            """)
            revenue_result = await session.execute(revenue_query, {
                "user_id": str(user_id), "start": start, "end": end
            })
            revenue_items = [dict(row) for row in revenue_result.mappings()]
            total_revenue = sum(Decimal(str(r["total"])) for r in revenue_items)

            cogs_query = text("""
                SELECT category, COALESCE(SUM(amount), 0) as total
                FROM expense_records
                WHERE user_id = :user_id AND category = 'cost_of_goods_sold'
                AND transaction_date BETWEEN :start AND :end
                GROUP BY category
            """)
            cogs_result = await session.execute(cogs_query, {
                "user_id": str(user_id), "start": start, "end": end
            })
            cogs_items = [dict(row) for row in cogs_result.mappings()]
            total_cogs = sum(Decimal(str(c["total"])) for c in cogs_items)

            opex_query = text("""
                SELECT category, COALESCE(SUM(amount), 0) as total
                FROM expense_records
                WHERE user_id = :user_id AND category != 'cost_of_goods_sold'
                AND transaction_date BETWEEN :start AND :end
                GROUP BY category
                ORDER BY total DESC
            """)
            opex_result = await session.execute(opex_query, {
                "user_id": str(user_id), "start": start, "end": end
            })
            opex_items = [dict(row) for row in opex_result.mappings()]
            total_opex = sum(Decimal(str(o["total"])) for o in opex_items)

            gross_profit = total_revenue - total_cogs
            operating_income = gross_profit - total_opex
            tax = operating_income * Decimal("0.25") if operating_income > 0 else Decimal("0")
            net_income = operating_income - tax

            return {
                "period": {"start": start.isoformat(), "end": end.isoformat()},
                "revenue": {
                    "items": revenue_items,
                    "total": float(total_revenue),
                },
                "cost_of_goods_sold": {
                    "items": cogs_items,
                    "total": float(total_cogs),
                },
                "gross_profit": float(gross_profit),
                "gross_margin_pct": float(safe_divide(gross_profit, total_revenue, Decimal("0")) * 100),
                "operating_expenses": {
                    "items": opex_items,
                    "total": float(total_opex),
                },
                "operating_income": float(operating_income),
                "operating_margin_pct": float(safe_divide(operating_income, total_revenue, Decimal("0")) * 100),
                "tax": float(tax),
                "net_income": float(net_income),
                "net_margin_pct": float(safe_divide(net_income, total_revenue, Decimal("0")) * 100),
            }
