"""
ZANOX V18 Accounting Engine Core
Manages the complete accounting lifecycle.
"""
from typing import Dict, Any, List, Optional
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.models import AccountType, Money
from shared.exceptions import ValidationError, ResourceNotFoundError
from shared.database import get_db_context
from shared.logger import get_logger

logger = get_logger("accounting_engine")


class AccountingEngine:
    def __init__(self):
        self._chart = None
        self._journal = None

    async def initialize(self):
        from .chart_of_accounts import ChartOfAccounts
        from .journal import JournalEntryManager
        self._chart = ChartOfAccounts()
        self._journal = JournalEntryManager()
        logger.info("AccountingEngine initialized")

    async def create_account(self, data: Dict[str, Any]) -> Dict[str, Any]:
        if not self._chart:
            raise RuntimeError("Engine not initialized")
        return await self._chart.create_account(data)

    async def get_account(self, account_id: UUID) -> Dict[str, Any]:
        if not self._chart:
            raise RuntimeError("Engine not initialized")
        return await self._chart.get_account(account_id)

    async def list_accounts(self, user_id: UUID, account_type: Optional[str] = None) -> List[Dict[str, Any]]:
        if not self._chart:
            raise RuntimeError("Engine not initialized")
        return await self._chart.list_accounts(user_id, account_type)

    async def create_journal_entry(self, data: Dict[str, Any]) -> Dict[str, Any]:
        if not self._journal:
            raise RuntimeError("Engine not initialized")
        return await self._journal.create_entry(data)

    async def get_trial_balance(self, user_id: UUID, as_of: date) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT account_id, account_name, account_type,
                       COALESCE(SUM(debit), 0) as total_debit,
                       COALESCE(SUM(credit), 0) as total_credit
                FROM journal_entries je
                JOIN accounts a ON a.id = je.account_id
                WHERE a.user_id = :user_id AND je.entry_date <= :as_of
                GROUP BY account_id, account_name, account_type
                ORDER BY account_type, account_name
            """)
            result = await session.execute(query, {"user_id": str(user_id), "as_of": as_of})
            rows = [dict(row) for row in result.mappings()]
            total_debit = sum(Decimal(str(r["total_debit"])) for r in rows)
            total_credit = sum(Decimal(str(r["total_credit"])) for r in rows)
            return {
                "as_of": as_of.isoformat(),
                "accounts": rows,
                "total_debit": float(total_debit),
                "total_credit": float(total_credit),
                "balanced": abs(total_debit - total_credit) < Decimal("0.01"),
            }

    async def get_balance_sheet(self, user_id: UUID, as_of: date) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            assets_query = text("""
                SELECT COALESCE(SUM(balance), 0) as total FROM accounts
                WHERE user_id = :user_id AND account_type = 'asset' AND created_at <= :as_of
            """)
            liabilities_query = text("""
                SELECT COALESCE(SUM(balance), 0) as total FROM accounts
                WHERE user_id = :user_id AND account_type = 'liability' AND created_at <= :as_of
            """)
            equity_query = text("""
                SELECT COALESCE(SUM(balance), 0) as total FROM accounts
                WHERE user_id = :user_id AND account_type = 'equity' AND created_at <= :as_of
            """)
            assets = await session.execute(assets_query, {"user_id": str(user_id), "as_of": as_of})
            liabilities = await session.execute(liabilities_query, {"user_id": str(user_id), "as_of": as_of})
            equity = await session.execute(equity_query, {"user_id": str(user_id), "as_of": as_of})
            total_assets = Decimal(str(assets.fetchone()[0]))
            total_liabilities = Decimal(str(liabilities.fetchone()[0]))
            total_equity = Decimal(str(equity.fetchone()[0]))
            return {
                "as_of": as_of.isoformat(),
                "assets": float(total_assets),
                "liabilities": float(total_liabilities),
                "equity": float(total_equity),
                "total_liabilities_and_equity": float(total_liabilities + total_equity),
                "balanced": abs(total_assets - (total_liabilities + total_equity)) < Decimal("0.01"),
            }

    async def shutdown(self):
        logger.info("AccountingEngine shut down")
