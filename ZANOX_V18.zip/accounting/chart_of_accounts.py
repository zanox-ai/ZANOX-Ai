"""
ZANOX V18 Chart of Accounts
Manages the hierarchical account structure.
"""
from typing import Dict, Any, List, Optional
from decimal import Decimal
from uuid import UUID

from shared.models import AccountType
from shared.exceptions import ValidationError, DuplicateEntryError
from shared.database import get_db_context
from shared.utils import generate_reference
from shared.logger import get_logger

logger = get_logger("chart_of_accounts")


class ChartOfAccounts:
    DEFAULT_ACCOUNTS = [
        {"name": "Cash", "type": "asset", "category": "current_asset"},
        {"name": "Bank Account", "type": "asset", "category": "current_asset"},
        {"name": "Accounts Receivable", "type": "asset", "category": "current_asset"},
        {"name": "Inventory", "type": "asset", "category": "current_asset"},
        {"name": "Equipment", "type": "asset", "category": "fixed_asset"},
        {"name": "Buildings", "type": "asset", "category": "fixed_asset"},
        {"name": "Accounts Payable", "type": "liability", "category": "current_liability"},
        {"name": "Loans Payable", "type": "liability", "category": "long_term_liability"},
        {"name": "Credit Card", "type": "liability", "category": "current_liability"},
        {"name": "Owner's Equity", "type": "equity", "category": "equity"},
        {"name": "Retained Earnings", "type": "equity", "category": "equity"},
        {"name": "Sales Revenue", "type": "revenue", "category": "operating_revenue"},
        {"name": "Service Revenue", "type": "revenue", "category": "operating_revenue"},
        {"name": "Cost of Goods Sold", "type": "expense", "category": "operating_expense"},
        {"name": "Rent Expense", "type": "expense", "category": "operating_expense"},
        {"name": "Salaries Expense", "type": "expense", "category": "operating_expense"},
        {"name": "Utilities Expense", "type": "expense", "category": "operating_expense"},
        {"name": "Marketing Expense", "type": "expense", "category": "operating_expense"},
    ]

    async def create_account(self, data: Dict[str, Any]) -> Dict[str, Any]:
        required = ["user_id", "name", "type"]
        for field in required:
            if field not in data:
                raise ValidationError(f"Missing required field: {field}")
        if data.get("type") not in [t.value for t in AccountType]:
            raise ValidationError(f"Invalid account type: {data.get('type')}")

        async with get_db_context() as session:
            from sqlalchemy import text
            check_query = text("""
                SELECT id FROM accounts WHERE user_id = :user_id AND name = :name
            """)
            existing = await session.execute(check_query, {
                "user_id": data["user_id"], "name": data["name"]
            })
            if existing.fetchone():
                raise DuplicateEntryError(f"Account '{data['name']}' already exists")

            insert_query = text("""
                INSERT INTO accounts (id, user_id, name, account_type, category, description,
                balance, currency, parent_account_id, account_number, is_active, created_at, updated_at)
                VALUES (gen_random_uuid(), :user_id, :name, :type, :category, :description,
                :balance, :currency, :parent_account_id, :account_number, true, NOW(), NOW())
                RETURNING id
            """)
            result = await session.execute(insert_query, {
                "user_id": data["user_id"],
                "name": data["name"],
                "type": data["type"],
                "category": data.get("category", ""),
                "description": data.get("description", ""),
                "balance": str(data.get("balance", 0)),
                "currency": data.get("currency", "USD"),
                "parent_account_id": data.get("parent_account_id"),
                "account_number": data.get("account_number", generate_reference("ACC")),
            })
            row = result.fetchone()
            account_id = str(row[0])
            logger.info(f"Created account: {account_id} - {data['name']}")
            return {"id": account_id, "name": data["name"], "type": data["type"]}

    async def get_account(self, account_id: UUID) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("SELECT * FROM accounts WHERE id = :id")
            result = await session.execute(query, {"id": str(account_id)})
            row = result.mappings().fetchone()
            if not row:
                raise ValidationError("Account not found")
            return dict(row)

    async def list_accounts(self, user_id: UUID, account_type: Optional[str] = None) -> List[Dict[str, Any]]:
        async with get_db_context() as session:
            from sqlalchemy import text
            if account_type:
                query = text("""
                    SELECT * FROM accounts WHERE user_id = :user_id AND account_type = :type AND is_active = true
                    ORDER BY account_type, name
                """)
                result = await session.execute(query, {"user_id": str(user_id), "type": account_type})
            else:
                query = text("""
                    SELECT * FROM accounts WHERE user_id = :user_id AND is_active = true
                    ORDER BY account_type, name
                """)
                result = await session.execute(query, {"user_id": str(user_id)})
            return [dict(row) for row in result.mappings()]

    async def setup_default_accounts(self, user_id: UUID) -> List[Dict[str, Any]]:
        created = []
        for account in self.DEFAULT_ACCOUNTS:
            data = {"user_id": str(user_id), **account}
            try:
                result = await self.create_account(data)
                created.append(result)
            except DuplicateEntryError:
                pass
        logger.info(f"Setup {len(created)} default accounts for user {user_id}")
        return created

    async def deactivate_account(self, account_id: UUID) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                UPDATE accounts SET is_active = false, updated_at = NOW() WHERE id = :id
                RETURNING id, name, is_active
            """)
            result = await session.execute(query, {"id": str(account_id)})
            row = result.mappings().fetchone()
            if not row:
                raise ValidationError("Account not found")
            return dict(row)
