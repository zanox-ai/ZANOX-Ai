"""
ZANOX V18 Journal Entry Manager
Handles double-entry journal postings with full audit trail.
"""
from typing import Dict, Any, List
from decimal import Decimal
from uuid import UUID
from datetime import date

from shared.exceptions import ValidationError, InvalidTransactionError
from shared.database import get_db_context
from shared.utils import generate_reference
from shared.logger import get_logger

logger = get_logger("journal_manager")


class JournalEntryManager:
    async def create_entry(self, data: Dict[str, Any]) -> Dict[str, Any]:
        required = ["user_id", "entries", "entry_date"]
        for field in required:
            if field not in data:
                raise ValidationError(f"Missing required field: {field}")

        entries = data["entries"]
        if len(entries) < 2:
            raise ValidationError("Journal entry requires at least 2 lines")

        total_debit = sum(Decimal(str(e["debit"])) for e in entries if e.get("debit"))
        total_credit = sum(Decimal(str(e["credit"])) for e in entries if e.get("credit"))
        if abs(total_debit - total_credit) > Decimal("0.01"):
            raise InvalidTransactionError(f"Debits ({total_debit}) != Credits ({total_credit})")

        reference = generate_reference("JE")
        async with get_db_context() as session:
            from sqlalchemy import text
            header_query = text("""
                INSERT INTO journal_entry_headers (id, user_id, reference, entry_date, description, created_at)
                VALUES (gen_random_uuid(), :user_id, :reference, :entry_date, :description, NOW())
                RETURNING id
            """)
            header_result = await session.execute(header_query, {
                "user_id": data["user_id"],
                "reference": reference,
                "entry_date": data["entry_date"],
                "description": data.get("description", ""),
            })
            header_id = str(header_result.fetchone()[0])

            line_query = text("""
                INSERT INTO journal_entries (id, header_id, account_id, debit, credit, description, entry_date, created_at)
                VALUES (gen_random_uuid(), :header_id, :account_id, :debit, :credit, :description, :entry_date, NOW())
            """)
            for entry in entries:
                await session.execute(line_query, {
                    "header_id": header_id,
                    "account_id": entry["account_id"],
                    "debit": str(entry.get("debit", 0) or 0),
                    "credit": str(entry.get("credit", 0) or 0),
                    "description": entry.get("description", ""),
                    "entry_date": data["entry_date"],
                })

            logger.info(f"Created journal entry: {reference} with {len(entries)} lines")
            return {
                "header_id": header_id,
                "reference": reference,
                "total_debit": float(total_debit),
                "total_credit": float(total_credit),
                "line_count": len(entries),
            }

    async def get_entries_by_account(self, account_id: UUID, start: date, end: date) -> List[Dict[str, Any]]:
        async with get_db_context() as session:
            from sqlalchemy import text
            query = text("""
                SELECT je.*, jeh.reference, jeh.description as header_description
                FROM journal_entries je
                JOIN journal_entry_headers jeh ON jeh.id = je.header_id
                WHERE je.account_id = :account_id AND je.entry_date BETWEEN :start AND :end
                ORDER BY je.entry_date DESC
            """)
            result = await session.execute(query, {
                "account_id": str(account_id), "start": start, "end": end
            })
            return [dict(row) for row in result.mappings()]

    async def reverse_entry(self, header_id: UUID, reason: str) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            original_query = text("""
                SELECT * FROM journal_entries WHERE header_id = :header_id
            """)
            result = await session.execute(original_query, {"header_id": str(header_id)})
            original_entries = [dict(row) for row in result.mappings()]

            if not original_entries:
                raise ValidationError("Original journal entry not found")

            reversed_entries = []
            for entry in original_entries:
                reversed_entries.append({
                    "account_id": entry["account_id"],
                    "debit": entry["credit"],
                    "credit": entry["debit"],
                    "description": f"Reversal of {entry.get('description', '')}: {reason}",
                })

            reversal_data = {
                "user_id": original_entries[0].get("user_id", ""),
                "entries": reversed_entries,
                "entry_date": date.today(),
                "description": f"Reversal of entry {header_id}: {reason}",
            }
            return await self.create_entry(reversal_data)
