"""
ZANOX V18 Wealth Management API
"""
from fastapi import APIRouter
from uuid import UUID

from .engine import WealthEngine

router = APIRouter(prefix="/wealth", tags=["wealth"])
engine = WealthEngine()


@router.get("/overview/{user_id}")
async def get_overview(user_id: UUID):
    return await engine.get_wealth_overview(user_id)


@router.get("/projection/{user_id}")
async def get_projection(user_id: UUID, years: int = 20):
    return await engine.get_wealth_projection(user_id, years)


@router.get("/recommendations/{user_id}")
async def get_recommendations(user_id: UUID):
    return await engine.get_wealth_recommendations(user_id)
