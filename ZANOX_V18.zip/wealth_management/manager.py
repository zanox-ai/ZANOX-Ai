"""
ZANOX V18 Wealth Manager
Comprehensive wealth management with goal tracking.
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date, timedelta
from uuid import UUID

from shared.database import get_db_context
from shared.utils import calculate_compound_interest, safe_divide
from shared.logger import get_logger

logger = get_logger("wealth_manager")


class WealthManager:
    async def get_overview(self, user_id: UUID) -> Dict[str, Any]:
        async with get_db_context() as session:
            from sqlalchemy import text
            assets_query = text("SELECT COALESCE(SUM(balance), 0) as total FROM accounts WHERE user_id = :user_id AND account_type = 'asset'")
            liabilities_query = text("SELECT COALESCE(SUM(balance), 0) as total FROM accounts WHERE user_id = :user_id AND account_type = 'liability'")
            investment_query = text("SELECT COALESCE(SUM(total_amount), 0) as total FROM investment_trades WHERE user_id = :user_id AND status = 'completed'")
            crypto_query = text("SELECT COALESCE(SUM(quantity * current_price), 0) as total FROM crypto_holdings WHERE user_id = :user_id")
            stock_query = text("SELECT COALESCE(SUM(quantity * current_price), 0) as total FROM stock_holdings WHERE user_id = :user_id")

            assets = Decimal(str((await session.execute(assets_query, {"user_id": str(user_id)})).fetchone()[0]))
            liabilities = Decimal(str((await session.execute(liabilities_query, {"user_id": str(user_id)})).fetchone()[0]))
            investments = Decimal(str((await session.execute(investment_query, {"user_id": str(user_id)})).fetchone()[0]))
            crypto = Decimal(str((await session.execute(crypto_query, {"user_id": str(user_id)})).fetchone()[0]))
            stocks = Decimal(str((await session.execute(stock_query, {"user_id": str(user_id)})).fetchone()[0]))

        net_worth = assets - liabilities
        total_wealth = net_worth + investments + crypto + stocks

        return {
            "user_id": str(user_id),
            "as_of": date.today().isoformat(),
            "assets": float(assets.quantize(Decimal("0.01"))),
            "liabilities": float(liabilities.quantize(Decimal("0.01"))),
            "net_worth": float(net_worth.quantize(Decimal("0.01"))),
            "investments": float(investments.quantize(Decimal("0.01"))),
            "crypto": float(crypto.quantize(Decimal("0.01"))),
            "stocks": float(stocks.quantize(Decimal("0.01"))),
            "total_wealth": float(total_wealth.quantize(Decimal("0.01"))),
        }

    async def project(self, user_id: UUID, years: int = 20) -> List[Dict[str, Any]]:
        overview = await self.get_overview(user_id)
        current_wealth = Decimal(str(overview["total_wealth"]))
        annual_return = Decimal("7")
        annual_contribution = Decimal("10000")
        projections = []
        for year in range(1, years + 1):
            future_value = calculate_compound_interest(current_wealth, annual_return, year)
            contribution_growth = calculate_compound_interest(annual_contribution, annual_return, year)
            total = future_value + contribution_growth
            projections.append({
                "year": date.today().year + year,
                "projected_wealth": float(total.quantize(Decimal("0.01"))),
                "growth_from_investments": float((future_value - current_wealth).quantize(Decimal("0.01"))),
                "growth_from_contributions": float((contribution_growth - annual_contribution * year).quantize(Decimal("0.01"))),
            })
        return projections

    async def get_recommendations(self, user_id: UUID) -> List[Dict[str, Any]]:
        overview = await self.get_overview(user_id)
        recommendations = []
        net_worth = Decimal(str(overview["net_worth"]))
        total_wealth = Decimal(str(overview["total_wealth"]))
        crypto_pct = safe_divide(Decimal(str(overview["crypto"])), total_wealth, Decimal("0")) * 100
        stock_pct = safe_divide(Decimal(str(overview["stocks"])), total_wealth, Decimal("0")) * 100

        if crypto_pct > 20:
            recommendations.append({
                "type": "rebalance",
                "message": f"Crypto allocation is {float(crypto_pct):.1f}%. Consider reducing to 5-10%.",
                "priority": "high",
            })
        if stock_pct < 30 and total_wealth > 50000:
            recommendations.append({
                "type": "diversify",
                "message": "Stock allocation is low. Consider increasing equity exposure for growth.",
                "priority": "medium",
            })
        if net_worth < 0:
            recommendations.append({
                "type": "debt_reduction",
                "message": "Negative net worth. Focus on debt elimination before investing.",
                "priority": "critical",
            })
        return recommendations
