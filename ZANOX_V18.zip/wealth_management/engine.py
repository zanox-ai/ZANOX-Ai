"""
ZANOX V18 Wealth Management Engine Core
"""
from typing import Dict, Any, List
from decimal import Decimal
from datetime import date
from uuid import UUID

from shared.logger import get_logger

logger = get_logger("wealth_engine")


class WealthEngine:
    def __init__(self):
        self._manager = None

    async def initialize(self):
        from .manager import WealthManager
        self._manager = WealthManager()
        logger.info("WealthEngine initialized")

    async def get_wealth_overview(self, user_id: UUID) -> Dict[str, Any]:
        if not self._manager:
            raise RuntimeError("Engine not initialized")
        return await self._manager.get_overview(user_id)

    async def get_wealth_projection(self, user_id: UUID, years: int = 20) -> List[Dict[str, Any]]:
        if not self._manager:
            raise RuntimeError("Engine not initialized")
        return await self._manager.project(user_id, years)

    async def get_wealth_recommendations(self, user_id: UUID) -> List[Dict[str, Any]]:
        if not self._manager:
            raise RuntimeError("Engine not initialized")
        return await self._manager.get_recommendations(user_id)

    async def shutdown(self):
        logger.info("WealthEngine shut down")
