"""Discord Integration."""
from typing import Dict, List, Optional

class DiscordIntegration:
    def __init__(self, bot_token: Optional[str] = None):
        self.bot_token = bot_token
        self.connected = False

    async def connect(self, bot_token: str) -> bool:
        self.bot_token = bot_token
        self.connected = True
        return True

    async def send_message(self, channel_id: str, message: str) -> bool:
        if not self.connected:
            return False
        return True
