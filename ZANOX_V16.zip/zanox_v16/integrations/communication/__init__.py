"""Communication Integrations - Telegram, Gmail, Slack, Discord."""
from .telegram import TelegramIntegration
from .gmail import GmailIntegration
from .slack import SlackIntegration
from .discord import DiscordIntegration
