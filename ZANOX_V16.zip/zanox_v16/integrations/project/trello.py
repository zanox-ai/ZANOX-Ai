"""Trello Integration."""
from typing import Dict, List, Optional

class TrelloIntegration:
    def __init__(self, key: Optional[str] = None, token: Optional[str] = None):
        self.key = key
        self.token = token
        self.connected = False

    async def connect(self, key: str, token: str) -> bool:
        self.key = key
        self.token = token
        self.connected = True
        return True

    async def get_boards(self) -> List[Dict]:
        if not self.connected:
            return []
        return []
