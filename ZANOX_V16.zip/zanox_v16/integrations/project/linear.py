"""Linear Integration."""
from typing import Dict, List, Optional

class LinearIntegration:
    def __init__(self, token: Optional[str] = None):
        self.token = token
        self.connected = False

    async def connect(self, token: str) -> bool:
        self.token = token
        self.connected = True
        return True

    async def get_issues(self) -> List[Dict]:
        if not self.connected:
            return []
        return []
