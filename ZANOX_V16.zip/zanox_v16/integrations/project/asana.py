"""Asana Integration."""
from typing import Dict, List, Optional

class AsanaIntegration:
    def __init__(self, token: Optional[str] = None):
        self.token = token
        self.connected = False

    async def connect(self, token: str) -> bool:
        self.token = token
        self.connected = True
        return True

    async def get_tasks(self, project_id: Optional[str] = None) -> List[Dict]:
        if not self.connected:
            return []
        return []

    async def create_task(self, name: str, project_id: Optional[str] = None) -> Optional[str]:
        if not self.connected:
            return None
        return "asana-task-id"
