"""Obsidian Integration."""
import os
from typing import Dict, List, Optional

class ObsidianIntegration:
    def __init__(self, vault_path: Optional[str] = None):
        self.vault_path = vault_path

    async def get_notes(self) -> List[Dict]:
        if not self.vault_path or not os.path.exists(self.vault_path):
            return []
        notes = []
        for root, dirs, files in os.walk(self.vault_path):
            for f in files:
                if f.endswith(".md"):
                    fp = os.path.join(root, f)
                    notes.append({"path": fp, "name": f, "modified": os.path.getmtime(fp)})
        return notes

    async def create_note(self, title: str, content: str) -> str:
        if not self.vault_path:
            return ""
        filepath = os.path.join(self.vault_path, f"{title}.md")
        with open(filepath, "w") as f:
            f.write(content)
        return filepath
