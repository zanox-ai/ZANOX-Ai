"""
Productivity Recommender - Personalized Recommendations
Generates personalized productivity recommendations based on user patterns,
goals, and current state.
"""

import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any

import asyncpg
import redis.asyncio as redis


class ProductivityRecommender:
    """Generates personalized productivity recommendations."""

    def __init__(self):
        self.db_pool: Optional[asyncpg.Pool] = None
        self.redis: Optional[redis.Redis] = None

    def initialize(self, db_pool: asyncpg.Pool, redis_client: redis.Redis):
        self.db_pool = db_pool
        self.redis = redis_client

    async def get_recommendations(self, user_id: str, 
                                    score_data: Dict[str, Any]) -> List[Dict[str, str]]:
        """Get personalized productivity recommendations."""
        recommendations = []
        
        components = score_data.get("components", {})
        
        # Task completion recommendations
        task_comp = components.get("task_completion", {})
        if task_comp.get("score", 100) < 70:
            pending = task_comp.get("pending_tasks", 0)
            recommendations.append({
                "priority": "high",
                "category": "tasks",
                "title": f"Clear Task Backlog ({pending} pending)",
                "description": "You have tasks accumulating. Try the 2-minute rule: if a task takes under 2 minutes, do it now.",
                "action": "review_pending_tasks"
            })
        
        # Focus time recommendations
        focus = components.get("focus_time", {})
        if focus.get("score", 100) < 60:
            recommendations.append({
                "priority": "high",
                "category": "focus",
                "title": "Increase Deep Work Time",
                "description": f"You've logged {focus.get('total_hours', 0)} hours of focused work. Aim for at least 4 hours per day.",
                "action": "start_focus_session"
            })
        
        # Habit recommendations
        habit = components.get("habit_consistency", {})
        if habit.get("score", 100) < 60:
            recommendations.append({
                "priority": "medium",
                "category": "habits",
                "title": "Build Consistent Habits",
                "description": f"Habit consistency at {habit.get('score', 0):.0f}%. Try habit stacking: link a new habit to an existing one.",
                "action": "review_habits"
            })
        
        # Goal recommendations
        goal = components.get("goal_progress", {})
        if goal.get("score", 100) < 50:
            recommendations.append({
                "priority": "medium",
                "category": "goals",
                "title": "Advance Your Goals",
                "description": "Goal progress is below target. Break down goals into weekly milestones.",
                "action": "review_goals"
            })
        
        # Time management
        time_mgmt = components.get("time_management", {})
        if time_mgmt.get("score", 100) < 60:
            recommendations.append({
                "priority": "medium",
                "category": "schedule",
                "title": "Optimize Your Schedule",
                "description": "Try time blocking: assign specific time slots for different types of work.",
                "action": "optimize_schedule"
            })
        
        # Add proactive recommendations
        proactive = await self._get_proactive_recommendations()
        recommendations.extend(proactive)
        
        return sorted(recommendations, key=lambda r: 0 if r["priority"] == "high" else (1 if r["priority"] == "medium" else 2))

    async def _get_proactive_recommendations(self) -> List[Dict[str, str]]:
        """Get proactive recommendations based on patterns."""
        recommendations = []
        
        # Check for upcoming deadlines
        if self.db_pool:
            upcoming = await self.db_pool.fetch(
                """SELECT title, due_date
                   FROM tasks
                   WHERE due_date BETWEEN NOW() AND NOW() + INTERVAL '48 hours'
                   AND status NOT IN ('completed', 'cancelled')
                   ORDER BY due_date LIMIT 3"""
            )
            
            for task in upcoming:
                hours_remaining = int((task["due_date"] - datetime.utcnow()).total_seconds() / 3600)
                recommendations.append({
                    "priority": "high",
                    "category": "deadlines",
                    "title": f"Upcoming Deadline: {task['title']}",
                    "description": f"Due in {hours_remaining} hours. Prioritize this task.",
                    "action": "focus_on_task"
                })
        
        # Suggest review if it's been a while
        recommendations.append({
            "priority": "low",
            "category": "review",
            "title": "Weekly Review",
            "description": "Take 15 minutes to review your week. What's working? What needs adjustment?",
            "action": "start_weekly_review"
        })
        
        return recommendations
