"""
Productivity Analyzer - Pattern Detection and Analysis
Identifies productivity patterns, peak hours, bottlenecks, and trends.
"""

import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from collections import defaultdict

import asyncpg
import redis.asyncio as redis


class ProductivityAnalyzer:
    """Analyzes productivity patterns and generates insights."""

    def __init__(self):
        self.db_pool: Optional[asyncpg.Pool] = None
        self.redis: Optional[redis.Redis] = None

    def initialize(self, db_pool: asyncpg.Pool, redis_client: redis.Redis):
        self.db_pool = db_pool
        self.redis = redis_client

    async def analyze_patterns(self, user_id: str) -> Dict[str, Any]:
        """Analyze productivity patterns for a user."""
        cache_key = f"productivity_insights:{user_id}"
        
        if self.redis:
            cached = await self.redis.get(cache_key)
            if cached:
                return json.loads(cached)
        
        insights = {
            "peak_hours": await self._find_peak_hours(),
            "productive_days": await self._find_productive_days(),
            "bottlenecks": await self._identify_bottlenecks(),
            "task_patterns": await self._analyze_task_patterns(),
            "focus_patterns": await self._analyze_focus_patterns(),
            "recommendations": await self._generate_insight_recommendations()
        }
        
        if self.redis:
            await self.redis.setex(cache_key, 3600, json.dumps(insights, default=str))
        
        return insights

    async def _find_peak_hours(self) -> List[Dict[str, Any]]:
        """Find the most productive hours of the day."""
        if not self.db_pool:
            return []
        
        rows = await self.db_pool.fetch(
            """SELECT EXTRACT(HOUR FROM started_at) as hour,
                COUNT(*) as session_count,
                AVG(actual_duration_minutes) as avg_duration
               FROM focus_sessions
               WHERE started_at > NOW() - INTERVAL '30 days'
               GROUP BY EXTRACT(HOUR FROM started_at)
               ORDER BY session_count DESC LIMIT 5"""
        )
        
        return [
            {
                "hour": int(r["hour"]),
                "hour_formatted": f"{int(r['hour']):02d}:00",
                "session_count": r["session_count"],
                "avg_duration_minutes": round(r["avg_duration"] or 0, 1)
            }
            for r in rows
        ]

    async def _find_productive_days(self) -> List[Dict[str, Any]]:
        """Find the most productive days of the week."""
        if not self.db_pool:
            return []
        
        rows = await self.db_pool.fetch(
            """SELECT EXTRACT(DOW FROM started_at) as day_of_week,
                COUNT(*) as session_count,
                SUM(actual_duration_minutes) as total_minutes
               FROM focus_sessions
               WHERE started_at > NOW() - INTERVAL '30 days'
               GROUP BY EXTRACT(DOW FROM started_at)
               ORDER BY total_minutes DESC"""
        )
        
        days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
        return [
            {
                "day": days[int(r["day_of_week"])],
                "session_count": r["session_count"],
                "total_hours": round((r["total_minutes"] or 0) / 60, 1)
            }
            for r in rows
        ]

    async def _identify_bottlenecks(self) -> List[Dict[str, str]]:
        """Identify productivity bottlenecks."""
        if not self.db_pool:
            return []
        
        bottlenecks = []
        
        # Long-running tasks
        old_tasks = await self.db_pool.fetch(
            """SELECT title, created_at, priority
               FROM tasks
               WHERE status NOT IN ('completed', 'cancelled')
               AND created_at < NOW() - INTERVAL '14 days'
               ORDER BY created_at LIMIT 5"""
        )
        
        for t in old_tasks:
            bottlenecks.append({
                "type": "stale_task",
                "title": t["title"],
                "description": f"Task pending for {(datetime.utcnow() - t['created_at']).days} days"
            })
        
        # Missed deadlines
        missed = await self.db_pool.fetch(
            """SELECT title, due_date
               FROM tasks
               WHERE due_date < NOW() AND status NOT IN ('completed', 'cancelled')
               ORDER BY due_date LIMIT 5"""
        )
        
        for t in missed:
            bottlenecks.append({
                "type": "missed_deadline",
                "title": t["title"],
                "description": f"Overdue by {(datetime.utcnow() - t['due_date']).days} days"
            })
        
        return bottlenecks

    async def _analyze_task_patterns(self) -> Dict[str, Any]:
        """Analyze task completion patterns."""
        if not self.db_pool:
            return {}
        
        # Completion by priority
        priority_data = await self.db_pool.fetch(
            """SELECT priority,
                COUNT(*) FILTER (WHERE status = 'completed') as completed,
                COUNT(*) as total
               FROM tasks
               WHERE created_at > NOW() - INTERVAL '30 days'
               GROUP BY priority"""
        )
        
        priority_patterns = {}
        for r in priority_data:
            rate = (r["completed"] / max(r["total"], 1)) * 100
            priority_patterns[r["priority"]] = {
                "completion_rate": round(rate, 1),
                "total": r["total"],
                "completed": r["completed"]
            }
        
        # Average completion time by priority
        avg_times = await self.db_pool.fetch(
            """SELECT priority,
                AVG(EXTRACT(EPOCH FROM (updated_at - created_at))/3600) as avg_hours
               FROM tasks
               WHERE status = 'completed' AND created_at > NOW() - INTERVAL '30 days'
               GROUP BY priority"""
        )
        
        for r in avg_times:
            if r["priority"] in priority_patterns:
                priority_patterns[r["priority"]]["avg_completion_hours"] = round(r["avg_hours"] or 0, 1)
        
        return priority_patterns

    async def _analyze_focus_patterns(self) -> Dict[str, Any]:
        """Analyze focus session patterns."""
        if not self.db_pool:
            return {}
        
        rows = await self.db_pool.fetch(
            """SELECT mode,
                COUNT(*) as session_count,
                AVG(actual_duration_minutes) as avg_duration,
                AVG(interruptions) as avg_interruptions,
                AVG(rating) as avg_rating
               FROM focus_sessions
               WHERE started_at > NOW() - INTERVAL '30 days'
               GROUP BY mode"""
        )
        
        return {
            r["mode"]: {
                "session_count": r["session_count"],
                "avg_duration_minutes": round(r["avg_duration"] or 0, 1),
                "avg_interruptions": round(r["avg_interruptions"] or 0, 1),
                "avg_rating": round(r["avg_rating"] or 0, 1)
            }
            for r in rows
        }

    async def _generate_insight_recommendations(self) -> List[Dict[str, str]]:
        """Generate recommendations based on insights."""
        recommendations = []
        
        peak_hours = await self._find_peak_hours()
        if peak_hours:
            best_hour = peak_hours[0]["hour_formatted"]
            recommendations.append({
                "category": "scheduling",
                "title": "Schedule Deep Work During Peak Hours",
                "description": f"Your most productive time is around {best_hour}. Schedule your most important tasks then."
            })
        
        bottlenecks = await self._identify_bottlenecks()
        if bottlenecks:
            recommendations.append({
                "category": "task_management",
                "title": "Address Stale Tasks",
                "description": f"You have {len(bottlenecks)} tasks that have been pending for over 2 weeks. Consider breaking them down or delegating."
            })
        
        focus_patterns = await self._analyze_focus_patterns()
        pomodoro_data = focus_patterns.get("pomodoro", {})
        if pomodoro_data and pomodoro_data.get("avg_rating", 0) < 3:
            recommendations.append({
                "category": "focus",
                "title": "Optimize Focus Sessions",
                "description": "Your focus session ratings are below average. Try shorter sessions or eliminate distractions."
            })
        
        return recommendations
