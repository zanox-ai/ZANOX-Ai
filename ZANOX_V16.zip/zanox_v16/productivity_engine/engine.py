"""
Productivity Engine - Core Productivity Optimization
Provides analytics, insights, optimization recommendations, and scoring
for personal productivity across all ZANOX V16 subsystems.
"""

import json
import math
from datetime import datetime, date, timedelta
from typing import Dict, List, Optional, Any, Tuple

import asyncpg
import redis.asyncio as redis

from .analyzer import ProductivityAnalyzer
from .optimizer import ProductivityOptimizer
from .recommender import ProductivityRecommender


class ProductivityEngine:
    """
    Core productivity engine that analyzes user activity across all
    ZANOX V16 subsystems and provides optimization recommendations.
    """

    def __init__(self):
        self.db_pool: Optional[asyncpg.Pool] = None
        self.redis: Optional[redis.Redis] = None
        self.analyzer = ProductivityAnalyzer()
        self.optimizer = ProductivityOptimizer()
        self.recommender = ProductivityRecommender()

    async def initialize(self, db_pool: asyncpg.Pool, redis_client: redis.Redis):
        """Initialize the productivity engine."""
        self.db_pool = db_pool
        self.redis = redis_client
        self.analyzer.initialize(db_pool, redis_client)
        self.optimizer.initialize(db_pool, redis_client)
        self.recommender.initialize(db_pool, redis_client)

    async def calculate_productivity_score(self, user_id: str, 
                                            period_days: int = 7) -> Dict[str, Any]:
        """
        Calculate an overall productivity score for a user.
        
        Score components:
        - Task completion rate (25%)
        - Focus/deep work time (25%)
        - Habit consistency (20%)
        - Goal progress (15%)
        - Time management (15%)
        """
        cache_key = f"productivity_score:{user_id}:{period_days}"
        
        if self.redis:
            cached = await self.redis.get(cache_key)
            if cached:
                return json.loads(cached)
        
        if not self.db_pool:
            return {"score": 0, "components": {}}
        
        start_date = datetime.utcnow() - timedelta(days=period_days)
        
        # Task completion rate
        task_stats = await self.db_pool.fetchrow(
            """SELECT 
                COUNT(*) FILTER (WHERE status = 'completed' AND updated_at >= $1) as completed,
                COUNT(*) FILTER (WHERE created_at >= $1) as created,
                COUNT(*) FILTER (WHERE status NOT IN ('completed', 'cancelled')) as pending,
                AVG(EXTRACT(EPOCH FROM (updated_at - created_at))/3600) FILTER (WHERE status = 'completed') as avg_completion_hours
               FROM tasks
               WHERE assigned_to = $2 OR assigned_to IS NULL""",
            start_date, user_id
        )
        
        completed = task_stats["completed"] or 0
        created = max(task_stats["created"] or 0, 1)
        task_score = min(completed / max(created * 0.8, 1), 1.0) * 100
        
        # Focus time
        focus_stats = await self.db_pool.fetchrow(
            """SELECT 
                COALESCE(SUM(actual_duration_minutes), 0) as total_minutes,
                COUNT(*) as session_count
               FROM focus_sessions
               WHERE started_at >= $1""",
            start_date
        )
        
        focus_hours = (focus_stats["total_minutes"] or 0) / 60
        focus_score = min(focus_hours / (period_days * 4), 1.0) * 100
        
        # Habit consistency
        habit_stats = await self.db_pool.fetchrow(
            """SELECT 
                COUNT(DISTINCT hl.habit_id) as habits_tracked,
                COUNT(*) as total_logs,
                (SELECT COUNT(*) FROM habits WHERE active = true) as active_habits
               FROM habit_logs hl
               JOIN habits h ON hl.habit_id = h.id
               WHERE hl.completed_at >= $1 AND h.active = true""",
            start_date
        )
        
        active_habits = max(habit_stats["active_habits"] or 0, 1)
        expected_logs = active_habits * period_days
        habit_score = min((habit_stats["total_logs"] or 0) / max(expected_logs * 0.7, 1), 1.0) * 100
        
        # Goal progress
        goal_stats = await self.db_pool.fetchrow(
            """SELECT AVG(progress_percentage) as avg_progress
               FROM goals
               WHERE status IN ('active', 'in_progress')"""
        )
        
        goal_score = min((goal_stats["avg_progress"] or 0), 100)
        
        # Time management (schedule adherence)
        schedule_score = await self._calculate_schedule_adherence(start_date)
        
        # Weighted composite score
        composite = (
            task_score * 0.25 +
            focus_score * 0.25 +
            habit_score * 0.20 +
            goal_score * 0.15 +
            schedule_score * 0.15
        )
        
        result = {
            "score": round(composite, 1),
            "grade": self._score_to_grade(composite),
            "period_days": period_days,
            "calculated_at": datetime.utcnow().isoformat(),
            "components": {
                "task_completion": {
                    "score": round(task_score, 1),
                    "weight": 0.25,
                    "completed_tasks": completed,
                    "created_tasks": task_stats["created"] or 0,
                    "pending_tasks": task_stats["pending"] or 0
                },
                "focus_time": {
                    "score": round(focus_score, 1),
                    "weight": 0.25,
                    "total_hours": round(focus_hours, 1),
                    "session_count": focus_stats["session_count"] or 0
                },
                "habit_consistency": {
                    "score": round(habit_score, 1),
                    "weight": 0.20,
                    "active_habits": active_habits,
                    "logs_count": habit_stats["total_logs"] or 0
                },
                "goal_progress": {
                    "score": round(goal_score, 1),
                    "weight": 0.15,
                    "average_progress": round(goal_score, 1)
                },
                "time_management": {
                    "score": round(schedule_score, 1),
                    "weight": 0.15
                }
            }
        }
        
        if self.redis:
            await self.redis.setex(cache_key, 3600, json.dumps(result))
        
        return result

    async def _calculate_schedule_adherence(self, start_date: datetime) -> float:
        """Calculate how well the user adheres to their schedule."""
        if not self.db_pool:
            return 50.0
        
        # Compare planned vs actual task completion within scheduled time blocks
        planned = await self.db_pool.fetchval(
            """SELECT COUNT(*) FROM calendar_events
               WHERE start_time >= $1 AND event_type IN ('task', 'focus')""",
            start_date
        ) or 0
        
        completed_on_time = await self.db_pool.fetchval(
            """SELECT COUNT(*) FROM tasks t
               JOIN calendar_events e ON t.id = e.linked_task_id
               WHERE t.status = 'completed' AND t.updated_at <= e.end_time
               AND e.start_time >= $1""",
            start_date
        ) or 0
        
        if planned == 0:
            return 70.0
        
        return min((completed_on_time / planned) * 100, 100)

    def _score_to_grade(self, score: float) -> str:
        """Convert numeric score to letter grade."""
        if score >= 90:
            return "A"
        elif score >= 80:
            return "B"
        elif score >= 70:
            return "C"
        elif score >= 60:
            return "D"
        else:
            return "F"

    async def get_weekly_report(self, user_id: str) -> Dict[str, Any]:
        """Generate a comprehensive weekly productivity report."""
        week_start = datetime.utcnow() - timedelta(days=datetime.utcnow().weekday())
        week_start = week_start.replace(hour=0, minute=0, second=0, microsecond=0)
        week_end = week_start + timedelta(days=7)
        
        score_data = await self.calculate_productivity_score(user_id, 7)
        
        # Daily breakdown
        daily_breakdown = []
        for i in range(7):
            day = week_start + timedelta(days=i)
            day_data = await self._get_day_stats(day)
            daily_breakdown.append({
                "date": day.isoformat(),
                "day_name": day.strftime("%A"),
                **day_data
            })
        
        # Trend (compare to previous week)
        prev_week_start = week_start - timedelta(days=7)
        prev_score = await self._get_period_score(prev_week_start, week_start)
        current_score = score_data["score"]
        trend = current_score - prev_score
        
        # Top achievements
        achievements = await self._get_weekly_achievements(week_start, week_end)
        
        # Recommendations
        recommendations = await self.recommender.get_recommendations(user_id, score_data)
        
        return {
            "period": {
                "start": week_start.isoformat(),
                "end": week_end.isoformat()
            },
            "overall_score": score_data["score"],
            "grade": score_data["grade"],
            "trend": round(trend, 1),
            "daily_breakdown": daily_breakdown,
            "components": score_data["components"],
            "achievements": achievements,
            "recommendations": recommendations,
            "generated_at": datetime.utcnow().isoformat()
        }

    async def _get_day_stats(self, day: datetime) -> Dict[str, Any]:
        """Get productivity stats for a specific day."""
        if not self.db_pool:
            return {}
        
        next_day = day + timedelta(days=1)
        
        tasks_completed = await self.db_pool.fetchval(
            "SELECT COUNT(*) FROM tasks WHERE status = 'completed' AND DATE(updated_at) = DATE($1)",
            day
        ) or 0
        
        focus_minutes = await self.db_pool.fetchval(
            "SELECT COALESCE(SUM(actual_duration_minutes), 0) FROM focus_sessions WHERE DATE(started_at) = DATE($1)",
            day
        ) or 0
        
        habits_done = await self.db_pool.fetchval(
            "SELECT COUNT(*) FROM habit_logs WHERE DATE(completed_at) = DATE($1)",
            day
        ) or 0
        
        events_count = await self.db_pool.fetchval(
            "SELECT COUNT(*) FROM calendar_events WHERE DATE(start_time) = DATE($1)",
            day
        ) or 0
        
        return {
            "tasks_completed": tasks_completed,
            "focus_minutes": focus_minutes,
            "focus_hours": round(focus_minutes / 60, 1),
            "habits_completed": habits_done,
            "events_count": events_count
        }

    async def _get_period_score(self, start: datetime, end: datetime) -> float:
        """Get average productivity score for a period."""
        score_data = await self.calculate_productivity_score("default", min(7, (end - start).days))
        return score_data["score"]

    async def _get_weekly_achievements(self, week_start: datetime, 
                                        week_end: datetime) -> List[Dict[str, str]]:
        """Get list of achievements for the week."""
        if not self.db_pool:
            return []
        
        achievements = []
        
        # Task milestones
        tasks_done = await self.db_pool.fetchval(
            "SELECT COUNT(*) FROM tasks WHERE status = 'completed' AND updated_at >= $1 AND updated_at < $2",
            week_start, week_end
        ) or 0
        
        if tasks_done >= 10:
            achievements.append({
                "type": "task_milestone",
                "title": "Task Master",
                "description": f"Completed {tasks_done} tasks this week"
            })
        
        # Focus milestones
        focus_min = await self.db_pool.fetchval(
            "SELECT COALESCE(SUM(actual_duration_minutes), 0) FROM focus_sessions WHERE started_at >= $1 AND started_at < $2",
            week_start, week_end
        ) or 0
        
        if focus_min >= 600:
            achievements.append({
                "type": "focus_milestone",
                "title": "Deep Worker",
                "description": f"{focus_min // 60} hours of focused work"
            })
        
        # Habit streak
        streak_data = await self.db_pool.fetch(
            """SELECT h.name, h.current_streak
               FROM habits h
               WHERE h.current_streak >= 7
               ORDER BY h.current_streak DESC LIMIT 3"""
        )
        
        for row in streak_data:
            achievements.append({
                "type": "habit_streak",
                "title": f"{row['name']} Streak",
                "description": f"{row['current_streak']} day streak!"
            })
        
        return achievements

    async def get_productivity_insights(self, user_id: str) -> Dict[str, Any]:
        """Get AI-powered productivity insights and patterns."""
        return await self.analyzer.analyze_patterns(user_id)

    async def optimize_schedule(self, user_id: str, date: Optional[date] = None) -> Dict[str, Any]:
        """Get schedule optimization recommendations."""
        return await self.optimizer.optimize_daily_schedule(user_id, date)
