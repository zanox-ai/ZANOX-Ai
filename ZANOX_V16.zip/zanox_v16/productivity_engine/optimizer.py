"""
Productivity Optimizer - Schedule and Task Optimization
Provides AI-powered schedule optimization, task batching, and time blocking.
"""

import json
from datetime import datetime, date, timedelta, time
from typing import Dict, List, Optional, Any

import asyncpg
import redis.asyncio as redis


class ProductivityOptimizer:
    """Optimizes schedules and tasks for maximum productivity."""

    def __init__(self):
        self.db_pool: Optional[asyncpg.Pool] = None
        self.redis: Optional[redis.Redis] = None

    def initialize(self, db_pool: asyncpg.Pool, redis_client: redis.Redis):
        self.db_pool = db_pool
        self.redis = redis_client

    async def optimize_daily_schedule(self, user_id: str, 
                                       target_date: Optional[date] = None) -> Dict[str, Any]:
        """
        Optimize the daily schedule by:
        1. Identifying peak productivity hours
        2. Matching task difficulty to energy levels
        3. Minimizing context switching
        4. Ensuring adequate breaks
        """
        if not target_date:
            target_date = date.today()
        
        # Get existing commitments
        existing_events = await self._get_existing_events(target_date)
        
        # Get prioritized tasks
        prioritized_tasks = await self._get_prioritized_tasks(user_id)
        
        # Get energy curve (peak hours)
        energy_curve = await self._get_energy_curve()
        
        # Build optimized schedule
        schedule_blocks = self._build_optimized_schedule(
            existing_events, prioritized_tasks, energy_curve, target_date
        )
        
        return {
            "date": target_date.isoformat(),
            "schedule_blocks": schedule_blocks,
            "total_focus_time": sum(b["duration_minutes"] for b in schedule_blocks if b["type"] == "focus"),
            "total_tasks_scheduled": len([b for b in schedule_blocks if b.get("task_id")]),
            "breaks_scheduled": len([b for b in schedule_blocks if b["type"] == "break"]),
            "rationale": self._generate_schedule_rationale(schedule_blocks, energy_curve)
        }

    async def _get_existing_events(self, target_date: date) -> List[Dict[str, Any]]:
        """Get existing calendar events for the date."""
        if not self.db_pool:
            return []
        
        rows = await self.db_pool.fetch(
            """SELECT id, title, start_time, end_time, event_type
               FROM calendar_events
               WHERE DATE(start_time) = $1
               ORDER BY start_time""",
            target_date
        )
        return [dict(r) for r in rows]

    async def _get_prioritized_tasks(self, user_id: str) -> List[Dict[str, Any]]:
        """Get tasks prioritized by urgency and importance."""
        if not self.db_pool:
            return []
        
        rows = await self.db_pool.fetch(
            """SELECT id, title, priority, estimated_duration_minutes, 
                due_date, description
               FROM tasks
               WHERE status NOT IN ('completed', 'cancelled')
               AND (due_date IS NULL OR due_date <= NOW() + INTERVAL '7 days')
               ORDER BY 
                 CASE priority 
                   WHEN 'urgent' THEN 1 
                   WHEN 'high' THEN 2 
                   WHEN 'medium' THEN 3 
                   WHEN 'low' THEN 4 
                   ELSE 5 
                 END,
                 COALESCE(due_date, '9999-12-31'::timestamp)
               LIMIT 10"""
        )
        return [dict(r) for r in rows]

    async def _get_energy_curve(self) -> List[int]:
        """Get the user's energy curve (productivity by hour)."""
        if not self.db_pool:
            return [3] * 24
        
        rows = await self.db_pool.fetch(
            """SELECT EXTRACT(HOUR FROM started_at) as hour,
                COUNT(*) as session_count,
                AVG(actual_duration_minutes) as avg_duration
               FROM focus_sessions
               WHERE started_at > NOW() - INTERVAL '30 days'
               GROUP BY EXTRACT(HOUR FROM started_at)
               ORDER BY hour"""
        )
        
        energy = [3] * 24  # Default medium energy
        for r in rows:
            hour = int(r["hour"])
            score = min(int((r["session_count"] or 0) * 10 + (r["avg_duration"] or 0) / 10), 5)
            energy[hour] = max(1, min(5, score))
        
        return energy

    def _build_optimized_schedule(self, existing_events: List[Dict], 
                                   tasks: List[Dict],
                                   energy_curve: List[int],
                                   target_date: date) -> List[Dict[str, Any]]:
        """Build an optimized daily schedule."""
        blocks = []
        
        # Add existing events first
        for event in existing_events:
            blocks.append({
                "type": "existing",
                "title": event["title"],
                "start_time": event["start_time"].isoformat() if isinstance(event["start_time"], datetime) else event["start_time"],
                "end_time": event["end_time"].isoformat() if isinstance(event["end_time"], datetime) else event["end_time"],
                "event_type": event["event_type"],
                "fixed": True
            })
        
        # Sort tasks by priority and match to high-energy slots
        priority_order = {"urgent": 0, "high": 1, "medium": 2, "low": 3}
        sorted_tasks = sorted(tasks, key=lambda t: priority_order.get(t.get("priority", "low"), 3))
        
        # Find open slots in typical work hours (9-17)
        work_start = 9
        work_end = 17
        
        for hour in range(work_start, work_end):
            if hour >= len(energy_curve):
                break
                
            energy = energy_curve[hour]
            slot_start = datetime.combine(target_date, time(hour, 0))
            slot_end = slot_start + timedelta(hours=1)
            
            # Check if slot is occupied
            slot_occupied = any(
                b["fixed"] and 
                datetime.fromisoformat(str(b["start_time"]).replace("Z", "+00:00")).hour == hour
                for b in blocks if b.get("fixed")
            )
            
            if slot_occupied:
                continue
            
            # Assign task based on energy level
            if energy >= 4 and sorted_tasks:
                # High energy = important task
                task = sorted_tasks.pop(0)
                blocks.append({
                    "type": "focus",
                    "title": f"Focus: {task['title']}",
                    "task_id": str(task["id"]),
                    "start_time": slot_start.isoformat(),
                    "end_time": slot_end.isoformat(),
                    "duration_minutes": 60,
                    "priority": task.get("priority", "medium"),
                    "energy_match": "high"
                })
            elif energy >= 3 and sorted_tasks:
                # Medium energy = medium priority task
                task = sorted_tasks.pop(0)
                blocks.append({
                    "type": "task",
                    "title": task['title'],
                    "task_id": str(task["id"]),
                    "start_time": slot_start.isoformat(),
                    "end_time": slot_end.isoformat(),
                    "duration_minutes": 60,
                    "priority": task.get("priority", "medium"),
                    "energy_match": "medium"
                })
            elif energy <= 2:
                # Low energy = break or admin
                blocks.append({
                    "type": "break",
                    "title": "Break / Admin Time",
                    "start_time": slot_start.isoformat(),
                    "end_time": (slot_start + timedelta(minutes=30)).isoformat(),
                    "duration_minutes": 30,
                    "energy_match": "low"
                })
        
        # Sort blocks by start time
        blocks.sort(key=lambda b: b["start_time"])
        
        return blocks

    def _generate_schedule_rationale(self, blocks: List[Dict], 
                                      energy_curve: List[int]) -> List[str]:
        """Generate explanation for the optimized schedule."""
        rationale = []
        
        focus_blocks = [b for b in blocks if b["type"] == "focus"]
        if focus_blocks:
            hours = [datetime.fromisoformat(b["start_time"]).hour for b in focus_blocks]
            peak_hours = [h for h in hours if h < len(energy_curve) and energy_curve[h] >= 4]
            if peak_hours:
                rationale.append(
                    f"Deep work scheduled during peak energy hours: {', '.join(f'{h:02d}:00' for h in peak_hours)}"
                )
        
        break_count = len([b for b in blocks if b["type"] == "break"])
        if break_count > 0:
            rationale.append(f"{break_count} break blocks included for recovery")
        
        remaining = len([b for b in blocks if b.get("task_id") and b["type"] != "focus"])
        if remaining > 0:
            rationale.append(f"{remaining} additional tasks scheduled during medium-energy periods")
        
        return rationale

    async def suggest_task_batching(self, user_id: str) -> List[Dict[str, Any]]:
        """Suggest task batching based on context switching analysis."""
        if not self.db_pool:
            return []
        
        # Find tasks that could be batched by category/tag
        rows = await self.db_pool.fetch(
            """SELECT id, title, tags, priority, estimated_duration_minutes
               FROM tasks
               WHERE status NOT IN ('completed', 'cancelled')
               AND estimated_duration_minutes <= 30
               ORDER BY tags, priority"""
        )
        
        batches = {}
        for row in rows:
            tags = json.loads(row["tags"]) if isinstance(row["tags"], str) else (row["tags"] or [])
            category = tags[0] if tags else "uncategorized"
            
            if category not in batches:
                batches[category] = []
            batches[category].append({
                "id": str(row["id"]),
                "title": row["title"],
                "estimated_minutes": row["estimated_duration_minutes"] or 15
            })
        
        batch_suggestions = []
        for category, tasks in batches.items():
            if len(tasks) >= 3:
                total_time = sum(t["estimated_minutes"] for t in tasks)
                batch_suggestions.append({
                    "category": category,
                    "tasks": tasks[:5],
                    "total_estimated_minutes": total_time,
                    "rationale": f"Batch {len(tasks)} small tasks to minimize context switching"
                })
        
        return batch_suggestions
