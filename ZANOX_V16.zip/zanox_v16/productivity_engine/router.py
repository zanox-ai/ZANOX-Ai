"""
FastAPI Router for the Productivity Engine.
"""

from datetime import date
from typing import Optional
from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field

from ..models import APIResponse
from .engine import ProductivityEngine

router = APIRouter()
_engine: Optional[ProductivityEngine] = None


def set_engine(engine: ProductivityEngine):
    global _engine
    _engine = engine


@router.get("/score", response_model=APIResponse)
async def get_productivity_score(
    user_id: str = Query(..., description="User ID"),
    period_days: int = Query(7, ge=1, le=90)
):
    """Get productivity score for a user."""
    if not _engine:
        raise HTTPException(status_code=503, detail="Engine not initialized")
    score = await _engine.calculate_productivity_score(user_id, period_days)
    return APIResponse(success=True, data=score)


@router.get("/weekly-report", response_model=APIResponse)
async def get_weekly_report(user_id: str = Query(...)):
    """Get comprehensive weekly report."""
    if not _engine:
        raise HTTPException(status_code=503, detail="Engine not initialized")
    report = await _engine.get_weekly_report(user_id)
    return APIResponse(success=True, data=report)


@router.get("/insights", response_model=APIResponse)
async def get_productivity_insights(user_id: str = Query(...)):
    """Get AI-powered productivity insights."""
    if not _engine:
        raise HTTPException(status_code=503, detail="Engine not initialized")
    insights = await _engine.get_productivity_insights(user_id)
    return APIResponse(success=True, data=insights)


@router.get("/optimize-schedule", response_model=APIResponse)
async def optimize_schedule(
    user_id: str = Query(...),
    target_date: Optional[date] = None
):
    """Get optimized daily schedule."""
    if not _engine:
        raise HTTPException(status_code=503, detail="Engine not initialized")
    optimization = await _engine.optimize_schedule(user_id, target_date)
    return APIResponse(success=True, data=optimization)


@router.get("/batch-suggestions", response_model=APIResponse)
async def get_batch_suggestions(user_id: str = Query(...)):
    """Get task batching suggestions."""
    if not _engine:
        raise HTTPException(status_code=503, detail="Engine not initialized")
    batches = await _engine.optimizer.suggest_task_batching(user_id)
    return APIResponse(success=True, data=batches)
