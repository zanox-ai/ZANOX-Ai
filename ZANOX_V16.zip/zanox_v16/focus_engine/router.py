"""Focus Engine Router - FastAPI endpoints."""
from typing import Optional
from uuid import UUID
from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from datetime import datetime, date, time
from ..models import APIResponse
from .service import FocusService

router = APIRouter()
_service: Optional[FocusService] = None

def set_service(service: FocusService):
    global _service
    _service = service

class StartSessionRequest(BaseModel):
    mode: str = "deep_work"
    planned_duration_minutes: int = 90
    task_id: Optional[UUID] = None
    project_id: Optional[UUID] = None

class PomodoroRequest(BaseModel):
    task_id: Optional[UUID] = None
    duration_minutes: int = 25
    break_duration_minutes: int = 5

class DeepWorkRequest(BaseModel):
    task_id: Optional[UUID] = None
    project_id: Optional[UUID] = None
    date: date
    planned_start: str
    planned_end: str

@router.post("/sessions", response_model=APIResponse)
async def start_session(request: StartSessionRequest):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.start_session(request.mode, request.planned_duration_minutes, request.task_id, request.project_id)
    return APIResponse(success=True, data=result.model_dump() if hasattr(result, "model_dump") else result)

@router.put("/sessions/{session_id}/end", response_model=APIResponse)
async def end_session(session_id: UUID, rating: Optional[int] = Query(None), notes: Optional[str] = Query(None)):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.end_session(session_id, rating, notes)
    return APIResponse(success=True, data=result.model_dump() if hasattr(result, "model_dump") else result)

@router.get("/sessions", response_model=APIResponse)
async def get_sessions(start: datetime, end: datetime, mode: Optional[str] = Query(None)):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.get_sessions(start, end, mode)
    return APIResponse(success=True, data=[s.model_dump() if hasattr(s, "model_dump") else s for s in result])

@router.post("/pomodoro/start", response_model=APIResponse)
async def start_pomodoro(request: PomodoroRequest):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.start_pomodoro(request.task_id, request.duration_minutes, request.break_duration_minutes)
    return APIResponse(success=True, data=result.model_dump() if hasattr(result, "model_dump") else result)

@router.put("/pomodoro/{session_id}/complete", response_model=APIResponse)
async def complete_pomodoro(session_id: UUID):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.complete_pomodoro(session_id)
    return APIResponse(success=True, data=result.model_dump() if hasattr(result, "model_dump") else result)

@router.post("/deep-work", response_model=APIResponse)
async def schedule_deep_work(request: DeepWorkRequest):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    ps = datetime.strptime(request.planned_start, "%H:%M").time()
    pe = datetime.strptime(request.planned_end, "%H:%M").time()
    result = await _service.schedule_deep_work(request.task_id, request.project_id, request.date, ps, pe)
    return APIResponse(success=True, data=result.model_dump() if hasattr(result, "model_dump") else result)

@router.get("/stats/daily", response_model=APIResponse)
async def get_daily_stats(target_date: Optional[date] = Query(None)):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.get_daily_stats(target_date or date.today())
    return APIResponse(success=True, data=result)
