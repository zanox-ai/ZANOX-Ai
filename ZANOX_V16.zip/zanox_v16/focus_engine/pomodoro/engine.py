"""Pomodoro Engine - Full pomodoro cycle management."""
from datetime import datetime, timedelta
from typing import Dict, List, Optional

class PomodoroEngine:
    DEFAULT_WORK = 25
    DEFAULT_SHORT_BREAK = 5
    DEFAULT_LONG_BREAK = 15
    POMODOROS_BEFORE_LONG = 4

    async def get_daily_plan(self, work_hours: int = 8) -> List[Dict]:
        plan = []
        current = datetime.now().replace(hour=9, minute=0, second=0, microsecond=0)
        pomodoro_count = 0

        while current.hour < 9 + work_hours:
            pomodoro_count += 1
            plan.append({"type": "work", "start": current.isoformat(), "duration": self.DEFAULT_WORK})
            current += timedelta(minutes=self.DEFAULT_WORK)

            if pomodoro_count % self.POMODOROS_BEFORE_LONG == 0:
                plan.append({"type": "long_break", "start": current.isoformat(), "duration": self.DEFAULT_LONG_BREAK})
                current += timedelta(minutes=self.DEFAULT_LONG_BREAK)
            else:
                plan.append({"type": "short_break", "start": current.isoformat(), "duration": self.DEFAULT_SHORT_BREAK})
                current += timedelta(minutes=self.DEFAULT_SHORT_BREAK)

        return plan

    async def get_stats(self, total_completed_today: int = 0) -> Dict:
        return {
            "completed_today": total_completed_today,
            "work_minutes": total_completed_today * self.DEFAULT_WORK,
            "break_minutes": (total_completed_today // self.POMODOROS_BEFORE_LONG) * self.DEFAULT_LONG_BREAK + (total_completed_today % self.POMODOROS_BEFORE_LONG) * self.DEFAULT_SHORT_BREAK,
            "next_long_break_after": self.POMODOROS_BEFORE_LONG - (total_completed_today % self.POMODOROS_BEFORE_LONG)
        }
