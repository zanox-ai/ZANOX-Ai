"""Focus Service - Manages focus sessions, pomodoro, and deep work blocks."""
from datetime import datetime, date, time, timedelta
from typing import Dict, List, Optional, Any
from uuid import UUID, uuid4
import asyncpg
from ..models import FocusSession, PomodoroSession, DeepWorkBlock, FocusMode

class FocusService:
    def __init__(self):
        self.db_pool = None
    def initialize(self, db_pool, redis_client):
        self.db_pool = db_pool

    async def start_session(self, mode: str, planned_duration: int, task_id: Optional[UUID] = None, project_id: Optional[UUID] = None) -> FocusSession:
        if not self.db_pool:
            raise RuntimeError("Database not initialized")
        sid = uuid4()
        now = datetime.utcnow()
        await self.db_pool.execute(
            "INSERT INTO focus_sessions (id, mode, started_at, planned_duration_minutes, task_id, project_id) VALUES ($1, $2, $3, $4, $5, $6)",
            sid, mode, now, planned_duration,
            str(task_id) if task_id else None, str(project_id) if project_id else None
        )
        return FocusSession(id=sid, mode=FocusMode(mode), started_at=now, planned_duration_minutes=planned_duration, task_id=task_id, project_id=project_id)

    async def end_session(self, session_id: UUID, rating: Optional[int] = None, notes: Optional[str] = None) -> Optional[FocusSession]:
        if not self.db_pool:
            return None
        now = datetime.utcnow()
        row = await self.db_pool.fetchrow("SELECT started_at FROM focus_sessions WHERE id = $1", session_id)
        if not row:
            return None
        actual_mins = int((now - row["started_at"]).total_seconds() / 60)
        await self.db_pool.execute(
            "UPDATE focus_sessions SET ended_at = $1, actual_duration_minutes = $2, rating = $3, notes = $4 WHERE id = $5",
            now, actual_mins, rating, notes, session_id
        )
        return await self.get_session(session_id)

    async def get_session(self, session_id: UUID) -> Optional[FocusSession]:
        if not self.db_pool:
            return None
        row = await self.db_pool.fetchrow("SELECT * FROM focus_sessions WHERE id = $1", session_id)
        if not row:
            return None
        return FocusSession(
            id=row["id"], mode=FocusMode(row["mode"]), started_at=row["started_at"],
            ended_at=row["ended_at"], planned_duration_minutes=row["planned_duration_minutes"],
            actual_duration_minutes=row["actual_duration_minutes"],
            task_id=UUID(row["task_id"]) if row["task_id"] else None,
            project_id=UUID(row["project_id"]) if row["project_id"] else None,
            interruptions=row["interruptions"] or 0, notes=row["notes"], rating=row["rating"]
        )

    async def get_sessions(self, start: datetime, end: datetime, mode: Optional[str] = None) -> List[FocusSession]:
        if not self.db_pool:
            return []
        q = "SELECT * FROM focus_sessions WHERE started_at >= $1 AND started_at < $2"
        params = [start, end]
        if mode:
            q += f" AND mode = ${len(params)+1}"
            params.append(mode)
        q += " ORDER BY started_at DESC"
        rows = await self.db_pool.fetch(q, *params)
        return [await self.get_session(r["id"]) for r in rows]

    async def record_interruption(self, session_id: UUID):
        if not self.db_pool:
            return
        await self.db_pool.execute(
            "UPDATE focus_sessions SET interruptions = interruptions + 1 WHERE id = $1", session_id
        )

    async def start_pomodoro(self, task_id: Optional[UUID] = None, duration: int = 25, break_duration: int = 5) -> PomodoroSession:
        if not self.db_pool:
            raise RuntimeError("Database not initialized")
        sid = uuid4()
        now = datetime.utcnow()
        await self.db_pool.execute(
            """INSERT INTO pomodoro_sessions (id, task_id, started_at, duration_minutes, break_duration_minutes)
             VALUES ($1, $2, $3, $4, $5)""",
            sid, str(task_id) if task_id else None, now, duration, break_duration
        )
        return PomodoroSession(id=sid, task_id=task_id, started_at=now, duration_minutes=duration, break_duration_minutes=break_duration)

    async def complete_pomodoro(self, session_id: UUID) -> Optional[PomodoroSession]:
        if not self.db_pool:
            return None
        now = datetime.utcnow()
        await self.db_pool.execute(
            "UPDATE pomodoro_sessions SET completed = true, completed_at = $1 WHERE id = $2",
            now, session_id
        )
        row = await self.db_pool.fetchrow("SELECT * FROM pomodoro_sessions WHERE id = $1", session_id)
        if not row:
            return None
        return PomodoroSession(
            id=row["id"], task_id=UUID(row["task_id"]) if row["task_id"] else None,
            started_at=row["started_at"], completed_at=row["completed_at"],
            duration_minutes=row["duration_minutes"], break_duration_minutes=row["break_duration_minutes"],
            completed=row["completed"], interruptions=row["interruptions"] or 0
        )

    async def schedule_deep_work(self, task_id: Optional[UUID], project_id: Optional[UUID], work_date: date, planned_start: time, planned_end: time) -> DeepWorkBlock:
        if not self.db_pool:
            raise RuntimeError("Database not initialized")
        bid = uuid4()
        await self.db_pool.execute(
            """INSERT INTO deep_work_blocks (id, task_id, project_id, date, planned_start, planned_end)
             VALUES ($1, $2, $3, $4, $5, $6)""",
            bid, str(task_id) if task_id else None, str(project_id) if project_id else None,
            work_date, planned_start, planned_end
        )
        return DeepWorkBlock(id=bid, task_id=task_id, project_id=project_id, date=work_date, planned_start=planned_start, planned_end=planned_end)

    async def get_daily_stats(self, target_date: date) -> Dict:
        if not self.db_pool:
            return {}
        focus_min = await self.db_pool.fetchval(
            "SELECT COALESCE(SUM(actual_duration_minutes), 0) FROM focus_sessions WHERE DATE(started_at) = $1 AND ended_at IS NOT NULL",
            target_date
        ) or 0
        pomos = await self.db_pool.fetchval(
            "SELECT COUNT(*) FROM pomodoro_sessions WHERE DATE(started_at) = $1 AND completed = true",
            target_date
        ) or 0
        return {
            "date": target_date.isoformat(),
            "total_focus_minutes": focus_min,
            "total_focus_hours": round(focus_min / 60, 1),
            "pomodoros_completed": pomos,
            "sessions_count": await self.db_pool.fetchval(
                "SELECT COUNT(*) FROM focus_sessions WHERE DATE(started_at) = $1", target_date
            ) or 0
        }
