"""
ZANOX V16 Shared Models and Schemas
All Pydantic models used across the Personal Assistant & Productivity Layer.
"""

from datetime import datetime, date, time, timedelta
from typing import List, Optional, Dict, Any, Literal
from enum import Enum
from uuid import UUID, uuid4
from pydantic import BaseModel, Field, ConfigDict


class PriorityLevel(str, Enum):
    URGENT = "urgent"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    MINIMAL = "minimal"


class TaskStatus(str, Enum):
    BACKLOG = "backlog"
    TODO = "todo"
    IN_PROGRESS = "in_progress"
    IN_REVIEW = "in_review"
    BLOCKED = "blocked"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


class ProjectStatus(str, Enum):
    PLANNING = "planning"
    ACTIVE = "active"
    ON_HOLD = "on_hold"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


class GoalStatus(str, Enum):
    DRAFT = "draft"
    ACTIVE = "active"
    IN_PROGRESS = "in_progress"
    ACHIEVED = "achieved"
    ABANDONED = "abandoned"


class HabitFrequency(str, Enum):
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"
    CUSTOM = "custom"


class EventType(str, Enum):
    MEETING = "meeting"
    TASK = "task"
    REMINDER = "reminder"
    FOCUS = "focus"
    HABIT = "habit"
    PERSONAL = "personal"
    WORK = "work"


class FocusMode(str, Enum):
    POMODORO = "pomodoro"
    DEEP_WORK = "deep_work"
    FLOW_STATE = "flow_state"
    FREE = "free"


class DecisionType(str, Enum):
    BINARY = "binary"
    MULTI_OPTION = "multi_option"
    WEIGHTED = "weighted"
    PRIORITIZATION = "prioritization"


class NoteType(str, Enum):
    QUICK = "quick"
    STRUCTURED = "structured"
    DAILY = "daily"
    PROJECT = "project"
    MEETING = "meeting"
    RESEARCH = "research"


class DocumentType(str, Enum):
    FILE = "file"
    FOLDER = "folder"
    LINK = "link"
    DOCUMENT = "document"
    SPREADSHEET = "spreadsheet"
    PRESENTATION = "presentation"


# ============== Task Management Models ==============

class TaskBase(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    title: str = Field(..., min_length=1, max_length=500)
    description: Optional[str] = None
    priority: PriorityLevel = PriorityLevel.MEDIUM
    status: TaskStatus = TaskStatus.TODO
    due_date: Optional[datetime] = None
    estimated_duration_minutes: Optional[int] = None
    actual_duration_minutes: Optional[int] = None
    tags: List[str] = Field(default_factory=list)
    project_id: Optional[UUID] = None
    goal_id: Optional[UUID] = None
    assigned_to: Optional[UUID] = None
    parent_task_id: Optional[UUID] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)


class TaskCreate(TaskBase):
    dependencies: List[UUID] = Field(default_factory=list)
    recurring_rule: Optional[str] = None


class TaskUpdate(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    title: Optional[str] = None
    description: Optional[str] = None
    priority: Optional[PriorityLevel] = None
    status: Optional[TaskStatus] = None
    due_date: Optional[datetime] = None
    estimated_duration_minutes: Optional[int] = None
    actual_duration_minutes: Optional[int] = None
    tags: Optional[List[str]] = None
    project_id: Optional[UUID] = None
    goal_id: Optional[UUID] = None
    status_notes: Optional[str] = None


class Task(TaskBase):
    id: UUID = Field(default_factory=uuid4)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = None
    dependencies: List["TaskDependency"] = Field(default_factory=list)
    subtasks: List["Task"] = Field(default_factory=list)
    completion_percentage: float = 0.0


class TaskDependency(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID = Field(default_factory=uuid4)
    task_id: UUID
    depends_on_task_id: UUID
    dependency_type: Literal["blocks", "blocked_by", "relates_to"] = "blocked_by"
    created_at: datetime = Field(default_factory=datetime.utcnow)


class TaskPriorityScore(BaseModel):
    task_id: UUID
    priority_score: float
    urgency_score: float
    importance_score: float
    effort_score: float
    deadline_score: float
    composite_score: float
    recommended_order: int


class RecurringTaskRule(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID = Field(default_factory=uuid4)
    task_template_id: UUID
    frequency: Literal["daily", "weekly", "monthly", "custom"]
    interval: int = 1
    days_of_week: Optional[List[int]] = None
    day_of_month: Optional[int] = None
    end_date: Optional[datetime] = None
    max_occurrences: Optional[int] = None
    active: bool = True


# ============== Project Management Models ==============

class ProjectBase(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    name: str = Field(..., min_length=1, max_length=200)
    description: Optional[str] = None
    status: ProjectStatus = ProjectStatus.PLANNING
    priority: PriorityLevel = PriorityLevel.MEDIUM
    start_date: Optional[date] = None
    target_end_date: Optional[date] = None
    actual_end_date: Optional[date] = None
    owner_id: Optional[UUID] = None
    tags: List[str] = Field(default_factory=list)
    color: Optional[str] = "#6366f1"
    metadata: Dict[str, Any] = Field(default_factory=dict)


class ProjectCreate(ProjectBase):
    template_id: Optional[str] = None
    goal_ids: List[UUID] = Field(default_factory=list)


class Project(ProjectBase):
    id: UUID = Field(default_factory=uuid4)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    tasks: List[Task] = Field(default_factory=list)
    milestones: List["Milestone"] = Field(default_factory=list)
    progress_percentage: float = 0.0
    total_tasks: int = 0
    completed_tasks: int = 0


class Milestone(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID = Field(default_factory=uuid4)
    project_id: UUID
    name: str = Field(..., min_length=1, max_length=200)
    description: Optional[str] = None
    due_date: Optional[date] = None
    completed_date: Optional[date] = None
    status: Literal["pending", "in_progress", "completed", "missed"] = "pending"
    deliverables: List[str] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=datetime.utcnow)


class RoadmapItem(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID = Field(default_factory=uuid4)
    project_id: UUID
    title: str
    description: Optional[str] = None
    quarter: Optional[int] = None
    year: Optional[int] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    status: Literal["planned", "in_progress", "completed", "deferred"] = "planned"
    dependencies: List[UUID] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=datetime.utcnow)


# ============== Goal Management Models ==============

class GoalBase(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    title: str = Field(..., min_length=1, max_length=300)
    description: Optional[str] = None
    status: GoalStatus = GoalStatus.ACTIVE
    priority: PriorityLevel = PriorityLevel.MEDIUM
    category: Optional[str] = None
    target_date: Optional[date] = None
    parent_goal_id: Optional[UUID] = None
    owner_id: Optional[UUID] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)


class GoalCreate(GoalBase):
    key_results: List[str] = Field(default_factory=list)


class Goal(GoalBase):
    id: UUID = Field(default_factory=uuid4)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    progress_percentage: float = 0.0
    key_results: List["KeyResult"] = Field(default_factory=list)
    subgoals: List["Goal"] = Field(default_factory=list)


class KeyResult(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID = Field(default_factory=uuid4)
    goal_id: UUID
    description: str
    target_value: float
    current_value: float = 0.0
    unit: Optional[str] = None
    deadline: Optional[date] = None
    status: Literal["not_started", "in_progress", "completed", "at_risk"] = "not_started"
    created_at: datetime = Field(default_factory=datetime.utcnow)


class GoalAnalytics(BaseModel):
    goal_id: UUID
    completion_rate: float
    days_remaining: Optional[int]
    pace_status: Literal["ahead", "on_track", "behind", "at_risk"]
    key_results_progress: List[Dict[str, Any]]
    contributing_projects: int
    contributing_tasks: int
    weekly_velocity: float
    predicted_completion_date: Optional[date]


# ============== Habit Management Models ==============

class HabitBase(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    name: str = Field(..., min_length=1, max_length=200)
    description: Optional[str] = None
    frequency: HabitFrequency = HabitFrequency.DAILY
    target_per_period: int = 1
    color: Optional[str] = "#10b981"
    icon: Optional[str] = "check"
    reminder_time: Optional[time] = None
    associated_goal_id: Optional[UUID] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)


class HabitCreate(HabitBase):
    pass


class Habit(HabitBase):
    id: UUID = Field(default_factory=uuid4)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    current_streak: int = 0
    longest_streak: int = 0
    total_completions: int = 0
    last_completed: Optional[datetime] = None
    active: bool = True


class HabitLog(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID = Field(default_factory=uuid4)
    habit_id: UUID
    completed_at: datetime = Field(default_factory=datetime.utcnow)
    notes: Optional[str] = None
    value: Optional[float] = None
    mood: Optional[int] = Field(None, ge=1, le=5)


class HabitAnalytics(BaseModel):
    habit_id: UUID
    completion_rate_30d: float
    completion_rate_7d: float
    current_streak: int
    longest_streak: int
    total_completions: int
    average_mood: Optional[float]
    trend: Literal["improving", "stable", "declining"]
    consistency_score: float
    next_milestone: int


# ============== Calendar Models ==============

class CalendarEventBase(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    title: str = Field(..., min_length=1, max_length=500)
    description: Optional[str] = None
    event_type: EventType = EventType.MEETING
    start_time: datetime
    end_time: datetime
    timezone: str = "UTC"
    location: Optional[str] = None
    is_recurring: bool = False
    recurring_rule: Optional[str] = None
    attendees: List[str] = Field(default_factory=list)
    linked_task_id: Optional[UUID] = None
    linked_project_id: Optional[UUID] = None
    linked_goal_id: Optional[UUID] = None
    color: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)


class CalendarEventCreate(CalendarEventBase):
    reminders: List[int] = Field(default_factory=lambda: [15])


class CalendarEvent(CalendarEventBase):
    id: UUID = Field(default_factory=uuid4)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class TimeBlock(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID = Field(default_factory=uuid4)
    name: str
    start_time: time
    end_time: time
    days_of_week: List[int] = Field(default_factory=list)
    block_type: Literal["focus", "meeting", "break", "personal", "learning", "admin"] = "focus"
    color: Optional[str] = None
    active: bool = True
    created_at: datetime = Field(default_factory=datetime.utcnow)


class Reminder(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID = Field(default_factory=uuid4)
    title: str
    message: Optional[str] = None
    trigger_time: datetime
    entity_type: Optional[str] = None
    entity_id: Optional[UUID] = None
    dismissed: bool = False
    dismissed_at: Optional[datetime] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)


class Notification(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID = Field(default_factory=uuid4)
    title: str
    message: str
    notification_type: Literal["info", "warning", "success", "error", "reminder"] = "info"
    channel: Literal["in_app", "email", "push", "sms", "telegram"] = "in_app"
    read: bool = False
    read_at: Optional[datetime] = None
    action_url: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)


# ============== Focus Models ==============

class FocusSession(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID = Field(default_factory=uuid4)
    mode: FocusMode
    started_at: datetime = Field(default_factory=datetime.utcnow)
    ended_at: Optional[datetime] = None
    planned_duration_minutes: int
    actual_duration_minutes: Optional[int] = None
    task_id: Optional[UUID] = None
    project_id: Optional[UUID] = None
    interruptions: int = 0
    notes: Optional[str] = None
    rating: Optional[int] = Field(None, ge=1, le=5)


class PomodoroSession(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID = Field(default_factory=uuid4)
    task_id: Optional[UUID] = None
    started_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = None
    duration_minutes: int = 25
    break_duration_minutes: int = 5
    completed: bool = False
    interruptions: int = 0


class DeepWorkBlock(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID = Field(default_factory=uuid4)
    task_id: Optional[UUID] = None
    project_id: Optional[UUID] = None
    date: date = Field(default_factory=date.today)
    planned_start: time
    planned_end: time
    actual_start: Optional[datetime] = None
    actual_end: Optional[datetime] = None
    status: Literal["scheduled", "in_progress", "completed", "cancelled"] = "scheduled"
    quality_rating: Optional[int] = Field(None, ge=1, le=5)
    output_summary: Optional[str] = None


# ============== Decision Support Models ==============

class DecisionOption(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID = Field(default_factory=uuid4)
    title: str
    description: Optional[str] = None
    pros: List[str] = Field(default_factory=list)
    cons: List[str] = Field(default_factory=list)
    scores: Dict[str, float] = Field(default_factory=dict)


class DecisionMatrix(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID = Field(default_factory=uuid4)
    title: str = Field(..., min_length=1, max_length=300)
    description: Optional[str] = None
    decision_type: DecisionType
    criteria: List[str] = Field(default_factory=list)
    criteria_weights: Dict[str, float] = Field(default_factory=dict)
    options: List[DecisionOption] = Field(default_factory=list)
    final_decision: Optional[str] = None
    confidence_score: Optional[float] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    resolved_at: Optional[datetime] = None


# ============== Knowledge Management Models ==============

class KnowledgeEntry(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID = Field(default_factory=uuid4)
    title: str = Field(..., min_length=1, max_length=300)
    content: str
    category: Optional[str] = None
    tags: List[str] = Field(default_factory=list)
    source: Optional[str] = None
    related_entries: List[UUID] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    version: int = 1


class Note(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID = Field(default_factory=uuid4)
    title: Optional[str] = None
    content: str
    note_type: NoteType = NoteType.QUICK
    tags: List[str] = Field(default_factory=list)
    linked_task_id: Optional[UUID] = None
    linked_project_id: Optional[UUID] = None
    linked_goal_id: Optional[UUID] = None
    folder: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class Bookmark(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID = Field(default_factory=uuid4)
    url: str
    title: Optional[str] = None
    description: Optional[str] = None
    favicon: Optional[str] = None
    tags: List[str] = Field(default_factory=list)
    folder: Optional[str] = None
    reading_time_minutes: Optional[int] = None
    is_archived: bool = False
    click_count: int = 0
    created_at: datetime = Field(default_factory=datetime.utcnow)


class ReadingListItem(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID = Field(default_factory=uuid4)
    title: str
    url: Optional[str] = None
    content_type: Literal["article", "book", "paper", "video", "podcast", "other"] = "article"
    status: Literal["to_read", "reading", "completed", "abandoned"] = "to_read"
    priority: PriorityLevel = PriorityLevel.MEDIUM
    estimated_reading_time: Optional[int] = None
    notes: Optional[str] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)


# ============== Document Management Models ==============

class Document(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID = Field(default_factory=uuid4)
    name: str
    document_type: DocumentType
    storage_path: Optional[str] = None
    size_bytes: Optional[int] = None
    mime_type: Optional[str] = None
    checksum: Optional[str] = None
    folder_id: Optional[UUID] = None
    tags: List[str] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class FileFolder(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID = Field(default_factory=uuid4)
    name: str
    parent_id: Optional[UUID] = None
    color: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)


# ============== Learning Models ==============

class LearningItem(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID = Field(default_factory=uuid4)
    title: str
    skill_category: Optional[str] = None
    resource_type: Literal["course", "book", "article", "video", "practice", "project"] = "course"
    status: Literal["planned", "in_progress", "completed", "on_hold"] = "planned"
    progress_percentage: float = 0.0
    start_date: Optional[date] = None
    target_completion_date: Optional[date] = None
    completed_date: Optional[date] = None
    time_spent_minutes: int = 0
    notes: Optional[str] = None
    rating: Optional[int] = Field(None, ge=1, le=5)
    created_at: datetime = Field(default_factory=datetime.utcnow)


class LearningLog(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID = Field(default_factory=uuid4)
    learning_item_id: UUID
    session_date: date = Field(default_factory=date.today)
    duration_minutes: int
    notes: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)


# ============== Dashboard & Analytics Models ==============

class DailySummary(BaseModel):
    date: date
    tasks_completed: int
    tasks_created: int
    focus_minutes: int
    pomodoros_completed: int
    habits_completed: int
    habits_total: int
    goals_progressed: int
    events_attended: int
    learning_minutes: int
    productivity_score: float


class WeeklyReview(BaseModel):
    week_start: date
    week_end: date
    tasks_completed: int
    tasks_total: int
    focus_hours: float
    pomodoros_completed: int
    habits_consistency: float
    goals_progress: List[Dict[str, Any]]
    top_projects: List[Dict[str, Any]]
    productivity_trend: float
    wins: List[str] = Field(default_factory=list)
    improvements: List[str] = Field(default_factory=list)


class ProductivityMetrics(BaseModel):
    user_id: UUID
    period_start: date
    period_end: date
    task_completion_rate: float
    on_time_completion_rate: float
    average_task_duration: float
    focus_sessions_count: int
    total_focus_hours: float
    deep_work_hours: float
    pomodoros_completed: int
    habit_consistency: float
    goal_progress_rate: float
    overall_productivity_score: float
    comparison_to_previous_period: float


class LifeDashboardData(BaseModel):
    user_id: UUID
    generated_at: datetime = Field(default_factory=datetime.utcnow)
    daily_summary: DailySummary
    active_tasks: List[Task]
    upcoming_events: List[CalendarEvent]
    habits_today: List[Habit]
    focus_sessions: List[FocusSession]
    goals_progress: List[Goal]
    project_status: List[Project]
    pending_decisions: List[DecisionMatrix]
    recent_notes: List[Note]
    learning_in_progress: List[LearningItem]
    notifications: List[Notification]
    productivity_score: float
    weekly_trend: float
    focus_score: float
    balance_score: float


# ============== Request/Response Models ==============

class APIResponse(BaseModel):
    success: bool = True
    message: str = "Success"
    data: Optional[Any] = None
    error: Optional[str] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class PaginatedResponse(BaseModel):
    items: List[Any]
    total: int
    page: int
    page_size: int
    total_pages: int


class BulkActionRequest(BaseModel):
    ids: List[UUID]
    action: Literal["complete", "delete", "archive", "update_priority", "assign"]
    value: Optional[str] = None


class ScheduleOptimizeRequest(BaseModel):
    task_ids: List[UUID]
    preferences: Dict[str, Any] = Field(default_factory=dict)
    constraints: Dict[str, Any] = Field(default_factory=dict)


class SearchRequest(BaseModel):
    query: str = Field(..., min_length=1)
    entity_types: List[str] = Field(default_factory=list)
    filters: Dict[str, Any] = Field(default_factory=dict)
    limit: int = 20
    offset: int = 0


class AIAssistantRequest(BaseModel):
    message: str = Field(..., min_length=1)
    context: Optional[Dict[str, Any]] = None
    session_id: Optional[str] = None
    response_format: Optional[str] = None


class AIAssistantResponse(BaseModel):
    response: str
    actions: List[Dict[str, Any]] = Field(default_factory=list)
    suggested_tasks: List[Dict[str, Any]] = Field(default_factory=list)
    context_updates: Dict[str, Any] = Field(default_factory=dict)
