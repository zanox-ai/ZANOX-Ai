"""Calendar Engine Router - FastAPI endpoints."""
from typing import Optional, List
from uuid import UUID
from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from datetime import datetime, time
from ..models import APIResponse
from .service import CalendarService

router = APIRouter()
_service: Optional[CalendarService] = None

def set_service(service: CalendarService):
    global _service
    _service = service

class EventCreateRequest(BaseModel):
    title: str
    description: Optional[str] = None
    event_type: str = "meeting"
    start_time: datetime
    end_time: datetime
    location: Optional[str] = None
    reminders: Optional[List[int]] = [15]

class TimeBlockRequest(BaseModel):
    name: str
    start_time: str
    end_time: str
    days_of_week: List[int]
    block_type: str = "focus"
    color: Optional[str] = None

@router.post("/events", response_model=APIResponse)
async def create_event(request: EventCreateRequest):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    from ..models import CalendarEventCreate, EventType
    event_data = CalendarEventCreate(
        title=request.title, description=request.description,
        event_type=EventType(request.event_type), start_time=request.start_time,
        end_time=request.end_time, location=request.location, reminders=request.reminders or [15]
    )
    result = await _service.create_event(event_data)
    return APIResponse(success=True, data=result.model_dump() if hasattr(result, "model_dump") else result)

@router.get("/events", response_model=APIResponse)
async def list_events(start: datetime, end: datetime, event_type: Optional[str] = Query(None)):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.list_events(start, end, event_type)
    return APIResponse(success=True, data=[e.model_dump() if hasattr(e, "model_dump") else e for e in result])

@router.get("/events/{event_id}", response_model=APIResponse)
async def get_event(event_id: UUID):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.get_event(event_id)
    if not result:
        raise HTTPException(status_code=404, detail="Event not found")
    return APIResponse(success=True, data=result.model_dump() if hasattr(result, "model_dump") else result)

@router.delete("/events/{event_id}", response_model=APIResponse)
async def delete_event(event_id: UUID):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    success = await _service.delete_event(event_id)
    return APIResponse(success=success)

@router.post("/time-blocks", response_model=APIResponse)
async def create_time_block(request: TimeBlockRequest):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    from datetime import datetime
    st = datetime.strptime(request.start_time, "%H:%M").time()
    et = datetime.strptime(request.end_time, "%H:%M").time()
    result = await _service.create_time_block(request.name, st, et, request.days_of_week, request.block_type, request.color)
    return APIResponse(success=True, data=result.model_dump() if hasattr(result, "model_dump") else result)

@router.get("/time-blocks", response_model=APIResponse)
async def get_time_blocks():
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.get_time_blocks()
    return APIResponse(success=True, data=[t.model_dump() if hasattr(t, "model_dump") else t for t in result])

@router.get("/reminders", response_model=APIResponse)
async def get_reminders(dismissed: bool = Query(False)):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.get_reminders(dismissed)
    return APIResponse(success=True, data=[r.model_dump() if hasattr(r, "model_dump") else r for r in result])

@router.post("/reminders/{reminder_id}/dismiss", response_model=APIResponse)
async def dismiss_reminder(reminder_id: UUID):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    await _service.dismiss_reminder(reminder_id)
    return APIResponse(success=True)
