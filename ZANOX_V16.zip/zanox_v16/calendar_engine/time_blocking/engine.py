"""Time Blocking Engine - Creates and manages time blocks."""
from datetime import datetime, time, timedelta
from typing import Dict, List

class TimeBlockingEngine:
    BLOCK_TYPES = {
        "focus": {"color": "#6366f1", "label": "Deep Work"},
        "meeting": {"color": "#f59e0b", "label": "Meetings"},
        "break": {"color": "#10b981", "label": "Break"},
        "personal": {"color": "#ec4899", "label": "Personal"},
        "learning": {"color": "#8b5cf6", "label": "Learning"},
        "admin": {"color": "#6b7280", "label": "Admin"}
    }

    async def generate_daily_blocks(self, date: datetime, work_start: int = 9, work_end: int = 17) -> List[Dict]:
        blocks = []
        current = datetime(date.year, date.month, date.day, work_start, 0)
        while current.hour < work_end:
            block_type = "focus" if 9 <= current.hour <= 11 else ("meeting" if 14 <= current.hour <= 16 else "admin")
            blocks.append({
                "start": current.isoformat(),
                "end": (current + timedelta(hours=1)).isoformat(),
                "type": block_type,
                **self.BLOCK_TYPES[block_type]
            })
            current += timedelta(hours=1)
        return blocks
