"""Event Management - Calendar event handling."""
from .service import EventManagementService
