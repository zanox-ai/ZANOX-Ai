"""Calendar Service - Full calendar management with events and scheduling."""
import json
from datetime import datetime, date, time, timedelta
from typing import Dict, List, Optional, Any
from uuid import UUID, uuid4
import asyncpg
from ..models import CalendarEvent, CalendarEventCreate, TimeBlock, Reminder, EventType

class CalendarService:
    def __init__(self):
        self.db_pool = None
    def initialize(self, db_pool, redis_client):
        self.db_pool = db_pool

    async def create_event(self, event: CalendarEventCreate) -> CalendarEvent:
        if not self.db_pool:
            raise RuntimeError("Database not initialized")
        eid = uuid4()
        await self.db_pool.execute(
            """INSERT INTO calendar_events (id, title, description, event_type, start_time, end_time, timezone, location, attendees, linked_task_id, linked_project_id, linked_goal_id, color, created_at, updated_at)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, NOW(), NOW())""",
            eid, event.title, event.description, event.event_type.value, event.start_time, event.end_time,
            event.timezone, event.location, json.dumps(event.attendees),
            str(event.linked_task_id) if event.linked_task_id else None,
            str(event.linked_project_id) if event.linked_project_id else None,
            str(event.linked_goal_id) if event.linked_goal_id else None,
            event.color
        )
        # Create reminders
        for minutes_before in event.reminders:
            rid = uuid4()
            trigger = event.start_time - timedelta(minutes=minutes_before)
            await self.db_pool.execute(
                """INSERT INTO reminders (id, title, message, trigger_time, entity_type, entity_id, created_at)
                 VALUES ($1, $2, $3, $4, 'event', $5, NOW())""",
                rid, f"Reminder: {event.title}", f"Your event '{event.title}' starts in {minutes_before} minutes",
                trigger, eid
            )
        return await self.get_event(eid)

    async def get_event(self, event_id: UUID) -> Optional[CalendarEvent]:
        if not self.db_pool:
            return None
        row = await self.db_pool.fetchrow("SELECT * FROM calendar_events WHERE id = $1", event_id)
        if not row:
            return None
        return CalendarEvent(
            id=row["id"], title=row["title"], description=row["description"],
            event_type=EventType(row["event_type"]), start_time=row["start_time"],
            end_time=row["end_time"], timezone=row["timezone"], location=row["location"],
            is_recurring=row["is_recurring"] or False, recurring_rule=row["recurring_rule"],
            attendees=json.loads(row["attendees"]) if row["attendees"] else [],
            linked_task_id=UUID(row["linked_task_id"]) if row["linked_task_id"] else None,
            linked_project_id=UUID(row["linked_project_id"]) if row["linked_project_id"] else None,
            linked_goal_id=UUID(row["linked_goal_id"]) if row["linked_goal_id"] else None,
            color=row["color"], created_at=row["created_at"], updated_at=row["updated_at"]
        )

    async def list_events(self, start: datetime, end: datetime, event_type: Optional[str] = None) -> List[CalendarEvent]:
        if not self.db_pool:
            return []
        q = "SELECT * FROM calendar_events WHERE start_time >= $1 AND start_time < $2"
        params = [start, end]
        if event_type:
            q += f" AND event_type = ${len(params)+1}"
            params.append(event_type)
        q += " ORDER BY start_time"
        rows = await self.db_pool.fetch(q, *params)
        return [await self.get_event(r["id"]) for r in rows]

    async def update_event(self, event_id: UUID, updates: Dict) -> Optional[CalendarEvent]:
        if not self.db_pool:
            return None
        set_clauses = []
        params = [event_id]
        for key in ("title", "description", "start_time", "end_time", "location", "color"):
            if key in updates:
                set_clauses.append(f"{key} = ${len(params)+1}")
                params.append(updates[key])
        if set_clauses:
            set_clauses.append("updated_at = NOW()")
            await self.db_pool.execute(f"UPDATE calendar_events SET {', '.join(set_clauses)} WHERE id = $1", *params)
        return await self.get_event(event_id)

    async def delete_event(self, event_id: UUID):
        if not self.db_pool:
            return False
        await self.db_pool.execute("DELETE FROM calendar_events WHERE id = $1", event_id)
        await self.db_pool.execute("DELETE FROM reminders WHERE entity_id = $1 AND entity_type = 'event'", event_id)
        return True

    async def create_time_block(self, name: str, start: time, end: time, days: List[int], block_type: str = "focus", color: Optional[str] = None) -> TimeBlock:
        if not self.db_pool:
            raise RuntimeError("Database not initialized")
        tid = uuid4()
        await self.db_pool.execute(
            """INSERT INTO time_blocks (id, name, start_time, end_time, days_of_week, block_type, color, active, created_at)
             VALUES ($1, $2, $3, $4, $5, $6, $7, true, NOW())""",
            tid, name, start, end, days, block_type, color
        )
        return TimeBlock(id=tid, name=name, start_time=start, end_time=end, days_of_week=days, block_type=block_type, color=color)

    async def get_time_blocks(self) -> List[TimeBlock]:
        if not self.db_pool:
            return []
        rows = await self.db_pool.fetch("SELECT * FROM time_blocks WHERE active = true ORDER BY start_time")
        return [TimeBlock(id=r["id"], name=r["name"], start_time=r["start_time"], end_time=r["end_time"], days_of_week=r["days_of_week"], block_type=r["block_type"], color=r["color"], active=r["active"], created_at=r["created_at"]) for r in rows]

    async def get_reminders(self, dismissed: bool = False) -> List[Reminder]:
        if not self.db_pool:
            return []
        rows = await self.db_pool.fetch(
            "SELECT * FROM reminders WHERE dismissed = $1 ORDER BY trigger_time", dismissed
        )
        return [Reminder(id=r["id"], title=r["title"], message=r["message"], trigger_time=r["trigger_time"], entity_type=r["entity_type"], entity_id=r["entity_id"], dismissed=r["dismissed"], dismissed_at=r["dismissed_at"], created_at=r["created_at"]) for r in rows]

    async def dismiss_reminder(self, reminder_id: UUID):
        if not self.db_pool:
            return False
        await self.db_pool.execute("UPDATE reminders SET dismissed = true, dismissed_at = NOW() WHERE id = $1", reminder_id)
        return True
