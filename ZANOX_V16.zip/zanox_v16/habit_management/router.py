"""Habit Management Router - FastAPI endpoints."""
from typing import Optional
from uuid import UUID
from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from ..models import APIResponse
from .service import HabitService

router = APIRouter()
_service: Optional[HabitService] = None

def set_service(service: HabitService):
    global _service
    _service = service

class HabitCreateRequest(BaseModel):
    name: str
    description: Optional[str] = None
    frequency: str = "daily"
    target_per_period: int = 1
    color: Optional[str] = "#10b981"
    icon: Optional[str] = "check"

@router.post("", response_model=APIResponse)
async def create_habit(request: HabitCreateRequest):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    from ..models import HabitCreate, HabitFrequency
    habit_data = HabitCreate(
        name=request.name, description=request.description,
        frequency=HabitFrequency(request.frequency), target_per_period=request.target_per_period,
        color=request.color, icon=request.icon
    )
    result = await _service.create_habit(habit_data)
    return APIResponse(success=True, data=result.model_dump() if hasattr(result, "model_dump") else result)

@router.get("", response_model=APIResponse)
async def list_habits(active_only: bool = Query(True)):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.list_habits(active_only)
    return APIResponse(success=True, data=[h.model_dump() if hasattr(h, "model_dump") else h for h in result])

@router.get("/{habit_id}", response_model=APIResponse)
async def get_habit(habit_id: UUID):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.get_habit(habit_id)
    if not result:
        raise HTTPException(status_code=404, detail="Habit not found")
    return APIResponse(success=True, data=result.model_dump() if hasattr(result, "model_dump") else result)

@router.post("/{habit_id}/log", response_model=APIResponse)
async def log_habit(habit_id: UUID, notes: Optional[str] = None, value: Optional[float] = None, mood: Optional[int] = Query(None)):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.log_habit(habit_id, notes, value, mood)
    return APIResponse(success=True, data=result.model_dump() if hasattr(result, "model_dump") else result)

@router.get("/{habit_id}/logs", response_model=APIResponse)
async def get_habit_logs(habit_id: UUID, days: int = Query(30)):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.get_logs(habit_id, days)
    return APIResponse(success=True, data=[l.model_dump() if hasattr(l, "model_dump") else l for l in result])
