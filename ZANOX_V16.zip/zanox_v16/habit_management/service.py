"""Habit Management Service - Habit tracking with streaks and analytics."""
import json
from datetime import datetime, date, timedelta
from typing import Dict, List, Optional, Any
from uuid import UUID, uuid4
import asyncpg
from ..models import Habit, HabitCreate, HabitLog, HabitFrequency

class HabitService:
    def __init__(self):
        self.db_pool = None
    def initialize(self, db_pool, redis_client):
        self.db_pool = db_pool

    async def create_habit(self, habit: HabitCreate) -> Habit:
        if not self.db_pool:
            raise RuntimeError("Database not initialized")
        hid = uuid4()
        await self.db_pool.execute(
            """INSERT INTO habits (id, name, description, frequency, target_per_period, color, icon, reminder_time, associated_goal_id, active, created_at)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, true, NOW())""",
            hid, habit.name, habit.description, habit.frequency.value, habit.target_per_period,
            habit.color, habit.icon, habit.reminder_time,
            str(habit.associated_goal_id) if habit.associated_goal_id else None
        )
        return Habit(id=hid, name=habit.name, description=habit.description,
                     frequency=habit.frequency, target_per_period=habit.target_per_period,
                     color=habit.color, icon=habit.icon, reminder_time=habit.reminder_time,
                     associated_goal_id=habit.associated_goal_id)

    async def get_habit(self, habit_id: UUID) -> Optional[Habit]:
        if not self.db_pool:
            return None
        row = await self.db_pool.fetchrow("SELECT * FROM habits WHERE id = $1", habit_id)
        if not row:
            return None
        return Habit(
            id=row["id"], name=row["name"], description=row["description"],
            frequency=HabitFrequency(row["frequency"]), target_per_period=row["target_per_period"],
            color=row["color"], icon=row["icon"], reminder_time=row["reminder_time"],
            associated_goal_id=UUID(row["associated_goal_id"]) if row["associated_goal_id"] else None,
            current_streak=row["current_streak"] or 0, longest_streak=row["longest_streak"] or 0,
            total_completions=row["total_completions"] or 0,
            last_completed=row["last_completed"], active=row["active"],
            created_at=row["created_at"]
        )

    async def list_habits(self, active_only: bool = True) -> List[Habit]:
        if not self.db_pool:
            return []
        q = "SELECT * FROM habits"
        if active_only:
            q += " WHERE active = true"
        q += " ORDER BY name"
        rows = await self.db_pool.fetch(q)
        return [await self.get_habit(r["id"]) for r in rows]

    async def log_habit(self, habit_id: UUID, notes: Optional[str] = None, value: Optional[float] = None, mood: Optional[int] = None) -> HabitLog:
        if not self.db_pool:
            raise RuntimeError("Database not initialized")
        lid = uuid4()
        now = datetime.utcnow()
        await self.db_pool.execute(
            "INSERT INTO habit_logs (id, habit_id, completed_at, notes, value, mood) VALUES ($1, $2, $3, $4, $5, $6)",
            lid, habit_id, now, notes, value, mood
        )

        # Update streaks
        await self._update_streak(habit_id, now)

        return HabitLog(id=lid, habit_id=habit_id, completed_at=now, notes=notes, value=value, mood=mood)

    async def _update_streak(self, habit_id: UUID, completed_at: datetime):
        if not self.db_pool:
            return
        habit = await self.db_pool.fetchrow("SELECT current_streak, longest_streak, last_completed, frequency FROM habits WHERE id = $1", habit_id)
        if not habit:
            return

        last = habit["last_completed"]
        freq = habit["frequency"]
        current = habit["current_streak"] or 0
        longest = habit["longest_streak"] or 0

        # Check if consecutive
        if freq == "daily":
            is_consecutive = last and (completed_at.date() - last.date()).days <= 1
        elif freq == "weekly":
            is_consecutive = last and (completed_at.date() - last.date()).days <= 7
        else:
            is_consecutive = True

        new_streak = current + 1 if is_consecutive else 1
        new_longest = max(longest, new_streak)

        await self.db_pool.execute(
            """UPDATE habits SET current_streak = $1, longest_streak = $2, total_completions = total_completions + 1,
               last_completed = $3, updated_at = NOW() WHERE id = $4""",
            new_streak, new_longest, completed_at, habit_id
        )

    async def get_logs(self, habit_id: UUID, days: int = 30) -> List[HabitLog]:
        if not self.db_pool:
            return []
        rows = await self.db_pool.fetch(
            "SELECT * FROM habit_logs WHERE habit_id = $1 AND completed_at > NOW() - INTERVAL '%s days' ORDER BY completed_at DESC" % days,
            habit_id
        )
        return [HabitLog(id=r["id"], habit_id=r["habit_id"], completed_at=r["completed_at"], notes=r["notes"], value=r["value"], mood=r["mood"]) for r in rows]
