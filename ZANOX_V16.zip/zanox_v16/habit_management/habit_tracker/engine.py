"""Habit Tracking Engine - Streak calculation and tracking logic."""
from datetime import datetime, date, timedelta
from typing import Dict, List, Optional
from uuid import UUID
import asyncpg

class HabitTrackingEngine:
    def __init__(self):
        self.db_pool = None
    def initialize(self, db_pool):
        self.db_pool = db_pool

    async def get_streak_status(self, habit_id: UUID) -> Dict:
        if not self.db_pool:
            return {}
        row = await self.db_pool.fetchrow("SELECT current_streak, longest_streak, last_completed, frequency FROM habits WHERE id = $1", habit_id)
        if not row:
            return {}
        return {
            "current_streak": row["current_streak"] or 0,
            "longest_streak": row["longest_streak"] or 0,
            "last_completed": row["last_completed"].isoformat() if row["last_completed"] else None,
            "at_risk": self._is_streak_at_risk(row["last_completed"], row["frequency"])
        }

    def _is_streak_at_risk(self, last_completed: Optional[datetime], frequency: str) -> bool:
        if not last_completed:
            return False
        today = date.today()
        if frequency == "daily":
            return (today - last_completed.date()).days >= 1
        elif frequency == "weekly":
            return (today - last_completed.date()).days >= 6
        return False
