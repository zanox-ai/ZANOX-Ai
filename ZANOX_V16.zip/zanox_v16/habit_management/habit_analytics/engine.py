"""Habit Analytics Engine - Completion rates, trends, and insights."""
from datetime import datetime, date, timedelta
from typing import Dict, List, Optional
from uuid import UUID
import asyncpg

class HabitAnalyticsEngine:
    def __init__(self):
        self.db_pool = None
    def initialize(self, db_pool):
        self.db_pool = db_pool

    async def get_analytics(self, habit_id: UUID) -> Dict:
        if not self.db_pool:
            return {}
        # 30-day completion rate
        d30 = await self.db_pool.fetchval(
            """SELECT COUNT(DISTINCT DATE(completed_at)) FROM habit_logs
               WHERE habit_id = $1 AND completed_at > NOW() - INTERVAL '30 days'""", habit_id
        ) or 0
        # 7-day completion rate
        d7 = await self.db_pool.fetchval(
            """SELECT COUNT(DISTINCT DATE(completed_at)) FROM habit_logs
               WHERE habit_id = $1 AND completed_at > NOW() - INTERVAL '7 days'""", habit_id
        ) or 0
        habit = await self.db_pool.fetchrow("SELECT * FROM habits WHERE id = $1", habit_id)
        if not habit:
            return {}
        rate_30 = min((d30 / 30) * 100, 100)
        rate_7 = min((d7 / 7) * 100, 100)
        trend = "improving" if rate_7 > rate_30 else ("stable" if rate_7 == rate_30 else "declining")
        return {
            "habit_id": str(habit_id),
            "completion_rate_30d": round(rate_30, 1),
            "completion_rate_7d": round(rate_7, 1),
            "current_streak": habit["current_streak"] or 0,
            "longest_streak": habit["longest_streak"] or 0,
            "total_completions": habit["total_completions"] or 0,
            "trend": trend,
            "consistency_score": round(min(rate_30 / 100 * 5, 5), 1),
            "next_milestone": self._next_milestone(habit["current_streak"] or 0)
        }

    def _next_milestone(self, streak: int) -> int:
        milestones = [7, 14, 30, 60, 90, 180, 365]
        for m in milestones:
            if streak < m:
                return m
        return 730
