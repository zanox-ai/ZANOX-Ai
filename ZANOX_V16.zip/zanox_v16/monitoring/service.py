"""Monitoring Service - Tracks system health and user activity."""
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
import asyncpg

class MonitoringService:
    def __init__(self):
        self.db_pool = None
        self.redis = None
    def initialize(self, db_pool, redis_client):
        self.db_pool = db_pool
        self.redis = redis_client

    async def log_activity(self, activity_type: str, details: Optional[Dict] = None):
        """Log user activity for analytics."""
        if self.db_pool:
            await self.db_pool.execute(
                "INSERT INTO activity_log (id, activity_type, details, created_at) VALUES (gen_random_uuid(), $1, $2, NOW())",
                activity_type, details or {}
            )

    async def get_activity_summary(self, days: int = 7) -> Dict[str, int]:
        """Get activity summary."""
        if not self.db_pool:
            return {}
        rows = await self.db_pool.fetch(
            "SELECT activity_type, COUNT(*) as count FROM activity_log WHERE created_at > NOW() - INTERVAL '%s days' GROUP BY activity_type" % days
        )
        return {r["activity_type"]: r["count"] for r in rows}

    async def get_system_health(self) -> Dict[str, Any]:
        """Get system health status."""
        health = {
            "status": "healthy",
            "timestamp": datetime.utcnow().isoformat(),
            "database": "connected" if self.db_pool else "disconnected",
            "cache": "connected" if self.redis else "disconnected",
            "services": {}
        }
        return health

    async def check_data_integrity(self) -> List[Dict[str, str]]:
        """Check for data integrity issues."""
        issues = []
        if self.db_pool:
            # Check orphaned tasks (references to non-existent projects)
            orphaned = await self.db_pool.fetch(
                "SELECT id, title FROM tasks WHERE project_id IS NOT NULL AND project_id NOT IN (SELECT id FROM projects)"
            )
            for o in orphaned:
                issues.append({"type": "orphaned_task", "id": str(o["id"]), "title": o["title"]})
        return issues
