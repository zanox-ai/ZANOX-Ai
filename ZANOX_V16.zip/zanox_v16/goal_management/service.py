"""Goal Management Service - Full OKR lifecycle management."""
import json
from datetime import datetime, date
from typing import Dict, List, Optional, Any
from uuid import UUID, uuid4
import asyncpg
from ..models import Goal, GoalCreate, GoalStatus, KeyResult, GoalAnalytics, PriorityLevel

class GoalService:
    def __init__(self):
        self.db_pool = None
    def initialize(self, db_pool, redis_client):
        self.db_pool = db_pool

    async def create_goal(self, goal: GoalCreate) -> Goal:
        if not self.db_pool:
            raise RuntimeError("Database not initialized")
        gid = uuid4()
        await self.db_pool.execute(
            """INSERT INTO goals (id, title, description, status, priority, category, target_date, parent_goal_id, owner_id, created_at, updated_at)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, NOW(), NOW())""",
            gid, goal.title, goal.description, goal.status.value, goal.priority.value,
            goal.category, goal.target_date,
            str(goal.parent_goal_id) if goal.parent_goal_id else None,
            str(goal.owner_id) if goal.owner_id else None
        )
        for kr_desc in goal.key_results:
            kr_id = uuid4()
            await self.db_pool.execute(
                "INSERT INTO key_results (id, goal_id, description, target_value, current_value, unit, deadline) VALUES ($1, $2, $3, 100.0, 0.0, '%', $4)",
                kr_id, gid, kr_desc, goal.target_date
            )
        return await self.get_goal(gid)

    async def get_goal(self, goal_id: UUID) -> Optional[Goal]:
        if not self.db_pool:
            return None
        row = await self.db_pool.fetchrow("SELECT * FROM goals WHERE id = $1", goal_id)
        if not row:
            return None
        krs = await self.db_pool.fetch("SELECT * FROM key_results WHERE goal_id = $1", goal_id)
        subgoals = await self.db_pool.fetch("SELECT * FROM goals WHERE parent_goal_id = $1", goal_id)
        return Goal(
            id=row["id"], title=row["title"], description=row["description"],
            status=GoalStatus(row["status"]), priority=PriorityLevel(row["priority"]),
            category=row["category"], target_date=row["target_date"],
            parent_goal_id=UUID(row["parent_goal_id"]) if row["parent_goal_id"] else None,
            owner_id=UUID(row["owner_id"]) if row["owner_id"] else None,
            created_at=row["created_at"], updated_at=row["updated_at"],
            progress_percentage=row["progress_percentage"] or 0.0,
            key_results=[KeyResult(id=r["id"], goal_id=r["goal_id"], description=r["description"],
                         target_value=r["target_value"], current_value=r["current_value"],
                         unit=r["unit"], deadline=r["deadline"], status=r["status"], created_at=r["created_at"]) for r in krs],
            subgoals=[await self.get_goal(r["id"]) for r in subgoals]
        )

    async def list_goals(self, status=None, category=None) -> List[Goal]:
        if not self.db_pool:
            return []
        where = []
        params = []
        if status:
            where.append(f"status = ${len(params)+1}")
            params.append(status)
        if category:
            where.append(f"category = ${len(params)+1}")
            params.append(category)
        q = "SELECT * FROM goals"
        if where:
            q += " WHERE " + " AND ".join(where)
        q += " ORDER BY priority, created_at"
        rows = await self.db_pool.fetch(q, *params)
        return [await self.get_goal(r["id"]) for r in rows]

    async def update_key_result(self, kr_id: UUID, current_value: float):
        if not self.db_pool:
            return
        await self.db_pool.execute(
            "UPDATE key_results SET current_value = $1, updated_at = NOW() WHERE id = $2",
            current_value, kr_id
        )
        # Update goal progress
        row = await self.db_pool.fetchrow("SELECT goal_id FROM key_results WHERE id = $1", kr_id)
        if row:
            await self._recalculate_goal_progress(row["goal_id"])

    async def _recalculate_goal_progress(self, goal_id: UUID):
        if not self.db_pool:
            return
        await self.db_pool.execute(
            """UPDATE goals SET progress_percentage = (
                SELECT COALESCE(AVG((current_value / NULLIF(target_value, 0)) * 100), 0)
                FROM key_results WHERE goal_id = $1
            ), updated_at = NOW() WHERE id = $1""", goal_id
        )

    async def get_analytics(self, goal_id: UUID) -> GoalAnalytics:
        goal = await self.get_goal(goal_id)
        if not goal:
            return GoalAnalytics(goal_id=goal_id, completion_rate=0.0, days_remaining=None, pace_status="at_risk", key_results_progress=[], contributing_projects=0, contributing_tasks=0, weekly_velocity=0.0, predicted_completion_date=None)

        days_remaining = (goal.target_date - date.today()).days if goal.target_date else None
        completion_rate = goal.progress_percentage

        if days_remaining and days_remaining > 0:
            needed_velocity = (100 - completion_rate) / max(days_remaining / 7, 1)
            if needed_velocity < 2:
                pace = "ahead"
            elif needed_velocity < 5:
                pace = "on_track"
            elif needed_velocity < 10:
                pace = "behind"
            else:
                pace = "at_risk"
        else:
            pace = "at_risk"

        if self.db_pool:
            projects = await self.db_pool.fetchval("SELECT COUNT(*) FROM projects WHERE id IN (SELECT project_id FROM tasks WHERE goal_id = $1)", goal_id) or 0
            tasks = await self.db_pool.fetchval("SELECT COUNT(*) FROM tasks WHERE goal_id = $1", goal_id) or 0
        else:
            projects, tasks = 0, 0

        kr_progress = [{"description": kr.description, "progress": (kr.current_value / max(kr.target_value, 1)) * 100, "status": kr.status} for kr in goal.key_results]

        return GoalAnalytics(
            goal_id=goal_id, completion_rate=completion_rate, days_remaining=days_remaining,
            pace_status=pace, key_results_progress=kr_progress, contributing_projects=projects,
            contributing_tasks=tasks, weekly_velocity=completion_rate / max(1, 7),
            predicted_completion_date=goal.target_date
        )
