"""Goal Analytics - Advanced goal analytics engine."""
from .engine import GoalAnalyticsEngine
