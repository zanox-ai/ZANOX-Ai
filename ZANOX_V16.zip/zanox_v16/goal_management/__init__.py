"""ZANOX V16 - Goal Management System with OKR support."""
from .router import router
from .service import GoalService
__all__ = ["router", "GoalService"]
