"""Goal Management Router - FastAPI endpoints."""
from typing import Optional
from uuid import UUID
from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from datetime import date
from ..models import APIResponse
from .service import GoalService

router = APIRouter()
_service: Optional[GoalService] = None

def set_service(service: GoalService):
    global _service
    _service = service

class GoalCreateRequest(BaseModel):
    title: str
    description: Optional[str] = None
    priority: str = "medium"
    category: Optional[str] = None
    target_date: Optional[date] = None
    key_results: list = []

@router.post("", response_model=APIResponse)
async def create_goal(request: GoalCreateRequest):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    from ..models import GoalCreate, GoalStatus, PriorityLevel
    goal_data = GoalCreate(
        title=request.title, description=request.description,
        priority=PriorityLevel(request.priority), status=GoalStatus.ACTIVE,
        category=request.category, target_date=request.target_date,
        key_results=request.key_results
    )
    result = await _service.create_goal(goal_data)
    return APIResponse(success=True, data=result.model_dump() if hasattr(result, "model_dump") else result)

@router.get("", response_model=APIResponse)
async def list_goals(status: Optional[str] = Query(None), category: Optional[str] = Query(None)):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.list_goals(status=status, category=category)
    return APIResponse(success=True, data=[g.model_dump() if hasattr(g, "model_dump") else g for g in result])

@router.get("/{goal_id}", response_model=APIResponse)
async def get_goal(goal_id: UUID):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.get_goal(goal_id)
    if not result:
        raise HTTPException(status_code=404, detail="Goal not found")
    return APIResponse(success=True, data=result.model_dump() if hasattr(result, "model_dump") else result)

@router.put("/{goal_id}/key-results/{kr_id}", response_model=APIResponse)
async def update_key_result(goal_id: UUID, kr_id: UUID, current_value: float = Query(...)):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    await _service.update_key_result(kr_id, current_value)
    return APIResponse(success=True, message="Key result updated")

@router.get("/{goal_id}/analytics", response_model=APIResponse)
async def get_goal_analytics(goal_id: UUID):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.get_analytics(goal_id)
    return APIResponse(success=True, data=result.model_dump() if hasattr(result, "model_dump") else result)
