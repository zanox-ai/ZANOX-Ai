"""Goal Tracking - Progress tracking engine."""
from .tracker import GoalTracker
