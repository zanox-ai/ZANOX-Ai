"""Dashboard Engine - Aggregates all personal data into a unified view."""
from datetime import datetime, date, timedelta
from typing import Dict, List, Optional, Any
import asyncpg

class DashboardEngine:
    def __init__(self):
        self.db_pool = None
    def initialize(self, db_pool, redis_client):
        self.db_pool = db_pool

    async def get_dashboard(self, target_date: Optional[date] = None) -> Dict[str, Any]:
        if not self.db_pool:
            return {}
        target = target_date or date.today()

        # Tasks
        tasks_pending = await self.db_pool.fetchval(
            "SELECT COUNT(*) FROM tasks WHERE status NOT IN ('completed', 'cancelled')"
        ) or 0
        tasks_due_today = await self.db_pool.fetchval(
            "SELECT COUNT(*) FROM tasks WHERE DATE(due_date) = $1 AND status NOT IN ('completed', 'cancelled')", target
        ) or 0
        tasks_completed_today = await self.db_pool.fetchval(
            "SELECT COUNT(*) FROM tasks WHERE status = 'completed' AND DATE(updated_at) = $1", target
        ) or 0

        # Events
        events = await self.db_pool.fetch(
            "SELECT id, title, start_time, event_type FROM calendar_events WHERE DATE(start_time) = $1 ORDER BY start_time", target
        )

        # Habits
        habits = await self.db_pool.fetch("SELECT id, name, current_streak, active FROM habits WHERE active = true ORDER BY name")
        habits_today = await self.db_pool.fetch(
            """SELECT h.id, h.name, EXISTS(SELECT 1 FROM habit_logs hl WHERE hl.habit_id = h.id AND DATE(hl.completed_at) = $1) as done
               FROM habits h WHERE h.active = true""", target
        )

        # Goals
        goals = await self.db_pool.fetch(
            "SELECT id, title, progress_percentage, status FROM goals WHERE status IN ('active', 'in_progress') ORDER BY priority LIMIT 5"
        )

        # Focus
        focus_min = await self.db_pool.fetchval(
            "SELECT COALESCE(SUM(actual_duration_minutes), 0) FROM focus_sessions WHERE DATE(started_at) = $1", target
        ) or 0

        # Productivity score
        completion_rate = (tasks_completed_today / max(tasks_completed_today + tasks_pending, 1)) * 100
        focus_score = min(focus_min / 240, 1) * 100
        productivity_score = round(completion_rate * 0.6 + focus_score * 0.4, 1)

        return {
            "date": target.isoformat(),
            "generated_at": datetime.utcnow().isoformat(),
            "tasks": {
                "pending": tasks_pending,
                "due_today": tasks_due_today,
                "completed_today": tasks_completed_today
            },
            "events": [{"id": str(r["id"]), "title": r["title"], "start": r["start_time"].isoformat() if r["start_time"] else None, "type": r["event_type"]} for r in events],
            "habits": [{"id": str(h["id"]), "name": h["name"], "done": h["done"]} for h in habits_today],
            "goals": [{"id": str(g["id"]), "title": g["title"], "progress": g["progress_percentage"] or 0} for g in goals],
            "focus": {"minutes_today": focus_min, "hours_today": round(focus_min / 60, 1)},
            "productivity_score": productivity_score,
            "weekly_trend": 0.0,
            "focus_score": round(focus_score, 1),
            "balance_score": 70.0,
            "notifications": [],
            "recent_notes": []
        }

    async def get_weekly_overview(self) -> Dict[str, Any]:
        today = date.today()
        week_start = today - timedelta(days=today.weekday())
        days = []
        for i in range(7):
            day = week_start + timedelta(days=i)
            day_data = await self.get_dashboard(day)
            days.append({
                "date": day.isoformat(),
                "day": day.strftime("%a"),
                "tasks_completed": day_data.get("tasks", {}).get("completed_today", 0),
                "focus_minutes": day_data.get("focus", {}).get("minutes_today", 0),
                "productivity_score": day_data.get("productivity_score", 0)
            })
        return {"week_start": week_start.isoformat(), "days": days}
