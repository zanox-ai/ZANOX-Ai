"""Life Dashboard Router - FastAPI endpoints."""
from typing import Optional
from fastapi import APIRouter, HTTPException, Query
from datetime import date
from ..models import APIResponse
from .engine import DashboardEngine

router = APIRouter()
_engine: Optional[DashboardEngine] = None

def set_engine(engine: DashboardEngine):
    global _engine
    _engine = engine

@router.get("/today", response_model=APIResponse)
async def get_today_dashboard():
    if not _engine:
        raise HTTPException(status_code=503, detail="Engine not initialized")
    result = await _engine.get_dashboard()
    return APIResponse(success=True, data=result)

@router.get("/date/{target_date}", response_model=APIResponse)
async def get_dashboard_for_date(target_date: date):
    if not _engine:
        raise HTTPException(status_code=503, detail="Engine not initialized")
    result = await _engine.get_dashboard(target_date)
    return APIResponse(success=True, data=result)

@router.get("/weekly", response_model=APIResponse)
async def get_weekly_overview():
    if not _engine:
        raise HTTPException(status_code=503, detail="Engine not initialized")
    result = await _engine.get_weekly_overview()
    return APIResponse(success=True, data=result)
