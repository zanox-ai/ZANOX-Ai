"""
ZANOX V16 Configuration Module
Production-ready configuration for all subsystems.
"""

import os
from dataclasses import dataclass, field
from typing import List, Dict, Optional
from enum import Enum


class Environment(str, Enum):
    DEVELOPMENT = "development"
    STAGING = "staging"
    PRODUCTION = "production"


@dataclass
class DatabaseConfig:
    host: str = os.getenv("POSTGRES_HOST", "postgres")
    port: int = int(os.getenv("POSTGRES_PORT", "5432"))
    user: str = os.getenv("POSTGRES_USER", "zanox")
    password: str = os.getenv("POSTGRES_PASSWORD", "zanox")
    database: str = os.getenv("POSTGRES_DB", "zanox_v16")
    pool_min_size: int = 5
    pool_max_size: int = 20
    command_timeout: int = 60

    @property
    def dsn(self) -> str:
        return (
            f"postgresql://{self.user}:{self.password}"
            f"@{self.host}:{self.port}/{self.database}"
        )


@dataclass
class RedisConfig:
    host: str = os.getenv("REDIS_HOST", "redis")
    port: int = int(os.getenv("REDIS_PORT", "6379"))
    db: int = int(os.getenv("REDIS_DB", "0"))
    password: Optional[str] = os.getenv("REDIS_PASSWORD")
    decode_responses: bool = True


@dataclass
class KafkaConfig:
    bootstrap_servers: List[str] = field(
        default_factory=lambda: os.getenv("KAFKA_BOOTSTRAP_SERVERS", "kafka:9092").split(",")
    )
    topic_prefix: str = "zanox.v16"
    retries: int = 3
    acks: str = "all"


@dataclass
class OpenTelemetryConfig:
    service_name: str = "zanox-v16-personal-assistant"
    otlp_endpoint: str = os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT", "http://otel-collector:4317")
    insecure: bool = True


@dataclass
class SecurityConfig:
    jwt_secret: str = os.getenv("JWT_SECRET", "zanox-v16-super-secret-key")
    jwt_algorithm: str = "HS256"
    jwt_expiration_hours: int = 24
    encryption_key: str = os.getenv("ENCRYPTION_KEY", "zanox-encryption-key-32bytes!!")
    max_login_attempts: int = 5
    lockout_duration_minutes: int = 30


@dataclass
class CalendarConfig:
    google_client_id: str = os.getenv("GOOGLE_CLIENT_ID", "")
    google_client_secret: str = os.getenv("GOOGLE_CLIENT_SECRET", "")
    google_redirect_uri: str = os.getenv("GOOGLE_REDIRECT_URI", "http://localhost:8000/auth/google/callback")
    microsoft_client_id: str = os.getenv("MICROSOFT_CLIENT_ID", "")
    microsoft_client_secret: str = os.getenv("MICROSOFT_CLIENT_SECRET", "")
    apple_team_id: str = os.getenv("APPLE_TEAM_ID", "")
    apple_key_id: str = os.getenv("APPLE_KEY_ID", "")
    apple_private_key: str = os.getenv("APPLE_PRIVATE_KEY", "")


@dataclass
class IntegrationConfig:
    notion_token: str = os.getenv("NOTION_TOKEN", "")
    obsidian_vault_path: str = os.getenv("OBSIDIAN_VAULT_PATH", "")
    evernote_token: str = os.getenv("EVERNOTE_TOKEN", "")
    google_drive_credentials: str = os.getenv("GOOGLE_DRIVE_CREDENTIALS", "")
    onedrive_client_id: str = os.getenv("ONEDRIVE_CLIENT_ID", "")
    dropbox_token: str = os.getenv("DROPBOX_TOKEN", "")
    telegram_bot_token: str = os.getenv("TELEGRAM_BOT_TOKEN", "")
    gmail_credentials: str = os.getenv("GMAIL_CREDENTIALS", "")
    slack_bot_token: str = os.getenv("SLACK_BOT_TOKEN", "")
    discord_bot_token: str = os.getenv("DISCORD_BOT_TOKEN", "")
    todoist_token: str = os.getenv("TODOIST_TOKEN", "")
    ticktick_token: str = os.getenv("TICKTICK_TOKEN", "")
    clickup_token: str = os.getenv("CLICKUP_TOKEN", "")
    trello_key: str = os.getenv("TRELLO_KEY", "")
    trello_token: str = os.getenv("TRELLO_TOKEN", "")
    asana_token: str = os.getenv("ASANA_TOKEN", "")
    jira_base_url: str = os.getenv("JIRA_BASE_URL", "")
    jira_username: str = os.getenv("JIRA_USERNAME", "")
    jira_api_token: str = os.getenv("JIRA_API_TOKEN", "")
    linear_token: str = os.getenv("LINEAR_TOKEN", "")
    github_token: str = os.getenv("GITHUB_TOKEN", "")


@dataclass
class ProductivityConfig:
    default_pomodoro_duration: int = 25
    default_short_break: int = 5
    default_long_break: int = 15
    pomodoros_before_long_break: int = 4
    max_daily_pomodoros: int = 16
    deep_work_default_duration: int = 90
    daily_focus_goal_hours: float = 4.0
    weekly_focus_goal_hours: float = 20.0
    task_batch_size: int = 5
    priority_levels: List[str] = field(
        default_factory=lambda: ["urgent", "high", "medium", "low", "minimal"]
    )
    urgency_decay_hours: int = 48


@dataclass
class ZANOXV16Config:
    env: Environment = Environment(os.getenv("ZANOX_ENV", "development"))
    debug: bool = os.getenv("DEBUG", "false").lower() == "true"
    host: str = os.getenv("HOST", "0.0.0.0")
    port: int = int(os.getenv("PORT", "8000"))
    database: DatabaseConfig = field(default_factory=DatabaseConfig)
    redis: RedisConfig = field(default_factory=RedisConfig)
    kafka: KafkaConfig = field(default_factory=KafkaConfig)
    otel: OpenTelemetryConfig = field(default_factory=OpenTelemetryConfig)
    security: SecurityConfig = field(default_factory=SecurityConfig)
    calendar: CalendarConfig = field(default_factory=CalendarConfig)
    integrations: IntegrationConfig = field(default_factory=IntegrationConfig)
    productivity: ProductivityConfig = field(default_factory=ProductivityConfig)

    def get_kafka_topic(self, module: str) -> str:
        return f"{self.kafka.topic_prefix}.{module}"


# Global config instance
config = ZANOXV16Config()
