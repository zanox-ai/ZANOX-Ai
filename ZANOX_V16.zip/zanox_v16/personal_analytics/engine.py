"""Personal Analytics Engine - Aggregates and analyzes personal data."""
from datetime import datetime, date, timedelta
from typing import Dict, List, Optional, Any
import asyncpg

class PersonalAnalyticsEngine:
    def __init__(self):
        self.db_pool = None
    def initialize(self, db_pool, redis_client):
        self.db_pool = db_pool

    async def get_activity_summary(self, days: int = 30) -> Dict[str, Any]:
        if not self.db_pool:
            return {}
        start = datetime.utcnow() - timedelta(days=days)
        tasks_completed = await self.db_pool.fetchval("SELECT COUNT(*) FROM tasks WHERE status = 'completed' AND updated_at >= $1", start) or 0
        tasks_created = await self.db_pool.fetchval("SELECT COUNT(*) FROM tasks WHERE created_at >= $1", start) or 0
        focus_min = await self.db_pool.fetchval("SELECT COALESCE(SUM(actual_duration_minutes), 0) FROM focus_sessions WHERE started_at >= $1", start) or 0
        habits_logged = await self.db_pool.fetchval("SELECT COUNT(*) FROM habit_logs WHERE completed_at >= $1", start) or 0
        events = await self.db_pool.fetchval("SELECT COUNT(*) FROM calendar_events WHERE start_time >= $1", start) or 0
        notes_created = await self.db_pool.fetchval("SELECT COUNT(*) FROM notes WHERE created_at >= $1", start) or 0
        return {
            "period_days": days,
            "tasks_completed": tasks_completed,
            "tasks_created": tasks_created,
            "focus_hours": round(focus_min / 60, 1),
            "habits_logged": habits_logged,
            "events": events,
            "notes_created": notes_created,
            "completion_rate": round(tasks_completed / max(tasks_created, 1) * 100, 1)
        }

    async def get_weekly_patterns(self) -> List[Dict]:
        if not self.db_pool:
            return []
        rows = await self.db_pool.fetch(
            """SELECT EXTRACT(DOW FROM started_at) as day, EXTRACT(HOUR FROM started_at) as hour, COUNT(*) as sessions
               FROM focus_sessions WHERE started_at > NOW() - INTERVAL '30 days'
               GROUP BY EXTRACT(DOW FROM started_at), EXTRACT(HOUR FROM started_at)
               ORDER BY day, hour"""
        )
        days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
        return [{"day": days[int(r["day"])], "hour": int(r["hour"]), "sessions": r["sessions"]} for r in rows]

    async def get_life_balance_score(self) -> Dict[str, float]:
        categories = {
            "work": 0.0, "health": 0.0, "learning": 0.0,
            "relationships": 0.0, "personal": 0.0, "finance": 0.0
        }
        return {cat: round(score + 50, 1) for cat, score in categories.items()}
