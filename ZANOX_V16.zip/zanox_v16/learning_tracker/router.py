"""Learning Tracker Router - FastAPI endpoints."""
from typing import Optional
from uuid import UUID
from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from datetime import date
from ..models import APIResponse
from .service import LearningTrackerService

router = APIRouter()
_service: Optional[LearningTrackerService] = None

def set_service(service: LearningTrackerService):
    global _service
    _service = service

class LearningItemRequest(BaseModel):
    title: str
    skill_category: Optional[str] = None
    resource_type: str = "course"
    target_completion_date: Optional[date] = None

class LogSessionRequest(BaseModel):
    duration_minutes: int
    notes: Optional[str] = None

@router.post("", response_model=APIResponse)
async def create_learning_item(request: LearningItemRequest):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.create_learning_item(request.title, request.skill_category, request.resource_type, target_date=request.target_completion_date)
    return APIResponse(success=True, data=result.model_dump() if hasattr(result, "model_dump") else result)

@router.get("", response_model=APIResponse)
async def list_learning_items(status: Optional[str] = Query(None), skill: Optional[str] = Query(None)):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.list_learning_items(status, skill)
    return APIResponse(success=True, data=[i.model_dump() if hasattr(i, "model_dump") else i for i in result])

@router.get("/{item_id}", response_model=APIResponse)
async def get_learning_item(item_id: UUID):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.get_learning_item(item_id)
    if not result:
        raise HTTPException(status_code=404, detail="Item not found")
    return APIResponse(success=True, data=result.model_dump() if hasattr(result, "model_dump") else result)

@router.put("/{item_id}/progress", response_model=APIResponse)
async def update_progress(item_id: UUID, progress: float = Query(..., ge=0, le=100)):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    await _service.update_progress(item_id, progress)
    return APIResponse(success=True)

@router.post("/{item_id}/log", response_model=APIResponse)
async def log_session(item_id: UUID, request: LogSessionRequest):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.log_session(item_id, request.duration_minutes, request.notes)
    return APIResponse(success=True, data=result.model_dump() if hasattr(result, "model_dump") else result)

@router.get("/skills/summary", response_model=APIResponse)
async def get_skill_summary():
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.get_skill_summary()
    return APIResponse(success=True, data=result)
