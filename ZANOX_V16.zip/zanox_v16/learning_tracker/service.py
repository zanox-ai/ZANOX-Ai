"""Learning Tracker Service - Skill and learning management."""
from datetime import datetime, date
from typing import Dict, List, Optional, Any
from uuid import UUID, uuid4
import asyncpg
from ..models import LearningItem, LearningLog

class LearningTrackerService:
    def __init__(self):
        self.db_pool = None
    def initialize(self, db_pool, redis_client):
        self.db_pool = db_pool

    async def create_learning_item(self, title: str, skill_category: Optional[str] = None, resource_type: str = "course", status: str = "planned", target_date: Optional[date] = None) -> LearningItem:
        if not self.db_pool:
            raise RuntimeError("Database not initialized")
        lid = uuid4()
        await self.db_pool.execute(
            "INSERT INTO learning_items (id, title, skill_category, resource_type, status, target_completion_date, created_at) VALUES ($1, $2, $3, $4, $5, $6, NOW())",
            lid, title, skill_category, resource_type, status, target_date
        )
        return LearningItem(id=lid, title=title, skill_category=skill_category, resource_type=resource_type, status=status, target_completion_date=target_date)

    async def get_learning_item(self, item_id: UUID) -> Optional[LearningItem]:
        if not self.db_pool:
            return None
        row = await self.db_pool.fetchrow("SELECT * FROM learning_items WHERE id = $1", item_id)
        if not row:
            return None
        return LearningItem(
            id=row["id"], title=row["title"], skill_category=row["skill_category"],
            resource_type=row["resource_type"], status=row["status"],
            progress_percentage=row["progress_percentage"] or 0.0,
            start_date=row["start_date"], target_completion_date=row["target_completion_date"],
            completed_date=row["completed_date"], time_spent_minutes=row["time_spent_minutes"] or 0,
            notes=row["notes"], rating=row["rating"]
        )

    async def list_learning_items(self, status: Optional[str] = None, skill: Optional[str] = None) -> List[LearningItem]:
        if not self.db_pool:
            return []
        q = "SELECT * FROM learning_items"
        params = []
        if status:
            q += " WHERE status = $1"; params.append(status)
        if skill:
            q += " AND skill_category = $2" if params else " WHERE skill_category = $1"; params.append(skill)
        q += " ORDER BY created_at DESC"
        rows = await self.db_pool.fetch(q, *params)
        return [await self.get_learning_item(r["id"]) for r in rows]

    async def update_progress(self, item_id: UUID, progress: float):
        if not self.db_pool:
            return
        await self.db_pool.execute(
            "UPDATE learning_items SET progress_percentage = $1, updated_at = NOW() WHERE id = $2",
            min(progress, 100), item_id
        )

    async def log_session(self, item_id: UUID, duration_minutes: int, notes: Optional[str] = None) -> LearningLog:
        if not self.db_pool:
            raise RuntimeError("Database not initialized")
        lid = uuid4()
        now = datetime.utcnow()
        await self.db_pool.execute(
            "INSERT INTO learning_logs (id, learning_item_id, session_date, duration_minutes, notes, created_at) VALUES ($1, $2, $3, $4, $5, NOW())",
            lid, item_id, now.date(), duration_minutes, notes
        )
        await self.db_pool.execute(
            "UPDATE learning_items SET time_spent_minutes = time_spent_minutes + $1, updated_at = NOW() WHERE id = $2",
            duration_minutes, item_id
        )
        return LearningLog(id=lid, learning_item_id=item_id, session_date=now.date(), duration_minutes=duration_minutes, notes=notes)

    async def get_skill_summary(self) -> List[Dict]:
        if not self.db_pool:
            return []
        rows = await self.db_pool.fetch(
            """SELECT skill_category, COUNT(*) as items, SUM(time_spent_minutes) as total_minutes,
                AVG(progress_percentage) as avg_progress
               FROM learning_items
               WHERE skill_category IS NOT NULL
               GROUP BY skill_category"""
        )
        return [dict(r) for r in rows]
