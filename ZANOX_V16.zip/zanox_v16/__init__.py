"""
ZANOX V16 - Personal Assistant & Productivity Layer
=====================================================

A world-class personal operating system capable of managing tasks, projects,
goals, habits, schedules, notes, documents, knowledge, life planning,
productivity and personal execution.

Modules:
    - assistant_engine: Personal AI assistant core
    - productivity_engine: Productivity optimization system
    - task_management: Task creation, scheduling, prioritization, dependencies
    - project_management: Project planning, milestones, roadmaps
    - goal_management: Goal tracking and analytics
    - habit_management: Habit tracking and analytics
    - calendar_engine: Calendar and scheduling engine
    - focus_engine: Deep work and focus management
    - decision_support: Decision matrix and support tools
    - knowledge_management: Knowledge base, wiki, note-taking
    - document_management: File organization, bookmarks, reading lists
    - learning_tracker: Learning management and tracking
    - life_dashboard: Personal life dashboard
    - personal_analytics: Personal analytics engine
    - productivity_analytics: Productivity metrics and insights
    - life_os: Life operating system engine
    - memory: Personal memory layer
    - search: Personal search engine
    - recommendations: Personal recommendation engine
    - monitoring: Personal monitoring layer
    - security: Personal security layer
    - governance: Personal governance layer
    - compliance: Personal compliance layer
    - integrations: External service integrations
    - deployment: Deployment configurations
    - docs: Documentation

Version: 16.0.0
"""

__version__ = "16.0.0"
__author__ = "ZANOX Systems"

from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import redis.asyncio as redis
from kafka import KafkaProducer, KafkaConsumer
import asyncpg
import openTelemetry.sdk.resources as otel_resources
from openTelemetry.sdk.trace import TracerProvider
from openTelemetry.sdk.trace.export import BatchSpanProcessor
from openTelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter

from .assistant_engine import engine as assistant_engine
from .productivity_engine import engine as productivity_engine
from .task_management import router as task_router
from .project_management import router as project_router
from .goal_management import router as goal_router
from .habit_management import router as habit_router
from .calendar_engine import router as calendar_router
from .focus_engine import router as focus_router
from .decision_support import router as decision_router
from .knowledge_management import router as knowledge_router
from .document_management import router as document_router
from .learning_tracker import router as learning_router
from .life_dashboard import router as dashboard_router
from .life_os import engine as life_os_engine
from .memory import engine as memory_engine
from .search import engine as search_engine
from .recommendations import engine as recommendations_engine
from .monitoring import service as monitoring_service
from .security import engine as security_engine
from .governance import engine as governance_engine
from .compliance import engine as compliance_engine


class ZANOXV16App:
    """Main ZANOX V16 Application Container."""

    def __init__(self):
        self.app = FastAPI(
            title="ZANOX V16 - Personal Assistant & Productivity Layer",
            description="Personal operating system for task, project, goal, habit, schedule, and knowledge management",
            version="16.0.0"
        )
        self.redis_client = None
        self.db_pool = None
        self.kafka_producer = None
        self.tracer = None
        self._setup_telemetry()
        self._setup_middleware()
        self._setup_routes()

    def _setup_telemetry(self):
        """Initialize OpenTelemetry tracing."""
        resource = otel_resources.Resource.create(
            {"service.name": "zanox-v16-personal-assistant"}
        )
        provider = TracerProvider(resource=resource)
        otlp_exporter = OTLPSpanExporter(endpoint="http://otel-collector:4317", insecure=True)
        processor = BatchSpanProcessor(otlp_exporter)
        provider.add_span_processor(processor)
        self.tracer = provider.get_tracer(__name__)

    def _setup_middleware(self):
        """Configure FastAPI middleware."""
        self.app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

    def _setup_routes(self):
        """Register all module routers."""
        self.app.include_router(task_router, prefix="/api/v16/tasks", tags=["Tasks"])
        self.app.include_router(project_router, prefix="/api/v16/projects", tags=["Projects"])
        self.app.include_router(goal_router, prefix="/api/v16/goals", tags=["Goals"])
        self.app.include_router(habit_router, prefix="/api/v16/habits", tags=["Habits"])
        self.app.include_router(calendar_router, prefix="/api/v16/calendar", tags=["Calendar"])
        self.app.include_router(focus_router, prefix="/api/v16/focus", tags=["Focus"])
        self.app.include_router(decision_router, prefix="/api/v16/decisions", tags=["Decisions"])
        self.app.include_router(knowledge_router, prefix="/api/v16/knowledge", tags=["Knowledge"])
        self.app.include_router(document_router, prefix="/api/v16/documents", tags=["Documents"])
        self.app.include_router(learning_router, prefix="/api/v16/learning", tags=["Learning"])
        self.app.include_router(dashboard_router, prefix="/api/v16/dashboard", tags=["Dashboard"])

    async def startup(self):
        """Initialize all connections and engines."""
        self.redis_client = redis.Redis(host="redis", port=6379, decode_responses=True)
        self.db_pool = await asyncpg.create_pool(
            "postgresql://zanox:zanox@postgres:5432/zanox_v16"
        )
        self.kafka_producer = KafkaProducer(
            bootstrap_servers=["kafka:9092"],
            value_serializer=lambda v: str(v).encode("utf-8")
        )
        await assistant_engine.initialize(self.db_pool, self.redis_client)
        await productivity_engine.initialize(self.db_pool, self.redis_client)
        await life_os_engine.initialize(self.db_pool, self.redis_client)
        await memory_engine.initialize(self.db_pool, self.redis_client)
        await search_engine.initialize(self.db_pool, self.redis_client)
        await recommendations_engine.initialize(self.db_pool, self.redis_client)
        await monitoring_service.initialize(self.db_pool, self.redis_client)
        await security_engine.initialize(self.db_pool, self.redis_client)
        await governance_engine.initialize(self.db_pool, self.redis_client)
        await compliance_engine.initialize(self.db_pool, self.redis_client)

    async def shutdown(self):
        """Graceful shutdown."""
        if self.redis_client:
            await self.redis_client.close()
        if self.db_pool:
            await self.db_pool.close()
        if self.kafka_producer:
            self.kafka_producer.close()

    @asynccontextmanager
    async def lifespan(self, app):
        await self.startup()
        yield
        await self.shutdown()


def create_app() -> FastAPI:
    """Factory function to create the ZANOX V16 application."""
    zanox = ZANOXV16App()
    zanox.app.router.lifespan_context = zanox.lifespan
    return zanox.app
