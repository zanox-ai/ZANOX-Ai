"""Decision Support Service - Decision analysis and matrix evaluation."""
from datetime import datetime
from typing import Dict, List, Optional, Any
from uuid import UUID, uuid4
import asyncpg
from ..models import DecisionMatrix, DecisionOption, DecisionType

class DecisionSupportService:
    def __init__(self):
        self.db_pool = None
    def initialize(self, db_pool, redis_client):
        self.db_pool = db_pool

    async def create_decision(self, title: str, description: Optional[str] = None, decision_type: str = "weighted", criteria: Optional[List[str]] = None, criteria_weights: Optional[Dict[str, float]] = None) -> DecisionMatrix:
        if not self.db_pool:
            raise RuntimeError("Database not initialized")
        did = uuid4()
        await self.db_pool.execute(
            "INSERT INTO decision_matrices (id, title, description, decision_type, criteria, criteria_weights, created_at) VALUES ($1, $2, $3, $4, $5, $6, NOW())",
            did, title, description, decision_type, criteria or [], criteria_weights or {}
        )
        return DecisionMatrix(id=did, title=title, description=description, decision_type=DecisionType(decision_type), criteria=criteria or [], criteria_weights=criteria_weights or {})

    async def add_option(self, decision_id: UUID, title: str, description: Optional[str] = None, pros: Optional[List[str]] = None, cons: Optional[List[str]] = None) -> DecisionOption:
        if not self.db_pool:
            raise RuntimeError("Database not initialized")
        oid = uuid4()
        await self.db_pool.execute(
            "INSERT INTO decision_options (id, decision_id, title, description, pros, cons) VALUES ($1, $2, $3, $4, $5, $6)",
            oid, decision_id, title, description, pros or [], cons or []
        )
        return DecisionOption(id=oid, title=title, description=description, pros=pros or [], cons=cons or [])

    async def score_option(self, decision_id: UUID, option_id: UUID, criteria_scores: Dict[str, float]):
        if not self.db_pool:
            return
        await self.db_pool.execute(
            "UPDATE decision_options SET scores = $1 WHERE id = $2 AND decision_id = $3",
            criteria_scores, option_id, decision_id
        )

    async def evaluate_decision(self, decision_id: UUID) -> Dict[str, Any]:
        if not self.db_pool:
            return {}
        dm = await self.db_pool.fetchrow("SELECT * FROM decision_matrices WHERE id = $1", decision_id)
        if not dm:
            return {}
        options = await self.db_pool.fetch("SELECT * FROM decision_options WHERE decision_id = $1", decision_id)
        weights = dm["criteria_weights"] or {}
        results = []
        for opt in options:
            scores = opt["scores"] or {}
            total = sum(scores.get(c, 0) * weights.get(c, 1.0) for c in (dm["criteria"] or []))
            results.append({
                "option_id": str(opt["id"]),
                "title": opt["title"],
                "total_score": round(total, 2),
                "scores": scores
            })
        results.sort(key=lambda r: r["total_score"], reverse=True)
        best = results[0] if results else None
        return {
            "decision_id": str(decision_id),
            "title": dm["title"],
            "criteria": dm["criteria"],
            "weights": weights,
            "results": results,
            "recommendation": best["title"] if best else None,
            "confidence": round(best["total_score"] / max(sum(weights.values()) * 10, 1), 2) if best else 0
        }

    async def get_decision(self, decision_id: UUID) -> Optional[DecisionMatrix]:
        if not self.db_pool:
            return None
        row = await self.db_pool.fetchrow("SELECT * FROM decision_matrices WHERE id = $1", decision_id)
        if not row:
            return None
        return DecisionMatrix(
            id=row["id"], title=row["title"], description=row["description"],
            decision_type=DecisionType(row["decision_type"]), criteria=row["criteria"] or [],
            criteria_weights=row["criteria_weights"] or {}, final_decision=row["final_decision"],
            confidence_score=row["confidence_score"], created_at=row["created_at"],
            resolved_at=row["resolved_at"]
        )

    async def list_decisions(self, resolved: Optional[bool] = None) -> List[DecisionMatrix]:
        if not self.db_pool:
            return []
        q = "SELECT * FROM decision_matrices"
        if resolved is not None:
            q += " WHERE final_decision IS " + ("NOT NULL" if resolved else "NULL")
        q += " ORDER BY created_at DESC"
        rows = await self.db_pool.fetch(q)
        return [await self.get_decision(r["id"]) for r in rows]

    async def resolve_decision(self, decision_id: UUID, final_choice: str):
        if not self.db_pool:
            return
        await self.db_pool.execute(
            "UPDATE decision_matrices SET final_decision = $1, resolved_at = NOW() WHERE id = $2",
            final_choice, decision_id
        )
