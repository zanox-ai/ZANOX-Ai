"""Decision Matrix Engine - MCDA implementation."""
from typing import Dict, List

class DecisionMatrixEngine:
    METHODS = ["weighted_sum", "ahp", "topsis"]

    def weighted_sum(self, alternatives: List[Dict], weights: Dict[str, float]) -> List[Dict]:
        results = []
        for alt in alternatives:
            score = sum(alt.get(criterion, 0) * weight for criterion, weight in weights.items())
            results.append({**alt, "weighted_score": round(score, 2)})
        return sorted(results, key=lambda r: r["weighted_score"], reverse=True)
