"""Decision Support Router - FastAPI endpoints."""
from typing import Optional, List, Dict
from uuid import UUID
from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from ..models import APIResponse
from .service import DecisionSupportService

router = APIRouter()
_service: Optional[DecisionSupportService] = None

def set_service(service: DecisionSupportService):
    global _service
    _service = service

class CreateDecisionRequest(BaseModel):
    title: str
    description: Optional[str] = None
    decision_type: str = "weighted"
    criteria: Optional[List[str]] = None
    criteria_weights: Optional[Dict[str, float]] = None

class AddOptionRequest(BaseModel):
    title: str
    description: Optional[str] = None
    pros: Optional[List[str]] = None
    cons: Optional[List[str]] = None

class ScoreOptionRequest(BaseModel):
    scores: Dict[str, float]

@router.post("", response_model=APIResponse)
async def create_decision(request: CreateDecisionRequest):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.create_decision(request.title, request.description, request.decision_type, request.criteria, request.criteria_weights)
    return APIResponse(success=True, data=result.model_dump() if hasattr(result, "model_dump") else result)

@router.get("", response_model=APIResponse)
async def list_decisions(resolved: Optional[bool] = Query(None)):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.list_decisions(resolved)
    return APIResponse(success=True, data=[d.model_dump() if hasattr(d, "model_dump") else d for d in result])

@router.get("/{decision_id}", response_model=APIResponse)
async def get_decision(decision_id: UUID):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.get_decision(decision_id)
    if not result:
        raise HTTPException(status_code=404, detail="Decision not found")
    return APIResponse(success=True, data=result.model_dump() if hasattr(result, "model_dump") else result)

@router.post("/{decision_id}/options", response_model=APIResponse)
async def add_option(decision_id: UUID, request: AddOptionRequest):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.add_option(decision_id, request.title, request.description, request.pros, request.cons)
    return APIResponse(success=True, data=result.model_dump() if hasattr(result, "model_dump") else result)

@router.post("/{decision_id}/options/{option_id}/score", response_model=APIResponse)
async def score_option(decision_id: UUID, option_id: UUID, request: ScoreOptionRequest):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    await _service.score_option(decision_id, option_id, request.scores)
    return APIResponse(success=True)

@router.post("/{decision_id}/evaluate", response_model=APIResponse)
async def evaluate_decision(decision_id: UUID):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.evaluate_decision(decision_id)
    return APIResponse(success=True, data=result)

@router.post("/{decision_id}/resolve", response_model=APIResponse)
async def resolve_decision(decision_id: UUID, choice: str = Query(...)):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    await _service.resolve_decision(decision_id, choice)
    return APIResponse(success=True, message="Decision resolved")
