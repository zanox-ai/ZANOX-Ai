"""Project Planner - Auto-generates plans from templates."""
from datetime import datetime, date, timedelta
from typing import Dict, List, Optional
from uuid import UUID
from ...models import APIResponse

class ProjectPlanner:
    """Generates project plans with milestones, tasks, and timelines."""

    TEMPLATES = {
        "software": {
            "milestones": ["Requirements", "Design", "Development", "Testing", "Deployment"],
            "default_duration_weeks": 12
        },
        "marketing": {
            "milestones": ["Research", "Strategy", "Content Creation", "Execution", "Analysis"],
            "default_duration_weeks": 8
        },
        "research": {
            "milestones": ["Literature Review", "Methodology", "Data Collection", "Analysis", "Publication"],
            "default_duration_weeks": 24
        }
    }

    async def generate_plan(self, name: str, template: str, start_date: Optional[date] = None) -> Dict:
        start = start_date or date.today()
        tmpl = self.TEMPLATES.get(template, self.TEMPLATES["software"])
        duration_weeks = tmpl["default_duration_weeks"]
        week_per_phase = duration_weeks // len(tmpl["milestones"])

        milestones = []
        for i, ms_name in enumerate(tmpl["milestones"]):
            ms_date = start + timedelta(weeks=i * week_per_phase)
            milestones.append({
                "name": ms_name,
                "due_date": ms_date.isoformat(),
                "description": f"Complete {ms_name} phase"
            })

        return {
            "name": name,
            "template": template,
            "start_date": start.isoformat(),
            "target_end_date": (start + timedelta(weeks=duration_weeks)).isoformat(),
            "milestones": milestones,
            "estimated_tasks": len(tmpl["milestones"]) * 5
        }
