"""Milestone Tracker - Tracks milestone progress and alerts."""
from datetime import datetime, date, timedelta
from typing import Dict, List, Optional
from uuid import UUID
import asyncpg

class MilestoneTracker:
    def __init__(self):
        self.db_pool = None
    def initialize(self, db_pool):
        self.db_pool = db_pool

    async def get_upcoming_milestones(self, days: int = 7) -> List[Dict]:
        if not self.db_pool:
            return []
        rows = await self.db_pool.fetch(
            "SELECT * FROM milestones WHERE status = 'pending' AND due_date <= CURRENT_DATE + $1 ORDER BY due_date",
            timedelta(days=days)
        )
        return [dict(r) for r in rows]

    async def check_overdue_milestones(self) -> List[Dict]:
        if not self.db_pool:
            return []
        rows = await self.db_pool.fetch(
            "SELECT * FROM milestones WHERE status = 'pending' AND due_date < CURRENT_DATE"
        )
        return [dict(r) for r in rows]
