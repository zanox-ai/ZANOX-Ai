"""ZANOX V16 - Project Management System"""
from .router import router
from .service import ProjectService
__all__ = ["router", "ProjectService"]
