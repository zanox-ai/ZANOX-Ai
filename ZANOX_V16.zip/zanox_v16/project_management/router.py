"""Project Management Router - FastAPI endpoints."""
from typing import Optional
from uuid import UUID
from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from datetime import date
from ..models import APIResponse
from .service import ProjectService

router = APIRouter()
_service: Optional[ProjectService] = None

def set_service(service: ProjectService):
    global _service
    _service = service

class ProjectCreateRequest(BaseModel):
    name: str
    description: Optional[str] = None
    priority: str = "medium"
    start_date: Optional[date] = None
    target_end_date: Optional[date] = None

class MilestoneCreate(BaseModel):
    name: str
    description: Optional[str] = None
    due_date: Optional[date] = None
    deliverables: Optional[list] = None

class RoadmapCreate(BaseModel):
    title: str
    description: Optional[str] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None

@router.post("", response_model=APIResponse)
async def create_project(request: ProjectCreateRequest):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    from ..models import ProjectCreate, PriorityLevel, ProjectStatus
    project_data = ProjectCreate(
        name=request.name, description=request.description,
        priority=PriorityLevel(request.priority), status=ProjectStatus.PLANNING,
        start_date=request.start_date, target_end_date=request.target_end_date
    )
    result = await _service.create_project(project_data)
    return APIResponse(success=True, data=result.model_dump() if hasattr(result, "model_dump") else result)

@router.get("", response_model=APIResponse)
async def list_projects(status: Optional[str] = Query(None), page: int = 1, page_size: int = 20):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.list_projects(status=status, page=page, page_size=page_size)
    return APIResponse(success=True, data={"items": [p.model_dump() if hasattr(p, "model_dump") else p for p in result.items], "total": result.total, "page": result.page, "page_size": result.page_size})

@router.get("/{project_id}", response_model=APIResponse)
async def get_project(project_id: UUID):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.get_project(project_id)
    if not result:
        raise HTTPException(status_code=404, detail="Project not found")
    return APIResponse(success=True, data=result.model_dump() if hasattr(result, "model_dump") else result)

@router.put("/{project_id}", response_model=APIResponse)
async def update_project(project_id: UUID, updates: dict):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.update_project(project_id, updates)
    return APIResponse(success=True, data=result.model_dump() if hasattr(result, "model_dump") else result)

@router.delete("/{project_id}", response_model=APIResponse)
async def delete_project(project_id: UUID):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    success = await _service.delete_project(project_id)
    return APIResponse(success=success)

@router.post("/{project_id}/milestones", response_model=APIResponse)
async def add_milestone(project_id: UUID, request: MilestoneCreate):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.add_milestone(project_id, request.name, request.description, request.due_date, request.deliverables)
    return APIResponse(success=True, data=result.model_dump() if hasattr(result, "model_dump") else result)

@router.get("/{project_id}/milestones", response_model=APIResponse)
async def get_milestones(project_id: UUID):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.get_milestones(project_id)
    return APIResponse(success=True, data=[m.model_dump() if hasattr(m, "model_dump") else m for m in result])

@router.post("/{project_id}/roadmap", response_model=APIResponse)
async def add_roadmap_item(project_id: UUID, request: RoadmapCreate):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.add_roadmap_item(project_id, request.title, request.description, request.start_date, request.end_date)
    return APIResponse(success=True, data=result.model_dump() if hasattr(result, "model_dump") else result)

@router.get("/{project_id}/roadmap", response_model=APIResponse)
async def get_roadmap(project_id: UUID):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.get_roadmap(project_id)
    return APIResponse(success=True, data=[r.model_dump() if hasattr(r, "model_dump") else r for r in result])
