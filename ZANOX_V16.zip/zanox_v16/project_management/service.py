"""Project Management Service - Full CRUD for projects with milestones and roadmaps."""
import json
from datetime import datetime, date
from typing import Dict, List, Optional, Any
from uuid import UUID, uuid4
import asyncpg
import redis.asyncio as redis
from ..models import Project, ProjectCreate, ProjectStatus, Milestone, RoadmapItem, APIResponse, PaginatedResponse

class ProjectService:
    def __init__(self):
        self.db_pool = None
        self.redis = None
    def initialize(self, db_pool, redis_client):
        self.db_pool = db_pool
        self.redis = redis_client

    async def create_project(self, project: ProjectCreate) -> Project:
        if not self.db_pool:
            raise RuntimeError("Database not initialized")
        pid = uuid4()
        await self.db_pool.execute(
            """INSERT INTO projects (id, name, description, status, priority, start_date, target_end_date, owner_id, tags, color, created_at, updated_at)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, NOW(), NOW())""",
            pid, project.name, project.description, project.status.value, project.priority.value,
            project.start_date, project.target_end_date,
            str(project.owner_id) if project.owner_id else None,
            json.dumps(project.tags), project.color
        )
        return await self.get_project(pid)

    async def get_project(self, project_id: UUID) -> Optional[Project]:
        if not self.db_pool:
            return None
        row = await self.db_pool.fetchrow("SELECT * FROM projects WHERE id = $1", project_id)
        if not row:
            return None
        tags = json.loads(row["tags"]) if row["tags"] else []
        return Project(
            id=row["id"], name=row["name"], description=row["description"],
            status=ProjectStatus(row["status"]), priority=row["priority"],
            start_date=row["start_date"], target_end_date=row["target_end_date"],
            actual_end_date=row["actual_end_date"], owner_id=UUID(row["owner_id"]) if row["owner_id"] else None,
            tags=tags, color=row["color"], created_at=row["created_at"], updated_at=row["updated_at"],
            progress_percentage=row["progress_percentage"] or 0.0
        )

    async def list_projects(self, status=None, page=1, page_size=20) -> PaginatedResponse:
        if not self.db_pool:
            return PaginatedResponse(items=[], total=0, page=page, page_size=page_size, total_pages=0)
        where = "WHERE status = $1" if status else ""
        params = [status] if status else []
        total = await self.db_pool.fetchval(f"SELECT COUNT(*) FROM projects {where}", *params)
        offset = (page - 1) * page_size
        rows = await self.db_pool.fetch(
            f"SELECT * FROM projects {where} ORDER BY created_at DESC LIMIT ${len(params)+1} OFFSET ${len(params)+2}",
            *params, page_size, offset
        )
        projects = [await self.get_project(r["id"]) for r in rows]
        total_pages = (total + page_size - 1) // page_size
        return PaginatedResponse(items=projects, total=total, page=page, page_size=page_size, total_pages=total_pages)

    async def update_project(self, project_id: UUID, updates: Dict) -> Optional[Project]:
        if not self.db_pool:
            return None
        set_clauses = []
        params = [project_id]
        for key, value in updates.items():
            if key in ("name", "description", "status", "priority", "color"):
                set_clauses.append(f"{key} = ${len(params)+1}")
                params.append(value)
        if set_clauses:
            set_clauses.append("updated_at = NOW()")
            await self.db_pool.execute(f"UPDATE projects SET {', '.join(set_clauses)} WHERE id = $1", *params)
        return await self.get_project(project_id)

    async def delete_project(self, project_id: UUID) -> bool:
        if not self.db_pool:
            return False
        await self.db_pool.execute("UPDATE projects SET status = 'cancelled', updated_at = NOW() WHERE id = $1", project_id)
        return True

    async def add_milestone(self, project_id: UUID, name: str, description=None, due_date=None, deliverables=None) -> Milestone:
        if not self.db_pool:
            raise RuntimeError("Database not initialized")
        mid = uuid4()
        await self.db_pool.execute(
            """INSERT INTO milestones (id, project_id, name, description, due_date, deliverables, created_at)
             VALUES ($1, $2, $3, $4, $5, $6, NOW())""",
            mid, project_id, name, description, due_date, json.dumps(deliverables or [])
        )
        return Milestone(id=mid, project_id=project_id, name=name, description=description, due_date=due_date, deliverables=deliverables or [])

    async def get_milestones(self, project_id: UUID) -> List[Milestone]:
        if not self.db_pool:
            return []
        rows = await self.db_pool.fetch("SELECT * FROM milestones WHERE project_id = $1 ORDER BY due_date", project_id)
        return [Milestone(id=r["id"], project_id=r["project_id"], name=r["name"], description=r["description"], due_date=r["due_date"], status=r["status"], deliverables=json.loads(r["deliverables"]) if r["deliverables"] else [], created_at=r["created_at"]) for r in rows]

    async def complete_milestone(self, milestone_id: UUID):
        if not self.db_pool:
            return
        await self.db_pool.execute("UPDATE milestones SET status = 'completed', completed_date = CURRENT_DATE, updated_at = NOW() WHERE id = $1", milestone_id)

    async def add_roadmap_item(self, project_id: UUID, title: str, description=None, start_date=None, end_date=None, quarter=None, year=None) -> RoadmapItem:
        if not self.db_pool:
            raise RuntimeError("Database not initialized")
        rid = uuid4()
        await self.db_pool.execute(
            """INSERT INTO roadmap_items (id, project_id, title, description, start_date, end_date, quarter, year, created_at)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, NOW())""",
            rid, project_id, title, description, start_date, end_date, quarter, year
        )
        return RoadmapItem(id=rid, project_id=project_id, title=title, description=description, start_date=start_date, end_date=end_date, quarter=quarter, year=year)

    async def get_roadmap(self, project_id: UUID) -> List[RoadmapItem]:
        if not self.db_pool:
            return []
        rows = await self.db_pool.fetch("SELECT * FROM roadmap_items WHERE project_id = $1 ORDER BY start_date", project_id)
        return [RoadmapItem(id=r["id"], project_id=r["project_id"], title=r["title"], description=r["description"], start_date=r["start_date"], end_date=r["end_date"], quarter=r["quarter"], year=r["year"], status=r["status"], created_at=r["created_at"]) for r in rows]

    async def update_progress(self, project_id: UUID):
        if not self.db_pool:
            return
        await self.db_pool.execute(
            """UPDATE projects SET progress_percentage = (
                SELECT COALESCE(AVG(CASE WHEN status = 'completed' THEN 100 ELSE 0 END), 0)
                FROM tasks WHERE project_id = $1
            ), updated_at = NOW() WHERE id = $1""", project_id
        )
