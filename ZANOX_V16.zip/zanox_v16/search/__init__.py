"""ZANOX V16 - Personal Search Engine."""
from .engine import SearchEngine
