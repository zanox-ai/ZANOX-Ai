"""Search Engine - Unified search across all personal data."""
from datetime import datetime
from typing import Dict, List, Optional, Any
import asyncpg

class SearchEngine:
    def __init__(self):
        self.db_pool = None
        self.redis = None
    def initialize(self, db_pool, redis_client):
        self.db_pool = db_pool
        self.redis = redis_client

    async def search(self, query: str, entity_types: Optional[List[str]] = None, limit: int = 20) -> Dict[str, List]:
        """Search across all entity types."""
        if not self.db_pool:
            return {}

        results = {}
        types = entity_types or ["tasks", "projects", "goals", "notes", "events", "knowledge"]

        for etype in types:
            if etype == "tasks":
                rows = await self.db_pool.fetch(
                    "SELECT id, title, status, priority FROM tasks WHERE title ILIKE $1 OR description ILIKE $1 LIMIT $2",
                    f"%{query}%", limit
                )
                results["tasks"] = [dict(r) for r in rows]
            elif etype == "projects":
                rows = await self.db_pool.fetch(
                    "SELECT id, name, status FROM projects WHERE name ILIKE $1 OR description ILIKE $1 LIMIT $2",
                    f"%{query}%", limit
                )
                results["projects"] = [dict(r) for r in rows]
            elif etype == "goals":
                rows = await self.db_pool.fetch(
                    "SELECT id, title, status, progress_percentage FROM goals WHERE title ILIKE $1 LIMIT $2",
                    f"%{query}%", limit
                )
                results["goals"] = [dict(r) for r in rows]
            elif etype == "notes":
                rows = await self.db_pool.fetch(
                    "SELECT id, title, content FROM notes WHERE title ILIKE $1 OR content ILIKE $1 LIMIT $2",
                    f"%{query}%", limit
                )
                results["notes"] = [dict(r) for r in rows]
            elif etype == "knowledge":
                rows = await self.db_pool.fetch(
                    "SELECT id, title, category FROM knowledge_entries WHERE title ILIKE $1 OR content ILIKE $1 LIMIT $2",
                    f"%{query}%", limit
                )
                results["knowledge"] = [dict(r) for r in rows]

        return results

    async def global_search(self, query: str, limit: int = 50) -> List[Dict]:
        """Perform a global search with relevance scoring."""
        all_results = await self.search(query, limit=limit)
        flat = []
        for entity_type, items in all_results.items():
            for item in items:
                flat.append({"type": entity_type, **item, "relevance": 1.0})
        return sorted(flat, key=lambda x: x["relevance"], reverse=True)[:limit]
