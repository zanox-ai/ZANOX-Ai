"""Recommendation Engine - Personalized recommendations."""
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
import asyncpg

class RecommendationEngine:
    def __init__(self):
        self.db_pool = None
        self.redis = None
    def initialize(self, db_pool, redis_client):
        self.db_pool = db_pool
        self.redis = redis_client

    async def get_recommendations(self, context: Optional[str] = None) -> List[Dict[str, str]]:
        """Get personalized recommendations."""
        recommendations = []

        if self.db_pool:
            # Suggest tasks based on overdue items
            overdue = await self.db_pool.fetch(
                "SELECT title FROM tasks WHERE due_date < NOW() AND status NOT IN ('completed', 'cancelled') LIMIT 3"
            )
            for t in overdue:
                recommendations.append({
                    "type": "task",
                    "priority": "high",
                    "title": f"Overdue: {t['title']}",
                    "action": "complete_task"
                })

            # Suggest habits
            habits = await self.db_pool.fetch(
                "SELECT name FROM habits WHERE active = true ORDER BY total_completions LIMIT 3"
            )
            for h in habits:
                recommendations.append({
                    "type": "habit",
                    "priority": "medium",
                    "title": f"Track habit: {h['name']}",
                    "action": "log_habit"
                })

        if context == "morning":
            recommendations.append({"type": "focus", "priority": "high", "title": "Start a focus session", "action": "start_focus"})
        elif context == "evening":
            recommendations.append({"type": "review", "priority": "medium", "title": "Review today's progress", "action": "daily_review"})

        return recommendations

    async def suggest_tasks(self, available_minutes: int = 30) -> List[Dict]:
        """Suggest tasks that fit available time."""
        if not self.db_pool:
            return []
        rows = await self.db_pool.fetch(
            "SELECT id, title, priority FROM tasks WHERE status NOT IN ('completed', 'cancelled') AND (estimated_duration_minutes IS NULL OR estimated_duration_minutes <= $1) ORDER BY priority LIMIT 5",
            available_minutes
        )
        return [{"id": str(r["id"]), "title": r["title"], "priority": r["priority"]} for r in rows]

    async def suggest_learning(self) -> List[Dict]:
        """Suggest learning resources."""
        return []
