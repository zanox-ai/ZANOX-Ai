"""Personal Wiki - Wiki-style personal knowledge."""
from .engine import PersonalWikiEngine
