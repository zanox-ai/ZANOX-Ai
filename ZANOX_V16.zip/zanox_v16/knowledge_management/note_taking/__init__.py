"""Note Taking - Advanced note-taking engine."""
from .engine import NoteTakingEngine
