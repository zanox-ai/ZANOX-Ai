"""Knowledge Management Service - Knowledge base, wiki, and note-taking."""
from datetime import datetime
from typing import Dict, List, Optional, Any
from uuid import UUID, uuid4
import asyncpg
from ..models import KnowledgeEntry, Note, Bookmark, ReadingListItem, NoteType

class KnowledgeService:
    def __init__(self):
        self.db_pool = None
    def initialize(self, db_pool, redis_client):
        self.db_pool = db_pool

    async def create_knowledge_entry(self, title: str, content: str, category: Optional[str] = None, tags: Optional[List[str]] = None, source: Optional[str] = None, related: Optional[List[UUID]] = None) -> KnowledgeEntry:
        if not self.db_pool:
            raise RuntimeError("Database not initialized")
        kid = uuid4()
        await self.db_pool.execute(
            "INSERT INTO knowledge_entries (id, title, content, category, tags, source, related_entries, created_at, updated_at) VALUES ($1, $2, $3, $4, $5, $6, $7, NOW(), NOW())",
            kid, title, content, category, tags or [], source, [str(r) for r in (related or [])]
        )
        return KnowledgeEntry(id=kid, title=title, content=content, category=category, tags=tags or [], source=source, related_entries=related or [])

    async def get_knowledge_entry(self, entry_id: UUID) -> Optional[KnowledgeEntry]:
        if not self.db_pool:
            return None
        row = await self.db_pool.fetchrow("SELECT * FROM knowledge_entries WHERE id = $1", entry_id)
        if not row:
            return None
        return KnowledgeEntry(id=row["id"], title=row["title"], content=row["content"], category=row["category"], tags=row["tags"] or [], source=row["source"], related_entries=[UUID(r) for r in row["related_entries"]] if row["related_entries"] else [], created_at=row["created_at"], updated_at=row["updated_at"], version=row["version"] or 1)

    async def search_knowledge(self, query: str, limit: int = 20) -> List[KnowledgeEntry]:
        if not self.db_pool:
            return []
        rows = await self.db_pool.fetch(
            "SELECT * FROM knowledge_entries WHERE title ILIKE $1 OR content ILIKE $1 ORDER BY updated_at DESC LIMIT $2",
            f"%{query}%", limit
        )
        return [await self.get_knowledge_entry(r["id"]) for r in rows]

    async def create_note(self, title: Optional[str], content: str, note_type: str = "quick", tags: Optional[List[str]] = None, folder: Optional[str] = None) -> Note:
        if not self.db_pool:
            raise RuntimeError("Database not initialized")
        nid = uuid4()
        await self.db_pool.execute(
            "INSERT INTO notes (id, title, content, note_type, tags, folder, created_at, updated_at) VALUES ($1, $2, $3, $4, $5, $6, NOW(), NOW())",
            nid, title, content, note_type, tags or [], folder
        )
        return Note(id=nid, title=title, content=content, note_type=NoteType(note_type), tags=tags or [], folder=folder)

    async def get_notes(self, note_type: Optional[str] = None, folder: Optional[str] = None, search: Optional[str] = None) -> List[Note]:
        if not self.db_pool:
            return []
        q = "SELECT * FROM notes WHERE 1=1"
        params = []
        if note_type:
            q += " AND note_type = $%d" % (len(params) + 1)
            params.append(note_type)
        if folder:
            q += " AND folder = $%d" % (len(params) + 1)
            params.append(folder)
        if search:
            q += " AND (title ILIKE $%d OR content ILIKE $%d)" % (len(params) + 1, len(params) + 1)
            params.append(f"%{search}%")
        q += " ORDER BY created_at DESC"
        rows = await self.db_pool.fetch(q, *params)
        return [Note(id=r["id"], title=r["title"], content=r["content"], note_type=NoteType(r["note_type"]), tags=r["tags"] or [], folder=r["folder"], created_at=r["created_at"], updated_at=r["updated_at"]) for r in rows]

    async def add_bookmark(self, url: str, title: Optional[str] = None, description: Optional[str] = None, tags: Optional[List[str]] = None, folder: Optional[str] = None) -> Bookmark:
        if not self.db_pool:
            raise RuntimeError("Database not initialized")
        bid = uuid4()
        await self.db_pool.execute(
            "INSERT INTO bookmarks (id, url, title, description, tags, folder, created_at) VALUES ($1, $2, $3, $4, $5, $6, NOW())",
            bid, url, title or url, description, tags or [], folder
        )
        return Bookmark(id=bid, url=url, title=title or url, description=description, tags=tags or [], folder=folder)

    async def get_bookmarks(self, folder: Optional[str] = None, search: Optional[str] = None) -> List[Bookmark]:
        if not self.db_pool:
            return []
        q = "SELECT * FROM bookmarks WHERE is_archived = false"
        params = []
        if folder:
            q += " AND folder = $%d" % (len(params) + 1)
            params.append(folder)
        if search:
            q += " AND (title ILIKE $%d OR url ILIKE $%d OR description ILIKE $%d)" % (len(params) + 1, len(params) + 1, len(params) + 1)
            params.append(f"%{search}%")
        q += " ORDER BY created_at DESC"
        rows = await self.db_pool.fetch(q, *params)
        return [Bookmark(id=r["id"], url=r["url"], title=r["title"], description=r["description"], tags=r["tags"] or [], folder=r["folder"], click_count=r["click_count"] or 0, is_archived=r["is_archived"] or False, created_at=r["created_at"]) for r in rows]

    async def add_reading_item(self, title: str, url: Optional[str] = None, content_type: str = "article", priority: str = "medium", estimated_time: Optional[int] = None) -> ReadingListItem:
        if not self.db_pool:
            raise RuntimeError("Database not initialized")
        rid = uuid4()
        await self.db_pool.execute(
            "INSERT INTO reading_list (id, title, url, content_type, priority, estimated_reading_time, created_at) VALUES ($1, $2, $3, $4, $5, $6, NOW())",
            rid, title, url, content_type, priority, estimated_time
        )
        return ReadingListItem(id=rid, title=title, url=url, content_type=content_type, priority=priority, estimated_reading_time=estimated_time)

    async def get_reading_list(self, status: Optional[str] = None) -> List[ReadingListItem]:
        if not self.db_pool:
            return []
        q = "SELECT * FROM reading_list"
        params = []
        if status:
            q += " WHERE status = $1"
            params.append(status)
        q += " ORDER BY created_at DESC"
        rows = await self.db_pool.fetch(q, *params)
        return [ReadingListItem(id=r["id"], title=r["title"], url=r["url"], content_type=r["content_type"], status=r["status"], priority=r["priority"], estimated_reading_time=r["estimated_reading_time"], notes=r["notes"], created_at=r["created_at"]) for r in rows]
