"""ZANOX V16 - Knowledge Management System."""
from .router import router
from .service import KnowledgeService
__all__ = ["router", "KnowledgeService"]
