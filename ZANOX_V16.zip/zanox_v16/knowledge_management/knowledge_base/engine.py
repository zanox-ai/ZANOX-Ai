"""Knowledge Base Engine - Full-text search and knowledge graph."""
from typing import Dict, List, Optional
from uuid import UUID
import asyncpg

class KnowledgeBaseEngine:
    def __init__(self):
        self.db_pool = None
    def initialize(self, db_pool):
        self.db_pool = db_pool

    async def full_text_search(self, query: str, limit: int = 20) -> List[Dict]:
        if not self.db_pool:
            return []
        rows = await self.db_pool.fetch(
            """SELECT id, title, content, category, ts_rank(to_tsvector('english', title || ' ' || content), plainto_tsquery('english', $1)) as rank
               FROM knowledge_entries
               WHERE to_tsvector('english', title || ' ' || content) @@ plainto_tsquery('english', $1)
               ORDER BY rank DESC LIMIT $2""",
            query, limit
        )
        return [dict(r) for r in rows]

    async def get_related_entries(self, entry_id: UUID) -> List[Dict]:
        if not self.db_pool:
            return []
        row = await self.db_pool.fetchrow("SELECT tags, category FROM knowledge_entries WHERE id = $1", entry_id)
        if not row:
            return []
        rows = await self.db_pool.fetch(
            "SELECT id, title FROM knowledge_entries WHERE id != $1 AND (category = $2 OR tags && $3) LIMIT 10",
            entry_id, row["category"], row["tags"] or []
        )
        return [dict(r) for r in rows]
