"""Knowledge Base - Structured knowledge storage."""
from .engine import KnowledgeBaseEngine
