"""Knowledge Management Router - FastAPI endpoints."""
from typing import Optional, List
from uuid import UUID
from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from ..models import APIResponse
from .service import KnowledgeService

router = APIRouter()
_service: Optional[KnowledgeService] = None

def set_service(service: KnowledgeService):
    global _service
    _service = service

class KnowledgeEntryRequest(BaseModel):
    title: str
    content: str
    category: Optional[str] = None
    tags: Optional[List[str]] = None
    source: Optional[str] = None

class NoteRequest(BaseModel):
    title: Optional[str] = None
    content: str
    note_type: str = "quick"
    tags: Optional[List[str]] = None
    folder: Optional[str] = None

class BookmarkRequest(BaseModel):
    url: str
    title: Optional[str] = None
    description: Optional[str] = None
    tags: Optional[List[str]] = None
    folder: Optional[str] = None

class ReadingItemRequest(BaseModel):
    title: str
    url: Optional[str] = None
    content_type: str = "article"
    priority: str = "medium"
    estimated_reading_time: Optional[int] = None

@router.post("/entries", response_model=APIResponse)
async def create_knowledge_entry(request: KnowledgeEntryRequest):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.create_knowledge_entry(request.title, request.content, request.category, request.tags, request.source)
    return APIResponse(success=True, data=result.model_dump() if hasattr(result, "model_dump") else result)

@router.get("/entries/search", response_model=APIResponse)
async def search_knowledge(q: str = Query(...), limit: int = Query(20)):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.search_knowledge(q, limit)
    return APIResponse(success=True, data=[e.model_dump() if hasattr(e, "model_dump") else e for e in result])

@router.post("/notes", response_model=APIResponse)
async def create_note(request: NoteRequest):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.create_note(request.title, request.content, request.note_type, request.tags, request.folder)
    return APIResponse(success=True, data=result.model_dump() if hasattr(result, "model_dump") else result)

@router.get("/notes", response_model=APIResponse)
async def get_notes(note_type: Optional[str] = Query(None), folder: Optional[str] = Query(None), search: Optional[str] = Query(None)):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.get_notes(note_type, folder, search)
    return APIResponse(success=True, data=[n.model_dump() if hasattr(n, "model_dump") else n for n in result])

@router.post("/bookmarks", response_model=APIResponse)
async def add_bookmark(request: BookmarkRequest):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.add_bookmark(request.url, request.title, request.description, request.tags, request.folder)
    return APIResponse(success=True, data=result.model_dump() if hasattr(result, "model_dump") else result)

@router.get("/bookmarks", response_model=APIResponse)
async def get_bookmarks(folder: Optional[str] = Query(None), search: Optional[str] = Query(None)):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.get_bookmarks(folder, search)
    return APIResponse(success=True, data=[b.model_dump() if hasattr(b, "model_dump") else b for b in result])

@router.post("/reading-list", response_model=APIResponse)
async def add_reading_item(request: ReadingItemRequest):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.add_reading_item(request.title, request.url, request.content_type, request.priority, request.estimated_reading_time)
    return APIResponse(success=True, data=result.model_dump() if hasattr(result, "model_dump") else result)

@router.get("/reading-list", response_model=APIResponse)
async def get_reading_list(status: Optional[str] = Query(None)):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.get_reading_list(status)
    return APIResponse(success=True, data=[r.model_dump() if hasattr(r, "model_dump") else r for r in result])
