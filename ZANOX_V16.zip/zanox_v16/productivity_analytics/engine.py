"""Productivity Analytics Engine - Deep productivity analysis and insights."""
from datetime import datetime, date, timedelta
from typing import Dict, List, Optional, Any
import asyncpg

class ProductivityAnalyticsEngine:
    def __init__(self):
        self.db_pool = None
    def initialize(self, db_pool, redis_client):
        self.db_pool = db_pool

    async def get_metrics(self, period_days: int = 7) -> Dict[str, Any]:
        if not self.db_pool:
            return {}
        start = datetime.utcnow() - timedelta(days=period_days)
        total_tasks = await self.db_pool.fetchval("SELECT COUNT(*) FROM tasks WHERE created_at >= $1", start) or 1
        completed = await self.db_pool.fetchval("SELECT COUNT(*) FROM tasks WHERE status = 'completed' AND updated_at >= $1", start) or 0
        on_time = await self.db_pool.fetchval("SELECT COUNT(*) FROM tasks WHERE status = 'completed' AND (completed_at <= due_date OR due_date IS NULL) AND updated_at >= $1", start) or 0
        focus_min = await self.db_pool.fetchval("SELECT COALESCE(SUM(actual_duration_minutes), 0) FROM focus_sessions WHERE started_at >= $1", start) or 0
        pomos = await self.db_pool.fetchval("SELECT COUNT(*) FROM pomodoro_sessions WHERE completed = true AND completed_at >= $1", start) or 0
        avg_task_time = await self.db_pool.fetchval(
            "SELECT AVG(EXTRACT(EPOCH FROM (updated_at - created_at))/3600) FROM tasks WHERE status = 'completed' AND updated_at >= $1", start
        ) or 0
        return {
            "period_days": period_days,
            "task_completion_rate": round(completed / max(total_tasks, 1) * 100, 1),
            "on_time_completion_rate": round(on_time / max(completed, 1) * 100, 1),
            "average_task_duration_hours": round(avg_task_time, 1),
            "total_focus_hours": round(focus_min / 60, 1),
            "pomodoros_completed": pomos,
            "deep_work_hours": round(focus_min / 60 * 0.6, 1),
            "overall_productivity_score": round(min((completed / max(total_tasks, 1) * 100 + min(focus_min / 60 / (period_days * 4), 1) * 100) / 2, 100), 1)
        }

    async def get_trend(self, weeks: int = 4) -> List[Dict]:
        if not self.db_pool:
            return []
        trends = []
        for i in range(weeks):
            week_start = datetime.utcnow() - timedelta(weeks=i+1)
            week_end = datetime.utcnow() - timedelta(weeks=i)
            completed = await self.db_pool.fetchval("SELECT COUNT(*) FROM tasks WHERE status = 'completed' AND updated_at >= $1 AND updated_at < $2", week_start, week_end) or 0
            focus = await self.db_pool.fetchval("SELECT COALESCE(SUM(actual_duration_minutes), 0) FROM focus_sessions WHERE started_at >= $1 AND started_at < $2", week_start, week_end) or 0
            trends.append({
                "week": (week_start + timedelta(days=3)).strftime("%Y-W%U"),
                "tasks_completed": completed,
                "focus_hours": round(focus / 60, 1)
            })
        return list(reversed(trends))

    async def get_comparison_to_previous(self, period_days: int = 7) -> Dict[str, Any]:
        current = await self.get_metrics(period_days)
        previous = await self.get_metrics(period_days * 2)
        return {
            "current": current,
            "change": {
                "task_completion_change": round(current.get("task_completion_rate", 0) - previous.get("task_completion_rate", 0), 1),
                "focus_hours_change": round(current.get("total_focus_hours", 0) - previous.get("total_focus_hours", 0), 1),
            }
        }
