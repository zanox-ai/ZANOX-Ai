"""Security Engine - Encryption, access control, and audit."""
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
import hashlib
import hmac
import secrets

class SecurityEngine:
    def __init__(self):
        self.db_pool = None
        self.redis = None
        self.encryption_key = None
    def initialize(self, db_pool, redis_client):
        self.db_pool = db_pool
        self.redis = redis_client

    def hash_password(self, password: str, salt: Optional[str] = None) -> Dict[str, str]:
        """Hash a password with salt."""
        salt = salt or secrets.token_hex(16)
        hashed = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 100000)
        return {"hash": hashed.hex(), "salt": salt}

    def verify_password(self, password: str, hash_hex: str, salt: str) -> bool:
        """Verify a password against a hash."""
        expected = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 100000)
        return hmac.compare_digest(expected.hex(), hash_hex)

    def generate_token(self, user_id: str, expires_hours: int = 24) -> str:
        """Generate a secure session token."""
        import base64
        import json
        payload = {
            "user_id": user_id,
            "iat": datetime.utcnow().isoformat(),
            "exp": (datetime.utcnow() + timedelta(hours=expires_hours)).isoformat(),
            "nonce": secrets.token_hex(8)
        }
        return base64.b64encode(json.dumps(payload).encode()).decode()

    async def audit_log(self, action: str, user_id: str, details: Optional[Dict] = None):
        """Log security-relevant events."""
        if self.db_pool:
            await self.db_pool.execute(
                "INSERT INTO audit_log (id, action, user_id, details, created_at) VALUES (gen_random_uuid(), $1, $2, $3, NOW())",
                action, user_id, details or {}
            )

    async def get_audit_log(self, user_id: Optional[str] = None, days: int = 30) -> List[Dict]:
        """Get audit log entries."""
        if not self.db_pool:
            return []
        if user_id:
            rows = await self.db_pool.fetch(
                "SELECT * FROM audit_log WHERE user_id = $1 AND created_at > NOW() - INTERVAL '%s days' ORDER BY created_at DESC" % days,
                user_id
            )
        else:
            rows = await self.db_pool.fetch(
                "SELECT * FROM audit_log WHERE created_at > NOW() - INTERVAL '%s days' ORDER BY created_at DESC LIMIT 100" % days
            )
        return [dict(r) for r in rows]
