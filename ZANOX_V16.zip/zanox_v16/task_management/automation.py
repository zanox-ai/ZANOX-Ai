"""
Task Automation Engine - Automated Task Processing
Handles recurring tasks, automatic status transitions, and workflow automation.
"""

from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from uuid import UUID

import asyncpg
import redis.asyncio as redis


class TaskAutomation:
    """Automates task processing including recurring tasks and status transitions."""

    def __init__(self):
        self.db_pool: Optional[asyncpg.Pool] = None
        self.redis: Optional[redis.Redis] = None

    def initialize(self, db_pool: asyncpg.Pool, redis_client: redis.Redis):
        self.db_pool = db_pool
        self.redis = redis_client

    async def process_recurring_tasks(self) -> int:
        """Process all recurring task rules and create new instances."""
        if not self.db_pool:
            return 0

        rows = await self.db_pool.fetch(
            """SELECT * FROM recurring_task_rules WHERE active = true
               AND (end_date IS NULL OR end_date > NOW())"""
        )

        created = 0
        for rule in rows:
            should_create = await self._should_create_instance(rule)
            if should_create:
                await self._create_task_instance(rule)
                created += 1

        return created

    async def auto_transition_tasks(self) -> int:
        """Automatically transition tasks based on rules."""
        if not self.db_pool:
            return 0

        # Auto-start tasks whose dependencies are resolved
        result = await self.db_pool.execute(
            """UPDATE tasks SET status = 'in_progress', updated_at = NOW()
               WHERE status = 'blocked'
               AND NOT EXISTS (
                 SELECT 1 FROM task_dependencies d
                 JOIN tasks dep ON d.depends_on_task_id = dep.id
                 WHERE d.task_id = tasks.id AND dep.status != 'completed'
               )"""
        )

        # Auto-complete tasks with all subtasks done
        await self.db_pool.execute(
            """UPDATE tasks SET status = 'completed', completed_at = NOW(), updated_at = NOW()
               WHERE status = 'in_progress'
               AND EXISTS (SELECT 1 FROM tasks sub WHERE sub.parent_task_id = tasks.id)
               AND NOT EXISTS (
                 SELECT 1 FROM tasks sub
                 WHERE sub.parent_task_id = tasks.id
                 AND sub.status != 'completed'
               )"""
        )

        try:
            return int(result.split()[-1])
        except (IndexError, ValueError):
            return 0

    async def send_deadline_reminders(self) -> int:
        """Send reminders for upcoming deadlines."""
        if not self.db_pool:
            return 0

        # Tasks due within 24 hours
        upcoming = await self.db_pool.fetch(
            """SELECT id, title, due_date, assigned_to
               FROM tasks
               WHERE due_date BETWEEN NOW() AND NOW() + INTERVAL '24 hours'
               AND status NOT IN ('completed', 'cancelled')
               AND reminder_sent = false"""
        )

        for task in upcoming:
            await self.db_pool.execute(
                """INSERT INTO reminders (id, title, message, trigger_time, entity_type, entity_id)
                 VALUES (gen_random_uuid(), $1, $2, NOW(), 'task', $3)""",
                f"Deadline approaching: {task['title']}",
                f"Task '{task['title']}' is due at {task['due_date']}",
                task["id"]
            )

            await self.db_pool.execute(
                "UPDATE tasks SET reminder_sent = true WHERE id = $1",
                task["id"]
            )

        return len(upcoming)

    async def _should_create_instance(self, rule: asyncpg.Record) -> bool:
        """Check if a new recurring task instance should be created."""
        if not self.db_pool:
            return False

        last_created = await self.db_pool.fetchval(
            """SELECT MAX(created_at) FROM tasks WHERE recurring_rule_id = $1""",
            rule["id"]
        )

        if not last_created:
            return True

        frequency = rule["frequency"]
        interval = rule["interval"] or 1

        if frequency == "daily":
            return (datetime.utcnow() - last_created).days >= interval
        elif frequency == "weekly":
            return (datetime.utcnow() - last_created).days >= 7 * interval
        elif frequency == "monthly":
            return (datetime.utcnow() - last_created).days >= 30 * interval

        return False

    async def _create_task_instance(self, rule: asyncpg.Record):
        """Create a new task instance from a recurring rule."""
        if not self.db_pool:
            return

        template = await self.db_pool.fetchrow(
            "SELECT * FROM tasks WHERE id = $1", rule["task_template_id"]
        )

        if not template:
            return

        due_date = None
        if template["due_date"]:
            days_offset = (datetime.utcnow() - template["due_date"]).days
            due_date = datetime.utcnow() + timedelta(days=max(days_offset, 1))

        await self.db_pool.execute(
            """INSERT INTO tasks (title, description, priority, status, due_date,
                estimated_duration_minutes, tags, project_id, goal_id, assigned_to,
                recurring_rule_id, created_at, updated_at)
             VALUES ($1, $2, $3, 'todo', $4, $5, $6, $7, $8, $9, $10, NOW(), NOW())""",
            template["title"], template["description"], template["priority"],
            due_date, template["estimated_duration_minutes"],
            template["tags"], template["project_id"], template["goal_id"],
            template["assigned_to"], rule["id"]
        )
