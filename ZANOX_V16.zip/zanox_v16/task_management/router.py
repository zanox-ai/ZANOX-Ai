"""
Task Management Router - FastAPI endpoints for task operations.
"""

from typing import Optional, List
from uuid import UUID
from fastapi import APIRouter, HTTPException, Query

from ..models import TaskCreate, TaskUpdate, APIResponse, PaginatedResponse, BulkActionRequest
from .service import TaskService

router = APIRouter()

_service: Optional[TaskService] = None

def set_service(service: TaskService):
    global _service
    _service = service

@router.post("", response_model=APIResponse)
async def create_task(task: TaskCreate):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.create_task(task)
    return APIResponse(success=True, data=result.model_dump() if hasattr(result, "model_dump") else result)

@router.get("", response_model=APIResponse)
async def list_tasks(
    status: Optional[str] = Query(None),
    priority: Optional[str] = Query(None),
    project_id: Optional[UUID] = Query(None),
    goal_id: Optional[UUID] = Query(None),
    overdue_only: bool = Query(False),
    search: Optional[str] = Query(None),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    sort_by: str = Query("due_date"),
    sort_order: str = Query("asc")
):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.list_tasks(
        status=status, priority=priority, project_id=project_id,
        goal_id=goal_id, overdue_only=overdue_only, search=search,
        page=page, page_size=page_size, sort_by=sort_by, sort_order=sort_order
    )
    return APIResponse(success=True, data={"items": [t.model_dump() if hasattr(t, "model_dump") else t for t in result.items], "total": result.total, "page": result.page, "page_size": result.page_size, "total_pages": result.total_pages})

@router.get("/{task_id}", response_model=APIResponse)
async def get_task(task_id: UUID):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.get_task(task_id)
    if not result:
        raise HTTPException(status_code=404, detail="Task not found")
    return APIResponse(success=True, data=result.model_dump() if hasattr(result, "model_dump") else result)

@router.put("/{task_id}", response_model=APIResponse)
async def update_task(task_id: UUID, update: TaskUpdate):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.update_task(task_id, update)
    if not result:
        raise HTTPException(status_code=404, detail="Task not found")
    return APIResponse(success=True, data=result.model_dump() if hasattr(result, "model_dump") else result)

@router.delete("/{task_id}", response_model=APIResponse)
async def delete_task(task_id: UUID):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    success = await _service.delete_task(task_id)
    return APIResponse(success=success, message="Task deleted" if success else "Failed")

@router.post("/bulk", response_model=APIResponse)
async def bulk_update(request: BulkActionRequest):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    count = await _service.bulk_update(request.ids, {"status": request.action})
    return APIResponse(success=True, data={"updated": count})

@router.get("/stats/summary", response_model=APIResponse)
async def get_task_stats():
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    stats = await _service.get_task_stats()
    return APIResponse(success=True, data=stats)
