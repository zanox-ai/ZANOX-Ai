"""
Task Prioritization Engine - Intelligent Task Prioritization
Uses multi-factor scoring to determine task priority and execution order.
"""

import json
import math
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from uuid import UUID

import asyncpg
import redis.asyncio as redis


class TaskPrioritizer:
    """Multi-factor task prioritization using urgency, importance, effort, and deadline scoring."""

    # Priority weights
    URGENCY_WEIGHT = 0.35
    IMPORTANCE_WEIGHT = 0.30
    EFFORT_WEIGHT = 0.15
    DEADLINE_WEIGHT = 0.20

    def __init__(self):
        self.db_pool: Optional[asyncpg.Pool] = None
        self.redis: Optional[redis.Redis] = None

    def initialize(self, db_pool: asyncpg.Pool, redis_client: redis.Redis):
        self.db_pool = db_pool
        self.redis = redis_client

    async def prioritize_tasks(self, user_id: Optional[str] = None,
                                task_ids: Optional[List[UUID]] = None,
                                limit: int = 20) -> List[Dict[str, Any]]:
        """Generate prioritized task list with scoring."""
        if not self.db_pool:
            return []
        
        if task_ids:
            rows = await self.db_pool.fetch(
                """SELECT * FROM tasks 
                   WHERE id = ANY($1) AND status NOT IN ('completed', 'cancelled')
                   ORDER BY created_at""",
                [str(t) for t in task_ids]
            )
        else:
            rows = await self.db_pool.fetch(
                """SELECT * FROM tasks 
                   WHERE status NOT IN ('completed', 'cancelled')
                   AND (assigned_to = $1 OR assigned_to IS NULL)
                   ORDER BY created_at LIMIT $2""",
                user_id, limit * 2
            )
        
        scored_tasks = []
        for row in rows:
            scores = self._calculate_scores(row)
            composite = (
                scores["urgency"] * self.URGENCY_WEIGHT +
                scores["importance"] * self.IMPORTANCE_WEIGHT +
                scores["effort"] * self.EFFORT_WEIGHT +
                scores["deadline"] * self.DEADLINE_WEIGHT
            )
            
            scored_tasks.append({
                "task_id": str(row["id"]),
                "title": row["title"],
                "priority": row["priority"],
                "composite_score": round(composite, 2),
                "scores": {k: round(v, 2) for k, v in scores.items()},
                "due_date": row["due_date"].isoformat() if row["due_date"] else None,
                "estimated_minutes": row["estimated_duration_minutes"]
            })
        
        scored_tasks.sort(key=lambda t: t["composite_score"], reverse=True)
        
        # Add recommended order
        for i, task in enumerate(scored_tasks[:limit], 1):
            task["recommended_order"] = i
        
        return scored_tasks[:limit]

    async def get_eisenhower_matrix(self, user_id: Optional[str] = None) -> Dict[str, List[Dict[str, Any]]]:
        """Get tasks organized in the Eisenhower Matrix."""
        prioritized = await self.prioritize_tasks(user_id)
        
        matrix = {
            "urgent_important": [],
            "important_not_urgent": [],
            "urgent_not_important": [],
            "not_urgent_not_important": []
        }
        
        for task in prioritized:
            urgency = task["scores"]["urgency"]
            importance = task["scores"]["importance"]
            
            if urgency >= 0.6 and importance >= 0.6:
                matrix["urgent_important"].append(task)
            elif urgency < 0.6 and importance >= 0.6:
                matrix["important_not_urgent"].append(task)
            elif urgency >= 0.6 and importance < 0.6:
                matrix["urgent_not_important"].append(task)
            else:
                matrix["not_urgent_not_important"].append(task)
        
        return matrix

    def _calculate_scores(self, row: asyncpg.Record) -> Dict[str, float]:
        """Calculate individual factor scores for a task."""
        now = datetime.utcnow()
        
        # Urgency score (0-1)
        priority_urgency = {"urgent": 1.0, "high": 0.75, "medium": 0.5, "low": 0.25, "minimal": 0.1}
        base_urgency = priority_urgency.get(row["priority"], 0.5)
        
        # Boost urgency if overdue
        if row["due_date"] and row["due_date"] < now:
            base_urgency = min(base_urgency * 1.5, 1.0)
        
        urgency = min(base_urgency, 1.0)
        
        # Importance score (0-1)
        importance = priority_urgency.get(row["priority"], 0.5)
        
        # Effort score (0-1, higher = less effort = better to do)
        estimated = row["estimated_duration_minutes"] or 60
        if estimated <= 15:
            effort = 0.9
        elif estimated <= 60:
            effort = 0.7
        elif estimated <= 120:
            effort = 0.5
        elif estimated <= 240:
            effort = 0.3
        else:
            effort = 0.2
        
        # Deadline score (0-1, higher = closer deadline)
        if row["due_date"]:
            time_until_due = (row["due_date"] - now).total_seconds()
            if time_until_due <= 0:
                deadline = 1.0
            elif time_until_due <= 86400:  # 24 hours
                deadline = 0.8
            elif time_until_due <= 259200:  # 3 days
                deadline = 0.6
            elif time_until_due <= 604800:  # 7 days
                deadline = 0.4
            elif time_until_due <= 2592000:  # 30 days
                deadline = 0.2
            else:
                deadline = 0.1
        else:
            deadline = 0.3  # No deadline = moderate
        
        return {
            "urgency": urgency,
            "importance": importance,
            "effort": effort,
            "deadline": deadline
        }

    async def suggest_next_task(self, user_id: Optional[str] = None,
                                 context: Optional[Dict] = None) -> Optional[Dict[str, Any]]:
        """Suggest the next task to work on based on current context."""
        prioritized = await self.prioritize_tasks(user_id, limit=5)
        
        if not prioritized:
            return None
        
        # Adjust based on context
        if context:
            available_time = context.get("available_minutes", 60)
            # Filter tasks that fit available time
            fitting = [t for t in prioritized 
                       if (t.get("estimated_minutes") or 60) <= available_time]
            if fitting:
                return fitting[0]
        
        return prioritized[0]
