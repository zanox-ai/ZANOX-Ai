"""
Task Scheduler - Intelligent Task Scheduling
Schedules tasks based on priority, deadlines, availability, and user preferences.
"""

import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from uuid import UUID

import asyncpg
import redis.asyncio as redis


class TaskScheduler:
    """Intelligent task scheduler that optimizes when tasks should be worked on."""

    def __init__(self):
        self.db_pool: Optional[asyncpg.Pool] = None
        self.redis: Optional[redis.Redis] = None

    def initialize(self, db_pool: asyncpg.Pool, redis_client: redis.Redis):
        self.db_pool = db_pool
        self.redis = redis_client

    async def schedule_task(self, task_id: UUID, preferred_date: Optional[datetime] = None,
                            constraints: Optional[Dict] = None) -> Dict[str, Any]:
        """Find the optimal time slot for a task."""
        if not self.db_pool:
            return {"error": "Database not initialized"}
        
        task = await self.db_pool.fetchrow("SELECT * FROM tasks WHERE id = $1", task_id)
        if not task:
            return {"error": "Task not found"}
        
        # Get available slots
        target_date = preferred_date or datetime.utcnow()
        available_slots = await self._find_available_slots(target_date, task["estimated_duration_minutes"] or 60)
        
        # Score each slot based on task priority and user energy
        scored_slots = []
        for slot in available_slots:
            score = self._score_slot(slot, task)
            scored_slots.append({**slot, "score": score})
        
        scored_slots.sort(key=lambda s: s["score"], reverse=True)
        
        return {
            "task_id": str(task_id),
            "task_title": task["title"],
            "recommended_slots": scored_slots[:5],
            "rationale": self._generate_scheduling_rationale(task, scored_slots[:1])
        }

    async def auto_schedule_tasks(self, user_id: Optional[str] = None,
                                   date: Optional[datetime] = None) -> List[Dict[str, Any]]:
        """Automatically schedule all unscheduled tasks for a day."""
        if not self.db_pool:
            return []
        
        target_date = date or datetime.utcnow()
        day_start = target_date.replace(hour=9, minute=0, second=0, microsecond=0)
        day_end = target_date.replace(hour=17, minute=0, second=0, microsecond=0)
        
        # Get unscheduled tasks
        rows = await self.db_pool.fetch(
            """SELECT * FROM tasks 
               WHERE status NOT IN ('completed', 'cancelled')
               AND (due_date IS NULL OR due_date <= $1 + INTERVAL '7 days')
               ORDER BY 
                 CASE priority WHEN 'urgent' THEN 1 WHEN 'high' THEN 2 WHEN 'medium' THEN 3 ELSE 4 END,
                 COALESCE(due_date, '9999-12-31')""",
            target_date
        )
        
        # Get existing events
        events = await self._get_day_events(target_date)
        
        # Simple scheduling: fill gaps
        schedule = []
        current_time = day_start
        
        for task in rows:
            if current_time >= day_end:
                break
            
            # Skip past occupied times
            while any(e["start_time"] <= current_time < e["end_time"] for e in events):
                current_time = min(
                    (e["end_time"] for e in events if e["start_time"] <= current_time < e["end_time"]),
                    default=current_time + timedelta(hours=1)
                )
            
            duration = timedelta(minutes=task["estimated_duration_minutes"] or 60)
            end_time = min(current_time + duration, day_end)
            
            schedule.append({
                "task_id": str(task["id"]),
                "title": task["title"],
                "scheduled_start": current_time.isoformat(),
                "scheduled_end": end_time.isoformat(),
                "priority": task["priority"]
            })
            
            current_time = end_time
        
        return schedule

    async def _find_available_slots(self, date: datetime, 
                                     duration_minutes: int) -> List[Dict[str, Any]]:
        """Find available time slots on a given date."""
        if not self.db_pool:
            return []
        
        day_start = date.replace(hour=9, minute=0, second=0, microsecond=0)
        day_end = date.replace(hour=17, minute=0, second=0, microsecond=0)
        
        events = await self._get_day_events(date)
        
        slots = []
        current = day_start
        duration = timedelta(minutes=duration_minutes)
        
        while current + duration <= day_end:
            is_free = all(
                not (e["start_time"] <= current < e["end_time"] or
                     e["start_time"] < current + duration <= e["end_time"])
                for e in events
            )
            
            if is_free:
                slots.append({
                    "start_time": current.isoformat(),
                    "end_time": (current + duration).isoformat(),
                    "hour": current.hour
                })
                current += duration
            else:
                current += timedelta(minutes=30)
        
        return slots

    async def _get_day_events(self, date: datetime) -> List[Dict[str, Any]]:
        """Get calendar events for a day."""
        if not self.db_pool:
            return []
        
        rows = await self.db_pool.fetch(
            "SELECT start_time, end_time FROM calendar_events WHERE DATE(start_time) = DATE($1)",
            date
        )
        return [dict(r) for r in rows]

    def _score_slot(self, slot: Dict, task: asyncpg.Record) -> float:
        """Score a time slot for a task."""
        score = 50.0
        
        # Higher score for morning slots for important tasks
        hour = slot.get("hour", 12)
        if task["priority"] in ("urgent", "high") and 9 <= hour <= 11:
            score += 30
        elif task["priority"] == "medium" and 10 <= hour <= 14:
            score += 20
        elif task["priority"] == "low" and hour >= 15:
            score += 10
        
        return min(score, 100)

    def _generate_scheduling_rationale(self, task: asyncpg.Record, 
                                        slots: List[Dict]) -> str:
        """Generate explanation for the scheduling recommendation."""
        if not slots:
            return "No available slots found. Consider rescheduling existing commitments."
        
        best = slots[0]
        priority = task["priority"]
        
        rationale = f"Task '{task['title']}' ({priority} priority) scheduled for {best['start_time']}."
        
        if priority in ("urgent", "high"):
            rationale += " High-priority tasks are scheduled during peak morning hours."
        
        return rationale
