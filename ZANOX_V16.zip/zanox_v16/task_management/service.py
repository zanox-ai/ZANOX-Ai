"""
Task Management Service - Core Task Operations
Provides full CRUD operations for tasks with filtering, sorting, and bulk operations.
"""

import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from uuid import UUID

import asyncpg
import redis.asyncio as redis

from ..models import Task, TaskCreate, TaskUpdate, TaskStatus, PriorityLevel, PaginatedResponse


class TaskService:
    """Core service for task management operations."""

    def __init__(self):
        self.db_pool: Optional[asyncpg.Pool] = None
        self.redis: Optional[redis.Redis] = None

    def initialize(self, db_pool: asyncpg.Pool, redis_client: redis.Redis):
        self.db_pool = db_pool
        self.redis = redis_client

    async def create_task(self, task: TaskCreate, task_id: Optional[UUID] = None) -> Task:
        """Create a new task."""
        if not self.db_pool:
            raise RuntimeError("Database not initialized")
        
        tid = task_id or task.id if hasattr(task, 'id') else None
        if not tid:
            from uuid import uuid4
            tid = uuid4()
        
        await self.db_pool.execute(
            """INSERT INTO tasks (id, title, description, priority, status, due_date,
                estimated_duration_minutes, tags, project_id, goal_id, assigned_to,
                parent_task_id, metadata, created_at, updated_at)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, NOW(), NOW())""",
            tid, task.title, task.description, task.priority.value, task.status.value,
            task.due_date, task.estimated_duration_minutes,
            json.dumps(task.tags) if task.tags else "[]",
            str(task.project_id) if task.project_id else None,
            str(task.goal_id) if task.goal_id else None,
            str(task.assigned_to) if task.assigned_to else None,
            str(task.parent_task_id) if task.parent_task_id else None,
            json.dumps(task.metadata) if task.metadata else "{}"
        )
        
        # Handle dependencies
        if hasattr(task, 'dependencies') and task.dependencies:
            for dep_id in task.dependencies:
                await self.db_pool.execute(
                    """INSERT INTO task_dependencies (id, task_id, depends_on_task_id, dependency_type)
                     VALUES (gen_random_uuid(), $1, $2, 'blocked_by')""",
                    tid, dep_id
                )
        
        # Cache the task
        if self.redis:
            await self.redis.setex(f"task:{tid}", 3600, json.dumps({
                "id": str(tid), "title": task.title, "status": task.status.value,
                "priority": task.priority.value
            }))
        
        return await self.get_task(tid)

    async def get_task(self, task_id: UUID) -> Optional[Task]:
        """Get a task by ID."""
        if not self.db_pool:
            return None
        
        row = await self.db_pool.fetchrow("SELECT * FROM tasks WHERE id = $1", task_id)
        if not row:
            return None
        
        return self._row_to_task(row)

    async def update_task(self, task_id: UUID, update: TaskUpdate) -> Optional[Task]:
        """Update a task."""
        if not self.db_pool:
            return None
        
        updates = []
        params = [task_id]
        
        if update.title is not None:
            updates.append(f"title = ${len(params) + 1}")
            params.append(update.title)
        if update.description is not None:
            updates.append(f"description = ${len(params) + 1}")
            params.append(update.description)
        if update.priority is not None:
            updates.append(f"priority = ${len(params) + 1}")
            params.append(update.priority.value)
        if update.status is not None:
            updates.append(f"status = ${len(params) + 1}")
            params.append(update.status.value)
            if update.status == TaskStatus.COMPLETED:
                updates.append("completed_at = NOW()")
        if update.due_date is not None:
            updates.append(f"due_date = ${len(params) + 1}")
            params.append(update.due_date)
        if update.estimated_duration_minutes is not None:
            updates.append(f"estimated_duration_minutes = ${len(params) + 1}")
            params.append(update.estimated_duration_minutes)
        if update.actual_duration_minutes is not None:
            updates.append(f"actual_duration_minutes = ${len(params) + 1}")
            params.append(update.actual_duration_minutes)
        if update.tags is not None:
            updates.append(f"tags = ${len(params) + 1}")
            params.append(json.dumps(update.tags))
        if update.project_id is not None:
            updates.append(f"project_id = ${len(params) + 1}")
            params.append(str(update.project_id))
        if update.goal_id is not None:
            updates.append(f"goal_id = ${len(params) + 1}")
            params.append(str(update.goal_id))
        
        updates.append("updated_at = NOW()")
        
        query = f"UPDATE tasks SET {', '.join(updates)} WHERE id = $1"
        await self.db_pool.execute(query, *params)
        
        # Invalidate cache
        if self.redis:
            await self.redis.delete(f"task:{task_id}")
        
        return await self.get_task(task_id)

    async def delete_task(self, task_id: UUID) -> bool:
        """Delete a task (soft delete by default)."""
        if not self.db_pool:
            return False
        
        await self.db_pool.execute(
            "UPDATE tasks SET status = 'cancelled', updated_at = NOW() WHERE id = $1",
            task_id
        )
        
        if self.redis:
            await self.redis.delete(f"task:{task_id}")
        
        return True

    async def list_tasks(
        self, user_id: Optional[str] = None,
        status: Optional[str] = None,
        priority: Optional[str] = None,
        project_id: Optional[UUID] = None,
        goal_id: Optional[UUID] = None,
        overdue_only: bool = False,
        search: Optional[str] = None,
        page: int = 1, page_size: int = 20,
        sort_by: str = "due_date", sort_order: str = "asc"
    ) -> PaginatedResponse:
        """List tasks with filtering and pagination."""
        if not self.db_pool:
            return PaginatedResponse(items=[], total=0, page=page, page_size=page_size, total_pages=0)
        
        conditions = ["1=1"]
        params = []
        
        if user_id:
            conditions.append(f"(assigned_to = ${len(params) + 1} OR assigned_to IS NULL)")
            params.append(user_id)
        if status:
            conditions.append(f"status = ${len(params) + 1}")
            params.append(status)
        if priority:
            conditions.append(f"priority = ${len(params) + 1}")
            params.append(priority)
        if project_id:
            conditions.append(f"project_id = ${len(params) + 1}")
            params.append(str(project_id))
        if goal_id:
            conditions.append(f"goal_id = ${len(params) + 1}")
            params.append(str(goal_id))
        if overdue_only:
            conditions.append("due_date < NOW() AND status NOT IN ('completed', 'cancelled')")
        if search:
            conditions.append(f"(title ILIKE ${len(params) + 1} OR description ILIKE ${len(params) + 1})")
            params.append(f"%{search}%")
        
        where_clause = " AND ".join(conditions)
        
        # Get total count
        total = await self.db_pool.fetchval(
            f"SELECT COUNT(*) FROM tasks WHERE {where_clause}", *params
        )
        
        # Get paginated results
        offset = (page - 1) * page_size
        sort_column = {"due_date": "due_date", "priority": "priority", "created_at": "created_at", "title": "title"}.get(sort_by, "due_date")
        order = "DESC" if sort_order == "desc" else "ASC"
        
        rows = await self.db_pool.fetch(
            f"""SELECT * FROM tasks WHERE {where_clause}
                ORDER BY {sort_column} {order}
                LIMIT ${len(params) + 1} OFFSET ${len(params) + 2}""",
            *params, page_size, offset
        )
        
        tasks = [self._row_to_task(r) for r in rows]
        total_pages = (total + page_size - 1) // page_size
        
        return PaginatedResponse(
            items=tasks, total=total, page=page,
            page_size=page_size, total_pages=total_pages
        )

    async def get_task_stats(self, user_id: Optional[str] = None) -> Dict[str, Any]:
        """Get task statistics."""
        if not self.db_pool:
            return {}
        
        row = await self.db_pool.fetchrow(
            """SELECT 
                COUNT(*) FILTER (WHERE status NOT IN ('completed', 'cancelled')) as active,
                COUNT(*) FILTER (WHERE status = 'completed') as completed,
                COUNT(*) FILTER (WHERE status = 'in_progress') as in_progress,
                COUNT(*) FILTER (WHERE due_date < NOW() AND status NOT IN ('completed', 'cancelled')) as overdue,
                COUNT(*) as total
               FROM tasks
               WHERE assigned_to = $1 OR assigned_to IS NULL""",
            user_id
        )
        
        return dict(row) if row else {}

    async def bulk_update(self, task_ids: List[UUID], updates: Dict[str, Any]) -> int:
        """Bulk update tasks."""
        if not self.db_pool or not task_ids:
            return 0
        
        set_clauses = []
        params = []
        
        if "status" in updates:
            set_clauses.append(f"status = ${len(params) + 1}")
            params.append(updates["status"])
        if "priority" in updates:
            set_clauses.append(f"priority = ${len(params) + 1}")
            params.append(updates["priority"])
        if "project_id" in updates:
            set_clauses.append(f"project_id = ${len(params) + 1}")
            params.append(str(updates["project_id"]))
        
        set_clauses.append("updated_at = NOW()")
        
        query = f"UPDATE tasks SET {', '.join(set_clauses)} WHERE id = ANY(${len(params) + 1})"
        params.append([str(t) for t in task_ids])
        
        result = await self.db_pool.execute(query, *params)
        
        # Invalidate cache
        if self.redis:
            for tid in task_ids:
                await self.redis.delete(f"task:{tid}")
        
        # Parse "UPDATE N" result
        try:
            return int(result.split()[-1])
        except (IndexError, ValueError):
            return len(task_ids)

    def _row_to_task(self, row: asyncpg.Record) -> Task:
        """Convert a database row to a Task model."""
        tags = json.loads(row["tags"]) if isinstance(row["tags"], str) and row["tags"] else []
        metadata = json.loads(row["metadata"]) if isinstance(row["metadata"], str) and row["metadata"] else {}
        
        return Task(
            id=row["id"],
            title=row["title"],
            description=row["description"],
            priority=PriorityLevel(row["priority"]),
            status=TaskStatus(row["status"]),
            due_date=row["due_date"],
            estimated_duration_minutes=row["estimated_duration_minutes"],
            actual_duration_minutes=row["actual_duration_minutes"],
            tags=tags,
            project_id=UUID(row["project_id"]) if row["project_id"] else None,
            goal_id=UUID(row["goal_id"]) if row["goal_id"] else None,
            assigned_to=UUID(row["assigned_to"]) if row["assigned_to"] else None,
            parent_task_id=UUID(row["parent_task_id"]) if row["parent_task_id"] else None,
            metadata=metadata,
            created_at=row["created_at"],
            updated_at=row["updated_at"],
            completed_at=row["completed_at"]
        )
