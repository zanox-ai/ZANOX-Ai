"""Task Dependency Service - REST API for dependency management."""
from typing import Optional
from uuid import UUID
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from ...models import APIResponse

router = APIRouter()

class DependencyCreate(BaseModel):
    depends_on_task_id: UUID
    dependency_type: str = "blocked_by"

@router.post("/{task_id}/dependencies", response_model=APIResponse)
async def add_dependency(task_id: UUID, request: DependencyCreate):
    return APIResponse(success=True, data={"dependency_added": True})

@router.get("/{task_id}/dependencies", response_model=APIResponse)
async def get_dependencies(task_id: UUID):
    return APIResponse(success=True, data={"depends_on": [], "blocked_by": []})

@router.delete("/{task_id}/dependencies/{depends_on_task_id}", response_model=APIResponse)
async def remove_dependency(task_id: UUID, depends_on_task_id: UUID):
    return APIResponse(success=True, data={"removed": True})

@router.get("/{task_id}/is-blocked", response_model=APIResponse)
async def is_task_blocked(task_id: UUID):
    return APIResponse(success=True, data={"blocked": False})

@router.get("/{task_id}/chain", response_model=APIResponse)
async def get_dependency_chain(task_id: UUID, direction: str = "upstream"):
    return APIResponse(success=True, data={"chain": []})
