"""
Task Dependency Engine - Manages task dependencies and relationships
Handles task blocking, prerequisite chains, and dependency validation.
"""

from datetime import datetime
from typing import Dict, List, Optional, Any, Set
from uuid import UUID

import asyncpg
import redis.asyncio as redis


class DependencyManager:
    """Manages task dependencies, blocking relationships, and prerequisite chains."""

    def __init__(self):
        self.db_pool: Optional[asyncpg.Pool] = None
        self.redis: Optional[redis.Redis] = None

    def initialize(self, db_pool: asyncpg.Pool, redis_client: redis.Redis):
        self.db_pool = db_pool
        self.redis = redis_client

    async def add_dependency(self, task_id: UUID, depends_on_task_id: UUID,
                             dependency_type: str = "blocked_by") -> bool:
        """Add a dependency between two tasks."""
        if not self.db_pool:
            return False
        
        # Check for circular dependency
        if await self._would_create_cycle(task_id, depends_on_task_id):
            raise ValueError("Adding this dependency would create a circular reference")
        
        await self.db_pool.execute(
            """INSERT INTO task_dependencies (id, task_id, depends_on_task_id, dependency_type)
             VALUES (gen_random_uuid(), $1, $2, $3)
             ON CONFLICT (task_id, depends_on_task_id) DO NOTHING""",
            task_id, depends_on_task_id, dependency_type
        )
        
        # Update task status if now blocked
        await self._update_blocked_status(task_id)
        
        return True

    async def remove_dependency(self, task_id: UUID, depends_on_task_id: UUID) -> bool:
        """Remove a dependency between two tasks."""
        if not self.db_pool:
            return False
        
        await self.db_pool.execute(
            "DELETE FROM task_dependencies WHERE task_id = $1 AND depends_on_task_id = $2",
            task_id, depends_on_task_id
        )
        
        # Check if task is still blocked
        await self._update_blocked_status(task_id)
        
        return True

    async def get_dependencies(self, task_id: UUID) -> Dict[str, List[Dict[str, Any]]]:
        """Get all dependencies for a task."""
        if not self.db_pool:
            return {"depends_on": [], "blocked_by": []}
        
        # Tasks this task depends on
        depends_on = await self.db_pool.fetch(
            """SELECT d.*, t.title, t.status
               FROM task_dependencies d
               JOIN tasks t ON d.depends_on_task_id = t.id
               WHERE d.task_id = $1""",
            task_id
        )
        
        # Tasks that depend on this task
        blocked_by = await self.db_pool.fetch(
            """SELECT d.*, t.title, t.status
               FROM task_dependencies d
               JOIN tasks t ON d.task_id = t.id
               WHERE d.depends_on_task_id = $1""",
            task_id
        )
        
        return {
            "depends_on": [{"task_id": str(r["depends_on_task_id"]), "title": r["title"],
                           "status": r["status"], "type": r["dependency_type"]} for r in depends_on],
            "blocked_by": [{"task_id": str(r["task_id"]), "title": r["title"],
                           "status": r["status"], "type": r["dependency_type"]} for r in blocked_by]
        }

    async def is_task_blocked(self, task_id: UUID) -> bool:
        """Check if a task is blocked by uncompleted dependencies."""
        if not self.db_pool:
            return False
        
        count = await self.db_pool.fetchval(
            """SELECT COUNT(*) FROM task_dependencies d
               JOIN tasks t ON d.depends_on_task_id = t.id
               WHERE d.task_id = $1 AND t.status != 'completed'""",
            task_id
        )
        
        return count > 0

    async def get_dependency_chain(self, task_id: UUID, 
                                    direction: str = "upstream") -> List[Dict[str, Any]]:
        """Get the full dependency chain for a task."""
        if not self.db_pool:
            return []
        
        visited: Set[str] = set()
        chain = []
        
        async def traverse(current_id: str, depth: int = 0):
            if depth > 10 or current_id in visited:
                return
            visited.add(current_id)
            
            if direction == "upstream":
                rows = await self.db_pool.fetch(
                    """SELECT d.depends_on_task_id as related_id, t.title, t.status, t.priority
                       FROM task_dependencies d
                       JOIN tasks t ON d.depends_on_task_id = t.id
                       WHERE d.task_id = $1""",
                    UUID(current_id)
                )
            else:
                rows = await self.db_pool.fetch(
                    """SELECT d.task_id as related_id, t.title, t.status, t.priority
                       FROM task_dependencies d
                       JOIN tasks t ON d.task_id = t.id
                       WHERE d.depends_on_task_id = $1""",
                    UUID(current_id)
                )
            
            for row in rows:
                chain.append({
                    "task_id": str(row["related_id"]),
                    "title": row["title"],
                    "status": row["status"],
                    "priority": row["priority"],
                    "depth": depth
                })
                await traverse(str(row["related_id"]), depth + 1)
        
        await traverse(str(task_id))
        return chain

    async def _would_create_cycle(self, task_id: UUID, depends_on_task_id: UUID) -> bool:
        """Check if adding a dependency would create a circular reference."""
        chain = await self.get_dependency_chain(depends_on_task_id, direction="downstream")
        return any(item["task_id"] == str(task_id) for item in chain)

    async def _update_blocked_status(self, task_id: UUID):
        """Update task status based on dependency state."""
        if not self.db_pool:
            return
        
        is_blocked = await self.is_task_blocked(task_id)
        
        task = await self.db_pool.fetchrow("SELECT status FROM tasks WHERE id = $1", task_id)
        if task and task["status"] not in ("completed", "cancelled"):
            new_status = "blocked" if is_blocked else "todo"
            await self.db_pool.execute(
                "UPDATE tasks SET status = $1, updated_at = NOW() WHERE id = $2 AND status != $1",
                new_status, task_id
            )

    async def check_all_dependencies(self) -> List[Dict[str, Any]]:
        """Check all tasks for dependency issues."""
        if not self.db_pool:
            return []
        
        rows = await self.db_pool.fetch(
            """SELECT t.id, t.title, t.status, COUNT(d.depends_on_task_id) as blocked_count
               FROM tasks t
               LEFT JOIN task_dependencies d ON d.task_id = t.id
               LEFT JOIN tasks dep ON d.depends_on_task_id = dep.id AND dep.status != 'completed'
               WHERE t.status NOT IN ('completed', 'cancelled')
               GROUP BY t.id
               HAVING COUNT(d.depends_on_task_id) > 0"""
        )
        
        issues = []
        for r in rows:
            deps = await self.get_dependencies(r["id"])
            incomplete = [d for d in deps["depends_on"] if d["status"] != "completed"]
            if incomplete:
                issues.append({
                    "task_id": str(r["id"]),
                    "title": r["title"],
                    "status": r["status"],
                    "blocked_by_count": len(incomplete),
                    "blocked_by": incomplete
                })
        
        return issues
