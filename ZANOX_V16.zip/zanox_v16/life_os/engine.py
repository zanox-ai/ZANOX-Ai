"""Life OS Engine - Orchestrates all personal productivity subsystems."""
from datetime import datetime, date, timedelta
from typing import Dict, List, Optional, Any
import asyncpg

class LifeOSEngine:
    """The Life OS Engine is the central orchestrator that coordinates all ZANOX V16 subsystems
    to provide a unified personal operating system experience."""

    def __init__(self):
        self.db_pool = None
        self.redis = None
        self.subsystems = {}

    def initialize(self, db_pool, redis_client):
        self.db_pool = db_pool
        self.redis = redis_client

    async def register_subsystem(self, name: str, engine):
        """Register a subsystem for coordination."""
        self.subsystems[name] = engine

    async def get_daily_briefing(self) -> Dict[str, Any]:
        """Generate a comprehensive daily briefing."""
        today = date.today()
        briefing = {
            "date": today.isoformat(),
            "generated_at": datetime.utcnow().isoformat(),
            "greeting": self._generate_greeting(),
            "priorities": [],
            "schedule": [],
            "habits": [],
            "focus_recommendation": {},
            "insights": []
        }

        if self.db_pool:
            # Top 3 tasks for today
            tasks = await self.db_pool.fetch(
                "SELECT title, priority FROM tasks WHERE status NOT IN ('completed', 'cancelled') ORDER BY priority LIMIT 3"
            )
            briefing["priorities"] = [{"task": t["title"], "priority": t["priority"]} for t in tasks]

            # Today's events
            events = await self.db_pool.fetch(
                "SELECT title, start_time FROM calendar_events WHERE DATE(start_time) = CURRENT_DATE ORDER BY start_time"
            )
            briefing["schedule"] = [{"event": e["title"], "time": e["start_time"].strftime("%H:%M") if e["start_time"] else ""} for e in events]

            # Habits
            habits = await self.db_pool.fetch(
                "SELECT name FROM habits WHERE active = true ORDER BY name"
            )
            briefing["habits"] = [h["name"] for h in habits]

        return briefing

    async def get_weekly_review(self) -> Dict[str, Any]:
        """Generate weekly review."""
        week_start = date.today() - timedelta(days=date.today().weekday())
        return {
            "week_start": week_start.isoformat(),
            "generated_at": datetime.utcnow().isoformat(),
            "accomplishments": [],
            "challenges": [],
            "metrics": {},
            "recommendations": []
        }

    async def run_morning_routine(self) -> List[Dict[str, str]]:
        """Execute morning routine automation."""
        actions = []
        if self.db_pool:
            # Check overnight tasks
            overnight = await self.db_pool.fetch(
                "SELECT title FROM tasks WHERE status = 'completed' AND DATE(updated_at) = CURRENT_DATE - 1"
            )
            if overnight:
                actions.append({"type": "info", "message": f"{len(overnight)} tasks completed yesterday"})

            # Check today's deadlines
            deadlines = await self.db_pool.fetch(
                "SELECT title FROM tasks WHERE DATE(due_date) = CURRENT_DATE AND status NOT IN ('completed', 'cancelled')"
            )
            if deadlines:
                actions.append({"type": "urgent", "message": f"{len(deadlines)} tasks due today"})

        actions.append({"type": "habit", "message": "Time to track your morning habits"})
        return actions

    async def run_evening_routine(self) -> List[Dict[str, str]]:
        """Execute evening routine automation."""
        actions = [
            {"type": "review", "message": "Review today's accomplishments"},
            {"type": "plan", "message": "Plan tomorrow's priorities"},
            {"type": "habit", "message": "Log today's habits"}
        ]
        return actions

    def _generate_greeting(self) -> str:
        hour = datetime.utcnow().hour
        if 5 <= hour < 12:
            return "Good morning! Let's make today productive."
        elif 12 <= hour < 17:
            return "Good afternoon! Keep the momentum going."
        elif 17 <= hour < 22:
            return "Good evening! Time to review and plan."
        else:
            return "Rest well. Tomorrow is a new day."
