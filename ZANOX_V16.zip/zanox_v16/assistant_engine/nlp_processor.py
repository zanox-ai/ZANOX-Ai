"""
NLP Processor for the Personal Assistant Engine.
Handles natural language understanding, entity extraction, and response generation.
"""

import re
from datetime import datetime, date, time, timedelta
from typing import Dict, List, Optional, Any


class NLPProcessor:
    """Natural language processing for the personal assistant."""

    def __init__(self):
        self.date_patterns = [
            r'today',
            r'tomorrow',
            r'next\s+(monday|tuesday|wednesday|thursday|friday|saturday|sunday)',
            r'in\s+(\d+)\s+days?',
            r'on\s+(monday|tuesday|wednesday|thursday|friday|saturday|sunday)',
            r'\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}',
            r'\d{4}[\/\-]\d{1,2}[\/\-]\d{1,2}',
        ]
        self.time_patterns = [
            r'(\d{1,2}):(\d{2})\s*(am|pm)?',
            r'(\d{1,2})\s*(am|pm)',
            r'noon',
            r'midnight',
        ]
        self.priority_keywords = {
            "urgent": ["urgent", "asap", "immediately", "critical", "emergency"],
            "high": ["important", "high priority", "crucial", "essential"],
            "low": ["low priority", "whenever", "sometime", "eventually"],
        }

    async def extract_task_details(self, message: str, entities: Dict[str, Any]) -> Dict[str, Any]:
        """Extract task creation details from natural language."""
        title = self._extract_title(message)
        due_date = await self._extract_date(message)
        priority = self._extract_priority(message)
        tags = self._extract_tags(message)
        estimated_duration = self._extract_duration(message)
        
        return {
            "title": title,
            "description": message,
            "due_date": due_date,
            "priority": priority,
            "tags": tags,
            "estimated_duration_minutes": estimated_duration,
            **entities
        }

    async def extract_project_details(self, message: str, entities: Dict[str, Any]) -> Dict[str, Any]:
        """Extract project creation details from natural language."""
        name = self._extract_project_name(message)
        milestones = self._extract_milestones(message)
        target_date = await self._extract_date(message)
        
        return {
            "name": name,
            "description": message,
            "target_end_date": target_date,
            "milestones": milestones,
            **entities
        }

    async def extract_goal_details(self, message: str, entities: Dict[str, Any]) -> Dict[str, Any]:
        """Extract goal creation details from natural language."""
        title = self._extract_title(message, prefix_pattern=r'(?:set\s+goal\s+|goal\s+)')
        target_date = await self._extract_date(message)
        category = self._extract_category(message)
        
        key_results = []
        kr_matches = re.findall(r'key\s+result\s*:?\s*([^\n,]+)', message, re.IGNORECASE)
        for kr in kr_matches:
            key_results.append(kr.strip())
        
        return {
            "title": title,
            "description": message,
            "target_date": target_date,
            "category": category,
            "key_results": key_results or [f"Make progress on {title}"],
            **entities
        }

    async def extract_habit_details(self, message: str, entities: Dict[str, Any]) -> Dict[str, Any]:
        """Extract habit creation details from natural language."""
        name = self._extract_title(message, prefix_pattern=r'(?:create\s+habit\s+|habit\s+|track\s+)')
        
        frequency = "daily"
        if "weekly" in message.lower():
            frequency = "weekly"
        elif "monthly" in message.lower():
            frequency = "monthly"
        
        reminder_time = None
        time_match = re.search(r'at\s+(\d{1,2}):?(\d{2})?\s*(am|pm)?', message, re.IGNORECASE)
        if time_match:
            hour = int(time_match.group(1))
            minute = int(time_match.group(2) or 0)
            ampm = time_match.group(3)
            if ampm and ampm.lower() == "pm" and hour != 12:
                hour += 12
            if ampm and ampm.lower() == "am" and hour == 12:
                hour = 0
            reminder_time = time(hour, minute)
        
        return {
            "name": name,
            "description": message,
            "frequency": frequency,
            "reminder_time": reminder_time,
            **entities
        }

    async def extract_event_details(self, message: str, entities: Dict[str, Any]) -> Dict[str, Any]:
        """Extract event scheduling details from natural language."""
        title = self._extract_title(message, prefix_pattern=r'(?:schedule\s+|meeting\s+|call\s+)')
        start_time = await self._extract_datetime(message)
        
        if not start_time:
            start_time = datetime.utcnow() + timedelta(hours=1)
        
        duration = self._extract_duration(message) or 60
        end_time = start_time + timedelta(minutes=duration)
        
        location = None
        loc_match = re.search(r'(?:at|in|location)\s+([\w\s]+?)(?:\s|$|,|\.)', message, re.IGNORECASE)
        if loc_match:
            location = loc_match.group(1).strip()
        
        return {
            "title": title,
            "start_time": start_time,
            "end_time": end_time,
            "location": location,
            **entities
        }

    async def extract_note_details(self, message: str, entities: Dict[str, Any]) -> Dict[str, Any]:
        """Extract note creation details from natural language."""
        content = message
        title = None
        
        title_match = re.search(r'(?:note\s+(?:that\s+)?(?:about\s+)?)([^.\n]+)', message, re.IGNORECASE)
        if title_match:
            title = title_match.group(1).strip()
        
        tags = self._extract_tags(message)
        note_type = "quick"
        if "meeting" in message.lower():
            note_type = "meeting"
        elif "project" in message.lower():
            note_type = "project"
        elif "daily" in message.lower():
            note_type = "daily"
        
        return {
            "title": title,
            "content": content,
            "note_type": note_type,
            "tags": tags,
            **entities
        }

    async def extract_reminder_details(self, message: str, entities: Dict[str, Any]) -> Dict[str, Any]:
        """Extract reminder creation details from natural language."""
        reminder_text = message
        trigger_time = await self._extract_datetime(message)
        
        if not trigger_time:
            trigger_time = datetime.utcnow() + timedelta(hours=1)
        
        return {
            "title": reminder_text[:100],
            "message": reminder_text,
            "trigger_time": trigger_time,
            **entities
        }

    async def extract_task_filters(self, message: str, entities: Dict[str, Any]) -> Dict[str, Any]:
        """Extract task filtering criteria from natural language."""
        filters = {}
        
        if "today" in message.lower():
            filters["due_today"] = True
        if "this week" in message.lower():
            filters["due_this_week"] = True
        if "high priority" in message.lower() or "urgent" in message.lower():
            filters["priority"] = "high"
        if "overdue" in message.lower():
            filters["overdue"] = True
        if "completed" in message.lower() or "done" in message.lower():
            filters["status"] = "completed"
        else:
            filters["status"] = "active"
        
        return filters

    async def generate_response(self, message: str, recent_context: List[Dict], 
                                 user_context: Dict[str, Any]) -> str:
        """Generate a natural language response based on context."""
        msg_lower = message.lower()
        
        if any(kw in msg_lower for kw in ["hello", "hi", "hey"]):
            return self._generate_greeting(user_context)
        
        if any(kw in msg_lower for kw in ["thank", "thanks"]):
            return "You're welcome! I'm here to help you stay organized and productive."
        
        if any(kw in msg_lower for kw in ["how are you", "how's it going"]):
            return "I'm doing great and ready to help you be productive! What would you like to work on?"
        
        if any(kw in msg_lower for kw in ["busy", "overwhelmed", "stressed", "too much"]):
            return (
                "I understand feeling overwhelmed. Let's break things down:\n\n"
                "1. **Take a breath** - You can only do one thing at a time\n"
                "2. **Prioritize** - Ask me to 'prioritize my tasks'\n"
                "3. **Focus** - Try a 25-minute pomodoro session\n"
                "4. **Delegate** - What can wait until tomorrow?\n\n"
                "Would you like me to help prioritize your tasks or start a focus session?"
            )
        
        if any(kw in msg_lower for kw in ["good morning", "morning"]):
            return self._generate_morning_briefing(user_context)
        
        if any(kw in msg_lower for kw in ["good evening", "evening"]):
            return self._generate_evening_summary(user_context)
        
        return (
            "I understand. I'm here to help you manage tasks, schedule events, "
            "track goals, build habits, and stay focused.\n\n"
            "What would you like to do? Type 'help' for available commands."
        )

    def _generate_greeting(self, user_context: Dict[str, Any]) -> str:
        """Generate a personalized greeting."""
        hour = datetime.utcnow().hour
        if 5 <= hour < 12:
            time_greeting = "Good morning"
        elif 12 <= hour < 17:
            time_greeting = "Good afternoon"
        else:
            time_greeting = "Good evening"
        
        active_tasks = len(user_context.get("active_tasks", []))
        if active_tasks > 0:
            return f"{time_greeting}! You have {active_tasks} active tasks. Ready to be productive?"
        return f"{time_greeting}! Ready to plan a productive day?"

    def _generate_morning_briefing(self, user_context: Dict[str, Any]) -> str:
        """Generate a morning briefing."""
        tasks = user_context.get("active_tasks", [])
        events = user_context.get("today_events", [])
        habits = user_context.get("active_habits", [])
        
        response = "**Good morning! Here's your briefing:**\n\n"
        
        if events:
            response += f"**Today's Schedule:** {len(events)} events\n"
            for e in events[:3]:
                start = e.get("start_time", "")
                if isinstance(start, datetime):
                    start = start.strftime("%H:%M")
                response += f"  {start} - {e.get('title', '')}\n"
            response += "\n"
        
        if tasks:
            urgent = [t for t in tasks if t.get("priority") in ("urgent", "high")]
            response += f"**Priority Tasks:** {len(urgent)} urgent/high\n"
            for t in urgent[:3]:
                response += f"  {t.get('title', '')}\n"
            response += "\n"
        
        if habits:
            response += f"**Habits Today:** {len(habits)} to track\n"
        
        response += "\nLet's make today count! What would you like to focus on first?"
        return response

    def _generate_evening_summary(self, user_context: Dict[str, Any]) -> str:
        """Generate an evening summary."""
        tasks = user_context.get("active_tasks", [])
        completed = len([t for t in tasks if t.get("status") == "completed"])
        remaining = len([t for t in tasks if t.get("status") != "completed"])
        
        response = "**Good evening! Day's end summary:**\n\n"
        response += f"Tasks completed: {completed}\n"
        response += f"Remaining for tomorrow: {remaining}\n\n"
        
        if remaining > 0:
            response += "Would you like me to help you plan tomorrow's priorities?"
        else:
            response += "All caught up! Great job today."
        
        return response

    def _extract_title(self, message: str, prefix_pattern: str = "") -> str:
        """Extract a title from a message."""
        if prefix_pattern:
            match = re.search(prefix_pattern + r'([^,.\n]+)', message, re.IGNORECASE)
            if match:
                return match.group(1).strip()[:200]
        
        sentences = re.split(r'[.\n]', message)
        return sentences[0].strip()[:200] if sentences else message[:200]

    def _extract_project_name(self, message: str) -> str:
        """Extract a project name from a message."""
        match = re.search(r'(?:project\s+|create\s+project\s+)([^,.\n]+)', message, re.IGNORECASE)
        return match.group(1).strip()[:200] if match else message[:200]

    def _extract_milestones(self, message: str) -> List[Dict[str, str]]:
        """Extract milestone information from a message."""
        milestones = []
        matches = re.findall(r'milestone\s*:?\s*([^,.\n]+)', message, re.IGNORECASE)
        for m in matches:
            milestones.append({"name": m.strip(), "description": ""})
        return milestones

    def _extract_category(self, message: str) -> Optional[str]:
        """Extract a category from a message."""
        categories = ["health", "career", "finance", "learning", "relationships", "personal", "creative"]
        for cat in categories:
            if cat in message.lower():
                return cat
        return None

    async def _extract_date(self, message: str) -> Optional[datetime]:
        """Extract a date from natural language."""
        msg_lower = message.lower()
        
        if "today" in msg_lower:
            return datetime.utcnow()
        if "tomorrow" in msg_lower:
            return datetime.utcnow() + timedelta(days=1)
        
        days_match = re.search(r'in\s+(\d+)\s+days?', msg_lower)
        if days_match:
            return datetime.utcnow() + timedelta(days=int(days_match.group(1)))
        
        date_match = re.search(r'(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})', message)
        if date_match:
            month, day, year = int(date_match.group(1)), int(date_match.group(2)), date_match.group(3)
            year = int(year)
            if year < 100:
                year += 2000
            try:
                return datetime(year, month, day)
            except ValueError:
                pass
        
        return None

    async def _extract_datetime(self, message: str) -> Optional[datetime]:
        """Extract a datetime from natural language."""
        extracted_date = await self._extract_date(message)
        
        time_match = re.search(r'(\d{1,2}):(\d{2})\s*(am|pm)?', message, re.IGNORECASE)
        if time_match:
            hour = int(time_match.group(1))
            minute = int(time_match.group(2))
            ampm = time_match.group(3)
            if ampm and ampm.lower() == "pm" and hour != 12:
                hour += 12
            if ampm and ampm.lower() == "am" and hour == 12:
                hour = 0
            
            base_date = extracted_date or datetime.utcnow()
            return base_date.replace(hour=hour, minute=minute, second=0, microsecond=0)
        
        return extracted_date

    def _extract_priority(self, message: str) -> str:
        """Extract priority level from a message."""
        msg_lower = message.lower()
        for level, keywords in self.priority_keywords.items():
            for kw in keywords:
                if kw in msg_lower:
                    return level
        return "medium"

    def _extract_tags(self, message: str) -> List[str]:
        """Extract hashtags/tags from a message."""
        return re.findall(r'#(\w+)', message)

    def _extract_duration(self, message: str) -> Optional[int]:
        """Extract duration in minutes from a message."""
        hour_match = re.search(r'(\d+)\s*hours?', message, re.IGNORECASE)
        if hour_match:
            return int(hour_match.group(1)) * 60
        
        min_match = re.search(r'(\d+)\s*minutes?', message, re.IGNORECASE)
        if min_match:
            return int(min_match.group(1))
        
        return None
