"""
Action Executor for the Personal Assistant Engine.
Executes actions across all ZANOX V16 subsystems by calling the appropriate services.
"""

import json
import uuid
from datetime import datetime, date, timedelta
from typing import Dict, List, Optional, Any

import asyncpg
import redis.asyncio as redis


class ActionExecutor:
    """
    Executes actions by interfacing with all ZANOX V16 subsystem databases.
    Provides a unified interface for the assistant to perform operations.
    """

    def __init__(self):
        self.db_pool: Optional[asyncpg.Pool] = None
        self.redis: Optional[redis.Redis] = None

    def initialize(self, db_pool: asyncpg.Pool, redis_client: redis.Redis):
        """Initialize with database and cache connections."""
        self.db_pool = db_pool
        self.redis = redis_client

    async def create_task(self, task, task_id: str):
        """Create a task in the database."""
        if not self.db_pool:
            return
        
        due_date = task.due_date if task.due_date else None
        await self.db_pool.execute(
            """INSERT INTO tasks (id, title, description, priority, status, due_date, 
                estimated_duration_minutes, tags, project_id, goal_id, assigned_to, 
                parent_task_id, created_at, updated_at)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, NOW(), NOW())""",
            task_id, task.title, task.description, task.priority.value, 
            task.status.value, due_date, task.estimated_duration_minutes,
            json.dumps(task.tags), str(task.project_id) if task.project_id else None,
            str(task.goal_id) if task.goal_id else None,
            str(task.assigned_to) if task.assigned_to else None,
            str(task.parent_task_id) if task.parent_task_id else None
        )
        
        if self.redis:
            await self.redis.setex(f"task:{task_id}", 3600, json.dumps({
                "id": task_id, "title": task.title, "status": task.status.value,
                "priority": task.priority.value
            }))

    async def create_project(self, project, project_id: str):
        """Create a project in the database."""
        if not self.db_pool:
            return
        
        await self.db_pool.execute(
            """INSERT INTO projects (id, name, description, status, priority, 
                start_date, target_end_date, owner_id, tags, color, created_at, updated_at)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, NOW(), NOW())""",
            project_id, project.name, project.description,
            project.status.value, project.priority.value,
            project.start_date, project.target_end_date,
            str(project.owner_id) if project.owner_id else None,
            json.dumps(project.tags), project.color
        )

    async def create_goal(self, goal, goal_id: str):
        """Create a goal in the database."""
        if not self.db_pool:
            return
        
        await self.db_pool.execute(
            """INSERT INTO goals (id, title, description, status, priority, 
                category, target_date, parent_goal_id, owner_id, created_at, updated_at)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, NOW(), NOW())""",
            goal_id, goal.title, goal.description,
            goal.status.value, goal.priority.value, goal.category,
            goal.target_date,
            str(goal.parent_goal_id) if goal.parent_goal_id else None,
            str(goal.owner_id) if goal.owner_id else None
        )
        
        for kr in goal.key_results:
            kr_id = str(uuid.uuid4())
            await self.db_pool.execute(
                """INSERT INTO key_results (id, goal_id, description, target_value, unit, deadline)
                 VALUES ($1, $2, $3, $4, $5, $6)""",
                kr_id, goal_id, kr, 100.0, "%", goal.target_date
            )

    async def create_habit(self, habit, habit_id: str):
        """Create a habit in the database."""
        if not self.db_pool:
            return
        
        await self.db_pool.execute(
            """INSERT INTO habits (id, name, description, frequency, target_per_period, 
                color, icon, reminder_time, associated_goal_id, active, created_at)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, true, NOW())""",
            habit_id, habit.name, habit.description,
            habit.frequency.value, habit.target_per_period,
            habit.color, habit.icon, habit.reminder_time,
            str(habit.associated_goal_id) if habit.associated_goal_id else None
        )

    async def schedule_event(self, event, event_id: str):
        """Create a calendar event in the database."""
        if not self.db_pool:
            return
        
        await self.db_pool.execute(
            """INSERT INTO calendar_events (id, title, description, event_type, 
                start_time, end_time, timezone, location, attendees, 
                linked_task_id, color, created_at, updated_at)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, NOW(), NOW())""",
            event_id, event.title, event.description,
            event.event_type.value, event.start_time, event.end_time,
            event.timezone, event.location,
            json.dumps(event.attendees),
            str(event.linked_task_id) if event.linked_task_id else None,
            event.color
        )

    async def add_note(self, note, note_id: str):
        """Add a note to the database."""
        if not self.db_pool:
            return
        
        await self.db_pool.execute(
            """INSERT INTO notes (id, title, content, note_type, tags, 
                linked_task_id, linked_project_id, linked_goal_id, folder, created_at, updated_at)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, NOW(), NOW())""",
            note_id, note.title, note.content, note.note_type.value,
            json.dumps(note.tags),
            str(note.linked_task_id) if note.linked_task_id else None,
            str(note.linked_project_id) if note.linked_project_id else None,
            str(note.linked_goal_id) if note.linked_goal_id else None,
            note.folder
        )

    async def set_reminder(self, reminder, reminder_id: str):
        """Set a reminder in the database."""
        if not self.db_pool:
            return
        
        await self.db_pool.execute(
            """INSERT INTO reminders (id, title, message, trigger_time, 
                entity_type, entity_id, dismissed, created_at)
             VALUES ($1, $2, $3, $4, $5, $6, false, NOW())""",
            reminder_id, reminder.title, reminder.message,
            reminder.trigger_time, reminder.entity_type,
            str(reminder.entity_id) if reminder.entity_id else None
        )

    async def get_tasks(self, user_id: Optional[str], filters: Dict[str, Any]) -> List[Dict]:
        """Get tasks for a user with optional filters."""
        if not self.db_pool:
            return []
        
        query = "SELECT * FROM tasks WHERE 1=1"
        params = []
        
        if user_id:
            query += f" AND assigned_to = ${len(params) + 1}"
            params.append(user_id)
        
        if filters.get("status") == "active":
            query += " AND status NOT IN ('completed', 'cancelled')"
        elif filters.get("status"):
            query += f" AND status = ${len(params) + 1}"
            params.append(filters["status"])
        
        if filters.get("priority"):
            query += f" AND priority = ${len(params) + 1}"
            params.append(filters["priority"])
        
        if filters.get("due_today"):
            query += f" AND DATE(due_date) = CURRENT_DATE"
        
        if filters.get("overdue"):
            query += " AND due_date < NOW() AND status NOT IN ('completed', 'cancelled')"
        
        query += " ORDER BY priority, due_date LIMIT 50"
        
        rows = await self.db_pool.fetch(query, *params)
        return [dict(r) for r in rows]

    async def get_schedule(self, user_id: Optional[str], date_filter) -> List[Dict]:
        """Get schedule for a specific date."""
        if not self.db_pool:
            return []
        
        if isinstance(date_filter, str):
            if date_filter == "today":
                date_filter = date.today()
            elif date_filter == "tomorrow":
                date_filter = date.today() + timedelta(days=1)
        
        if isinstance(date_filter, datetime):
            date_filter = date_filter.date()
        
        rows = await self.db_pool.fetch(
            "SELECT * FROM calendar_events WHERE DATE(start_time) = $1 ORDER BY start_time",
            date_filter
        )
        return [dict(r) for r in rows]

    async def get_summary(self, user_id: Optional[str], period: str) -> Dict[str, Any]:
        """Get a summary for a given period."""
        if not self.db_pool:
            return {}
        
        if period in ("today", "daily"):
            start = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
            end = start + timedelta(days=1)
        elif period == "this_week":
            start = datetime.utcnow() - timedelta(days=datetime.utcnow().weekday())
            start = start.replace(hour=0, minute=0, second=0, microsecond=0)
            end = start + timedelta(days=7)
        elif period == "this_month":
            start = datetime.utcnow().replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            if start.month == 12:
                end = start.replace(year=start.year + 1, month=1)
            else:
                end = start.replace(month=start.month + 1)
        else:
            start = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
            end = start + timedelta(days=1)
        
        tasks_completed = await self.db_pool.fetchval(
            "SELECT COUNT(*) FROM tasks WHERE status = 'completed' AND updated_at >= $1 AND updated_at < $2",
            start, end
        ) or 0
        
        tasks_total = await self.db_pool.fetchval(
            "SELECT COUNT(*) FROM tasks WHERE created_at >= $1 AND created_at < $2",
            start, end
        ) or 0
        
        focus_minutes = await self.db_pool.fetchval(
            "SELECT COALESCE(SUM(actual_duration_minutes), 0) FROM focus_sessions WHERE started_at >= $1 AND started_at < $2",
            start, end
        ) or 0
        
        habits_completed = await self.db_pool.fetchval(
            "SELECT COUNT(*) FROM habit_logs WHERE completed_at >= $1 AND completed_at < $2",
            start, end
        ) or 0
        
        habits_total = await self.db_pool.fetchval(
            "SELECT COUNT(*) FROM habits WHERE active = true"
        ) or 0
        
        productivity_score = 0.0
        if tasks_total > 0:
            completion_rate = tasks_completed / tasks_total
            focus_score = min(focus_minutes / 240, 1.0)
            habit_score = min(habits_completed / max(habits_total * 7, 1), 1.0)
            productivity_score = (completion_rate * 0.4 + focus_score * 0.3 + habit_score * 0.3) * 100
        
        return {
            "tasks_completed": tasks_completed,
            "tasks_total": tasks_total,
            "focus_minutes": focus_minutes,
            "habits_completed": habits_completed,
            "habits_total": habits_total,
            "productivity_score": round(productivity_score, 1)
        }

    async def prioritize_tasks(self, user_id: Optional[str]) -> List[Dict]:
        """Get prioritized list of tasks using the prioritization engine."""
        if not self.db_pool:
            return []
        
        rows = await self.db_pool.fetch(
            """SELECT t.*, 
                CASE 
                    WHEN t.priority = 'urgent' THEN 1.0
                    WHEN t.priority = 'high' THEN 0.75
                    WHEN t.priority = 'medium' THEN 0.5
                    WHEN t.priority = 'low' THEN 0.25
                    ELSE 0.1
                END as priority_weight,
                CASE
                    WHEN t.due_date IS NULL THEN 0.3
                    WHEN t.due_date < NOW() + INTERVAL '24 hours' THEN 1.0
                    WHEN t.due_date < NOW() + INTERVAL '72 hours' THEN 0.7
                    WHEN t.due_date < NOW() + INTERVAL '7 days' THEN 0.5
                    ELSE 0.3
                END as deadline_weight,
                COALESCE(t.estimated_duration_minutes, 60) as effort
             FROM tasks t
             WHERE t.status NOT IN ('completed', 'cancelled')
             ORDER BY priority_weight * 0.4 + deadline_weight * 0.6 DESC, t.due_date ASC
             LIMIT 20"""
        )
        
        tasks = []
        for i, row in enumerate(rows):
            score = float(row["priority_weight"]) * 0.4 + float(row["deadline_weight"]) * 0.6
            tasks.append({
                "id": str(row["id"]),
                "title": row["title"],
                "priority": row["priority"],
                "due_date": row["due_date"].isoformat() if row["due_date"] else None,
                "priority_score": round(score, 2),
                "recommended_order": i + 1
            })
        
        return tasks

    async def start_focus_session(self, user_id: Optional[str], mode: str, 
                                   duration: int, session_id: str):
        """Start a focus session."""
        if not self.db_pool:
            return
        
        await self.db_pool.execute(
            """INSERT INTO focus_sessions (id, mode, started_at, planned_duration_minutes, user_id)
             VALUES ($1, $2, NOW(), $3, $4)""",
            session_id, mode, duration, user_id
        )
