"""
Context Manager for the Personal Assistant Engine.
Manages conversation context, user state, and cross-reference information
across all ZANOX V16 subsystems.
"""

import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any

import asyncpg
import redis.asyncio as redis


class ContextManager:
    """
    Manages contextual awareness for the personal assistant.
    Maintains user state, recent interactions, and cross-references
    across all productivity domains.
    """

    def __init__(self):
        self.db_pool: Optional[asyncpg.Pool] = None
        self.redis: Optional[redis.Redis] = None

    def initialize(self, db_pool: asyncpg.Pool, redis_client: redis.Redis):
        """Initialize with database and cache connections."""
        self.db_pool = db_pool
        self.redis = redis_client

    async def build_context(self, user_id: str, entities: Dict[str, Any]) -> Dict[str, Any]:
        """
        Build a comprehensive context object for the current interaction.
        This provides the assistant with relevant background information.
        """
        context = {
            "user_id": user_id,
            "timestamp": datetime.utcnow().isoformat(),
            "entities": entities,
            "user_preferences": await self._get_user_preferences(user_id),
            "recent_tasks": await self._get_recent_tasks(user_id),
            "upcoming_events": await self._get_upcoming_events(user_id),
            "active_goals": await self._get_active_goals(user_id),
            "today_habits": await self._get_today_habits(user_id),
            "active_focus": await self._get_active_focus_session(user_id),
            "recent_notes": await self._get_recent_notes(user_id),
            "pending_decisions": await self._get_pending_decisions(user_id),
            "productivity_trend": await self._get_productivity_trend(user_id),
        }
        
        # Cache context for quick retrieval
        if self.redis:
            await self.redis.setex(
                f"context:{user_id}",
                300,  # 5 minute TTL
                json.dumps(context, default=str)
            )
        
        return context

    async def _get_user_preferences(self, user_id: str) -> Dict[str, Any]:
        """Get user preferences from cache or database."""
        if self.redis:
            cached = await self.redis.get(f"preferences:{user_id}")
            if cached:
                return json.loads(cached)
        
        if self.db_pool:
            row = await self.db_pool.fetchrow(
                "SELECT * FROM user_preferences WHERE user_id = $1", user_id
            )
            if row:
                prefs = dict(row)
                if self.redis:
                    await self.redis.setex(f"preferences:{user_id}", 3600, json.dumps(prefs, default=str))
                return prefs
        
        return {
            "default_focus_duration": 25,
            "preferred_working_hours": {"start": 9, "end": 17},
            "timezone": "UTC",
            "notification_channels": ["in_app"],
            "theme": "light"
        }

    async def _get_recent_tasks(self, user_id: str, limit: int = 5) -> List[Dict]:
        """Get recently active tasks for context."""
        if not self.db_pool:
            return []
        
        rows = await self.db_pool.fetch(
            """SELECT id, title, status, priority, due_date 
               FROM tasks 
               WHERE assigned_to = $1 AND status NOT IN ('completed', 'cancelled')
               ORDER BY updated_at DESC LIMIT $2""",
            user_id, limit
        )
        return [dict(r) for r in rows]

    async def _get_upcoming_events(self, user_id: str, limit: int = 5) -> List[Dict]:
        """Get upcoming calendar events for context."""
        if not self.db_pool:
            return []
        
        rows = await self.db_pool.fetch(
            """SELECT id, title, start_time, end_time, event_type, location
               FROM calendar_events
               WHERE start_time > NOW() AND start_time < NOW() + INTERVAL '48 hours'
               ORDER BY start_time LIMIT $1""",
            limit
        )
        return [dict(r) for r in rows]

    async def _get_active_goals(self, user_id: str, limit: int = 5) -> List[Dict]:
        """Get active goals for context."""
        if not self.db_pool:
            return []
        
        rows = await self.db_pool.fetch(
            """SELECT id, title, progress_percentage, target_date, priority
               FROM goals
               WHERE status IN ('active', 'in_progress')
               ORDER BY priority, created_at LIMIT $1""",
            limit
        )
        return [dict(r) for r in rows]

    async def _get_today_habits(self, user_id: str) -> List[Dict]:
        """Get today's habit status for context."""
        if not self.db_pool:
            return []
        
        rows = await self.db_pool.fetch(
            """SELECT h.id, h.name, h.frequency, h.color,
                EXISTS(
                    SELECT 1 FROM habit_logs hl 
                    WHERE hl.habit_id = h.id 
                    AND DATE(hl.completed_at) = CURRENT_DATE
                ) as completed_today
               FROM habits h
               WHERE h.active = true
               ORDER BY h.name"""
        )
        return [dict(r) for r in rows]

    async def _get_active_focus_session(self, user_id: str) -> Optional[Dict]:
        """Get currently active focus session."""
        if not self.db_pool:
            return None
        
        row = await self.db_pool.fetchrow(
            """SELECT id, mode, started_at, planned_duration_minutes
               FROM focus_sessions
               WHERE ended_at IS NULL AND started_at > NOW() - INTERVAL '4 hours'
               ORDER BY started_at DESC LIMIT 1"""
        )
        return dict(row) if row else None

    async def _get_recent_notes(self, user_id: str, limit: int = 3) -> List[Dict]:
        """Get recent notes for context."""
        if not self.db_pool:
            return []
        
        rows = await self.db_pool.fetch(
            """SELECT id, title, content, note_type, created_at
               FROM notes
               ORDER BY created_at DESC LIMIT $1""",
            limit
        )
        return [dict(r) for r in rows]

    async def _get_pending_decisions(self, user_id: str, limit: int = 3) -> List[Dict]:
        """Get pending decisions for context."""
        if not self.db_pool:
            return []
        
        rows = await self.db_pool.fetch(
            """SELECT id, title, decision_type, created_at
               FROM decision_matrices
               WHERE final_decision IS NULL
               ORDER BY created_at DESC LIMIT $1""",
            limit
        )
        return [dict(r) for r in rows]

    async def _get_productivity_trend(self, user_id: str) -> Dict[str, Any]:
        """Get recent productivity trend for context."""
        if not self.db_pool:
            return {"trend": "stable", "score": 0}
        
        # Get last 7 days of task completion
        rows = await self.db_pool.fetch(
            """SELECT DATE(updated_at) as date, COUNT(*) as completed
               FROM tasks
               WHERE status = 'completed' 
               AND updated_at > NOW() - INTERVAL '7 days'
               GROUP BY DATE(updated_at)
               ORDER BY date"""
        )
        
        if len(rows) >= 3:
            recent = sum(r["completed"] for r in rows[-3:]) / 3
            previous = sum(r["completed"] for r in rows[:max(3, len(rows)-3)]) / max(len(rows)-3, 1)
            
            if recent > previous * 1.2:
                trend = "improving"
            elif recent < previous * 0.8:
                trend = "declining"
            else:
                trend = "stable"
            
            return {"trend": trend, "score": round(recent, 1)}
        
        return {"trend": "stable", "score": 0}

    async def update_context(self, user_id: str, key: str, value: Any):
        """Update a specific context value."""
        if self.redis:
            cache_key = f"context:{user_id}"
            cached = await self.redis.get(cache_key)
            if cached:
                context = json.loads(cached)
                context[key] = value
                context["updated_at"] = datetime.utcnow().isoformat()
                await self.redis.setex(cache_key, 300, json.dumps(context, default=str))

    async def clear_context(self, user_id: str):
        """Clear cached context for a user."""
        if self.redis:
            await self.redis.delete(f"context:{user_id}")

    async def get_conversation_history(self, user_id: str, limit: int = 20) -> List[Dict]:
        """Get recent conversation history for a user."""
        if not self.db_pool:
            return []
        
        rows = await self.db_pool.fetch(
            """SELECT message, response, intent, created_at
               FROM assistant_conversations
               WHERE user_id = $1
               ORDER BY created_at DESC LIMIT $2""",
            user_id, limit
        )
        return [dict(r) for r in reversed(rows)]

    async def persist_conversation(self, user_id: str, message: str, 
                                    response: str, intent: str, confidence: float):
        """Persist a conversation exchange to the database."""
        if self.db_pool:
            await self.db_pool.execute(
                """INSERT INTO assistant_conversations 
                   (user_id, message, response, intent, confidence, created_at)
                   VALUES ($1, $2, $3, $4, $5, NOW())""",
                user_id, message, response, intent, confidence
            )
