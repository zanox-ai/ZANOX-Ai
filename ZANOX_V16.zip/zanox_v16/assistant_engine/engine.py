"""
Personal Assistant Engine - Core AI Orchestration
Handles natural language processing, intent classification, context management,
and automated action execution across all ZANOX V16 subsystems.
"""

import json
import uuid
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field

import asyncpg
import redis.asyncio as redis
from kafka import KafkaProducer

from ..models import (
    AIAssistantRequest, AIAssistantResponse, TaskCreate, ProjectCreate,
    GoalCreate, HabitCreate, CalendarEventCreate, Note, Reminder,
    PriorityLevel
)
from .nlp_processor import NLPProcessor
from .intent_classifier import IntentClassifier
from .action_executor import ActionExecutor
from .context_manager import ContextManager


@dataclass
class ConversationSession:
    """Tracks a conversation session with the personal assistant."""
    session_id: str
    user_id: str
    messages: List[Dict[str, Any]] = field(default_factory=list)
    context: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.utcnow)
    last_active: datetime = field(default_factory=datetime.utcnow)
    active: bool = True


@dataclass
class ScheduledAction:
    """Represents an action scheduled by the assistant."""
    action_id: str
    action_type: str
    parameters: Dict[str, Any]
    scheduled_for: datetime
    recurring: bool = False
    recurrence_rule: Optional[str] = None
    status: str = "pending"
    created_at: datetime = field(default_factory=datetime.utcnow)


class PersonalAssistantEngine:
    """
    Core Personal Assistant Engine for ZANOX V16.
    Provides AI-powered task management, planning, and execution.
    """

    def __init__(self):
        self.db_pool: Optional[asyncpg.Pool] = None
        self.redis: Optional[redis.Redis] = None
        self.kafka: Optional[KafkaProducer] = None
        self.nlp = NLPProcessor()
        self.intent_classifier = IntentClassifier()
        self.action_executor = ActionExecutor()
        self.context_manager = ContextManager()
        self.sessions: Dict[str, ConversationSession] = {}
        self.scheduled_actions: Dict[str, ScheduledAction] = {}
        self._command_handlers: Dict[str, Callable] = {}
        self._setup_handlers()

    def _setup_handlers(self):
        """Register all command handlers."""
        self._command_handlers = {
            "create_task": self._handle_create_task,
            "create_project": self._handle_create_project,
            "create_goal": self._handle_create_goal,
            "create_habit": self._handle_create_habit,
            "schedule_event": self._handle_schedule_event,
            "add_note": self._handle_add_note,
            "set_reminder": self._handle_set_reminder,
            "get_tasks": self._handle_get_tasks,
            "get_schedule": self._handle_get_schedule,
            "get_summary": self._handle_get_summary,
            "prioritize_tasks": self._handle_prioritize_tasks,
            "focus_mode": self._handle_focus_mode,
            "help": self._handle_help,
            "general_chat": self._handle_general_chat,
        }

    async def initialize(self, db_pool: asyncpg.Pool, redis_client: redis.Redis):
        """Initialize the assistant engine with database and cache connections."""
        self.db_pool = db_pool
        self.redis = redis_client
        self.action_executor.initialize(db_pool, redis_client)
        self.context_manager.initialize(db_pool, redis_client)
        self.kafka = KafkaProducer(
            bootstrap_servers=["kafka:9092"],
            value_serializer=lambda v: json.dumps(v).encode("utf-8")
        )
        await self._load_scheduled_actions()

    async def _load_scheduled_actions(self):
        """Load pending scheduled actions from database."""
        if not self.db_pool:
            return
        rows = await self.db_pool.fetch(
            "SELECT * FROM assistant_scheduled_actions WHERE status = 'pending'"
        )
        for row in rows:
            action = ScheduledAction(
                action_id=row["action_id"],
                action_type=row["action_type"],
                parameters=json.loads(row["parameters"]),
                scheduled_for=row["scheduled_for"],
                recurring=row["recurring"],
                recurrence_rule=row["recurrence_rule"],
                status=row["status"],
                created_at=row["created_at"]
            )
            self.scheduled_actions[action.action_id] = action

    async def process_message(self, request: AIAssistantRequest) -> AIAssistantResponse:
        """
        Process a user message and return an AI response with actions.
        
        This is the main entry point for the personal assistant.
        """
        session = await self._get_or_create_session(request.session_id, request.context)
        session.messages.append({"role": "user", "content": request.message, "timestamp": datetime.utcnow().isoformat()})
        
        intent, entities, confidence = await self.intent_classifier.classify(request.message)
        context = await self.context_manager.build_context(session.user_id, entities)
        
        handler = self._command_handlers.get(intent, self._handle_general_chat)
        response_text, actions, context_updates = await handler(
            request.message, entities, context, session
        )
        
        response = AIAssistantResponse(
            response=response_text,
            actions=actions,
            suggested_tasks=context_updates.get("suggested_tasks", []),
            context_updates=context_updates
        )
        
        session.messages.append({
            "role": "assistant",
            "content": response_text,
            "timestamp": datetime.utcnow().isoformat()
        })
        session.last_active = datetime.utcnow()
        
        await self._persist_session(session)
        await self._publish_interaction(session.session_id, intent, confidence)
        
        return response

    async def _get_or_create_session(self, session_id: Optional[str], context: Optional[Dict]) -> ConversationSession:
        """Get existing session or create a new one."""
        if session_id and session_id in self.sessions:
            return self.sessions[session_id]
        
        sid = session_id or str(uuid.uuid4())
        user_id = context.get("user_id", "default") if context else "default"
        session = ConversationSession(session_id=sid, user_id=user_id)
        self.sessions[sid] = session
        return session

    async def _persist_session(self, session: ConversationSession):
        """Persist session to Redis."""
        if self.redis:
            await self.redis.setex(
                f"session:{session.session_id}",
                timedelta(hours=24),
                json.dumps({
                    "session_id": session.session_id,
                    "user_id": session.user_id,
                    "messages": session.messages[-50:],
                    "context": session.context,
                    "last_active": session.last_active.isoformat()
                })
            )

    async def _publish_interaction(self, session_id: str, intent: str, confidence: float):
        """Publish interaction event to Kafka."""
        if self.kafka:
            self.kafka.send("zanox.v16.assistant.interactions", {
                "session_id": session_id,
                "intent": intent,
                "confidence": confidence,
                "timestamp": datetime.utcnow().isoformat()
            })

    async def _handle_create_task(self, message: str, entities: Dict, context: Dict, session: ConversationSession):
        """Handle task creation requests."""
        task_data = await self.nlp.extract_task_details(message, entities)
        task = TaskCreate(**task_data)
        
        task_id = str(uuid.uuid4())
        await self.action_executor.create_task(task, task_id)
        
        response = f"Created task: '{task.title}'"
        if task.due_date:
            response += f"\nDue: {task.due_date}"
        if task.priority != PriorityLevel.MEDIUM:
            response += f"\nPriority: {task.priority.value}"
        
        actions = [{"type": "create_task", "task_id": task_id, "details": task_data}]
        return response, actions, {"suggested_tasks": []}

    async def _handle_create_project(self, message: str, entities: Dict, context: Dict, session: ConversationSession):
        """Handle project creation requests."""
        project_data = await self.nlp.extract_project_details(message, entities)
        project = ProjectCreate(**project_data)
        
        project_id = str(uuid.uuid4())
        await self.action_executor.create_project(project, project_id)
        
        milestones = []
        if project_data.get("milestones"):
            for ms in project_data["milestones"]:
                milestones.append(ms)
        
        response = f"Created project: '{project.name}'\n"
        if milestones:
            response += f"With {len(milestones)} milestones planned."
        
        actions = [{"type": "create_project", "project_id": project_id, "details": project_data}]
        return response, actions, {}

    async def _handle_create_goal(self, message: str, entities: Dict, context: Dict, session: ConversationSession):
        """Handle goal creation requests."""
        goal_data = await self.nlp.extract_goal_details(message, entities)
        goal = GoalCreate(**goal_data)
        
        goal_id = str(uuid.uuid4())
        await self.action_executor.create_goal(goal, goal_id)
        
        response = f"Set goal: '{goal.title}'"
        if goal.target_date:
            response += f"\nTarget date: {goal.target_date}"
        
        actions = [{"type": "create_goal", "goal_id": goal_id, "details": goal_data}]
        return response, actions, {}

    async def _handle_create_habit(self, message: str, entities: Dict, context: Dict, session: ConversationSession):
        """Handle habit creation requests."""
        habit_data = await self.nlp.extract_habit_details(message, entities)
        habit = HabitCreate(**habit_data)
        
        habit_id = str(uuid.uuid4())
        await self.action_executor.create_habit(habit, habit_id)
        
        response = f"Created habit: '{habit.name}'\n"
        response += f"Frequency: {habit.frequency.value}"
        if habit.reminder_time:
            response += f"\nReminder: {habit.reminder_time}"
        
        actions = [{"type": "create_habit", "habit_id": habit_id, "details": habit_data}]
        return response, actions, {}

    async def _handle_schedule_event(self, message: str, entities: Dict, context: Dict, session: ConversationSession):
        """Handle event scheduling requests."""
        event_data = await self.nlp.extract_event_details(message, entities)
        event = CalendarEventCreate(**event_data)
        
        event_id = str(uuid.uuid4())
        await self.action_executor.schedule_event(event, event_id)
        
        response = f"Scheduled: '{event.title}'"
        response += f"\nWhen: {event.start_time}"
        if event.location:
            response += f"\nWhere: {event.location}"
        
        actions = [{"type": "schedule_event", "event_id": event_id, "details": event_data}]
        return response, actions, {}

    async def _handle_add_note(self, message: str, entities: Dict, context: Dict, session: ConversationSession):
        """Handle note creation requests."""
        note_data = await self.nlp.extract_note_details(message, entities)
        note = Note(**note_data)
        
        note_id = str(uuid.uuid4())
        await self.action_executor.add_note(note, note_id)
        
        response = f"Note saved: '{note.title or note.content[:50]}...'"
        actions = [{"type": "add_note", "note_id": note_id, "details": note_data}]
        return response, actions, {}

    async def _handle_set_reminder(self, message: str, entities: Dict, context: Dict, session: ConversationSession):
        """Handle reminder creation requests."""
        reminder_data = await self.nlp.extract_reminder_details(message, entities)
        reminder = Reminder(**reminder_data)
        
        reminder_id = str(uuid.uuid4())
        await self.action_executor.set_reminder(reminder, reminder_id)
        
        response = f"Reminder set: '{reminder.title}' at {reminder.trigger_time}"
        actions = [{"type": "set_reminder", "reminder_id": reminder_id, "details": reminder_data}]
        return response, actions, {}

    async def _handle_get_tasks(self, message: str, entities: Dict, context: Dict, session: ConversationSession):
        """Handle task listing requests."""
        filters = await self.nlp.extract_task_filters(message, entities)
        tasks = await self.action_executor.get_tasks(context.get("user_id"), filters)
        
        if tasks:
            response = f"Found {len(tasks)} tasks:\n"
            for i, t in enumerate(tasks[:10], 1):
                status_icon = "x" if t["status"] == "completed" else " "
                response += f"\n[{status_icon}] {i}. {t['title']} ({t['priority']})"
        else:
            response = "No tasks found. You're all clear!"
        
        return response, [{"type": "list_tasks", "count": len(tasks)}], {}

    async def _handle_get_schedule(self, message: str, entities: Dict, context: Dict, session: ConversationSession):
        """Handle schedule viewing requests."""
        date_filter = entities.get("date", datetime.utcnow())
        events = await self.action_executor.get_schedule(context.get("user_id"), date_filter)
        
        if events:
            response = f"Schedule for {date_filter.strftime('%A, %B %d')}:\n"
            for e in events:
                start = e["start_time"].strftime("%H:%M") if isinstance(e["start_time"], datetime) else e["start_time"]
                response += f"\n{start} - {e['title']}"
        else:
            response = "Nothing scheduled. It's a free day!"
        
        return response, [{"type": "get_schedule", "count": len(events)}], {}

    async def _handle_get_summary(self, message: str, entities: Dict, context: Dict, session: ConversationSession):
        """Handle daily/weekly summary requests."""
        period = entities.get("period", "today")
        summary = await self.action_executor.get_summary(context.get("user_id"), period)
        
        response = f"**{period.title()} Summary**\n\n"
        response += f"Tasks: {summary.get('tasks_completed', 0)}/{summary.get('tasks_total', 0)} completed\n"
        response += f"Focus time: {summary.get('focus_minutes', 0)} minutes\n"
        response += f"Habits: {summary.get('habits_completed', 0)} completed\n"
        response += f"Productivity score: {summary.get('productivity_score', 0):.0f}/100"
        
        return response, [{"type": "get_summary", "period": period}], {}

    async def _handle_prioritize_tasks(self, message: str, entities: Dict, context: Dict, session: ConversationSession):
        """Handle task prioritization requests."""
        prioritized = await self.action_executor.prioritize_tasks(context.get("user_id"))
        
        if prioritized:
            response = "Here's your prioritized task list:\n\n**Do First (Urgent + Important):**\n"
            urgent = [t for t in prioritized if t["priority_score"] > 0.8]
            important = [t for t in prioritized if 0.5 < t["priority_score"] <= 0.8]
            later = [t for t in prioritized if t["priority_score"] <= 0.5]
            
            for t in urgent[:3]:
                response += f"  {t['title']}\n"
            
            if important:
                response += "\n**Schedule (Important):**\n"
                for t in important[:3]:
                    response += f"  {t['title']}\n"
            
            if later:
                response += "\n**Delegate/Defer:**\n"
                for t in later[:3]:
                    response += f"  {t['title']}\n"
        else:
            response = "No pending tasks to prioritize!"
        
        return response, [{"type": "prioritize_tasks", "count": len(prioritized)}], {}

    async def _handle_focus_mode(self, message: str, entities: Dict, context: Dict, session: ConversationSession):
        """Handle focus mode activation requests."""
        mode = entities.get("focus_mode", "deep_work")
        duration = entities.get("duration_minutes", 90)
        
        session_id = str(uuid.uuid4())
        await self.action_executor.start_focus_session(context.get("user_id"), mode, duration, session_id)
        
        response = f"Focus mode activated: {mode}\n"
        response += f"Duration: {duration} minutes\n\n"
        response += "I'm blocking distractions. You've got this!"
        
        actions = [{"type": "focus_mode", "session_id": session_id, "mode": mode, "duration": duration}]
        return response, actions, {}

    async def _handle_help(self, message: str, entities: Dict, context: Dict, session: ConversationSession):
        """Handle help requests."""
        response = """**ZANOX Personal Assistant - Available Commands:**

**Tasks:**
- "Create task [title] due [date] priority [level]"
- "What are my tasks?"
- "Prioritize my tasks"

**Projects:**
- "Create project [name] with milestones [list]"
- "Show project [name] status"

**Goals:**
- "Set goal [title] by [date]"
- "Track goal [title]"

**Habits:**
- "Create habit [name] daily/weekly"
- "Log habit [name]"

**Schedule:**
- "Schedule [event] on [date] at [time]"
- "What's my schedule today?"

**Focus:**
- "Start focus mode for [X] minutes"
- "Start pomodoro"

**Notes:**
- "Add note [content]"
- "Create note about [topic]"

**Reminders:**
- "Remind me to [task] at [time]"

Just chat naturally - I understand context!"""
        
        return response, [{"type": "help"}], {}

    async def _handle_general_chat(self, message: str, entities: Dict, context: Dict, session: ConversationSession):
        """Handle general conversation with contextual awareness."""
        recent_context = session.messages[-6:] if len(session.messages) > 1 else []
        
        response = await self.nlp.generate_response(message, recent_context, context)
        
        suggested_actions = []
        if any(kw in message.lower() for kw in ["busy", "overwhelmed", "stressed"]):
            suggested_actions.append({"type": "suggest_focus_mode", "duration": 25})
        if any(kw in message.lower() for kw in ["deadline", "due", "forget"]):
            suggested_actions.append({"type": "suggest_create_task"})
        if any(kw in message.lower() for kw in ["meeting", "call", "appointment"]):
            suggested_actions.append({"type": "suggest_schedule_event"})
        
        return response, suggested_actions, {}

    async def schedule_action(self, action_type: str, parameters: Dict[str, Any],
                             scheduled_for: datetime, recurring: bool = False,
                             recurrence_rule: Optional[str] = None) -> str:
        """Schedule a future action."""
        action_id = str(uuid.uuid4())
        action = ScheduledAction(
            action_id=action_id,
            action_type=action_type,
            parameters=parameters,
            scheduled_for=scheduled_for,
            recurring=recurring,
            recurrence_rule=recurrence_rule
        )
        self.scheduled_actions[action_id] = action
        
        if self.db_pool:
            await self.db_pool.execute(
                """INSERT INTO assistant_scheduled_actions 
                   (action_id, action_type, parameters, scheduled_for, recurring, recurrence_rule, status)
                   VALUES ($1, $2, $3, $4, $5, $6, 'pending')""",
                action_id, action_type, json.dumps(parameters), scheduled_for, recurring, recurrence_rule
            )
        
        if self.redis:
            await self.redis.setex(
                f"scheduled_action:{action_id}",
                int((scheduled_for - datetime.utcnow()).total_seconds()),
                json.dumps({"action_id": action_id, "type": action_type})
            )
        
        return action_id

    async def cancel_scheduled_action(self, action_id: str) -> bool:
        """Cancel a scheduled action."""
        if action_id in self.scheduled_actions:
            self.scheduled_actions[action_id].status = "cancelled"
            if self.db_pool:
                await self.db_pool.execute(
                    "UPDATE assistant_scheduled_actions SET status = 'cancelled' WHERE action_id = $1",
                    action_id
                )
            if self.redis:
                await self.redis.delete(f"scheduled_action:{action_id}")
            return True
        return False

    async def process_scheduled_actions(self):
        """Process all pending scheduled actions that are due."""
        now = datetime.utcnow()
        due_actions = [
            a for a in self.scheduled_actions.values()
            if a.status == "pending" and a.scheduled_for <= now
        ]
        
        for action in due_actions:
            handler = self._command_handlers.get(action.action_type)
            if handler:
                try:
                    await handler("", action.parameters, {}, ConversationSession(
                        session_id="scheduled", user_id="system"
                    ))
                    action.status = "completed"
                    
                    if action.recurring and action.recurrence_rule:
                        next_time = self._calculate_next_occurrence(
                            action.scheduled_for, action.recurrence_rule
                        )
                        await self.schedule_action(
                            action.action_type, action.parameters,
                            next_time, True, action.recurrence_rule
                        )
                except Exception as e:
                    action.status = "failed"
                    if self.kafka:
                        self.kafka.send("zanox.v16.assistant.errors", {
                            "action_id": action.action_id,
                            "error": str(e),
                            "timestamp": datetime.utcnow().isoformat()
                        })
            
            if self.db_pool:
                await self.db_pool.execute(
                    "UPDATE assistant_scheduled_actions SET status = $1 WHERE action_id = $2",
                    action.status, action.action_id
                )

    def _calculate_next_occurrence(self, current: datetime, rule: str) -> datetime:
        """Calculate the next occurrence of a recurring action."""
        if rule == "daily":
            return current + timedelta(days=1)
        elif rule == "weekly":
            return current + timedelta(weeks=1)
        elif rule == "monthly":
            if current.month == 12:
                return current.replace(year=current.year + 1, month=1)
            return current.replace(month=current.month + 1)
        return current + timedelta(days=1)

    async def get_user_context(self, user_id: str) -> Dict[str, Any]:
        """Get full context for a user including all active items."""
        context = {
            "user_id": user_id,
            "timestamp": datetime.utcnow().isoformat(),
            "active_tasks": [],
            "today_events": [],
            "active_habits": [],
            "active_goals": [],
            "active_projects": [],
            "recent_focus_sessions": [],
            "notifications": []
        }
        
        if self.db_pool:
            tasks = await self.db_pool.fetch(
                "SELECT * FROM tasks WHERE assigned_to = $1 AND status NOT IN ('completed', 'cancelled') ORDER BY priority, due_date LIMIT 10",
                user_id
            )
            context["active_tasks"] = [dict(t) for t in tasks]
            
            today = datetime.utcnow().date()
            events = await self.db_pool.fetch(
                "SELECT * FROM calendar_events WHERE DATE(start_time) = $1 ORDER BY start_time",
                today
            )
            context["today_events"] = [dict(e) for e in events]
            
            habits = await self.db_pool.fetch(
                "SELECT * FROM habits WHERE active = true ORDER BY name"
            )
            context["active_habits"] = [dict(h) for h in habits]
            
            goals = await self.db_pool.fetch(
                "SELECT * FROM goals WHERE status IN ('active', 'in_progress') ORDER BY priority"
            )
            context["active_goals"] = [dict(g) for g in goals]
        
        return context
