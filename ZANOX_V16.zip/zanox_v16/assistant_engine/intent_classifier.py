"""
Intent Classifier for the Personal Assistant Engine.
Classifies user messages into actionable intents using keyword matching
and contextual analysis.
"""

import re
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass


@dataclass
class IntentPattern:
    intent: str
    patterns: List[str]
    weight: float = 1.0


class IntentClassifier:
    """
    Intent classifier for understanding user commands.
    Maps natural language to actionable intents.
    """

    def __init__(self):
        self.intent_patterns: List[IntentPattern] = [
            # Task management intents
            IntentPattern("create_task", [
                r"create\s+task",
                r"add\s+task",
                r"new\s+task",
                r"todo\s*:",
                r"to[\s\-]?do\s*:",
                r"remind\s+me\s+to",
                r"i\s+need\s+to",
                r"i\s+have\s+to",
                r"i\s+should",
                r"(?:don't|dont)\s+forget\s+to",
                r"make\s+sure\s+to",
            ], weight=1.0),
            
            IntentPattern("create_project", [
                r"create\s+project",
                r"new\s+project",
                r"start\s+project",
                r"set\s+up\s+project",
                r"project\s*:",
                r"initiate\s+project",
            ], weight=1.0),
            
            IntentPattern("create_goal", [
                r"set\s+goal",
                r"create\s+goal",
                r"new\s+goal",
                r"goal\s*:",
                r"i\s+want\s+to\s+(?:achieve|reach|accomplish)",
                r"my\s+goal\s+is",
                r"okr\s*:",
            ], weight=1.0),
            
            IntentPattern("create_habit", [
                r"create\s+habit",
                r"new\s+habit",
                r"track\s+habit",
                r"habit\s*:",
                r"i\s+want\s+to\s+(?:start|build)\s+(?:a\s+)?habit",
                r"daily\s+(\w+)",
            ], weight=1.0),
            
            IntentPattern("schedule_event", [
                r"schedule\s+(?:a\s+)?(?:meeting|call|event|appointment)",
                r"book\s+(?:a\s+)?(?:meeting|call|slot)",
                r"set\s+up\s+(?:a\s+)?(?:meeting|call)",
                r"(?:meeting|call)\s+(?:with|at)",
                r"calendar\s*:",
                r"add\s+to\s+calendar",
            ], weight=1.0),
            
            IntentPattern("add_note", [
                r"add\s+note",
                r"create\s+note",
                r"note\s*:",
                r"write\s+down",
                r"jot\s+down",
                r"remember\s+that",
                r"note\s+that",
            ], weight=1.0),
            
            IntentPattern("set_reminder", [
                r"remind\s+me",
                r"set\s+(?:a\s+)?reminder",
                r"reminder\s*:",
                r"ping\s+me",
                r"notify\s+me",
            ], weight=1.0),
            
            IntentPattern("get_tasks", [
                r"(?:what|show)\s+(?:are\s+)?my\s+tasks",
                r"(?:list|show)\s+tasks",
                r"my\s+to[\s\-]?do\s+list",
                r"what\s+do\s+i\s+need\s+to\s+do",
                r"pending\s+tasks",
                r"open\s+tasks",
            ], weight=1.0),
            
            IntentPattern("get_schedule", [
                r"what'?s\s+(?:my\s+)?schedule",
                r"(?:my\s+)?calendar\s+(?:for\s+)?(?:today|tomorrow|this\s+week)",
                r"what\s+do\s+i\s+have\s+(?:today|tomorrow)",
                r"show\s+(?:my\s+)?calendar",
                r"upcoming\s+events",
            ], weight=1.0),
            
            IntentPattern("get_summary", [
                r"(?:daily|weekly)\s+summary",
                r"summary\s+(?:of\s+)?(?:my\s+)?(?:day|week)",
                r"how\s+did\s+i\s+do",
                r"my\s+progress",
                r"productivity\s+report",
                r"what\s+did\s+i\s+accomplish",
            ], weight=1.0),
            
            IntentPattern("prioritize_tasks", [
                r"prioritize\s+(?:my\s+)?tasks",
                r"what\s+should\s+i\s+do\s+first",
                r"(?:most\s+)?important\s+tasks",
                r"what\s+to\s+focus\s+on",
                r"help\s+me\s+prioritize",
                r"(?:urgent|priority)\s+tasks",
            ], weight=1.0),
            
            IntentPattern("focus_mode", [
                r"start\s+focus\s+(?:mode|session)",
                r"focus\s+(?:time|mode|session)",
                r"deep\s+work",
                r"pomodoro",
                r"concentration\s+mode",
                r"distraction[\s\-]?free\s+mode",
                r"start\s+(?:a\s+)?timer",
            ], weight=1.0),
            
            IntentPattern("help", [
                r"^(?:help|commands|what\s+can\s+you\s+do)",
                r"show\s+(?:me\s+)?(?:the\s+)?(?:available\s+)?commands",
                r"how\s+do\s+i\s+use",
                r"instructions",
                r"guide",
                r"\?\s*$",
            ], weight=1.0),
        ]
        
        self.entity_patterns = {
            "date": [
                r"today", r"tomorrow", r"next\s+\w+", r"\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}",
                r"\w+\s+\d{1,2}(?:st|nd|rd|th)?",
            ],
            "time": [
                r"\d{1,2}:\d{2}\s*(?:am|pm)?", r"\d{1,2}\s*(?:am|pm)", r"noon", r"midnight",
            ],
            "priority": [
                r"(?:high|low|medium|urgent)\s+priority",
                r"(?:top|low)\s+priority",
                r"asap",
                r"urgent",
            ],
            "person": [
                r"(?:with|to|from)\s+([A-Z][a-z]+\s+[A-Z][a-z]+)",
                r"@(\w+)",
            ],
            "duration": [
                r"(\d+)\s*(?:min|minutes?|hrs?|hours?)",
                r"half\s+an?\s+hour",
                r"an?\s+hour",
            ],
        }

    async def classify(self, message: str) -> Tuple[str, Dict[str, Any], float]:
        """
        Classify a user message into an intent.
        
        Returns:
            Tuple of (intent_name, extracted_entities, confidence_score)
        """
        scores: Dict[str, float] = {}
        
        for intent_pattern in self.intent_patterns:
            score = self._calculate_intent_score(message, intent_pattern)
            if score > 0:
                scores[intent_pattern.intent] = scores.get(intent_pattern.intent, 0) + score
        
        if not scores:
            return "general_chat", {}, 0.5
        
        best_intent = max(scores, key=scores.get)
        confidence = min(scores[best_intent] / 2.0, 1.0)
        
        entities = self._extract_entities(message)
        
        return best_intent, entities, confidence

    def _calculate_intent_score(self, message: str, intent_pattern: IntentPattern) -> float:
        """Calculate the match score for an intent pattern."""
        msg_lower = message.lower()
        score = 0.0
        
        for pattern in intent_pattern.patterns:
            if re.search(pattern, msg_lower):
                score += intent_pattern.weight
        
        return score

    def _extract_entities(self, message: str) -> Dict[str, Any]:
        """Extract relevant entities from the message."""
        entities = {}
        msg_lower = message.lower()
        
        # Extract date references
        if "today" in msg_lower:
            entities["date"] = "today"
        elif "tomorrow" in msg_lower:
            entities["date"] = "tomorrow"
        elif "next week" in msg_lower:
            entities["date"] = "next_week"
        
        # Extract priority
        if "urgent" in msg_lower or "asap" in msg_lower:
            entities["priority"] = "urgent"
        elif "high priority" in msg_lower:
            entities["priority"] = "high"
        elif "low priority" in msg_lower:
            entities["priority"] = "low"
        
        # Extract duration for focus mode
        duration_match = re.search(r'(\d+)\s*(?:min|minutes?)', message, re.IGNORECASE)
        if duration_match:
            entities["duration_minutes"] = int(duration_match.group(1))
        
        # Extract focus mode type
        if "pomodoro" in msg_lower:
            entities["focus_mode"] = "pomodoro"
        elif "deep work" in msg_lower:
            entities["focus_mode"] = "deep_work"
        
        # Extract task/project references
        task_match = re.search(r'(?:task|todo)\s+(?:named?\s+)?["\']?([^"\',.]+)["\']?', message, re.IGNORECASE)
        if task_match:
            entities["task_title"] = task_match.group(1).strip()
        
        return entities

    def add_intent_pattern(self, intent: str, patterns: List[str], weight: float = 1.0):
        """Add a new intent pattern dynamically."""
        self.intent_patterns.append(IntentPattern(intent, patterns, weight))

    def get_available_intents(self) -> List[str]:
        """Get list of all available intents."""
        return list(set(p.intent for p in self.intent_patterns))
