"""
FastAPI Router for the Personal Assistant Engine.
Exposes REST API endpoints and WebSocket for real-time assistant communication.
"""

import json
from datetime import datetime
from typing import Optional
from uuid import UUID

from fastapi import APIRouter, WebSocket, WebSocketDisconnect, HTTPException, Depends, Query
from pydantic import BaseModel, Field

from ..models import AIAssistantRequest, AIAssistantResponse, APIResponse
from .engine import PersonalAssistantEngine

router = APIRouter()

# Will be set during app initialization
_engine: Optional[PersonalAssistantEngine] = None


def set_engine(engine: PersonalAssistantEngine):
    """Set the assistant engine instance."""
    global _engine
    _engine = engine


class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=4000)
    session_id: Optional[str] = None
    context: Optional[dict] = None


class ScheduleActionRequest(BaseModel):
    action_type: str
    parameters: dict = Field(default_factory=dict)
    scheduled_for: datetime
    recurring: bool = False
    recurrence_rule: Optional[str] = None


@router.post("/chat", response_model=APIResponse)
async def chat(request: ChatRequest):
    """Send a message to the personal assistant and get a response."""
    if not _engine:
        raise HTTPException(status_code=503, detail="Assistant engine not initialized")
    
    try:
        ai_request = AIAssistantRequest(
            message=request.message,
            session_id=request.session_id,
            context=request.context
        )
        response = await _engine.process_message(ai_request)
        return APIResponse(success=True, data=response.model_dump())
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket endpoint for real-time assistant communication."""
    if not _engine:
        await websocket.close(code=1011, reason="Engine not initialized")
        return
    
    await websocket.accept()
    session_id = None
    
    try:
        while True:
            data = await websocket.receive_text()
            try:
                payload = json.loads(data)
                message = payload.get("message", "")
                session_id = payload.get("session_id", session_id)
                context = payload.get("context", {})
                
                ai_request = AIAssistantRequest(
                    message=message,
                    session_id=session_id,
                    context=context
                )
                response = await _engine.process_message(ai_request)
                
                await websocket.send_json({
                    "type": "response",
                    "data": response.model_dump(),
                    "session_id": session_id,
                    "timestamp": datetime.utcnow().isoformat()
                })
                
            except json.JSONDecodeError:
                await websocket.send_json({
                    "type": "error",
                    "message": "Invalid JSON payload"
                })
            except Exception as e:
                await websocket.send_json({
                    "type": "error",
                    "message": str(e)
                })
                
    except WebSocketDisconnect:
        pass


@router.post("/schedule-action", response_model=APIResponse)
async def schedule_action(request: ScheduleActionRequest):
    """Schedule a future action."""
    if not _engine:
        raise HTTPException(status_code=503, detail="Assistant engine not initialized")
    
    action_id = await _engine.schedule_action(
        action_type=request.action_type,
        parameters=request.parameters,
        scheduled_for=request.scheduled_for,
        recurring=request.recurring,
        recurrence_rule=request.recurrence_rule
    )
    
    return APIResponse(
        success=True,
        message="Action scheduled successfully",
        data={"action_id": action_id, "scheduled_for": request.scheduled_for.isoformat()}
    )


@router.delete("/schedule-action/{action_id}", response_model=APIResponse)
async def cancel_scheduled_action(action_id: str):
    """Cancel a scheduled action."""
    if not _engine:
        raise HTTPException(status_code=503, detail="Assistant engine not initialized")
    
    success = await _engine.cancel_scheduled_action(action_id)
    if not success:
        raise HTTPException(status_code=404, detail="Scheduled action not found")
    
    return APIResponse(success=True, message="Action cancelled successfully")


@router.get("/context/{user_id}", response_model=APIResponse)
async def get_user_context(user_id: str):
    """Get the full context for a user."""
    if not _engine:
        raise HTTPException(status_code=503, detail="Assistant engine not initialized")
    
    context = await _engine.get_user_context(user_id)
    return APIResponse(success=True, data=context)


@router.get("/intents", response_model=APIResponse)
async def get_available_intents():
    """Get list of available intents the assistant can handle."""
    if not _engine:
        raise HTTPException(status_code=503, detail="Assistant engine not initialized")
    
    intents = _engine.intent_classifier.get_available_intents()
    return APIResponse(success=True, data={"intents": intents})


@router.get("/health")
async def health_check():
    """Health check endpoint for the assistant engine."""
    if not _engine:
        return {"status": "not_initialized"}
    
    return {
        "status": "healthy",
        "sessions_active": len(_engine.sessions),
        "scheduled_actions": len(_engine.scheduled_actions),
        "timestamp": datetime.utcnow().isoformat()
    }
