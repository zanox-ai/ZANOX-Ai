# ZANOX V16 API Reference

## Authentication
All endpoints require a valid JWT token passed in the Authorization header:
```
Authorization: Bearer <token>
```

## Personal Assistant
### POST /api/v16/assistant/chat
Send a message to the AI assistant.
**Body:** `{"message": "Create task review PR due tomorrow", "session_id": "optional"}`

### WS /api/v16/assistant/ws
WebSocket endpoint for real-time chat.

## Tasks
### GET /api/v16/tasks
List tasks with filtering.
**Query params:** `status`, `priority`, `project_id`, `overdue_only`, `search`, `page`, `page_size`

### POST /api/v16/tasks
Create a new task.
**Body:** `{"title": "", "description": "", "priority": "medium", "due_date": "", "estimated_duration_minutes": 60}`

### PUT /api/v16/tasks/{id}
Update a task.

### DELETE /api/v16/tasks/{id}
Delete (soft delete) a task.

## Projects
### GET /api/v16/projects
List projects.

### POST /api/v16/projects
Create a project.

### GET /api/v16/projects/{id}/milestones
Get project milestones.

### POST /api/v16/projects/{id}/milestones
Add a milestone.

## Goals
### GET /api/v16/goals
List goals.

### POST /api/v16/goals
Create a goal with key results.

### PUT /api/v16/goals/{goal_id}/key-results/{kr_id}
Update key result progress.

## Habits
### GET /api/v16/habits
List habits.

### POST /api/v16/habits/{id}/log
Log a habit completion.

## Calendar
### GET /api/v16/calendar/events
List events between dates.

### POST /api/v16/calendar/events
Create an event.

### GET /api/v16/calendar/reminders
Get pending reminders.

## Focus
### POST /api/v16/focus/sessions
Start a focus session.

### PUT /api/v16/focus/sessions/{id}/end
End a focus session.

### POST /api/v16/focus/pomodoro/start
Start a pomodoro.

## Dashboard
### GET /api/v16/dashboard/today
Get today's dashboard.

### GET /api/v16/dashboard/weekly
Get weekly overview.
