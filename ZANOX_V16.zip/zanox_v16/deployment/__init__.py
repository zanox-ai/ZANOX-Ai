"""ZANOX V16 - Deployment Configurations."""
