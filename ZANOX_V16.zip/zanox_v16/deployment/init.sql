-- ZANOX V16 Database Initialization Script
-- Creates all required tables for the Personal Assistant & Productivity Layer

-- Tasks
CREATE TABLE IF NOT EXISTS tasks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    description TEXT,
    priority TEXT DEFAULT 'medium',
    status TEXT DEFAULT 'todo',
    due_date TIMESTAMP,
    estimated_duration_minutes INT,
    actual_duration_minutes INT,
    tags JSONB DEFAULT '[]',
    project_id UUID,
    goal_id UUID,
    assigned_to UUID,
    parent_task_id UUID,
    metadata JSONB DEFAULT '{}',
    reminder_sent BOOLEAN DEFAULT false,
    recurring_rule_id UUID,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    completed_at TIMESTAMP
);

-- Task Dependencies
CREATE TABLE IF NOT EXISTS task_dependencies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    task_id UUID NOT NULL,
    depends_on_task_id UUID NOT NULL,
    dependency_type TEXT DEFAULT 'blocked_by',
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(task_id, depends_on_task_id)
);

-- Recurring Task Rules
CREATE TABLE IF NOT EXISTS recurring_task_rules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    task_template_id UUID NOT NULL,
    frequency TEXT DEFAULT 'daily',
    interval INT DEFAULT 1,
    days_of_week INT[],
    day_of_month INT,
    end_date TIMESTAMP,
    max_occurrences INT,
    active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Projects
CREATE TABLE IF NOT EXISTS projects (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    description TEXT,
    status TEXT DEFAULT 'planning',
    priority TEXT DEFAULT 'medium',
    start_date DATE,
    target_end_date DATE,
    actual_end_date DATE,
    owner_id UUID,
    tags JSONB DEFAULT '[]',
    color TEXT DEFAULT '#6366f1',
    progress_percentage FLOAT DEFAULT 0,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Milestones
CREATE TABLE IF NOT EXISTS milestones (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id UUID NOT NULL,
    name TEXT NOT NULL,
    description TEXT,
    due_date DATE,
    completed_date DATE,
    status TEXT DEFAULT 'pending',
    deliverables JSONB DEFAULT '[]',
    created_at TIMESTAMP DEFAULT NOW()
);

-- Roadmap Items
CREATE TABLE IF NOT EXISTS roadmap_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id UUID NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    quarter INT,
    year INT,
    start_date DATE,
    end_date DATE,
    status TEXT DEFAULT 'planned',
    created_at TIMESTAMP DEFAULT NOW()
);

-- Goals
CREATE TABLE IF NOT EXISTS goals (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    description TEXT,
    status TEXT DEFAULT 'active',
    priority TEXT DEFAULT 'medium',
    category TEXT,
    target_date DATE,
    parent_goal_id UUID,
    owner_id UUID,
    progress_percentage FLOAT DEFAULT 0,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Key Results
CREATE TABLE IF NOT EXISTS key_results (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    goal_id UUID NOT NULL,
    description TEXT NOT NULL,
    target_value FLOAT DEFAULT 100,
    current_value FLOAT DEFAULT 0,
    unit TEXT DEFAULT '%',
    deadline DATE,
    status TEXT DEFAULT 'not_started',
    created_at TIMESTAMP DEFAULT NOW()
);

-- Habits
CREATE TABLE IF NOT EXISTS habits (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    description TEXT,
    frequency TEXT DEFAULT 'daily',
    target_per_period INT DEFAULT 1,
    color TEXT DEFAULT '#10b981',
    icon TEXT DEFAULT 'check',
    reminder_time TIME,
    associated_goal_id UUID,
    current_streak INT DEFAULT 0,
    longest_streak INT DEFAULT 0,
    total_completions INT DEFAULT 0,
    last_completed TIMESTAMP,
    active BOOLEAN DEFAULT true,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT NOW()
);

-- Habit Logs
CREATE TABLE IF NOT EXISTS habit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    habit_id UUID NOT NULL,
    completed_at TIMESTAMP DEFAULT NOW(),
    notes TEXT,
    value FLOAT,
    mood INT,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Calendar Events
CREATE TABLE IF NOT EXISTS calendar_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    description TEXT,
    event_type TEXT DEFAULT 'meeting',
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP NOT NULL,
    timezone TEXT DEFAULT 'UTC',
    location TEXT,
    is_recurring BOOLEAN DEFAULT false,
    recurring_rule TEXT,
    attendees JSONB DEFAULT '[]',
    linked_task_id UUID,
    linked_project_id UUID,
    linked_goal_id UUID,
    color TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Time Blocks
CREATE TABLE IF NOT EXISTS time_blocks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    days_of_week INT[],
    block_type TEXT DEFAULT 'focus',
    color TEXT,
    active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Reminders
CREATE TABLE IF NOT EXISTS reminders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    message TEXT,
    trigger_time TIMESTAMP NOT NULL,
    entity_type TEXT,
    entity_id UUID,
    dismissed BOOLEAN DEFAULT false,
    dismissed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Focus Sessions
CREATE TABLE IF NOT EXISTS focus_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    mode TEXT DEFAULT 'deep_work',
    started_at TIMESTAMP DEFAULT NOW(),
    ended_at TIMESTAMP,
    planned_duration_minutes INT NOT NULL,
    actual_duration_minutes INT,
    task_id UUID,
    project_id UUID,
    interruptions INT DEFAULT 0,
    notes TEXT,
    rating INT
);

-- Pomodoro Sessions
CREATE TABLE IF NOT EXISTS pomodoro_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    task_id UUID,
    started_at TIMESTAMP DEFAULT NOW(),
    completed_at TIMESTAMP,
    duration_minutes INT DEFAULT 25,
    break_duration_minutes INT DEFAULT 5,
    completed BOOLEAN DEFAULT false,
    interruptions INT DEFAULT 0
);

-- Deep Work Blocks
CREATE TABLE IF NOT EXISTS deep_work_blocks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    task_id UUID,
    project_id UUID,
    date DATE NOT NULL,
    planned_start TIME NOT NULL,
    planned_end TIME NOT NULL,
    actual_start TIMESTAMP,
    actual_end TIMESTAMP,
    status TEXT DEFAULT 'scheduled',
    quality_rating INT,
    output_summary TEXT
);

-- Decision Matrices
CREATE TABLE IF NOT EXISTS decision_matrices (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    description TEXT,
    decision_type TEXT DEFAULT 'weighted',
    criteria JSONB DEFAULT '[]',
    criteria_weights JSONB DEFAULT '{}',
    final_decision TEXT,
    confidence_score FLOAT,
    created_at TIMESTAMP DEFAULT NOW(),
    resolved_at TIMESTAMP
);

-- Decision Options
CREATE TABLE IF NOT EXISTS decision_options (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    decision_id UUID NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    pros JSONB DEFAULT '[]',
    cons JSONB DEFAULT '[]',
    scores JSONB DEFAULT '{}'
);

-- Knowledge Entries
CREATE TABLE IF NOT EXISTS knowledge_entries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    category TEXT,
    tags JSONB DEFAULT '[]',
    source TEXT,
    related_entries UUID[],
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    version INT DEFAULT 1
);

-- Notes
CREATE TABLE IF NOT EXISTS notes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT,
    content TEXT NOT NULL,
    note_type TEXT DEFAULT 'quick',
    tags JSONB DEFAULT '[]',
    linked_task_id UUID,
    linked_project_id UUID,
    linked_goal_id UUID,
    folder TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Bookmarks
CREATE TABLE IF NOT EXISTS bookmarks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    url TEXT NOT NULL,
    title TEXT,
    description TEXT,
    favicon TEXT,
    tags JSONB DEFAULT '[]',
    folder TEXT,
    reading_time_minutes INT,
    is_archived BOOLEAN DEFAULT false,
    click_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Reading List
CREATE TABLE IF NOT EXISTS reading_list (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    url TEXT,
    content_type TEXT DEFAULT 'article',
    status TEXT DEFAULT 'to_read',
    priority TEXT DEFAULT 'medium',
    estimated_reading_time INT,
    notes TEXT,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Documents
CREATE TABLE IF NOT EXISTS documents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    document_type TEXT DEFAULT 'file',
    storage_path TEXT,
    size_bytes BIGINT,
    mime_type TEXT,
    checksum TEXT,
    folder_id UUID,
    tags JSONB DEFAULT '[]',
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- File Folders
CREATE TABLE IF NOT EXISTS file_folders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    parent_id UUID,
    color TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Learning Items
CREATE TABLE IF NOT EXISTS learning_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    skill_category TEXT,
    resource_type TEXT DEFAULT 'course',
    status TEXT DEFAULT 'planned',
    progress_percentage FLOAT DEFAULT 0,
    start_date DATE,
    target_completion_date DATE,
    completed_date DATE,
    time_spent_minutes INT DEFAULT 0,
    notes TEXT,
    rating INT,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Learning Logs
CREATE TABLE IF NOT EXISTS learning_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    learning_item_id UUID NOT NULL,
    session_date DATE NOT NULL,
    duration_minutes INT NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Assistant Scheduled Actions
CREATE TABLE IF NOT EXISTS assistant_scheduled_actions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    action_id TEXT NOT NULL UNIQUE,
    action_type TEXT NOT NULL,
    parameters JSONB DEFAULT '{}',
    scheduled_for TIMESTAMP NOT NULL,
    recurring BOOLEAN DEFAULT false,
    recurrence_rule TEXT,
    status TEXT DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT NOW()
);

-- Assistant Conversations
CREATE TABLE IF NOT EXISTS assistant_conversations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id TEXT,
    message TEXT NOT NULL,
    response TEXT NOT NULL,
    intent TEXT,
    confidence FLOAT,
    created_at TIMESTAMP DEFAULT NOW()
);

-- User Preferences
CREATE TABLE IF NOT EXISTS user_preferences (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id TEXT NOT NULL,
    default_focus_duration INT DEFAULT 25,
    preferred_working_hours JSONB DEFAULT '{"start": 9, "end": 17}',
    timezone TEXT DEFAULT 'UTC',
    notification_channels JSONB DEFAULT '["in_app"]',
    theme TEXT DEFAULT 'light',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Activity Log
CREATE TABLE IF NOT EXISTS activity_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    activity_type TEXT NOT NULL,
    details JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT NOW()
);

-- Audit Log
CREATE TABLE IF NOT EXISTS audit_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    action TEXT NOT NULL,
    user_id TEXT,
    details JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT NOW()
);

-- Compliance Log
CREATE TABLE IF NOT EXISTS compliance_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    event_type TEXT NOT NULL,
    details JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT NOW()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);
CREATE INDEX IF NOT EXISTS idx_tasks_priority ON tasks(priority);
CREATE INDEX IF NOT EXISTS idx_tasks_due_date ON tasks(due_date);
CREATE INDEX IF NOT EXISTS idx_tasks_project_id ON tasks(project_id);
CREATE INDEX IF NOT EXISTS idx_tasks_goal_id ON tasks(goal_id);
CREATE INDEX IF NOT EXISTS idx_calendar_events_start_time ON calendar_events(start_time);
CREATE INDEX IF NOT EXISTS idx_habit_logs_habit_id ON habit_logs(habit_id);
CREATE INDEX IF NOT EXISTS idx_focus_sessions_started_at ON focus_sessions(started_at);
CREATE INDEX IF NOT EXISTS idx_notes_note_type ON notes(note_type);
CREATE INDEX IF NOT EXISTS idx_knowledge_entries_category ON knowledge_entries(category);
