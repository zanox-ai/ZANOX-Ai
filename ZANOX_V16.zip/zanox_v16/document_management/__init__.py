"""ZANOX V16 - Document Management System."""
from .router import router
from .service import DocumentService
__all__ = ["router", "DocumentService"]
