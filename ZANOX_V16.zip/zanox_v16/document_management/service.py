"""Document Management Service - File organization and document handling."""
from datetime import datetime
from typing import Dict, List, Optional, Any
from uuid import UUID, uuid4
import asyncpg
from ..models import Document, FileFolder, DocumentType

class DocumentService:
    def __init__(self):
        self.db_pool = None
    def initialize(self, db_pool, redis_client):
        self.db_pool = db_pool

    async def create_folder(self, name: str, parent_id: Optional[UUID] = None, color: Optional[str] = None) -> FileFolder:
        if not self.db_pool:
            raise RuntimeError("Database not initialized")
        fid = uuid4()
        await self.db_pool.execute(
            "INSERT INTO file_folders (id, name, parent_id, color, created_at) VALUES ($1, $2, $3, $4, NOW())",
            fid, name, str(parent_id) if parent_id else None, color
        )
        return FileFolder(id=fid, name=name, parent_id=parent_id, color=color)

    async def create_document(self, name: str, document_type: str, folder_id: Optional[UUID] = None, storage_path: Optional[str] = None, size_bytes: Optional[int] = None, mime_type: Optional[str] = None, tags: Optional[List[str]] = None) -> Document:
        if not self.db_pool:
            raise RuntimeError("Database not initialized")
        did = uuid4()
        import hashlib
        checksum = hashlib.md5(name.encode()).hexdigest()
        await self.db_pool.execute(
            "INSERT INTO documents (id, name, document_type, folder_id, storage_path, size_bytes, mime_type, checksum, tags, created_at, updated_at) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, NOW(), NOW())",
            did, name, document_type, str(folder_id) if folder_id else None, storage_path, size_bytes, mime_type, checksum, tags or []
        )
        return Document(id=did, name=name, document_type=DocumentType(document_type), folder_id=folder_id, storage_path=storage_path, size_bytes=size_bytes, mime_type=mime_type, checksum=checksum, tags=tags or [])

    async def get_folder_contents(self, folder_id: Optional[UUID] = None) -> Dict[str, List]:
        if not self.db_pool:
            return {"folders": [], "documents": []}
        folders = await self.db_pool.fetch("SELECT * FROM file_folders WHERE parent_id = $1 ORDER BY name", str(folder_id) if folder_id else None)
        docs = await self.db_pool.fetch("SELECT * FROM documents WHERE folder_id = $1 ORDER BY name", str(folder_id) if folder_id else None)
        return {
            "folders": [FileFolder(id=r["id"], name=r["name"], parent_id=UUID(r["parent_id"]) if r["parent_id"] else None, color=r["color"]).model_dump() for r in folders],
            "documents": [Document(id=r["id"], name=r["name"], document_type=DocumentType(r["document_type"]), folder_id=UUID(r["folder_id"]) if r["folder_id"] else None, storage_path=r["storage_path"], size_bytes=r["size_bytes"], mime_type=r["mime_type"]).model_dump() for r in docs]
        }

    async def search_documents(self, query: str) -> List[Document]:
        if not self.db_pool:
            return []
        rows = await self.db_pool.fetch(
            "SELECT * FROM documents WHERE name ILIKE $1 ORDER BY name", f"%{query}%"
        )
        return [Document(id=r["id"], name=r["name"], document_type=DocumentType(r["document_type"]), storage_path=r["storage_path"], size_bytes=r["size_bytes"], mime_type=r["mime_type"]) for r in rows]
