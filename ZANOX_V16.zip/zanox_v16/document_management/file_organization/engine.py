"""File Organization Engine - Auto-organizes files by rules."""
from typing import Dict, List, Optional
from uuid import UUID

class FileOrganizationEngine:
    RULES = {
        "by_date": lambda f: f"{f.get('year', 'unknown')}/{f.get('month', 'unknown')}",
        "by_type": lambda f: f.get('extension', 'unknown').upper(),
        "by_project": lambda f: f.get('project', 'unsorted'),
    }

    async def auto_organize(self, files: List[Dict], method: str = "by_date") -> Dict[str, List[Dict]]:
        rule = self.RULES.get(method, self.RULES["by_date"])
        organized = {}
        for f in files:
            folder = rule(f)
            if folder not in organized:
                organized[folder] = []
            organized[folder].append(f)
        return organized

    async def suggest_tags(self, filename: str) -> List[str]:
        tags = []
        lower = filename.lower()
        tag_map = {
            "invoice": ["invoice", "bill", "receipt"],
            "contract": ["contract", "agreement", "nda"],
            "report": ["report", "analysis", "summary"],
            "design": ["design", "mockup", "wireframe", "figma"],
            "code": [".py", ".js", ".ts", ".java", ".go"],
        }
        for tag, keywords in tag_map.items():
            if any(kw in lower for kw in keywords):
                tags.append(tag)
        return tags
