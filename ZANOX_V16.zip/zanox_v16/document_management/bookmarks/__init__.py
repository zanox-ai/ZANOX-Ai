"""Bookmarks - Bookmark management engine."""
from .engine import BookmarkEngine
