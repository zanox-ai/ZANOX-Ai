"""Bookmark Engine - Advanced bookmark management."""
from typing import Dict, List, Optional

class BookmarkEngine:
    async def categorize(self, url: str, title: str) -> str:
        combined = (url + " " + title).lower()
        categories = {
            "development": ["github", "stackoverflow", "docs", "api", "dev"],
            "design": ["dribbble", "figma", "behance", "color", "font"],
            "learning": ["tutorial", "course", "learn", "book", "guide"],
            "news": ["news", "blog", "medium", "substack"],
            "tools": ["tool", "converter", "generator", "calculator"],
        }
        for cat, keywords in categories.items():
            if any(kw in combined for kw in keywords):
                return cat
        return "general"

    async def estimate_reading_time(self, url: str) -> int:
        return 5
