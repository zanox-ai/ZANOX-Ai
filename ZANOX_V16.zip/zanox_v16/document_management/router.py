"""Document Management Router - FastAPI endpoints."""
from typing import Optional, List
from uuid import UUID
from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from ..models import APIResponse
from .service import DocumentService

router = APIRouter()
_service: Optional[DocumentService] = None

def set_service(service: DocumentService):
    global _service
    _service = service

class FolderRequest(BaseModel):
    name: str
    parent_id: Optional[UUID] = None
    color: Optional[str] = None

class DocumentRequest(BaseModel):
    name: str
    document_type: str = "file"
    folder_id: Optional[UUID] = None
    storage_path: Optional[str] = None
    size_bytes: Optional[int] = None
    mime_type: Optional[str] = None
    tags: Optional[List[str]] = None

@router.post("/folders", response_model=APIResponse)
async def create_folder(request: FolderRequest):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.create_folder(request.name, request.parent_id, request.color)
    return APIResponse(success=True, data=result.model_dump() if hasattr(result, "model_dump") else result)

@router.get("/folders/{folder_id}/contents", response_model=APIResponse)
async def get_folder_contents(folder_id: Optional[UUID] = None):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.get_folder_contents(folder_id)
    return APIResponse(success=True, data=result)

@router.post("/documents", response_model=APIResponse)
async def create_document(request: DocumentRequest):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.create_document(request.name, request.document_type, request.folder_id, request.storage_path, request.size_bytes, request.mime_type, request.tags)
    return APIResponse(success=True, data=result.model_dump() if hasattr(result, "model_dump") else result)

@router.get("/documents/search", response_model=APIResponse)
async def search_documents(q: str = Query(...)):
    if not _service:
        raise HTTPException(status_code=503, detail="Service not initialized")
    result = await _service.search_documents(q)
    return APIResponse(success=True, data=[d.model_dump() if hasattr(d, "model_dump") else d for d in result])
