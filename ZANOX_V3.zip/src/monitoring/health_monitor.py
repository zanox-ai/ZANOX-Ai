"""Agent Health Monitoring for Nexus Core V3.

Real-time health checks, heartbeat monitoring, and status tracking.
"""
import asyncio
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from collections import deque
import aiohttp

from ..schemas.agent import AgentStatus, AgentHealth, AgentResponse
from ..schemas.monitoring import HealthCheckType, HealthCheckResult, AlertSeverity


@dataclass
class HealthMetrics:
    """Health metrics for an agent."""
    agent_id: str
    latency_history: deque = field(default_factory=lambda: deque(maxlen=100))
    error_history: deque = field(default_factory=lambda: deque(maxlen=100))
    check_history: deque = field(default_factory=lambda: deque(maxlen=1000))
    consecutive_failures: int = 0
    last_success: Optional[datetime] = None
    total_checks: int = 0
    failed_checks: int = 0


class AgentHealthMonitor:
    """Monitors health of all registered agents."""

    def __init__(self, registry, alert_manager=None):
        self.registry = registry
        self.alert_manager = alert_manager
        self.metrics: Dict[str, HealthMetrics] = {}
        self.running = False
        self.check_interval = 30  # seconds
        self._monitor_task = None

    async def start_monitoring(self):
        """Start the health monitoring loop."""
        self.running = True
        self._monitor_task = asyncio.create_task(self._monitor_loop())

    async def stop_monitoring(self):
        """Stop the health monitoring loop."""
        self.running = False
        if self._monitor_task:
            self._monitor_task.cancel()
            try:
                await self._monitor_task
            except asyncio.CancelledError:
                pass

    async def _monitor_loop(self):
        """Main monitoring loop."""
        while self.running:
            try:
                await self._run_health_checks()
                await asyncio.sleep(self.check_interval)
            except Exception as e:
                print(f"Health monitor error: {e}")
                await asyncio.sleep(5)

    async def _run_health_checks(self):
        """Run health checks for all active agents."""
        agents = self.registry.list_agents(status=AgentStatus.ACTIVE)

        tasks = []
        for agent in agents:
            tasks.append(self._check_agent_health(agent))

        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

    async def _check_agent_health(self, agent: AgentResponse):
        """Check health of a single agent."""
        agent_id = agent.agent_id

        if agent_id not in self.metrics:
            self.metrics[agent_id] = HealthMetrics(agent_id=agent_id)

        metrics = self.metrics[agent_id]
        start_time = time.time()

        try:
            # Run ping check
            health_result = await self._ping_agent(agent)
            latency_ms = (time.time() - start_time) * 1000

            metrics.latency_history.append(latency_ms)
            metrics.total_checks += 1
            metrics.consecutive_failures = 0
            metrics.last_success = datetime.utcnow()

            # Determine status based on latency and error rate
            status = self._determine_status(metrics, latency_ms)

            # Update registry
            health_score = self._calculate_health_score(metrics)
            self.registry.update_agent_health_score(agent_id, health_score)

            # Record check
            check_result = HealthCheckResult(
                agent_id=agent_id,
                check_type=HealthCheckType.PING,
                status=status,
                latency_ms=latency_ms,
                details={"health_score": health_score},
            )
            metrics.check_history.append(check_result)

            # Check if status degraded
            if status in [AgentStatus.DEGRADED, AgentStatus.OFFLINE]:
                await self._handle_degraded_agent(agent, status, latency_ms)

        except Exception as e:
            metrics.error_history.append(str(e))
            metrics.consecutive_failures += 1
            metrics.failed_checks += 1
            metrics.total_checks += 1

            # Determine status based on failures
            if metrics.consecutive_failures >= 5:
                status = AgentStatus.OFFLINE
            elif metrics.consecutive_failures >= 3:
                status = AgentStatus.DEGRADED
            else:
                status = AgentStatus.ACTIVE

            check_result = HealthCheckResult(
                agent_id=agent_id,
                check_type=HealthCheckType.PING,
                status=status,
                latency_ms=99999,
                error_message=str(e),
            )
            metrics.check_history.append(check_result)

            await self._handle_degraded_agent(agent, status, 99999)

    async def _ping_agent(self, agent: AgentResponse) -> bool:
        """Ping an agent to check availability."""
        # Implement provider-specific ping
        # For now, simulate with HTTP request to base URL
        try:
            timeout = aiohttp.ClientTimeout(total=10)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(agent.base_url) as response:
                    return response.status < 500
        except Exception:
            # If ping fails, try a lightweight API call
            return await self._lightweight_api_test(agent)

    async def _lightweight_api_test(self, agent: AgentResponse) -> bool:
        """Test agent with a lightweight API call."""
        # Provider-specific lightweight tests
        provider_tests = {
            "openai": self._test_openai,
            "anthropic": self._test_anthropic,
            "google": self._test_google,
            "xai": self._test_xai,
            "moonshot": self._test_moonshot,
            "perplexity": self._test_perplexity,
            "alibaba": self._test_alibaba,
            "microsoft": self._test_microsoft,
            "manus": self._test_manus,
        }

        test_func = provider_tests.get(agent.provider.value)
        if test_func:
            return await test_func(agent)
        return False

    async def _test_openai(self, agent: AgentResponse) -> bool:
        """Test OpenAI API."""
        try:
            headers = {"Authorization": f"Bearer {agent.config.custom_headers.get('api_key', '')}"}
            timeout = aiohttp.ClientTimeout(total=10)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(
                    f"{agent.base_url}/models",
                    headers=headers
                ) as response:
                    return response.status == 200
        except Exception:
            return False

    async def _test_anthropic(self, agent: AgentResponse) -> bool:
        """Test Anthropic API."""
        try:
            headers = {"x-api-key": agent.config.custom_headers.get("api_key", "")}
            timeout = aiohttp.ClientTimeout(total=10)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(
                    f"{agent.base_url}/v1/models",
                    headers=headers
                ) as response:
                    return response.status == 200
        except Exception:
            return False

    async def _test_google(self, agent: AgentResponse) -> bool:
        """Test Google Gemini API."""
        try:
            timeout = aiohttp.ClientTimeout(total=10)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(
                    f"{agent.base_url}/models?key={agent.config.custom_headers.get('api_key', '')}"
                ) as response:
                    return response.status == 200
        except Exception:
            return False

    async def _test_xai(self, agent: AgentResponse) -> bool:
        """Test XAI Grok API."""
        try:
            headers = {"Authorization": f"Bearer {agent.config.custom_headers.get('api_key', '')}"}
            timeout = aiohttp.ClientTimeout(total=10)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(
                    f"{agent.base_url}/models",
                    headers=headers
                ) as response:
                    return response.status == 200
        except Exception:
            return False

    async def _test_moonshot(self, agent: AgentResponse) -> bool:
        """Test Moonshot Kimi API."""
        try:
            headers = {"Authorization": f"Bearer {agent.config.custom_headers.get('api_key', '')}"}
            timeout = aiohttp.ClientTimeout(total=10)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(
                    f"{agent.base_url}/models",
                    headers=headers
                ) as response:
                    return response.status == 200
        except Exception:
            return False

    async def _test_perplexity(self, agent: AgentResponse) -> bool:
        """Test Perplexity API."""
        try:
            headers = {"Authorization": f"Bearer {agent.config.custom_headers.get('api_key', '')}"}
            timeout = aiohttp.ClientTimeout(total=10)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(
                    f"{agent.base_url}/models",
                    headers=headers
                ) as response:
                    return response.status == 200
        except Exception:
            return False

    async def _test_alibaba(self, agent: AgentResponse) -> bool:
        """Test Alibaba Qwen API."""
        try:
            headers = {"Authorization": f"Bearer {agent.config.custom_headers.get('api_key', '')}"}
            timeout = aiohttp.ClientTimeout(total=10)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(
                    f"{agent.base_url}/models",
                    headers=headers
                ) as response:
                    return response.status == 200
        except Exception:
            return False

    async def _test_microsoft(self, agent: AgentResponse) -> bool:
        """Test Microsoft Copilot API."""
        try:
            headers = {"Authorization": f"Bearer {agent.config.custom_headers.get('api_key', '')}"}
            timeout = aiohttp.ClientTimeout(total=10)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(
                    f"{agent.base_url}/models",
                    headers=headers
                ) as response:
                    return response.status == 200
        except Exception:
            return False

    async def _test_manus(self, agent: AgentResponse) -> bool:
        """Test Manus API."""
        try:
            headers = {"Authorization": f"Bearer {agent.config.custom_headers.get('api_key', '')}"}
            timeout = aiohttp.ClientTimeout(total=10)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(
                    f"{agent.base_url}/health",
                    headers=headers
                ) as response:
                    return response.status == 200
        except Exception:
            return False

    def _determine_status(self, metrics: HealthMetrics, current_latency: float) -> AgentStatus:
        """Determine agent status based on metrics."""
        if metrics.consecutive_failures >= 5:
            return AgentStatus.OFFLINE
        elif metrics.consecutive_failures >= 3:
            return AgentStatus.DEGRADED

        # Check latency
        if metrics.latency_history:
            avg_latency = sum(metrics.latency_history) / len(metrics.latency_history)
            if avg_latency > 10000:  # 10 seconds
                return AgentStatus.DEGRADED

        # Check error rate
        if metrics.total_checks > 0:
            error_rate = metrics.failed_checks / metrics.total_checks
            if error_rate > 0.1:  # 10% error rate
                return AgentStatus.DEGRADED

        return AgentStatus.ACTIVE

    def _calculate_health_score(self, metrics: HealthMetrics) -> float:
        """Calculate health score (0-1)."""
        if metrics.total_checks == 0:
            return 1.0

        # Base score from success rate
        success_rate = 1 - (metrics.failed_checks / metrics.total_checks)

        # Latency penalty
        latency_penalty = 0.0
        if metrics.latency_history:
            avg_latency = sum(metrics.latency_history) / len(metrics.latency_history)
            if avg_latency > 5000:
                latency_penalty = 0.2
            elif avg_latency > 2000:
                latency_penalty = 0.1

        # Failure penalty
        failure_penalty = min(metrics.consecutive_failures * 0.1, 0.5)

        score = max(0.0, success_rate - latency_penalty - failure_penalty)
        return round(score, 2)

    async def _handle_degraded_agent(self, agent: AgentResponse, status: AgentStatus, latency: float):
        """Handle degraded agent."""
        if self.alert_manager:
            severity = AlertSeverity.CRITICAL if status == AgentStatus.OFFLINE else AlertSeverity.WARNING
            await self.alert_manager.send_alert(
                agent_id=agent.agent_id,
                severity=severity,
                title=f"Agent {agent.name} is {status.value}",
                description=f"Agent health degraded. Latency: {latency:.0f}ms",
                metric_name="agent_status",
                metric_value=0.0 if status == AgentStatus.OFFLINE else 0.5,
                threshold=0.8,
            )

    def get_health_status(self, agent_id: str) -> Optional[AgentHealth]:
        """Get current health status for an agent."""
        if agent_id not in self.metrics:
            return None

        metrics = self.metrics[agent_id]

        # Calculate uptime
        if metrics.total_checks > 0:
            uptime = 1 - (metrics.failed_checks / metrics.total_checks)
        else:
            uptime = 1.0

        # Calculate average latency
        avg_latency = 0.0
        if metrics.latency_history:
            avg_latency = sum(metrics.latency_history) / len(metrics.latency_history)

        # Get latest status
        latest_status = AgentStatus.ACTIVE
        if metrics.check_history:
            latest_status = metrics.check_history[-1].status

        return AgentHealth(
            agent_id=agent_id,
            status=latest_status,
            latency_ms=avg_latency,
            error_rate=metrics.failed_checks / max(metrics.total_checks, 1),
            last_check=datetime.utcnow(),
            uptime_percentage=uptime * 100,
            consecutive_failures=metrics.consecutive_failures,
        )

    def get_all_health_status(self) -> List[AgentHealth]:
        """Get health status for all agents."""
        return [
            self.get_health_status(agent_id)
            for agent_id in self.metrics.keys()
        ]

    def get_health_history(self, agent_id: str, hours: int = 24) -> List[HealthCheckResult]:
        """Get health check history for an agent."""
        if agent_id not in self.metrics:
            return []

        cutoff = datetime.utcnow() - timedelta(hours=hours)
        return [
            check for check in self.metrics[agent_id].check_history
            if check.timestamp > cutoff
        ]
