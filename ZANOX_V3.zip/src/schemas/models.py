"""Base SQLAlchemy models for Nexus Core V3."""
from datetime import datetime
from sqlalchemy import Column, String, DateTime, Boolean, Float, Integer, JSON, Text, ForeignKey, Enum, Index
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
import enum

Base = declarative_base()


class AgentStatusEnum(str, enum.Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    DEGRADED = "degraded"
    MAINTENANCE = "maintenance"
    OFFLINE = "offline"


class CapabilityCategoryEnum(str, enum.Enum):
    TEXT_GENERATION = "text_generation"
    CODE_GENERATION = "code_generation"
    REASONING = "reasoning"
    ANALYSIS = "analysis"
    CREATIVE_WRITING = "creative_writing"
    MULTIMODAL = "multimodal"
    SEARCH = "search"
    REAL_TIME = "real_time"
    CITATION = "citation"
    RESEARCH = "research"
    LONG_CONTEXT = "long_context"
    AUTONOMOUS = "autonomous"
    TASK_EXECUTION = "task_execution"
    BROWSER_AUTOMATION = "browser_automation"
    FILE_PROCESSING = "file_processing"
    X_INTEGRATION = "x_integration"
    GITHUB_INTEGRATION = "github_integration"
    CODE_REVIEW = "code_review"


class AgentModel(Base):
    """Agent database model."""
    __tablename__ = "agents"

    id = Column(String(36), primary_key=True)
    name = Column(String(100), nullable=False)
    provider = Column(String(50), nullable=False)
    description = Column(Text)
    api_key_encrypted = Column(Text, nullable=False)
    base_url = Column(String(500), nullable=False)
    status = Column(Enum(AgentStatusEnum), default=AgentStatusEnum.ACTIVE)
    tags = Column(JSON, default=list)
    metadata = Column(JSON, default=dict)

    # Performance metrics
    health_score = Column(Float, default=1.0)
    rank_score = Column(Float, default=0.0)
    total_requests = Column(Integer, default=0)
    total_tokens = Column(Integer, default=0)
    total_cost = Column(Float, default=0.0)
    avg_latency_ms = Column(Float, default=0.0)
    error_rate = Column(Float, default=0.0)

    # Configuration
    timeout = Column(Integer, default=30)
    retry_attempts = Column(Integer, default=3)
    retry_delay = Column(Float, default=1.0)
    max_concurrent_requests = Column(Integer, default=100)
    rate_limit_per_minute = Column(Integer, default=60)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, onupdate=datetime.utcnow)
    last_health_check = Column(DateTime)
    is_available = Column(Boolean, default=True)

    # Relationships
    capabilities = relationship("AgentCapabilityModel", back_populates="agent", cascade="all, delete-orphan")
    models = relationship("AgentModelConfig", back_populates="agent", cascade="all, delete-orphan")
    cost_history = relationship("AgentCostHistory", back_populates="agent", cascade="all, delete-orphan")
    health_checks = relationship("AgentHealthCheck", back_populates="agent", cascade="all, delete-orphan")

    __table_args__ = (
        Index("idx_agent_status", "status"),
        Index("idx_agent_provider", "provider"),
        Index("idx_agent_rank", "rank_score"),
    )


class AgentCapabilityModel(Base):
    """Agent capability database model."""
    __tablename__ = "agent_capabilities"

    id = Column(String(36), primary_key=True)
    agent_id = Column(String(36), ForeignKey("agents.id"), nullable=False)
    category = Column(Enum(CapabilityCategoryEnum), nullable=False)
    name = Column(String(100), nullable=False)
    description = Column(Text)
    confidence_score = Column(Float, default=0.0)
    parameters = Column(JSON, default=dict)
    examples = Column(JSON, default=list)
    benchmark_scores = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, onupdate=datetime.utcnow)

    agent = relationship("AgentModel", back_populates="capabilities")

    __table_args__ = (
        Index("idx_capability_category", "category"),
        Index("idx_capability_agent", "agent_id"),
    )


class AgentModelConfig(Base):
    """Agent model configuration database model."""
    __tablename__ = "agent_models"

    id = Column(String(36), primary_key=True)
    agent_id = Column(String(36), ForeignKey("agents.id"), nullable=False)
    name = Column(String(100), nullable=False)
    version = Column(String(50))
    max_tokens = Column(Integer, default=128000)
    context_window = Column(Integer, default=128000)
    supports_streaming = Column(Boolean, default=True)
    supports_functions = Column(Boolean, default=False)
    supports_vision = Column(Boolean, default=False)
    parameters = Column(JSON, default=dict)
    is_default = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    agent = relationship("AgentModel", back_populates="models")

    __table_args__ = (
        Index("idx_model_agent", "agent_id"),
    )


class AgentCostHistory(Base):
    """Agent cost history database model."""
    __tablename__ = "agent_cost_history"

    id = Column(String(36), primary_key=True)
    agent_id = Column(String(36), ForeignKey("agents.id"), nullable=False)
    request_id = Column(String(36))
    input_tokens = Column(Integer, default=0)
    output_tokens = Column(Integer, default=0)
    input_cost = Column(Float, default=0.0)
    output_cost = Column(Float, default=0.0)
    total_cost = Column(Float, default=0.0)
    currency = Column(String(3), default="USD")
    timestamp = Column(DateTime, default=datetime.utcnow)

    agent = relationship("AgentModel", back_populates="cost_history")

    __table_args__ = (
        Index("idx_cost_agent", "agent_id"),
        Index("idx_cost_timestamp", "timestamp"),
    )


class AgentHealthCheck(Base):
    """Agent health check database model."""
    __tablename__ = "agent_health_checks"

    id = Column(String(36), primary_key=True)
    agent_id = Column(String(36), ForeignKey("agents.id"), nullable=False)
    check_type = Column(String(50), nullable=False)
    status = Column(Enum(AgentStatusEnum), nullable=False)
    latency_ms = Column(Float, default=0.0)
    error_message = Column(Text)
    details = Column(JSON, default=dict)
    timestamp = Column(DateTime, default=datetime.utcnow)

    agent = relationship("AgentModel", back_populates="health_checks")

    __table_args__ = (
        Index("idx_health_agent", "agent_id"),
        Index("idx_health_timestamp", "timestamp"),
    )


class AgentRankingHistory(Base):
    """Agent ranking history database model."""
    __tablename__ = "agent_ranking_history"

    id = Column(String(36), primary_key=True)
    agent_id = Column(String(36), nullable=False)
    rank = Column(Integer, nullable=False)
    overall_score = Column(Float, default=0.0)
    performance_score = Column(Float, default=0.0)
    reliability_score = Column(Float, default=0.0)
    cost_efficiency_score = Column(Float, default=0.0)
    user_feedback_score = Column(Float, default=0.0)
    trend = Column(String(20), default="stable")
    change_from_last = Column(Integer, default=0)
    calculated_at = Column(DateTime, default=datetime.utcnow)

    __table_args__ = (
        Index("idx_ranking_agent", "agent_id"),
        Index("idx_ranking_calculated", "calculated_at"),
    )


class RequestLog(Base):
    """Request log database model."""
    __tablename__ = "request_logs"

    id = Column(String(36), primary_key=True)
    request_id = Column(String(36), nullable=False, index=True)
    agent_id = Column(String(36), nullable=False)
    user_id = Column(String(36))
    session_id = Column(String(36))
    status = Column(String(20), nullable=False)
    priority = Column(String(20), default="normal")
    input_tokens = Column(Integer, default=0)
    output_tokens = Column(Integer, default=0)
    total_cost = Column(Float, default=0.0)
    latency_ms = Column(Float, default=0.0)
    fallback_used = Column(Boolean, default=False)
    fallback_chain = Column(JSON, default=list)
    error_message = Column(Text)
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime)

    __table_args__ = (
        Index("idx_request_status", "status"),
        Index("idx_request_created", "created_at"),
        Index("idx_request_user", "user_id"),
    )


class SystemAlert(Base):
    """System alert database model."""
    __tablename__ = "system_alerts"

    id = Column(String(36), primary_key=True)
    agent_id = Column(String(36))
    severity = Column(String(20), nullable=False)
    title = Column(String(200), nullable=False)
    description = Column(Text)
    metric_name = Column(String(100))
    metric_value = Column(Float)
    threshold = Column(Float)
    triggered_at = Column(DateTime, default=datetime.utcnow)
    resolved_at = Column(DateTime)
    acknowledged = Column(Boolean, default=False)
    acknowledged_by = Column(String(36))
    resolution_notes = Column(Text)

    __table_args__ = (
        Index("idx_alert_severity", "severity"),
        Index("idx_alert_triggered", "triggered_at"),
    )
