"""Agent schemas for Nexus Core V3."""
from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field, ConfigDict
from enum import Enum

from .base import BaseSchema, TimestampSchema, AgentStatus, CapabilityCategory


class AgentProvider(str, Enum):
    """Agent providers."""
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    GOOGLE = "google"
    XAI = "xai"
    MOONSHOT = "moonshot"
    PERPLEXITY = "perplexity"
    ALIBABA = "alibaba"
    MICROSOFT = "microsoft"
    MANUS = "manus"


class AgentCapability(BaseModel):
    """Agent capability definition."""
    model_config = ConfigDict(populate_by_name=True)

    category: CapabilityCategory
    name: str
    description: str
    confidence_score: float = Field(default=0.0, ge=0.0, le=1.0)
    parameters: Dict[str, Any] = Field(default_factory=dict)
    examples: List[str] = Field(default_factory=list)
    benchmark_scores: Dict[str, float] = Field(default_factory=dict)


class AgentCost(BaseModel):
    """Agent cost structure."""
    model_config = ConfigDict(populate_by_name=True)

    input_per_1k_tokens: float = Field(default=0.0, ge=0.0)
    output_per_1k_tokens: float = Field(default=0.0, ge=0.0)
    per_request: float = Field(default=0.0, ge=0.0)
    per_image: float = Field(default=0.0, ge=0.0)
    currency: str = "USD"
    billing_model: str = "pay_per_use"


class AgentModel(BaseModel):
    """Agent model definition."""
    model_config = ConfigDict(populate_by_name=True)

    name: str
    version: str
    max_tokens: int
    context_window: int
    supports_streaming: bool = True
    supports_functions: bool = False
    supports_vision: bool = False
    parameters: Dict[str, Any] = Field(default_factory=dict)


class AgentConfig(BaseModel):
    """Agent configuration."""
    model_config = ConfigDict(populate_by_name=True)

    timeout: int = Field(default=30, ge=1)
    retry_attempts: int = Field(default=3, ge=0, le=10)
    retry_delay: float = Field(default=1.0, ge=0.0)
    max_concurrent_requests: int = Field(default=100, ge=1)
    rate_limit_per_minute: int = Field(default=60, ge=1)
    custom_headers: Dict[str, str] = Field(default_factory=dict)


class AgentCreate(BaseSchema):
    """Agent creation schema."""
    name: str = Field(..., min_length=1, max_length=100)
    provider: AgentProvider
    description: Optional[str] = None
    api_key: str = Field(..., min_length=10)
    base_url: str
    models: List[AgentModel]
    capabilities: List[AgentCapability]
    cost: AgentCost
    config: AgentConfig = Field(default_factory=AgentConfig)
    tags: List[str] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class AgentUpdate(BaseSchema):
    """Agent update schema."""
    name: Optional[str] = Field(None, min_length=1, max_length=100)
    description: Optional[str] = None
    api_key: Optional[str] = Field(None, min_length=10)
    base_url: Optional[str] = None
    models: Optional[List[AgentModel]] = None
    capabilities: Optional[List[AgentCapability]] = None
    cost: Optional[AgentCost] = None
    config: Optional[AgentConfig] = None
    status: Optional[AgentStatus] = None
    tags: Optional[List[str]] = None
    metadata: Optional[Dict[str, Any]] = None


class AgentResponse(TimestampSchema):
    """Agent response schema."""
    id: str = Field(..., alias="agent_id")
    name: str
    provider: AgentProvider
    description: Optional[str] = None
    status: AgentStatus = AgentStatus.ACTIVE
    models: List[AgentModel]
    capabilities: List[AgentCapability]
    cost: AgentCost
    config: AgentConfig
    tags: List[str] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)
    health_score: float = Field(default=1.0, ge=0.0, le=1.0)
    rank_score: float = Field(default=0.0, ge=0.0, le=1.0)
    total_requests: int = Field(default=0, ge=0)
    total_tokens: int = Field(default=0, ge=0)
    total_cost: float = Field(default=0.0, ge=0.0)
    avg_latency_ms: float = Field(default=0.0, ge=0.0)
    error_rate: float = Field(default=0.0, ge=0.0, le=1.0)
    last_health_check: Optional[datetime] = None
    is_available: bool = True


class AgentListResponse(BaseSchema):
    """Agent list response."""
    agents: List[AgentResponse]
    total: int


class AgentHealth(BaseSchema):
    """Agent health status."""
    agent_id: str
    status: AgentStatus
    latency_ms: float
    error_rate: float
    last_check: datetime
    uptime_percentage: float
    consecutive_failures: int
    message: Optional[str] = None


class AgentMetrics(BaseSchema):
    """Agent performance metrics."""
    agent_id: str
    timestamp: datetime
    requests_count: int
    tokens_input: int
    tokens_output: int
    total_cost: float
    avg_latency_ms: float
    p50_latency_ms: float
    p95_latency_ms: float
    p99_latency_ms: float
    error_count: int
    error_rate: float
    success_rate: float
    concurrent_requests: int
    queue_depth: int


class AgentSelectionCriteria(BaseSchema):
    """Criteria for agent selection."""
    required_capabilities: List[CapabilityCategory]
    preferred_providers: Optional[List[AgentProvider]] = None
    max_cost_per_request: Optional[float] = None
    max_latency_ms: Optional[float] = None
    min_success_rate: Optional[float] = Field(None, ge=0.0, le=1.0)
    priority: str = "normal"
    fallback_enabled: bool = True


class AgentSelectionResult(BaseSchema):
    """Agent selection result."""
    selected_agent_id: str
    selected_model: str
    confidence_score: float
    estimated_cost: float
    estimated_latency_ms: float
    fallback_chain: List[str] = Field(default_factory=list)
    selection_reason: str


class AgentRanking(BaseSchema):
    """Agent ranking entry."""
    agent_id: str
    rank: int
    overall_score: float
    performance_score: float
    reliability_score: float
    cost_efficiency_score: float
    user_feedback_score: float
    trend: str = "stable"
    change_from_last: int = 0


class AgentDiscoveryFilter(BaseSchema):
    """Filter for agent discovery."""
    providers: Optional[List[AgentProvider]] = None
    capabilities: Optional[List[CapabilityCategory]] = None
    min_health_score: Optional[float] = Field(None, ge=0.0, le=1.0)
    max_cost_per_1k_tokens: Optional[float] = None
    status: Optional[AgentStatus] = None
    tags: Optional[List[str]] = None
    search_query: Optional[str] = None
    sort_by: str = "rank_score"
    sort_order: str = "desc"
