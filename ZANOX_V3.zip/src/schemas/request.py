"""Request and response schemas for Nexus Core V3."""
from datetime import datetime
from typing import Optional, List, Dict, Any, Union
from pydantic import BaseModel, Field
from enum import Enum

from .base import BaseSchema, RequestPriority
from .agent import AgentResponse, AgentSelectionResult, CapabilityCategory


class MessageRole(str, Enum):
    """Message roles."""
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"


class Message(BaseModel):
    """Chat message."""
    role: MessageRole
    content: str
    name: Optional[str] = None
    tool_calls: Optional[List[Dict[str, Any]]] = None
    tool_call_id: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)


class ToolDefinition(BaseModel):
    """Tool/function definition."""
    name: str
    description: str
    parameters: Dict[str, Any]


class RequestConfig(BaseModel):
    """Request configuration."""
    temperature: float = Field(default=0.7, ge=0.0, le=2.0)
    max_tokens: Optional[int] = Field(default=None, ge=1)
    top_p: float = Field(default=1.0, ge=0.0, le=1.0)
    frequency_penalty: float = Field(default=0.0, ge=-2.0, le=2.0)
    presence_penalty: float = Field(default=0.0, ge=-2.0, le=2.0)
    stream: bool = False
    tools: Optional[List[ToolDefinition]] = None
    response_format: Optional[Dict[str, Any]] = None
    seed: Optional[int] = None


class UnifiedRequest(BaseSchema):
    """Unified request to the agent marketplace."""
    request_id: str = Field(..., description="Unique request identifier")
    messages: List[Message]
    preferred_agents: Optional[List[str]] = None
    excluded_agents: Optional[List[str]] = None
    required_capabilities: List[CapabilityCategory] = Field(default_factory=list)
    config: RequestConfig = Field(default_factory=RequestConfig)
    priority: RequestPriority = RequestPriority.NORMAL
    timeout: Optional[int] = Field(default=None, ge=1)
    metadata: Dict[str, Any] = Field(default_factory=dict)
    user_id: Optional[str] = None
    session_id: Optional[str] = None
    fallback_enabled: bool = True
    cost_budget: Optional[float] = None


class UnifiedResponse(BaseSchema):
    """Unified response from the agent marketplace."""
    response_id: str
    request_id: str
    agent_id: str
    agent_name: str
    model: str
    content: str
    usage: Dict[str, Any] = Field(default_factory=dict)
    latency_ms: float
    cost: float
    finish_reason: str = "stop"
    tool_calls: Optional[List[Dict[str, Any]]] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    fallback_used: bool = False
    fallback_chain: List[str] = Field(default_factory=list)


class StreamChunk(BaseSchema):
    """Streaming response chunk."""
    chunk_id: str
    request_id: str
    agent_id: str
    content: str
    finish_reason: Optional[str] = None
    usage: Optional[Dict[str, Any]] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class BatchRequest(BaseSchema):
    """Batch request for multiple tasks."""
    batch_id: str
    requests: List[UnifiedRequest]
    parallel: bool = True
    aggregate_results: bool = True


class BatchResponse(BaseSchema):
    """Batch response."""
    batch_id: str
    responses: List[UnifiedResponse]
    completed_count: int
    failed_count: int
    total_latency_ms: float
    total_cost: float
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class RequestStatus(BaseSchema):
    """Request status tracking."""
    request_id: str
    status: str  # pending, processing, completed, failed, cancelled
    agent_id: Optional[str] = None
    progress: float = Field(default=0.0, ge=0.0, le=1.0)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    error_message: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)


class CostBreakdown(BaseSchema):
    """Cost breakdown for a request."""
    request_id: str
    agent_id: str
    input_tokens: int
    output_tokens: int
    input_cost: float
    output_cost: float
    total_cost: float
    currency: str = "USD"
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class PerformanceMetrics(BaseSchema):
    """Performance metrics for a request."""
    request_id: str
    agent_id: str
    latency_ms: float
    time_to_first_token_ms: Optional[float] = None
    tokens_per_second: float
    queue_time_ms: float
    processing_time_ms: float
    timestamp: datetime = Field(default_factory=datetime.utcnow)
