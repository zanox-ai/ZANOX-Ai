"""Monitoring schemas for Nexus Core V3."""
from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from enum import Enum

from .base import BaseSchema, AgentStatus


class HealthCheckType(str, Enum):
    """Types of health checks."""
    PING = "ping"
    API_TEST = "api_test"
    LATENCY_TEST = "latency_test"
    CAPABILITY_TEST = "capability_test"
    FULL_DIAGNOSTIC = "full_diagnostic"


class HealthCheckResult(BaseSchema):
    """Health check result."""
    agent_id: str
    check_type: HealthCheckType
    status: AgentStatus
    latency_ms: float
    error_message: Optional[str] = None
    details: Dict[str, Any] = Field(default_factory=dict)
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class HealthHistory(BaseSchema):
    """Health check history."""
    agent_id: str
    checks: List[HealthCheckResult]
    uptime_24h: float
    uptime_7d: float
    uptime_30d: float
    avg_latency_24h: float
    error_rate_24h: float


class AlertSeverity(str, Enum):
    """Alert severity levels."""
    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"
    EMERGENCY = "emergency"


class Alert(BaseSchema):
    """System alert."""
    alert_id: str
    agent_id: Optional[str] = None
    severity: AlertSeverity
    title: str
    description: str
    metric_name: str
    metric_value: float
    threshold: float
    triggered_at: datetime = Field(default_factory=datetime.utcnow)
    resolved_at: Optional[datetime] = None
    acknowledged: bool = False
    acknowledged_by: Optional[str] = None
    resolution_notes: Optional[str] = None


class DashboardMetrics(BaseSchema):
    """Dashboard metrics summary."""
    total_agents: int
    active_agents: int
    degraded_agents: int
    offline_agents: int
    total_requests_24h: int
    total_tokens_24h: int
    total_cost_24h: float
    avg_latency_ms: float
    error_rate: float
    top_agents: List[Dict[str, Any]]
    recent_alerts: List[Alert]
    capacity_usage: float
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class SystemMetrics(BaseSchema):
    """System-wide metrics."""
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    cpu_usage: float
    memory_usage: float
    disk_usage: float
    network_io: Dict[str, float]
    active_connections: int
    queue_depth: int
    request_rate: float
    error_rate: float
    latency_histogram: Dict[str, float]
