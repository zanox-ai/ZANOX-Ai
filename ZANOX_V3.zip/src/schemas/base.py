"""Base schemas for Nexus Core V3."""
from datetime import datetime
from typing import Optional, List, Dict, Any, Union
from pydantic import BaseModel, Field, ConfigDict
from enum import Enum


class AgentStatus(str, Enum):
    """Agent operational status."""
    ACTIVE = "active"
    INACTIVE = "inactive"
    DEGRADED = "degraded"
    MAINTENANCE = "maintenance"
    OFFLINE = "offline"


class CapabilityCategory(str, Enum):
    """Capability categories."""
    TEXT_GENERATION = "text_generation"
    CODE_GENERATION = "code_generation"
    REASONING = "reasoning"
    ANALYSIS = "analysis"
    CREATIVE_WRITING = "creative_writing"
    MULTIMODAL = "multimodal"
    SEARCH = "search"
    REAL_TIME = "real_time"
    CITATION = "citation"
    RESEARCH = "research"
    LONG_CONTEXT = "long_context"
    AUTONOMOUS = "autonomous"
    TASK_EXECUTION = "task_execution"
    BROWSER_AUTOMATION = "browser_automation"
    FILE_PROCESSING = "file_processing"
    X_INTEGRATION = "x_integration"
    GITHUB_INTEGRATION = "github_integration"
    CODE_REVIEW = "code_review"


class RequestPriority(str, Enum):
    """Request priority levels."""
    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
    CRITICAL = "critical"


class BaseSchema(BaseModel):
    """Base schema with common configuration."""
    model_config = ConfigDict(
        populate_by_name=True,
        json_schema_extra={"protected_namespaces": ()}
    )


class TimestampSchema(BaseSchema):
    """Schema with timestamp fields."""
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: Optional[datetime] = None
    deleted_at: Optional[datetime] = None


class PaginationParams(BaseSchema):
    """Pagination parameters."""
    page: int = Field(default=1, ge=1)
    page_size: int = Field(default=20, ge=1, le=100)
    sort_by: str = "created_at"
    sort_order: str = "desc"


class PaginatedResponse(BaseSchema):
    """Paginated response wrapper."""
    items: List[Any]
    total: int
    page: int
    page_size: int
    total_pages: int
    has_next: bool
    has_prev: bool
