"""Agent Capability Database for Nexus Core V3.

Manages capability taxonomy, skill mapping, and capability scoring.
"""
import uuid
from datetime import datetime
from typing import List, Optional, Dict, Any, Set
from sqlalchemy.orm import Session
from sqlalchemy import func

from ..schemas.agent import AgentCapability, CapabilityCategory, AgentResponse
from ..schemas.models import AgentCapabilityModel, AgentModel as AgentDB


class CapabilityTaxonomy:
    """Capability taxonomy and ontology management."""

    # Capability hierarchy
    CAPABILITY_HIERARCHY = {
        CapabilityCategory.TEXT_GENERATION: {
            "parent": None,
            "children": [CapabilityCategory.CREATIVE_WRITING],
            "skills": ["writing", "summarization", "translation", "paraphrasing"],
        },
        CapabilityCategory.CODE_GENERATION: {
            "parent": None,
            "children": [CapabilityCategory.CODE_REVIEW],
            "skills": ["python", "javascript", "java", "cpp", "rust", "go", "sql"],
        },
        CapabilityCategory.REASONING: {
            "parent": None,
            "children": [CapabilityCategory.ANALYSIS],
            "skills": ["logical_reasoning", "mathematical", "deductive", "inductive"],
        },
        CapabilityCategory.ANALYSIS: {
            "parent": CapabilityCategory.REASONING,
            "children": [CapabilityCategory.RESEARCH],
            "skills": ["data_analysis", "sentiment_analysis", "trend_analysis"],
        },
        CapabilityCategory.CREATIVE_WRITING: {
            "parent": CapabilityCategory.TEXT_GENERATION,
            "children": [],
            "skills": ["storytelling", "poetry", "scriptwriting", "copywriting"],
        },
        CapabilityCategory.MULTIMODAL: {
            "parent": None,
            "children": [],
            "skills": ["image_understanding", "video_analysis", "audio_processing", "ocr"],
        },
        CapabilityCategory.SEARCH: {
            "parent": None,
            "children": [CapabilityCategory.RESEARCH],
            "skills": ["web_search", "semantic_search", "database_query"],
        },
        CapabilityCategory.REAL_TIME: {
            "parent": None,
            "children": [],
            "skills": ["live_data", "streaming", "news_aggregation"],
        },
        CapabilityCategory.CITATION: {
            "parent": None,
            "children": [],
            "skills": ["source_verification", "bibliography", "fact_checking"],
        },
        CapabilityCategory.RESEARCH: {
            "parent": CapabilityCategory.ANALYSIS,
            "children": [],
            "skills": ["literature_review", "hypothesis_generation", "experiment_design"],
        },
        CapabilityCategory.LONG_CONTEXT: {
            "parent": None,
            "children": [],
            "skills": ["document_processing", "book_analysis", "large_codebase"],
        },
        CapabilityCategory.AUTONOMOUS: {
            "parent": None,
            "children": [CapabilityCategory.TASK_EXECUTION],
            "skills": ["planning", "self_correction", "goal_oriented"],
        },
        CapabilityCategory.TASK_EXECUTION: {
            "parent": CapabilityCategory.AUTONOMOUS,
            "children": [CapabilityCategory.BROWSER_AUTOMATION, CapabilityCategory.FILE_PROCESSING],
            "skills": ["workflow_execution", "api_integration", "data_pipeline"],
        },
        CapabilityCategory.BROWSER_AUTOMATION: {
            "parent": CapabilityCategory.TASK_EXECUTION,
            "children": [],
            "skills": ["web_scraping", "form_filling", "navigation"],
        },
        CapabilityCategory.FILE_PROCESSING: {
            "parent": CapabilityCategory.TASK_EXECUTION,
            "children": [],
            "skills": ["pdf_processing", "spreadsheet_analysis", "document_conversion"],
        },
        CapabilityCategory.X_INTEGRATION: {
            "parent": None,
            "children": [],
            "skills": ["social_media", "trend_analysis", "content_generation"],
        },
        CapabilityCategory.GITHUB_INTEGRATION: {
            "parent": None,
            "children": [CapabilityCategory.CODE_REVIEW],
            "skills": ["pr_review", "issue_management", "code_search"],
        },
        CapabilityCategory.CODE_REVIEW: {
            "parent": CapabilityCategory.CODE_GENERATION,
            "children": [],
            "skills": ["bug_detection", "security_audit", "performance_review"],
        },
    }

    @classmethod
    def get_children(cls, category: CapabilityCategory) -> List[CapabilityCategory]:
        """Get child capabilities."""
        entry = cls.CAPABILITY_HIERARCHY.get(category, {})
        return entry.get("children", [])

    @classmethod
    def get_parent(cls, category: CapabilityCategory) -> Optional[CapabilityCategory]:
        """Get parent capability."""
        entry = cls.CAPABILITY_HIERARCHY.get(category, {})
        return entry.get("parent")

    @classmethod
    def get_skills(cls, category: CapabilityCategory) -> List[str]:
        """Get skills for a capability."""
        entry = cls.CAPABILITY_HIERARCHY.get(category, {})
        return entry.get("skills", [])

    @classmethod
    def get_all_descendants(cls, category: CapabilityCategory) -> Set[CapabilityCategory]:
        """Get all descendants including self."""
        descendants = {category}
        children = cls.get_children(category)
        for child in children:
            descendants.update(cls.get_all_descendants(child))
        return descendants


class AgentCapabilityDatabase:
    """Database for agent capabilities."""

    def __init__(self, db_session: Session):
        self.db = db_session
        self.taxonomy = CapabilityTaxonomy()

    def add_capability(
        self,
        agent_id: str,
        capability: AgentCapability,
    ) -> bool:
        """Add a capability to an agent."""
        agent = self.db.query(AgentDB).filter(AgentDB.id == agent_id).first()
        if not agent:
            return False

        cap_model = AgentCapabilityModel(
            id=str(uuid.uuid4()),
            agent_id=agent_id,
            category=capability.category.value,
            name=capability.name,
            description=capability.description,
            confidence_score=capability.confidence_score,
            parameters=capability.parameters,
            examples=capability.examples,
            benchmark_scores=capability.benchmark_scores,
        )
        self.db.add(cap_model)
        self.db.commit()
        return True

    def get_agent_capabilities(self, agent_id: str) -> List[AgentCapability]:
        """Get all capabilities for an agent."""
        caps = self.db.query(AgentCapabilityModel).filter(
            AgentCapabilityModel.agent_id == agent_id
        ).all()

        return [
            AgentCapability(
                category=CapabilityCategory(cap.category),
                name=cap.name,
                description=cap.description,
                confidence_score=cap.confidence_score,
                parameters=cap.parameters,
                examples=cap.examples,
                benchmark_scores=cap.benchmark_scores,
            )
            for cap in caps
        ]

    def find_agents_by_capability(
        self,
        category: CapabilityCategory,
        min_confidence: float = 0.0,
    ) -> List[str]:
        """Find agents that have a specific capability."""
        # Include descendants
        categories = self.taxonomy.get_all_descendants(category)
        category_values = [c.value for c in categories]

        results = self.db.query(AgentCapabilityModel).filter(
            AgentCapabilityModel.category.in_(category_values),
            AgentCapabilityModel.confidence_score >= min_confidence,
        ).all()

        return list(set([r.agent_id for r in results]))

    def find_agents_by_capabilities(
        self,
        categories: List[CapabilityCategory],
        match_all: bool = True,
        min_confidence: float = 0.0,
    ) -> List[str]:
        """Find agents matching multiple capabilities."""
        if match_all:
            # Agent must have ALL capabilities
            agent_ids = None
            for category in categories:
                current_ids = set(self.find_agents_by_capability(category, min_confidence))
                if agent_ids is None:
                    agent_ids = current_ids
                else:
                    agent_ids = agent_ids.intersection(current_ids)
            return list(agent_ids) if agent_ids else []
        else:
            # Agent must have ANY capability
            all_ids = set()
            for category in categories:
                all_ids.update(self.find_agents_by_capability(category, min_confidence))
            return list(all_ids)

    def score_agent_capability(
        self,
        agent_id: str,
        category: CapabilityCategory,
        benchmark_results: Dict[str, float],
    ) -> float:
        """Score and update agent capability based on benchmarks."""
        cap = self.db.query(AgentCapabilityModel).filter(
            AgentCapabilityModel.agent_id == agent_id,
            AgentCapabilityModel.category == category.value,
        ).first()

        if not cap:
            return 0.0

        # Calculate weighted score from benchmarks
        weights = {
            "accuracy": 0.3,
            "speed": 0.2,
            "reliability": 0.25,
            "cost_efficiency": 0.15,
            "user_satisfaction": 0.1,
        }

        score = 0.0
        total_weight = 0.0

        for metric, value in benchmark_results.items():
            weight = weights.get(metric, 0.1)
            score += value * weight
            total_weight += weight

        if total_weight > 0:
            score = score / total_weight

        cap.confidence_score = score
        cap.benchmark_scores = benchmark_results
        cap.updated_at = datetime.utcnow()
        self.db.commit()

        return score

    def get_capability_statistics(self, category: CapabilityCategory) -> Dict[str, Any]:
        """Get statistics for a capability across all agents."""
        categories = self.taxonomy.get_all_descendants(category)
        category_values = [c.value for c in categories]

        results = self.db.query(AgentCapabilityModel).filter(
            AgentCapabilityModel.category.in_(category_values)
        ).all()

        if not results:
            return {}

        scores = [r.confidence_score for r in results]

        return {
            "category": category.value,
            "total_agents": len(results),
            "avg_confidence": sum(scores) / len(scores),
            "max_confidence": max(scores),
            "min_confidence": min(scores),
            "top_agents": sorted(
                [(r.agent_id, r.confidence_score) for r in results],
                key=lambda x: x[1],
                reverse=True,
            )[:10],
        }

    def validate_capability_claim(
        self,
        agent_id: str,
        category: CapabilityCategory,
        test_cases: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """Validate an agent's capability claim with test cases."""
        # This would run actual tests against the agent
        # For now, return a validation structure
        return {
            "agent_id": agent_id,
            "category": category.value,
            "test_cases_run": len(test_cases),
            "passed": 0,
            "failed": 0,
            "validation_score": 0.0,
            "validated_at": datetime.utcnow().isoformat(),
        }
