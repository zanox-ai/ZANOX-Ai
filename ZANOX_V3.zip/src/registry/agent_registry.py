"""Unified Agent Registry for Nexus Core V3.

Manages agent registration, lifecycle, and metadata.
"""
import uuid
from datetime import datetime
from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_

from ..schemas.agent import (
    AgentCreate, AgentUpdate, AgentResponse, AgentProvider,
    AgentCapability, AgentModel, AgentCost, AgentConfig, AgentStatus
)
from ..schemas.models import AgentModel as AgentDB, AgentCapabilityModel, AgentModelConfig


class UnifiedAgentRegistry:
    """Central registry for all AI agents."""

    def __init__(self, db_session: Session):
        self.db = db_session

    def register_agent(self, agent_data: AgentCreate) -> AgentResponse:
        """Register a new agent in the marketplace."""
        agent_id = str(uuid.uuid4())

        # Create agent record
        agent = AgentDB(
            id=agent_id,
            name=agent_data.name,
            provider=agent_data.provider.value,
            description=agent_data.description,
            api_key_encrypted=self._encrypt_key(agent_data.api_key),
            base_url=agent_data.base_url,
            status=AgentStatus.ACTIVE,
            tags=agent_data.tags,
            metadata=agent_data.metadata,
            timeout=agent_data.config.timeout,
            retry_attempts=agent_data.config.retry_attempts,
            retry_delay=agent_data.config.retry_delay,
            max_concurrent_requests=agent_data.config.max_concurrent_requests,
            rate_limit_per_minute=agent_data.config.rate_limit_per_minute,
        )

        self.db.add(agent)

        # Add capabilities
        for cap in agent_data.capabilities:
            cap_model = AgentCapabilityModel(
                id=str(uuid.uuid4()),
                agent_id=agent_id,
                category=cap.category.value,
                name=cap.name,
                description=cap.description,
                confidence_score=cap.confidence_score,
                parameters=cap.parameters,
                examples=cap.examples,
                benchmark_scores=cap.benchmark_scores,
            )
            self.db.add(cap_model)

        # Add models
        for i, model in enumerate(agent_data.models):
            model_config = AgentModelConfig(
                id=str(uuid.uuid4()),
                agent_id=agent_id,
                name=model.name,
                version=model.version,
                max_tokens=model.max_tokens,
                context_window=model.context_window,
                supports_streaming=model.supports_streaming,
                supports_functions=model.supports_functions,
                supports_vision=model.supports_vision,
                parameters=model.parameters,
                is_default=(i == 0),
            )
            self.db.add(model_config)

        self.db.commit()
        self.db.refresh(agent)

        return self._to_response(agent)

    def update_agent(self, agent_id: str, agent_data: AgentUpdate) -> Optional[AgentResponse]:
        """Update an existing agent."""
        agent = self.db.query(AgentDB).filter(AgentDB.id == agent_id).first()
        if not agent:
            return None

        if agent_data.name:
            agent.name = agent_data.name
        if agent_data.description is not None:
            agent.description = agent_data.description
        if agent_data.api_key:
            agent.api_key_encrypted = self._encrypt_key(agent_data.api_key)
        if agent_data.base_url:
            agent.base_url = agent_data.base_url
        if agent_data.status:
            agent.status = agent_data.status
        if agent_data.tags:
            agent.tags = agent_data.tags
        if agent_data.metadata:
            agent.metadata = agent_data.metadata
        if agent_data.config:
            agent.timeout = agent_data.config.timeout
            agent.retry_attempts = agent_data.config.retry_attempts
            agent.retry_delay = agent_data.config.retry_delay
            agent.max_concurrent_requests = agent_data.config.max_concurrent_requests
            agent.rate_limit_per_minute = agent_data.config.rate_limit_per_minute

        agent.updated_at = datetime.utcnow()
        self.db.commit()
        self.db.refresh(agent)

        return self._to_response(agent)

    def get_agent(self, agent_id: str) -> Optional[AgentResponse]:
        """Get agent by ID."""
        agent = self.db.query(AgentDB).filter(AgentDB.id == agent_id).first()
        if not agent:
            return None
        return self._to_response(agent)

    def list_agents(
        self,
        status: Optional[AgentStatus] = None,
        provider: Optional[AgentProvider] = None,
        tags: Optional[List[str]] = None,
        search: Optional[str] = None,
        skip: int = 0,
        limit: int = 100,
    ) -> List[AgentResponse]:
        """List agents with optional filtering."""
        query = self.db.query(AgentDB)

        if status:
            query = query.filter(AgentDB.status == status.value)
        if provider:
            query = query.filter(AgentDB.provider == provider.value)
        if tags:
            for tag in tags:
                query = query.filter(AgentDB.tags.contains([tag]))
        if search:
            query = query.filter(
                or_(
                    AgentDB.name.ilike(f"%{search}%"),
                    AgentDB.description.ilike(f"%{search}%"),
                )
            )

        agents = query.offset(skip).limit(limit).all()
        return [self._to_response(agent) for agent in agents]

    def delete_agent(self, agent_id: str) -> bool:
        """Soft delete an agent."""
        agent = self.db.query(AgentDB).filter(AgentDB.id == agent_id).first()
        if not agent:
            return False

        agent.status = AgentStatus.INACTIVE
        agent.is_available = False
        agent.updated_at = datetime.utcnow()
        self.db.commit()
        return True

    def get_agent_by_provider(self, provider: AgentProvider) -> List[AgentResponse]:
        """Get all agents for a specific provider."""
        agents = self.db.query(AgentDB).filter(AgentDB.provider == provider.value).all()
        return [self._to_response(agent) for agent in agents]

    def update_agent_health_score(self, agent_id: str, health_score: float) -> bool:
        """Update agent health score."""
        agent = self.db.query(AgentDB).filter(AgentDB.id == agent_id).first()
        if not agent:
            return False

        agent.health_score = health_score
        agent.last_health_check = datetime.utcnow()
        self.db.commit()
        return True

    def update_agent_metrics(
        self,
        agent_id: str,
        latency_ms: float,
        tokens: int,
        cost: float,
        error: bool = False,
    ) -> bool:
        """Update agent performance metrics."""
        agent = self.db.query(AgentDB).filter(AgentDB.id == agent_id).first()
        if not agent:
            return False

        agent.total_requests += 1
        agent.total_tokens += tokens
        agent.total_cost += cost

        # Update rolling average latency
        if agent.total_requests > 1:
            agent.avg_latency_ms = (
                (agent.avg_latency_ms * (agent.total_requests - 1) + latency_ms)
                / agent.total_requests
            )
        else:
            agent.avg_latency_ms = latency_ms

        # Update error rate
        if error:
            agent.error_rate = (
                (agent.error_rate * (agent.total_requests - 1) + 1)
                / agent.total_requests
            )
        else:
            agent.error_rate = (
                agent.error_rate * (agent.total_requests - 1)
                / agent.total_requests
            )

        agent.updated_at = datetime.utcnow()
        self.db.commit()
        return True

    def _to_response(self, agent: AgentDB) -> AgentResponse:
        """Convert DB model to response schema."""
        capabilities = [
            AgentCapability(
                category=cap.category,
                name=cap.name,
                description=cap.description,
                confidence_score=cap.confidence_score,
                parameters=cap.parameters,
                examples=cap.examples,
                benchmark_scores=cap.benchmark_scores,
            )
            for cap in agent.capabilities
        ]

        models = [
            AgentModel(
                name=m.name,
                version=m.version,
                max_tokens=m.max_tokens,
                context_window=m.context_window,
                supports_streaming=m.supports_streaming,
                supports_functions=m.supports_functions,
                supports_vision=m.supports_vision,
                parameters=m.parameters,
            )
            for m in agent.models
        ]

        return AgentResponse(
            agent_id=agent.id,
            name=agent.name,
            provider=AgentProvider(agent.provider),
            description=agent.description,
            status=AgentStatus(agent.status),
            models=models,
            capabilities=capabilities,
            cost=AgentCost(),  # Populated from config
            config=AgentConfig(
                timeout=agent.timeout,
                retry_attempts=agent.retry_attempts,
                retry_delay=agent.retry_delay,
                max_concurrent_requests=agent.max_concurrent_requests,
                rate_limit_per_minute=agent.rate_limit_per_minute,
            ),
            tags=agent.tags,
            metadata=agent.metadata,
            health_score=agent.health_score,
            rank_score=agent.rank_score,
            total_requests=agent.total_requests,
            total_tokens=agent.total_tokens,
            total_cost=agent.total_cost,
            avg_latency_ms=agent.avg_latency_ms,
            error_rate=agent.error_rate,
            last_health_check=agent.last_health_check,
            is_available=agent.is_available,
            created_at=agent.created_at,
            updated_at=agent.updated_at,
        )

    def _encrypt_key(self, api_key: str) -> str:
        """Encrypt API key (placeholder - implement proper encryption)."""
        # In production, use proper encryption like AWS KMS or HashiCorp Vault
        return f"encrypted:{api_key[:10]}..."
