from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Text, ForeignKey, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel
import uuid

class SecurityPolicyDB(Base):
    __tablename__ = "security_policies"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(255), nullable=False)
    policy_type = Column(String(50), nullable=False)
    rules = Column(JSON, default=list)
    scope = Column(String(50), default="global")
    is_active = Column(Boolean, default=True)
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class SecurityAuditLogDB(Base):
    __tablename__ = "security_audit_logs"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    event_type = Column(String(50), nullable=False)
    user_id = Column(String(255), nullable=True)
    resource_type = Column(String(50), nullable=False)
    resource_id = Column(String(255), nullable=False)
    action = Column(String(50), nullable=False)
    result = Column(String(50), default="success")
    ip_address = Column(String(50), nullable=True)
    user_agent = Column(String(512), nullable=True)
    details = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)

class SecurityPolicyCreate(ZANOXBaseModel):
    name: str
    policy_type: str
    rules: Optional[List[Dict[str, Any]]] = Field(default_factory=list)
    scope: str = "global"
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict)

class SecurityAuditLogCreate(ZANOXBaseModel):
    event_type: str
    user_id: Optional[str] = None
    resource_type: str
    resource_id: str
    action: str
    result: str = "success"
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    details: Optional[Dict[str, Any]] = Field(default_factory=dict)

class SecurityPolicyResponse(ZANOXBaseModel):
    id: str
    name: str
    policy_type: str
    scope: str
    is_active: bool
    created_at: datetime
