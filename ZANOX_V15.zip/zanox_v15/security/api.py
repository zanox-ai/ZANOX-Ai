from typing import Optional, List, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import SecurityPolicyCreate, SecurityAuditLogCreate, SecurityPolicyResponse
from .service import SecurityService

router = APIRouter(prefix="/security", tags=["Security"])

@router.post("/policies", response_model=SecurityPolicyResponse)
async def create_policy(data: SecurityPolicyCreate, db: AsyncSession = Depends(get_db_session)):
    service = SecurityService(db)
    return await service.create_policy(data)

@router.post("/audit")
async def log_audit(data: SecurityAuditLogCreate, db: AsyncSession = Depends(get_db_session)):
    service = SecurityService(db)
    return await service.log_audit(data)

@router.get("/policies", response_model=List[SecurityPolicyResponse])
async def get_policies(policy_type: Optional[str] = Query(None), db: AsyncSession = Depends(get_db_session)):
    service = SecurityService(db)
    return await service.get_policies(policy_type)

@router.get("/audit-logs")
async def get_audit_logs(user_id: Optional[str] = Query(None), resource_type: Optional[str] = Query(None), limit: int = Query(100, ge=1, le=500), db: AsyncSession = Depends(get_db_session)):
    service = SecurityService(db)
    return await service.get_audit_logs(user_id, resource_type, limit)
