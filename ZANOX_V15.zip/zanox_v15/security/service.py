import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from shared.cache import cache
from shared.messaging import messaging
from .models import SecurityPolicyDB, SecurityAuditLogDB, SecurityPolicyCreate, SecurityAuditLogCreate, SecurityPolicyResponse

class SecurityService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_policy(self, data: SecurityPolicyCreate) -> SecurityPolicyResponse:
        db_policy = SecurityPolicyDB(
            id=uuid.uuid4(), name=data.name, policy_type=data.policy_type,
            rules=data.rules, scope=data.scope, metadata=data.metadata
        )
        self.db.add(db_policy)
        await self.db.flush()
        await cache.set(f"security:policy:{db_policy.id}", db_policy.__dict__, ttl=86400)
        await messaging.send_message("security.policy_created", {"policy_id": str(db_policy.id), "name": data.name})
        return SecurityPolicyResponse(
            id=str(db_policy.id), name=db_policy.name, policy_type=db_policy.policy_type,
            scope=db_policy.scope, is_active=db_policy.is_active, created_at=db_policy.created_at
        )

    async def log_audit(self, data: SecurityAuditLogCreate) -> Dict[str, Any]:
        db_log = SecurityAuditLogDB(
            id=uuid.uuid4(), event_type=data.event_type, user_id=data.user_id,
            resource_type=data.resource_type, resource_id=data.resource_id,
            action=data.action, result=data.result, ip_address=data.ip_address,
            user_agent=data.user_agent, details=data.details
        )
        self.db.add(db_log)
        await self.db.flush()
        await messaging.send_message("security.audit", {
            "log_id": str(db_log.id), "event": data.event_type, "resource": data.resource_id, "action": data.action
        })
        return {"log_id": str(db_log.id), "status": "logged"}

    async def get_policies(self, policy_type: Optional[str] = None) -> List[SecurityPolicyResponse]:
        query = select(SecurityPolicyDB).where(SecurityPolicyDB.is_active == True)
        if policy_type: query = query.where(SecurityPolicyDB.policy_type == policy_type)
        result = await self.db.execute(query)
        return [SecurityPolicyResponse(
            id=str(p.id), name=p.name, policy_type=p.policy_type, scope=p.scope, is_active=p.is_active, created_at=p.created_at
        ) for p in result.scalars().all()]

    async def get_audit_logs(self, user_id: Optional[str] = None, resource_type: Optional[str] = None, limit: int = 100) -> List[Dict[str, Any]]:
        query = select(SecurityAuditLogDB)
        if user_id: query = query.where(SecurityAuditLogDB.user_id == user_id)
        if resource_type: query = query.where(SecurityAuditLogDB.resource_type == resource_type)
        query = query.order_by(SecurityAuditLogDB.created_at.desc()).limit(limit)
        result = await self.db.execute(query)
        return [{"id": str(l.id), "event_type": l.event_type, "user_id": l.user_id, "resource_type": l.resource_type, "action": l.action, "result": l.result, "created_at": l.created_at.isoformat()} for l in result.scalars().all()]
