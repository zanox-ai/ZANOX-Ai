from typing import List, Dict, Any
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import RoutingRuleCreate, RoutingDecisionResponse
from .service import RouterService

router = APIRouter(prefix="/router", tags=["Communication Router"])

@router.post("/rules")
async def create_rule(
    rule: RoutingRuleCreate,
    db: AsyncSession = Depends(get_db_session)
):
    service = RouterService(db)
    return await service.create_rule(rule)

@router.post("/route/{message_id}", response_model=RoutingDecisionResponse)
async def route_message(
    message_id: str,
    context: Dict[str, Any],
    db: AsyncSession = Depends(get_db_session)
):
    service = RouterService(db)
    return await service.route_message(message_id, context)

@router.get("/rules")
async def list_rules(
    db: AsyncSession = Depends(get_db_session)
):
    service = RouterService(db)
    return await service.list_rules()
