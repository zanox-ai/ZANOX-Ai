from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Enum as SQLEnum, Text, ForeignKey, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel, CommunicationChannel
import uuid

class RoutingRuleDB(Base):
    __tablename__ = "routing_rules"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(255), nullable=False)
    condition = Column(JSON, nullable=False)
    target_channel = Column(String(50), nullable=False)
    priority = Column(Integer, default=100)
    is_active = Column(Boolean, default=True)
    fallback_channel = Column(String(50), nullable=True)
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class RoutingDecisionDB(Base):
    __tablename__ = "routing_decisions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    message_id = Column(UUID(as_uuid=True), nullable=False)
    selected_channel = Column(String(50), nullable=False)
    rule_id = Column(UUID(as_uuid=True), ForeignKey("routing_rules.id"), nullable=True)
    confidence = Column(Integer, default=100)
    reasoning = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)

class RoutingRuleCreate(ZANOXBaseModel):
    name: str
    condition: Dict[str, Any]
    target_channel: str
    priority: int = 100
    fallback_channel: Optional[str] = None

class RoutingDecisionResponse(ZANOXBaseModel):
    id: str
    message_id: str
    selected_channel: str
    confidence: int
    reasoning: Optional[str] = None
    created_at: datetime
