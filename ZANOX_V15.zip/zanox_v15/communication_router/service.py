import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, and_, or_
from shared.messaging import messaging
from shared.cache import cache
from .models import RoutingRuleDB, RoutingDecisionDB, RoutingRuleCreate, RoutingDecisionResponse

class RouterService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_rule(self, rule: RoutingRuleCreate) -> Dict[str, Any]:
        db_rule = RoutingRuleDB(
            id=uuid.uuid4(),
            name=rule.name,
            condition=rule.condition,
            target_channel=rule.target_channel,
            priority=rule.priority,
            fallback_channel=rule.fallback_channel
        )
        self.db.add(db_rule)
        await self.db.flush()
        await cache.set(f"router:rule:{db_rule.id}", db_rule.__dict__, ttl=86400)
        return {"id": str(db_rule.id), "name": db_rule.name, "status": "created"}

    async def route_message(self, message_id: str, message_context: Dict[str, Any]) -> RoutingDecisionResponse:
        result = await self.db.execute(
            select(RoutingRuleDB)
            .where(RoutingRuleDB.is_active == True)
            .order_by(RoutingRuleDB.priority.asc())
        )
        rules = result.scalars().all()

        selected_channel = None
        matched_rule = None
        confidence = 0
        reasoning = []

        for rule in rules:
            if self._evaluate_condition(rule.condition, message_context):
                selected_channel = rule.target_channel
                matched_rule = rule
                confidence = 95
                reasoning.append(f"Matched rule '{rule.name}' with priority {rule.priority}")
                break

        if not selected_channel:
            selected_channel = message_context.get("preferred_channel", "email")
            confidence = 50
            reasoning.append("No rule matched, using preferred channel fallback")

        decision = RoutingDecisionDB(
            id=uuid.uuid4(),
            message_id=uuid.UUID(message_id),
            selected_channel=selected_channel,
            rule_id=matched_rule.id if matched_rule else None,
            confidence=confidence,
            reasoning="; ".join(reasoning)
        )
        self.db.add(decision)
        await self.db.flush()

        await messaging.send_message("router.decisions", {
            "decision_id": str(decision.id),
            "message_id": message_id,
            "channel": selected_channel,
            "confidence": confidence
        })

        return RoutingDecisionResponse(
            id=str(decision.id),
            message_id=message_id,
            selected_channel=selected_channel,
            confidence=confidence,
            reasoning=decision.reasoning,
            created_at=decision.created_at
        )

    def _evaluate_condition(self, condition: Dict[str, Any], context: Dict[str, Any]) -> bool:
        for key, expected in condition.items():
            actual = context.get(key)
            if isinstance(expected, list):
                if actual not in expected:
                    return False
            elif actual != expected:
                return False
        return True

    async def list_rules(self) -> List[Dict[str, Any]]:
        result = await self.db.execute(select(RoutingRuleDB).where(RoutingRuleDB.is_active == True))
        return [
            {"id": str(r.id), "name": r.name, "channel": r.target_channel, "priority": r.priority}
            for r in result.scalars().all()
        ]
