from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Text, ForeignKey, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel, Priority
import uuid

class NotificationDB(Base):
    __tablename__ = "notifications"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(String(255), nullable=False, index=True)
    title = Column(String(500), nullable=False)
    body = Column(Text, nullable=False)
    notification_type = Column(String(50), nullable=False)
    channels = Column(ARRAY(String), default=list)
    priority = Column(SQLEnum(Priority), default=Priority.MEDIUM)
    action_url = Column(String(1024), nullable=True)
    action_data = Column(JSON, default=dict)
    is_read = Column(Boolean, default=False)
    read_at = Column(DateTime, nullable=True)
    delivered_channels = Column(ARRAY(String), default=list)
    failed_channels = Column(ARRAY(String), default=list)
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime, nullable=True)

class NotificationCreate(ZANOXBaseModel):
    user_id: str
    title: str
    body: str
    notification_type: str
    channels: Optional[List[str]] = Field(default_factory=list)
    priority: Priority = Priority.MEDIUM
    action_url: Optional[str] = None
    action_data: Optional[Dict[str, Any]] = Field(default_factory=dict)
    expires_at: Optional[datetime] = None

class NotificationResponse(ZANOXBaseModel):
    id: str
    user_id: str
    title: str
    body: str
    notification_type: str
    priority: str
    is_read: bool
    read_at: Optional[datetime] = None
    created_at: datetime
    expires_at: Optional[datetime] = None
