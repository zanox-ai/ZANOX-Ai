from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import NotificationCreate, NotificationResponse
from .service import NotificationEngineService

router = APIRouter(prefix="/notifications", tags=["Notification Engine"])

@router.post("/", response_model=NotificationResponse)
async def create_notification(
    notification: NotificationCreate,
    db: AsyncSession = Depends(get_db_session)
):
    service = NotificationEngineService(db)
    return await service.create_notification(notification)

@router.get("/users/{user_id}", response_model=List[NotificationResponse])
async def get_user_notifications(
    user_id: str,
    unread_only: bool = Query(False),
    limit: int = Query(50, ge=1, le=100),
    db: AsyncSession = Depends(get_db_session)
):
    service = NotificationEngineService(db)
    return await service.get_user_notifications(user_id, unread_only, limit)

@router.patch("/{notification_id}/read")
async def mark_read(
    notification_id: str,
    db: AsyncSession = Depends(get_db_session)
):
    service = NotificationEngineService(db)
    await service.mark_read(notification_id)
    return {"status": "marked_read", "notification_id": notification_id}

@router.patch("/{notification_id}/delivered/{channel}")
async def mark_delivered(
    notification_id: str,
    channel: str,
    db: AsyncSession = Depends(get_db_session)
):
    service = NotificationEngineService(db)
    await service.mark_delivered(notification_id, channel)
    return {"status": "delivered", "notification_id": notification_id, "channel": channel}

@router.get("/users/{user_id}/unread-count")
async def get_unread_count(
    user_id: str,
    db: AsyncSession = Depends(get_db_session)
):
    service = NotificationEngineService(db)
    count = await service.get_unread_count(user_id)
    return {"user_id": user_id, "unread_count": count}
