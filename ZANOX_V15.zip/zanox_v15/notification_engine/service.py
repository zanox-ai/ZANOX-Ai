import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from shared.cache import cache
from shared.messaging import messaging
from .models import NotificationDB, NotificationCreate, NotificationResponse

class NotificationEngineService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_notification(self, notification: NotificationCreate) -> NotificationResponse:
        db_notif = NotificationDB(
            id=uuid.uuid4(),
            user_id=notification.user_id,
            title=notification.title,
            body=notification.body,
            notification_type=notification.notification_type,
            channels=notification.channels,
            priority=notification.priority,
            action_url=notification.action_url,
            action_data=notification.action_data,
            expires_at=notification.expires_at
        )
        self.db.add(db_notif)
        await self.db.flush()

        for channel in notification.channels:
            await messaging.send_message(f"notifications.{channel}", {
                "notification_id": str(db_notif.id),
                "user_id": notification.user_id,
                "title": notification.title,
                "body": notification.body,
                "priority": notification.priority.value
            })

        await cache.set(f"notif:{db_notif.id}", db_notif.__dict__, ttl=3600)

        return NotificationResponse(
            id=str(db_notif.id), user_id=db_notif.user_id,
            title=db_notif.title, body=db_notif.body,
            notification_type=db_notif.notification_type,
            priority=db_notif.priority.value, is_read=db_notif.is_read,
            read_at=db_notif.read_at, created_at=db_notif.created_at,
            expires_at=db_notif.expires_at
        )

    async def get_user_notifications(self, user_id: str, unread_only: bool = False, limit: int = 50) -> List[NotificationResponse]:
        query = select(NotificationDB).where(NotificationDB.user_id == user_id)
        if unread_only:
            query = query.where(NotificationDB.is_read == False)
        query = query.order_by(NotificationDB.created_at.desc()).limit(limit)
        result = await self.db.execute(query)
        return [
            NotificationResponse(
                id=str(n.id), user_id=n.user_id, title=n.title, body=n.body,
                notification_type=n.notification_type, priority=n.priority.value,
                is_read=n.is_read, read_at=n.read_at, created_at=n.created_at,
                expires_at=n.expires_at
            ) for n in result.scalars().all()
        ]

    async def mark_read(self, notification_id: str) -> bool:
        await self.db.execute(
            update(NotificationDB)
            .where(NotificationDB.id == uuid.UUID(notification_id))
            .values(is_read=True, read_at=datetime.utcnow())
        )
        await cache.delete(f"notif:{notification_id}")
        return True

    async def mark_delivered(self, notification_id: str, channel: str) -> bool:
        result = await self.db.execute(
            select(NotificationDB).where(NotificationDB.id == uuid.UUID(notification_id))
        )
        notif = result.scalar_one_or_none()
        if not notif:
            return False

        delivered = list(notif.delivered_channels) + [channel]
        await self.db.execute(
            update(NotificationDB)
            .where(NotificationDB.id == uuid.UUID(notification_id))
            .values(delivered_channels=delivered)
        )
        await cache.delete(f"notif:{notification_id}")
        return True

    async def get_unread_count(self, user_id: str) -> int:
        result = await self.db.execute(
            select(NotificationDB)
            .where(NotificationDB.user_id == user_id)
            .where(NotificationDB.is_read == False)
        )
        return len(result.scalars().all())
