import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, func
from shared.cache import cache
from shared.messaging import messaging
from .models import (
    ConversationDB, ConversationMessageDB,
    ConversationCreate, ConversationMessageCreate,
    ConversationResponse, ConversationMessageResponse
)

class ConversationEngineService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_conversation(self, data: ConversationCreate) -> ConversationResponse:
        db_conv = ConversationDB(
            id=uuid.uuid4(),
            title=data.title,
            participants=data.participants,
            channels=data.channels,
            is_group=data.is_group,
            metadata=data.metadata
        )
        self.db.add(db_conv)
        await self.db.flush()

        await messaging.send_message("conversation.created", {
            "conversation_id": str(db_conv.id),
            "participants": db_conv.participants,
            "channels": db_conv.channels
        })

        return ConversationResponse(
            id=str(db_conv.id),
            title=db_conv.title,
            participants=db_conv.participants,
            channels=db_conv.channels,
            status=db_conv.status,
            is_group=db_conv.is_group,
            last_message_at=db_conv.last_message_at,
            last_message_preview=db_conv.last_message_preview,
            message_count=db_conv.message_count,
            unread_count=db_conv.unread_count,
            created_at=db_conv.created_at
        )

    async def add_message(self, data: ConversationMessageCreate) -> ConversationMessageResponse:
        db_msg = ConversationMessageDB(
            id=uuid.uuid4(),
            conversation_id=uuid.UUID(data.conversation_id),
            sender_id=data.sender_id,
            sender_type=data.sender_type,
            channel=data.channel,
            content=data.content,
            content_type=data.content_type,
            attachments=data.attachments,
            reply_to_id=uuid.UUID(data.reply_to_id) if data.reply_to_id else None
        )
        self.db.add(db_msg)

        await self.db.execute(
            update(ConversationDB)
            .where(ConversationDB.id == uuid.UUID(data.conversation_id))
            .values(
                last_message_at=datetime.utcnow(),
                last_message_preview=data.content[:200],
                message_count=ConversationDB.message_count + 1,
                updated_at=datetime.utcnow()
            )
        )
        await self.db.flush()

        await messaging.send_message("conversation.new_message", {
            "conversation_id": data.conversation_id,
            "message_id": str(db_msg.id),
            "sender": data.sender_id,
            "channel": data.channel
        })

        await cache.set(f"conv:msg:{db_msg.id}", db_msg.__dict__, ttl=3600)

        return ConversationMessageResponse(
            id=str(db_msg.id),
            conversation_id=data.conversation_id,
            sender_id=db_msg.sender_id,
            sender_type=db_msg.sender_type,
            channel=db_msg.channel,
            content=db_msg.content,
            content_type=db_msg.content_type,
            is_edited=db_msg.is_edited,
            created_at=db_msg.created_at
        )

    async def get_conversation(self, conversation_id: str) -> Optional[ConversationResponse]:
        result = await self.db.execute(
            select(ConversationDB).where(ConversationDB.id == uuid.UUID(conversation_id))
        )
        conv = result.scalar_one_or_none()
        if not conv:
            return None
        return ConversationResponse(
            id=str(conv.id),
            title=conv.title,
            participants=conv.participants,
            channels=conv.channels,
            status=conv.status,
            is_group=conv.is_group,
            last_message_at=conv.last_message_at,
            last_message_preview=conv.last_message_preview,
            message_count=conv.message_count,
            unread_count=conv.unread_count,
            created_at=conv.created_at
        )

    async def get_messages(self, conversation_id: str, limit: int = 50, offset: int = 0) -> List[ConversationMessageResponse]:
        result = await self.db.execute(
            select(ConversationMessageDB)
            .where(ConversationMessageDB.conversation_id == uuid.UUID(conversation_id))
            .order_by(ConversationMessageDB.created_at.desc())
            .limit(limit).offset(offset)
        )
        return [
            ConversationMessageResponse(
                id=str(m.id), conversation_id=conversation_id,
                sender_id=m.sender_id, sender_type=m.sender_type,
                channel=m.channel, content=m.content,
                content_type=m.content_type, is_edited=m.is_edited,
                created_at=m.created_at
            ) for m in result.scalars().all()
        ]

    async def list_conversations(self, participant_id: Optional[str] = None, limit: int = 50) -> List[ConversationResponse]:
        query = select(ConversationDB).where(ConversationDB.status == "active")
        if participant_id:
            query = query.where(ConversationDB.participants.contains([participant_id]))
        query = query.order_by(ConversationDB.last_message_at.desc().nullslast()).limit(limit)
        result = await self.db.execute(query)
        return [
            ConversationResponse(
                id=str(c.id), title=c.title, participants=c.participants,
                channels=c.channels, status=c.status, is_group=c.is_group,
                last_message_at=c.last_message_at, last_message_preview=c.last_message_preview,
                message_count=c.message_count, unread_count=c.unread_count,
                created_at=c.created_at
            ) for c in result.scalars().all()
        ]
