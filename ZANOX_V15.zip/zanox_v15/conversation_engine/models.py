from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Enum as SQLEnum, Text, ForeignKey, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel, CommunicationChannel
import uuid

class ConversationDB(Base):
    __tablename__ = "conversations"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    title = Column(String(500), nullable=True)
    participants = Column(ARRAY(String), default=list)
    channels = Column(ARRAY(String), default=list)
    status = Column(String(50), default="active")
    is_group = Column(Boolean, default=False)
    metadata = Column(JSON, default=dict)
    last_message_at = Column(DateTime, nullable=True)
    last_message_preview = Column(Text, nullable=True)
    message_count = Column(Integer, default=0)
    unread_count = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class ConversationMessageDB(Base):
    __tablename__ = "conversation_messages"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    conversation_id = Column(UUID(as_uuid=True), ForeignKey("conversations.id"), nullable=False, index=True)
    sender_id = Column(String(255), nullable=False)
    sender_type = Column(String(50), default="user")
    channel = Column(String(50), nullable=False)
    content = Column(Text, nullable=False)
    content_type = Column(String(50), default="text")
    attachments = Column(JSON, default=list)
    metadata = Column(JSON, default=dict)
    is_edited = Column(Boolean, default=False)
    edited_at = Column(DateTime, nullable=True)
    reply_to_id = Column(UUID(as_uuid=True), ForeignKey("conversation_messages.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

class ConversationCreate(ZANOXBaseModel):
    title: Optional[str] = None
    participants: List[str]
    channels: List[str]
    is_group: bool = False
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict)

class ConversationMessageCreate(ZANOXBaseModel):
    conversation_id: str
    sender_id: str
    sender_type: str = "user"
    channel: str
    content: str
    content_type: str = "text"
    attachments: Optional[List[Dict[str, Any]]] = Field(default_factory=list)
    reply_to_id: Optional[str] = None

class ConversationResponse(ZANOXBaseModel):
    id: str
    title: Optional[str] = None
    participants: List[str]
    channels: List[str]
    status: str
    is_group: bool
    last_message_at: Optional[datetime] = None
    last_message_preview: Optional[str] = None
    message_count: int
    unread_count: int
    created_at: datetime

class ConversationMessageResponse(ZANOXBaseModel):
    id: str
    conversation_id: str
    sender_id: str
    sender_type: str
    channel: str
    content: str
    content_type: str
    is_edited: bool
    created_at: datetime
