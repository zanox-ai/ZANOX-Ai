from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import ConversationCreate, ConversationMessageCreate, ConversationResponse, ConversationMessageResponse
from .service import ConversationEngineService

router = APIRouter(prefix="/conversations", tags=["Conversation Engine"])

@router.post("/", response_model=ConversationResponse)
async def create_conversation(
    data: ConversationCreate,
    db: AsyncSession = Depends(get_db_session)
):
    service = ConversationEngineService(db)
    return await service.create_conversation(data)

@router.post("/messages", response_model=ConversationMessageResponse)
async def add_message(
    data: ConversationMessageCreate,
    db: AsyncSession = Depends(get_db_session)
):
    service = ConversationEngineService(db)
    return await service.add_message(data)

@router.get("/{conversation_id}", response_model=ConversationResponse)
async def get_conversation(
    conversation_id: str,
    db: AsyncSession = Depends(get_db_session)
):
    service = ConversationEngineService(db)
    result = await service.get_conversation(conversation_id)
    if not result:
        raise HTTPException(status_code=404, detail="Conversation not found")
    return result

@router.get("/{conversation_id}/messages", response_model=List[ConversationMessageResponse])
async def get_messages(
    conversation_id: str,
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    db: AsyncSession = Depends(get_db_session)
):
    service = ConversationEngineService(db)
    return await service.get_messages(conversation_id, limit, offset)

@router.get("/", response_model=List[ConversationResponse])
async def list_conversations(
    participant_id: Optional[str] = Query(None),
    limit: int = Query(50, ge=1, le=100),
    db: AsyncSession = Depends(get_db_session)
):
    service = ConversationEngineService(db)
    return await service.list_conversations(participant_id, limit)
