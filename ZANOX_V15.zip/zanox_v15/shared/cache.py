import json
import pickle
from typing import Optional, Any, Union
import redis.asyncio as redis
from .config import settings

class RedisCache:
    _instance: Optional[redis.Redis] = None

    @classmethod
    async def get_client(cls) -> redis.Redis:
        if cls._instance is None:
            cls._instance = redis.from_url(
                settings.REDIS_URL,
                decode_responses=False,
                max_connections=settings.REDIS_POOL_SIZE
            )
        return cls._instance

    @classmethod
    async def close(cls) -> None:
        if cls._instance:
            await cls._instance.close()
            cls._instance = None

    @classmethod
    async def get(cls, key: str) -> Optional[Any]:
        client = await cls.get_client()
        data = await client.get(key)
        if data is None:
            return None
        try:
            return pickle.loads(data)
        except Exception:
            return data.decode('utf-8') if isinstance(data, bytes) else data

    @classmethod
    async def set(cls, key: str, value: Any, ttl: Optional[int] = None) -> None:
        client = await cls.get_client()
        serialized = pickle.dumps(value)
        await client.set(key, serialized, ex=ttl)

    @classmethod
    async def delete(cls, key: str) -> None:
        client = await cls.get_client()
        await client.delete(key)

    @classmethod
    async def publish(cls, channel: str, message: Any) -> None:
        client = await cls.get_client()
        await client.publish(channel, json.dumps(message))

    @classmethod
    async def subscribe(cls, channel: str):
        client = await cls.get_client()
        pubsub = client.pubsub()
        await pubsub.subscribe(channel)
        return pubsub

cache = RedisCache()
