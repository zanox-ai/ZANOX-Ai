from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field, ConfigDict
from enum import Enum

class CommunicationChannel(str, Enum):
    EMAIL = "email"
    TELEGRAM = "telegram"
    WHATSAPP = "whatsapp"
    DISCORD = "discord"
    SLACK = "slack"
    TEAMS = "teams"
    MESSENGER = "messenger"
    INSTAGRAM = "instagram"
    LINKEDIN = "linkedin"
    X = "x"
    SMS = "sms"
    PUSH = "push"
    WEB = "web"
    VOICE = "voice"
    VIDEO = "video"

class MessageStatus(str, Enum):
    PENDING = "pending"
    QUEUED = "queued"
    SENT = "sent"
    DELIVERED = "delivered"
    READ = "read"
    FAILED = "failed"
    RETRYING = "retrying"
    CANCELLED = "cancelled"

class MeetingProvider(str, Enum):
    ZOOM = "zoom"
    GOOGLE_MEET = "google_meet"
    TEAMS_MEETINGS = "teams_meetings"
    DISCORD_VOICE = "discord_voice"
    TELEGRAM_CALLS = "telegram_calls"

class Priority(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class Sentiment(str, Enum):
    VERY_NEGATIVE = "very_negative"
    NEGATIVE = "negative"
    NEUTRAL = "neutral"
    POSITIVE = "positive"
    VERY_POSITIVE = "very_positive"

class ZANOXBaseModel(BaseModel):
    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

class TimestampMixin(BaseModel):
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: Optional[datetime] = None
