import os
from typing import Optional, List
from pydantic_settings import BaseSettings

class ZANOXSettings(BaseSettings):
    APP_NAME: str = "ZANOX V15 Communication & Collaboration Layer"
    APP_VERSION: str = "15.0.0"
    DEBUG: bool = False

    # Database
    DATABASE_URL: str = os.getenv("DATABASE_URL", "postgresql+asyncpg://zanox:zanox@localhost:5432/zanox_comm")
    DATABASE_POOL_SIZE: int = 20
    DATABASE_MAX_OVERFLOW: int = 40

    # Redis
    REDIS_URL: str = os.getenv("REDIS_URL", "redis://localhost:6379/0")
    REDIS_POOL_SIZE: int = 50

    # Kafka
    KAFKA_BOOTSTRAP_SERVERS: str = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092")
    KAFKA_CONSUMER_GROUP: str = "zanox-v15-comm"

    # Security
    SECRET_KEY: str = os.getenv("SECRET_KEY", "zanox-v15-secure-key-change-in-production")
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60

    # Channels
    ENABLED_CHANNELS: List[str] = ["email", "telegram", "whatsapp", "discord", "slack", "teams", 
                                    "messenger", "instagram", "linkedin", "x", "sms", "push", 
                                    "web", "voice", "video"]

    # Meeting Providers
    MEETING_PROVIDERS: List[str] = ["zoom", "google_meet", "teams_meetings", "discord_voice", "telegram_calls"]

    # API Keys (loaded from env)
    TWILIO_ACCOUNT_SID: Optional[str] = os.getenv("TWILIO_ACCOUNT_SID")
    TWILIO_AUTH_TOKEN: Optional[str] = os.getenv("TWILIO_AUTH_TOKEN")
    SENDGRID_API_KEY: Optional[str] = os.getenv("SENDGRID_API_KEY")
    TELEGRAM_BOT_TOKEN: Optional[str] = os.getenv("TELEGRAM_BOT_TOKEN")
    WHATSAPP_BUSINESS_TOKEN: Optional[str] = os.getenv("WHATSAPP_BUSINESS_TOKEN")
    DISCORD_BOT_TOKEN: Optional[str] = os.getenv("DISCORD_BOT_TOKEN")
    SLACK_BOT_TOKEN: Optional[str] = os.getenv("SLACK_BOT_TOKEN")
    ZOOM_API_KEY: Optional[str] = os.getenv("ZOOM_API_KEY")
    ZOOM_API_SECRET: Optional[str] = os.getenv("ZOOM_API_SECRET")
    LINKEDIN_CLIENT_ID: Optional[str] = os.getenv("LINKEDIN_CLIENT_ID")
    LINKEDIN_CLIENT_SECRET: Optional[str] = os.getenv("LINKEDIN_CLIENT_SECRET")

    # OpenTelemetry
    OTEL_EXPORTER_OTLP_ENDPOINT: Optional[str] = os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT")

    class Config:
        env_file = ".env"
        case_sensitive = True

settings = ZANOXSettings()
