import json
import asyncio
from typing import Dict, Any, Optional, Callable, List
from aiokafka import AIOKafkaProducer, AIOKafkaConsumer
from .config import settings

class KafkaMessaging:
    _producer: Optional[AIOKafkaProducer] = None
    _consumers: Dict[str, AIOKafkaConsumer] = {}
    _handlers: Dict[str, List[Callable]] = {}

    @classmethod
    async def get_producer(cls) -> AIOKafkaProducer:
        if cls._producer is None:
            cls._producer = AIOKafkaProducer(
                bootstrap_servers=settings.KAFKA_BOOTSTRAP_SERVERS,
                value_serializer=lambda v: json.dumps(v).encode('utf-8'),
                key_serializer=lambda k: k.encode('utf-8') if k else None,
            )
            await cls._producer.start()
        return cls._producer

    @classmethod
    async def send_message(cls, topic: str, message: Dict[str, Any], key: Optional[str] = None) -> None:
        producer = await cls.get_producer()
        await producer.send(topic, value=message, key=key)

    @classmethod
    async def start_consumer(cls, topic: str, group_id: Optional[str] = None) -> AIOKafkaConsumer:
        if topic in cls._consumers:
            return cls._consumers[topic]

        consumer = AIOKafkaConsumer(
            topic,
            bootstrap_servers=settings.KAFKA_BOOTSTRAP_SERVERS,
            group_id=group_id or settings.KAFKA_CONSUMER_GROUP,
            value_deserializer=lambda v: json.loads(v.decode('utf-8')),
            auto_offset_reset='latest',
        )
        await consumer.start()
        cls._consumers[topic] = consumer
        return consumer

    @classmethod
    async def stop_all(cls) -> None:
        if cls._producer:
            await cls._producer.stop()
            cls._producer = None
        for consumer in cls._consumers.values():
            await consumer.stop()
        cls._consumers.clear()

messaging = KafkaMessaging()
