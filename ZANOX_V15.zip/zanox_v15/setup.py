from setuptools import setup, find_packages

setup(
    name="zanox-v15-communication",
    version="15.0.0",
    description="ZANOX V15 Communication & Collaboration Layer",
    author="ZANOX Team",
    packages=find_packages(),
    python_requires=">=3.11",
    install_requires=[
        "fastapi>=0.109.0",
        "uvicorn[standard]>=0.27.0",
        "sqlalchemy[asyncio]>=2.0.25",
        "asyncpg>=0.29.0",
        "redis>=5.0.1",
        "aiokafka>=0.9.0",
        "pydantic>=2.5.3",
        "pydantic-settings>=2.1.0",
        "python-jose[cryptography]>=3.3.0",
        "passlib[bcrypt]>=1.7.4",
        "python-multipart>=0.0.6",
        "httpx>=0.26.0",
        "websockets>=12.0",
        "opentelemetry-api>=1.22.0",
        "opentelemetry-sdk>=1.22.0",
        "opentelemetry-instrumentation-fastapi>=0.43b0",
    ],
)
