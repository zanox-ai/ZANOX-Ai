from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import MeetingCreate, MeetingResponse
from .service import MeetingEngineService

router = APIRouter(prefix="/meetings", tags=["Meeting Engine"])

@router.post("/", response_model=MeetingResponse)
async def create_meeting(
    meeting: MeetingCreate,
    db: AsyncSession = Depends(get_db_session)
):
    service = MeetingEngineService(db)
    return await service.create_meeting(meeting)

@router.post("/{meeting_id}/start")
async def start_meeting(
    meeting_id: str,
    db: AsyncSession = Depends(get_db_session)
):
    service = MeetingEngineService(db)
    return await service.start_meeting(meeting_id)

@router.post("/{meeting_id}/end")
async def end_meeting(
    meeting_id: str,
    db: AsyncSession = Depends(get_db_session)
):
    service = MeetingEngineService(db)
    return await service.end_meeting(meeting_id)

@router.get("/{meeting_id}", response_model=MeetingResponse)
async def get_meeting(
    meeting_id: str,
    db: AsyncSession = Depends(get_db_session)
):
    service = MeetingEngineService(db)
    result = await service.get_meeting(meeting_id)
    if not result:
        raise HTTPException(status_code=404, detail="Meeting not found")
    return result

@router.get("/", response_model=List[MeetingResponse])
async def list_meetings(
    status: Optional[str] = Query(None),
    host_id: Optional[str] = Query(None),
    limit: int = Query(50, ge=1, le=100),
    db: AsyncSession = Depends(get_db_session)
):
    service = MeetingEngineService(db)
    return await service.list_meetings(status, host_id, limit)
