import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from shared.cache import cache
from shared.messaging import messaging
from .models import MeetingDB, MeetingCreate, MeetingResponse

class MeetingEngineService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_meeting(self, meeting: MeetingCreate) -> MeetingResponse:
        db_meeting = MeetingDB(
            id=uuid.uuid4(),
            title=meeting.title,
            description=meeting.description,
            provider=meeting.provider,
            host_id=meeting.host_id,
            participants=meeting.participants,
            scheduled_start=meeting.scheduled_start,
            scheduled_end=meeting.scheduled_end,
            timezone=meeting.timezone,
            recurrence=meeting.recurrence,
            settings=meeting.settings
        )
        self.db.add(db_meeting)
        await self.db.flush()

        await messaging.send_message("meeting.created", {
            "meeting_id": str(db_meeting.id),
            "title": db_meeting.title,
            "provider": db_meeting.provider,
            "start": db_meeting.scheduled_start.isoformat()
        })

        return MeetingResponse(
            id=str(db_meeting.id), title=db_meeting.title,
            provider=db_meeting.provider, meeting_url=db_meeting.meeting_url,
            meeting_id=db_meeting.meeting_id, host_id=db_meeting.host_id,
            participants=db_meeting.participants,
            scheduled_start=db_meeting.scheduled_start,
            scheduled_end=db_meeting.scheduled_end,
            status=db_meeting.status, timezone=db_meeting.timezone,
            created_at=db_meeting.created_at
        )

    async def start_meeting(self, meeting_id: str) -> Dict[str, Any]:
        await self.db.execute(
            update(MeetingDB)
            .where(MeetingDB.id == uuid.UUID(meeting_id))
            .values(actual_start=datetime.utcnow(), status="in_progress", updated_at=datetime.utcnow())
        )

        await messaging.send_message("meeting.started", {
            "meeting_id": meeting_id,
            "timestamp": datetime.utcnow().isoformat()
        })

        return {"meeting_id": meeting_id, "status": "in_progress", "started_at": datetime.utcnow().isoformat()}

    async def end_meeting(self, meeting_id: str) -> Dict[str, Any]:
        await self.db.execute(
            update(MeetingDB)
            .where(MeetingDB.id == uuid.UUID(meeting_id))
            .values(actual_end=datetime.utcnow(), status="completed", updated_at=datetime.utcnow())
        )

        await messaging.send_message("meeting.ended", {
            "meeting_id": meeting_id,
            "timestamp": datetime.utcnow().isoformat()
        })

        return {"meeting_id": meeting_id, "status": "completed", "ended_at": datetime.utcnow().isoformat()}

    async def get_meeting(self, meeting_id: str) -> Optional[MeetingResponse]:
        result = await self.db.execute(
            select(MeetingDB).where(MeetingDB.id == uuid.UUID(meeting_id))
        )
        m = result.scalar_one_or_none()
        if not m:
            return None
        return MeetingResponse(
            id=str(m.id), title=m.title, provider=m.provider,
            meeting_url=m.meeting_url, meeting_id=m.meeting_id,
            host_id=m.host_id, participants=m.participants,
            scheduled_start=m.scheduled_start, scheduled_end=m.scheduled_end,
            status=m.status, timezone=m.timezone, created_at=m.created_at
        )

    async def list_meetings(self, status: Optional[str] = None, host_id: Optional[str] = None, limit: int = 50) -> List[MeetingResponse]:
        query = select(MeetingDB)
        if status:
            query = query.where(MeetingDB.status == status)
        if host_id:
            query = query.where(MeetingDB.host_id == host_id)
        query = query.order_by(MeetingDB.scheduled_start.desc()).limit(limit)
        result = await self.db.execute(query)
        return [
            MeetingResponse(
                id=str(m.id), title=m.title, provider=m.provider,
                meeting_url=m.meeting_url, meeting_id=m.meeting_id,
                host_id=m.host_id, participants=m.participants,
                scheduled_start=m.scheduled_start, scheduled_end=m.scheduled_end,
                status=m.status, timezone=m.timezone, created_at=m.created_at
            ) for m in result.scalars().all()
        ]
