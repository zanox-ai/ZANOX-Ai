from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Enum as SQLEnum, Text, ForeignKey, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel, MeetingProvider, Priority
import uuid

class MeetingDB(Base):
    __tablename__ = "meetings"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    title = Column(String(500), nullable=False)
    description = Column(Text, nullable=True)
    provider = Column(String(50), nullable=False)
    meeting_url = Column(String(1024), nullable=True)
    meeting_id = Column(String(255), nullable=True)
    password = Column(String(100), nullable=True)
    host_id = Column(String(255), nullable=False)
    participants = Column(ARRAY(String), default=list)
    scheduled_start = Column(DateTime, nullable=False)
    scheduled_end = Column(DateTime, nullable=True)
    actual_start = Column(DateTime, nullable=True)
    actual_end = Column(DateTime, nullable=True)
    status = Column(String(50), default="scheduled")
    timezone = Column(String(50), default="UTC")
    recurrence = Column(JSON, default=dict)
    settings = Column(JSON, default=dict)
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class MeetingCreate(ZANOXBaseModel):
    title: str
    description: Optional[str] = None
    provider: str
    host_id: str
    participants: Optional[List[str]] = Field(default_factory=list)
    scheduled_start: datetime
    scheduled_end: Optional[datetime] = None
    timezone: str = "UTC"
    recurrence: Optional[Dict[str, Any]] = Field(default_factory=dict)
    settings: Optional[Dict[str, Any]] = Field(default_factory=dict)

class MeetingResponse(ZANOXBaseModel):
    id: str
    title: str
    provider: str
    meeting_url: Optional[str] = None
    meeting_id: Optional[str] = None
    host_id: str
    participants: List[str]
    scheduled_start: datetime
    scheduled_end: Optional[datetime] = None
    status: str
    timezone: str
    created_at: datetime
