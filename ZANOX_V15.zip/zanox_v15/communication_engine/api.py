from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import CommunicationRequestCreate, CommunicationRequestResponse
from .service import CommunicationEngineService

router = APIRouter(prefix="/communication-engine", tags=["Communication Engine"])

@router.post("/requests", response_model=CommunicationRequestResponse)
async def create_request(
    request: CommunicationRequestCreate,
    db: AsyncSession = Depends(get_db_session),
    user_id: Optional[str] = None
):
    service = CommunicationEngineService(db)
    return await service.create_request(request, user_id)

@router.get("/requests/{request_id}", response_model=CommunicationRequestResponse)
async def get_request(
    request_id: str,
    db: AsyncSession = Depends(get_db_session)
):
    service = CommunicationEngineService(db)
    result = await service.get_request(request_id)
    if not result:
        raise HTTPException(status_code=404, detail="Request not found")
    return result

@router.get("/requests", response_model=List[CommunicationRequestResponse])
async def list_requests(
    status: Optional[str] = Query(None),
    limit: int = Query(50, ge=1, le=100),
    offset: int = Query(0, ge=0),
    db: AsyncSession = Depends(get_db_session)
):
    service = CommunicationEngineService(db)
    return await service.list_requests(status, limit, offset)

@router.patch("/requests/{request_id}/status")
async def update_status(
    request_id: str,
    status: str,
    db: AsyncSession = Depends(get_db_session)
):
    service = CommunicationEngineService(db)
    success = await service.update_status(request_id, status)
    if not success:
        raise HTTPException(status_code=404, detail="Request not found")
    return {"status": "updated", "request_id": request_id, "new_status": status}
