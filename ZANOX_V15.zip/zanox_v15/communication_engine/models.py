from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Enum as SQLEnum, Boolean, Text, ForeignKey
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel, CommunicationChannel, MessageStatus, Priority
import uuid

class CommunicationRequestDB(Base):
    __tablename__ = "communication_requests"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    objective = Column(Text, nullable=False)
    channels = Column(ARRAY(String), nullable=False)
    target_audience = Column(JSON, default=dict)
    content_template = Column(Text)
    scheduled_at = Column(DateTime, nullable=True)
    priority = Column(SQLEnum(Priority), default=Priority.MEDIUM)
    status = Column(String(50), default="pending")
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)

class CommunicationRequestCreate(ZANOXBaseModel):
    objective: str
    channels: List[CommunicationChannel]
    target_audience: Optional[Dict[str, Any]] = Field(default_factory=dict)
    content_template: Optional[str] = None
    scheduled_at: Optional[datetime] = None
    priority: Priority = Priority.MEDIUM

class CommunicationRequestResponse(ZANOXBaseModel):
    id: str
    objective: str
    channels: List[str]
    status: str
    priority: str
    created_at: datetime
