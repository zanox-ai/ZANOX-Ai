import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from shared.messaging import messaging
from shared.cache import cache
from .models import CommunicationRequestDB, CommunicationRequestCreate, CommunicationRequestResponse

class CommunicationEngineService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_request(self, request: CommunicationRequestCreate, user_id: Optional[str] = None) -> CommunicationRequestResponse:
        db_request = CommunicationRequestDB(
            id=uuid.uuid4(),
            objective=request.objective,
            channels=[c.value for c in request.channels],
            target_audience=request.target_audience,
            content_template=request.content_template,
            scheduled_at=request.scheduled_at,
            priority=request.priority,
            status="pending",
            created_by=uuid.UUID(user_id) if user_id else None
        )
        self.db.add(db_request)
        await self.db.flush()

        await messaging.send_message("communication.requests", {
            "request_id": str(db_request.id),
            "objective": db_request.objective,
            "channels": db_request.channels,
            "priority": db_request.priority.value,
            "action": "process"
        })

        await cache.set(f"comm:req:{db_request.id}", db_request.__dict__, ttl=3600)
        return CommunicationRequestResponse(
            id=str(db_request.id),
            objective=db_request.objective,
            channels=db_request.channels,
            status=db_request.status,
            priority=db_request.priority.value,
            created_at=db_request.created_at
        )

    async def get_request(self, request_id: str) -> Optional[CommunicationRequestResponse]:
        cached = await cache.get(f"comm:req:{request_id}")
        if cached:
            return CommunicationRequestResponse(**cached)

        result = await self.db.execute(
            select(CommunicationRequestDB).where(CommunicationRequestDB.id == uuid.UUID(request_id))
        )
        req = result.scalar_one_or_none()
        if not req:
            return None
        return CommunicationRequestResponse(
            id=str(req.id),
            objective=req.objective,
            channels=req.channels,
            status=req.status,
            priority=req.priority.value,
            created_at=req.created_at
        )

    async def list_requests(self, status: Optional[str] = None, limit: int = 50, offset: int = 0) -> List[CommunicationRequestResponse]:
        query = select(CommunicationRequestDB)
        if status:
            query = query.where(CommunicationRequestDB.status == status)
        query = query.order_by(CommunicationRequestDB.created_at.desc()).limit(limit).offset(offset)
        result = await self.db.execute(query)
        return [
            CommunicationRequestResponse(
                id=str(r.id), objective=r.objective, channels=r.channels,
                status=r.status, priority=r.priority.value, created_at=r.created_at
            ) for r in result.scalars().all()
        ]

    async def update_status(self, request_id: str, status: str) -> bool:
        await self.db.execute(
            update(CommunicationRequestDB)
            .where(CommunicationRequestDB.id == uuid.UUID(request_id))
            .values(status=status, updated_at=datetime.utcnow())
        )
        await cache.delete(f"comm:req:{request_id}")
        await messaging.send_message("communication.status_updates", {
            "request_id": request_id,
            "status": status,
            "timestamp": datetime.utcnow().isoformat()
        })
        return True
