from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Text, ForeignKey, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel
import uuid

class GovernanceRuleDB(Base):
    __tablename__ = "governance_rules"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(255), nullable=False)
    rule_type = Column(String(50), nullable=False)
    description = Column(Text, nullable=True)
    conditions = Column(JSON, nullable=False)
    actions = Column(JSON, default=list)
    scope = Column(String(50), default="global")
    is_active = Column(Boolean, default=True)
    enforcement_level = Column(String(50), default="warn")
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class GovernanceRuleCreate(ZANOXBaseModel):
    name: str
    rule_type: str
    description: Optional[str] = None
    conditions: Dict[str, Any]
    actions: Optional[List[Dict[str, Any]]] = Field(default_factory=list)
    scope: str = "global"
    enforcement_level: str = "warn"
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict)

class GovernanceRuleResponse(ZANOXBaseModel):
    id: str
    name: str
    rule_type: str
    scope: str
    enforcement_level: str
    is_active: bool
    created_at: datetime
