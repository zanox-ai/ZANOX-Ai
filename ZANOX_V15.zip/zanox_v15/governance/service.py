import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from shared.cache import cache
from shared.messaging import messaging
from .models import GovernanceRuleDB, GovernanceRuleCreate, GovernanceRuleResponse

class GovernanceService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_rule(self, data: GovernanceRuleCreate) -> GovernanceRuleResponse:
        db_rule = GovernanceRuleDB(
            id=uuid.uuid4(), name=data.name, rule_type=data.rule_type,
            description=data.description, conditions=data.conditions,
            actions=data.actions, scope=data.scope, enforcement_level=data.enforcement_level,
            metadata=data.metadata
        )
        self.db.add(db_rule)
        await self.db.flush()
        await cache.set(f"governance:rule:{db_rule.id}", db_rule.__dict__, ttl=86400)
        await messaging.send_message("governance.rule_created", {"rule_id": str(db_rule.id), "name": data.name})
        return GovernanceRuleResponse(
            id=str(db_rule.id), name=db_rule.name, rule_type=db_rule.rule_type,
            scope=db_rule.scope, enforcement_level=db_rule.enforcement_level,
            is_active=db_rule.is_active, created_at=db_rule.created_at
        )

    async def evaluate_rule(self, rule_id: str, context: Dict[str, Any]) -> Dict[str, Any]:
        result = await self.db.execute(select(GovernanceRuleDB).where(GovernanceRuleDB.id == uuid.UUID(rule_id)))
        rule = result.scalar_one_or_none()
        if not rule: return {"error": "Rule not found"}
        conditions = rule.conditions
        passed = True
        for key, expected in conditions.items():
            actual = context.get(key)
            if isinstance(expected, list):
                if actual not in expected: passed = False
            elif actual != expected: passed = False
        return {
            "rule_id": rule_id, "passed": passed, "enforcement_level": rule.enforcement_level,
            "actions": rule.actions if not passed else []
        }

    async def get_rules(self, rule_type: Optional[str] = None, scope: Optional[str] = None) -> List[GovernanceRuleResponse]:
        query = select(GovernanceRuleDB).where(GovernanceRuleDB.is_active == True)
        if rule_type: query = query.where(GovernanceRuleDB.rule_type == rule_type)
        if scope: query = query.where(GovernanceRuleDB.scope == scope)
        result = await self.db.execute(query)
        return [GovernanceRuleResponse(
            id=str(r.id), name=r.name, rule_type=r.rule_type, scope=r.scope,
            enforcement_level=r.enforcement_level, is_active=r.is_active, created_at=r.created_at
        ) for r in result.scalars().all()]
