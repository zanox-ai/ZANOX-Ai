from typing import Optional, List, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import GovernanceRuleCreate, GovernanceRuleResponse
from .service import GovernanceService

router = APIRouter(prefix="/governance", tags=["Governance"])

@router.post("/rules", response_model=GovernanceRuleResponse)
async def create_rule(data: GovernanceRuleCreate, db: AsyncSession = Depends(get_db_session)):
    service = GovernanceService(db)
    return await service.create_rule(data)

@router.post("/rules/{rule_id}/evaluate")
async def evaluate_rule(rule_id: str, context: Dict[str, Any], db: AsyncSession = Depends(get_db_session)):
    service = GovernanceService(db)
    result = await service.evaluate_rule(rule_id, context)
    if "error" in result: raise HTTPException(status_code=404, detail=result["error"])
    return result

@router.get("/rules", response_model=List[GovernanceRuleResponse])
async def get_rules(rule_type: Optional[str] = Query(None), scope: Optional[str] = Query(None), db: AsyncSession = Depends(get_db_session)):
    service = GovernanceService(db)
    return await service.get_rules(rule_type, scope)
