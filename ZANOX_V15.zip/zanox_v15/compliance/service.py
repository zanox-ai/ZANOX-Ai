import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from shared.cache import cache
from shared.messaging import messaging
from .models import ComplianceCheckDB, ComplianceCheckCreate, ComplianceCheckResponse

class ComplianceService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_check(self, data: ComplianceCheckCreate) -> ComplianceCheckResponse:
        db_check = ComplianceCheckDB(
            id=uuid.uuid4(), check_name=data.check_name, regulation=data.regulation,
            findings=data.findings, severity=data.severity, remediation=data.remediation, metadata=data.metadata
        )
        self.db.add(db_check)
        await self.db.flush()
        await messaging.send_message("compliance.check_created", {
            "check_id": str(db_check.id), "name": data.check_name, "regulation": data.regulation
        })
        return ComplianceCheckResponse(
            id=str(db_check.id), check_name=db_check.check_name, regulation=db_check.regulation,
            status=db_check.status, severity=db_check.severity,
            checked_at=db_check.checked_at, resolved_at=db_check.resolved_at, created_at=db_check.created_at
        )

    async def run_check(self, check_id: str) -> Dict[str, Any]:
        result = await self.db.execute(select(ComplianceCheckDB).where(ComplianceCheckDB.id == uuid.UUID(check_id)))
        check = result.scalar_one_or_none()
        if not check: return {"error": "Check not found"}
        status = "passed" if not check.findings else "failed"
        await self.db.execute(
            update(ComplianceCheckDB).where(ComplianceCheckDB.id == uuid.UUID(check_id))
            .values(status=status, checked_at=datetime.utcnow(), updated_at=datetime.utcnow())
        )
        await messaging.send_message("compliance.check_run", {"check_id": check_id, "status": status})
        return {"check_id": check_id, "status": status, "findings_count": len(check.findings)}

    async def resolve_check(self, check_id: str) -> bool:
        await self.db.execute(
            update(ComplianceCheckDB).where(ComplianceCheckDB.id == uuid.UUID(check_id))
            .values(status="resolved", resolved_at=datetime.utcnow(), updated_at=datetime.utcnow())
        )
        await messaging.send_message("compliance.check_resolved", {"check_id": check_id})
        return True

    async def get_checks(self, regulation: Optional[str] = None, status: Optional[str] = None, limit: int = 50) -> List[ComplianceCheckResponse]:
        query = select(ComplianceCheckDB)
        if regulation: query = query.where(ComplianceCheckDB.regulation == regulation)
        if status: query = query.where(ComplianceCheckDB.status == status)
        query = query.order_by(ComplianceCheckDB.created_at.desc()).limit(limit)
        result = await self.db.execute(query)
        return [ComplianceCheckResponse(
            id=str(c.id), check_name=c.check_name, regulation=c.regulation,
            status=c.status, severity=c.severity,
            checked_at=c.checked_at, resolved_at=c.resolved_at, created_at=c.created_at
        ) for c in result.scalars().all()]

    async def get_compliance_summary(self) -> Dict[str, Any]:
        result = await self.db.execute(select(ComplianceCheckDB))
        checks = result.scalars().all()
        by_status = {}
        by_regulation = {}
        for c in checks:
            by_status[c.status] = by_status.get(c.status, 0) + 1
            by_regulation[c.regulation] = by_regulation.get(c.regulation, 0) + 1
        return {"total_checks": len(checks), "by_status": by_status, "by_regulation": by_regulation}
