from typing import Optional, List, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import ComplianceCheckCreate, ComplianceCheckResponse
from .service import ComplianceService

router = APIRouter(prefix="/compliance", tags=["Compliance"])

@router.post("/checks", response_model=ComplianceCheckResponse)
async def create_check(data: ComplianceCheckCreate, db: AsyncSession = Depends(get_db_session)):
    service = ComplianceService(db)
    return await service.create_check(data)

@router.post("/checks/{check_id}/run")
async def run_check(check_id: str, db: AsyncSession = Depends(get_db_session)):
    service = ComplianceService(db)
    result = await service.run_check(check_id)
    if "error" in result: raise HTTPException(status_code=404, detail=result["error"])
    return result

@router.patch("/checks/{check_id}/resolve")
async def resolve_check(check_id: str, db: AsyncSession = Depends(get_db_session)):
    service = ComplianceService(db)
    await service.resolve_check(check_id)
    return {"status": "resolved", "check_id": check_id}

@router.get("/checks", response_model=List[ComplianceCheckResponse])
async def get_checks(regulation: Optional[str] = Query(None), status: Optional[str] = Query(None), limit: int = Query(50, ge=1, le=100), db: AsyncSession = Depends(get_db_session)):
    service = ComplianceService(db)
    return await service.get_checks(regulation, status, limit)

@router.get("/summary")
async def get_compliance_summary(db: AsyncSession = Depends(get_db_session)):
    service = ComplianceService(db)
    return await service.get_compliance_summary()
