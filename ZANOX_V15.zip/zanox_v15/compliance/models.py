from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Text, ForeignKey, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel
import uuid

class ComplianceCheckDB(Base):
    __tablename__ = "compliance_checks"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    check_name = Column(String(255), nullable=False)
    regulation = Column(String(100), nullable=False)
    status = Column(String(50), default="pending")
    findings = Column(JSON, default=list)
    severity = Column(String(50), default="info")
    remediation = Column(Text, nullable=True)
    checked_at = Column(DateTime, nullable=True)
    resolved_at = Column(DateTime, nullable=True)
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)

class ComplianceCheckCreate(ZANOXBaseModel):
    check_name: str
    regulation: str
    findings: Optional[List[Dict[str, Any]]] = Field(default_factory=list)
    severity: str = "info"
    remediation: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict)

class ComplianceCheckResponse(ZANOXBaseModel):
    id: str
    check_name: str
    regulation: str
    status: str
    severity: str
    checked_at: Optional[datetime] = None
    resolved_at: Optional[datetime] = None
    created_at: datetime
