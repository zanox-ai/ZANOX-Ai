from typing import Optional, List, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import SentimentAnalysisCreate, SentimentAnalysisResponse
from .service import SentimentAnalysisService

router = APIRouter(prefix="/sentiment-analysis", tags=["Sentiment Analysis"])

@router.post("/analyze", response_model=SentimentAnalysisResponse)
async def analyze(data: SentimentAnalysisCreate, db: AsyncSession = Depends(get_db_session)):
    service = SentimentAnalysisService(db)
    return await service.analyze(data)

@router.get("/trends/{entity_id}")
async def get_sentiment_trend(entity_id: str, days: int = Query(30, ge=1, le=365), db: AsyncSession = Depends(get_db_session)):
    service = SentimentAnalysisService(db)
    return await service.get_sentiment_trend(entity_id, days)

@router.get("/aggregate")
async def get_aggregate_sentiment(entity_type: Optional[str] = Query(None), days: int = Query(30, ge=1, le=365), db: AsyncSession = Depends(get_db_session)):
    service = SentimentAnalysisService(db)
    return await service.get_aggregate_sentiment(entity_type, days)
