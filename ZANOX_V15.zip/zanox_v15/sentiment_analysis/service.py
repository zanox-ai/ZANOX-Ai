import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from shared.cache import cache
from shared.messaging import messaging
from .models import SentimentRecordDB, SentimentAnalysisCreate, SentimentAnalysisResponse

class SentimentAnalysisService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def analyze(self, data: SentimentAnalysisCreate) -> SentimentAnalysisResponse:
        db_rec = SentimentRecordDB(
            id=uuid.uuid4(), entity_type=data.entity_type, entity_id=data.entity_id,
            text=data.text, sentiment=data.sentiment, confidence=data.confidence,
            emotions=data.emotions, keywords=data.keywords, language=data.language, metadata=data.metadata
        )
        self.db.add(db_rec)
        await self.db.flush()
        await messaging.send_message("sentiment.analyzed", {
            "record_id": str(db_rec.id), "entity": data.entity_id, "sentiment": data.sentiment
        })
        return SentimentAnalysisResponse(
            id=str(db_rec.id), entity_type=db_rec.entity_type, entity_id=db_rec.entity_id,
            sentiment=db_rec.sentiment.value, confidence=db_rec.confidence,
            emotions=db_rec.emotions, keywords=db_rec.keywords, created_at=db_rec.created_at
        )

    async def get_sentiment_trend(self, entity_id: str, days: int = 30) -> List[Dict[str, Any]]:
        from_date = datetime.utcnow() - __import__('datetime').timedelta(days=days)
        result = await self.db.execute(
            select(SentimentRecordDB)
            .where(SentimentRecordDB.entity_id == entity_id)
            .where(SentimentRecordDB.created_at >= from_date)
            .order_by(SentimentRecordDB.created_at.asc())
        )
        return [{"date": r.created_at.isoformat(), "sentiment": r.sentiment.value, "confidence": r.confidence} for r in result.scalars().all()]

    async def get_aggregate_sentiment(self, entity_type: Optional[str] = None, days: int = 30) -> Dict[str, Any]:
        from_date = datetime.utcnow() - __import__('datetime').timedelta(days=days)
        query = select(SentimentRecordDB).where(SentimentRecordDB.created_at >= from_date)
        if entity_type: query = query.where(SentimentRecordDB.entity_type == entity_type)
        result = await self.db.execute(query)
        records = result.scalars().all()
        if not records: return {"total": 0, "distribution": {}}
        distribution = {}
        for r in records:
            s = r.sentiment.value
            distribution[s] = distribution.get(s, 0) + 1
        avg_confidence = sum(r.confidence for r in records) / len(records)
        return {"total": len(records), "distribution": distribution, "avg_confidence": round(avg_confidence, 3)}
