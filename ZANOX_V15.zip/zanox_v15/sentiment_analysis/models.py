from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Text, ForeignKey, Float, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel, Sentiment
import uuid

class SentimentRecordDB(Base):
    __tablename__ = "sentiment_records"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    entity_type = Column(String(50), nullable=False)
    entity_id = Column(String(255), nullable=False, index=True)
    text = Column(Text, nullable=False)
    sentiment = Column(SQLEnum(Sentiment), default=Sentiment.NEUTRAL)
    confidence = Column(Float, default=0.0)
    emotions = Column(JSON, default=dict)
    keywords = Column(ARRAY(String), default=list)
    language = Column(String(10), default="en")
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)

class SentimentAnalysisCreate(ZANOXBaseModel):
    entity_type: str
    entity_id: str
    text: str
    sentiment: str = "neutral"
    confidence: float = 0.0
    emotions: Optional[Dict[str, Any]] = Field(default_factory=dict)
    keywords: Optional[List[str]] = Field(default_factory=list)
    language: str = "en"
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict)

class SentimentAnalysisResponse(ZANOXBaseModel):
    id: str
    entity_type: str
    entity_id: str
    sentiment: str
    confidence: float
    emotions: Dict[str, Any]
    keywords: List[str]
    created_at: datetime
