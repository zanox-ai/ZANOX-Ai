import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, text
from shared.cache import cache
from .models import SearchIndexDB, SearchQuery, SearchResult

class ConversationSearchService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def index_content(self, entity_type: str, entity_id: str, content: str, 
                         conversation_id: Optional[str] = None, metadata: Optional[Dict] = None) -> str:
        db_index = SearchIndexDB(
            id=uuid.uuid4(),
            entity_type=entity_type,
            entity_id=uuid.UUID(entity_id),
            conversation_id=uuid.UUID(conversation_id) if conversation_id else None,
            content=content,
            metadata=metadata or {}
        )
        self.db.add(db_index)
        await self.db.flush()

        await self.db.execute(
            text("UPDATE search_index SET search_vector = to_tsvector('english', content) WHERE id = :id"),
            {"id": db_index.id}
        )
        return str(db_index.id)

    async def search(self, query: SearchQuery) -> List[SearchResult]:
        sql = "SELECT id, entity_type, entity_id, conversation_id, content, " +               "ts_rank(search_vector, plainto_tsquery('english', :query)) as rank, " +               "metadata, created_at FROM search_index " +               "WHERE search_vector @@ plainto_tsquery('english', :query)"
        params = {"query": query.query}

        if query.entity_types:
            sql += " AND entity_type = ANY(:entity_types)"
            params["entity_types"] = query.entity_types
        if query.conversation_id:
            sql += " AND conversation_id = :conv_id"
            params["conv_id"] = uuid.UUID(query.conversation_id)
        if query.date_from:
            sql += " AND created_at >= :date_from"
            params["date_from"] = query.date_from
        if query.date_to:
            sql += " AND created_at <= :date_to"
            params["date_to"] = query.date_to

        sql += " ORDER BY rank DESC LIMIT :limit"
        params["limit"] = query.limit

        result = await self.db.execute(text(sql), params)
        rows = result.all()

        return [
            SearchResult(
                id=str(r.id),
                entity_type=r.entity_type,
                entity_id=str(r.entity_id),
                conversation_id=str(r.conversation_id) if r.conversation_id else None,
                content=r.content,
                relevance_score=float(r.rank),
                metadata=r.metadata,
                created_at=r.created_at
            ) for r in rows
        ]

    async def search_by_sender(self, sender_id: str, limit: int = 50) -> List[SearchResult]:
        result = await self.db.execute(
            select(SearchIndexDB)
            .where(SearchIndexDB.metadata.contains({"sender_id": sender_id}))
            .order_by(SearchIndexDB.created_at.desc())
            .limit(limit)
        )
        return [
            SearchResult(
                id=str(r.id), entity_type=r.entity_type, entity_id=str(r.entity_id),
                conversation_id=str(r.conversation_id) if r.conversation_id else None,
                content=r.content, relevance_score=1.0, metadata=r.metadata, created_at=r.created_at
            ) for r in result.scalars().all()
        ]
