from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Text, ForeignKey, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY, TSVECTOR
from shared.database import Base
from shared.models import ZANOXBaseModel
import uuid

class SearchIndexDB(Base):
    __tablename__ = "search_index"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    entity_type = Column(String(50), nullable=False, index=True)
    entity_id = Column(UUID(as_uuid=True), nullable=False, index=True)
    conversation_id = Column(UUID(as_uuid=True), ForeignKey("conversations.id"), nullable=True, index=True)
    content = Column(Text, nullable=False)
    search_vector = Column(TSVECTOR, nullable=True)
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)

class SearchQuery(ZANOXBaseModel):
    query: str
    entity_types: Optional[List[str]] = Field(default_factory=list)
    conversation_id: Optional[str] = None
    date_from: Optional[datetime] = None
    date_to: Optional[datetime] = None
    limit: int = 20

class SearchResult(ZANOXBaseModel):
    id: str
    entity_type: str
    entity_id: str
    conversation_id: Optional[str] = None
    content: str
    relevance_score: float
    metadata: Dict[str, Any]
    created_at: datetime
