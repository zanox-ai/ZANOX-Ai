from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import SearchQuery, SearchResult
from .service import ConversationSearchService

router = APIRouter(prefix="/conversation-search", tags=["Conversation Search"])

@router.post("/search", response_model=List[SearchResult])
async def search(
    query: SearchQuery,
    db: AsyncSession = Depends(get_db_session)
):
    service = ConversationSearchService(db)
    return await service.search(query)

@router.post("/index")
async def index_content(
    entity_type: str,
    entity_id: str,
    content: str,
    conversation_id: str = None,
    metadata: dict = None,
    db: AsyncSession = Depends(get_db_session)
):
    service = ConversationSearchService(db)
    index_id = await service.index_content(entity_type, entity_id, content, conversation_id, metadata)
    return {"status": "indexed", "index_id": index_id}

@router.get("/by-sender/{sender_id}", response_model=List[SearchResult])
async def search_by_sender(
    sender_id: str,
    limit: int = 50,
    db: AsyncSession = Depends(get_db_session)
):
    service = ConversationSearchService(db)
    return await service.search_by_sender(sender_id, limit)
