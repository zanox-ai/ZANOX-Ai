# ZANOX V15 API Documentation

## Base URL
http://localhost:8000

## Authentication
Bearer token JWT authentication

## Endpoints by Module

### Communication Engine
- POST /communication-engine/requests
- GET /communication-engine/requests/{request_id}
- GET /communication-engine/requests
- PATCH /communication-engine/requests/{request_id}/status

### Communication Orchestrator
- POST /orchestrator/plans
- POST /orchestrator/plans/{plan_id}/execute-next
- GET /orchestrator/plans/{plan_id}

### Communication Router
- POST /router/rules
- POST /router/route/{message_id}
- GET /router/rules

### Channel Manager
- GET /channels/
- GET /channels/{channel_type}
- POST /channels/{channel_type}/health-check
- PATCH /channels/{channel_type}

### Unified Inbox
- POST /inbox/messages
- GET /inbox/messages
- PATCH /inbox/messages/{message_id}/read
- PATCH /inbox/messages/{message_id}/flag
- PATCH /inbox/messages/{message_id}/archive
- POST /inbox/messages/{message_id}/labels

### Unified Outbox
- POST /outbox/messages
- GET /outbox/pending
- PATCH /outbox/messages/{message_id}/sent
- PATCH /outbox/messages/{message_id}/failed
- PATCH /outbox/messages/{message_id}/delivered

### Conversation Engine
- POST /conversations/
- POST /conversations/messages
- GET /conversations/{conversation_id}
- GET /conversations/{conversation_id}/messages
- GET /conversations/

### Conversation Memory
- POST /conversation-memory/snapshots
- GET /conversation-memory/conversations/{conversation_id}/latest
- GET /conversation-memory/conversations/{conversation_id}/history
- POST /conversation-memory/conversations/{conversation_id}/context

### Conversation Search
- POST /conversation-search/search
- POST /conversation-search/index
- GET /conversation-search/by-sender/{sender_id}

### Conversation Analytics
- POST /conversation-analytics/reports
- GET /conversation-analytics/reports/{report_id}
- GET /conversation-analytics/conversations/{conversation_id}/stats
- GET /conversation-analytics/dashboard

### Messaging Engine
- POST /messaging-engine/templates
- POST /messaging-engine/render/{template_name}
- POST /messaging-engine/send
- GET /messaging-engine/templates

### Broadcast Engine
- POST /broadcast/campaigns
- POST /broadcast/campaigns/{campaign_id}/execute
- GET /broadcast/campaigns/{campaign_id}
- GET /broadcast/campaigns

### Campaign Engine
- POST /campaigns/
- POST /campaigns/{campaign_id}/launch
- PATCH /campaigns/{campaign_id}/metrics
- GET /campaigns/{campaign_id}
- GET /campaigns/

### Follow-Up Engine
- POST /followup/rules
- POST /followup/schedule
- GET /followup/pending
- POST /followup/tasks/{task_id}/execute

### Notification Engine
- POST /notifications/
- GET /notifications/users/{user_id}
- PATCH /notifications/{notification_id}/read
- PATCH /notifications/{notification_id}/delivered/{channel}
- GET /notifications/users/{user_id}/unread-count

### Alert Engine
- POST /alerts/rules
- POST /alerts/trigger
- PATCH /alerts/events/{event_id}/acknowledge
- PATCH /alerts/events/{event_id}/resolve
- GET /alerts/active

### Meeting Engine
- POST /meetings/
- POST /meetings/{meeting_id}/start
- POST /meetings/{meeting_id}/end
- GET /meetings/{meeting_id}
- GET /meetings/

### Meeting Scheduler
- POST /meeting-scheduler/availability
- POST /meeting-scheduler/find-slots
- POST /meeting-scheduler/requests
- POST /meeting-scheduler/requests/{request_id}/confirm/{slot_index}

### Meeting Recorder
- POST /recordings/start
- POST /recordings/{recording_id}/stop
- GET /recordings/{recording_id}
- GET /recordings/

### Transcription Engine
- POST /transcriptions/
- POST /transcriptions/{transcription_id}/segments
- GET /transcriptions/{transcription_id}
- GET /transcriptions/meetings/{meeting_id}

### Meeting Summary
- POST /meeting-summaries/
- GET /meeting-summaries/meetings/{meeting_id}
- GET /meeting-summaries/

### Meeting Intelligence
- POST /meeting-intelligence/insights
- GET /meeting-intelligence/meetings/{meeting_id}/insights
- GET /meeting-intelligence/trending-topics

### Call Management
- POST /calls/
- POST /calls/{call_id}/start
- POST /calls/{call_id}/end
- GET /calls/{call_id}
- GET /calls/

### Contacts
- POST /contacts/
- GET /contacts/{contact_id}
- PATCH /contacts/{contact_id}
- GET /contacts/search/{query}
- GET /contacts/

### CRM Connector
- POST /crm-connector/connections
- POST /crm-connector/connections/{connection_id}/sync
- GET /crm-connector/connections/{connection_id}
- GET /crm-connector/connections

### Customer Communication
- POST /customer-communication/interactions
- PATCH /customer-communication/interactions/{interaction_id}/status
- GET /customer-communication/interactions/{interaction_id}
- GET /customer-communication/interactions

### Community Management
- POST /communities/
- PATCH /communities/{community_id}/metrics
- GET /communities/{community_id}
- GET /communities/

### Team Collaboration
- POST /teams/
- POST /teams/{team_id}/members/{member_id}
- GET /teams/{team_id}
- GET /teams/

### Internal Messaging
- POST /internal-messaging/send
- PATCH /internal-messaging/messages/{message_id}/read
- GET /internal-messaging/inbox/{user_id}
- GET /internal-messaging/sent/{user_id}

### Presence
- POST /presence/update
- GET /presence/users/{user_id}
- GET /presence/online

### Status
- POST /status/
- GET /status/users/{user_id}
- GET /status/recent

### Task Extraction
- POST /task-extraction/extract
- PATCH /task-extraction/tasks/{task_id}/confirm
- GET /task-extraction/tasks

### Action Items
- POST /action-items/
- PATCH /action-items/{action_id}/complete
- PATCH /action-items/{action_id}/assign
- GET /action-items/{action_id}
- GET /action-items/

### Relationship Intelligence
- POST /relationship-intelligence/relationships
- POST /relationship-intelligence/relationships/{relationship_id}/interact
- GET /relationship-intelligence/entities/{entity_id}/relationships
- GET /relationship-intelligence/entities/{entity_id}/network

### Sentiment Analysis
- POST /sentiment-analysis/analyze
- GET /sentiment-analysis/trends/{entity_id}
- GET /sentiment-analysis/aggregate

### Translation
- POST /translation/translate
- GET /translation/{translation_id}
- GET /translation/entities/{entity_type}/{entity_id}

### Voice Communication
- POST /voice-communication/sessions
- POST /voice-communication/sessions/{session_id}/start
- POST /voice-communication/sessions/{session_id}/end
- GET /voice-communication/sessions/{session_id}
- GET /voice-communication/sessions

### Video Communication
- POST /video-communication/sessions
- POST /video-communication/sessions/{session_id}/start
- POST /video-communication/sessions/{session_id}/end
- PATCH /video-communication/sessions/{session_id}/screen-share
- GET /video-communication/sessions/{session_id}
- GET /video-communication/sessions

### Monitoring
- POST /monitoring/events
- GET /monitoring/events
- GET /monitoring/health-summary

### Analytics
- POST /analytics/metrics
- GET /analytics/metrics/{metric_name}
- GET /analytics/metrics/{metric_name}/aggregate
- GET /analytics/communication-overview

### Security
- POST /security/policies
- POST /security/audit
- GET /security/policies
- GET /security/audit-logs

### Governance
- POST /governance/rules
- POST /governance/rules/{rule_id}/evaluate
- GET /governance/rules

### Compliance
- POST /compliance/checks
- POST /compliance/checks/{check_id}/run
- PATCH /compliance/checks/{check_id}/resolve
- GET /compliance/checks
- GET /compliance/summary

### Deployment
- POST /deployment/
- POST /deployment/{deployment_id}/deploy
- POST /deployment/{deployment_id}/rollback
- GET /deployment/{deployment_id}
- GET /deployment/
