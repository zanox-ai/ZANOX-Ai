from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Enum as SQLEnum, Text, ForeignKey, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel, CommunicationChannel, Priority
import uuid

class OrchestrationPlanDB(Base):
    __tablename__ = "orchestration_plans"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    request_id = Column(UUID(as_uuid=True), ForeignKey("communication_requests.id"), nullable=False)
    steps = Column(JSON, default=list)
    current_step = Column(Integer, default=0)
    status = Column(String(50), default="pending")
    channel_sequence = Column(ARRAY(String))
    timing_strategy = Column(String(50), default="immediate")
    retry_policy = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    completed_at = Column(DateTime, nullable=True)

class OrchestrationStep(BaseModel):
    step_number: int
    channel: str
    action: str
    delay_seconds: int = 0
    conditions: Optional[Dict[str, Any]] = None
    fallback_channel: Optional[str] = None

class OrchestrationPlanCreate(ZANOXBaseModel):
    request_id: str
    steps: List[OrchestrationStep]
    timing_strategy: str = "immediate"
    retry_policy: Optional[Dict[str, Any]] = Field(default_factory=dict)

class OrchestrationPlanResponse(ZANOXBaseModel):
    id: str
    request_id: str
    current_step: int
    status: str
    total_steps: int
    created_at: datetime
