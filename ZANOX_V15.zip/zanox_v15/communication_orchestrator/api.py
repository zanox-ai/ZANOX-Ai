from typing import Optional, List, Dict, Any
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import OrchestrationPlanCreate, OrchestrationPlanResponse
from .service import OrchestratorService

router = APIRouter(prefix="/orchestrator", tags=["Communication Orchestrator"])

@router.post("/plans", response_model=OrchestrationPlanResponse)
async def create_plan(
    plan: OrchestrationPlanCreate,
    db: AsyncSession = Depends(get_db_session)
):
    service = OrchestratorService(db)
    return await service.create_plan(plan)

@router.post("/plans/{plan_id}/execute-next")
async def execute_next_step(
    plan_id: str,
    db: AsyncSession = Depends(get_db_session)
):
    service = OrchestratorService(db)
    result = await service.execute_next_step(plan_id)
    if "error" in result:
        raise HTTPException(status_code=404, detail=result["error"])
    return result

@router.get("/plans/{plan_id}", response_model=OrchestrationPlanResponse)
async def get_plan(
    plan_id: str,
    db: AsyncSession = Depends(get_db_session)
):
    service = OrchestratorService(db)
    result = await service.get_plan(plan_id)
    if not result:
        raise HTTPException(status_code=404, detail="Plan not found")
    return result
