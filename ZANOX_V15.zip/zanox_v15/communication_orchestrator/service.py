import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from shared.messaging import messaging
from shared.cache import cache
from .models import OrchestrationPlanDB, OrchestrationPlanCreate, OrchestrationPlanResponse, OrchestrationStep

class OrchestratorService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_plan(self, plan: OrchestrationPlanCreate) -> OrchestrationPlanResponse:
        db_plan = OrchestrationPlanDB(
            id=uuid.uuid4(),
            request_id=uuid.UUID(plan.request_id),
            steps=[s.model_dump() for s in plan.steps],
            current_step=0,
            status="pending",
            channel_sequence=[s.channel for s in plan.steps],
            timing_strategy=plan.timing_strategy,
            retry_policy=plan.retry_policy
        )
        self.db.add(db_plan)
        await self.db.flush()

        await messaging.send_message("orchestrator.plans", {
            "plan_id": str(db_plan.id),
            "request_id": plan.request_id,
            "action": "execute",
            "steps": db_plan.steps
        })

        return OrchestrationPlanResponse(
            id=str(db_plan.id),
            request_id=plan.request_id,
            current_step=0,
            status="pending",
            total_steps=len(plan.steps),
            created_at=db_plan.created_at
        )

    async def execute_next_step(self, plan_id: str) -> Dict[str, Any]:
        result = await self.db.execute(
            select(OrchestrationPlanDB).where(OrchestrationPlanDB.id == uuid.UUID(plan_id))
        )
        plan = result.scalar_one_or_none()
        if not plan:
            return {"error": "Plan not found"}

        steps = plan.steps
        if plan.current_step >= len(steps):
            await self.db.execute(
                update(OrchestrationPlanDB)
                .where(OrchestrationPlanDB.id == uuid.UUID(plan_id))
                .values(status="completed", completed_at=datetime.utcnow())
            )
            return {"status": "completed", "plan_id": plan_id}

        current_step = steps[plan.current_step]
        plan.current_step += 1

        await messaging.send_message(f"orchestrator.steps.{current_step['channel']}", {
            "plan_id": plan_id,
            "step": current_step,
            "sequence": plan.current_step
        })

        await self.db.execute(
            update(OrchestrationPlanDB)
            .where(OrchestrationPlanDB.id == uuid.UUID(plan_id))
            .values(current_step=plan.current_step, updated_at=datetime.utcnow())
        )

        return {
            "status": "executing",
            "plan_id": plan_id,
            "current_step": plan.current_step,
            "channel": current_step["channel"],
            "action": current_step["action"]
        }

    async def get_plan(self, plan_id: str) -> Optional[OrchestrationPlanResponse]:
        result = await self.db.execute(
            select(OrchestrationPlanDB).where(OrchestrationPlanDB.id == uuid.UUID(plan_id))
        )
        plan = result.scalar_one_or_none()
        if not plan:
            return None
        return OrchestrationPlanResponse(
            id=str(plan.id),
            request_id=str(plan.request_id),
            current_step=plan.current_step,
            status=plan.status,
            total_steps=len(plan.steps),
            created_at=plan.created_at
        )
