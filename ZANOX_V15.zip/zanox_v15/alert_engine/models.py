from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Text, ForeignKey, Boolean, Float
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel, Priority
import uuid

class AlertRuleDB(Base):
    __tablename__ = "alert_rules"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(255), nullable=False)
    alert_type = Column(String(50), nullable=False)
    condition = Column(JSON, nullable=False)
    severity = Column(SQLEnum(Priority), default=Priority.HIGH)
    channels = Column(ARRAY(String), nullable=False)
    recipients = Column(ARRAY(String), nullable=False)
    cooldown_minutes = Column(Integer, default=60)
    is_active = Column(Boolean, default=True)
    last_triggered_at = Column(DateTime, nullable=True)
    trigger_count = Column(Integer, default=0)
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class AlertEventDB(Base):
    __tablename__ = "alert_events"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    rule_id = Column(UUID(as_uuid=True), ForeignKey("alert_rules.id"), nullable=False)
    severity = Column(String(50), nullable=False)
    title = Column(String(500), nullable=False)
    description = Column(Text, nullable=True)
    source = Column(String(255), nullable=True)
    context = Column(JSON, default=dict)
    status = Column(String(50), default="active")
    acknowledged_by = Column(String(255), nullable=True)
    acknowledged_at = Column(DateTime, nullable=True)
    resolved_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

class AlertRuleCreate(ZANOXBaseModel):
    name: str
    alert_type: str
    condition: Dict[str, Any]
    severity: Priority = Priority.HIGH
    channels: List[str]
    recipients: List[str]
    cooldown_minutes: int = 60

class AlertEventCreate(ZANOXBaseModel):
    rule_id: str
    severity: str
    title: str
    description: Optional[str] = None
    source: Optional[str] = None
    context: Optional[Dict[str, Any]] = Field(default_factory=dict)

class AlertEventResponse(ZANOXBaseModel):
    id: str
    rule_id: str
    severity: str
    title: str
    status: str
    created_at: datetime
    acknowledged_at: Optional[datetime] = None
    resolved_at: Optional[datetime] = None
