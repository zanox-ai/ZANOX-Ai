import uuid
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from shared.cache import cache
from shared.messaging import messaging
from .models import AlertRuleDB, AlertEventDB, AlertRuleCreate, AlertEventCreate, AlertEventResponse

class AlertEngineService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_rule(self, rule: AlertRuleCreate) -> Dict[str, Any]:
        db_rule = AlertRuleDB(
            id=uuid.uuid4(),
            name=rule.name,
            alert_type=rule.alert_type,
            condition=rule.condition,
            severity=rule.severity,
            channels=rule.channels,
            recipients=rule.recipients,
            cooldown_minutes=rule.cooldown_minutes
        )
        self.db.add(db_rule)
        await self.db.flush()
        await cache.set(f"alert:rule:{db_rule.id}", db_rule.__dict__, ttl=86400)
        return {"id": str(db_rule.id), "name": db_rule.name, "status": "created"}

    async def trigger_alert(self, event: AlertEventCreate) -> AlertEventResponse:
        result = await self.db.execute(
            select(AlertRuleDB).where(AlertRuleDB.id == uuid.UUID(event.rule_id))
        )
        rule = result.scalar_one_or_none()
        if not rule:
            raise ValueError("Rule not found")

        if rule.last_triggered_at:
            cooldown = timedelta(minutes=rule.cooldown_minutes)
            if datetime.utcnow() - rule.last_triggered_at < cooldown:
                raise ValueError("Alert cooldown active")

        db_event = AlertEventDB(
            id=uuid.uuid4(),
            rule_id=uuid.UUID(event.rule_id),
            severity=event.severity,
            title=event.title,
            description=event.description,
            source=event.source,
            context=event.context
        )
        self.db.add(db_event)

        rule.trigger_count += 1
        rule.last_triggered_at = datetime.utcnow()
        await self.db.execute(
            update(AlertRuleDB)
            .where(AlertRuleDB.id == rule.id)
            .values(trigger_count=rule.trigger_count, last_triggered_at=rule.last_triggered_at)
        )
        await self.db.flush()

        for channel in rule.channels:
            for recipient in rule.recipients:
                await messaging.send_message(f"alerts.{channel}", {
                    "event_id": str(db_event.id),
                    "recipient": recipient,
                    "title": event.title,
                    "severity": event.severity,
                    "body": event.description or ""
                })

        return AlertEventResponse(
            id=str(db_event.id), rule_id=event.rule_id,
            severity=db_event.severity, title=db_event.title,
            status=db_event.status, created_at=db_event.created_at,
            acknowledged_at=db_event.acknowledged_at,
            resolved_at=db_event.resolved_at
        )

    async def acknowledge_alert(self, event_id: str, user_id: str) -> bool:
        await self.db.execute(
            update(AlertEventDB)
            .where(AlertEventDB.id == uuid.UUID(event_id))
            .values(
                status="acknowledged",
                acknowledged_by=user_id,
                acknowledged_at=datetime.utcnow()
            )
        )
        return True

    async def resolve_alert(self, event_id: str) -> bool:
        await self.db.execute(
            update(AlertEventDB)
            .where(AlertEventDB.id == uuid.UUID(event_id))
            .values(status="resolved", resolved_at=datetime.utcnow())
        )
        return True

    async def get_active_alerts(self, limit: int = 50) -> List[AlertEventResponse]:
        result = await self.db.execute(
            select(AlertEventDB)
            .where(AlertEventDB.status == "active")
            .order_by(AlertEventDB.created_at.desc())
            .limit(limit)
        )
        return [
            AlertEventResponse(
                id=str(e.id), rule_id=str(e.rule_id), severity=e.severity,
                title=e.title, status=e.status, created_at=e.created_at,
                acknowledged_at=e.acknowledged_at, resolved_at=e.resolved_at
            ) for e in result.scalars().all()
        ]
