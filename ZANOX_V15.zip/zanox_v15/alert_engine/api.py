from typing import Optional, List, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import AlertRuleCreate, AlertEventCreate, AlertEventResponse
from .service import AlertEngineService

router = APIRouter(prefix="/alerts", tags=["Alert Engine"])

@router.post("/rules")
async def create_rule(
    rule: AlertRuleCreate,
    db: AsyncSession = Depends(get_db_session)
):
    service = AlertEngineService(db)
    return await service.create_rule(rule)

@router.post("/trigger", response_model=AlertEventResponse)
async def trigger_alert(
    event: AlertEventCreate,
    db: AsyncSession = Depends(get_db_session)
):
    service = AlertEngineService(db)
    try:
        return await service.trigger_alert(event)
    except ValueError as e:
        raise HTTPException(status_code=429, detail=str(e))

@router.patch("/events/{event_id}/acknowledge")
async def acknowledge_alert(
    event_id: str,
    user_id: str,
    db: AsyncSession = Depends(get_db_session)
):
    service = AlertEngineService(db)
    await service.acknowledge_alert(event_id, user_id)
    return {"status": "acknowledged", "event_id": event_id, "by": user_id}

@router.patch("/events/{event_id}/resolve")
async def resolve_alert(
    event_id: str,
    db: AsyncSession = Depends(get_db_session)
):
    service = AlertEngineService(db)
    await service.resolve_alert(event_id)
    return {"status": "resolved", "event_id": event_id}

@router.get("/active", response_model=List[AlertEventResponse])
async def get_active_alerts(
    limit: int = Query(50, ge=1, le=100),
    db: AsyncSession = Depends(get_db_session)
):
    service = AlertEngineService(db)
    return await service.get_active_alerts(limit)
