from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Text, ForeignKey, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel
import uuid

class ConversationMemoryDB(Base):
    __tablename__ = "conversation_memories"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    conversation_id = Column(UUID(as_uuid=True), ForeignKey("conversations.id"), nullable=False, index=True)
    summary = Column(Text, nullable=True)
    key_points = Column(ARRAY(String), default=list)
    decisions = Column(ARRAY(String), default=list)
    action_items = Column(ARRAY(String), default=list)
    topics = Column(ARRAY(String), default=list)
    sentiment_history = Column(JSON, default=list)
    participant_engagement = Column(JSON, default=dict)
    context_window = Column(JSON, default=list)
    metadata = Column(JSON, default=dict)
    version = Column(Integer, default=1)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class MemorySnapshotCreate(ZANOXBaseModel):
    conversation_id: str
    summary: Optional[str] = None
    key_points: Optional[List[str]] = Field(default_factory=list)
    decisions: Optional[List[str]] = Field(default_factory=list)
    action_items: Optional[List[str]] = Field(default_factory=list)
    topics: Optional[List[str]] = Field(default_factory=list)
    sentiment_history: Optional[List[Dict[str, Any]]] = Field(default_factory=list)
    participant_engagement: Optional[Dict[str, Any]] = Field(default_factory=dict)
    context_window: Optional[List[Dict[str, Any]]] = Field(default_factory=list)

class MemorySnapshotResponse(ZANOXBaseModel):
    id: str
    conversation_id: str
    summary: Optional[str] = None
    key_points: List[str]
    decisions: List[str]
    action_items: List[str]
    topics: List[str]
    version: int
    created_at: datetime
    updated_at: datetime
