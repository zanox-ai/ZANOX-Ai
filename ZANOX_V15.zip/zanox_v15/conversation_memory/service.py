import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from shared.cache import cache
from shared.messaging import messaging
from .models import ConversationMemoryDB, MemorySnapshotCreate, MemorySnapshotResponse

class ConversationMemoryService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_snapshot(self, data: MemorySnapshotCreate) -> MemorySnapshotResponse:
        existing = await self.db.execute(
            select(ConversationMemoryDB).where(ConversationMemoryDB.conversation_id == uuid.UUID(data.conversation_id)).order_by(ConversationMemoryDB.version.desc())
        )
        last = existing.scalar_one_or_none()
        version = (last.version + 1) if last else 1
        db_mem = ConversationMemoryDB(
            id=uuid.uuid4(), conversation_id=uuid.UUID(data.conversation_id),
            summary=data.summary, key_points=data.key_points, decisions=data.decisions,
            action_items=data.action_items, topics=data.topics, sentiment_history=data.sentiment_history,
            participant_engagement=data.participant_engagement, context_window=data.context_window, version=version
        )
        self.db.add(db_mem)
        await self.db.flush()
        await cache.set(f"memory:{data.conversation_id}:latest", db_mem.__dict__, ttl=7200)
        return MemorySnapshotResponse(
            id=str(db_mem.id), conversation_id=data.conversation_id, summary=db_mem.summary,
            key_points=db_mem.key_points, decisions=db_mem.decisions, action_items=db_mem.action_items,
            topics=db_mem.topics, version=db_mem.version, created_at=db_mem.created_at, updated_at=db_mem.updated_at
        )

    async def get_latest(self, conversation_id: str) -> Optional[MemorySnapshotResponse]:
        cached = await cache.get(f"memory:{conversation_id}:latest")
        if cached: return MemorySnapshotResponse(**cached)
        result = await self.db.execute(
            select(ConversationMemoryDB).where(ConversationMemoryDB.conversation_id == uuid.UUID(conversation_id)).order_by(ConversationMemoryDB.version.desc()).limit(1)
        )
        mem = result.scalar_one_or_none()
        if not mem: return None
        return MemorySnapshotResponse(
            id=str(mem.id), conversation_id=conversation_id, summary=mem.summary,
            key_points=mem.key_points, decisions=mem.decisions, action_items=mem.action_items,
            topics=mem.topics, version=mem.version, created_at=mem.created_at, updated_at=mem.updated_at
        )

    async def get_history(self, conversation_id: str, limit: int = 10) -> List[MemorySnapshotResponse]:
        result = await self.db.execute(
            select(ConversationMemoryDB).where(ConversationMemoryDB.conversation_id == uuid.UUID(conversation_id)).order_by(ConversationMemoryDB.version.desc()).limit(limit)
        )
        return [MemorySnapshotResponse(
            id=str(m.id), conversation_id=conversation_id, summary=m.summary,
            key_points=m.key_points, decisions=m.decisions, action_items=m.action_items,
            topics=m.topics, version=m.version, created_at=m.created_at, updated_at=m.updated_at
        ) for m in result.scalars().all()]

    async def update_context(self, conversation_id: str, context_entry: Dict[str, Any]) -> bool:
        result = await self.db.execute(
            select(ConversationMemoryDB).where(ConversationMemoryDB.conversation_id == uuid.UUID(conversation_id)).order_by(ConversationMemoryDB.version.desc()).limit(1)
        )
        mem = result.scalar_one_or_none()
        if not mem: return False
        window = list(mem.context_window)
        window.append(context_entry)
        if len(window) > 100: window = window[-100:]
        await self.db.execute(
            update(ConversationMemoryDB).where(ConversationMemoryDB.id == mem.id).values(context_window=window, updated_at=datetime.utcnow())
        )
        await cache.delete(f"memory:{conversation_id}:latest")
        return True
