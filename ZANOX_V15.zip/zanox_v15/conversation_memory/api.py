from typing import List, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import MemorySnapshotCreate, MemorySnapshotResponse
from .service import ConversationMemoryService

router = APIRouter(prefix="/conversation-memory", tags=["Conversation Memory"])

@router.post("/snapshots", response_model=MemorySnapshotResponse)
async def create_snapshot(data: MemorySnapshotCreate, db: AsyncSession = Depends(get_db_session)):
    service = ConversationMemoryService(db)
    return await service.create_snapshot(data)

@router.get("/conversations/{conversation_id}/latest", response_model=MemorySnapshotResponse)
async def get_latest(conversation_id: str, db: AsyncSession = Depends(get_db_session)):
    service = ConversationMemoryService(db)
    result = await service.get_latest(conversation_id)
    if not result: raise HTTPException(status_code=404, detail="No memory found for conversation")
    return result

@router.get("/conversations/{conversation_id}/history", response_model=List[MemorySnapshotResponse])
async def get_history(conversation_id: str, limit: int = Query(10, ge=1, le=50), db: AsyncSession = Depends(get_db_session)):
    service = ConversationMemoryService(db)
    return await service.get_history(conversation_id, limit)

@router.post("/conversations/{conversation_id}/context")
async def update_context(conversation_id: str, context_entry: Dict[str, Any], db: AsyncSession = Depends(get_db_session)):
    service = ConversationMemoryService(db)
    success = await service.update_context(conversation_id, context_entry)
    if not success: raise HTTPException(status_code=404, detail="Conversation memory not found")
    return {"status": "context_updated", "conversation_id": conversation_id}
