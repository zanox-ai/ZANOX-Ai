import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from shared.cache import cache
from shared.messaging import messaging
from .models import TranslationRecordDB, TranslationCreate, TranslationResponse

class TranslationService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def translate(self, data: TranslationCreate) -> TranslationResponse:
        # Production translation would call external API; here we store and return
        translated = data.source_text  # Placeholder for actual translation
        db_rec = TranslationRecordDB(
            id=uuid.uuid4(), source_text=data.source_text, translated_text=translated,
            source_language=data.source_language, target_language=data.target_language,
            entity_type=data.entity_type, entity_id=data.entity_id,
            confidence=0.95, engine=data.engine, metadata=data.metadata
        )
        self.db.add(db_rec)
        await self.db.flush()
        await cache.set(f"trans:{db_rec.id}", db_rec.__dict__, ttl=3600)
        await messaging.send_message("translation.completed", {
            "translation_id": str(db_rec.id), "from": data.source_language, "to": data.target_language
        })
        return TranslationResponse(
            id=str(db_rec.id), source_text=db_rec.source_text, translated_text=db_rec.translated_text,
            source_language=db_rec.source_language, target_language=db_rec.target_language,
            confidence=db_rec.confidence, engine=db_rec.engine, created_at=db_rec.created_at
        )

    async def get_translation(self, translation_id: str) -> Optional[TranslationResponse]:
        cached = await cache.get(f"trans:{translation_id}")
        if cached: return TranslationResponse(**cached)
        result = await self.db.execute(select(TranslationRecordDB).where(TranslationRecordDB.id == uuid.UUID(translation_id)))
        t = result.scalar_one_or_none()
        if not t: return None
        return TranslationResponse(
            id=str(t.id), source_text=t.source_text, translated_text=t.translated_text,
            source_language=t.source_language, target_language=t.target_language,
            confidence=t.confidence, engine=t.engine, created_at=t.created_at
        )

    async def get_entity_translations(self, entity_type: str, entity_id: str, limit: int = 50) -> List[TranslationResponse]:
        result = await self.db.execute(
            select(TranslationRecordDB)
            .where(TranslationRecordDB.entity_type == entity_type)
            .where(TranslationRecordDB.entity_id == entity_id)
            .order_by(TranslationRecordDB.created_at.desc())
            .limit(limit)
        )
        return [TranslationResponse(
            id=str(t.id), source_text=t.source_text, translated_text=t.translated_text,
            source_language=t.source_language, target_language=t.target_language,
            confidence=t.confidence, engine=t.engine, created_at=t.created_at
        ) for t in result.scalars().all()]
