from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import TranslationCreate, TranslationResponse
from .service import TranslationService

router = APIRouter(prefix="/translation", tags=["Translation Engine"])

@router.post("/translate", response_model=TranslationResponse)
async def translate(data: TranslationCreate, db: AsyncSession = Depends(get_db_session)):
    service = TranslationService(db)
    return await service.translate(data)

@router.get("/{translation_id}", response_model=TranslationResponse)
async def get_translation(translation_id: str, db: AsyncSession = Depends(get_db_session)):
    service = TranslationService(db)
    result = await service.get_translation(translation_id)
    if not result: raise HTTPException(status_code=404, detail="Translation not found")
    return result

@router.get("/entities/{entity_type}/{entity_id}", response_model=List[TranslationResponse])
async def get_entity_translations(entity_type: str, entity_id: str, limit: int = Query(50, ge=1, le=100), db: AsyncSession = Depends(get_db_session)):
    service = TranslationService(db)
    return await service.get_entity_translations(entity_type, entity_id, limit)
