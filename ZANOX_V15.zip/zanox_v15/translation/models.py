from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Text, ForeignKey, Float, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel
import uuid

class TranslationRecordDB(Base):
    __tablename__ = "translation_records"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    source_text = Column(Text, nullable=False)
    translated_text = Column(Text, nullable=False)
    source_language = Column(String(10), nullable=False)
    target_language = Column(String(10), nullable=False)
    entity_type = Column(String(50), nullable=True)
    entity_id = Column(String(255), nullable=True, index=True)
    confidence = Column(Float, nullable=True)
    engine = Column(String(50), default="auto")
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)

class TranslationCreate(ZANOXBaseModel):
    source_text: str
    source_language: str
    target_language: str
    entity_type: Optional[str] = None
    entity_id: Optional[str] = None
    engine: str = "auto"
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict)

class TranslationResponse(ZANOXBaseModel):
    id: str
    source_text: str
    translated_text: str
    source_language: str
    target_language: str
    confidence: Optional[float] = None
    engine: str
    created_at: datetime
