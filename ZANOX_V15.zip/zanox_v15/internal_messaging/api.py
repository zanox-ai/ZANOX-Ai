from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import InternalMessageCreate, InternalMessageResponse
from .service import InternalMessagingService

router = APIRouter(prefix="/internal-messaging", tags=["Internal Messaging"])

@router.post("/send", response_model=InternalMessageResponse)
async def send_message(data: InternalMessageCreate, db: AsyncSession = Depends(get_db_session)):
    service = InternalMessagingService(db)
    return await service.send_message(data)

@router.patch("/messages/{message_id}/read")
async def mark_read(message_id: str, db: AsyncSession = Depends(get_db_session)):
    service = InternalMessagingService(db)
    await service.mark_read(message_id)
    return {"status": "marked_read", "message_id": message_id}

@router.get("/inbox/{user_id}", response_model=List[InternalMessageResponse])
async def get_inbox(user_id: str, unread_only: bool = Query(False), limit: int = Query(50, ge=1, le=100), db: AsyncSession = Depends(get_db_session)):
    service = InternalMessagingService(db)
    return await service.get_inbox(user_id, unread_only, limit)

@router.get("/sent/{user_id}", response_model=List[InternalMessageResponse])
async def get_sent(user_id: str, limit: int = Query(50, ge=1, le=100), db: AsyncSession = Depends(get_db_session)):
    service = InternalMessagingService(db)
    return await service.get_sent(user_id, limit)
