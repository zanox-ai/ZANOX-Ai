from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Text, ForeignKey, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel
import uuid

class InternalMessageDB(Base):
    __tablename__ = "internal_messages"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    sender_id = Column(String(255), nullable=False, index=True)
    recipient_id = Column(String(255), nullable=False, index=True)
    subject = Column(String(500), nullable=True)
    body = Column(Text, nullable=False)
    attachments = Column(JSON, default=list)
    priority = Column(String(50), default="normal")
    is_read = Column(Boolean, default=False)
    read_at = Column(DateTime, nullable=True)
    is_urgent = Column(Boolean, default=False)
    thread_id = Column(String(255), nullable=True, index=True)
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)

class InternalMessageCreate(ZANOXBaseModel):
    sender_id: str
    recipient_id: str
    subject: Optional[str] = None
    body: str
    attachments: Optional[List[Dict[str, Any]]] = Field(default_factory=list)
    priority: str = "normal"
    is_urgent: bool = False
    thread_id: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict)

class InternalMessageResponse(ZANOXBaseModel):
    id: str
    sender_id: str
    recipient_id: str
    subject: Optional[str] = None
    body: str
    priority: str
    is_read: bool
    is_urgent: bool
    created_at: datetime
    read_at: Optional[datetime] = None
