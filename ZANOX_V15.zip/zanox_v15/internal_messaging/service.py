import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from shared.cache import cache
from shared.messaging import messaging
from .models import InternalMessageDB, InternalMessageCreate, InternalMessageResponse

class InternalMessagingService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def send_message(self, data: InternalMessageCreate) -> InternalMessageResponse:
        db_msg = InternalMessageDB(
            id=uuid.uuid4(), sender_id=data.sender_id, recipient_id=data.recipient_id,
            subject=data.subject, body=data.body, attachments=data.attachments,
            priority=data.priority, is_urgent=data.is_urgent, thread_id=data.thread_id, metadata=data.metadata
        )
        self.db.add(db_msg)
        await self.db.flush()
        await messaging.send_message("internal.message", {
            "message_id": str(db_msg.id), "sender": data.sender_id, "recipient": data.recipient_id, "urgent": data.is_urgent
        })
        return InternalMessageResponse(
            id=str(db_msg.id), sender_id=db_msg.sender_id, recipient_id=db_msg.recipient_id,
            subject=db_msg.subject, body=db_msg.body, priority=db_msg.priority,
            is_read=db_msg.is_read, is_urgent=db_msg.is_urgent, created_at=db_msg.created_at, read_at=db_msg.read_at
        )

    async def mark_read(self, message_id: str) -> bool:
        await self.db.execute(update(InternalMessageDB).where(InternalMessageDB.id == uuid.UUID(message_id)).values(is_read=True, read_at=datetime.utcnow()))
        await cache.delete(f"internal:{message_id}")
        return True

    async def get_inbox(self, user_id: str, unread_only: bool = False, limit: int = 50) -> List[InternalMessageResponse]:
        query = select(InternalMessageDB).where(InternalMessageDB.recipient_id == user_id)
        if unread_only: query = query.where(InternalMessageDB.is_read == False)
        query = query.order_by(InternalMessageDB.created_at.desc()).limit(limit)
        result = await self.db.execute(query)
        return [InternalMessageResponse(
            id=str(m.id), sender_id=m.sender_id, recipient_id=m.recipient_id,
            subject=m.subject, body=m.body, priority=m.priority,
            is_read=m.is_read, is_urgent=m.is_urgent, created_at=m.created_at, read_at=m.read_at
        ) for m in result.scalars().all()]

    async def get_sent(self, user_id: str, limit: int = 50) -> List[InternalMessageResponse]:
        result = await self.db.execute(
            select(InternalMessageDB).where(InternalMessageDB.sender_id == user_id).order_by(InternalMessageDB.created_at.desc()).limit(limit)
        )
        return [InternalMessageResponse(
            id=str(m.id), sender_id=m.sender_id, recipient_id=m.recipient_id,
            subject=m.subject, body=m.body, priority=m.priority,
            is_read=m.is_read, is_urgent=m.is_urgent, created_at=m.created_at, read_at=m.read_at
        ) for m in result.scalars().all()]
