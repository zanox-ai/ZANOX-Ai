from typing import Optional, List, Dict, Any
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import AvailabilitySlotCreate, SchedulingRequestCreate, SuggestedSlot
from .service import MeetingSchedulerService

router = APIRouter(prefix="/meeting-scheduler", tags=["Meeting Scheduler"])

@router.post("/availability")
async def set_availability(
    slot: AvailabilitySlotCreate,
    db: AsyncSession = Depends(get_db_session)
):
    service = MeetingSchedulerService(db)
    return await service.set_availability(slot)

@router.post("/find-slots", response_model=List[SuggestedSlot])
async def find_slots(
    request: SchedulingRequestCreate,
    db: AsyncSession = Depends(get_db_session)
):
    service = MeetingSchedulerService(db)
    return await service.find_slots(request)

@router.post("/requests")
async def create_request(
    request: SchedulingRequestCreate,
    db: AsyncSession = Depends(get_db_session)
):
    service = MeetingSchedulerService(db)
    return await service.create_scheduling_request(request)

@router.post("/requests/{request_id}/confirm/{slot_index}")
async def confirm_slot(
    request_id: str,
    slot_index: int,
    db: AsyncSession = Depends(get_db_session)
):
    service = MeetingSchedulerService(db)
    result = await service.confirm_slot(request_id, slot_index)
    if "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])
    return result
