import uuid
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, and_
from shared.cache import cache
from shared.messaging import messaging
from .models import AvailabilitySlotDB, SchedulingRequestDB, AvailabilitySlotCreate, SchedulingRequestCreate, SuggestedSlot

class MeetingSchedulerService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def set_availability(self, slot: AvailabilitySlotCreate) -> Dict[str, Any]:
        db_slot = AvailabilitySlotDB(
            id=uuid.uuid4(),
            user_id=slot.user_id,
            start_time=slot.start_time,
            end_time=slot.end_time,
            timezone=slot.timezone,
            is_available=slot.is_available,
            recurrence_pattern=slot.recurrence_pattern
        )
        self.db.add(db_slot)
        await self.db.flush()
        return {"id": str(db_slot.id), "user_id": slot.user_id, "status": "created"}

    async def find_slots(self, request: SchedulingRequestCreate) -> List[SuggestedSlot]:
        participant_ids = request.participant_ids + [request.requester_id]
        duration = timedelta(minutes=request.duration_minutes)

        start = request.preferred_start or datetime.utcnow()
        end = request.preferred_end or (start + timedelta(days=7))

        slots = []
        current = start
        while current < end:
            slot_end = current + duration
            available = []
            for pid in participant_ids:
                result = await self.db.execute(
                    select(AvailabilitySlotDB)
                    .where(AvailabilitySlotDB.user_id == pid)
                    .where(AvailabilitySlotDB.is_available == True)
                    .where(AvailabilitySlotDB.start_time <= current)
                    .where(AvailabilitySlotDB.end_time >= slot_end)
                )
                if result.scalar_one_or_none():
                    available.append(pid)

            if len(available) == len(participant_ids):
                confidence = 1.0
            elif len(available) >= len(participant_ids) * 0.5:
                confidence = 0.5
            else:
                confidence = 0.0

            if confidence > 0:
                slots.append(SuggestedSlot(
                    start_time=current,
                    end_time=slot_end,
                    available_participants=available,
                    confidence=confidence
                ))

            current += timedelta(minutes=30)
            if len(slots) >= 10:
                break

        return slots

    async def create_scheduling_request(self, request: SchedulingRequestCreate) -> Dict[str, Any]:
        suggested = await self.find_slots(request)

        db_request = SchedulingRequestDB(
            id=uuid.uuid4(),
            requester_id=request.requester_id,
            participant_ids=request.participant_ids,
            duration_minutes=request.duration_minutes,
            preferred_start=request.preferred_start,
            preferred_end=request.preferred_end,
            timezone=request.timezone,
            suggested_slots=[s.model_dump() for s in suggested]
        )
        self.db.add(db_request)
        await self.db.flush()

        return {
            "request_id": str(db_request.id),
            "suggested_slots": [s.model_dump() for s in suggested],
            "status": "pending"
        }

    async def confirm_slot(self, request_id: str, slot_index: int) -> Dict[str, Any]:
        result = await self.db.execute(
            select(SchedulingRequestDB).where(SchedulingRequestDB.id == uuid.UUID(request_id))
        )
        req = result.scalar_one_or_none()
        if not req:
            return {"error": "Request not found"}

        slots = req.suggested_slots
        if slot_index >= len(slots):
            return {"error": "Invalid slot index"}

        selected = slots[slot_index]

        await self.db.execute(
            update(SchedulingRequestDB)
            .where(SchedulingRequestDB.id == uuid.UUID(request_id))
            .values(selected_slot=selected, status="confirmed", updated_at=datetime.utcnow())
        )

        await messaging.send_message("scheduler.confirmed", {
            "request_id": request_id,
            "slot": selected,
            "timestamp": datetime.utcnow().isoformat()
        })

        return {"request_id": request_id, "status": "confirmed", "slot": selected}
