from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Text, ForeignKey, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel
import uuid

class AvailabilitySlotDB(Base):
    __tablename__ = "availability_slots"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(String(255), nullable=False, index=True)
    start_time = Column(DateTime, nullable=False)
    end_time = Column(DateTime, nullable=False)
    timezone = Column(String(50), default="UTC")
    is_available = Column(Boolean, default=True)
    recurrence_pattern = Column(String(100), nullable=True)
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class SchedulingRequestDB(Base):
    __tablename__ = "scheduling_requests"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    requester_id = Column(String(255), nullable=False)
    participant_ids = Column(ARRAY(String), nullable=False)
    duration_minutes = Column(Integer, default=30)
    preferred_start = Column(DateTime, nullable=True)
    preferred_end = Column(DateTime, nullable=True)
    timezone = Column(String(50), default="UTC")
    status = Column(String(50), default="pending")
    suggested_slots = Column(JSON, default=list)
    selected_slot = Column(JSON, nullable=True)
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class AvailabilitySlotCreate(ZANOXBaseModel):
    user_id: str
    start_time: datetime
    end_time: datetime
    timezone: str = "UTC"
    is_available: bool = True
    recurrence_pattern: Optional[str] = None

class SchedulingRequestCreate(ZANOXBaseModel):
    requester_id: str
    participant_ids: List[str]
    duration_minutes: int = 30
    preferred_start: Optional[datetime] = None
    preferred_end: Optional[datetime] = None
    timezone: str = "UTC"

class SuggestedSlot(ZANOXBaseModel):
    start_time: datetime
    end_time: datetime
    available_participants: List[str]
    confidence: float
