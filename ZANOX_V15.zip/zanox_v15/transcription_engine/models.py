from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Text, ForeignKey, Boolean, Float
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel
import uuid

class TranscriptionDB(Base):
    __tablename__ = "transcriptions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    recording_id = Column(UUID(as_uuid=True), ForeignKey("recordings.id"), nullable=False, index=True)
    meeting_id = Column(UUID(as_uuid=True), ForeignKey("meetings.id"), nullable=False, index=True)
    language = Column(String(10), default="en")
    segments = Column(JSON, default=list)
    full_text = Column(Text, nullable=True)
    speaker_labels = Column(JSON, default=dict)
    confidence_score = Column(Float, nullable=True)
    word_count = Column(Integer, default=0)
    duration_seconds = Column(Integer, nullable=True)
    status = Column(String(50), default="processing")
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime, nullable=True)

class TranscriptionSegment(BaseModel):
    start_time: float
    end_time: float
    speaker: str
    text: str
    confidence: float

class TranscriptionCreate(ZANOXBaseModel):
    recording_id: str
    meeting_id: str
    language: str = "en"
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict)

class TranscriptionResponse(ZANOXBaseModel):
    id: str
    recording_id: str
    meeting_id: str
    language: str
    full_text: Optional[str] = None
    word_count: int
    confidence_score: Optional[float] = None
    status: str
    created_at: datetime
    completed_at: Optional[datetime] = None
