import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from shared.cache import cache
from shared.messaging import messaging
from .models import TranscriptionDB, TranscriptionSegment, TranscriptionCreate, TranscriptionResponse

class TranscriptionEngineService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_transcription(self, data: TranscriptionCreate) -> TranscriptionResponse:
        db_trans = TranscriptionDB(
            id=uuid.uuid4(),
            recording_id=uuid.UUID(data.recording_id),
            meeting_id=uuid.UUID(data.meeting_id),
            language=data.language,
            status="processing",
            metadata=data.metadata
        )
        self.db.add(db_trans)
        await self.db.flush()

        await messaging.send_message("transcription.started", {
            "transcription_id": str(db_trans.id),
            "recording_id": data.recording_id,
            "meeting_id": data.meeting_id
        })

        return TranscriptionResponse(
            id=str(db_trans.id), recording_id=data.recording_id,
            meeting_id=data.meeting_id, language=db_trans.language,
            full_text=db_trans.full_text, word_count=db_trans.word_count,
            confidence_score=db_trans.confidence_score,
            status=db_trans.status, created_at=db_trans.created_at,
            completed_at=db_trans.completed_at
        )

    async def add_segments(self, transcription_id: str, segments: List[TranscriptionSegment]) -> Dict[str, Any]:
        full_text = " ".join([s.text for s in segments])
        word_count = len(full_text.split())
        avg_confidence = sum(s.confidence for s in segments) / len(segments) if segments else 0

        speakers = {}
        for s in segments:
            if s.speaker not in speakers:
                speakers[s.speaker] = {"segments": 0, "words": 0}
            speakers[s.speaker]["segments"] += 1
            speakers[s.speaker]["words"] += len(s.text.split())

        await self.db.execute(
            update(TranscriptionDB)
            .where(TranscriptionDB.id == uuid.UUID(transcription_id))
            .values(
                segments=[s.model_dump() for s in segments],
                full_text=full_text,
                word_count=word_count,
                confidence_score=avg_confidence,
                speaker_labels=speakers,
                status="completed",
                completed_at=datetime.utcnow()
            )
        )

        await messaging.send_message("transcription.completed", {
            "transcription_id": transcription_id,
            "word_count": word_count,
            "confidence": avg_confidence
        })

        return {
            "transcription_id": transcription_id,
            "status": "completed",
            "word_count": word_count,
            "confidence": round(avg_confidence, 3)
        }

    async def get_transcription(self, transcription_id: str) -> Optional[TranscriptionResponse]:
        result = await self.db.execute(
            select(TranscriptionDB).where(TranscriptionDB.id == uuid.UUID(transcription_id))
        )
        t = result.scalar_one_or_none()
        if not t:
            return None
        return TranscriptionResponse(
            id=str(t.id), recording_id=str(t.recording_id),
            meeting_id=str(t.meeting_id), language=t.language,
            full_text=t.full_text, word_count=t.word_count,
            confidence_score=t.confidence_score, status=t.status,
            created_at=t.created_at, completed_at=t.completed_at
        )

    async def get_meeting_transcription(self, meeting_id: str) -> Optional[TranscriptionResponse]:
        result = await self.db.execute(
            select(TranscriptionDB)
            .where(TranscriptionDB.meeting_id == uuid.UUID(meeting_id))
            .order_by(TranscriptionDB.created_at.desc())
            .limit(1)
        )
        t = result.scalar_one_or_none()
        if not t:
            return None
        return TranscriptionResponse(
            id=str(t.id), recording_id=str(t.recording_id),
            meeting_id=str(t.meeting_id), language=t.language,
            full_text=t.full_text, word_count=t.word_count,
            confidence_score=t.confidence_score, status=t.status,
            created_at=t.created_at, completed_at=t.completed_at
        )
