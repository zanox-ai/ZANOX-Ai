from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import TranscriptionSegment, TranscriptionCreate, TranscriptionResponse
from .service import TranscriptionEngineService

router = APIRouter(prefix="/transcriptions", tags=["Transcription Engine"])

@router.post("/", response_model=TranscriptionResponse)
async def create_transcription(
    data: TranscriptionCreate,
    db: AsyncSession = Depends(get_db_session)
):
    service = TranscriptionEngineService(db)
    return await service.create_transcription(data)

@router.post("/{transcription_id}/segments")
async def add_segments(
    transcription_id: str,
    segments: List[TranscriptionSegment],
    db: AsyncSession = Depends(get_db_session)
):
    service = TranscriptionEngineService(db)
    return await service.add_segments(transcription_id, segments)

@router.get("/{transcription_id}", response_model=TranscriptionResponse)
async def get_transcription(
    transcription_id: str,
    db: AsyncSession = Depends(get_db_session)
):
    service = TranscriptionEngineService(db)
    result = await service.get_transcription(transcription_id)
    if not result:
        raise HTTPException(status_code=404, detail="Transcription not found")
    return result

@router.get("/meetings/{meeting_id}", response_model=TranscriptionResponse)
async def get_meeting_transcription(
    meeting_id: str,
    db: AsyncSession = Depends(get_db_session)
):
    service = TranscriptionEngineService(db)
    result = await service.get_meeting_transcription(meeting_id)
    if not result:
        raise HTTPException(status_code=404, detail="No transcription found for meeting")
    return result
