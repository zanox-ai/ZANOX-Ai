from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Text, ForeignKey, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel
import uuid

class DeploymentDB(Base):
    __tablename__ = "deployments"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    version = Column(String(50), nullable=False)
    environment = Column(String(50), nullable=False)
    status = Column(String(50), default="pending")
    deployed_by = Column(String(255), nullable=True)
    deployed_at = Column(DateTime, nullable=True)
    rollback_at = Column(DateTime, nullable=True)
    health_check_url = Column(String(1024), nullable=True)
    config = Column(JSON, default=dict)
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class DeploymentCreate(ZANOXBaseModel):
    version: str
    environment: str
    deployed_by: Optional[str] = None
    health_check_url: Optional[str] = None
    config: Optional[Dict[str, Any]] = Field(default_factory=dict)
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict)

class DeploymentResponse(ZANOXBaseModel):
    id: str
    version: str
    environment: str
    status: str
    deployed_by: Optional[str] = None
    deployed_at: Optional[datetime] = None
    created_at: datetime
