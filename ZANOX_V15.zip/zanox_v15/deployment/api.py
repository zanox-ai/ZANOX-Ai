from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import DeploymentCreate, DeploymentResponse
from .service import DeploymentService

router = APIRouter(prefix="/deployment", tags=["Deployment"])

@router.post("/", response_model=DeploymentResponse)
async def create_deployment(data: DeploymentCreate, db: AsyncSession = Depends(get_db_session)):
    service = DeploymentService(db)
    return await service.create_deployment(data)

@router.post("/{deployment_id}/deploy")
async def mark_deployed(deployment_id: str, db: AsyncSession = Depends(get_db_session)):
    service = DeploymentService(db)
    return await service.mark_deployed(deployment_id)

@router.post("/{deployment_id}/rollback")
async def rollback(deployment_id: str, db: AsyncSession = Depends(get_db_session)):
    service = DeploymentService(db)
    return await service.rollback(deployment_id)

@router.get("/{deployment_id}", response_model=DeploymentResponse)
async def get_deployment(deployment_id: str, db: AsyncSession = Depends(get_db_session)):
    service = DeploymentService(db)
    result = await service.get_deployment(deployment_id)
    if not result: raise HTTPException(status_code=404, detail="Deployment not found")
    return result

@router.get("/", response_model=List[DeploymentResponse])
async def list_deployments(environment: Optional[str] = Query(None), limit: int = Query(50, ge=1, le=100), db: AsyncSession = Depends(get_db_session)):
    service = DeploymentService(db)
    return await service.list_deployments(environment, limit)
