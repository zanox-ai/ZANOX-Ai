import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from shared.cache import cache
from shared.messaging import messaging
from .models import DeploymentDB, DeploymentCreate, DeploymentResponse

class DeploymentService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_deployment(self, data: DeploymentCreate) -> DeploymentResponse:
        db_dep = DeploymentDB(
            id=uuid.uuid4(), version=data.version, environment=data.environment,
            deployed_by=data.deployed_by, health_check_url=data.health_check_url,
            config=data.config, metadata=data.metadata
        )
        self.db.add(db_dep)
        await self.db.flush()
        await messaging.send_message("deployment.created", {
            "deployment_id": str(db_dep.id), "version": data.version, "environment": data.environment
        })
        return DeploymentResponse(
            id=str(db_dep.id), version=db_dep.version, environment=db_dep.environment,
            status=db_dep.status, deployed_by=db_dep.deployed_by,
            deployed_at=db_dep.deployed_at, created_at=db_dep.created_at
        )

    async def mark_deployed(self, deployment_id: str) -> Dict[str, Any]:
        await self.db.execute(
            update(DeploymentDB).where(DeploymentDB.id == uuid.UUID(deployment_id))
            .values(status="deployed", deployed_at=datetime.utcnow(), updated_at=datetime.utcnow())
        )
        await messaging.send_message("deployment.deployed", {"deployment_id": deployment_id, "timestamp": datetime.utcnow().isoformat()})
        return {"deployment_id": deployment_id, "status": "deployed", "timestamp": datetime.utcnow().isoformat()}

    async def rollback(self, deployment_id: str) -> Dict[str, Any]:
        await self.db.execute(
            update(DeploymentDB).where(DeploymentDB.id == uuid.UUID(deployment_id))
            .values(status="rolled_back", rollback_at=datetime.utcnow(), updated_at=datetime.utcnow())
        )
        await messaging.send_message("deployment.rolled_back", {"deployment_id": deployment_id, "timestamp": datetime.utcnow().isoformat()})
        return {"deployment_id": deployment_id, "status": "rolled_back", "timestamp": datetime.utcnow().isoformat()}

    async def get_deployment(self, deployment_id: str) -> Optional[DeploymentResponse]:
        result = await self.db.execute(select(DeploymentDB).where(DeploymentDB.id == uuid.UUID(deployment_id)))
        d = result.scalar_one_or_none()
        if not d: return None
        return DeploymentResponse(
            id=str(d.id), version=d.version, environment=d.environment,
            status=d.status, deployed_by=d.deployed_by, deployed_at=d.deployed_at, created_at=d.created_at
        )

    async def list_deployments(self, environment: Optional[str] = None, limit: int = 50) -> List[DeploymentResponse]:
        query = select(DeploymentDB)
        if environment: query = query.where(DeploymentDB.environment == environment)
        query = query.order_by(DeploymentDB.created_at.desc()).limit(limit)
        result = await self.db.execute(query)
        return [DeploymentResponse(
            id=str(d.id), version=d.version, environment=d.environment,
            status=d.status, deployed_by=d.deployed_by, deployed_at=d.deployed_at, created_at=d.created_at
        ) for d in result.scalars().all()]
