from typing import Optional, List, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import MonitoringEventCreate, MonitoringEventResponse
from .service import MonitoringService

router = APIRouter(prefix="/monitoring", tags=["Monitoring"])

@router.post("/events", response_model=MonitoringEventResponse)
async def log_event(data: MonitoringEventCreate, db: AsyncSession = Depends(get_db_session)):
    service = MonitoringService(db)
    return await service.log_event(data)

@router.get("/events", response_model=List[MonitoringEventResponse])
async def get_events(
    event_type: Optional[str] = Query(None),
    service_name: Optional[str] = Query(None),
    severity: Optional[str] = Query(None),
    limit: int = Query(100, ge=1, le=500),
    db: AsyncSession = Depends(get_db_session)
):
    service = MonitoringService(db)
    return await service.get_events(event_type, service_name, severity, limit)

@router.get("/health-summary")
async def get_health_summary(db: AsyncSession = Depends(get_db_session)):
    service = MonitoringService(db)
    return await service.get_health_summary()
