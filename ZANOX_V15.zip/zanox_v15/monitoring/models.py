from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Text, ForeignKey, Float, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel
import uuid

class MonitoringEventDB(Base):
    __tablename__ = "monitoring_events"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    event_type = Column(String(50), nullable=False, index=True)
    service_name = Column(String(255), nullable=False)
    severity = Column(String(50), default="info")
    message = Column(Text, nullable=False)
    details = Column(JSON, default=dict)
    trace_id = Column(String(255), nullable=True)
    span_id = Column(String(255), nullable=True)
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)

class MonitoringEventCreate(ZANOXBaseModel):
    event_type: str
    service_name: str
    severity: str = "info"
    message: str
    details: Optional[Dict[str, Any]] = Field(default_factory=dict)
    trace_id: Optional[str] = None
    span_id: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict)

class MonitoringEventResponse(ZANOXBaseModel):
    id: str
    event_type: str
    service_name: str
    severity: str
    message: str
    created_at: datetime
