import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from shared.cache import cache
from shared.messaging import messaging
from .models import MonitoringEventDB, MonitoringEventCreate, MonitoringEventResponse

class MonitoringService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def log_event(self, data: MonitoringEventCreate) -> MonitoringEventResponse:
        db_event = MonitoringEventDB(
            id=uuid.uuid4(), event_type=data.event_type, service_name=data.service_name,
            severity=data.severity, message=data.message, details=data.details,
            trace_id=data.trace_id, span_id=data.span_id, metadata=data.metadata
        )
        self.db.add(db_event)
        await self.db.flush()
        await messaging.send_message("monitoring.event", {
            "event_id": str(db_event.id), "type": data.event_type, "service": data.service_name, "severity": data.severity
        })
        return MonitoringEventResponse(
            id=str(db_event.id), event_type=db_event.event_type, service_name=db_event.service_name,
            severity=db_event.severity, message=db_event.message, created_at=db_event.created_at
        )

    async def get_events(self, event_type: Optional[str] = None, service_name: Optional[str] = None, severity: Optional[str] = None, limit: int = 100) -> List[MonitoringEventResponse]:
        query = select(MonitoringEventDB)
        if event_type: query = query.where(MonitoringEventDB.event_type == event_type)
        if service_name: query = query.where(MonitoringEventDB.service_name == service_name)
        if severity: query = query.where(MonitoringEventDB.severity == severity)
        query = query.order_by(MonitoringEventDB.created_at.desc()).limit(limit)
        result = await self.db.execute(query)
        return [MonitoringEventResponse(
            id=str(e.id), event_type=e.event_type, service_name=e.service_name,
            severity=e.severity, message=e.message, created_at=e.created_at
        ) for e in result.scalars().all()]

    async def get_health_summary(self) -> Dict[str, Any]:
        result = await self.db.execute(
            select(MonitoringEventDB).where(MonitoringEventDB.created_at >= datetime.utcnow() - __import__('datetime').timedelta(hours=1))
        )
        events = result.scalars().all()
        severity_counts = {}
        for e in events:
            severity_counts[e.severity] = severity_counts.get(e.severity, 0) + 1
        return {"period_hours": 1, "total_events": len(events), "severity_distribution": severity_counts}
