from typing import Optional, List, Dict, Any
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import MessageTemplateCreate, RenderedMessage
from .service import MessagingEngineService

router = APIRouter(prefix="/messaging-engine", tags=["Messaging Engine"])

@router.post("/templates")
async def create_template(template: MessageTemplateCreate, db: AsyncSession = Depends(get_db_session)):
    service = MessagingEngineService(db)
    return await service.create_template(template)

@router.post("/render/{template_name}", response_model=RenderedMessage)
async def render_message(template_name: str, variables: Dict[str, Any], db: AsyncSession = Depends(get_db_session)):
    service = MessagingEngineService(db)
    result = await service.render_message(template_name, variables)
    if not result: raise HTTPException(status_code=404, detail="Template not found")
    return result

@router.post("/send")
async def send_message(channel: str, recipient: str, body: str, subject: str = None, metadata: dict = None, db: AsyncSession = Depends(get_db_session)):
    service = MessagingEngineService(db)
    return await service.send_message(channel, recipient, subject, body, metadata)

@router.get("/templates")
async def list_templates(channel: Optional[str] = None, category: Optional[str] = None, db: AsyncSession = Depends(get_db_session)):
    service = MessagingEngineService(db)
    return await service.list_templates(channel, category)
