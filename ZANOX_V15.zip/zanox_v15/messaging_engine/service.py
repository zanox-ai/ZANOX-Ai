import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from shared.cache import cache
from shared.messaging import messaging
from .models import MessageTemplateDB, MessageTemplateCreate, RenderedMessage

class MessagingEngineService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_template(self, template: MessageTemplateCreate) -> Dict[str, Any]:
        db_template = MessageTemplateDB(
            id=uuid.uuid4(), name=template.name, channel=template.channel,
            subject_template=template.subject_template, body_template=template.body_template,
            variables=template.variables, category=template.category
        )
        self.db.add(db_template)
        await self.db.flush()
        await cache.set(f"template:{db_template.name}", db_template.__dict__, ttl=86400)
        return {"id": str(db_template.id), "name": db_template.name, "status": "created"}

    async def render_message(self, template_name: str, variables: Dict[str, Any]) -> Optional[RenderedMessage]:
        cached = await cache.get(f"template:{template_name}")
        if cached: template = cached
        else:
            result = await self.db.execute(select(MessageTemplateDB).where(MessageTemplateDB.name == template_name))
            t = result.scalar_one_or_none()
            if not t: return None
            template = t.__dict__
            await cache.set(f"template:{template_name}", template, ttl=86400)
        body = template["body_template"]
        subject = template.get("subject_template")
        for key, value in variables.items():
            placeholder = f"{{{{{key}}}}}"
            body = body.replace(placeholder, str(value))
            if subject: subject = subject.replace(placeholder, str(value))
        return RenderedMessage(channel=template["channel"], subject=subject, body=body, variables_used=variables)

    async def send_message(self, channel: str, recipient: str, subject: Optional[str], body: str, metadata: Optional[Dict] = None) -> Dict[str, Any]:
        message_id = str(uuid.uuid4())
        await messaging.send_message(f"channel.{channel}.send", {
            "message_id": message_id, "recipient": recipient, "subject": subject, "body": body, "metadata": metadata or {}
        })
        return {"message_id": message_id, "channel": channel, "recipient": recipient, "status": "queued", "timestamp": datetime.utcnow().isoformat()}

    async def list_templates(self, channel: Optional[str] = None, category: Optional[str] = None) -> List[Dict[str, Any]]:
        query = select(MessageTemplateDB).where(MessageTemplateDB.is_active == True)
        if channel: query = query.where(MessageTemplateDB.channel == channel)
        if category: query = query.where(MessageTemplateDB.category == category)
        result = await self.db.execute(query)
        return [{"id": str(t.id), "name": t.name, "channel": t.channel, "category": t.category} for t in result.scalars().all()]
