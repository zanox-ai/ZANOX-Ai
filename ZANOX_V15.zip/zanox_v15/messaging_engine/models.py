from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Text, ForeignKey, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel
import uuid

class MessageTemplateDB(Base):
    __tablename__ = "message_templates"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(255), nullable=False, unique=True)
    channel = Column(String(50), nullable=False)
    subject_template = Column(Text, nullable=True)
    body_template = Column(Text, nullable=False)
    variables = Column(ARRAY(String), default=list)
    category = Column(String(100), nullable=True)
    is_active = Column(Boolean, default=True)
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class MessageTemplateCreate(ZANOXBaseModel):
    name: str
    channel: str
    subject_template: Optional[str] = None
    body_template: str
    variables: Optional[List[str]] = Field(default_factory=list)
    category: Optional[str] = None

class RenderedMessage(ZANOXBaseModel):
    channel: str
    subject: Optional[str] = None
    body: str
    variables_used: Dict[str, Any]
