from typing import Optional, List, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import CustomerInteractionCreate, CustomerInteractionResponse
from .service import CustomerCommunicationService

router = APIRouter(prefix="/customer-communication", tags=["Customer Communication"])

@router.post("/interactions", response_model=CustomerInteractionResponse)
async def create_interaction(data: CustomerInteractionCreate, db: AsyncSession = Depends(get_db_session)):
    service = CustomerCommunicationService(db)
    return await service.create_interaction(data)

@router.patch("/interactions/{interaction_id}/status")
async def update_status(interaction_id: str, status: str, resolution: str = None, db: AsyncSession = Depends(get_db_session)):
    service = CustomerCommunicationService(db)
    await service.update_status(interaction_id, status, resolution)
    return {"status": "updated", "interaction_id": interaction_id, "new_status": status}

@router.get("/interactions/{interaction_id}", response_model=CustomerInteractionResponse)
async def get_interaction(interaction_id: str, db: AsyncSession = Depends(get_db_session)):
    service = CustomerCommunicationService(db)
    result = await service.get_interaction(interaction_id)
    if not result: raise HTTPException(status_code=404, detail="Interaction not found")
    return result

@router.get("/interactions", response_model=List[CustomerInteractionResponse])
async def list_interactions(customer_id: Optional[str] = Query(None), status: Optional[str] = Query(None), limit: int = Query(50, ge=1, le=100), db: AsyncSession = Depends(get_db_session)):
    service = CustomerCommunicationService(db)
    return await service.list_interactions(customer_id, status, limit)
