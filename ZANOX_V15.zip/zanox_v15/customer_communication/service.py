import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from shared.cache import cache
from shared.messaging import messaging
from .models import CustomerInteractionDB, CustomerInteractionCreate, CustomerInteractionResponse

class CustomerCommunicationService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_interaction(self, data: CustomerInteractionCreate) -> CustomerInteractionResponse:
        db_int = CustomerInteractionDB(
            id=uuid.uuid4(), customer_id=data.customer_id,
            contact_id=uuid.UUID(data.contact_id) if data.contact_id else None,
            channel=data.channel, interaction_type=data.interaction_type,
            subject=data.subject, body=data.body, priority=data.priority,
            assigned_to=data.assigned_to, tags=data.tags, metadata=data.metadata
        )
        self.db.add(db_int)
        await self.db.flush()
        await messaging.send_message("customer.interaction_created", {
            "interaction_id": str(db_int.id), "customer_id": data.customer_id, "channel": data.channel
        })
        return CustomerInteractionResponse(
            id=str(db_int.id), customer_id=db_int.customer_id, channel=db_int.channel,
            interaction_type=db_int.interaction_type, subject=db_int.subject, body=db_int.body,
            status=db_int.status, priority=db_int.priority.value, assigned_to=db_int.assigned_to,
            created_at=db_int.created_at, resolved_at=db_int.resolved_at
        )

    async def update_status(self, interaction_id: str, status: str, resolution: Optional[str] = None) -> bool:
        values = {"status": status, "updated_at": datetime.utcnow()}
        if status == "resolved":
            values["resolved_at"] = datetime.utcnow()
            values["resolution"] = resolution
        await self.db.execute(update(CustomerInteractionDB).where(CustomerInteractionDB.id == uuid.UUID(interaction_id)).values(**values))
        await cache.delete(f"interaction:{interaction_id}")
        await messaging.send_message("customer.status_updated", {"interaction_id": interaction_id, "status": status})
        return True

    async def get_interaction(self, interaction_id: str) -> Optional[CustomerInteractionResponse]:
        result = await self.db.execute(select(CustomerInteractionDB).where(CustomerInteractionDB.id == uuid.UUID(interaction_id)))
        i = result.scalar_one_or_none()
        if not i: return None
        return CustomerInteractionResponse(
            id=str(i.id), customer_id=i.customer_id, channel=i.channel,
            interaction_type=i.interaction_type, subject=i.subject, body=i.body,
            status=i.status, priority=i.priority.value, assigned_to=i.assigned_to,
            created_at=i.created_at, resolved_at=i.resolved_at
        )

    async def list_interactions(self, customer_id: Optional[str] = None, status: Optional[str] = None, limit: int = 50) -> List[CustomerInteractionResponse]:
        query = select(CustomerInteractionDB)
        if customer_id: query = query.where(CustomerInteractionDB.customer_id == customer_id)
        if status: query = query.where(CustomerInteractionDB.status == status)
        query = query.order_by(CustomerInteractionDB.created_at.desc()).limit(limit)
        result = await self.db.execute(query)
        return [CustomerInteractionResponse(
            id=str(i.id), customer_id=i.customer_id, channel=i.channel,
            interaction_type=i.interaction_type, subject=i.subject, body=i.body,
            status=i.status, priority=i.priority.value, assigned_to=i.assigned_to,
            created_at=i.created_at, resolved_at=i.resolved_at
        ) for i in result.scalars().all()]
