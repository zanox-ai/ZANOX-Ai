from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Text, ForeignKey, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel, Priority
import uuid

class CustomerInteractionDB(Base):
    __tablename__ = "customer_interactions"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    customer_id = Column(String(255), nullable=False, index=True)
    contact_id = Column(UUID(as_uuid=True), ForeignKey("contacts.id"), nullable=True)
    channel = Column(String(50), nullable=False)
    interaction_type = Column(String(50), default="inquiry")
    subject = Column(Text, nullable=True)
    body = Column(Text, nullable=False)
    status = Column(String(50), default="open")
    priority = Column(SQLEnum(Priority), default=Priority.MEDIUM)
    assigned_to = Column(String(255), nullable=True)
    resolution = Column(Text, nullable=True)
    satisfaction_score = Column(Integer, nullable=True)
    tags = Column(ARRAY(String), default=list)
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    resolved_at = Column(DateTime, nullable=True)

class CustomerInteractionCreate(ZANOXBaseModel):
    customer_id: str
    contact_id: Optional[str] = None
    channel: str
    interaction_type: str = "inquiry"
    subject: Optional[str] = None
    body: str
    priority: Priority = Priority.MEDIUM
    assigned_to: Optional[str] = None
    tags: Optional[List[str]] = Field(default_factory=list)
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict)

class CustomerInteractionResponse(ZANOXBaseModel):
    id: str
    customer_id: str
    channel: str
    interaction_type: str
    subject: Optional[str] = None
    body: str
    status: str
    priority: str
    assigned_to: Optional[str] = None
    created_at: datetime
    resolved_at: Optional[datetime] = None
