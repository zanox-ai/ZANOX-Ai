from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Text, ForeignKey, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel
import uuid

class PresenceDB(Base):
    __tablename__ = "presence"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(String(255), nullable=False, unique=True, index=True)
    status = Column(String(50), default="offline")
    last_seen_at = Column(DateTime, default=datetime.utcnow)
    current_activity = Column(String(255), nullable=True)
    available_channels = Column(ARRAY(String), default=list)
    device_info = Column(JSON, default=dict)
    metadata = Column(JSON, default=dict)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class PresenceUpdate(ZANOXBaseModel):
    user_id: str
    status: str
    current_activity: Optional[str] = None
    available_channels: Optional[List[str]] = Field(default_factory=list)
    device_info: Optional[Dict[str, Any]] = Field(default_factory=dict)

class PresenceResponse(ZANOXBaseModel):
    user_id: str
    status: str
    last_seen_at: datetime
    current_activity: Optional[str] = None
    available_channels: List[str]
