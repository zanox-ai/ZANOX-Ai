import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from shared.cache import cache
from shared.messaging import messaging
from .models import PresenceDB, PresenceUpdate, PresenceResponse

class PresenceService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def update_presence(self, data: PresenceUpdate) -> PresenceResponse:
        result = await self.db.execute(select(PresenceDB).where(PresenceDB.user_id == data.user_id))
        existing = result.scalar_one_or_none()
        if existing:
            await self.db.execute(
                update(PresenceDB).where(PresenceDB.id == existing.id)
                .values(
                    status=data.status, current_activity=data.current_activity,
                    available_channels=data.available_channels, device_info=data.device_info,
                    last_seen_at=datetime.utcnow(), updated_at=datetime.utcnow()
                )
            )
            presence_id = existing.id
        else:
            db_pres = PresenceDB(
                id=uuid.uuid4(), user_id=data.user_id, status=data.status,
                current_activity=data.current_activity, available_channels=data.available_channels,
                device_info=data.device_info
            )
            self.db.add(db_pres)
            await self.db.flush()
            presence_id = db_pres.id

        await cache.set(f"presence:{data.user_id}", {
            "user_id": data.user_id, "status": data.status, "last_seen_at": datetime.utcnow().isoformat(),
            "current_activity": data.current_activity, "available_channels": data.available_channels
        }, ttl=300)
        await messaging.send_message("presence.updated", {"user_id": data.user_id, "status": data.status})
        return PresenceResponse(
            user_id=data.user_id, status=data.status, last_seen_at=datetime.utcnow(),
            current_activity=data.current_activity, available_channels=data.available_channels
        )

    async def get_presence(self, user_id: str) -> Optional[PresenceResponse]:
        cached = await cache.get(f"presence:{user_id}")
        if cached: return PresenceResponse(**cached)
        result = await self.db.execute(select(PresenceDB).where(PresenceDB.user_id == user_id))
        p = result.scalar_one_or_none()
        if not p: return None
        return PresenceResponse(
            user_id=p.user_id, status=p.status, last_seen_at=p.last_seen_at,
            current_activity=p.current_activity, available_channels=p.available_channels
        )

    async def get_online_users(self) -> List[PresenceResponse]:
        result = await self.db.execute(
            select(PresenceDB).where(PresenceDB.status.in_(["online", "available", "busy"])).order_by(PresenceDB.last_seen_at.desc())
        )
        return [PresenceResponse(
            user_id=p.user_id, status=p.status, last_seen_at=p.last_seen_at,
            current_activity=p.current_activity, available_channels=p.available_channels
        ) for p in result.scalars().all()]
