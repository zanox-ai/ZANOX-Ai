from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import PresenceUpdate, PresenceResponse
from .service import PresenceService

router = APIRouter(prefix="/presence", tags=["Presence Engine"])

@router.post("/update", response_model=PresenceResponse)
async def update_presence(data: PresenceUpdate, db: AsyncSession = Depends(get_db_session)):
    service = PresenceService(db)
    return await service.update_presence(data)

@router.get("/users/{user_id}", response_model=PresenceResponse)
async def get_presence(user_id: str, db: AsyncSession = Depends(get_db_session)):
    service = PresenceService(db)
    result = await service.get_presence(user_id)
    if not result: raise HTTPException(status_code=404, detail="Presence not found")
    return result

@router.get("/online", response_model=List[PresenceResponse])
async def get_online_users(db: AsyncSession = Depends(get_db_session)):
    service = PresenceService(db)
    return await service.get_online_users()
