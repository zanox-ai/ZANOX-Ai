import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from shared.cache import cache
from shared.messaging import messaging
from .models import MeetingInsightDB, MeetingInsightCreate, MeetingInsightResponse

class MeetingIntelligenceService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_insight(self, data: MeetingInsightCreate) -> MeetingInsightResponse:
        db_insight = MeetingInsightDB(
            id=uuid.uuid4(), meeting_id=uuid.UUID(data.meeting_id),
            insight_type=data.insight_type, insight_text=data.insight_text,
            confidence=data.confidence, related_topics=data.related_topics,
            related_participants=data.related_participants, sentiment=data.sentiment
        )
        self.db.add(db_insight)
        await self.db.flush()
        await messaging.send_message("meeting.insight_created", {"insight_id": str(db_insight.id), "meeting_id": data.meeting_id, "type": data.insight_type})
        return MeetingInsightResponse(
            id=str(db_insight.id), meeting_id=data.meeting_id, insight_type=db_insight.insight_type,
            insight_text=db_insight.insight_text, confidence=db_insight.confidence,
            sentiment=db_insight.sentiment, created_at=db_insight.created_at
        )

    async def get_insights(self, meeting_id: str, insight_type: Optional[str] = None) -> List[MeetingInsightResponse]:
        query = select(MeetingInsightDB).where(MeetingInsightDB.meeting_id == uuid.UUID(meeting_id))
        if insight_type: query = query.where(MeetingInsightDB.insight_type == insight_type)
        query = query.order_by(MeetingInsightDB.confidence.desc())
        result = await self.db.execute(query)
        return [MeetingInsightResponse(
            id=str(i.id), meeting_id=meeting_id, insight_type=i.insight_type,
            insight_text=i.insight_text, confidence=i.confidence, sentiment=i.sentiment, created_at=i.created_at
        ) for i in result.scalars().all()]

    async def get_trending_topics(self, days: int = 30) -> List[Dict[str, Any]]:
        from_date = datetime.utcnow() - __import__('datetime').timedelta(days=days)
        result = await self.db.execute(
            select(MeetingInsightDB).where(MeetingInsightDB.created_at >= from_date)
        )
        topics = {}
        for insight in result.scalars().all():
            for topic in insight.related_topics:
                topics[topic] = topics.get(topic, 0) + 1
        return [{"topic": k, "frequency": v} for k, v in sorted(topics.items(), key=lambda x: x[1], reverse=True)]
