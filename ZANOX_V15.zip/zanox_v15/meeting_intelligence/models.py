from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Text, ForeignKey, Float, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel
import uuid

class MeetingInsightDB(Base):
    __tablename__ = "meeting_insights"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    meeting_id = Column(UUID(as_uuid=True), ForeignKey("meetings.id"), nullable=False, index=True)
    insight_type = Column(String(50), nullable=False)
    insight_text = Column(Text, nullable=False)
    confidence = Column(Float, default=0.0)
    related_topics = Column(ARRAY(String), default=list)
    related_participants = Column(ARRAY(String), default=list)
    sentiment = Column(String(50), default="neutral")
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)

class MeetingInsightCreate(ZANOXBaseModel):
    meeting_id: str
    insight_type: str
    insight_text: str
    confidence: float = 0.0
    related_topics: Optional[List[str]] = Field(default_factory=list)
    related_participants: Optional[List[str]] = Field(default_factory=list)
    sentiment: str = "neutral"

class MeetingInsightResponse(ZANOXBaseModel):
    id: str
    meeting_id: str
    insight_type: str
    insight_text: str
    confidence: float
    sentiment: str
    created_at: datetime
