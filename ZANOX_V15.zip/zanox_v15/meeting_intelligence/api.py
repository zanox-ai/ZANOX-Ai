from typing import Optional, List, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import MeetingInsightCreate, MeetingInsightResponse
from .service import MeetingIntelligenceService

router = APIRouter(prefix="/meeting-intelligence", tags=["Meeting Intelligence"])

@router.post("/insights", response_model=MeetingInsightResponse)
async def create_insight(data: MeetingInsightCreate, db: AsyncSession = Depends(get_db_session)):
    service = MeetingIntelligenceService(db)
    return await service.create_insight(data)

@router.get("/meetings/{meeting_id}/insights", response_model=List[MeetingInsightResponse])
async def get_insights(meeting_id: str, insight_type: Optional[str] = Query(None), db: AsyncSession = Depends(get_db_session)):
    service = MeetingIntelligenceService(db)
    return await service.get_insights(meeting_id, insight_type)

@router.get("/trending-topics")
async def get_trending_topics(days: int = Query(30, ge=1, le=365), db: AsyncSession = Depends(get_db_session)):
    service = MeetingIntelligenceService(db)
    return await service.get_trending_topics(days)
