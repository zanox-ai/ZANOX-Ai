import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from shared.cache import cache
from shared.messaging import messaging
from .models import CampaignDB, CampaignCreate, CampaignResponse

class CampaignEngineService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_campaign(self, campaign: CampaignCreate) -> CampaignResponse:
        db_campaign = CampaignDB(
            id=uuid.uuid4(),
            name=campaign.name,
            description=campaign.description,
            campaign_type=campaign.campaign_type,
            channels=campaign.channels,
            target_segments=campaign.target_segments,
            content_variants=campaign.content_variants,
            schedule=campaign.schedule,
            budget=campaign.budget,
            start_date=campaign.start_date,
            end_date=campaign.end_date,
            priority=campaign.priority
        )
        self.db.add(db_campaign)
        await self.db.flush()

        await messaging.send_message("campaign.created", {
            "campaign_id": str(db_campaign.id),
            "name": db_campaign.name,
            "type": db_campaign.campaign_type
        })

        return CampaignResponse(
            id=str(db_campaign.id), name=db_campaign.name,
            campaign_type=db_campaign.campaign_type, status=db_campaign.status,
            channels=db_campaign.channels, budget=db_campaign.budget,
            spent=db_campaign.spent, start_date=db_campaign.start_date,
            end_date=db_campaign.end_date, priority=db_campaign.priority.value,
            created_at=db_campaign.created_at
        )

    async def launch_campaign(self, campaign_id: str) -> Dict[str, Any]:
        result = await self.db.execute(
            select(CampaignDB).where(CampaignDB.id == uuid.UUID(campaign_id))
        )
        campaign = result.scalar_one_or_none()
        if not campaign:
            return {"error": "Campaign not found"}

        await self.db.execute(
            update(CampaignDB)
            .where(CampaignDB.id == uuid.UUID(campaign_id))
            .values(status="active", updated_at=datetime.utcnow())
        )

        await messaging.send_message("campaign.launched", {
            "campaign_id": campaign_id,
            "channels": campaign.channels,
            "timestamp": datetime.utcnow().isoformat()
        })

        return {"campaign_id": campaign_id, "status": "launched", "timestamp": datetime.utcnow().isoformat()}

    async def update_metrics(self, campaign_id: str, metrics: Dict[str, Any]) -> bool:
        result = await self.db.execute(
            select(CampaignDB).where(CampaignDB.id == uuid.UUID(campaign_id))
        )
        campaign = result.scalar_one_or_none()
        if not campaign:
            return False

        current = dict(campaign.metrics) if campaign.metrics else {}
        current.update(metrics)

        await self.db.execute(
            update(CampaignDB)
            .where(CampaignDB.id == uuid.UUID(campaign_id))
            .values(metrics=current, updated_at=datetime.utcnow())
        )
        await cache.delete(f"campaign:{campaign_id}")
        return True

    async def get_campaign(self, campaign_id: str) -> Optional[CampaignResponse]:
        cached = await cache.get(f"campaign:{campaign_id}")
        if cached:
            return CampaignResponse(**cached)

        result = await self.db.execute(
            select(CampaignDB).where(CampaignDB.id == uuid.UUID(campaign_id))
        )
        c = result.scalar_one_or_none()
        if not c:
            return None
        return CampaignResponse(
            id=str(c.id), name=c.name, campaign_type=c.campaign_type,
            status=c.status, channels=c.channels, budget=c.budget,
            spent=c.spent, start_date=c.start_date, end_date=c.end_date,
            priority=c.priority.value, created_at=c.created_at
        )

    async def list_campaigns(self, status: Optional[str] = None, limit: int = 50) -> List[CampaignResponse]:
        query = select(CampaignDB)
        if status:
            query = query.where(CampaignDB.status == status)
        query = query.order_by(CampaignDB.created_at.desc()).limit(limit)
        result = await self.db.execute(query)
        return [
            CampaignResponse(
                id=str(c.id), name=c.name, campaign_type=c.campaign_type,
                status=c.status, channels=c.channels, budget=c.budget,
                spent=c.spent, start_date=c.start_date, end_date=c.end_date,
                priority=c.priority.value, created_at=c.created_at
            ) for c in result.scalars().all()
        ]
