from typing import Optional, List, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import CampaignCreate, CampaignResponse
from .service import CampaignEngineService

router = APIRouter(prefix="/campaigns", tags=["Campaign Engine"])

@router.post("/", response_model=CampaignResponse)
async def create_campaign(
    campaign: CampaignCreate,
    db: AsyncSession = Depends(get_db_session)
):
    service = CampaignEngineService(db)
    return await service.create_campaign(campaign)

@router.post("/{campaign_id}/launch")
async def launch_campaign(
    campaign_id: str,
    db: AsyncSession = Depends(get_db_session)
):
    service = CampaignEngineService(db)
    result = await service.launch_campaign(campaign_id)
    if "error" in result:
        raise HTTPException(status_code=404, detail=result["error"])
    return result

@router.patch("/{campaign_id}/metrics")
async def update_metrics(
    campaign_id: str,
    metrics: Dict[str, Any],
    db: AsyncSession = Depends(get_db_session)
):
    service = CampaignEngineService(db)
    success = await service.update_metrics(campaign_id, metrics)
    if not success:
        raise HTTPException(status_code=404, detail="Campaign not found")
    return {"status": "metrics_updated", "campaign_id": campaign_id}

@router.get("/{campaign_id}", response_model=CampaignResponse)
async def get_campaign(
    campaign_id: str,
    db: AsyncSession = Depends(get_db_session)
):
    service = CampaignEngineService(db)
    result = await service.get_campaign(campaign_id)
    if not result:
        raise HTTPException(status_code=404, detail="Campaign not found")
    return result

@router.get("/", response_model=List[CampaignResponse])
async def list_campaigns(
    status: Optional[str] = Query(None),
    limit: int = Query(50, ge=1, le=100),
    db: AsyncSession = Depends(get_db_session)
):
    service = CampaignEngineService(db)
    return await service.list_campaigns(status, limit)
