from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Enum as SQLEnum, Text, ForeignKey, Boolean, Float
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel, Priority
import uuid

class CampaignDB(Base):
    __tablename__ = "campaigns"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    campaign_type = Column(String(50), nullable=False)
    status = Column(String(50), default="draft")
    channels = Column(ARRAY(String), nullable=False)
    target_segments = Column(JSON, default=list)
    content_variants = Column(JSON, default=list)
    schedule = Column(JSON, default=dict)
    metrics = Column(JSON, default=dict)
    budget = Column(Float, nullable=True)
    spent = Column(Float, default=0.0)
    start_date = Column(DateTime, nullable=True)
    end_date = Column(DateTime, nullable=True)
    priority = Column(SQLEnum(Priority), default=Priority.MEDIUM)
    is_active = Column(Boolean, default=True)
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class CampaignCreate(ZANOXBaseModel):
    name: str
    description: Optional[str] = None
    campaign_type: str
    channels: List[str]
    target_segments: Optional[List[Dict[str, Any]]] = Field(default_factory=list)
    content_variants: Optional[List[Dict[str, Any]]] = Field(default_factory=list)
    schedule: Optional[Dict[str, Any]] = Field(default_factory=dict)
    budget: Optional[float] = None
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    priority: Priority = Priority.MEDIUM

class CampaignResponse(ZANOXBaseModel):
    id: str
    name: str
    campaign_type: str
    status: str
    channels: List[str]
    budget: Optional[float] = None
    spent: float
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    priority: str
    created_at: datetime
