import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from shared.cache import cache
from shared.messaging import messaging
from .models import ExtractedTaskDB, ExtractedTaskCreate, ExtractedTaskResponse

class TaskExtractionService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def extract_task(self, data: ExtractedTaskCreate) -> ExtractedTaskResponse:
        db_task = ExtractedTaskDB(
            id=uuid.uuid4(), source_message_id=uuid.UUID(data.source_message_id),
            source_conversation_id=uuid.UUID(data.source_conversation_id) if data.source_conversation_id else None,
            task_text=data.task_text, assignee_id=data.assignee_id,
            due_date=data.due_date, priority=data.priority,
            confidence=data.confidence, context=data.context, metadata=data.metadata
        )
        self.db.add(db_task)
        await self.db.flush()
        await messaging.send_message("task.extracted", {
            "task_id": str(db_task.id), "source": data.source_message_id, "assignee": data.assignee_id
        })
        return ExtractedTaskResponse(
            id=str(db_task.id), source_message_id=data.source_message_id,
            task_text=db_task.task_text, assignee_id=db_task.assignee_id,
            due_date=db_task.due_date, priority=db_task.priority,
            confidence=db_task.confidence, status=db_task.status, created_at=db_task.created_at
        )

    async def confirm_task(self, task_id: str) -> bool:
        await self.db.execute(update(ExtractedTaskDB).where(ExtractedTaskDB.id == uuid.UUID(task_id)).values(status="confirmed"))
        await cache.delete(f"task:{task_id}")
        return True

    async def get_tasks(self, conversation_id: Optional[str] = None, status: Optional[str] = None, limit: int = 50) -> List[ExtractedTaskResponse]:
        query = select(ExtractedTaskDB)
        if conversation_id: query = query.where(ExtractedTaskDB.source_conversation_id == uuid.UUID(conversation_id))
        if status: query = query.where(ExtractedTaskDB.status == status)
        query = query.order_by(ExtractedTaskDB.created_at.desc()).limit(limit)
        result = await self.db.execute(query)
        return [ExtractedTaskResponse(
            id=str(t.id), source_message_id=str(t.source_message_id), task_text=t.task_text,
            assignee_id=t.assignee_id, due_date=t.due_date, priority=t.priority,
            confidence=t.confidence, status=t.status, created_at=t.created_at
        ) for t in result.scalars().all()]
