from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import ExtractedTaskCreate, ExtractedTaskResponse
from .service import TaskExtractionService

router = APIRouter(prefix="/task-extraction", tags=["Task Extraction"])

@router.post("/extract", response_model=ExtractedTaskResponse)
async def extract_task(data: ExtractedTaskCreate, db: AsyncSession = Depends(get_db_session)):
    service = TaskExtractionService(db)
    return await service.extract_task(data)

@router.patch("/tasks/{task_id}/confirm")
async def confirm_task(task_id: str, db: AsyncSession = Depends(get_db_session)):
    service = TaskExtractionService(db)
    await service.confirm_task(task_id)
    return {"status": "confirmed", "task_id": task_id}

@router.get("/tasks", response_model=List[ExtractedTaskResponse])
async def get_tasks(conversation_id: Optional[str] = Query(None), status: Optional[str] = Query(None), limit: int = Query(50, ge=1, le=100), db: AsyncSession = Depends(get_db_session)):
    service = TaskExtractionService(db)
    return await service.get_tasks(conversation_id, status, limit)
