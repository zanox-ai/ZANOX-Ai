from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Text, ForeignKey, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel
import uuid

class ExtractedTaskDB(Base):
    __tablename__ = "extracted_tasks"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    source_message_id = Column(UUID(as_uuid=True), nullable=False, index=True)
    source_conversation_id = Column(UUID(as_uuid=True), ForeignKey("conversations.id"), nullable=True)
    task_text = Column(Text, nullable=False)
    assignee_id = Column(String(255), nullable=True)
    due_date = Column(DateTime, nullable=True)
    priority = Column(String(50), default="medium")
    confidence = Column(Integer, default=100)
    status = Column(String(50), default="extracted")
    context = Column(Text, nullable=True)
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)

class ExtractedTaskCreate(ZANOXBaseModel):
    source_message_id: str
    source_conversation_id: Optional[str] = None
    task_text: str
    assignee_id: Optional[str] = None
    due_date: Optional[datetime] = None
    priority: str = "medium"
    confidence: int = 100
    context: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict)

class ExtractedTaskResponse(ZANOXBaseModel):
    id: str
    source_message_id: str
    task_text: str
    assignee_id: Optional[str] = None
    due_date: Optional[datetime] = None
    priority: str
    confidence: int
    status: str
    created_at: datetime
