from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Text, ForeignKey, Float, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel
import uuid

class ConversationAnalyticsDB(Base):
    __tablename__ = "conversation_analytics"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    conversation_id = Column(UUID(as_uuid=True), ForeignKey("conversations.id"), nullable=False, index=True)
    period_start = Column(DateTime, nullable=False)
    period_end = Column(DateTime, nullable=False)
    message_count = Column(Integer, default=0)
    participant_count = Column(Integer, default=0)
    avg_response_time_seconds = Column(Float, nullable=True)
    sentiment_distribution = Column(JSON, default=dict)
    top_topics = Column(ARRAY(String), default=list)
    engagement_score = Column(Float, nullable=True)
    resolution_rate = Column(Float, nullable=True)
    escalation_count = Column(Integer, default=0)
    channel_distribution = Column(JSON, default=dict)
    peak_activity_hours = Column(ARRAY(Integer), default=list)
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)

class AnalyticsReportCreate(ZANOXBaseModel):
    conversation_id: str
    period_start: datetime
    period_end: datetime
    message_count: int = 0
    participant_count: int = 0
    avg_response_time_seconds: Optional[float] = None
    sentiment_distribution: Optional[Dict[str, Any]] = Field(default_factory=dict)
    top_topics: Optional[List[str]] = Field(default_factory=list)
    engagement_score: Optional[float] = None
    resolution_rate: Optional[float] = None
    escalation_count: int = 0
    channel_distribution: Optional[Dict[str, Any]] = Field(default_factory=dict)

class AnalyticsReportResponse(ZANOXBaseModel):
    id: str
    conversation_id: str
    period_start: datetime
    period_end: datetime
    message_count: int
    participant_count: int
    avg_response_time_seconds: Optional[float] = None
    engagement_score: Optional[float] = None
    resolution_rate: Optional[float] = None
    escalation_count: int
    created_at: datetime
