import uuid
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_
from shared.cache import cache
from shared.messaging import messaging
from .models import ConversationAnalyticsDB, AnalyticsReportCreate, AnalyticsReportResponse

class ConversationAnalyticsService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def generate_report(self, data: AnalyticsReportCreate) -> AnalyticsReportResponse:
        db_report = ConversationAnalyticsDB(
            id=uuid.uuid4(), conversation_id=uuid.UUID(data.conversation_id),
            period_start=data.period_start, period_end=data.period_end,
            message_count=data.message_count, participant_count=data.participant_count,
            avg_response_time_seconds=data.avg_response_time_seconds,
            sentiment_distribution=data.sentiment_distribution, top_topics=data.top_topics,
            engagement_score=data.engagement_score, resolution_rate=data.resolution_rate,
            escalation_count=data.escalation_count, channel_distribution=data.channel_distribution
        )
        self.db.add(db_report)
        await self.db.flush()
        await messaging.send_message("analytics.report_generated", {
            "report_id": str(db_report.id), "conversation_id": data.conversation_id
        })
        return AnalyticsReportResponse(
            id=str(db_report.id), conversation_id=data.conversation_id,
            period_start=db_report.period_start, period_end=db_report.period_end,
            message_count=db_report.message_count, participant_count=db_report.participant_count,
            avg_response_time_seconds=db_report.avg_response_time_seconds,
            engagement_score=db_report.engagement_score, resolution_rate=db_report.resolution_rate,
            escalation_count=db_report.escalation_count, created_at=db_report.created_at
        )

    async def get_report(self, report_id: str) -> Optional[AnalyticsReportResponse]:
        result = await self.db.execute(select(ConversationAnalyticsDB).where(ConversationAnalyticsDB.id == uuid.UUID(report_id)))
        r = result.scalar_one_or_none()
        if not r: return None
        return AnalyticsReportResponse(
            id=str(r.id), conversation_id=str(r.conversation_id), period_start=r.period_start,
            period_end=r.period_end, message_count=r.message_count, participant_count=r.participant_count,
            avg_response_time_seconds=r.avg_response_time_seconds, engagement_score=r.engagement_score,
            resolution_rate=r.resolution_rate, escalation_count=r.escalation_count, created_at=r.created_at
        )

    async def get_conversation_stats(self, conversation_id: str, days: int = 30) -> Dict[str, Any]:
        from_date = datetime.utcnow() - timedelta(days=days)
        result = await self.db.execute(
            select(ConversationAnalyticsDB)
            .where(and_(ConversationAnalyticsDB.conversation_id == uuid.UUID(conversation_id), ConversationAnalyticsDB.period_start >= from_date))
            .order_by(ConversationAnalyticsDB.period_start.desc())
        )
        reports = result.scalars().all()
        if not reports: return {"conversation_id": conversation_id, "period_days": days, "reports_count": 0}
        total_messages = sum(r.message_count for r in reports)
        avg_engagement = sum(r.engagement_score or 0 for r in reports) / len(reports) if reports else 0
        avg_resolution = sum(r.resolution_rate or 0 for r in reports) / len(reports) if reports else 0
        return {
            "conversation_id": conversation_id, "period_days": days, "reports_count": len(reports),
            "total_messages": total_messages, "avg_engagement_score": round(avg_engagement, 2),
            "avg_resolution_rate": round(avg_resolution, 2), "total_escalations": sum(r.escalation_count for r in reports)
        }

    async def aggregate_dashboard(self, days: int = 7) -> Dict[str, Any]:
        from_date = datetime.utcnow() - timedelta(days=days)
        result = await self.db.execute(select(ConversationAnalyticsDB).where(ConversationAnalyticsDB.period_start >= from_date))
        reports = result.scalars().all()
        return {
            "period_days": days, "total_conversations": len(set(str(r.conversation_id) for r in reports)),
            "total_messages": sum(r.message_count for r in reports),
            "avg_response_time_seconds": round(sum(r.avg_response_time_seconds or 0 for r in reports) / len(reports), 2) if reports else 0,
            "total_reports": len(reports)
        }
