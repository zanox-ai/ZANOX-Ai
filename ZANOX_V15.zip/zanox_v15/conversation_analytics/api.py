from typing import Dict, Any, Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import AnalyticsReportCreate, AnalyticsReportResponse
from .service import ConversationAnalyticsService

router = APIRouter(prefix="/conversation-analytics", tags=["Conversation Analytics"])

@router.post("/reports", response_model=AnalyticsReportResponse)
async def generate_report(data: AnalyticsReportCreate, db: AsyncSession = Depends(get_db_session)):
    service = ConversationAnalyticsService(db)
    return await service.generate_report(data)

@router.get("/reports/{report_id}", response_model=AnalyticsReportResponse)
async def get_report(report_id: str, db: AsyncSession = Depends(get_db_session)):
    service = ConversationAnalyticsService(db)
    result = await service.get_report(report_id)
    if not result: raise HTTPException(status_code=404, detail="Report not found")
    return result

@router.get("/conversations/{conversation_id}/stats")
async def get_conversation_stats(conversation_id: str, days: int = Query(30, ge=1, le=365), db: AsyncSession = Depends(get_db_session)):
    service = ConversationAnalyticsService(db)
    return await service.get_conversation_stats(conversation_id, days)

@router.get("/dashboard")
async def get_dashboard(days: int = Query(7, ge=1, le=90), db: AsyncSession = Depends(get_db_session)):
    service = ConversationAnalyticsService(db)
    return await service.aggregate_dashboard(days)
