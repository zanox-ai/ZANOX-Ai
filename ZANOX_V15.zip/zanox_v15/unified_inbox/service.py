import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, and_, or_
from shared.cache import cache
from shared.messaging import messaging
from .models import InboxMessageDB, InboxMessageCreate, InboxMessageResponse

class UnifiedInboxService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def ingest_message(self, message: InboxMessageCreate) -> InboxMessageResponse:
        db_msg = InboxMessageDB(
            id=uuid.uuid4(),
            external_id=message.external_id,
            channel=message.channel,
            sender_id=message.sender_id,
            sender_name=message.sender_name,
            recipient_id=message.recipient_id,
            subject=message.subject,
            body=message.body,
            attachments=message.attachments,
            metadata=message.metadata,
            status="unread",
            thread_id=message.thread_id
        )
        self.db.add(db_msg)
        await self.db.flush()

        await messaging.send_message("inbox.new_message", {
            "message_id": str(db_msg.id),
            "channel": db_msg.channel,
            "sender": db_msg.sender_id,
            "recipient": db_msg.recipient_id
        })

        await cache.set(f"inbox:msg:{db_msg.id}", db_msg.__dict__, ttl=3600)

        return InboxMessageResponse(
            id=str(db_msg.id),
            channel=db_msg.channel,
            sender_id=db_msg.sender_id,
            sender_name=db_msg.sender_name,
            subject=db_msg.subject,
            body=db_msg.body,
            status=db_msg.status,
            is_flagged=db_msg.is_flagged,
            is_archived=db_msg.is_archived,
            labels=db_msg.labels,
            received_at=db_msg.received_at,
            read_at=db_msg.read_at
        )

    async def get_messages(
        self, 
        channel: Optional[str] = None,
        status: Optional[str] = None,
        is_flagged: Optional[bool] = None,
        limit: int = 50,
        offset: int = 0
    ) -> List[InboxMessageResponse]:
        query = select(InboxMessageDB).where(InboxMessageDB.is_archived == False)
        if channel:
            query = query.where(InboxMessageDB.channel == channel)
        if status:
            query = query.where(InboxMessageDB.status == status)
        if is_flagged is not None:
            query = query.where(InboxMessageDB.is_flagged == is_flagged)
        query = query.order_by(InboxMessageDB.received_at.desc()).limit(limit).offset(offset)
        result = await self.db.execute(query)
        return [
            InboxMessageResponse(
                id=str(m.id), channel=m.channel, sender_id=m.sender_id,
                sender_name=m.sender_name, subject=m.subject, body=m.body,
                status=m.status, is_flagged=m.is_flagged, is_archived=m.is_archived,
                labels=m.labels, received_at=m.received_at, read_at=m.read_at
            ) for m in result.scalars().all()
        ]

    async def mark_read(self, message_id: str) -> bool:
        await self.db.execute(
            update(InboxMessageDB)
            .where(InboxMessageDB.id == uuid.UUID(message_id))
            .values(status="read", read_at=datetime.utcnow())
        )
        await cache.delete(f"inbox:msg:{message_id}")
        return True

    async def flag_message(self, message_id: str, flagged: bool = True) -> bool:
        await self.db.execute(
            update(InboxMessageDB)
            .where(InboxMessageDB.id == uuid.UUID(message_id))
            .values(is_flagged=flagged)
        )
        await cache.delete(f"inbox:msg:{message_id}")
        return True

    async def archive_message(self, message_id: str) -> bool:
        await self.db.execute(
            update(InboxMessageDB)
            .where(InboxMessageDB.id == uuid.UUID(message_id))
            .values(is_archived=True)
        )
        await cache.delete(f"inbox:msg:{message_id}")
        return True

    async def add_label(self, message_id: str, label: str) -> bool:
        result = await self.db.execute(
            select(InboxMessageDB).where(InboxMessageDB.id == uuid.UUID(message_id))
        )
        msg = result.scalar_one_or_none()
        if msg and label not in msg.labels:
            labels = list(msg.labels) + [label]
            await self.db.execute(
                update(InboxMessageDB)
                .where(InboxMessageDB.id == uuid.UUID(message_id))
                .values(labels=labels)
            )
        await cache.delete(f"inbox:msg:{message_id}")
        return True
