from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import InboxMessageCreate, InboxMessageResponse
from .service import UnifiedInboxService

router = APIRouter(prefix="/inbox", tags=["Unified Inbox"])

@router.post("/messages", response_model=InboxMessageResponse)
async def ingest_message(
    message: InboxMessageCreate,
    db: AsyncSession = Depends(get_db_session)
):
    service = UnifiedInboxService(db)
    return await service.ingest_message(message)

@router.get("/messages", response_model=List[InboxMessageResponse])
async def get_messages(
    channel: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    is_flagged: Optional[bool] = Query(None),
    limit: int = Query(50, ge=1, le=100),
    offset: int = Query(0, ge=0),
    db: AsyncSession = Depends(get_db_session)
):
    service = UnifiedInboxService(db)
    return await service.get_messages(channel, status, is_flagged, limit, offset)

@router.patch("/messages/{message_id}/read")
async def mark_read(
    message_id: str,
    db: AsyncSession = Depends(get_db_session)
):
    service = UnifiedInboxService(db)
    await service.mark_read(message_id)
    return {"status": "marked_read", "message_id": message_id}

@router.patch("/messages/{message_id}/flag")
async def flag_message(
    message_id: str,
    flagged: bool = True,
    db: AsyncSession = Depends(get_db_session)
):
    service = UnifiedInboxService(db)
    await service.flag_message(message_id, flagged)
    return {"status": "flagged" if flagged else "unflagged", "message_id": message_id}

@router.patch("/messages/{message_id}/archive")
async def archive_message(
    message_id: str,
    db: AsyncSession = Depends(get_db_session)
):
    service = UnifiedInboxService(db)
    await service.archive_message(message_id)
    return {"status": "archived", "message_id": message_id}

@router.post("/messages/{message_id}/labels")
async def add_label(
    message_id: str,
    label: str,
    db: AsyncSession = Depends(get_db_session)
):
    service = UnifiedInboxService(db)
    await service.add_label(message_id, label)
    return {"status": "label_added", "message_id": message_id, "label": label}
