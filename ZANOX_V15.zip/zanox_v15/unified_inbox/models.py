from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Enum as SQLEnum, Text, ForeignKey, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel, CommunicationChannel, MessageStatus
import uuid

class InboxMessageDB(Base):
    __tablename__ = "inbox_messages"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    external_id = Column(String(255), nullable=True, index=True)
    channel = Column(String(50), nullable=False, index=True)
    sender_id = Column(String(255), nullable=False, index=True)
    sender_name = Column(String(255), nullable=True)
    recipient_id = Column(String(255), nullable=False)
    subject = Column(Text, nullable=True)
    body = Column(Text, nullable=False)
    attachments = Column(JSON, default=list)
    metadata = Column(JSON, default=dict)
    status = Column(String(50), default="unread")
    is_flagged = Column(Boolean, default=False)
    is_archived = Column(Boolean, default=False)
    labels = Column(ARRAY(String), default=list)
    thread_id = Column(String(255), nullable=True, index=True)
    conversation_id = Column(UUID(as_uuid=True), ForeignKey("conversations.id"), nullable=True)
    received_at = Column(DateTime, default=datetime.utcnow)
    read_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

class InboxMessageCreate(ZANOXBaseModel):
    channel: str
    sender_id: str
    sender_name: Optional[str] = None
    recipient_id: str
    subject: Optional[str] = None
    body: str
    attachments: Optional[List[Dict[str, Any]]] = Field(default_factory=list)
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict)
    thread_id: Optional[str] = None
    external_id: Optional[str] = None

class InboxMessageResponse(ZANOXBaseModel):
    id: str
    channel: str
    sender_id: str
    sender_name: Optional[str] = None
    subject: Optional[str] = None
    body: str
    status: str
    is_flagged: bool
    is_archived: bool
    labels: List[str]
    received_at: datetime
    read_at: Optional[datetime] = None
