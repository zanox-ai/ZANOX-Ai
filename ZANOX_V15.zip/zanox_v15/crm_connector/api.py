from typing import Optional, List, Dict, Any
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import CRMConnectionCreate, CRMConnectionResponse
from .service import CRMConnectorService

router = APIRouter(prefix="/crm-connector", tags=["CRM Connector"])

@router.post("/connections", response_model=CRMConnectionResponse)
async def create_connection(data: CRMConnectionCreate, db: AsyncSession = Depends(get_db_session)):
    service = CRMConnectorService(db)
    return await service.create_connection(data)

@router.post("/connections/{connection_id}/sync")
async def sync_connection(connection_id: str, db: AsyncSession = Depends(get_db_session)):
    service = CRMConnectorService(db)
    result = await service.sync_connection(connection_id)
    if "error" in result: raise HTTPException(status_code=404, detail=result["error"])
    return result

@router.get("/connections/{connection_id}", response_model=CRMConnectionResponse)
async def get_connection(connection_id: str, db: AsyncSession = Depends(get_db_session)):
    service = CRMConnectorService(db)
    result = await service.get_connection(connection_id)
    if not result: raise HTTPException(status_code=404, detail="Connection not found")
    return result

@router.get("/connections", response_model=List[CRMConnectionResponse])
async def list_connections(provider: Optional[str] = None, db: AsyncSession = Depends(get_db_session)):
    service = CRMConnectorService(db)
    return await service.list_connections(provider)
