from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Text, ForeignKey, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel
import uuid

class CRMConnectionDB(Base):
    __tablename__ = "crm_connections"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    provider = Column(String(50), nullable=False)
    name = Column(String(255), nullable=False)
    credentials = Column(JSON, default=dict)
    api_endpoint = Column(String(1024), nullable=True)
    webhook_url = Column(String(1024), nullable=True)
    sync_interval_minutes = Column(Integer, default=60)
    last_sync_at = Column(DateTime, nullable=True)
    status = Column(String(50), default="inactive")
    mappings = Column(JSON, default=dict)
    is_active = Column(Boolean, default=True)
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class CRMConnectionCreate(ZANOXBaseModel):
    provider: str
    name: str
    credentials: Optional[Dict[str, Any]] = Field(default_factory=dict)
    api_endpoint: Optional[str] = None
    webhook_url: Optional[str] = None
    sync_interval_minutes: int = 60
    mappings: Optional[Dict[str, Any]] = Field(default_factory=dict)

class CRMConnectionResponse(ZANOXBaseModel):
    id: str
    provider: str
    name: str
    status: str
    last_sync_at: Optional[datetime] = None
    sync_interval_minutes: int
    is_active: bool
    created_at: datetime
