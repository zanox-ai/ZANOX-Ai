import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from shared.cache import cache
from shared.messaging import messaging
from .models import CRMConnectionDB, CRMConnectionCreate, CRMConnectionResponse

class CRMConnectorService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_connection(self, data: CRMConnectionCreate) -> CRMConnectionResponse:
        db_conn = CRMConnectionDB(
            id=uuid.uuid4(), provider=data.provider, name=data.name,
            credentials=data.credentials, api_endpoint=data.api_endpoint,
            webhook_url=data.webhook_url, sync_interval_minutes=data.sync_interval_minutes,
            mappings=data.mappings
        )
        self.db.add(db_conn)
        await self.db.flush()
        await cache.set(f"crm:{db_conn.id}", db_conn.__dict__, ttl=86400)
        await messaging.send_message("crm.connection_created", {"connection_id": str(db_conn.id), "provider": data.provider})
        return CRMConnectionResponse(
            id=str(db_conn.id), provider=db_conn.provider, name=db_conn.name,
            status=db_conn.status, last_sync_at=db_conn.last_sync_at,
            sync_interval_minutes=db_conn.sync_interval_minutes, is_active=db_conn.is_active,
            created_at=db_conn.created_at
        )

    async def sync_connection(self, connection_id: str) -> Dict[str, Any]:
        result = await self.db.execute(select(CRMConnectionDB).where(CRMConnectionDB.id == uuid.UUID(connection_id)))
        conn = result.scalar_one_or_none()
        if not conn: return {"error": "Connection not found"}
        await self.db.execute(
            update(CRMConnectionDB).where(CRMConnectionDB.id == uuid.UUID(connection_id))
            .values(last_sync_at=datetime.utcnow(), status="active", updated_at=datetime.utcnow())
        )
        await cache.delete(f"crm:{connection_id}")
        await messaging.send_message("crm.synced", {"connection_id": connection_id, "provider": conn.provider, "timestamp": datetime.utcnow().isoformat()})
        return {"connection_id": connection_id, "status": "synced", "provider": conn.provider, "timestamp": datetime.utcnow().isoformat()}

    async def get_connection(self, connection_id: str) -> Optional[CRMConnectionResponse]:
        cached = await cache.get(f"crm:{connection_id}")
        if cached: return CRMConnectionResponse(**cached)
        result = await self.db.execute(select(CRMConnectionDB).where(CRMConnectionDB.id == uuid.UUID(connection_id)))
        c = result.scalar_one_or_none()
        if not c: return None
        return CRMConnectionResponse(
            id=str(c.id), provider=c.provider, name=c.name, status=c.status,
            last_sync_at=c.last_sync_at, sync_interval_minutes=c.sync_interval_minutes,
            is_active=c.is_active, created_at=c.created_at
        )

    async def list_connections(self, provider: Optional[str] = None) -> List[CRMConnectionResponse]:
        query = select(CRMConnectionDB).where(CRMConnectionDB.is_active == True)
        if provider: query = query.where(CRMConnectionDB.provider == provider)
        result = await self.db.execute(query)
        return [CRMConnectionResponse(
            id=str(c.id), provider=c.provider, name=c.name, status=c.status,
            last_sync_at=c.last_sync_at, sync_interval_minutes=c.sync_interval_minutes,
            is_active=c.is_active, created_at=c.created_at
        ) for c in result.scalars().all()]
