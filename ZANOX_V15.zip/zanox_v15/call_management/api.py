from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import CallCreate, CallResponse
from .service import CallManagementService

router = APIRouter(prefix="/calls", tags=["Call Management"])

@router.post("/", response_model=CallResponse)
async def create_call(data: CallCreate, db: AsyncSession = Depends(get_db_session)):
    service = CallManagementService(db)
    return await service.create_call(data)

@router.post("/{call_id}/start")
async def start_call(call_id: str, db: AsyncSession = Depends(get_db_session)):
    service = CallManagementService(db)
    return await service.start_call(call_id)

@router.post("/{call_id}/end")
async def end_call(call_id: str, duration: int, db: AsyncSession = Depends(get_db_session)):
    service = CallManagementService(db)
    return await service.end_call(call_id, duration)

@router.get("/{call_id}", response_model=CallResponse)
async def get_call(call_id: str, db: AsyncSession = Depends(get_db_session)):
    service = CallManagementService(db)
    result = await service.get_call(call_id)
    if not result: raise HTTPException(status_code=404, detail="Call not found")
    return result

@router.get("/", response_model=List[CallResponse])
async def list_calls(caller_id: Optional[str] = Query(None), status: Optional[str] = Query(None), limit: int = Query(50, ge=1, le=100), db: AsyncSession = Depends(get_db_session)):
    service = CallManagementService(db)
    return await service.list_calls(caller_id, status, limit)
