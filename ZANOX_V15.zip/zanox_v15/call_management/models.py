from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Text, ForeignKey, Float, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel
import uuid

class CallDB(Base):
    __tablename__ = "calls"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    call_type = Column(String(50), default="outbound")
    caller_id = Column(String(255), nullable=False)
    callee_id = Column(String(255), nullable=False)
    channel = Column(String(50), default="voice")
    status = Column(String(50), default="initiated")
    started_at = Column(DateTime, nullable=True)
    ended_at = Column(DateTime, nullable=True)
    duration_seconds = Column(Integer, nullable=True)
    recording_id = Column(UUID(as_uuid=True), nullable=True)
    quality_score = Column(Float, nullable=True)
    notes = Column(Text, nullable=True)
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class CallCreate(ZANOXBaseModel):
    call_type: str = "outbound"
    caller_id: str
    callee_id: str
    channel: str = "voice"
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict)

class CallResponse(ZANOXBaseModel):
    id: str
    call_type: str
    caller_id: str
    callee_id: str
    channel: str
    status: str
    started_at: Optional[datetime] = None
    ended_at: Optional[datetime] = None
    duration_seconds: Optional[int] = None
    created_at: datetime
