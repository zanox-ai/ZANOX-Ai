import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from shared.cache import cache
from shared.messaging import messaging
from .models import CallDB, CallCreate, CallResponse

class CallManagementService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_call(self, data: CallCreate) -> CallResponse:
        db_call = CallDB(
            id=uuid.uuid4(), call_type=data.call_type, caller_id=data.caller_id,
            callee_id=data.callee_id, channel=data.channel, metadata=data.metadata
        )
        self.db.add(db_call)
        await self.db.flush()
        await messaging.send_message("call.created", {"call_id": str(db_call.id), "caller": data.caller_id, "callee": data.callee_id})
        return CallResponse(
            id=str(db_call.id), call_type=db_call.call_type, caller_id=db_call.caller_id,
            callee_id=db_call.callee_id, channel=db_call.channel, status=db_call.status,
            started_at=db_call.started_at, ended_at=db_call.ended_at,
            duration_seconds=db_call.duration_seconds, created_at=db_call.created_at
        )

    async def start_call(self, call_id: str) -> Dict[str, Any]:
        await self.db.execute(
            update(CallDB).where(CallDB.id == uuid.UUID(call_id)).values(started_at=datetime.utcnow(), status="active", updated_at=datetime.utcnow())
        )
        await messaging.send_message("call.started", {"call_id": call_id, "timestamp": datetime.utcnow().isoformat()})
        return {"call_id": call_id, "status": "active", "started_at": datetime.utcnow().isoformat()}

    async def end_call(self, call_id: str, duration: int) -> Dict[str, Any]:
        await self.db.execute(
            update(CallDB).where(CallDB.id == uuid.UUID(call_id)).values(ended_at=datetime.utcnow(), status="completed", duration_seconds=duration, updated_at=datetime.utcnow())
        )
        await messaging.send_message("call.ended", {"call_id": call_id, "duration": duration})
        return {"call_id": call_id, "status": "completed", "duration": duration}

    async def get_call(self, call_id: str) -> Optional[CallResponse]:
        result = await self.db.execute(select(CallDB).where(CallDB.id == uuid.UUID(call_id)))
        c = result.scalar_one_or_none()
        if not c: return None
        return CallResponse(
            id=str(c.id), call_type=c.call_type, caller_id=c.caller_id, callee_id=c.callee_id,
            channel=c.channel, status=c.status, started_at=c.started_at, ended_at=c.ended_at,
            duration_seconds=c.duration_seconds, created_at=c.created_at
        )

    async def list_calls(self, caller_id: Optional[str] = None, status: Optional[str] = None, limit: int = 50) -> List[CallResponse]:
        query = select(CallDB)
        if caller_id: query = query.where(CallDB.caller_id == caller_id)
        if status: query = query.where(CallDB.status == status)
        query = query.order_by(CallDB.created_at.desc()).limit(limit)
        result = await self.db.execute(query)
        return [CallResponse(
            id=str(c.id), call_type=c.call_type, caller_id=c.caller_id, callee_id=c.callee_id,
            channel=c.channel, status=c.status, started_at=c.started_at, ended_at=c.ended_at,
            duration_seconds=c.duration_seconds, created_at=c.created_at
        ) for c in result.scalars().all()]
