from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Text, ForeignKey, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel
import uuid

class StatusUpdateDB(Base):
    __tablename__ = "status_updates"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(String(255), nullable=False, index=True)
    status_text = Column(String(500), nullable=False)
    emoji = Column(String(50), nullable=True)
    expires_at = Column(DateTime, nullable=True)
    is_auto = Column(Boolean, default=False)
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)

class StatusUpdateCreate(ZANOXBaseModel):
    user_id: str
    status_text: str
    emoji: Optional[str] = None
    expires_at: Optional[datetime] = None
    is_auto: bool = False
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict)

class StatusUpdateResponse(ZANOXBaseModel):
    id: str
    user_id: str
    status_text: str
    emoji: Optional[str] = None
    expires_at: Optional[datetime] = None
    is_auto: bool
    created_at: datetime
