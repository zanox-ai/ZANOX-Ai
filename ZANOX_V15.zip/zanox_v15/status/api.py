from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import StatusUpdateCreate, StatusUpdateResponse
from .service import StatusService

router = APIRouter(prefix="/status", tags=["Status Engine"])

@router.post("/", response_model=StatusUpdateResponse)
async def create_status(data: StatusUpdateCreate, db: AsyncSession = Depends(get_db_session)):
    service = StatusService(db)
    return await service.create_status(data)

@router.get("/users/{user_id}", response_model=StatusUpdateResponse)
async def get_status(user_id: str, db: AsyncSession = Depends(get_db_session)):
    service = StatusService(db)
    result = await service.get_status(user_id)
    if not result: raise HTTPException(status_code=404, detail="Status not found")
    return result

@router.get("/recent", response_model=List[StatusUpdateResponse])
async def get_recent(limit: int = Query(50, ge=1, le=100), db: AsyncSession = Depends(get_db_session)):
    service = StatusService(db)
    return await service.get_recent(limit)
