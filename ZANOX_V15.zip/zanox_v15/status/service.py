import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from shared.cache import cache
from shared.messaging import messaging
from .models import StatusUpdateDB, StatusUpdateCreate, StatusUpdateResponse

class StatusService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_status(self, data: StatusUpdateCreate) -> StatusUpdateResponse:
        db_status = StatusUpdateDB(
            id=uuid.uuid4(), user_id=data.user_id, status_text=data.status_text,
            emoji=data.emoji, expires_at=data.expires_at, is_auto=data.is_auto, metadata=data.metadata
        )
        self.db.add(db_status)
        await self.db.flush()
        await cache.set(f"status:{data.user_id}", db_status.__dict__, ttl=3600)
        await messaging.send_message("status.updated", {"user_id": data.user_id, "status": data.status_text})
        return StatusUpdateResponse(
            id=str(db_status.id), user_id=db_status.user_id, status_text=db_status.status_text,
            emoji=db_status.emoji, expires_at=db_status.expires_at, is_auto=db_status.is_auto, created_at=db_status.created_at
        )

    async def get_status(self, user_id: str) -> Optional[StatusUpdateResponse]:
        cached = await cache.get(f"status:{user_id}")
        if cached: return StatusUpdateResponse(**cached)
        result = await self.db.execute(
            select(StatusUpdateDB).where(StatusUpdateDB.user_id == user_id).order_by(StatusUpdateDB.created_at.desc()).limit(1)
        )
        s = result.scalar_one_or_none()
        if not s: return None
        return StatusUpdateResponse(
            id=str(s.id), user_id=s.user_id, status_text=s.status_text,
            emoji=s.emoji, expires_at=s.expires_at, is_auto=s.is_auto, created_at=s.created_at
        )

    async def get_recent(self, limit: int = 50) -> List[StatusUpdateResponse]:
        result = await self.db.execute(select(StatusUpdateDB).order_by(StatusUpdateDB.created_at.desc()).limit(limit))
        return [StatusUpdateResponse(
            id=str(s.id), user_id=s.user_id, status_text=s.status_text,
            emoji=s.emoji, expires_at=s.expires_at, is_auto=s.is_auto, created_at=s.created_at
        ) for s in result.scalars().all()]
