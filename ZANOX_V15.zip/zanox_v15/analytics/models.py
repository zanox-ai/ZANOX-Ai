from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Text, ForeignKey, Float, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel
import uuid

class AnalyticsMetricDB(Base):
    __tablename__ = "analytics_metrics"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    metric_name = Column(String(255), nullable=False, index=True)
    metric_value = Column(Float, nullable=False)
    metric_type = Column(String(50), default="count")
    dimensions = Column(JSON, default=dict)
    period_start = Column(DateTime, nullable=False)
    period_end = Column(DateTime, nullable=False)
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)

class AnalyticsMetricCreate(ZANOXBaseModel):
    metric_name: str
    metric_value: float
    metric_type: str = "count"
    dimensions: Optional[Dict[str, Any]] = Field(default_factory=dict)
    period_start: datetime
    period_end: datetime
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict)

class AnalyticsMetricResponse(ZANOXBaseModel):
    id: str
    metric_name: str
    metric_value: float
    metric_type: str
    dimensions: Dict[str, Any]
    period_start: datetime
    period_end: datetime
    created_at: datetime
