import uuid
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from shared.cache import cache
from shared.messaging import messaging
from .models import AnalyticsMetricDB, AnalyticsMetricCreate, AnalyticsMetricResponse

class AnalyticsService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def record_metric(self, data: AnalyticsMetricCreate) -> AnalyticsMetricResponse:
        db_metric = AnalyticsMetricDB(
            id=uuid.uuid4(), metric_name=data.metric_name, metric_value=data.metric_value,
            metric_type=data.metric_type, dimensions=data.dimensions,
            period_start=data.period_start, period_end=data.period_end, metadata=data.metadata
        )
        self.db.add(db_metric)
        await self.db.flush()
        await messaging.send_message("analytics.metric", {
            "metric_id": str(db_metric.id), "name": data.metric_name, "value": data.metric_value
        })
        return AnalyticsMetricResponse(
            id=str(db_metric.id), metric_name=db_metric.metric_name, metric_value=db_metric.metric_value,
            metric_type=db_metric.metric_type, dimensions=db_metric.dimensions,
            period_start=db_metric.period_start, period_end=db_metric.period_end, created_at=db_metric.created_at
        )

    async def get_metrics(self, metric_name: str, days: int = 30) -> List[AnalyticsMetricResponse]:
        from_date = datetime.utcnow() - timedelta(days=days)
        result = await self.db.execute(
            select(AnalyticsMetricDB)
            .where(AnalyticsMetricDB.metric_name == metric_name)
            .where(AnalyticsMetricDB.period_start >= from_date)
            .order_by(AnalyticsMetricDB.period_start.desc())
        )
        return [AnalyticsMetricResponse(
            id=str(m.id), metric_name=m.metric_name, metric_value=m.metric_value,
            metric_type=m.metric_type, dimensions=m.dimensions,
            period_start=m.period_start, period_end=m.period_end, created_at=m.created_at
        ) for m in result.scalars().all()]

    async def aggregate_metric(self, metric_name: str, days: int = 30) -> Dict[str, Any]:
        from_date = datetime.utcnow() - timedelta(days=days)
        result = await self.db.execute(
            select(AnalyticsMetricDB)
            .where(AnalyticsMetricDB.metric_name == metric_name)
            .where(AnalyticsMetricDB.period_start >= from_date)
        )
        metrics = result.scalars().all()
        if not metrics: return {"metric_name": metric_name, "total": 0, "avg": 0, "min": 0, "max": 0}
        values = [m.metric_value for m in metrics]
        return {
            "metric_name": metric_name, "total": sum(values), "avg": round(sum(values) / len(values), 2),
            "min": min(values), "max": max(values), "count": len(values)
        }

    async def get_communication_overview(self, days: int = 7) -> Dict[str, Any]:
        from_date = datetime.utcnow() - timedelta(days=days)
        result = await self.db.execute(
            select(AnalyticsMetricDB).where(AnalyticsMetricDB.period_start >= from_date)
        )
        metrics = result.scalars().all()
        by_name = {}
        for m in metrics:
            by_name[m.metric_name] = by_name.get(m.metric_name, 0) + m.metric_value
        return {"period_days": days, "metrics": by_name, "total_records": len(metrics)}
