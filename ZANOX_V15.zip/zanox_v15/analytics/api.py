from typing import Optional, List, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import AnalyticsMetricCreate, AnalyticsMetricResponse
from .service import AnalyticsService

router = APIRouter(prefix="/analytics", tags=["Analytics"])

@router.post("/metrics", response_model=AnalyticsMetricResponse)
async def record_metric(data: AnalyticsMetricCreate, db: AsyncSession = Depends(get_db_session)):
    service = AnalyticsService(db)
    return await service.record_metric(data)

@router.get("/metrics/{metric_name}", response_model=List[AnalyticsMetricResponse])
async def get_metrics(metric_name: str, days: int = Query(30, ge=1, le=365), db: AsyncSession = Depends(get_db_session)):
    service = AnalyticsService(db)
    return await service.get_metrics(metric_name, days)

@router.get("/metrics/{metric_name}/aggregate")
async def aggregate_metric(metric_name: str, days: int = Query(30, ge=1, le=365), db: AsyncSession = Depends(get_db_session)):
    service = AnalyticsService(db)
    return await service.aggregate_metric(metric_name, days)

@router.get("/communication-overview")
async def get_communication_overview(days: int = Query(7, ge=1, le=90), db: AsyncSession = Depends(get_db_session)):
    service = AnalyticsService(db)
    return await service.get_communication_overview(days)
