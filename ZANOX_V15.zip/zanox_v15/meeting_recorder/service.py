import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from shared.cache import cache
from shared.messaging import messaging
from .models import RecordingDB, RecordingCreate, RecordingResponse

class MeetingRecorderService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def start_recording(self, recording: RecordingCreate) -> RecordingResponse:
        db_rec = RecordingDB(
            id=uuid.uuid4(),
            meeting_id=uuid.UUID(recording.meeting_id),
            format=recording.format,
            status="recording",
            metadata=recording.metadata
        )
        self.db.add(db_rec)
        await self.db.flush()

        await messaging.send_message("recording.started", {
            "recording_id": str(db_rec.id),
            "meeting_id": recording.meeting_id,
            "timestamp": datetime.utcnow().isoformat()
        })

        return RecordingResponse(
            id=str(db_rec.id), meeting_id=recording.meeting_id,
            recording_url=db_rec.recording_url, format=db_rec.format,
            duration_seconds=db_rec.duration_seconds,
            status=db_rec.status, started_at=db_rec.started_at,
            stopped_at=db_rec.stopped_at
        )

    async def stop_recording(self, recording_id: str, duration: int, file_size: int, url: Optional[str] = None) -> Dict[str, Any]:
        await self.db.execute(
            update(RecordingDB)
            .where(RecordingDB.id == uuid.UUID(recording_id))
            .values(
                status="completed",
                duration_seconds=duration,
                file_size_bytes=file_size,
                recording_url=url,
                stopped_at=datetime.utcnow()
            )
        )

        await messaging.send_message("recording.completed", {
            "recording_id": recording_id,
            "duration": duration,
            "timestamp": datetime.utcnow().isoformat()
        })

        return {"recording_id": recording_id, "status": "completed", "duration": duration}

    async def get_recording(self, recording_id: str) -> Optional[RecordingResponse]:
        result = await self.db.execute(
            select(RecordingDB).where(RecordingDB.id == uuid.UUID(recording_id))
        )
        r = result.scalar_one_or_none()
        if not r:
            return None
        return RecordingResponse(
            id=str(r.id), meeting_id=str(r.meeting_id),
            recording_url=r.recording_url, format=r.format,
            duration_seconds=r.duration_seconds, status=r.status,
            started_at=r.started_at, stopped_at=r.stopped_at
        )

    async def list_recordings(self, meeting_id: Optional[str] = None, limit: int = 50) -> List[RecordingResponse]:
        query = select(RecordingDB)
        if meeting_id:
            query = query.where(RecordingDB.meeting_id == uuid.UUID(meeting_id))
        query = query.order_by(RecordingDB.created_at.desc()).limit(limit)
        result = await self.db.execute(query)
        return [
            RecordingResponse(
                id=str(r.id), meeting_id=str(r.meeting_id),
                recording_url=r.recording_url, format=r.format,
                duration_seconds=r.duration_seconds, status=r.status,
                started_at=r.started_at, stopped_at=r.stopped_at
            ) for r in result.scalars().all()
        ]
