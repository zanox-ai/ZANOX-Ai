from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import RecordingCreate, RecordingResponse
from .service import MeetingRecorderService

router = APIRouter(prefix="/recordings", tags=["Meeting Recorder"])

@router.post("/start", response_model=RecordingResponse)
async def start_recording(
    recording: RecordingCreate,
    db: AsyncSession = Depends(get_db_session)
):
    service = MeetingRecorderService(db)
    return await service.start_recording(recording)

@router.post("/{recording_id}/stop")
async def stop_recording(
    recording_id: str,
    duration: int,
    file_size: int,
    url: str = None,
    db: AsyncSession = Depends(get_db_session)
):
    service = MeetingRecorderService(db)
    return await service.stop_recording(recording_id, duration, file_size, url)

@router.get("/{recording_id}", response_model=RecordingResponse)
async def get_recording(
    recording_id: str,
    db: AsyncSession = Depends(get_db_session)
):
    service = MeetingRecorderService(db)
    result = await service.get_recording(recording_id)
    if not result:
        raise HTTPException(status_code=404, detail="Recording not found")
    return result

@router.get("/", response_model=List[RecordingResponse])
async def list_recordings(
    meeting_id: Optional[str] = Query(None),
    limit: int = Query(50, ge=1, le=100),
    db: AsyncSession = Depends(get_db_session)
):
    service = MeetingRecorderService(db)
    return await service.list_recordings(meeting_id, limit)
