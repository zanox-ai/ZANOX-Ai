from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Text, ForeignKey, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel
import uuid

class RecordingDB(Base):
    __tablename__ = "recordings"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    meeting_id = Column(UUID(as_uuid=True), ForeignKey("meetings.id"), nullable=False, index=True)
    recording_url = Column(String(1024), nullable=True)
    storage_path = Column(String(1024), nullable=True)
    format = Column(String(50), default="mp4")
    duration_seconds = Column(Integer, nullable=True)
    file_size_bytes = Column(Integer, nullable=True)
    status = Column(String(50), default="recording")
    started_at = Column(DateTime, default=datetime.utcnow)
    stopped_at = Column(DateTime, nullable=True)
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)

class RecordingCreate(ZANOXBaseModel):
    meeting_id: str
    format: str = "mp4"
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict)

class RecordingResponse(ZANOXBaseModel):
    id: str
    meeting_id: str
    recording_url: Optional[str] = None
    format: str
    duration_seconds: Optional[int] = None
    status: str
    started_at: datetime
    stopped_at: Optional[datetime] = None
