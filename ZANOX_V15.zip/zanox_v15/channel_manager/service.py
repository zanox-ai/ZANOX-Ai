import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from shared.cache import cache
from shared.messaging import messaging
from .models import ChannelConfigDB, ChannelConfigCreate, ChannelStatusResponse

class ChannelManagerService:
    CHANNELS = [
        "email", "telegram", "whatsapp", "discord", "slack", "teams",
        "messenger", "instagram", "linkedin", "x", "sms", "push",
        "web", "voice", "video"
    ]

    def __init__(self, db: AsyncSession):
        self.db = db

    async def initialize_channels(self) -> None:
        for ch in self.CHANNELS:
            existing = await self.db.execute(
                select(ChannelConfigDB).where(ChannelConfigDB.channel_type == ch)
            )
            if not existing.scalar_one_or_none():
                config = ChannelConfigDB(
                    id=uuid.uuid4(),
                    channel_type=ch,
                    display_name=ch.replace("_", " ").title(),
                    is_enabled=True,
                    rate_limits={"requests_per_minute": 60, "requests_per_hour": 1000}
                )
                self.db.add(config)
        await self.db.flush()

    async def get_channel(self, channel_type: str) -> Optional[ChannelStatusResponse]:
        cached = await cache.get(f"channel:{channel_type}")
        if cached:
            return ChannelStatusResponse(**cached)

        result = await self.db.execute(
            select(ChannelConfigDB).where(ChannelConfigDB.channel_type == channel_type)
        )
        config = result.scalar_one_or_none()
        if not config:
            return None
        return ChannelStatusResponse(
            channel_type=config.channel_type,
            display_name=config.display_name,
            is_enabled=config.is_enabled,
            health_status=config.health_status,
            last_health_check=config.last_health_check
        )

    async def update_channel(self, channel_type: str, updates: Dict[str, Any]) -> bool:
        await self.db.execute(
            update(ChannelConfigDB)
            .where(ChannelConfigDB.channel_type == channel_type)
            .values(**updates, updated_at=datetime.utcnow())
        )
        await cache.delete(f"channel:{channel_type}")
        return True

    async def health_check(self, channel_type: str) -> Dict[str, Any]:
        config = await self.get_channel(channel_type)
        if not config:
            return {"status": "not_found"}

        status = "healthy"
        await self.update_channel(channel_type, {
            "last_health_check": datetime.utcnow(),
            "health_status": status
        })

        await messaging.send_message("channel.health", {
            "channel": channel_type,
            "status": status,
            "timestamp": datetime.utcnow().isoformat()
        })

        return {"channel": channel_type, "status": status, "checked_at": datetime.utcnow().isoformat()}

    async def list_channels(self) -> List[ChannelStatusResponse]:
        result = await self.db.execute(select(ChannelConfigDB))
        return [
            ChannelStatusResponse(
                channel_type=c.channel_type,
                display_name=c.display_name,
                is_enabled=c.is_enabled,
                health_status=c.health_status,
                last_health_check=c.last_health_check
            ) for c in result.scalars().all()
        ]
