from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Enum as SQLEnum, Text, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel
import uuid

class ChannelConfigDB(Base):
    __tablename__ = "channel_configs"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    channel_type = Column(String(50), nullable=False, unique=True)
    display_name = Column(String(255), nullable=False)
    is_enabled = Column(Boolean, default=True)
    credentials = Column(JSON, default=dict)
    rate_limits = Column(JSON, default=dict)
    webhook_url = Column(String(512), nullable=True)
    api_endpoint = Column(String(512), nullable=True)
    settings = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_health_check = Column(DateTime, nullable=True)
    health_status = Column(String(50), default="unknown")

class ChannelConfigCreate(ZANOXBaseModel):
    channel_type: str
    display_name: str
    credentials: Optional[Dict[str, Any]] = Field(default_factory=dict)
    rate_limits: Optional[Dict[str, Any]] = Field(default_factory=dict)
    webhook_url: Optional[str] = None
    api_endpoint: Optional[str] = None
    settings: Optional[Dict[str, Any]] = Field(default_factory=dict)

class ChannelStatusResponse(ZANOXBaseModel):
    channel_type: str
    display_name: str
    is_enabled: bool
    health_status: str
    last_health_check: Optional[datetime] = None
