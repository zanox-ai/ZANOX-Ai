from typing import List, Dict, Any
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import ChannelConfigCreate, ChannelStatusResponse
from .service import ChannelManagerService

router = APIRouter(prefix="/channels", tags=["Channel Manager"])

@router.get("/", response_model=List[ChannelStatusResponse])
async def list_channels(
    db: AsyncSession = Depends(get_db_session)
):
    service = ChannelManagerService(db)
    return await service.list_channels()

@router.get("/{channel_type}", response_model=ChannelStatusResponse)
async def get_channel(
    channel_type: str,
    db: AsyncSession = Depends(get_db_session)
):
    service = ChannelManagerService(db)
    result = await service.get_channel(channel_type)
    if not result:
        raise HTTPException(status_code=404, detail="Channel not found")
    return result

@router.post("/{channel_type}/health-check")
async def health_check(
    channel_type: str,
    db: AsyncSession = Depends(get_db_session)
):
    service = ChannelManagerService(db)
    return await service.health_check(channel_type)

@router.patch("/{channel_type}")
async def update_channel(
    channel_type: str,
    updates: Dict[str, Any],
    db: AsyncSession = Depends(get_db_session)
):
    service = ChannelManagerService(db)
    success = await service.update_channel(channel_type, updates)
    if not success:
        raise HTTPException(status_code=404, detail="Channel not found")
    return {"status": "updated", "channel": channel_type}
