import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from shared.cache import cache
from shared.messaging import messaging
from .models import VideoSessionDB, VideoSessionCreate, VideoSessionResponse

class VideoCommunicationService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_session(self, data: VideoSessionCreate) -> VideoSessionResponse:
        db_sess = VideoSessionDB(
            id=uuid.uuid4(), host_id=data.host_id, participant_ids=data.participant_ids,
            channel=data.channel, metadata=data.metadata
        )
        self.db.add(db_sess)
        await self.db.flush()
        await messaging.send_message("video.session_created", {
            "session_id": str(db_sess.id), "host": data.host_id, "participants": len(data.participant_ids)
        })
        return VideoSessionResponse(
            id=str(db_sess.id), channel=db_sess.channel, host_id=db_sess.host_id,
            participant_ids=db_sess.participant_ids, status=db_sess.status,
            started_at=db_sess.started_at, ended_at=db_sess.ended_at,
            duration_seconds=db_sess.duration_seconds, screen_shared=db_sess.screen_shared,
            created_at=db_sess.created_at
        )

    async def start_session(self, session_id: str) -> Dict[str, Any]:
        await self.db.execute(
            update(VideoSessionDB).where(VideoSessionDB.id == uuid.UUID(session_id))
            .values(started_at=datetime.utcnow(), status="active", updated_at=datetime.utcnow())
        )
        await messaging.send_message("video.session_started", {"session_id": session_id, "timestamp": datetime.utcnow().isoformat()})
        return {"session_id": session_id, "status": "active", "started_at": datetime.utcnow().isoformat()}

    async def end_session(self, session_id: str, duration: int) -> Dict[str, Any]:
        await self.db.execute(
            update(VideoSessionDB).where(VideoSessionDB.id == uuid.UUID(session_id))
            .values(ended_at=datetime.utcnow(), status="completed", duration_seconds=duration, updated_at=datetime.utcnow())
        )
        await messaging.send_message("video.session_ended", {"session_id": session_id, "duration": duration})
        return {"session_id": session_id, "status": "completed", "duration": duration}

    async def toggle_screen_share(self, session_id: str, enabled: bool) -> bool:
        await self.db.execute(
            update(VideoSessionDB).where(VideoSessionDB.id == uuid.UUID(session_id))
            .values(screen_shared=enabled, updated_at=datetime.utcnow())
        )
        await cache.delete(f"video:{session_id}")
        return True

    async def get_session(self, session_id: str) -> Optional[VideoSessionResponse]:
        result = await self.db.execute(select(VideoSessionDB).where(VideoSessionDB.id == uuid.UUID(session_id)))
        s = result.scalar_one_or_none()
        if not s: return None
        return VideoSessionResponse(
            id=str(s.id), channel=s.channel, host_id=s.host_id, participant_ids=s.participant_ids,
            status=s.status, started_at=s.started_at, ended_at=s.ended_at,
            duration_seconds=s.duration_seconds, screen_shared=s.screen_shared, created_at=s.created_at
        )

    async def list_sessions(self, host_id: Optional[str] = None, limit: int = 50) -> List[VideoSessionResponse]:
        query = select(VideoSessionDB)
        if host_id: query = query.where(VideoSessionDB.host_id == host_id)
        query = query.order_by(VideoSessionDB.created_at.desc()).limit(limit)
        result = await self.db.execute(query)
        return [VideoSessionResponse(
            id=str(s.id), channel=s.channel, host_id=s.host_id, participant_ids=s.participant_ids,
            status=s.status, started_at=s.started_at, ended_at=s.ended_at,
            duration_seconds=s.duration_seconds, screen_shared=s.screen_shared, created_at=s.created_at
        ) for s in result.scalars().all()]
