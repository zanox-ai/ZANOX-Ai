from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import VideoSessionCreate, VideoSessionResponse
from .service import VideoCommunicationService

router = APIRouter(prefix="/video-communication", tags=["Video Communication"])

@router.post("/sessions", response_model=VideoSessionResponse)
async def create_session(data: VideoSessionCreate, db: AsyncSession = Depends(get_db_session)):
    service = VideoCommunicationService(db)
    return await service.create_session(data)

@router.post("/sessions/{session_id}/start")
async def start_session(session_id: str, db: AsyncSession = Depends(get_db_session)):
    service = VideoCommunicationService(db)
    return await service.start_session(session_id)

@router.post("/sessions/{session_id}/end")
async def end_session(session_id: str, duration: int, db: AsyncSession = Depends(get_db_session)):
    service = VideoCommunicationService(db)
    return await service.end_session(session_id, duration)

@router.patch("/sessions/{session_id}/screen-share")
async def toggle_screen_share(session_id: str, enabled: bool, db: AsyncSession = Depends(get_db_session)):
    service = VideoCommunicationService(db)
    await service.toggle_screen_share(session_id, enabled)
    return {"status": "updated", "session_id": session_id, "screen_shared": enabled}

@router.get("/sessions/{session_id}", response_model=VideoSessionResponse)
async def get_session(session_id: str, db: AsyncSession = Depends(get_db_session)):
    service = VideoCommunicationService(db)
    result = await service.get_session(session_id)
    if not result: raise HTTPException(status_code=404, detail="Session not found")
    return result

@router.get("/sessions", response_model=List[VideoSessionResponse])
async def list_sessions(host_id: Optional[str] = Query(None), limit: int = Query(50, ge=1, le=100), db: AsyncSession = Depends(get_db_session)):
    service = VideoCommunicationService(db)
    return await service.list_sessions(host_id, limit)
