from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Text, ForeignKey, Float, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel
import uuid

class VideoSessionDB(Base):
    __tablename__ = "video_sessions"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    channel = Column(String(50), default="video")
    host_id = Column(String(255), nullable=False)
    participant_ids = Column(ARRAY(String), default=list)
    status = Column(String(50), default="initiated")
    started_at = Column(DateTime, nullable=True)
    ended_at = Column(DateTime, nullable=True)
    duration_seconds = Column(Integer, nullable=True)
    quality_score = Column(Float, nullable=True)
    recording_id = Column(UUID(as_uuid=True), nullable=True)
    screen_shared = Column(Boolean, default=False)
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)

class VideoSessionCreate(ZANOXBaseModel):
    host_id: str
    participant_ids: Optional[List[str]] = Field(default_factory=list)
    channel: str = "video"
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict)

class VideoSessionResponse(ZANOXBaseModel):
    id: str
    channel: str
    host_id: str
    participant_ids: List[str]
    status: str
    started_at: Optional[datetime] = None
    ended_at: Optional[datetime] = None
    duration_seconds: Optional[int] = None
    screen_shared: bool
    created_at: datetime
