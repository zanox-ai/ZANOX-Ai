from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Text, ForeignKey, Float, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel
import uuid

class RelationshipDB(Base):
    __tablename__ = "relationships"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    entity_a_id = Column(String(255), nullable=False, index=True)
    entity_a_type = Column(String(50), default="contact")
    entity_b_id = Column(String(255), nullable=False, index=True)
    entity_b_type = Column(String(50), default="contact")
    relationship_type = Column(String(50), default="colleague")
    strength = Column(Float, default=0.5)
    interaction_count = Column(Integer, default=0)
    last_interaction_at = Column(DateTime, nullable=True)
    common_topics = Column(ARRAY(String), default=list)
    sentiment_trend = Column(String(50), default="neutral")
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class RelationshipCreate(ZANOXBaseModel):
    entity_a_id: str
    entity_a_type: str = "contact"
    entity_b_id: str
    entity_b_type: str = "contact"
    relationship_type: str = "colleague"
    strength: float = 0.5
    common_topics: Optional[List[str]] = Field(default_factory=list)
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict)

class RelationshipResponse(ZANOXBaseModel):
    id: str
    entity_a_id: str
    entity_b_id: str
    relationship_type: str
    strength: float
    interaction_count: int
    last_interaction_at: Optional[datetime] = None
    sentiment_trend: str
    created_at: datetime
