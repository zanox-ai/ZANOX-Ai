from typing import Optional, List, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import RelationshipCreate, RelationshipResponse
from .service import RelationshipIntelligenceService

router = APIRouter(prefix="/relationship-intelligence", tags=["Relationship Intelligence"])

@router.post("/relationships", response_model=RelationshipResponse)
async def create_relationship(data: RelationshipCreate, db: AsyncSession = Depends(get_db_session)):
    service = RelationshipIntelligenceService(db)
    return await service.create_relationship(data)

@router.post("/relationships/{relationship_id}/interact")
async def record_interaction(relationship_id: str, sentiment: str = None, db: AsyncSession = Depends(get_db_session)):
    service = RelationshipIntelligenceService(db)
    success = await service.record_interaction(relationship_id, sentiment)
    if not success: raise HTTPException(status_code=404, detail="Relationship not found")
    return {"status": "interaction_recorded", "relationship_id": relationship_id}

@router.get("/entities/{entity_id}/relationships", response_model=List[RelationshipResponse])
async def get_relationships(entity_id: str, entity_type: Optional[str] = Query(None), limit: int = Query(50, ge=1, le=100), db: AsyncSession = Depends(get_db_session)):
    service = RelationshipIntelligenceService(db)
    return await service.get_relationships(entity_id, entity_type, limit)

@router.get("/entities/{entity_id}/network")
async def get_network(entity_id: str, depth: int = Query(1, ge=1, le=3), db: AsyncSession = Depends(get_db_session)):
    service = RelationshipIntelligenceService(db)
    return await service.get_network(entity_id, depth)
