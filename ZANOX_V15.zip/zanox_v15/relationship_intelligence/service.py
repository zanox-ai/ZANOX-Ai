import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from shared.cache import cache
from shared.messaging import messaging
from .models import RelationshipDB, RelationshipCreate, RelationshipResponse

class RelationshipIntelligenceService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_relationship(self, data: RelationshipCreate) -> RelationshipResponse:
        db_rel = RelationshipDB(
            id=uuid.uuid4(), entity_a_id=data.entity_a_id, entity_a_type=data.entity_a_type,
            entity_b_id=data.entity_b_id, entity_b_type=data.entity_b_type,
            relationship_type=data.relationship_type, strength=data.strength,
            common_topics=data.common_topics, metadata=data.metadata
        )
        self.db.add(db_rel)
        await self.db.flush()
        await cache.set(f"rel:{db_rel.id}", db_rel.__dict__, ttl=86400)
        await messaging.send_message("relationship.created", {
            "relationship_id": str(db_rel.id), "a": data.entity_a_id, "b": data.entity_b_id
        })
        return RelationshipResponse(
            id=str(db_rel.id), entity_a_id=db_rel.entity_a_id, entity_b_id=db_rel.entity_b_id,
            relationship_type=db_rel.relationship_type, strength=db_rel.strength,
            interaction_count=db_rel.interaction_count, last_interaction_at=db_rel.last_interaction_at,
            sentiment_trend=db_rel.sentiment_trend, created_at=db_rel.created_at
        )

    async def record_interaction(self, relationship_id: str, sentiment: Optional[str] = None) -> bool:
        result = await self.db.execute(select(RelationshipDB).where(RelationshipDB.id == uuid.UUID(relationship_id)))
        rel = result.scalar_one_or_none()
        if not rel: return False
        await self.db.execute(
            update(RelationshipDB).where(RelationshipDB.id == uuid.UUID(relationship_id))
            .values(
                interaction_count=rel.interaction_count + 1,
                last_interaction_at=datetime.utcnow(),
                sentiment_trend=sentiment or rel.sentiment_trend,
                updated_at=datetime.utcnow()
            )
        )
        await cache.delete(f"rel:{relationship_id}")
        return True

    async def get_relationships(self, entity_id: str, entity_type: Optional[str] = None, limit: int = 50) -> List[RelationshipResponse]:
        query = select(RelationshipDB).where(
            (RelationshipDB.entity_a_id == entity_id) | (RelationshipDB.entity_b_id == entity_id)
        )
        if entity_type: query = query.where((RelationshipDB.entity_a_type == entity_type) | (RelationshipDB.entity_b_type == entity_type))
        query = query.order_by(RelationshipDB.strength.desc()).limit(limit)
        result = await self.db.execute(query)
        return [RelationshipResponse(
            id=str(r.id), entity_a_id=r.entity_a_id, entity_b_id=r.entity_b_id,
            relationship_type=r.relationship_type, strength=r.strength,
            interaction_count=r.interaction_count, last_interaction_at=r.last_interaction_at,
            sentiment_trend=r.sentiment_trend, created_at=r.created_at
        ) for r in result.scalars().all()]

    async def get_network(self, entity_id: str, depth: int = 1) -> Dict[str, Any]:
        relationships = await self.get_relationships(entity_id, limit=100)
        nodes = {entity_id}
        edges = []
        for r in relationships:
            nodes.add(r.entity_a_id)
            nodes.add(r.entity_b_id)
            edges.append({"source": r.entity_a_id, "target": r.entity_b_id, "strength": r.strength, "type": r.relationship_type})
        return {"center": entity_id, "nodes": list(nodes), "edges": edges, "depth": depth}
