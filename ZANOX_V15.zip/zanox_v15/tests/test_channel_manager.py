import pytest
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_list_channels():
    response = client.get("/channels/")
    assert response.status_code in [200, 500]

def test_get_channel():
    response = client.get("/channels/email")
    assert response.status_code in [200, 404]
