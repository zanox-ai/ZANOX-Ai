import pytest
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_health_check():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "healthy"

def test_create_communication_request():
    payload = {
        "objective": "Test communication",
        "channels": ["email"],
        "target_audience": {"segment": "all"},
        "content_template": "Hello {{name}}",
        "priority": "medium"
    }
    response = client.post("/communication-engine/requests", json=payload)
    assert response.status_code in [200, 201, 422]
