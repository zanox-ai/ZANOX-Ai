import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from shared.cache import cache
from shared.messaging import messaging
from .models import BroadcastCampaignDB, BroadcastCampaignCreate, BroadcastCampaignResponse

class BroadcastEngineService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_campaign(self, campaign: BroadcastCampaignCreate) -> BroadcastCampaignResponse:
        db_campaign = BroadcastCampaignDB(
            id=uuid.uuid4(), name=campaign.name, channels=campaign.channels,
            recipients=campaign.recipients, subject=campaign.subject, body=campaign.body,
            attachments=campaign.attachments, scheduled_at=campaign.scheduled_at,
            priority=campaign.priority, status="draft"
        )
        self.db.add(db_campaign)
        await self.db.flush()
        await messaging.send_message("broadcast.campaign_created", {
            "campaign_id": str(db_campaign.id), "name": db_campaign.name,
            "recipients_count": len(db_campaign.recipients)
        })
        return BroadcastCampaignResponse(
            id=str(db_campaign.id), name=db_campaign.name, channels=db_campaign.channels,
            status=db_campaign.status, priority=db_campaign.priority.value,
            sent_count=db_campaign.sent_count, failed_count=db_campaign.failed_count,
            scheduled_at=db_campaign.scheduled_at, sent_at=db_campaign.sent_at,
            created_at=db_campaign.created_at
        )

    async def execute_campaign(self, campaign_id: str) -> Dict[str, Any]:
        result = await self.db.execute(select(BroadcastCampaignDB).where(BroadcastCampaignDB.id == uuid.UUID(campaign_id)))
        campaign = result.scalar_one_or_none()
        if not campaign: return {"error": "Campaign not found"}
        if campaign.status != "draft": return {"error": f"Campaign already {campaign.status}"}
        sent, failed = 0, 0
        for recipient in campaign.recipients:
            for channel in campaign.channels:
                try:
                    await messaging.send_message(f"channel.{channel}.send", {
                        "campaign_id": campaign_id, "recipient": recipient,
                        "subject": campaign.subject, "body": campaign.body
                    })
                    sent += 1
                except Exception: failed += 1
        await self.db.execute(
            update(BroadcastCampaignDB).where(BroadcastCampaignDB.id == uuid.UUID(campaign_id))
            .values(status="sent", sent_at=datetime.utcnow(), sent_count=sent, failed_count=failed, updated_at=datetime.utcnow())
        )
        return {"campaign_id": campaign_id, "status": "sent", "sent_count": sent, "failed_count": failed}

    async def get_campaign(self, campaign_id: str) -> Optional[BroadcastCampaignResponse]:
        result = await self.db.execute(select(BroadcastCampaignDB).where(BroadcastCampaignDB.id == uuid.UUID(campaign_id)))
        c = result.scalar_one_or_none()
        if not c: return None
        return BroadcastCampaignResponse(
            id=str(c.id), name=c.name, channels=c.channels, status=c.status,
            priority=c.priority.value, sent_count=c.sent_count, failed_count=c.failed_count,
            scheduled_at=c.scheduled_at, sent_at=c.sent_at, created_at=c.created_at
        )

    async def list_campaigns(self, status: Optional[str] = None, limit: int = 50) -> List[BroadcastCampaignResponse]:
        query = select(BroadcastCampaignDB)
        if status: query = query.where(BroadcastCampaignDB.status == status)
        query = query.order_by(BroadcastCampaignDB.created_at.desc()).limit(limit)
        result = await self.db.execute(query)
        return [BroadcastCampaignResponse(
            id=str(c.id), name=c.name, channels=c.channels, status=c.status,
            priority=c.priority.value, sent_count=c.sent_count, failed_count=c.failed_count,
            scheduled_at=c.scheduled_at, sent_at=c.sent_at, created_at=c.created_at
        ) for c in result.scalars().all()]
