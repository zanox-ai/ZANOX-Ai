from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Enum as SQLEnum, Text, ForeignKey, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel, Priority
import uuid

class BroadcastCampaignDB(Base):
    __tablename__ = "broadcast_campaigns"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(255), nullable=False)
    channels = Column(ARRAY(String), nullable=False)
    recipients = Column(ARRAY(String), nullable=False)
    subject = Column(Text, nullable=True)
    body = Column(Text, nullable=False)
    attachments = Column(JSON, default=list)
    scheduled_at = Column(DateTime, nullable=True)
    sent_at = Column(DateTime, nullable=True)
    status = Column(String(50), default="draft")
    priority = Column(SQLEnum(Priority), default=Priority.MEDIUM)
    sent_count = Column(Integer, default=0)
    failed_count = Column(Integer, default=0)
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class BroadcastCampaignCreate(ZANOXBaseModel):
    name: str
    channels: List[str]
    recipients: List[str]
    subject: Optional[str] = None
    body: str
    attachments: Optional[List[Dict[str, Any]]] = Field(default_factory=list)
    scheduled_at: Optional[datetime] = None
    priority: Priority = Priority.MEDIUM

class BroadcastCampaignResponse(ZANOXBaseModel):
    id: str
    name: str
    channels: List[str]
    status: str
    priority: str
    sent_count: int
    failed_count: int
    scheduled_at: Optional[datetime] = None
    sent_at: Optional[datetime] = None
    created_at: datetime
