from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import BroadcastCampaignCreate, BroadcastCampaignResponse
from .service import BroadcastEngineService

router = APIRouter(prefix="/broadcast", tags=["Broadcast Engine"])

@router.post("/campaigns", response_model=BroadcastCampaignResponse)
async def create_campaign(campaign: BroadcastCampaignCreate, db: AsyncSession = Depends(get_db_session)):
    service = BroadcastEngineService(db)
    return await service.create_campaign(campaign)

@router.post("/campaigns/{campaign_id}/execute")
async def execute_campaign(campaign_id: str, db: AsyncSession = Depends(get_db_session)):
    service = BroadcastEngineService(db)
    result = await service.execute_campaign(campaign_id)
    if "error" in result: raise HTTPException(status_code=400, detail=result["error"])
    return result

@router.get("/campaigns/{campaign_id}", response_model=BroadcastCampaignResponse)
async def get_campaign(campaign_id: str, db: AsyncSession = Depends(get_db_session)):
    service = BroadcastEngineService(db)
    result = await service.get_campaign(campaign_id)
    if not result: raise HTTPException(status_code=404, detail="Campaign not found")
    return result

@router.get("/campaigns", response_model=List[BroadcastCampaignResponse])
async def list_campaigns(status: Optional[str] = Query(None), limit: int = Query(50, ge=1, le=100), db: AsyncSession = Depends(get_db_session)):
    service = BroadcastEngineService(db)
    return await service.list_campaigns(status, limit)
