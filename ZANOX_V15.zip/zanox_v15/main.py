from fastapi import FastAPI
from contextlib import asynccontextmanager
from shared.database import init_db, close_db
from shared.cache import cache
from shared.messaging import messaging

# Import all routers
from communication_engine.api import router as comm_engine_router
from communication_orchestrator.api import router as orch_router
from communication_router.api import router as router_router
from channel_manager.api import router as channel_router
from unified_inbox.api import router as inbox_router
from unified_outbox.api import router as outbox_router
from conversation_engine.api import router as conv_router
from conversation_memory.api import router as mem_router
from conversation_search.api import router as search_router
from conversation_analytics.api import router as analytics_router
from messaging_engine.api import router as msg_router
from broadcast_engine.api import router as broadcast_router
from campaign_engine.api import router as campaign_router
from followup_engine.api import router as followup_router
from notification_engine.api import router as notif_router
from alert_engine.api import router as alert_router
from meeting_engine.api import router as meeting_router
from meeting_scheduler.api import router as scheduler_router
from meeting_recorder.api import router as recorder_router
from transcription_engine.api import router as trans_router
from meeting_summary.api import router as summary_router
from meeting_intelligence.api import router as intel_router
from call_management.api import router as call_router
from contacts.api import router as contacts_router
from crm_connector.api import router as crm_router
from customer_communication.api import router as customer_router
from community_management.api import router as community_router
from team_collaboration.api import router as team_router
from internal_messaging.api import router as internal_router
from presence.api import router as presence_router
from status.api import router as status_router
from task_extraction.api import router as task_router
from action_items.api import router as action_router
from relationship_intelligence.api import router as rel_router
from sentiment_analysis.api import router as sentiment_router
from translation.api import router as translation_router
from voice_communication.api import router as voice_router
from video_communication.api import router as video_router
from monitoring.api import router as monitoring_router
from analytics.api import router as analytics_router
from security.api import router as security_router
from governance.api import router as governance_router
from compliance.api import router as compliance_router
from deployment.api import router as deployment_router

@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    yield
    await close_db()
    await cache.close()
    await messaging.stop_all()

app = FastAPI(
    title="ZANOX V15 Communication & Collaboration Layer",
    version="15.0.0",
    lifespan=lifespan
)

# Include all routers
app.include_router(comm_engine_router)
app.include_router(orch_router)
app.include_router(router_router)
app.include_router(channel_router)
app.include_router(inbox_router)
app.include_router(outbox_router)
app.include_router(conv_router)
app.include_router(mem_router)
app.include_router(search_router)
app.include_router(analytics_router)
app.include_router(msg_router)
app.include_router(broadcast_router)
app.include_router(campaign_router)
app.include_router(followup_router)
app.include_router(notif_router)
app.include_router(alert_router)
app.include_router(meeting_router)
app.include_router(scheduler_router)
app.include_router(recorder_router)
app.include_router(trans_router)
app.include_router(summary_router)
app.include_router(intel_router)
app.include_router(call_router)
app.include_router(contacts_router)
app.include_router(crm_router)
app.include_router(customer_router)
app.include_router(community_router)
app.include_router(team_router)
app.include_router(internal_router)
app.include_router(presence_router)
app.include_router(status_router)
app.include_router(task_router)
app.include_router(action_router)
app.include_router(rel_router)
app.include_router(sentiment_router)
app.include_router(translation_router)
app.include_router(voice_router)
app.include_router(video_router)
app.include_router(monitoring_router)
app.include_router(analytics_router)
app.include_router(security_router)
app.include_router(governance_router)
app.include_router(compliance_router)
app.include_router(deployment_router)

@app.get("/health")
async def health_check():
    return {"status": "healthy", "version": "15.0.0", "layer": "communication-collaboration"}

@app.get("/")
async def root():
    return {"app": "ZANOX V15", "version": "15.0.0", "docs": "/docs"}
