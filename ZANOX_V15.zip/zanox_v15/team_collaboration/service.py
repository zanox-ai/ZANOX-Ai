import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from shared.cache import cache
from shared.messaging import messaging
from .models import TeamDB, TeamCreate, TeamResponse

class TeamCollaborationService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_team(self, data: TeamCreate) -> TeamResponse:
        db_team = TeamDB(
            id=uuid.uuid4(), name=data.name, description=data.description,
            member_ids=data.member_ids, channels=data.channels,
            projects=data.projects, settings=data.settings
        )
        self.db.add(db_team)
        await self.db.flush()
        await cache.set(f"team:{db_team.id}", db_team.__dict__, ttl=86400)
        await messaging.send_message("team.created", {"team_id": str(db_team.id), "name": data.name, "members": len(data.member_ids)})
        return TeamResponse(
            id=str(db_team.id), name=db_team.name, member_count=len(db_team.member_ids),
            channels=db_team.channels, is_active=db_team.is_active, created_at=db_team.created_at
        )

    async def add_member(self, team_id: str, member_id: str) -> bool:
        result = await self.db.execute(select(TeamDB).where(TeamDB.id == uuid.UUID(team_id)))
        team = result.scalar_one_or_none()
        if not team: return False
        members = list(team.member_ids)
        if member_id not in members:
            members.append(member_id)
            await self.db.execute(update(TeamDB).where(TeamDB.id == uuid.UUID(team_id)).values(member_ids=members, updated_at=datetime.utcnow()))
            await cache.delete(f"team:{team_id}")
        return True

    async def get_team(self, team_id: str) -> Optional[TeamResponse]:
        cached = await cache.get(f"team:{team_id}")
        if cached: return TeamResponse(**cached)
        result = await self.db.execute(select(TeamDB).where(TeamDB.id == uuid.UUID(team_id)))
        t = result.scalar_one_or_none()
        if not t: return None
        return TeamResponse(
            id=str(t.id), name=t.name, member_count=len(t.member_ids),
            channels=t.channels, is_active=t.is_active, created_at=t.created_at
        )

    async def list_teams(self, limit: int = 50) -> List[TeamResponse]:
        result = await self.db.execute(select(TeamDB).where(TeamDB.is_active == True).order_by(TeamDB.created_at.desc()).limit(limit))
        return [TeamResponse(
            id=str(t.id), name=t.name, member_count=len(t.member_ids),
            channels=t.channels, is_active=t.is_active, created_at=t.created_at
        ) for t in result.scalars().all()]
