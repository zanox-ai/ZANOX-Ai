from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Text, ForeignKey, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel
import uuid

class TeamDB(Base):
    __tablename__ = "teams"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    member_ids = Column(ARRAY(String), default=list)
    channels = Column(ARRAY(String), default=list)
    projects = Column(ARRAY(String), default=list)
    settings = Column(JSON, default=dict)
    metadata = Column(JSON, default=dict)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class TeamCreate(ZANOXBaseModel):
    name: str
    description: Optional[str] = None
    member_ids: Optional[List[str]] = Field(default_factory=list)
    channels: Optional[List[str]] = Field(default_factory=list)
    projects: Optional[List[str]] = Field(default_factory=list)
    settings: Optional[Dict[str, Any]] = Field(default_factory=dict)

class TeamResponse(ZANOXBaseModel):
    id: str
    name: str
    member_count: int
    channels: List[str]
    is_active: bool
    created_at: datetime
