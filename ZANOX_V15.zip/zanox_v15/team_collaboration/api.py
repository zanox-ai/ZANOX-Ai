from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import TeamCreate, TeamResponse
from .service import TeamCollaborationService

router = APIRouter(prefix="/teams", tags=["Team Collaboration"])

@router.post("/", response_model=TeamResponse)
async def create_team(data: TeamCreate, db: AsyncSession = Depends(get_db_session)):
    service = TeamCollaborationService(db)
    return await service.create_team(data)

@router.post("/{team_id}/members/{member_id}")
async def add_member(team_id: str, member_id: str, db: AsyncSession = Depends(get_db_session)):
    service = TeamCollaborationService(db)
    success = await service.add_member(team_id, member_id)
    if not success: raise HTTPException(status_code=404, detail="Team not found")
    return {"status": "member_added", "team_id": team_id, "member_id": member_id}

@router.get("/{team_id}", response_model=TeamResponse)
async def get_team(team_id: str, db: AsyncSession = Depends(get_db_session)):
    service = TeamCollaborationService(db)
    result = await service.get_team(team_id)
    if not result: raise HTTPException(status_code=404, detail="Team not found")
    return result

@router.get("/", response_model=List[TeamResponse])
async def list_teams(limit: int = Query(50, ge=1, le=100), db: AsyncSession = Depends(get_db_session)):
    service = TeamCollaborationService(db)
    return await service.list_teams(limit)
