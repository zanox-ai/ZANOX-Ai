from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import VoiceSessionCreate, VoiceSessionResponse
from .service import VoiceCommunicationService

router = APIRouter(prefix="/voice-communication", tags=["Voice Communication"])

@router.post("/sessions", response_model=VoiceSessionResponse)
async def create_session(data: VoiceSessionCreate, db: AsyncSession = Depends(get_db_session)):
    service = VoiceCommunicationService(db)
    return await service.create_session(data)

@router.post("/sessions/{session_id}/start")
async def start_session(session_id: str, db: AsyncSession = Depends(get_db_session)):
    service = VoiceCommunicationService(db)
    return await service.start_session(session_id)

@router.post("/sessions/{session_id}/end")
async def end_session(session_id: str, duration: int, db: AsyncSession = Depends(get_db_session)):
    service = VoiceCommunicationService(db)
    return await service.end_session(session_id, duration)

@router.get("/sessions/{session_id}", response_model=VoiceSessionResponse)
async def get_session(session_id: str, db: AsyncSession = Depends(get_db_session)):
    service = VoiceCommunicationService(db)
    result = await service.get_session(session_id)
    if not result: raise HTTPException(status_code=404, detail="Session not found")
    return result

@router.get("/sessions", response_model=List[VoiceSessionResponse])
async def list_sessions(caller_id: Optional[str] = Query(None), limit: int = Query(50, ge=1, le=100), db: AsyncSession = Depends(get_db_session)):
    service = VoiceCommunicationService(db)
    return await service.list_sessions(caller_id, limit)
