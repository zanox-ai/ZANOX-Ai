import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from shared.cache import cache
from shared.messaging import messaging
from .models import VoiceSessionDB, VoiceSessionCreate, VoiceSessionResponse

class VoiceCommunicationService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_session(self, data: VoiceSessionCreate) -> VoiceSessionResponse:
        db_sess = VoiceSessionDB(
            id=uuid.uuid4(), caller_id=data.caller_id, callee_id=data.callee_id,
            channel=data.channel, metadata=data.metadata
        )
        self.db.add(db_sess)
        await self.db.flush()
        await messaging.send_message("voice.session_created", {
            "session_id": str(db_sess.id), "caller": data.caller_id, "callee": data.callee_id
        })
        return VoiceSessionResponse(
            id=str(db_sess.id), channel=db_sess.channel, caller_id=db_sess.caller_id,
            callee_id=db_sess.callee_id, status=db_sess.status,
            started_at=db_sess.started_at, ended_at=db_sess.ended_at,
            duration_seconds=db_sess.duration_seconds, created_at=db_sess.created_at
        )

    async def start_session(self, session_id: str) -> Dict[str, Any]:
        await self.db.execute(
            update(VoiceSessionDB).where(VoiceSessionDB.id == uuid.UUID(session_id))
            .values(started_at=datetime.utcnow(), status="active", updated_at=datetime.utcnow())
        )
        await messaging.send_message("voice.session_started", {"session_id": session_id, "timestamp": datetime.utcnow().isoformat()})
        return {"session_id": session_id, "status": "active", "started_at": datetime.utcnow().isoformat()}

    async def end_session(self, session_id: str, duration: int) -> Dict[str, Any]:
        await self.db.execute(
            update(VoiceSessionDB).where(VoiceSessionDB.id == uuid.UUID(session_id))
            .values(ended_at=datetime.utcnow(), status="completed", duration_seconds=duration, updated_at=datetime.utcnow())
        )
        await messaging.send_message("voice.session_ended", {"session_id": session_id, "duration": duration})
        return {"session_id": session_id, "status": "completed", "duration": duration}

    async def get_session(self, session_id: str) -> Optional[VoiceSessionResponse]:
        result = await self.db.execute(select(VoiceSessionDB).where(VoiceSessionDB.id == uuid.UUID(session_id)))
        s = result.scalar_one_or_none()
        if not s: return None
        return VoiceSessionResponse(
            id=str(s.id), channel=s.channel, caller_id=s.caller_id, callee_id=s.callee_id,
            status=s.status, started_at=s.started_at, ended_at=s.ended_at,
            duration_seconds=s.duration_seconds, created_at=s.created_at
        )

    async def list_sessions(self, caller_id: Optional[str] = None, limit: int = 50) -> List[VoiceSessionResponse]:
        query = select(VoiceSessionDB)
        if caller_id: query = query.where(VoiceSessionDB.caller_id == caller_id)
        query = query.order_by(VoiceSessionDB.created_at.desc()).limit(limit)
        result = await self.db.execute(query)
        return [VoiceSessionResponse(
            id=str(s.id), channel=s.channel, caller_id=s.caller_id, callee_id=s.callee_id,
            status=s.status, started_at=s.started_at, ended_at=s.ended_at,
            duration_seconds=s.duration_seconds, created_at=s.created_at
        ) for s in result.scalars().all()]
