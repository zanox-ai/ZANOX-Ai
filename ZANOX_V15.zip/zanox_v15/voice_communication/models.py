from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Text, ForeignKey, Float, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel
import uuid

class VoiceSessionDB(Base):
    __tablename__ = "voice_sessions"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    channel = Column(String(50), default="voice")
    caller_id = Column(String(255), nullable=False)
    callee_id = Column(String(255), nullable=False)
    status = Column(String(50), default="initiated")
    started_at = Column(DateTime, nullable=True)
    ended_at = Column(DateTime, nullable=True)
    duration_seconds = Column(Integer, nullable=True)
    quality_score = Column(Float, nullable=True)
    recording_id = Column(UUID(as_uuid=True), nullable=True)
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)

class VoiceSessionCreate(ZANOXBaseModel):
    caller_id: str
    callee_id: str
    channel: str = "voice"
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict)

class VoiceSessionResponse(ZANOXBaseModel):
    id: str
    channel: str
    caller_id: str
    callee_id: str
    status: str
    started_at: Optional[datetime] = None
    ended_at: Optional[datetime] = None
    duration_seconds: Optional[int] = None
    created_at: datetime
