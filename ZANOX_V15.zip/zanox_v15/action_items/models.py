from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Text, ForeignKey, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel
import uuid

class ActionItemDB(Base):
    __tablename__ = "action_items"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    title = Column(String(500), nullable=False)
    description = Column(Text, nullable=True)
    source_type = Column(String(50), default="manual")
    source_id = Column(UUID(as_uuid=True), nullable=True)
    assignee_id = Column(String(255), nullable=True, index=True)
    owner_id = Column(String(255), nullable=False)
    status = Column(String(50), default="open")
    priority = Column(String(50), default="medium")
    due_date = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)
    tags = Column(ARRAY(String), default=list)
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class ActionItemCreate(ZANOXBaseModel):
    title: str
    description: Optional[str] = None
    source_type: str = "manual"
    source_id: Optional[str] = None
    assignee_id: Optional[str] = None
    owner_id: str
    priority: str = "medium"
    due_date: Optional[datetime] = None
    tags: Optional[List[str]] = Field(default_factory=list)
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict)

class ActionItemResponse(ZANOXBaseModel):
    id: str
    title: str
    description: Optional[str] = None
    assignee_id: Optional[str] = None
    owner_id: str
    status: str
    priority: str
    due_date: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    created_at: datetime
