import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from shared.cache import cache
from shared.messaging import messaging
from .models import ActionItemDB, ActionItemCreate, ActionItemResponse

class ActionItemsService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_action_item(self, data: ActionItemCreate) -> ActionItemResponse:
        db_item = ActionItemDB(
            id=uuid.uuid4(), title=data.title, description=data.description,
            source_type=data.source_type, source_id=uuid.UUID(data.source_id) if data.source_id else None,
            assignee_id=data.assignee_id, owner_id=data.owner_id,
            priority=data.priority, due_date=data.due_date, tags=data.tags, metadata=data.metadata
        )
        self.db.add(db_item)
        await self.db.flush()
        await cache.set(f"action:{db_item.id}", db_item.__dict__, ttl=3600)
        await messaging.send_message("action_item.created", {
            "action_id": str(db_item.id), "title": data.title, "assignee": data.assignee_id
        })
        return ActionItemResponse(
            id=str(db_item.id), title=db_item.title, description=db_item.description,
            assignee_id=db_item.assignee_id, owner_id=db_item.owner_id,
            status=db_item.status, priority=db_item.priority,
            due_date=db_item.due_date, completed_at=db_item.completed_at, created_at=db_item.created_at
        )

    async def complete_action_item(self, action_id: str) -> bool:
        await self.db.execute(
            update(ActionItemDB).where(ActionItemDB.id == uuid.UUID(action_id))
            .values(status="completed", completed_at=datetime.utcnow(), updated_at=datetime.utcnow())
        )
        await cache.delete(f"action:{action_id}")
        await messaging.send_message("action_item.completed", {"action_id": action_id})
        return True

    async def assign_action_item(self, action_id: str, assignee_id: str) -> bool:
        await self.db.execute(
            update(ActionItemDB).where(ActionItemDB.id == uuid.UUID(action_id))
            .values(assignee_id=assignee_id, updated_at=datetime.utcnow())
        )
        await cache.delete(f"action:{action_id}")
        return True

    async def get_action_item(self, action_id: str) -> Optional[ActionItemResponse]:
        cached = await cache.get(f"action:{action_id}")
        if cached: return ActionItemResponse(**cached)
        result = await self.db.execute(select(ActionItemDB).where(ActionItemDB.id == uuid.UUID(action_id)))
        i = result.scalar_one_or_none()
        if not i: return None
        return ActionItemResponse(
            id=str(i.id), title=i.title, description=i.description,
            assignee_id=i.assignee_id, owner_id=i.owner_id,
            status=i.status, priority=i.priority,
            due_date=i.due_date, completed_at=i.completed_at, created_at=i.created_at
        )

    async def list_action_items(self, assignee_id: Optional[str] = None, status: Optional[str] = None, limit: int = 50) -> List[ActionItemResponse]:
        query = select(ActionItemDB)
        if assignee_id: query = query.where(ActionItemDB.assignee_id == assignee_id)
        if status: query = query.where(ActionItemDB.status == status)
        query = query.order_by(ActionItemDB.created_at.desc()).limit(limit)
        result = await self.db.execute(query)
        return [ActionItemResponse(
            id=str(i.id), title=i.title, description=i.description,
            assignee_id=i.assignee_id, owner_id=i.owner_id,
            status=i.status, priority=i.priority,
            due_date=i.due_date, completed_at=i.completed_at, created_at=i.created_at
        ) for i in result.scalars().all()]
