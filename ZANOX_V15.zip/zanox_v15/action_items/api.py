from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import ActionItemCreate, ActionItemResponse
from .service import ActionItemsService

router = APIRouter(prefix="/action-items", tags=["Action Items"])

@router.post("/", response_model=ActionItemResponse)
async def create_action_item(data: ActionItemCreate, db: AsyncSession = Depends(get_db_session)):
    service = ActionItemsService(db)
    return await service.create_action_item(data)

@router.patch("/{action_id}/complete")
async def complete_action_item(action_id: str, db: AsyncSession = Depends(get_db_session)):
    service = ActionItemsService(db)
    await service.complete_action_item(action_id)
    return {"status": "completed", "action_id": action_id}

@router.patch("/{action_id}/assign")
async def assign_action_item(action_id: str, assignee_id: str, db: AsyncSession = Depends(get_db_session)):
    service = ActionItemsService(db)
    await service.assign_action_item(action_id, assignee_id)
    return {"status": "assigned", "action_id": action_id, "assignee_id": assignee_id}

@router.get("/{action_id}", response_model=ActionItemResponse)
async def get_action_item(action_id: str, db: AsyncSession = Depends(get_db_session)):
    service = ActionItemsService(db)
    result = await service.get_action_item(action_id)
    if not result: raise HTTPException(status_code=404, detail="Action item not found")
    return result

@router.get("/", response_model=List[ActionItemResponse])
async def list_action_items(assignee_id: Optional[str] = Query(None), status: Optional[str] = Query(None), limit: int = Query(50, ge=1, le=100), db: AsyncSession = Depends(get_db_session)):
    service = ActionItemsService(db)
    return await service.list_action_items(assignee_id, status, limit)
