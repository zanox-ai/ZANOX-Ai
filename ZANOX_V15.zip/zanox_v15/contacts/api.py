from typing import Optional, List, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import ContactCreate, ContactResponse
from .service import ContactManagementService

router = APIRouter(prefix="/contacts", tags=["Contact Management"])

@router.post("/", response_model=ContactResponse)
async def create_contact(data: ContactCreate, db: AsyncSession = Depends(get_db_session)):
    service = ContactManagementService(db)
    return await service.create_contact(data)

@router.get("/{contact_id}", response_model=ContactResponse)
async def get_contact(contact_id: str, db: AsyncSession = Depends(get_db_session)):
    service = ContactManagementService(db)
    result = await service.get_contact(contact_id)
    if not result: raise HTTPException(status_code=404, detail="Contact not found")
    return result

@router.patch("/{contact_id}")
async def update_contact(contact_id: str, updates: Dict[str, Any], db: AsyncSession = Depends(get_db_session)):
    service = ContactManagementService(db)
    await service.update_contact(contact_id, updates)
    return {"status": "updated", "contact_id": contact_id}

@router.get("/search/{query}", response_model=List[ContactResponse])
async def search_contacts(query: str, limit: int = Query(50, ge=1, le=100), db: AsyncSession = Depends(get_db_session)):
    service = ContactManagementService(db)
    return await service.search_contacts(query, limit)

@router.get("/", response_model=List[ContactResponse])
async def list_contacts(tag: Optional[str] = Query(None), limit: int = Query(50, ge=1, le=100), db: AsyncSession = Depends(get_db_session)):
    service = ContactManagementService(db)
    return await service.list_contacts(tag, limit)
