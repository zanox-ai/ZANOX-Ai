import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from shared.cache import cache
from shared.messaging import messaging
from .models import ContactDB, ContactCreate, ContactResponse

class ContactManagementService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_contact(self, data: ContactCreate) -> ContactResponse:
        db_contact = ContactDB(
            id=uuid.uuid4(), external_id=data.external_id, first_name=data.first_name,
            last_name=data.last_name, email=data.email, phone=data.phone,
            company=data.company, title=data.title, channels=data.channels,
            channel_ids=data.channel_ids, tags=data.tags, notes=data.notes, metadata=data.metadata
        )
        self.db.add(db_contact)
        await self.db.flush()
        await cache.set(f"contact:{db_contact.id}", db_contact.__dict__, ttl=86400)
        await messaging.send_message("contact.created", {"contact_id": str(db_contact.id), "email": data.email})
        return ContactResponse(
            id=str(db_contact.id), first_name=db_contact.first_name, last_name=db_contact.last_name,
            email=db_contact.email, phone=db_contact.phone, company=db_contact.company,
            tags=db_contact.tags, is_active=db_contact.is_active,
            last_contact_at=db_contact.last_contact_at, created_at=db_contact.created_at
        )

    async def get_contact(self, contact_id: str) -> Optional[ContactResponse]:
        cached = await cache.get(f"contact:{contact_id}")
        if cached: return ContactResponse(**cached)
        result = await self.db.execute(select(ContactDB).where(ContactDB.id == uuid.UUID(contact_id)))
        c = result.scalar_one_or_none()
        if not c: return None
        return ContactResponse(
            id=str(c.id), first_name=c.first_name, last_name=c.last_name,
            email=c.email, phone=c.phone, company=c.company,
            tags=c.tags, is_active=c.is_active, last_contact_at=c.last_contact_at, created_at=c.created_at
        )

    async def update_contact(self, contact_id: str, updates: Dict[str, Any]) -> bool:
        await self.db.execute(update(ContactDB).where(ContactDB.id == uuid.UUID(contact_id)).values(**updates, updated_at=datetime.utcnow()))
        await cache.delete(f"contact:{contact_id}")
        return True

    async def search_contacts(self, query: str, limit: int = 50) -> List[ContactResponse]:
        result = await self.db.execute(
            select(ContactDB)
            .where(
                (ContactDB.first_name.ilike(f"%{query}%")) |
                (ContactDB.last_name.ilike(f"%{query}%")) |
                (ContactDB.email.ilike(f"%{query}%")) |
                (ContactDB.company.ilike(f"%{query}%"))
            )
            .where(ContactDB.is_active == True)
            .limit(limit)
        )
        return [ContactResponse(
            id=str(c.id), first_name=c.first_name, last_name=c.last_name,
            email=c.email, phone=c.phone, company=c.company,
            tags=c.tags, is_active=c.is_active, last_contact_at=c.last_contact_at, created_at=c.created_at
        ) for c in result.scalars().all()]

    async def list_contacts(self, tag: Optional[str] = None, limit: int = 50) -> List[ContactResponse]:
        query = select(ContactDB).where(ContactDB.is_active == True)
        if tag: query = query.where(ContactDB.tags.contains([tag]))
        query = query.order_by(ContactDB.created_at.desc()).limit(limit)
        result = await self.db.execute(query)
        return [ContactResponse(
            id=str(c.id), first_name=c.first_name, last_name=c.last_name,
            email=c.email, phone=c.phone, company=c.company,
            tags=c.tags, is_active=c.is_active, last_contact_at=c.last_contact_at, created_at=c.created_at
        ) for c in result.scalars().all()]
