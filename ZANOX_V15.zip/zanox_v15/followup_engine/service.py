import uuid
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from shared.cache import cache
from shared.messaging import messaging
from .models import FollowUpRuleDB, FollowUpTaskDB, FollowUpRuleCreate, FollowUpTaskResponse

class FollowUpEngineService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_rule(self, rule: FollowUpRuleCreate) -> Dict[str, Any]:
        db_rule = FollowUpRuleDB(
            id=uuid.uuid4(),
            name=rule.name,
            trigger_condition=rule.trigger_condition,
            delay_hours=rule.delay_hours,
            max_followups=rule.max_followups,
            channel=rule.channel,
            message_template=rule.message_template
        )
        self.db.add(db_rule)
        await self.db.flush()
        return {"id": str(db_rule.id), "name": db_rule.name, "status": "created"}

    async def schedule_followup(self, rule_id: str, recipient_id: str, conversation_id: Optional[str] = None,
                               context: Optional[Dict] = None) -> FollowUpTaskResponse:
        result = await self.db.execute(
            select(FollowUpRuleDB).where(FollowUpRuleDB.id == uuid.UUID(rule_id))
        )
        rule = result.scalar_one_or_none()
        if not rule:
            raise ValueError("Rule not found")

        scheduled_at = datetime.utcnow() + timedelta(hours=rule.delay_hours)
        db_task = FollowUpTaskDB(
            id=uuid.uuid4(),
            rule_id=uuid.UUID(rule_id),
            conversation_id=uuid.UUID(conversation_id) if conversation_id else None,
            recipient_id=recipient_id,
            scheduled_at=scheduled_at,
            status="pending",
            metadata=context or {}
        )
        self.db.add(db_task)
        await self.db.flush()

        await messaging.send_message("followup.scheduled", {
            "task_id": str(db_task.id),
            "recipient": recipient_id,
            "scheduled_at": scheduled_at.isoformat()
        })

        return FollowUpTaskResponse(
            id=str(db_task.id), rule_id=rule_id, recipient_id=recipient_id,
            scheduled_at=db_task.scheduled_at, status=db_task.status,
            attempt_count=db_task.attempt_count, created_at=db_task.created_at
        )

    async def get_pending_tasks(self, limit: int = 100) -> List[FollowUpTaskResponse]:
        result = await self.db.execute(
            select(FollowUpTaskDB)
            .where(FollowUpTaskDB.status == "pending")
            .where(FollowUpTaskDB.scheduled_at <= datetime.utcnow())
            .order_by(FollowUpTaskDB.scheduled_at.asc())
            .limit(limit)
        )
        return [
            FollowUpTaskResponse(
                id=str(t.id), rule_id=str(t.rule_id), recipient_id=t.recipient_id,
                scheduled_at=t.scheduled_at, status=t.status,
                attempt_count=t.attempt_count, created_at=t.created_at
            ) for t in result.scalars().all()
        ]

    async def execute_task(self, task_id: str) -> Dict[str, Any]:
        result = await self.db.execute(
            select(FollowUpTaskDB).where(FollowUpTaskDB.id == uuid.UUID(task_id))
        )
        task = result.scalar_one_or_none()
        if not task:
            return {"error": "Task not found"}

        rule_result = await self.db.execute(
            select(FollowUpRuleDB).where(FollowUpRuleDB.id == task.rule_id)
        )
        rule = rule_result.scalar_one_or_none()
        if not rule:
            return {"error": "Rule not found"}

        task.attempt_count += 1
        task.last_attempt_at = datetime.utcnow()

        if task.attempt_count >= rule.max_followups:
            task.status = "completed"
            task.completed_at = datetime.utcnow()
        else:
            task.scheduled_at = datetime.utcnow() + timedelta(hours=rule.delay_hours)

        await self.db.execute(
            update(FollowUpTaskDB)
            .where(FollowUpTaskDB.id == uuid.UUID(task_id))
            .values(
                attempt_count=task.attempt_count,
                last_attempt_at=task.last_attempt_at,
                scheduled_at=task.scheduled_at,
                status=task.status,
                completed_at=task.completed_at
            )
        )

        await messaging.send_message(f"channel.{rule.channel}.send", {
            "task_id": task_id,
            "recipient": task.recipient_id,
            "body": rule.message_template,
            "attempt": task.attempt_count
        })

        return {
            "task_id": task_id,
            "status": task.status,
            "attempt": task.attempt_count,
            "channel": rule.channel
        }
