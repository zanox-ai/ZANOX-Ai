from typing import Optional, List, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import FollowUpRuleCreate, FollowUpTaskResponse
from .service import FollowUpEngineService

router = APIRouter(prefix="/followup", tags=["Follow-Up Engine"])

@router.post("/rules")
async def create_rule(
    rule: FollowUpRuleCreate,
    db: AsyncSession = Depends(get_db_session)
):
    service = FollowUpEngineService(db)
    return await service.create_rule(rule)

@router.post("/schedule")
async def schedule_followup(
    rule_id: str,
    recipient_id: str,
    conversation_id: str = None,
    context: dict = None,
    db: AsyncSession = Depends(get_db_session)
):
    service = FollowUpEngineService(db)
    return await service.schedule_followup(rule_id, recipient_id, conversation_id, context)

@router.get("/pending", response_model=List[FollowUpTaskResponse])
async def get_pending_tasks(
    limit: int = Query(100, ge=1, le=500),
    db: AsyncSession = Depends(get_db_session)
):
    service = FollowUpEngineService(db)
    return await service.get_pending_tasks(limit)

@router.post("/tasks/{task_id}/execute")
async def execute_task(
    task_id: str,
    db: AsyncSession = Depends(get_db_session)
):
    service = FollowUpEngineService(db)
    result = await service.execute_task(task_id)
    if "error" in result:
        raise HTTPException(status_code=404, detail=result["error"])
    return result
