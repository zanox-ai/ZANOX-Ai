from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Enum as SQLEnum, Text, ForeignKey, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel, Priority
import uuid

class FollowUpRuleDB(Base):
    __tablename__ = "followup_rules"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(255), nullable=False)
    trigger_condition = Column(JSON, nullable=False)
    delay_hours = Column(Integer, default=24)
    max_followups = Column(Integer, default=3)
    channel = Column(String(50), nullable=False)
    message_template = Column(Text, nullable=False)
    is_active = Column(Boolean, default=True)
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class FollowUpTaskDB(Base):
    __tablename__ = "followup_tasks"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    rule_id = Column(UUID(as_uuid=True), ForeignKey("followup_rules.id"), nullable=False)
    conversation_id = Column(UUID(as_uuid=True), ForeignKey("conversations.id"), nullable=True)
    recipient_id = Column(String(255), nullable=False)
    scheduled_at = Column(DateTime, nullable=False)
    status = Column(String(50), default="pending")
    attempt_count = Column(Integer, default=0)
    last_attempt_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)

class FollowUpRuleCreate(ZANOXBaseModel):
    name: str
    trigger_condition: Dict[str, Any]
    delay_hours: int = 24
    max_followups: int = 3
    channel: str
    message_template: str

class FollowUpTaskResponse(ZANOXBaseModel):
    id: str
    rule_id: str
    recipient_id: str
    scheduled_at: datetime
    status: str
    attempt_count: int
    created_at: datetime
