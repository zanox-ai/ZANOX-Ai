from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import MeetingSummaryCreate, MeetingSummaryResponse
from .service import MeetingSummaryService

router = APIRouter(prefix="/meeting-summaries", tags=["Meeting Summary"])

@router.post("/", response_model=MeetingSummaryResponse)
async def create_summary(data: MeetingSummaryCreate, db: AsyncSession = Depends(get_db_session)):
    service = MeetingSummaryService(db)
    return await service.create_summary(data)

@router.get("/meetings/{meeting_id}", response_model=MeetingSummaryResponse)
async def get_summary(meeting_id: str, db: AsyncSession = Depends(get_db_session)):
    service = MeetingSummaryService(db)
    result = await service.get_summary(meeting_id)
    if not result: raise HTTPException(status_code=404, detail="Summary not found")
    return result

@router.get("/", response_model=List[MeetingSummaryResponse])
async def list_summaries(limit: int = Query(50, ge=1, le=100), db: AsyncSession = Depends(get_db_session)):
    service = MeetingSummaryService(db)
    return await service.list_summaries(limit)
