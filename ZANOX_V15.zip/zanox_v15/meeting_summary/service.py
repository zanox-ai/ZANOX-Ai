import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from shared.cache import cache
from shared.messaging import messaging
from .models import MeetingSummaryDB, MeetingSummaryCreate, MeetingSummaryResponse

class MeetingSummaryService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_summary(self, data: MeetingSummaryCreate) -> MeetingSummaryResponse:
        db_summary = MeetingSummaryDB(
            id=uuid.uuid4(), meeting_id=uuid.UUID(data.meeting_id),
            transcription_id=uuid.UUID(data.transcription_id) if data.transcription_id else None,
            summary_text=data.summary_text, key_points=data.key_points,
            action_items=data.action_items, decisions=data.decisions,
            topics=data.topics, sentiment=data.sentiment,
            duration_minutes=data.duration_minutes, participant_count=data.participant_count
        )
        self.db.add(db_summary)
        await self.db.flush()
        await cache.set(f"summary:{data.meeting_id}", db_summary.__dict__, ttl=86400)
        await messaging.send_message("meeting.summary_created", {"summary_id": str(db_summary.id), "meeting_id": data.meeting_id})
        return MeetingSummaryResponse(
            id=str(db_summary.id), meeting_id=data.meeting_id, summary_text=db_summary.summary_text,
            key_points=db_summary.key_points, action_items=db_summary.action_items,
            decisions=db_summary.decisions, topics=db_summary.topics,
            sentiment=db_summary.sentiment, created_at=db_summary.created_at
        )

    async def get_summary(self, meeting_id: str) -> Optional[MeetingSummaryResponse]:
        cached = await cache.get(f"summary:{meeting_id}")
        if cached: return MeetingSummaryResponse(**cached)
        result = await self.db.execute(
            select(MeetingSummaryDB).where(MeetingSummaryDB.meeting_id == uuid.UUID(meeting_id)).order_by(MeetingSummaryDB.created_at.desc()).limit(1)
        )
        s = result.scalar_one_or_none()
        if not s: return None
        return MeetingSummaryResponse(
            id=str(s.id), meeting_id=meeting_id, summary_text=s.summary_text,
            key_points=s.key_points, action_items=s.action_items,
            decisions=s.decisions, topics=s.topics, sentiment=s.sentiment, created_at=s.created_at
        )

    async def list_summaries(self, limit: int = 50) -> List[MeetingSummaryResponse]:
        result = await self.db.execute(select(MeetingSummaryDB).order_by(MeetingSummaryDB.created_at.desc()).limit(limit))
        return [MeetingSummaryResponse(
            id=str(s.id), meeting_id=str(s.meeting_id), summary_text=s.summary_text,
            key_points=s.key_points, action_items=s.action_items,
            decisions=s.decisions, topics=s.topics, sentiment=s.sentiment, created_at=s.created_at
        ) for s in result.scalars().all()]
