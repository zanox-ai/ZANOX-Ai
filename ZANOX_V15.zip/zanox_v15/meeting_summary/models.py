from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Text, ForeignKey, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel
import uuid

class MeetingSummaryDB(Base):
    __tablename__ = "meeting_summaries"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    meeting_id = Column(UUID(as_uuid=True), ForeignKey("meetings.id"), nullable=False, index=True)
    transcription_id = Column(UUID(as_uuid=True), ForeignKey("transcriptions.id"), nullable=True)
    summary_text = Column(Text, nullable=False)
    key_points = Column(ARRAY(String), default=list)
    action_items = Column(ARRAY(String), default=list)
    decisions = Column(ARRAY(String), default=list)
    topics = Column(ARRAY(String), default=list)
    sentiment = Column(String(50), default="neutral")
    duration_minutes = Column(Integer, nullable=True)
    participant_count = Column(Integer, default=0)
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)

class MeetingSummaryCreate(ZANOXBaseModel):
    meeting_id: str
    transcription_id: Optional[str] = None
    summary_text: str
    key_points: Optional[List[str]] = Field(default_factory=list)
    action_items: Optional[List[str]] = Field(default_factory=list)
    decisions: Optional[List[str]] = Field(default_factory=list)
    topics: Optional[List[str]] = Field(default_factory=list)
    sentiment: str = "neutral"
    duration_minutes: Optional[int] = None
    participant_count: int = 0

class MeetingSummaryResponse(ZANOXBaseModel):
    id: str
    meeting_id: str
    summary_text: str
    key_points: List[str]
    action_items: List[str]
    decisions: List[str]
    topics: List[str]
    sentiment: str
    created_at: datetime
