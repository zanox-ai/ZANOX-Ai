from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import OutboxMessageCreate, OutboxMessageResponse
from .service import UnifiedOutboxService

router = APIRouter(prefix="/outbox", tags=["Unified Outbox"])

@router.post("/messages", response_model=OutboxMessageResponse)
async def queue_message(
    message: OutboxMessageCreate,
    db: AsyncSession = Depends(get_db_session)
):
    service = UnifiedOutboxService(db)
    return await service.queue_message(message)

@router.get("/pending", response_model=List[OutboxMessageResponse])
async def get_pending(
    channel: Optional[str] = Query(None),
    limit: int = Query(100, ge=1, le=500),
    db: AsyncSession = Depends(get_db_session)
):
    service = UnifiedOutboxService(db)
    return await service.get_pending_messages(channel, limit)

@router.patch("/messages/{message_id}/sent")
async def mark_sent(
    message_id: str,
    db: AsyncSession = Depends(get_db_session)
):
    service = UnifiedOutboxService(db)
    await service.mark_sent(message_id)
    return {"status": "sent", "message_id": message_id}

@router.patch("/messages/{message_id}/failed")
async def mark_failed(
    message_id: str,
    error: str,
    db: AsyncSession = Depends(get_db_session)
):
    service = UnifiedOutboxService(db)
    await service.mark_failed(message_id, error)
    return {"status": "failed", "message_id": message_id}

@router.patch("/messages/{message_id}/delivered")
async def mark_delivered(
    message_id: str,
    db: AsyncSession = Depends(get_db_session)
):
    service = UnifiedOutboxService(db)
    await service.mark_delivered(message_id)
    return {"status": "delivered", "message_id": message_id}
