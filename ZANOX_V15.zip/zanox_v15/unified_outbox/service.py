import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from shared.cache import cache
from shared.messaging import messaging
from .models import OutboxMessageDB, OutboxMessageCreate, OutboxMessageResponse

class UnifiedOutboxService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def queue_message(self, message: OutboxMessageCreate) -> OutboxMessageResponse:
        db_msg = OutboxMessageDB(
            id=uuid.uuid4(),
            channel=message.channel,
            recipient_id=message.recipient_id,
            recipient_name=message.recipient_name,
            subject=message.subject,
            body=message.body,
            attachments=message.attachments,
            metadata=message.metadata,
            status="pending",
            priority=message.priority,
            scheduled_at=message.scheduled_at,
            thread_id=message.thread_id,
            max_retries=message.max_retries
        )
        self.db.add(db_msg)
        await self.db.flush()

        await messaging.send_message("outbox.new_message", {
            "message_id": str(db_msg.id),
            "channel": db_msg.channel,
            "recipient": db_msg.recipient_id,
            "priority": db_msg.priority.value,
            "scheduled_at": db_msg.scheduled_at.isoformat() if db_msg.scheduled_at else None
        })

        await cache.set(f"outbox:msg:{db_msg.id}", db_msg.__dict__, ttl=3600)

        return OutboxMessageResponse(
            id=str(db_msg.id),
            channel=db_msg.channel,
            recipient_id=db_msg.recipient_id,
            status=db_msg.status,
            priority=db_msg.priority.value,
            retry_count=db_msg.retry_count,
            scheduled_at=db_msg.scheduled_at,
            sent_at=db_msg.sent_at,
            created_at=db_msg.created_at
        )

    async def get_pending_messages(self, channel: Optional[str] = None, limit: int = 100) -> List[OutboxMessageResponse]:
        query = select(OutboxMessageDB).where(OutboxMessageDB.status.in_(["pending", "retrying"]))
        if channel:
            query = query.where(OutboxMessageDB.channel == channel)
        query = query.order_by(OutboxMessageDB.priority.asc(), OutboxMessageDB.created_at.asc()).limit(limit)
        result = await self.db.execute(query)
        return [
            OutboxMessageResponse(
                id=str(m.id), channel=m.channel, recipient_id=m.recipient_id,
                status=m.status, priority=m.priority.value, retry_count=m.retry_count,
                scheduled_at=m.scheduled_at, sent_at=m.sent_at, created_at=m.created_at
            ) for m in result.scalars().all()
        ]

    async def mark_sent(self, message_id: str) -> bool:
        await self.db.execute(
            update(OutboxMessageDB)
            .where(OutboxMessageDB.id == uuid.UUID(message_id))
            .values(status="sent", sent_at=datetime.utcnow(), updated_at=datetime.utcnow())
        )
        await cache.delete(f"outbox:msg:{message_id}")
        await messaging.send_message("outbox.sent", {"message_id": message_id, "timestamp": datetime.utcnow().isoformat()})
        return True

    async def mark_failed(self, message_id: str, error: str) -> bool:
        result = await self.db.execute(
            select(OutboxMessageDB).where(OutboxMessageDB.id == uuid.UUID(message_id))
        )
        msg = result.scalar_one_or_none()
        if not msg:
            return False

        new_status = "failed" if msg.retry_count >= msg.max_retries else "retrying"
        await self.db.execute(
            update(OutboxMessageDB)
            .where(OutboxMessageDB.id == uuid.UUID(message_id))
            .values(
                status=new_status,
                retry_count=msg.retry_count + 1,
                error_message=error,
                updated_at=datetime.utcnow()
            )
        )
        await cache.delete(f"outbox:msg:{message_id}")
        return True

    async def mark_delivered(self, message_id: str) -> bool:
        await self.db.execute(
            update(OutboxMessageDB)
            .where(OutboxMessageDB.id == uuid.UUID(message_id))
            .values(status="delivered", delivered_at=datetime.utcnow())
        )
        await cache.delete(f"outbox:msg:{message_id}")
        return True

    async def mark_read(self, message_id: str) -> bool:
        await self.db.execute(
            update(OutboxMessageDB)
            .where(OutboxMessageDB.id == uuid.UUID(message_id))
            .values(status="read", read_at=datetime.utcnow())
        )
        await cache.delete(f"outbox:msg:{message_id}")
        return True
