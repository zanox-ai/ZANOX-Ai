from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Enum as SQLEnum, Text, ForeignKey, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel, CommunicationChannel, MessageStatus, Priority
import uuid

class OutboxMessageDB(Base):
    __tablename__ = "outbox_messages"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    channel = Column(String(50), nullable=False, index=True)
    recipient_id = Column(String(255), nullable=False, index=True)
    recipient_name = Column(String(255), nullable=True)
    subject = Column(Text, nullable=True)
    body = Column(Text, nullable=False)
    attachments = Column(JSON, default=list)
    metadata = Column(JSON, default=dict)
    status = Column(String(50), default=MessageStatus.PENDING)
    priority = Column(SQLEnum(Priority), default=Priority.MEDIUM)
    scheduled_at = Column(DateTime, nullable=True)
    sent_at = Column(DateTime, nullable=True)
    delivered_at = Column(DateTime, nullable=True)
    read_at = Column(DateTime, nullable=True)
    retry_count = Column(Integer, default=0)
    max_retries = Column(Integer, default=3)
    error_message = Column(Text, nullable=True)
    thread_id = Column(String(255), nullable=True)
    conversation_id = Column(UUID(as_uuid=True), ForeignKey("conversations.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class OutboxMessageCreate(ZANOXBaseModel):
    channel: str
    recipient_id: str
    recipient_name: Optional[str] = None
    subject: Optional[str] = None
    body: str
    attachments: Optional[List[Dict[str, Any]]] = Field(default_factory=list)
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict)
    priority: Priority = Priority.MEDIUM
    scheduled_at: Optional[datetime] = None
    thread_id: Optional[str] = None
    max_retries: int = 3

class OutboxMessageResponse(ZANOXBaseModel):
    id: str
    channel: str
    recipient_id: str
    status: str
    priority: str
    retry_count: int
    scheduled_at: Optional[datetime] = None
    sent_at: Optional[datetime] = None
    created_at: datetime
