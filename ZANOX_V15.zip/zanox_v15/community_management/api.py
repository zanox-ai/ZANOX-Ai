from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import get_db_session
from .models import CommunityCreate, CommunityResponse
from .service import CommunityManagementService

router = APIRouter(prefix="/communities", tags=["Community Management"])

@router.post("/", response_model=CommunityResponse)
async def create_community(data: CommunityCreate, db: AsyncSession = Depends(get_db_session)):
    service = CommunityManagementService(db)
    return await service.create_community(data)

@router.patch("/{community_id}/metrics")
async def update_metrics(community_id: str, member_count: int, active_members: int, db: AsyncSession = Depends(get_db_session)):
    service = CommunityManagementService(db)
    await service.update_metrics(community_id, member_count, active_members)
    return {"status": "updated", "community_id": community_id}

@router.get("/{community_id}", response_model=CommunityResponse)
async def get_community(community_id: str, db: AsyncSession = Depends(get_db_session)):
    service = CommunityManagementService(db)
    result = await service.get_community(community_id)
    if not result: raise HTTPException(status_code=404, detail="Community not found")
    return result

@router.get("/", response_model=List[CommunityResponse])
async def list_communities(platform: Optional[str] = None, db: AsyncSession = Depends(get_db_session)):
    service = CommunityManagementService(db)
    return await service.list_communities(platform)
