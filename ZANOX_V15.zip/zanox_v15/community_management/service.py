import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from shared.cache import cache
from shared.messaging import messaging
from .models import CommunityDB, CommunityCreate, CommunityResponse

class CommunityManagementService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_community(self, data: CommunityCreate) -> CommunityResponse:
        db_comm = CommunityDB(
            id=uuid.uuid4(), name=data.name, description=data.description,
            platform=data.platform, external_id=data.external_id,
            channels=data.channels, rules=data.rules, settings=data.settings
        )
        self.db.add(db_comm)
        await self.db.flush()
        await cache.set(f"community:{db_comm.id}", db_comm.__dict__, ttl=86400)
        await messaging.send_message("community.created", {"community_id": str(db_comm.id), "name": data.name, "platform": data.platform})
        return CommunityResponse(
            id=str(db_comm.id), name=db_comm.name, platform=db_comm.platform,
            member_count=db_comm.member_count, active_members=db_comm.active_members,
            is_active=db_comm.is_active, created_at=db_comm.created_at
        )

    async def update_metrics(self, community_id: str, member_count: int, active_members: int) -> bool:
        await self.db.execute(
            update(CommunityDB).where(CommunityDB.id == uuid.UUID(community_id))
            .values(member_count=member_count, active_members=active_members, updated_at=datetime.utcnow())
        )
        await cache.delete(f"community:{community_id}")
        return True

    async def get_community(self, community_id: str) -> Optional[CommunityResponse]:
        cached = await cache.get(f"community:{community_id}")
        if cached: return CommunityResponse(**cached)
        result = await self.db.execute(select(CommunityDB).where(CommunityDB.id == uuid.UUID(community_id)))
        c = result.scalar_one_or_none()
        if not c: return None
        return CommunityResponse(
            id=str(c.id), name=c.name, platform=c.platform,
            member_count=c.member_count, active_members=c.active_members,
            is_active=c.is_active, created_at=c.created_at
        )

    async def list_communities(self, platform: Optional[str] = None) -> List[CommunityResponse]:
        query = select(CommunityDB).where(CommunityDB.is_active == True)
        if platform: query = query.where(CommunityDB.platform == platform)
        result = await self.db.execute(query)
        return [CommunityResponse(
            id=str(c.id), name=c.name, platform=c.platform,
            member_count=c.member_count, active_members=c.active_members,
            is_active=c.is_active, created_at=c.created_at
        ) for c in result.scalars().all()]
