from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from sqlalchemy import Column, String, DateTime, JSON, Integer, Text, ForeignKey, Boolean
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from shared.database import Base
from shared.models import ZANOXBaseModel
import uuid

class CommunityDB(Base):
    __tablename__ = "communities"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    platform = Column(String(50), nullable=False)
    external_id = Column(String(255), nullable=True)
    member_count = Column(Integer, default=0)
    active_members = Column(Integer, default=0)
    channels = Column(ARRAY(String), default=list)
    rules = Column(JSON, default=list)
    settings = Column(JSON, default=dict)
    metadata = Column(JSON, default=dict)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class CommunityCreate(ZANOXBaseModel):
    name: str
    description: Optional[str] = None
    platform: str
    external_id: Optional[str] = None
    channels: Optional[List[str]] = Field(default_factory=list)
    rules: Optional[List[Dict[str, Any]]] = Field(default_factory=list)
    settings: Optional[Dict[str, Any]] = Field(default_factory=dict)

class CommunityResponse(ZANOXBaseModel):
    id: str
    name: str
    platform: str
    member_count: int
    active_members: int
    is_active: bool
    created_at: datetime
