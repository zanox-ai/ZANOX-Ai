const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('electronAPI', {
  getStoreValue: (key, defaultValue) => ipcRenderer.invoke('get-store-value', key, defaultValue),
  setStoreValue: (key, value) => ipcRenderer.invoke('set-store-value', key, value),
  getSystemInfo: () => ipcRenderer.invoke('get-system-info'),
  showNotification: (options) => ipcRenderer.send('show-notification', options),
  onNavigate: (callback) => ipcRenderer.on('navigate', (event, path) => callback(path)),
  onQuickAction: (callback) => ipcRenderer.on('quick-action', () => callback()),
  removeAllListeners: (channel) => ipcRenderer.removeAllListeners(channel)
});
