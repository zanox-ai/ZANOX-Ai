const { app, BrowserWindow, ipcMain, shell, Tray, Menu, nativeImage } = require('electron');
const path = require('path');
const log = require('electron-log');
const Store = require('electron-store');
const store = new Store();
let mainWindow;
let tray;
const isDev = process.env.NODE_ENV === 'development';
const WEB_APP_URL = isDev ? 'http://localhost:3000' : 'https://zanox.io';

function createWindow() {
  mainWindow = new BrowserWindow({ width: 1400, height: 900, minWidth: 1024, minHeight: 768, titleBarStyle: 'hiddenInset', webPreferences: { nodeIntegration: false, contextIsolation: true, preload: path.join(__dirname, 'preload.js'), webSecurity: !isDev }, show: false, backgroundColor: '#0a0a0f' });
  mainWindow.loadURL(WEB_APP_URL);
  mainWindow.once('ready-to-show', () => { mainWindow.show(); if (isDev) mainWindow.webContents.openDevTools(); });
  mainWindow.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
  mainWindow.on('closed', () => { mainWindow = null; });
  mainWindow.on('minimize', (event) => { if (store.get('minimizeToTray', true)) { event.preventDefault(); mainWindow.hide(); } });
}

function createTray() {
  const icon = nativeImage.createFromPath(path.join(__dirname, 'assets', 'tray-icon.png')).resize({ width: 16, height: 16 });
  tray = new Tray(icon);
  const contextMenu = Menu.buildFromTemplate([{ label: 'Show ZANOX', click: () => { if (mainWindow) mainWindow.show(); } }, { label: 'New Agent', click: () => { if (mainWindow) { mainWindow.show(); mainWindow.webContents.send('navigate', '/agents/new'); } } }, { label: 'Quick Action', click: () => { if (mainWindow) { mainWindow.show(); mainWindow.webContents.send('quick-action'); } } }, { type: 'separator' }, { label: 'Settings', click: () => { if (mainWindow) { mainWindow.show(); mainWindow.webContents.send('navigate', '/settings'); } } }, { type: 'separator' }, { label: 'Quit', click: () => { app.quit(); } }]);
  tray.setToolTip('ZANOX Experience Layer');
  tray.setContextMenu(contextMenu);
  tray.on('click', () => { if (mainWindow) { if (mainWindow.isVisible()) mainWindow.hide(); else mainWindow.show(); } });
}

app.whenReady().then(() => { createWindow(); createTray(); app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); }); });
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
ipcMain.handle('get-store-value', (event, key, defaultValue) => store.get(key, defaultValue));
ipcMain.handle('set-store-value', (event, key, value) => store.set(key, value));
ipcMain.handle('get-system-info', () => ({ platform: process.platform, arch: process.arch, version: app.getVersion(), electronVersion: process.versions.electron }));
ipcMain.on('show-notification', (event, { title, body }) => { if (tray) tray.displayBalloon({ iconType: 'info', title: title || 'ZANOX', content: body || 'Notification' }); });
log.info('ZANOX Desktop App initialized');
