import React, { useState } from 'react';
import { View, Text, TextInput, ScrollView, StyleSheet, TouchableOpacity, KeyboardAvoidingView, Platform } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

const models = [
  { id: 'gpt-4', name: 'GPT-4', color: '#10b981' },
  { id: 'claude-3', name: 'Claude 3', color: '#f97316' },
  { id: 'gemini', name: 'Gemini', color: '#3b82f6' },
  { id: 'kimi', name: 'Kimi', color: '#8b5cf6' },
];

export default function AIScreen() {
  const [selectedModels, setSelectedModels] = useState(['gpt-4']);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState([{ id: '1', role: 'assistant', content: 'Hello! I am your AI assistant. How can I help you today?', model: 'GPT-4' }]);

  const toggleModel = (modelId: string) => {
    setSelectedModels(prev => prev.includes(modelId) ? prev.filter(m => m !== modelId) : [...prev, modelId]);
  };

  const sendMessage = () => {
    if (!input.trim()) return;
    setMessages(prev => [...prev, { id: Date.now().toString(), role: 'user', content: input }]);
    setInput('');
    setTimeout(() => {
      setMessages(prev => [...prev, { id: (Date.now() + 1).toString(), role: 'assistant', content: 'I have processed your request and generated a comprehensive response.', model: 'GPT-4' }]);
    }, 1500);
  };

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <View style={styles.header}>
        <Text style={styles.title}>AI Chat</Text>
      </View>
      <ScrollView style={styles.messagesContainer}>
        {messages.map((msg) => (
          <View key={msg.id} style={[styles.messageBubble, msg.role === 'user' ? styles.userBubble : styles.assistantBubble]}>
            <Text style={msg.role === 'user' ? styles.userText : styles.assistantText}>{msg.content}</Text>
            {msg.model && <Text style={styles.modelLabel}>{msg.model}</Text>}
          </View>
        ))}
      </ScrollView>
      <View style={styles.modelSelector}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {models.map((model) => (
            <TouchableOpacity key={model.id} onPress={() => toggleModel(model.id)} style={[styles.modelChip, selectedModels.includes(model.id) && { borderColor: model.color, backgroundColor: model.color + '20' }]}>
              <View style={[styles.modelDot, { backgroundColor: model.color }]} />
              <Text style={styles.modelChipText}>{model.name}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>
      <View style={styles.inputContainer}>
        <TextInput style={styles.input} value={input} onChangeText={setInput} placeholder="Message AI..." placeholderTextColor="#6b7280" multiline />
        <TouchableOpacity style={styles.sendButton} onPress={sendMessage}>
          <Icon name="send" size={20} color="#ffffff" />
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0a0a0f' },
  header: { padding: 20, paddingTop: 40 },
  title: { fontSize: 24, fontWeight: 'bold', color: '#ffffff' },
  messagesContainer: { flex: 1, padding: 16 },
  messageBubble: { maxWidth: '80%', padding: 12, borderRadius: 16, marginBottom: 12 },
  userBubble: { alignSelf: 'flex-end', backgroundColor: '#0ea5e9' },
  assistantBubble: { alignSelf: 'flex-start', backgroundColor: '#12121a', borderWidth: 1, borderColor: '#2a2a3e' },
  userText: { color: '#ffffff', fontSize: 14 },
  assistantText: { color: '#ffffff', fontSize: 14 },
  modelLabel: { fontSize: 10, color: '#6b7280', marginTop: 4 },
  modelSelector: { paddingHorizontal: 16, paddingVertical: 8 },
  modelChip: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12, paddingVertical: 8, borderRadius: 20, borderWidth: 1, borderColor: '#2a2a3e', marginRight: 8 },
  modelDot: { width: 8, height: 8, borderRadius: 4, marginRight: 6 },
  modelChipText: { color: '#ffffff', fontSize: 12 },
  inputContainer: { flexDirection: 'row', alignItems: 'flex-end', padding: 16, borderTopWidth: 1, borderTopColor: '#2a2a3e' },
  input: { flex: 1, backgroundColor: '#12121a', borderRadius: 20, padding: 12, color: '#ffffff', maxHeight: 100, borderWidth: 1, borderColor: '#2a2a3e' },
  sendButton: { width: 40, height: 40, borderRadius: 20, backgroundColor: '#0ea5e9', justifyContent: 'center', alignItems: 'center', marginLeft: 8 },
});
