import React from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, StatusBar } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

const stats = [
  { label: 'Agents', value: '12', icon: 'robot', color: '#0ea5e9' },
  { label: 'Workflows', value: '8', icon: 'lightning-bolt', color: '#8b5cf6' },
  { label: 'Projects', value: '24', icon: 'folder', color: '#f97316' },
  { label: 'Team', value: '6', icon: 'account-group', color: '#10b981' },
];

const quickActions = [
  { label: 'New Agent', icon: 'robot', color: '#0ea5e9' },
  { label: 'Create Flow', icon: 'lightning-bolt', color: '#8b5cf6' },
  { label: 'Generate', icon: 'palette', color: '#ec4899' },
  { label: 'Build App', icon: 'hammer', color: '#f97316' },
];

export default function DashboardScreen() {
  return (
    <ScrollView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0a0a0f" />
      <View style={styles.header}>
        <Text style={styles.title}>ZANOX</Text>
        <Text style={styles.subtitle}>Experience Layer</Text>
      </View>
      <View style={styles.statsGrid}>
        {stats.map((stat) => (
          <View key={stat.label} style={styles.statCard}>
            <Icon name={stat.icon} size={24} color={stat.color} />
            <Text style={styles.statValue}>{stat.value}</Text>
            <Text style={styles.statLabel}>{stat.label}</Text>
          </View>
        ))}
      </View>
      <Text style={styles.sectionTitle}>Quick Actions</Text>
      <View style={styles.actionsGrid}>
        {quickActions.map((action) => (
          <TouchableOpacity key={action.label} style={[styles.actionButton, { borderColor: action.color }]}>
            <Icon name={action.icon} size={28} color={action.color} />
            <Text style={[styles.actionLabel, { color: action.color }]}>{action.label}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0a0a0f' },
  header: { padding: 20, paddingTop: 40 },
  title: { fontSize: 28, fontWeight: 'bold', color: '#ffffff' },
  subtitle: { fontSize: 14, color: '#6b7280', marginTop: 4 },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', padding: 10, gap: 10 },
  statCard: { flex: 1, minWidth: '45%', backgroundColor: '#12121a', borderRadius: 12, padding: 16, borderWidth: 1, borderColor: '#2a2a3e', alignItems: 'center' },
  statValue: { fontSize: 24, fontWeight: 'bold', color: '#ffffff', marginTop: 8 },
  statLabel: { fontSize: 12, color: '#6b7280', marginTop: 4 },
  sectionTitle: { fontSize: 18, fontWeight: '600', color: '#ffffff', marginHorizontal: 20, marginTop: 20, marginBottom: 12 },
  actionsGrid: { flexDirection: 'row', flexWrap: 'wrap', padding: 10, gap: 10 },
  actionButton: { flex: 1, minWidth: '45%', backgroundColor: '#12121a', borderRadius: 12, padding: 20, borderWidth: 1, alignItems: 'center' },
  actionLabel: { fontSize: 14, fontWeight: '500', marginTop: 8 },
});
