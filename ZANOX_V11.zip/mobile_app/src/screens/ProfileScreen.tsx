import React from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Switch } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

const settings = [
  { label: 'Dark Mode', icon: 'theme-light-dark', type: 'toggle', value: true },
  { label: 'Notifications', icon: 'bell', type: 'toggle', value: true },
  { label: 'Biometric Login', icon: 'fingerprint', type: 'toggle', value: false },
  { label: 'Language', icon: 'translate', type: 'link', value: 'English' },
  { label: 'Account', icon: 'account', type: 'link', value: '' },
  { label: 'Security', icon: 'shield', type: 'link', value: '' },
  { label: 'About', icon: 'information', type: 'link', value: 'v11.0.0' },
  { label: 'Sign Out', icon: 'logout', type: 'button', value: '' },
];

export default function ProfileScreen() {
  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>AC</Text>
        </View>
        <Text style={styles.name}>Alex Chen</Text>
        <Text style={styles.email}>alex@zanox.io</Text>
      </View>
      <View style={styles.settingsList}>
        {settings.map((setting, index) => (
          <TouchableOpacity key={index} style={styles.settingItem}>
            <View style={styles.settingLeft}>
              <Icon name={setting.icon} size={20} color="#6b7280" />
              <Text style={styles.settingLabel}>{setting.label}</Text>
            </View>
            {setting.type === 'toggle' && <Switch value={setting.value} trackColor={{ false: '#2a2a3e', true: '#0ea5e9' }} thumbColor="#ffffff" />}
            {setting.type === 'link' && <Text style={styles.settingValue}>{setting.value}</Text>}
            {setting.type === 'button' && <Icon name="chevron-right" size={20} color="#6b7280" />}
          </TouchableOpacity>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0a0a0f' },
  header: { alignItems: 'center', padding: 40 },
  avatar: { width: 80, height: 80, borderRadius: 40, backgroundColor: '#0ea5e9', justifyContent: 'center', alignItems: 'center', marginBottom: 16 },
  avatarText: { fontSize: 24, fontWeight: 'bold', color: '#ffffff' },
  name: { fontSize: 20, fontWeight: '600', color: '#ffffff' },
  email: { fontSize: 14, color: '#6b7280', marginTop: 4 },
  settingsList: { paddingHorizontal: 16 },
  settingItem: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, backgroundColor: '#12121a', borderRadius: 12, marginBottom: 8, borderWidth: 1, borderColor: '#2a2a3e' },
  settingLeft: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  settingLabel: { fontSize: 16, color: '#ffffff' },
  settingValue: { fontSize: 14, color: '#6b7280' },
});
