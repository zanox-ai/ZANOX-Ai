import React from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

const workflows = [
  { id: '1', name: 'Lead Capture', status: 'active', runs: 1240, icon: 'lightning-bolt' },
  { id: '2', name: 'Email Campaign', status: 'active', runs: 856, icon: 'email' },
  { id: '3', name: 'Lead Scoring', status: 'paused', runs: 432, icon: 'filter' },
];

export default function WorkflowsScreen() {
  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Workflows</Text>
      </View>
      {workflows.map((workflow) => (
        <TouchableOpacity key={workflow.id} style={styles.workflowCard}>
          <View style={styles.workflowIcon}>
            <Icon name={workflow.icon} size={24} color="#0ea5e9" />
          </View>
          <View style={styles.workflowInfo}>
            <Text style={styles.workflowName}>{workflow.name}</Text>
            <Text style={styles.workflowStats}>{workflow.runs} runs</Text>
          </View>
          <View style={[styles.statusBadge, { backgroundColor: workflow.status === 'active' ? '#10b98120' : '#f59e0b20' }]}>
            <Text style={[styles.statusText, { color: workflow.status === 'active' ? '#10b981' : '#f59e0b' }]}>{workflow.status}</Text>
          </View>
        </TouchableOpacity>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0a0a0f' },
  header: { padding: 20, paddingTop: 40 },
  title: { fontSize: 24, fontWeight: 'bold', color: '#ffffff' },
  workflowCard: { flexDirection: 'row', alignItems: 'center', padding: 16, marginHorizontal: 16, marginBottom: 12, backgroundColor: '#12121a', borderRadius: 12, borderWidth: 1, borderColor: '#2a2a3e' },
  workflowIcon: { width: 40, height: 40, borderRadius: 10, backgroundColor: '#0ea5e920', justifyContent: 'center', alignItems: 'center', marginRight: 12 },
  workflowInfo: { flex: 1 },
  workflowName: { fontSize: 16, fontWeight: '600', color: '#ffffff' },
  workflowStats: { fontSize: 12, color: '#6b7280', marginTop: 2 },
  statusBadge: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8 },
  statusText: { fontSize: 12, fontWeight: '500' },
});
