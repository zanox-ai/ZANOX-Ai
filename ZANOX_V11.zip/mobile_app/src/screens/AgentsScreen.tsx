import React from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

const agents = [
  { id: '1', name: 'Code Reviewer', status: 'active', model: 'GPT-4', icon: 'robot' },
  { id: '2', name: 'Marketing AI', status: 'busy', model: 'Claude 3', icon: 'robot' },
  { id: '3', name: 'Image Gen', status: 'active', model: 'DALL-E 3', icon: 'robot' },
];

export default function AgentsScreen() {
  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Agents</Text>
      </View>
      {agents.map((agent) => (
        <TouchableOpacity key={agent.id} style={styles.agentCard}>
          <View style={[styles.statusDot, { backgroundColor: agent.status === 'active' ? '#10b981' : '#f59e0b' }]} />
          <View style={styles.agentInfo}>
            <Text style={styles.agentName}>{agent.name}</Text>
            <Text style={styles.agentModel}>{agent.model}</Text>
          </View>
          <Icon name="chevron-right" size={20} color="#6b7280" />
        </TouchableOpacity>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0a0a0f' },
  header: { padding: 20, paddingTop: 40 },
  title: { fontSize: 24, fontWeight: 'bold', color: '#ffffff' },
  agentCard: { flexDirection: 'row', alignItems: 'center', padding: 16, marginHorizontal: 16, marginBottom: 12, backgroundColor: '#12121a', borderRadius: 12, borderWidth: 1, borderColor: '#2a2a3e' },
  statusDot: { width: 10, height: 10, borderRadius: 5, marginRight: 12 },
  agentInfo: { flex: 1 },
  agentName: { fontSize: 16, fontWeight: '600', color: '#ffffff' },
  agentModel: { fontSize: 12, color: '#6b7280', marginTop: 2 },
});
