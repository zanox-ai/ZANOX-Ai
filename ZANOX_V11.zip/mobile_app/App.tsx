import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import DashboardScreen from './src/screens/DashboardScreen';
import AgentsScreen from './src/screens/AgentsScreen';
import AIScreen from './src/screens/AIScreen';
import WorkflowsScreen from './src/screens/WorkflowsScreen';
import ProfileScreen from './src/screens/ProfileScreen';
import LoginScreen from './src/screens/LoginScreen';

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

function MainTabs() {
  return (
    <Tab.Navigator screenOptions={({ route }) => ({ tabBarIcon: ({ focused, color, size }) => {
      let iconName;
      switch (route.name) {
        case 'Dashboard': iconName = focused ? 'view-dashboard' : 'view-dashboard-outline'; break;
        case 'Agents': iconName = focused ? 'robot' : 'robot-outline'; break;
        case 'AI': iconName = focused ? 'brain' : 'brain-outline'; break;
        case 'Workflows': iconName = focused ? 'lightning-bolt' : 'lightning-bolt-outline'; break;
        case 'Profile': iconName = focused ? 'account' : 'account-outline'; break;
        default: iconName = 'circle';
      }
      return <Icon name={iconName} size={size} color={color} />;
    }, tabBarActiveTintColor: '#0ea5e9', tabBarInactiveTintColor: '#6b7280', tabBarStyle: { backgroundColor: '#0a0a0f', borderTopColor: '#2a2a3e' }, headerShown: false })}>
      <Tab.Screen name="Dashboard" component={DashboardScreen} />
      <Tab.Screen name="Agents" component={AgentsScreen} />
      <Tab.Screen name="AI" component={AIScreen} />
      <Tab.Screen name="Workflows" component={WorkflowsScreen} />
      <Tab.Screen name="Profile" component={ProfileScreen} />
    </Tab.Navigator>
  );
}

export default function App() {
  return (
    <SafeAreaProvider>
      <NavigationContainer>
        <Stack.Navigator screenOptions={{ headerShown: false }}>
          <Stack.Screen name="Login" component={LoginScreen} />
          <Stack.Screen name="Main" component={MainTabs} />
        </Stack.Navigator>
      </NavigationContainer>
    </SafeAreaProvider>
  );
}
