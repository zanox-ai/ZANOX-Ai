'use client';

import { useZanox } from '@/hooks/useZanoxStore';
import { useEffect } from 'react';
import { motion } from 'framer-motion';
import { Bot, Workflow, Palette, Gamepad2, Building2, Zap, TrendingUp, ArrowUpRight, ArrowDownRight, Users, FolderKanban, CheckCircle2, AlertCircle, Loader2, CircleDot, Activity, Clock, Cpu } from 'lucide-react';
import Link from 'next/link';

const stats = [
  { name: 'Active Agents', value: '12', change: '+3', trend: 'up', icon: Bot, color: 'from-blue-500 to-cyan-500' },
  { name: 'Running Workflows', value: '8', change: '+2', trend: 'up', icon: Workflow, color: 'from-purple-500 to-pink-500' },
  { name: 'Projects', value: '24', change: '+5', trend: 'up', icon: FolderKanban, color: 'from-orange-500 to-red-500' },
  { name: 'Team Members', value: '6', change: '0', trend: 'neutral', icon: Users, color: 'from-green-500 to-emerald-500' },
];

const quickActions = [
  { name: 'New Agent', href: '/agents/new', icon: Bot, color: 'bg-blue-500/10 text-blue-600' },
  { name: 'Create Workflow', href: '/workflows/new', icon: Workflow, color: 'bg-purple-500/10 text-purple-600' },
  { name: 'Generate Image', href: '/creative/image', icon: Palette, color: 'bg-pink-500/10 text-pink-600' },
  { name: 'Build App', href: '/builder/new', icon: Zap, color: 'bg-orange-500/10 text-orange-600' },
  { name: 'New Game', href: '/games/new', icon: Gamepad2, color: 'bg-green-500/10 text-green-600' },
  { name: 'Business Report', href: '/business/reports', icon: Building2, color: 'bg-cyan-500/10 text-cyan-600' },
];

const recentActivity = [
  { id: '1', type: 'agent', title: 'GPT-4 Agent completed task', description: 'Code review for Project Alpha', time: '2 min ago', status: 'success' },
  { id: '2', type: 'workflow', title: 'Marketing Automation triggered', description: 'Email campaign sequence started', time: '15 min ago', status: 'active' },
  { id: '3', type: 'creative', title: 'Image generation completed', description: '5 assets for Brand Campaign', time: '32 min ago', status: 'success' },
  { id: '4', type: 'deployment', title: 'App deployed to production', description: 'E-commerce dashboard v2.1', time: '1 hour ago', status: 'success' },
  { id: '5', type: 'game', title: 'Unity build completed', description: 'Mobile game prototype ready', time: '2 hours ago', status: 'success' },
];

const aiProviders = [
  { name: 'ChatGPT', status: 'online', icon: 'GPT', color: 'bg-green-500' },
  { name: 'Claude', status: 'online', icon: 'Cl', color: 'bg-orange-500' },
  { name: 'Gemini', status: 'online', icon: 'G', color: 'bg-blue-500' },
  { name: 'Grok', status: 'busy', icon: 'Gk', color: 'bg-yellow-500' },
  { name: 'Kimi', status: 'online', icon: 'K', color: 'bg-purple-500' },
  { name: 'Perplexity', status: 'online', icon: 'P', color: 'bg-teal-500' },
  { name: 'Qwen', status: 'offline', icon: 'Q', color: 'bg-gray-400' },
  { name: 'Copilot', status: 'online', icon: 'Cp', color: 'bg-indigo-500' },
  { name: 'Manus', status: 'online', icon: 'M', color: 'bg-pink-500' },
];

export function UnifiedDashboard() {
  const { user, addNotification } = useZanox();

  useEffect(() => {
    const timer = setTimeout(() => {
      addNotification({
        id: 'welcome-' + Date.now(),
        type: 'info',
        title: 'Welcome to ZANOX V11',
        message: 'Experience Layer is now active. Explore the new unified interface.',
        read: false,
        timestamp: new Date().toISOString(),
      });
    }, 2000);
    return () => clearTimeout(timer);
  }, [addNotification]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Welcome back, <span className="text-gradient">{user?.name || 'User'}</span></h1>
          <p className="text-muted-foreground mt-1">Here is what is happening across your ZANOX ecosystem</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 px-3 py-1.5 bg-green-500/10 text-green-600 rounded-full text-sm">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            System Online
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => (
          <motion.div key={stat.name} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.1 }}
            className="glass-panel p-5 card-hover">
            <div className="flex items-start justify-between">
              <div className={`p-2.5 rounded-lg bg-gradient-to-br ${stat.color} text-white`}><stat.icon className="w-5 h-5" /></div>
              <div className={`flex items-center gap-1 text-sm ${stat.trend === 'up' ? 'text-green-600' : 'text-gray-500'}`}>
                {stat.trend === 'up' ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
                {stat.change}
              </div>
            </div>
            <div className="mt-3">
              <p className="text-2xl font-bold">{stat.value}</p>
              <p className="text-sm text-muted-foreground">{stat.name}</p>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="lg:col-span-2 glass-panel p-5">
          <h3 className="font-semibold mb-4">Quick Actions</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {quickActions.map((action) => (
              <Link key={action.name} href={action.href} className="flex items-center gap-3 p-3 rounded-lg hover:bg-accent transition-all group">
                <div className={`p-2 rounded-lg ${action.color} group-hover:scale-110 transition-transform`}><action.icon className="w-5 h-5" /></div>
                <span className="text-sm font-medium">{action.name}</span>
              </Link>
            ))}
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }} className="glass-panel p-5">
          <h3 className="font-semibold mb-4">AI Providers</h3>
          <div className="space-y-2.5">
            {aiProviders.map((provider) => (
              <div key={provider.name} className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-lg ${provider.color} flex items-center justify-center text-white text-xs font-bold`}>{provider.icon}</div>
                <div className="flex-1"><p className="text-sm font-medium">{provider.name}</p></div>
                <div className="flex items-center gap-1.5">
                  <div className={`w-2 h-2 rounded-full ${provider.status === 'online' ? 'bg-green-500' : provider.status === 'busy' ? 'bg-yellow-500' : 'bg-gray-400'}`} />
                  <span className="text-xs text-muted-foreground capitalize">{provider.status}</span>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }} className="glass-panel p-5">
          <h3 className="font-semibold mb-4">Recent Activity</h3>
          <div className="space-y-3">
            {recentActivity.map((activity) => (
              <div key={activity.id} className="flex items-start gap-3 p-3 rounded-lg hover:bg-accent/50 transition-colors">
                <div className={`mt-0.5 ${activity.status === 'success' ? 'text-green-500' : activity.status === 'active' ? 'text-blue-500' : 'text-gray-500'}`}>
                  {activity.status === 'success' ? <CheckCircle2 className="w-5 h-5" /> : activity.status === 'active' ? <Loader2 className="w-5 h-5 animate-spin" /> : <CircleDot className="w-5 h-5" />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium">{activity.title}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{activity.description}</p>
                </div>
                <span className="text-xs text-muted-foreground whitespace-nowrap">{activity.time}</span>
              </div>
            ))}
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.7 }} className="glass-panel p-5">
          <h3 className="font-semibold mb-4">System Health</h3>
          <div className="space-y-4">
            {[
              { label: 'CPU Usage', value: 42, color: 'from-blue-500 to-cyan-500' },
              { label: 'Memory', value: 68, color: 'from-purple-500 to-pink-500' },
              { label: 'Storage', value: 23, color: 'from-green-500 to-emerald-500' },
              { label: 'Network', value: 89, color: 'from-orange-500 to-red-500' },
            ].map((metric) => (
              <div key={metric.label}>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-sm">{metric.label}</span>
                  <span className="text-sm font-medium">{metric.value}%</span>
                </div>
                <div className="h-2 bg-accent rounded-full overflow-hidden">
                  <div className={`h-full bg-gradient-to-r ${metric.color} rounded-full transition-all`} style={{ width: `${metric.value}%` }} />
                </div>
              </div>
            ))}
            <div className="pt-2 border-t border-border">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Uptime</span>
                <span className="font-medium">99.98%</span>
              </div>
              <div className="flex items-center justify-between text-sm mt-1">
                <span className="text-muted-foreground">Last Backup</span>
                <span className="font-medium">2 hours ago</span>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
