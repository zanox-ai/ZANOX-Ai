'use client';

import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ThemeProvider } from 'next-themes';
import { Toaster } from 'react-hot-toast';
import { useState } from 'react';
import { WebSocketProvider } from '@/hooks/useWebSocket';
import { ZanoxStoreProvider } from '@/hooks/useZanoxStore';

export function Providers({ children }: { children: React.ReactNode }) {
  const [queryClient] = useState(() => new QueryClient({
    defaultOptions: { queries: { staleTime: 60 * 1000, refetchOnWindowFocus: false, retry: 3, retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000) } },
  }));

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
        <ZanoxStoreProvider>
          <WebSocketProvider url={process.env.NEXT_PUBLIC_WS_URL || 'ws://localhost:4001'}>
            {children}
            <Toaster position="top-right" toastOptions={{ duration: 4000, style: { background: 'var(--card)', color: 'var(--card-foreground)', border: '1px solid var(--border)' } }} />
          </WebSocketProvider>
        </ZanoxStoreProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}
