'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Users, Plus, Search, Mail, Shield, MoreHorizontal, Crown, UserCheck, UserX, Clock, Activity } from 'lucide-react';
import { AppShell } from '@/components/AppShell';

const teamMembers = [
  { id: '1', name: 'Alex Chen', email: 'alex@zanox.io', role: 'owner', status: 'active', lastActive: 'Just now', avatar: 'AC', projects: 12, tasks: 45 },
  { id: '2', name: 'Sarah Miller', email: 'sarah@zanox.io', role: 'admin', status: 'active', lastActive: '5 min ago', avatar: 'SM', projects: 8, tasks: 32 },
  { id: '3', name: 'James Wilson', email: 'james@zanox.io', role: 'member', status: 'active', lastActive: '1 hour ago', avatar: 'JW', projects: 6, tasks: 28 },
  { id: '4', name: 'Emily Davis', email: 'emily@zanox.io', role: 'member', status: 'away', lastActive: '3 hours ago', avatar: 'ED', projects: 5, tasks: 19 },
  { id: '5', name: 'Michael Park', email: 'michael@zanox.io', role: 'viewer', status: 'active', lastActive: '30 min ago', avatar: 'MP', projects: 3, tasks: 12 },
  { id: '6', name: 'Lisa Wang', email: 'lisa@zanox.io', role: 'member', status: 'offline', lastActive: '2 days ago', avatar: 'LW', projects: 4, tasks: 15 },
];

const roleColors = {
  owner: 'bg-purple-500/10 text-purple-600',
  admin: 'bg-blue-500/10 text-blue-600',
  member: 'bg-green-500/10 text-green-600',
  viewer: 'bg-gray-500/10 text-gray-600',
};

const statusColors = {
  active: 'bg-green-500',
  away: 'bg-yellow-500',
  offline: 'bg-gray-400',
};

export default function TeamPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const filteredMembers = teamMembers.filter((m) => m.name.toLowerCase().includes(searchQuery.toLowerCase()) || m.email.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <AppShell>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div><h1 className="text-2xl font-bold">Team Center</h1><p className="text-muted-foreground mt-1">Manage team members and permissions</p></div>
          <button className="btn-primary flex items-center gap-2"><Plus className="w-4 h-4" /> Invite Member</button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-5 gap-4">
          <div className="glass-panel p-4 text-center">
            <p className="text-3xl font-bold">{teamMembers.length}</p><p className="text-sm text-muted-foreground">Total Members</p>
          </div>
          <div className="glass-panel p-4 text-center">
            <p className="text-3xl font-bold text-green-600">{teamMembers.filter((m) => m.status === 'active').length}</p><p className="text-sm text-muted-foreground">Active Now</p>
          </div>
          <div className="glass-panel p-4 text-center">
            <p className="text-3xl font-bold">{teamMembers.reduce((acc, m) => acc + m.projects, 0)}</p><p className="text-sm text-muted-foreground">Projects</p>
          </div>
          <div className="glass-panel p-4 text-center">
            <p className="text-3xl font-bold">{teamMembers.reduce((acc, m) => acc + m.tasks, 0)}</p><p className="text-sm text-muted-foreground">Tasks</p>
          </div>
          <div className="glass-panel p-4 text-center">
            <p className="text-3xl font-bold text-purple-600">1</p><p className="text-sm text-muted-foreground">Owner</p>
          </div>
        </div>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Search team members..." className="w-full pl-9 pr-4 py-2 bg-background border border-input rounded-lg input-focus text-sm" />
        </div>

        <div className="space-y-3">
          {filteredMembers.map((member, index) => (
            <motion.div key={member.id} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: index * 0.05 }}
              className="glass-panel p-4 flex items-center gap-4 group hover:border-zanox-300 dark:hover:border-zanox-700 transition-colors">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-zanox-500 to-accent-purple flex items-center justify-center text-white font-medium text-sm">{member.avatar}</div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <h3 className="font-medium">{member.name}</h3>
                  <div className={`w-2 h-2 rounded-full ${statusColors[member.status as keyof typeof statusColors]}`} />
                </div>
                <p className="text-sm text-muted-foreground">{member.email}</p>
              </div>
              <div className="hidden sm:flex items-center gap-4 text-sm text-muted-foreground">
                <span className="flex items-center gap-1"><Activity className="w-4 h-4" /> {member.projects} projects</span>
                <span className="flex items-center gap-1"><Clock className="w-4 h-4" /> {member.lastActive}</span>
              </div>
              <span className={`px-2 py-1 text-xs rounded-lg font-medium ${roleColors[member.role as keyof typeof roleColors]}`}>{member.role}</span>
              <button className="p-2 hover:bg-accent rounded-lg transition-colors opacity-0 group-hover:opacity-100"><MoreHorizontal className="w-4 h-4" /></button>
            </motion.div>
          ))}
        </div>
      </div>
    </AppShell>
  );
}
