'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Settings, User, Bell, Shield, Palette, Globe, Database, Zap, Save, Moon, Sun, Monitor, Check } from 'lucide-react';
import { AppShell } from '@/components/AppShell';
import { useTheme } from 'next-themes';

const settingsTabs = [
  { id: 'profile', name: 'Profile', icon: User },
  { id: 'notifications', name: 'Notifications', icon: Bell },
  { id: 'appearance', name: 'Appearance', icon: Palette },
  { id: 'security', name: 'Security', icon: Shield },
  { id: 'integrations', name: 'Integrations', icon: Zap },
  { id: 'billing', name: 'Billing', icon: Database },
];

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState('profile');
  const { theme, setTheme } = useTheme();
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <AppShell>
      <div className="space-y-6">
        <div><h1 className="text-2xl font-bold">Settings</h1><p className="text-muted-foreground mt-1">Manage your account and preferences</p></div>
        <div className="flex flex-col lg:flex-row gap-6">
          <div className="w-full lg:w-64 space-y-1">
            {settingsTabs.map((tab) => (
              <button key={tab.id} onClick={() => setActiveTab(tab.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all ${activeTab === tab.id ? 'bg-zanox-50 dark:bg-zanox-900/30 text-zanox-700 dark:text-zanox-400 border-r-2 border-zanox-500' : 'text-gray-600 dark:text-gray-400 hover:bg-accent'}`}>
                <tab.icon className="w-5 h-5" />{tab.name}
              </button>
            ))}
          </div>
          <div className="flex-1">
            {activeTab === 'profile' && (
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="glass-panel p-6 space-y-6">
                <h3 className="font-semibold text-lg">Profile Settings</h3>
                <div className="flex items-center gap-4">
                  <div className="w-20 h-20 rounded-full bg-gradient-to-br from-zanox-500 to-accent-purple flex items-center justify-center text-white text-2xl font-medium">AC</div>
                  <div><button className="btn-primary text-sm">Change Avatar</button><p className="text-xs text-muted-foreground mt-1">JPG, PNG or GIF. Max 2MB.</p></div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div><label className="text-sm font-medium">First Name</label><input type="text" defaultValue="Alex" className="w-full mt-1 px-3 py-2 bg-background border border-input rounded-lg text-sm input-focus" /></div>
                  <div><label className="text-sm font-medium">Last Name</label><input type="text" defaultValue="Chen" className="w-full mt-1 px-3 py-2 bg-background border border-input rounded-lg text-sm input-focus" /></div>
                  <div className="sm:col-span-2"><label className="text-sm font-medium">Email</label><input type="email" defaultValue="alex@zanox.io" className="w-full mt-1 px-3 py-2 bg-background border border-input rounded-lg text-sm input-focus" /></div>
                  <div className="sm:col-span-2"><label className="text-sm font-medium">Bio</label><textarea defaultValue="AI enthusiast and automation expert." rows={3} className="w-full mt-1 px-3 py-2 bg-background border border-input rounded-lg text-sm input-focus resize-none" /></div>
                </div>
              </motion.div>
            )}
            {activeTab === 'appearance' && (
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="glass-panel p-6 space-y-6">
                <h3 className="font-semibold text-lg">Appearance</h3>
                <div className="space-y-4">
                  <div><label className="text-sm font-medium">Theme</label>
                    <div className="grid grid-cols-3 gap-3 mt-2">
                      <button onClick={() => setTheme('light')} className={`p-4 rounded-xl border-2 transition-all ${theme === 'light' ? 'border-zanox-500 bg-zanox-50' : 'border-border hover:border-zanox-300'}`}>
                        <Sun className="w-6 h-6 mx-auto mb-2" /><p className="text-sm font-medium text-center">Light</p>
                      </button>
                      <button onClick={() => setTheme('dark')} className={`p-4 rounded-xl border-2 transition-all ${theme === 'dark' ? 'border-zanox-500 bg-dark-elevated' : 'border-border hover:border-zanox-300'}`}>
                        <Moon className="w-6 h-6 mx-auto mb-2" /><p className="text-sm font-medium text-center">Dark</p>
                      </button>
                      <button onClick={() => setTheme('system')} className={`p-4 rounded-xl border-2 transition-all ${theme === 'system' ? 'border-zanox-500 bg-accent' : 'border-border hover:border-zanox-300'}`}>
                        <Monitor className="w-6 h-6 mx-auto mb-2" /><p className="text-sm font-medium text-center">System</p>
                      </button>
                    </div>
                  </div>
                  <div><label className="text-sm font-medium">Language</label>
                    <select className="w-full mt-1 px-3 py-2 bg-background border border-input rounded-lg text-sm input-focus">
                      <option>English</option><option>Chinese</option><option>Japanese</option><option>Spanish</option>
                    </select>
                  </div>
                  <div><label className="text-sm font-medium">Timezone</label>
                    <select className="w-full mt-1 px-3 py-2 bg-background border border-input rounded-lg text-sm input-focus">
                      <option>UTC-8 (Pacific Time)</option><option>UTC-5 (Eastern Time)</option><option>UTC+0 (London)</option><option>UTC+8 (Singapore)</option>
                    </select>
                  </div>
                </div>
              </motion.div>
            )}
            {activeTab === 'notifications' && (
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="glass-panel p-6 space-y-6">
                <h3 className="font-semibold text-lg">Notifications</h3>
                <div className="space-y-4">
                  {['Email notifications', 'Push notifications', 'Weekly digest', 'Agent alerts', 'Security alerts', 'Marketing updates'].map((item) => (
                    <div key={item} className="flex items-center justify-between p-3 bg-accent/50 rounded-lg">
                      <span className="text-sm font-medium">{item}</span>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" defaultChecked className="sr-only peer" />
                        <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-zanox-600"></div>
                      </label>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}
            <div className="mt-4 flex justify-end">
              <button onClick={handleSave} className="btn-primary flex items-center gap-2">
                {saved ? <><Check className="w-4 h-4" /> Saved</> : <><Save className="w-4 h-4" /> Save Changes</>}
              </button>
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
