'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Building2, Plus, Search, TrendingUp, Users, DollarSign, BarChart3, Target, Mail, MessageSquare, Headphones, Megaphone, ShoppingCart, FileText, Settings, ArrowUpRight, ArrowDownRight, Activity } from 'lucide-react';
import { AppShell } from '@/components/AppShell';

const businessModules = [
  { id: 'crm', name: 'CRM', icon: Users, color: 'bg-blue-500', description: 'Customer relationship management', leads: 1240, deals: 89 },
  { id: 'erp', name: 'ERP', icon: Building2, color: 'bg-indigo-500', description: 'Enterprise resource planning', orders: 456, inventory: 2340 },
  { id: 'marketing', name: 'Marketing', icon: Megaphone, color: 'bg-pink-500', description: 'Campaign management', campaigns: 12, reach: 45000 },
  { id: 'sales', name: 'Sales', icon: ShoppingCart, color: 'bg-green-500', description: 'Sales pipeline and forecasting', revenue: 124000, pipeline: 89000 },
  { id: 'analytics', name: 'Analytics', icon: BarChart3, color: 'bg-purple-500', description: 'Business intelligence', reports: 45, insights: 234 },
  { id: 'seo', name: 'SEO', icon: Target, color: 'bg-orange-500', description: 'Search optimization', keywords: 340, ranking: 12 },
  { id: 'support', name: 'Support', icon: Headphones, color: 'bg-cyan-500', description: 'Customer support tickets', tickets: 56, resolved: 48 },
  { id: 'automation', name: 'Automation', icon: Activity, color: 'bg-teal-500', description: 'Business process automation', workflows: 23, efficiency: 87 },
];

const mockDeals = [
  { id: '1', name: 'Enterprise Contract', value: 125000, stage: 'negotiation', probability: 75, company: 'TechCorp', contact: 'John Smith', lastActivity: '2 hours ago' },
  { id: '2', name: 'SaaS License', value: 45000, stage: 'proposal', probability: 60, company: 'StartupX', contact: 'Sarah Lee', lastActivity: '1 day ago' },
  { id: '3', name: 'Consulting Project', value: 89000, stage: 'discovery', probability: 40, company: 'GlobalInc', contact: 'Mike Chen', lastActivity: '3 days ago' },
  { id: '4', name: 'Integration Deal', value: 34000, stage: 'closed-won', probability: 100, company: 'DataFlow', contact: 'Emma Wilson', lastActivity: '1 week ago' },
  { id: '5', name: 'Support Contract', value: 18000, stage: 'proposal', probability: 55, company: 'CloudNet', contact: 'David Park', lastActivity: '2 days ago' },
];

export default function BusinessPage() {
  const [selectedModule, setSelectedModule] = useState('crm');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredDeals = mockDeals.filter((deal) => deal.name.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <AppShell>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div><h1 className="text-2xl font-bold">Business Center</h1><p className="text-muted-foreground mt-1">Complete business operating system</p></div>
          <button className="btn-primary flex items-center gap-2"><Plus className="w-4 h-4" /> New Deal</button>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
          {businessModules.map((module) => (
            <button key={module.id} onClick={() => setSelectedModule(module.id)}
              className={`p-4 rounded-xl transition-all ${selectedModule === module.id ? 'bg-zanox-50 dark:bg-zanox-900/30 border-2 border-zanox-500' : 'glass-panel hover:border-zanox-300'}`}>
              <div className={`w-8 h-8 rounded-lg ${module.color} flex items-center justify-center text-white mb-2`}><module.icon className="w-4 h-4" /></div>
              <h3 className="font-medium text-sm">{module.name}</h3>
            </button>
          ))}
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-5 gap-4">
          <div className="glass-panel p-4">
            <div className="flex items-center gap-2 mb-2"><DollarSign className="w-5 h-5 text-green-500" /><span className="text-sm text-muted-foreground">Total Revenue</span></div>
            <p className="text-2xl font-bold">$1.2M</p>
            <span className="text-xs text-green-600 flex items-center gap-1"><ArrowUpRight className="w-3 h-3" /> +12.5%</span>
          </div>
          <div className="glass-panel p-4">
            <div className="flex items-center gap-2 mb-2"><Users className="w-5 h-5 text-blue-500" /><span className="text-sm text-muted-foreground">Active Customers</span></div>
            <p className="text-2xl font-bold">2,450</p>
            <span className="text-xs text-green-600 flex items-center gap-1"><ArrowUpRight className="w-3 h-3" /> +8.3%</span>
          </div>
          <div className="glass-panel p-4">
            <div className="flex items-center gap-2 mb-2"><Target className="w-5 h-5 text-purple-500" /><span className="text-sm text-muted-foreground">Conversion Rate</span></div>
            <p className="text-2xl font-bold">24.8%</p>
            <span className="text-xs text-red-600 flex items-center gap-1"><ArrowDownRight className="w-3 h-3" /> -2.1%</span>
          </div>
          <div className="glass-panel p-4">
            <div className="flex items-center gap-2 mb-2"><TrendingUp className="w-5 h-5 text-orange-500" /><span className="text-sm text-muted-foreground">Pipeline Value</span></div>
            <p className="text-2xl font-bold">$450K</p>
            <span className="text-xs text-green-600 flex items-center gap-1"><ArrowUpRight className="w-3 h-3" /> +15.2%</span>
          </div>
          <div className="glass-panel p-4">
            <div className="flex items-center gap-2 mb-2"><Activity className="w-5 h-5 text-cyan-500" /><span className="text-sm text-muted-foreground">Active Deals</span></div>
            <p className="text-2xl font-bold">34</p>
            <span className="text-xs text-green-600 flex items-center gap-1"><ArrowUpRight className="w-3 h-3" /> +5.7%</span>
          </div>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Search deals..." className="w-full pl-9 pr-4 py-2 bg-background border border-input rounded-lg input-focus text-sm" />
        </div>
        <div className="space-y-3">
          {filteredDeals.map((deal, index) => (
            <motion.div key={deal.id} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: index * 0.05 }}
              className="glass-panel p-4 flex items-center gap-4 group hover:border-zanox-300 dark:hover:border-zanox-700 transition-colors">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-zanox-500 to-accent-purple flex items-center justify-center text-white flex-shrink-0"><DollarSign className="w-5 h-5" /></div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <h3 className="font-medium">{deal.name}</h3>
                  <span className="text-xs text-muted-foreground">{deal.company}</span>
                </div>
                <p className="text-sm text-muted-foreground mt-0.5">Contact: {deal.contact} | Probability: {deal.probability}%</p>
              </div>
              <div className="hidden sm:flex items-center gap-4 text-sm">
                <span className="font-medium">${deal.value.toLocaleString()}</span>
                <span className={`px-2 py-0.5 text-xs rounded-full ${deal.stage === 'closed-won' ? 'bg-green-500/10 text-green-600' : deal.stage === 'negotiation' ? 'bg-orange-500/10 text-orange-600' : 'bg-blue-500/10 text-blue-600'}`}>{deal.stage}</span>
                <span className="text-muted-foreground">{deal.lastActivity}</span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </AppShell>
  );
}
