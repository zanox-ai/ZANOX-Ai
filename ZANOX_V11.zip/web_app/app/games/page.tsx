'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Gamepad2, Plus, Search, Play, Download, Settings, Monitor, Smartphone, Globe, Box, Layers, Code, Star, Eye, GitFork, Cpu, Zap } from 'lucide-react';
import { AppShell } from '@/components/AppShell';

const gameEngines = [
  { name: 'Unity', icon: Box, color: 'bg-gray-800', category: '3D' },
  { name: 'Unreal', icon: Layers, color: 'bg-blue-900', category: '3D' },
  { name: 'Godot', icon: Code, color: 'bg-indigo-500', category: '2D/3D' },
  { name: 'Roblox Studio', icon: Box, color: 'bg-red-500', category: 'Metaverse' },
  { name: 'Construct 3', icon: Layers, color: 'bg-orange-500', category: '2D' },
  { name: 'GDevelop', icon: Code, color: 'bg-purple-500', category: '2D' },
  { name: 'Buildbox', icon: Box, color: 'bg-yellow-500', category: 'No-Code' },
  { name: 'Defold', icon: Layers, color: 'bg-blue-500', category: '2D' },
  { name: 'Rosebud', icon: Star, color: 'bg-pink-500', category: 'AI' },
];

const mockGames = [
  { id: '1', name: 'Space Explorer', engine: 'Unity', platform: 'mobile', status: 'published', players: 12400, rating: 4.8, lastUpdate: '2 days ago' },
  { id: '2', name: 'Puzzle Quest', engine: 'Godot', platform: 'web', status: 'beta', players: 3400, rating: 4.5, lastUpdate: '1 week ago' },
  { id: '3', name: 'Racing Pro', engine: 'Unreal', platform: 'desktop', status: 'development', players: 0, rating: 0, lastUpdate: '3 hours ago' },
  { id: '4', name: 'Meta World', engine: 'Roblox Studio', platform: 'metaverse', status: 'published', players: 56000, rating: 4.9, lastUpdate: '1 day ago' },
  { id: '5', name: 'Pixel Adventure', engine: 'GDevelop', platform: 'mobile', status: 'published', players: 8900, rating: 4.6, lastUpdate: '5 days ago' },
];

export default function GamesPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedEngine, setSelectedEngine] = useState('all');

  const filteredGames = mockGames.filter((game) => {
    const matchesSearch = game.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesEngine = selectedEngine === 'all' || game.engine === selectedEngine;
    return matchesSearch && matchesEngine;
  });

  return (
    <AppShell>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div><h1 className="text-2xl font-bold">Game Center</h1><p className="text-muted-foreground mt-1">Game development and publishing platform</p></div>
          <button className="btn-primary flex items-center gap-2"><Plus className="w-4 h-4" /> New Game</button>
        </div>
        <div className="glass-panel p-5">
          <h3 className="font-semibold mb-4">Connected Game Engines</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            {gameEngines.map((engine) => (
              <div key={engine.name} className="flex flex-col items-center gap-2 p-3 rounded-lg bg-accent/50 hover:bg-accent transition-colors cursor-pointer">
                <div className={`w-10 h-10 rounded-lg ${engine.color} flex items-center justify-center text-white`}><engine.icon className="w-5 h-5" /></div>
                <span className="text-xs font-medium text-center">{engine.name}</span>
                <span className="text-xs text-muted-foreground">{engine.category}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Search games..." className="w-full pl-9 pr-4 py-2 bg-background border border-input rounded-lg input-focus text-sm" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredGames.map((game, index) => (
            <motion.div key={game.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.05 }}
              className="glass-panel p-5 card-hover group">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-zanox-500 to-accent-purple flex items-center justify-center text-white"><Gamepad2 className="w-5 h-5" /></div>
                  <div><h3 className="font-semibold">{game.name}</h3><p className="text-xs text-muted-foreground">{game.engine} / {game.platform}</p></div>
                </div>
                <span className={`px-2 py-0.5 text-xs rounded-full ${game.status === 'published' ? 'bg-green-500/10 text-green-600' : game.status === 'beta' ? 'bg-blue-500/10 text-blue-600' : 'bg-yellow-500/10 text-yellow-600'}`}>{game.status}</span>
              </div>
              <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                <span className="flex items-center gap-1"><Eye className="w-4 h-4" /> {game.players.toLocaleString()}</span>
                <span className="flex items-center gap-1"><Star className="w-4 h-4" /> {game.rating}</span>
                <span>{game.lastUpdate}</span>
              </div>
              <div className="flex gap-2">
                <button className="flex-1 py-2 bg-zanox-50 dark:bg-zanox-900/20 text-zanox-700 dark:text-zanox-300 rounded-lg text-sm font-medium hover:bg-zanox-100 dark:hover:bg-zanox-900/40 transition-colors flex items-center justify-center gap-1"><Play className="w-4 h-4" /> Play</button>
                <button className="p-2 hover:bg-accent rounded-lg transition-colors"><Settings className="w-4 h-4" /></button>
                <button className="p-2 hover:bg-accent rounded-lg transition-colors"><Download className="w-4 h-4" /></button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </AppShell>
  );
}
