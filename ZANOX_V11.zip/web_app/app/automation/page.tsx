'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Workflow, Plus, Play, Pause, Settings, MoreHorizontal, Filter, Search, Clock, GitBranch, Zap, Timer, Mail, Database, Webhook, CheckCircle2, XCircle, Puzzle, Wind, Globe, LayoutGrid } from 'lucide-react';
import { AppShell } from '@/components/AppShell';

interface WorkflowNode {
  id: string;
  type: 'trigger' | 'action' | 'condition' | 'delay' | 'webhook';
  name: string;
  description: string;
  status: 'active' | 'paused' | 'error' | 'draft';
  lastRun: string;
  runs: number;
  icon: any;
}

const automationTools = [
  { name: 'n8n', icon: Zap, color: 'bg-orange-500' },
  { name: 'Zapier', icon: Zap, color: 'bg-orange-600' },
  { name: 'Make', icon: Workflow, color: 'bg-blue-600' },
  { name: 'Activepieces', icon: Puzzle, color: 'bg-purple-600' },
  { name: 'Pipedream', icon: GitBranch, color: 'bg-green-600' },
  { name: 'Windmill', icon: Wind, color: 'bg-cyan-600' },
  { name: 'Flowise', icon: LayoutGrid, color: 'bg-pink-600' },
  { name: 'Langflow', icon: Globe, color: 'bg-indigo-600' },
  { name: 'Dify', icon: Database, color: 'bg-teal-600' },
  { name: 'OpenWebUI', icon: Globe, color: 'bg-red-600' },
];

const mockWorkflows: WorkflowNode[] = [
  { id: '1', type: 'trigger', name: 'New Lead Capture', description: 'Trigger when new lead form submitted', status: 'active', lastRun: '2 min ago', runs: 1240, icon: Webhook },
  { id: '2', type: 'action', name: 'Email Campaign', description: 'Send personalized email sequence', status: 'active', lastRun: '15 min ago', runs: 856, icon: Mail },
  { id: '3', type: 'condition', name: 'Lead Scoring', description: 'Score leads based on behavior', status: 'paused', lastRun: '1 hour ago', runs: 432, icon: Filter },
  { id: '4', type: 'delay', name: 'Follow-up Timer', description: 'Wait 3 days before follow-up', status: 'active', lastRun: '3 days ago', runs: 234, icon: Timer },
  { id: '5', type: 'webhook', name: 'CRM Sync', description: 'Sync data to Salesforce', status: 'error', lastRun: '5 min ago', runs: 567, icon: Database },
];

export default function AutomationPage() {
  const [workflows] = useState<WorkflowNode[]>(mockWorkflows);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredWorkflows = workflows.filter((w) => w.name.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <AppShell>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div><h1 className="text-2xl font-bold">Automation Center</h1><p className="text-muted-foreground mt-1">Visual workflow builder and automation management</p></div>
          <button className="btn-primary flex items-center gap-2"><Plus className="w-4 h-4" /> New Workflow</button>
        </div>
        <div className="glass-panel p-5">
          <h3 className="font-semibold mb-4">Connected Automation Tools</h3>
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
            {automationTools.map((tool) => (
              <div key={tool.name} className="flex items-center gap-3 p-3 rounded-lg bg-accent/50 hover:bg-accent transition-colors">
                <div className={`w-8 h-8 rounded-lg ${tool.color} flex items-center justify-center text-white`}><tool.icon className="w-4 h-4" /></div>
                <span className="text-sm font-medium">{tool.name}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Search workflows..." className="w-full pl-9 pr-4 py-2 bg-background border border-input rounded-lg input-focus text-sm" />
        </div>
        <div className="space-y-3">
          {filteredWorkflows.map((workflow, index) => (
            <motion.div key={workflow.id} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: index * 0.05 }}
              className="glass-panel p-4 flex items-center gap-4 group hover:border-zanox-300 dark:hover:border-zanox-700 transition-colors">
              <div className={`p-2.5 rounded-lg ${workflow.type === 'trigger' ? 'bg-orange-500/10 text-orange-600' : workflow.type === 'action' ? 'bg-blue-500/10 text-blue-600' : workflow.type === 'condition' ? 'bg-purple-500/10 text-purple-600' : workflow.type === 'delay' ? 'bg-yellow-500/10 text-yellow-600' : 'bg-green-500/10 text-green-600'}`}>
                <workflow.icon className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <h3 className="font-medium">{workflow.name}</h3>
                  <span className={`px-2 py-0.5 text-xs rounded-full ${workflow.status === 'active' ? 'bg-green-500/10 text-green-600' : workflow.status === 'paused' ? 'bg-yellow-500/10 text-yellow-600' : 'bg-red-500/10 text-red-600'}`}>{workflow.status}</span>
                </div>
                <p className="text-sm text-muted-foreground mt-0.5">{workflow.description}</p>
              </div>
              <div className="hidden sm:flex items-center gap-4 text-sm text-muted-foreground">
                <span className="flex items-center gap-1"><Play className="w-4 h-4" /> {workflow.runs} runs</span>
                <span className="flex items-center gap-1"><Clock className="w-4 h-4" /> {workflow.lastRun}</span>
              </div>
              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button className="p-2 hover:bg-accent rounded-lg transition-colors">{workflow.status === 'active' ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}</button>
                <button className="p-2 hover:bg-accent rounded-lg transition-colors"><Settings className="w-4 h-4" /></button>
                <button className="p-2 hover:bg-accent rounded-lg transition-colors"><MoreHorizontal className="w-4 h-4" /></button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </AppShell>
  );
}
