'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Bot, Plus, Search, Play, Pause, Settings, MoreVertical, Cpu, MessageSquare, Sparkles, Code, Building2, Gamepad2 } from 'lucide-react';
import { AppShell } from '@/components/AppShell';

const agentTypes = [
  { id: 'chat', name: 'Chat Agent', icon: MessageSquare, color: 'bg-blue-500/10 text-blue-600' },
  { id: 'automation', name: 'Automation', icon: Sparkles, color: 'bg-purple-500/10 text-purple-600' },
  { id: 'creative', name: 'Creative', icon: Sparkles, color: 'bg-pink-500/10 text-pink-600' },
  { id: 'code', name: 'Code Agent', icon: Code, color: 'bg-orange-500/10 text-orange-600' },
  { id: 'business', name: 'Business', icon: Building2, color: 'bg-cyan-500/10 text-cyan-600' },
  { id: 'game', name: 'Game Dev', icon: Gamepad2, color: 'bg-green-500/10 text-green-600' },
];

const mockAgents = [
  { id: '1', name: 'Code Reviewer Pro', type: 'code', status: 'active', model: 'GPT-4', provider: 'OpenAI', lastActive: '2 min ago', tasks: 156 },
  { id: '2', name: 'Marketing Assistant', type: 'automation', status: 'busy', model: 'Claude 3', provider: 'Anthropic', lastActive: '5 min ago', tasks: 89 },
  { id: '3', name: 'Image Generator', type: 'creative', status: 'active', model: 'DALL-E 3', provider: 'OpenAI', lastActive: '12 min ago', tasks: 234 },
  { id: '4', name: 'Sales Bot', type: 'business', status: 'idle', model: 'Gemini Pro', provider: 'Google', lastActive: '1 hour ago', tasks: 45 },
  { id: '5', name: 'Game Designer', type: 'game', status: 'active', model: 'GPT-4', provider: 'OpenAI', lastActive: '30 min ago', tasks: 67 },
  { id: '6', name: 'Support Agent', type: 'chat', status: 'active', model: 'Kimi', provider: 'Moonshot', lastActive: 'Just now', tasks: 312 },
];

export default function AgentsPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState('all');

  const filteredAgents = mockAgents.filter((agent) => {
    const matchesSearch = agent.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = selectedType === 'all' || agent.type === selectedType;
    return matchesSearch && matchesType;
  });

  return (
    <AppShell>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">Agent Center</h1>
            <p className="text-muted-foreground mt-1">Manage and deploy your AI agents</p>
          </div>
          <button className="btn-primary flex items-center gap-2"><Plus className="w-4 h-4" /> Create Agent</button>
        </div>
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search agents..." className="w-full pl-9 pr-4 py-2 bg-background border border-input rounded-lg input-focus text-sm" />
          </div>
          <div className="flex gap-2 overflow-x-auto pb-2">
            <button onClick={() => setSelectedType('all')} className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${selectedType === 'all' ? 'bg-zanox-100 dark:bg-zanox-900/30 text-zanox-700 dark:text-zanox-300' : 'bg-accent text-muted-foreground hover:bg-accent/80'}`}>All</button>
            {agentTypes.map((type) => (
              <button key={type.id} onClick={() => setSelectedType(type.id)} className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${selectedType === type.id ? 'bg-zanox-100 dark:bg-zanox-900/30 text-zanox-700 dark:text-zanox-300' : 'bg-accent text-muted-foreground hover:bg-accent/80'}`}>{type.name}</button>
            ))}
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredAgents.map((agent, index) => (
            <motion.div key={agent.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.05 }}
              className="glass-panel p-5 card-hover group">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-zanox-500 to-accent-purple flex items-center justify-center text-white"><Bot className="w-5 h-5" /></div>
                  <div><h3 className="font-semibold">{agent.name}</h3><p className="text-xs text-muted-foreground">{agent.provider} / {agent.model}</p></div>
                </div>
                <div className={`w-2 h-2 rounded-full ${agent.status === 'active' ? 'bg-green-500 animate-pulse' : agent.status === 'busy' ? 'bg-yellow-500' : 'bg-gray-400'}`} />
              </div>
              <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                <span className="flex items-center gap-1"><Cpu className="w-4 h-4" /> {agent.tasks} tasks</span>
                <span>{agent.lastActive}</span>
              </div>
              <div className="flex gap-2">
                <button className="flex-1 py-2 bg-zanox-50 dark:bg-zanox-900/20 text-zanox-700 dark:text-zanox-300 rounded-lg text-sm font-medium hover:bg-zanox-100 dark:hover:bg-zanox-900/40 transition-colors">Configure</button>
                <button className="p-2 hover:bg-accent rounded-lg transition-colors"><Settings className="w-4 h-4" /></button>
                <button className="p-2 hover:bg-accent rounded-lg transition-colors"><MoreVertical className="w-4 h-4" /></button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </AppShell>
  );
}
