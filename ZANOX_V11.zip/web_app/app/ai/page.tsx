'use client';

import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Bot, User, Copy, Check, RotateCcw, Download, Settings, Image, Code } from 'lucide-react';
import { AppShell } from '@/components/AppShell';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  model?: string;
  provider?: string;
  timestamp: string;
}

const aiModels = [
  { id: 'gpt-4', name: 'GPT-4', provider: 'OpenAI', color: 'bg-green-500' },
  { id: 'claude-3', name: 'Claude 3', provider: 'Anthropic', color: 'bg-orange-500' },
  { id: 'gemini-pro', name: 'Gemini Pro', provider: 'Google', color: 'bg-blue-500' },
  { id: 'grok', name: 'Grok', provider: 'xAI', color: 'bg-yellow-500' },
  { id: 'kimi', name: 'Kimi', provider: 'Moonshot', color: 'bg-purple-500' },
  { id: 'perplexity', name: 'Perplexity', provider: 'Perplexity', color: 'bg-teal-500' },
  { id: 'qwen', name: 'Qwen', provider: 'Alibaba', color: 'bg-red-500' },
  { id: 'copilot', name: 'Copilot', provider: 'Microsoft', color: 'bg-indigo-500' },
  { id: 'manus', name: 'Manus', provider: 'Monica', color: 'bg-pink-500' },
];

const mockMessages: Message[] = [
  { id: '1', role: 'user', content: 'Analyze this code and suggest improvements for performance.', timestamp: '2024-01-15T10:30:00Z' },
  { id: '2', role: 'assistant', content: 'I have analyzed your code. Here are the key performance improvements:

1. **Memoization**: Use React.memo for components that render frequently with the same props
2. **Virtualization**: Implement windowing for large lists using react-window
3. **Lazy Loading**: Use dynamic imports for route-based code splitting
4. **State Optimization**: Move state closer to where it is used to prevent unnecessary re-renders', model: 'GPT-4', provider: 'OpenAI', timestamp: '2024-01-15T10:30:05Z' },
];

export default function AICenterPage() {
  const [messages, setMessages] = useState<Message[]>(mockMessages);
  const [input, setInput] = useState('');
  const [selectedModels, setSelectedModels] = useState(['gpt-4']);
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  useEffect(() => scrollToBottom(), [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;
    const userMessage: Message = { id: Date.now().toString(), role: 'user', content: input, timestamp: new Date().toISOString() };
    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);
    setTimeout(() => {
      const responses = selectedModels.map((modelId) => {
        const model = aiModels.find((m) => m.id === modelId);
        return { id: Date.now().toString() + Math.random(), role: 'assistant' as const, content: `Response from ${model?.name}: I have processed your request and generated a comprehensive analysis based on the latest available data. The results indicate strong performance metrics across all evaluated parameters.`, model: model?.name, provider: model?.provider, timestamp: new Date().toISOString() };
      });
      setMessages((prev) => [...prev, ...responses]);
      setIsLoading(false);
    }, 2000);
  };

  const copyMessage = (id: string, content: string) => {
    navigator.clipboard.writeText(content);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const toggleModel = (modelId: string) => {
    setSelectedModels((prev) => prev.includes(modelId) ? prev.filter((m) => m !== modelId) : [...prev, modelId]);
  };

  return (
    <AppShell>
      <div className="h-[calc(100vh-8rem)] flex flex-col">
        <div className="flex items-center justify-between mb-4">
          <div><h1 className="text-2xl font-bold">AI Center</h1><p className="text-muted-foreground mt-1">Multi-AI chat and reasoning</p></div>
          <button className="btn-secondary flex items-center gap-2"><Settings className="w-4 h-4" /> Settings</button>
        </div>
        <div className="flex gap-2 overflow-x-auto pb-3 mb-4">
          {aiModels.map((model) => (
            <button key={model.id} onClick={() => toggleModel(model.id)}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-all ${selectedModels.includes(model.id) ? 'bg-zanox-100 dark:bg-zanox-900/30 text-zanox-700 dark:text-zanox-300 border-2 border-zanox-500' : 'bg-accent text-muted-foreground border-2 border-transparent hover:bg-accent/80'}`}>
              <div className={`w-2 h-2 rounded-full ${model.color}`} />{model.name}
            </button>
          ))}
        </div>
        <div className="flex-1 overflow-y-auto space-y-4 mb-4 pr-2">
          <AnimatePresence>
            {messages.map((message) => (
              <motion.div key={message.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
                className={`flex gap-3 ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                {message.role === 'assistant' && (
                  <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-zanox-500 to-accent-purple flex items-center justify-center flex-shrink-0"><Bot className="w-4 h-4 text-white" /></div>
                )}
                <div className={`max-w-[80%] ${message.role === 'user' ? 'bg-zanox-600 text-white' : 'glass-panel'} rounded-2xl px-4 py-3`}>
                  {message.model && <div className="flex items-center gap-2 mb-2"><span className="text-xs font-medium opacity-70">{message.model}</span><span className="text-xs opacity-50">{message.provider}</span></div>}
                  <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                  {message.role === 'assistant' && (
                    <div className="flex items-center gap-2 mt-3 pt-2 border-t border-border/50">
                      <button onClick={() => copyMessage(message.id, message.content)} className="p-1 hover:bg-accent rounded transition-colors">{copiedId === message.id ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}</button>
                      <button className="p-1 hover:bg-accent rounded transition-colors"><RotateCcw className="w-4 h-4" /></button>
                      <button className="p-1 hover:bg-accent rounded transition-colors"><Download className="w-4 h-4" /></button>
                    </div>
                  )}
                </div>
                {message.role === 'user' && <div className="w-8 h-8 rounded-lg bg-zanox-700 flex items-center justify-center flex-shrink-0"><User className="w-4 h-4 text-white" /></div>}
              </motion.div>
            ))}
          </AnimatePresence>
          {isLoading && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex gap-3">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-zanox-500 to-accent-purple flex items-center justify-center"><Bot className="w-4 h-4 text-white animate-bounce" /></div>
              <div className="glass-panel rounded-2xl px-4 py-3">
                <div className="flex gap-1">
                  <div className="w-2 h-2 bg-zanox-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                  <div className="w-2 h-2 bg-zanox-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                  <div className="w-2 h-2 bg-zanox-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
              </div>
            </motion.div>
          )}
          <div ref={messagesEndRef} />
        </div>
        <div className="glass-panel p-3">
          <div className="flex items-end gap-2">
            <div className="flex-1">
              <textarea value={input} onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
                placeholder="Message multiple AI models..." className="w-full bg-transparent resize-none outline-none text-sm min-h-[44px] max-h-32 py-2.5 px-3" rows={1} />
            </div>
            <div className="flex items-center gap-2">
              <button className="p-2 hover:bg-accent rounded-lg transition-colors"><Image className="w-5 h-5 text-muted-foreground" /></button>
              <button className="p-2 hover:bg-accent rounded-lg transition-colors"><Code className="w-5 h-5 text-muted-foreground" /></button>
              <button onClick={handleSend} disabled={!input.trim() || isLoading} className="p-2.5 bg-zanox-600 hover:bg-zanox-700 text-white rounded-lg transition-colors disabled:opacity-50"><Send className="w-5 h-5" /></button>
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
