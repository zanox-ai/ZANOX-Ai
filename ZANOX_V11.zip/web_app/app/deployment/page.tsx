'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Rocket, Plus, Play, Pause, RotateCcw, Trash2, Globe, Server, Cloud, Container, CheckCircle2, XCircle, Clock, Activity, GitBranch, ArrowUpRight } from 'lucide-react';
import { AppShell } from '@/components/AppShell';

const deployments = [
  { id: '1', name: 'Web App Production', environment: 'production', status: 'running', version: 'v2.1.4', uptime: '45d 12h', health: 98, url: 'https://app.zanox.io', provider: 'AWS', lastDeploy: '2 hours ago' },
  { id: '2', name: 'API Gateway', environment: 'production', status: 'running', version: 'v1.8.2', uptime: '60d 4h', health: 99, url: 'https://api.zanox.io', provider: 'AWS', lastDeploy: '1 day ago' },
  { id: '3', name: 'Web App Staging', environment: 'staging', status: 'running', version: 'v2.2.0-beta', uptime: '5d 8h', health: 95, url: 'https://staging.zanox.io', provider: 'GCP', lastDeploy: '3 hours ago' },
  { id: '4', name: 'AI Worker Nodes', environment: 'production', status: 'running', version: 'v1.5.1', uptime: '30d 6h', health: 97, url: 'internal', provider: 'AWS', lastDeploy: '1 week ago' },
  { id: '5', name: 'Database Cluster', environment: 'production', status: 'running', version: 'PostgreSQL 16', uptime: '90d 2h', health: 100, url: 'internal', provider: 'AWS RDS', lastDeploy: '2 weeks ago' },
  { id: '6', name: 'Redis Cache', environment: 'production', status: 'running', version: 'Redis 7', uptime: '90d 2h', health: 100, url: 'internal', provider: 'AWS ElastiCache', lastDeploy: '2 weeks ago' },
];

const deployHistory = [
  { id: '1', deployment: 'Web App Production', version: 'v2.1.4', status: 'success', time: '2 hours ago', duration: '4m 32s', user: 'Alex Chen' },
  { id: '2', deployment: 'API Gateway', version: 'v1.8.2', status: 'success', time: '1 day ago', duration: '2m 15s', user: 'Sarah Miller' },
  { id: '3', deployment: 'Web App Staging', version: 'v2.2.0-beta', status: 'success', time: '3 hours ago', duration: '5m 48s', user: 'James Wilson' },
  { id: '4', deployment: 'AI Worker Nodes', version: 'v1.5.1', status: 'failed', time: '1 week ago', duration: '1m 12s', user: 'Alex Chen' },
  { id: '5', deployment: 'Web App Production', version: 'v2.1.3', status: 'success', time: '2 weeks ago', duration: '3m 45s', user: 'Sarah Miller' },
];

export default function DeploymentPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const filteredDeployments = deployments.filter((d) => d.name.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <AppShell>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div><h1 className="text-2xl font-bold">Deployment Center</h1><p className="text-muted-foreground mt-1">Manage deployments and infrastructure</p></div>
          <button className="btn-primary flex items-center gap-2"><Rocket className="w-4 h-4" /> New Deployment</button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="glass-panel p-4 text-center"><p className="text-3xl font-bold text-green-600">{deployments.filter((d) => d.status === 'running').length}</p><p className="text-sm text-muted-foreground">Running</p></div>
          <div className="glass-panel p-4 text-center"><p className="text-3xl font-bold">{deployments.length}</p><p className="text-sm text-muted-foreground">Total Services</p></div>
          <div className="glass-panel p-4 text-center"><p className="text-3xl font-bold text-blue-600">99.98%</p><p className="text-sm text-muted-foreground">Uptime</p></div>
          <div className="glass-panel p-4 text-center"><p className="text-3xl font-bold text-purple-600">24</p><p className="text-sm text-muted-foreground">Deploys Today</p></div>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Search deployments..." className="w-full pl-9 pr-4 py-2 bg-background border border-input rounded-lg input-focus text-sm" />
        </div>
        <div className="space-y-3">
          {filteredDeployments.map((deployment, index) => (
            <motion.div key={deployment.id} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: index * 0.05 }}
              className="glass-panel p-4 flex items-center gap-4 group hover:border-zanox-300 dark:hover:border-zanox-700 transition-colors">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-zanox-500 to-accent-purple flex items-center justify-center text-white"><Server className="w-5 h-5" /></div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <h3 className="font-medium">{deployment.name}</h3>
                  <span className={`px-2 py-0.5 text-xs rounded-full ${deployment.environment === 'production' ? 'bg-green-500/10 text-green-600' : 'bg-blue-500/10 text-blue-600'}`}>{deployment.environment}</span>
                  <span className={`px-2 py-0.5 text-xs rounded-full ${deployment.status === 'running' ? 'bg-green-500/10 text-green-600' : 'bg-red-500/10 text-red-600'}`}>{deployment.status}</span>
                </div>
                <p className="text-sm text-muted-foreground">{deployment.version} | {deployment.provider} | {deployment.url}</p>
              </div>
              <div className="hidden sm:flex items-center gap-4 text-sm text-muted-foreground">
                <span className="flex items-center gap-1"><Activity className="w-4 h-4" /> {deployment.health}%</span>
                <span className="flex items-center gap-1"><Clock className="w-4 h-4" /> {deployment.uptime}</span>
                <span>{deployment.lastDeploy}</span>
              </div>
              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button className="p-2 hover:bg-accent rounded-lg transition-colors"><RotateCcw className="w-4 h-4" /></button>
                <button className="p-2 hover:bg-accent rounded-lg transition-colors"><Trash2 className="w-4 h-4" /></button>
              </div>
            </motion.div>
          ))}
        </div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="glass-panel p-5">
          <h3 className="font-semibold mb-4">Recent Deployments</h3>
          <div className="space-y-3">
            {deployHistory.map((deploy) => (
              <div key={deploy.id} className="flex items-center gap-4 p-3 bg-accent/50 rounded-lg">
                <div className={`p-2 rounded-lg ${deploy.status === 'success' ? 'bg-green-500/10 text-green-600' : 'bg-red-500/10 text-red-600'}`}>
                  {deploy.status === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm">{deploy.deployment} <span className="text-muted-foreground">{deploy.version}</span></p>
                  <p className="text-xs text-muted-foreground">{deploy.user} | Duration: {deploy.duration}</p>
                </div>
                <span className="text-xs text-muted-foreground">{deploy.time}</span>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </AppShell>
  );
}
