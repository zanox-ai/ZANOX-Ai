'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { BarChart3, TrendingUp, TrendingDown, Users, DollarSign, Activity, ArrowUpRight, ArrowDownRight, Calendar, Download, Filter } from 'lucide-react';
import { AppShell } from '@/components/AppShell';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell, AreaChart, Area } from 'recharts';

const revenueData = [
  { name: 'Jan', revenue: 4000, costs: 2400, profit: 1600 },
  { name: 'Feb', revenue: 3000, costs: 1398, profit: 1602 },
  { name: 'Mar', revenue: 2000, costs: 9800, profit: -7800 },
  { name: 'Apr', revenue: 2780, costs: 3908, profit: -1128 },
  { name: 'May', revenue: 1890, costs: 4800, profit: -2910 },
  { name: 'Jun', revenue: 2390, costs: 3800, profit: -1410 },
  { name: 'Jul', revenue: 3490, costs: 4300, profit: -810 },
  { name: 'Aug', revenue: 4200, costs: 2100, profit: 2100 },
  { name: 'Sep', revenue: 5100, costs: 2300, profit: 2800 },
  { name: 'Oct', revenue: 6800, costs: 3400, profit: 3400 },
  { name: 'Nov', revenue: 7400, costs: 3900, profit: 3500 },
  { name: 'Dec', revenue: 8900, costs: 4100, profit: 4800 },
];

const agentUsageData = [
  { name: 'GPT-4', value: 35, color: '#10b981' },
  { name: 'Claude 3', value: 25, color: '#f97316' },
  { name: 'Gemini', value: 20, color: '#3b82f6' },
  { name: 'Kimi', value: 12, color: '#8b5cf6' },
  { name: 'Others', value: 8, color: '#6b7280' },
];

const workflowData = [
  { name: 'Mon', completed: 45, failed: 2 },
  { name: 'Tue', completed: 52, failed: 1 },
  { name: 'Wed', completed: 38, failed: 3 },
  { name: 'Thu', completed: 65, failed: 0 },
  { name: 'Fri', completed: 48, failed: 2 },
  { name: 'Sat', completed: 32, failed: 1 },
  { name: 'Sun', completed: 28, failed: 0 },
];

const kpiCards = [
  { title: 'Total Revenue', value: '$124,500', change: '+12.5%', trend: 'up', icon: DollarSign },
  { title: 'Active Users', value: '2,450', change: '+8.3%', trend: 'up', icon: Users },
  { title: 'AI Requests', value: '1.2M', change: '+45.2%', trend: 'up', icon: Activity },
  { title: 'Avg Response', value: '1.2s', change: '-15.3%', trend: 'down', icon: Activity },
];

export default function AnalyticsPage() {
  const [timeRange, setTimeRange] = useState('30d');

  return (
    <AppShell>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div><h1 className="text-2xl font-bold">Analytics Center</h1><p className="text-muted-foreground mt-1">Comprehensive insights and reporting</p></div>
          <div className="flex gap-2">
            {['7d', '30d', '90d', '1y'].map((range) => (
              <button key={range} onClick={() => setTimeRange(range)}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${timeRange === range ? 'bg-zanox-100 dark:bg-zanox-900/30 text-zanox-700 dark:text-zanox-300' : 'bg-accent text-muted-foreground hover:bg-accent/80'}`}>
                {range === '7d' ? '7 Days' : range === '30d' ? '30 Days' : range === '90d' ? '90 Days' : '1 Year'}
              </button>
            ))}
            <button className="btn-secondary flex items-center gap-2"><Download className="w-4 h-4" /> Export</button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {kpiCards.map((kpi, index) => (
            <motion.div key={kpi.title} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.1 }}
              className="glass-panel p-5 card-hover">
              <div className="flex items-start justify-between">
                <div className="p-2.5 rounded-lg bg-gradient-to-br from-zanox-500 to-accent-purple text-white"><kpi.icon className="w-5 h-5" /></div>
                <div className={`flex items-center gap-1 text-sm ${kpi.trend === 'up' ? 'text-green-600' : 'text-red-600'}`}>
                  {kpi.trend === 'up' ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}{kpi.change}
                </div>
              </div>
              <div className="mt-3"><p className="text-2xl font-bold">{kpi.value}</p><p className="text-sm text-muted-foreground">{kpi.title}</p></div>
            </motion.div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="glass-panel p-5">
            <h3 className="font-semibold mb-4">Revenue Overview</h3>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={revenueData}>
                <defs><linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#0ea5e9" stopOpacity={0.3}/><stop offset="95%" stopColor="#0ea5e9" stopOpacity={0}/></linearGradient></defs>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="name" stroke="var(--muted-foreground)" fontSize={12} />
                <YAxis stroke="var(--muted-foreground)" fontSize={12} />
                <Tooltip contentStyle={{ backgroundColor: 'var(--card)', border: '1px solid var(--border)', borderRadius: '8px' }} />
                <Area type="monotone" dataKey="revenue" stroke="#0ea5e9" fillOpacity={1} fill="url(#colorRevenue)" />
                <Area type="monotone" dataKey="profit" stroke="#10b981" fillOpacity={0.1} fill="#10b981" />
              </AreaChart>
            </ResponsiveContainer>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }} className="glass-panel p-5">
            <h3 className="font-semibold mb-4">AI Model Usage</h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie data={agentUsageData} cx="50%" cy="50%" innerRadius={60} outerRadius={100} paddingAngle={5} dataKey="value">
                  {agentUsageData.map((entry, index) => (<Cell key={`cell-${index}`} fill={entry.color} />))}
                </Pie>
                <Tooltip contentStyle={{ backgroundColor: 'var(--card)', border: '1px solid var(--border)', borderRadius: '8px' }} />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex justify-center gap-4 mt-4">
              {agentUsageData.map((item) => (
                <div key={item.name} className="flex items-center gap-2"><div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} /><span className="text-sm">{item.name} ({item.value}%)</span></div>
              ))}
            </div>
          </motion.div>
        </div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }} className="glass-panel p-5">
          <h3 className="font-semibold mb-4">Workflow Execution</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={workflowData}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="name" stroke="var(--muted-foreground)" fontSize={12} />
              <YAxis stroke="var(--muted-foreground)" fontSize={12} />
              <Tooltip contentStyle={{ backgroundColor: 'var(--card)', border: '1px solid var(--border)', borderRadius: '8px' }} />
              <Bar dataKey="completed" fill="#10b981" radius={[4, 4, 0, 0]} />
              <Bar dataKey="failed" fill="#ef4444" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </motion.div>
      </div>
    </AppShell>
  );
}
