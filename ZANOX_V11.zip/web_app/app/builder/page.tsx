'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Hammer, Plus, Search, Play, ExternalLink, Code, Layers, Smartphone, Globe, Monitor, Star, GitFork, Eye, Zap, Flame, Layout, Box, Type, Image as ImageIcon, Database, Cloud } from 'lucide-react';
import { AppShell } from '@/components/AppShell';

const builderTools = [
  { name: 'Replit', icon: Code, color: 'bg-indigo-500', category: 'Code' },
  { name: 'Firebase Studio', icon: Flame, color: 'bg-orange-500', category: 'Backend' },
  { name: 'FlutterFlow', icon: Smartphone, color: 'bg-blue-500', category: 'Mobile' },
  { name: 'Bolt', icon: Zap, color: 'bg-yellow-500', category: 'AI Builder' },
  { name: 'Lovable', icon: Heart, color: 'bg-pink-500', category: 'AI Builder' },
  { name: 'v0', icon: Type, color: 'bg-black', category: 'UI' },
  { name: 'Softgen', icon: Box, color: 'bg-purple-500', category: 'Fullstack' },
  { name: 'Draftbit', icon: Layout, color: 'bg-cyan-500', category: 'Mobile' },
  { name: 'Glide', icon: ImageIcon, color: 'bg-green-500', category: 'No-Code' },
  { name: 'Framer', icon: Monitor, color: 'bg-blue-600', category: 'Design' },
  { name: 'Adalo', icon: Smartphone, color: 'bg-indigo-600', category: 'Mobile' },
  { name: 'Bubble', icon: Cloud, color: 'bg-blue-400', category: 'No-Code' },
  { name: 'Wix AI', icon: Globe, color: 'bg-yellow-600', category: 'Website' },
  { name: 'Appsmith', icon: Database, color: 'bg-orange-600', category: 'Internal' },
];

const mockProjects = [
  { id: '1', name: 'E-commerce Dashboard', type: 'web', status: 'live', framework: 'Next.js', lastDeploy: '2 min ago', stars: 45, views: 1200 },
  { id: '2', name: 'Mobile App Prototype', type: 'mobile', status: 'building', framework: 'Flutter', lastDeploy: '15 min ago', stars: 23, views: 890 },
  { id: '3', name: 'Internal CRM Tool', type: 'web', status: 'live', framework: 'React', lastDeploy: '1 hour ago', stars: 67, views: 3400 },
  { id: '4', name: 'Landing Page Builder', type: 'web', status: 'draft', framework: 'Vue', lastDeploy: '3 hours ago', stars: 12, views: 450 },
  { id: '5', name: 'AI Chat Interface', type: 'web', status: 'live', framework: 'Next.js', lastDeploy: '30 min ago', stars: 89, views: 5600 },
];

export default function BuilderPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const filteredTools = builderTools.filter((tool) => {
    const matchesSearch = tool.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || tool.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <AppShell>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div><h1 className="text-2xl font-bold">Builder Center</h1><p className="text-muted-foreground mt-1">No-code and AI-powered application builder</p></div>
          <button className="btn-primary flex items-center gap-2"><Plus className="w-4 h-4" /> New Project</button>
        </div>
        <div className="glass-panel p-5">
          <h3 className="font-semibold mb-4">Connected Builder Tools</h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
            {builderTools.map((tool) => (
              <div key={tool.name} className="flex flex-col items-center gap-2 p-3 rounded-lg bg-accent/50 hover:bg-accent transition-colors cursor-pointer">
                <div className={`w-10 h-10 rounded-lg ${tool.color} flex items-center justify-center text-white`}><tool.icon className="w-5 h-5" /></div>
                <span className="text-xs font-medium text-center">{tool.name}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Search projects..." className="w-full pl-9 pr-4 py-2 bg-background border border-input rounded-lg input-focus text-sm" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {mockProjects.map((project, index) => (
            <motion.div key={project.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.05 }}
              className="glass-panel p-5 card-hover group">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-zanox-500 to-accent-purple flex items-center justify-center text-white"><Hammer className="w-5 h-5" /></div>
                  <div><h3 className="font-semibold">{project.name}</h3><p className="text-xs text-muted-foreground">{project.framework}</p></div>
                </div>
                <span className={`px-2 py-0.5 text-xs rounded-full ${project.status === 'live' ? 'bg-green-500/10 text-green-600' : project.status === 'building' ? 'bg-yellow-500/10 text-yellow-600' : 'bg-gray-500/10 text-gray-600'}`}>{project.status}</span>
              </div>
              <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                <span className="flex items-center gap-1"><Star className="w-4 h-4" /> {project.stars}</span>
                <span className="flex items-center gap-1"><Eye className="w-4 h-4" /> {project.views}</span>
                <span>{project.lastDeploy}</span>
              </div>
              <div className="flex gap-2">
                <button className="flex-1 py-2 bg-zanox-50 dark:bg-zanox-900/20 text-zanox-700 dark:text-zanox-300 rounded-lg text-sm font-medium hover:bg-zanox-100 dark:hover:bg-zanox-900/40 transition-colors flex items-center justify-center gap-1"><Play className="w-4 h-4" /> Preview</button>
                <button className="p-2 hover:bg-accent rounded-lg transition-colors"><ExternalLink className="w-4 h-4" /></button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </AppShell>
  );
}
