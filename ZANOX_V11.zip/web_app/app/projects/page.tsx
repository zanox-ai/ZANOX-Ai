'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { FolderKanban, Plus, Search, Filter, Grid, List, Star, GitFork, Clock, Users, MoreHorizontal, Bot, Workflow, Palette, Gamepad2, Building2, Hammer } from 'lucide-react';
import { AppShell } from '@/components/AppShell';

const projectTypes = [
  { id: 'all', name: 'All Projects', icon: FolderKanban },
  { id: 'ai', name: 'AI', icon: Bot },
  { id: 'automation', name: 'Automation', icon: Workflow },
  { id: 'builder', name: 'Builder', icon: Hammer },
  { id: 'creative', name: 'Creative', icon: Palette },
  { id: 'game', name: 'Game', icon: Gamepad2 },
  { id: 'business', name: 'Business', icon: Building2 },
];

const mockProjects = [
  { id: '1', name: 'AI Customer Support', type: 'ai', status: 'active', members: 4, tasks: 45, completed: 38, lastUpdated: '2 hours ago', starred: true },
  { id: '2', name: 'Marketing Automation', type: 'automation', status: 'active', members: 3, tasks: 23, completed: 19, lastUpdated: '1 day ago', starred: true },
  { id: '3', name: 'E-commerce App', type: 'builder', status: 'active', members: 6, tasks: 67, completed: 45, lastUpdated: '3 hours ago', starred: false },
  { id: '4', name: 'Brand Campaign', type: 'creative', status: 'active', members: 5, tasks: 34, completed: 28, lastUpdated: '5 hours ago', starred: true },
  { id: '5', name: 'Mobile RPG', type: 'game', status: 'development', members: 8, tasks: 124, completed: 56, lastUpdated: '1 day ago', starred: false },
  { id: '6', name: 'CRM Integration', type: 'business', status: 'active', members: 4, tasks: 29, completed: 24, lastUpdated: '12 hours ago', starred: false },
  { id: '7', name: 'Data Pipeline', type: 'automation', status: 'archived', members: 2, tasks: 18, completed: 18, lastUpdated: '2 weeks ago', starred: false },
  { id: '8', name: 'AI Image Generator', type: 'creative', status: 'active', members: 3, tasks: 41, completed: 35, lastUpdated: '4 hours ago', starred: true },
];

export default function ProjectsPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const filteredProjects = mockProjects.filter((project) => {
    const matchesSearch = project.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = selectedType === 'all' || project.type === selectedType;
    return matchesSearch && matchesType;
  });

  return (
    <AppShell>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div><h1 className="text-2xl font-bold">Project Manager</h1><p className="text-muted-foreground mt-1">Manage all your ZANOX projects</p></div>
          <button className="btn-primary flex items-center gap-2"><Plus className="w-4 h-4" /> New Project</button>
        </div>
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Search projects..." className="w-full pl-9 pr-4 py-2 bg-background border border-input rounded-lg input-focus text-sm" />
          </div>
          <div className="flex gap-2">
            <button onClick={() => setViewMode('grid')} className={`p-2 rounded-lg transition-colors ${viewMode === 'grid' ? 'bg-zanox-100 dark:bg-zanox-900/30 text-zanox-700' : 'hover:bg-accent'}`}><Grid className="w-5 h-5" /></button>
            <button onClick={() => setViewMode('list')} className={`p-2 rounded-lg transition-colors ${viewMode === 'list' ? 'bg-zanox-100 dark:bg-zanox-900/30 text-zanox-700' : 'hover:bg-accent'}`}><List className="w-5 h-5" /></button>
          </div>
        </div>
        <div className="flex gap-2 overflow-x-auto pb-2">
          {projectTypes.map((type) => (
            <button key={type.id} onClick={() => setSelectedType(type.id)}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${selectedType === type.id ? 'bg-zanox-100 dark:bg-zanox-900/30 text-zanox-700 dark:text-zanox-300' : 'bg-accent text-muted-foreground hover:bg-accent/80'}`}>
              <type.icon className="w-4 h-4" />{type.name}
            </button>
          ))}
        </div>
        <div className={viewMode === 'grid' ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4' : 'space-y-3'}>
          {filteredProjects.map((project, index) => (
            <motion.div key={project.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.05 }}
              className={`glass-panel p-5 card-hover group ${viewMode === 'list' ? 'flex items-center gap-4' : ''}`}>
              <div className={`flex items-center gap-3 ${viewMode === 'list' ? 'flex-1' : ''}`}>
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-zanox-500 to-accent-purple flex items-center justify-center text-white"><FolderKanban className="w-5 h-5" /></div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold">{project.name}</h3>
                    {project.starred && <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />}
                  </div>
                  <p className="text-xs text-muted-foreground">{project.type} | {project.status}</p>
                </div>
              </div>
              <div className={`flex items-center gap-4 text-sm text-muted-foreground ${viewMode === 'list' ? '' : 'mt-4'}`}>
                <span className="flex items-center gap-1"><Users className="w-4 h-4" /> {project.members}</span>
                <span className="flex items-center gap-1"><CheckCircle2 className="w-4 h-4" /> {project.completed}/{project.tasks}</span>
                <span className="flex items-center gap-1"><Clock className="w-4 h-4" /> {project.lastUpdated}</span>
              </div>
              <div className={`flex gap-2 ${viewMode === 'list' ? '' : 'mt-4'}`}>
                <div className="flex-1 h-2 bg-accent rounded-full overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-zanox-500 to-accent-purple rounded-full transition-all" style={{ width: `${(project.completed / project.tasks) * 100}%` }} />
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </AppShell>
  );
}
