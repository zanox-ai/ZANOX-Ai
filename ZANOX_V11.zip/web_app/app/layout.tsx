import type { Metadata, Viewport } from 'next';
import { Inter, JetBrains_Mono } from 'next/font/google';
import { Providers } from './providers';
import './globals.css';

const inter = Inter({ subsets: ['latin'], variable: '--font-inter', display: 'swap' });
const jetbrainsMono = JetBrains_Mono({ subsets: ['latin'], variable: '--font-mono', display: 'swap' });

export const metadata: Metadata = {
  title: 'ZANOX - Experience Layer',
  description: 'Universal AI Operating System - End-to-End Platform',
  keywords: ['AI', 'Automation', 'Workflow', 'Agent', 'ZANOX'],
  authors: [{ name: 'ZANOX Team' }],
  creator: 'ZANOX',
  publisher: 'ZANOX',
  robots: 'index, follow',
  openGraph: { type: 'website', locale: 'en_US', url: 'https://zanox.io', siteName: 'ZANOX', title: 'ZANOX Experience Layer', description: 'Universal AI Operating System', images: [{ url: '/og-image.png', width: 1200, height: 630 }] },
  twitter: { card: 'summary_large_image', title: 'ZANOX Experience Layer', description: 'Universal AI Operating System', images: ['/og-image.png'] },
  manifest: '/manifest.json',
  icons: { icon: '/favicon.ico', shortcut: '/favicon-16x16.png', apple: '/apple-touch-icon.png' },
};

export const viewport: Viewport = {
  themeColor: [{ media: '(prefers-color-scheme: light)', color: '#ffffff' }, { media: '(prefers-color-scheme: dark)', color: '#0a0a0f' }],
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning className={`${inter.variable} ${jetbrainsMono.variable}`}>
      <body className="font-sans antialiased min-h-screen bg-background text-foreground">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
