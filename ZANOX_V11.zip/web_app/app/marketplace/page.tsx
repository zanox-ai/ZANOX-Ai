'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { ShoppingBag, Search, Star, Download, Filter, Grid, List, TrendingUp, Clock, Tag, ChevronRight, Bot, Workflow, Palette, Hammer, Gamepad2, Building2 } from 'lucide-react';
import { AppShell } from '@/components/AppShell';

const categories = [
  { id: 'all', name: 'All', icon: ShoppingBag },
  { id: 'agents', name: 'Agents', icon: Bot },
  { id: 'workflows', name: 'Workflows', icon: Workflow },
  { id: 'templates', name: 'Templates', icon: Hammer },
  { id: 'creative', name: 'Creative', icon: Palette },
  { id: 'games', name: 'Games', icon: Gamepad2 },
  { id: 'business', name: 'Business', icon: Building2 },
];

const marketplaceItems = [
  { id: '1', name: 'Customer Support Bot', category: 'agents', author: 'ZANOX Team', rating: 4.9, downloads: 12400, price: 'Free', tags: ['AI', 'Support'], icon: Bot },
  { id: '2', name: 'Lead Nurturing Flow', category: 'workflows', author: 'Marketing Pro', rating: 4.7, downloads: 8900, price: 'Free', tags: ['Automation', 'CRM'], icon: Workflow },
  { id: '3', name: 'E-commerce Dashboard', category: 'templates', author: 'BuilderX', rating: 4.8, downloads: 5600, price: '$29', tags: ['Web', 'Dashboard'], icon: Hammer },
  { id: '4', name: 'AI Image Generator', category: 'creative', author: 'CreativeAI', rating: 4.9, downloads: 23400, price: 'Free', tags: ['Image', 'AI'], icon: Palette },
  { id: '5', name: 'Platformer Starter', category: 'games', author: 'GameDev', rating: 4.6, downloads: 3400, price: '$49', tags: ['Unity', '2D'], icon: Gamepad2 },
  { id: '6', name: 'Sales Pipeline CRM', category: 'business', author: 'BizTools', rating: 4.8, downloads: 6700, price: '$19', tags: ['CRM', 'Sales'], icon: Building2 },
  { id: '7', name: 'Code Review Agent', category: 'agents', author: 'DevTools', rating: 4.7, downloads: 4500, price: 'Free', tags: ['Code', 'AI'], icon: Bot },
  { id: '8', name: 'Social Media Automation', category: 'workflows', author: 'SocialPro', rating: 4.5, downloads: 12300, price: '$9', tags: ['Social', 'Marketing'], icon: Workflow },
];

export default function MarketplacePage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const filteredItems = marketplaceItems.filter((item) => {
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <AppShell>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div><h1 className="text-2xl font-bold">Marketplace</h1><p className="text-muted-foreground mt-1">Discover and install agents, workflows, and templates</p></div>
          <button className="btn-primary flex items-center gap-2"><Tag className="w-4 h-4" /> Publish</button>
        </div>
        <div className="flex gap-2 overflow-x-auto pb-2">
          {categories.map((cat) => (
            <button key={cat.id} onClick={() => setSelectedCategory(cat.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${selectedCategory === cat.id ? 'bg-zanox-100 dark:bg-zanox-900/30 text-zanox-700 dark:text-zanox-300' : 'bg-accent text-muted-foreground hover:bg-accent/80'}`}>
              <cat.icon className="w-4 h-4" />{cat.name}
            </button>
          ))}
        </div>
        <div className="flex gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Search marketplace..." className="w-full pl-9 pr-4 py-2 bg-background border border-input rounded-lg input-focus text-sm" />
          </div>
          <div className="flex gap-2">
            <button onClick={() => setViewMode('grid')} className={`p-2 rounded-lg transition-colors ${viewMode === 'grid' ? 'bg-zanox-100 dark:bg-zanox-900/30 text-zanox-700' : 'hover:bg-accent'}`}><Grid className="w-5 h-5" /></button>
            <button onClick={() => setViewMode('list')} className={`p-2 rounded-lg transition-colors ${viewMode === 'list' ? 'bg-zanox-100 dark:bg-zanox-900/30 text-zanox-700' : 'hover:bg-accent'}`}><List className="w-5 h-5" /></button>
          </div>
        </div>
        <div className={viewMode === 'grid' ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4' : 'space-y-3'}>
          {filteredItems.map((item, index) => (
            <motion.div key={item.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.05 }}
              className={`glass-panel p-5 card-hover group ${viewMode === 'list' ? 'flex items-center gap-4' : ''}`}>
              <div className={`flex items-center gap-3 ${viewMode === 'list' ? 'flex-1' : ''}`}>
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-zanox-500 to-accent-purple flex items-center justify-center text-white"><item.icon className="w-6 h-6" /></div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold">{item.name}</h3>
                  <p className="text-xs text-muted-foreground">{item.author}</p>
                  <div className="flex items-center gap-2 mt-1">
                    {item.tags.map((tag) => (<span key={tag} className="px-1.5 py-0.5 bg-accent rounded text-xs">{tag}</span>))}
                  </div>
                </div>
              </div>
              <div className={`flex items-center gap-4 ${viewMode === 'list' ? '' : 'mt-4'}`}>
                <div className="flex items-center gap-1"><Star className="w-4 h-4 text-yellow-500 fill-yellow-500" /><span className="text-sm font-medium">{item.rating}</span></div>
                <div className="flex items-center gap-1"><Download className="w-4 h-4 text-muted-foreground" /><span className="text-sm text-muted-foreground">{item.downloads.toLocaleString()}</span></div>
                <span className={`px-2 py-1 rounded-lg text-xs font-medium ${item.price === 'Free' ? 'bg-green-500/10 text-green-600' : 'bg-zanox-100 dark:bg-zanox-900/30 text-zanox-700'}`}>{item.price}</span>
                <button className="p-2 bg-zanox-600 hover:bg-zanox-700 text-white rounded-lg transition-colors opacity-0 group-hover:opacity-100"><Download className="w-4 h-4" /></button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </AppShell>
  );
}
