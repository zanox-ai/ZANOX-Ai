'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Shield, Lock, Key, Eye, EyeOff, Fingerprint, Smartphone, Globe, AlertTriangle, CheckCircle2, XCircle, RefreshCw, Download, History } from 'lucide-react';
import { AppShell } from '@/components/AppShell';

const securityStats = [
  { title: 'Security Score', value: '94/100', status: 'good', icon: Shield },
  { title: 'Active Sessions', value: '3', status: 'good', icon: Globe },
  { title: 'Failed Logins', value: '2', status: 'warning', icon: AlertTriangle },
  { title: '2FA Enabled', value: 'Enabled', status: 'good', icon: Fingerprint },
];

const auditLog = [
  { id: '1', action: 'Login successful', user: 'Alex Chen', ip: '192.168.1.1', location: 'San Francisco, US', time: '2 min ago', status: 'success' },
  { id: '2', action: 'API key generated', user: 'Sarah Miller', ip: '192.168.1.2', location: 'New York, US', time: '15 min ago', status: 'success' },
  { id: '3', action: 'Failed login attempt', user: 'Unknown', ip: '10.0.0.1', location: 'Moscow, RU', time: '1 hour ago', status: 'failed' },
  { id: '4', action: 'Password changed', user: 'James Wilson', ip: '192.168.1.3', location: 'London, UK', time: '3 hours ago', status: 'success' },
  { id: '5', action: 'Permission updated', user: 'Alex Chen', ip: '192.168.1.1', location: 'San Francisco, US', time: '5 hours ago', status: 'success' },
];

export default function SecurityPage() {
  const [showKeys, setShowKeys] = useState(false);

  return (
    <AppShell>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div><h1 className="text-2xl font-bold">Security Center</h1><p className="text-muted-foreground mt-1">Security settings and audit logs</p></div>
          <button className="btn-secondary flex items-center gap-2"><Download className="w-4 h-4" /> Export Logs</button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {securityStats.map((stat, index) => (
            <motion.div key={stat.title} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.1 }}
              className="glass-panel p-5 card-hover">
              <div className="flex items-start justify-between">
                <div className={`p-2.5 rounded-lg ${stat.status === 'good' ? 'bg-green-500/10 text-green-600' : 'bg-yellow-500/10 text-yellow-600'}`}><stat.icon className="w-5 h-5" /></div>
              </div>
              <div className="mt-3"><p className="text-2xl font-bold">{stat.value}</p><p className="text-sm text-muted-foreground">{stat.title}</p></div>
            </motion.div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="glass-panel p-5">
            <h3 className="font-semibold mb-4">API Keys</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-accent/50 rounded-lg">
                <div className="flex items-center gap-3"><Key className="w-5 h-5 text-zanox-500" /><div><p className="font-medium text-sm">Production API Key</p><p className="text-xs text-muted-foreground">Created 30 days ago</p></div></div>
                <div className="flex items-center gap-2">
                  <code className="px-2 py-1 bg-background rounded text-xs font-mono">{showKeys ? 'sk_live_51H...' : 'sk_live_••••••••'}</code>
                  <button onClick={() => setShowKeys(!showKeys)} className="p-1 hover:bg-accent rounded transition-colors">{showKeys ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}</button>
                  <button className="p-1 hover:bg-accent rounded transition-colors"><RefreshCw className="w-4 h-4" /></button>
                </div>
              </div>
              <div className="flex items-center justify-between p-3 bg-accent/50 rounded-lg">
                <div className="flex items-center gap-3"><Key className="w-5 h-5 text-zanox-500" /><div><p className="font-medium text-sm">Development API Key</p><p className="text-xs text-muted-foreground">Created 15 days ago</p></div></div>
                <div className="flex items-center gap-2">
                  <code className="px-2 py-1 bg-background rounded text-xs font-mono">{showKeys ? 'sk_test_51H...' : 'sk_test_••••••••'}</code>
                  <button onClick={() => setShowKeys(!showKeys)} className="p-1 hover:bg-accent rounded transition-colors">{showKeys ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}</button>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }} className="glass-panel p-5">
            <h3 className="font-semibold mb-4">Two-Factor Authentication</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-accent/50 rounded-lg">
                <div className="flex items-center gap-3"><Smartphone className="w-5 h-5 text-green-500" /><div><p className="font-medium text-sm">Authenticator App</p><p className="text-xs text-muted-foreground">Google Authenticator</p></div></div>
                <span className="px-2 py-1 bg-green-500/10 text-green-600 text-xs rounded-full font-medium">Enabled</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-accent/50 rounded-lg">
                <div className="flex items-center gap-3"><Fingerprint className="w-5 h-5 text-zanox-500" /><div><p className="font-medium text-sm">Biometric Login</p><p className="text-xs text-muted-foreground">Face ID / Touch ID</p></div></div>
                <span className="px-2 py-1 bg-green-500/10 text-green-600 text-xs rounded-full font-medium">Enabled</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-accent/50 rounded-lg">
                <div className="flex items-center gap-3"><Lock className="w-5 h-5 text-gray-500" /><div><p className="font-medium text-sm">SMS Backup</p><p className="text-xs text-muted-foreground">+1 *** *** 1234</p></div></div>
                <button className="px-3 py-1 bg-zanox-100 dark:bg-zanox-900/30 text-zanox-700 dark:text-zanox-300 text-xs rounded-lg font-medium">Enable</button>
              </div>
            </div>
          </motion.div>
        </div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }} className="glass-panel p-5">
          <h3 className="font-semibold mb-4">Audit Log</h3>
          <div className="space-y-3">
            {auditLog.map((log) => (
              <div key={log.id} className="flex items-center gap-4 p-3 bg-accent/50 rounded-lg">
                <div className={`p-2 rounded-lg ${log.status === 'success' ? 'bg-green-500/10 text-green-600' : 'bg-red-500/10 text-red-600'}`}>
                  {log.status === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm">{log.action}</p>
                  <p className="text-xs text-muted-foreground">{log.user} | {log.ip} | {log.location}</p>
                </div>
                <span className="text-xs text-muted-foreground whitespace-nowrap">{log.time}</span>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </AppShell>
  );
}
