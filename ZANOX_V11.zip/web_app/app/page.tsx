'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useZanox } from '@/hooks/useZanoxStore';
import { UnifiedDashboard } from '@/dashboard/components/UnifiedDashboard';
import { AppShell } from '@/components/AppShell';

export default function Home() {
  const { user, isLoading } = useZanox();
  const router = useRouter();

  useEffect(() => {
    if (!isLoading && !user) router.push('/auth/login');
  }, [user, isLoading, router]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-zanox-200 border-t-zanox-600 rounded-full animate-spin" />
          <p className="text-muted-foreground text-sm animate-pulse">Loading ZANOX...</p>
        </div>
      </div>
    );
  }
  if (!user) return null;

  return (
    <AppShell>
      <UnifiedDashboard />
    </AppShell>
  );
}
