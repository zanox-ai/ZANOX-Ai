'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Workflow, Plus, Play, Save, Settings, GitBranch, Layers, Zap, Timer, Mail, Database, Webhook, Filter, ArrowRight, Trash2, Copy, CheckCircle2 } from 'lucide-react';
import { AppShell } from '@/components/AppShell';

interface Node {
  id: string;
  type: 'trigger' | 'action' | 'condition' | 'delay' | 'transform';
  name: string;
  description: string;
  x: number;
  y: number;
  config: Record<string, any>;
}

interface Edge {
  id: string;
  source: string;
  target: string;
}

const nodeTypes = [
  { type: 'trigger', icon: Zap, color: 'bg-orange-500', label: 'Trigger' },
  { type: 'action', icon: Play, color: 'bg-blue-500', label: 'Action' },
  { type: 'condition', icon: Filter, color: 'bg-purple-500', label: 'Condition' },
  { type: 'delay', icon: Timer, color: 'bg-yellow-500', label: 'Delay' },
  { type: 'transform', icon: Layers, color: 'bg-green-500', label: 'Transform' },
];

const mockNodes: Node[] = [
  { id: '1', type: 'trigger', name: 'Webhook Trigger', description: 'Receive HTTP POST', x: 100, y: 200, config: { method: 'POST', path: '/webhook/lead' } },
  { id: '2', type: 'condition', name: 'Validate Lead', description: 'Check required fields', x: 300, y: 200, config: { rules: [{ field: 'email', operator: 'exists' }] } },
  { id: '3', type: 'action', name: 'Create Contact', description: 'Add to CRM', x: 500, y: 150, config: { system: 'salesforce', entity: 'Contact' } },
  { id: '4', type: 'delay', name: 'Wait 1 Hour', description: 'Delay before next action', x: 500, y: 250, config: { duration: 3600 } },
  { id: '5', type: 'action', name: 'Send Email', description: 'Welcome sequence', x: 700, y: 200, config: { template: 'welcome_v2', provider: 'sendgrid' } },
];

const mockEdges: Edge[] = [
  { id: 'e1', source: '1', target: '2' },
  { id: 'e2', source: '2', target: '3' },
  { id: 'e3', source: '2', target: '4' },
  { id: 'e4', source: '4', target: '5' },
];

export default function WorkflowsPage() {
  const [nodes] = useState<Node[]>(mockNodes);
  const [edges] = useState<Edge[]>(mockEdges);
  const [selectedNode, setSelectedNode] = useState<Node | null>(null);

  return (
    <AppShell>
      <div className="space-y-4 h-[calc(100vh-8rem)]">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div><h1 className="text-2xl font-bold">Workflow Studio</h1><p className="text-muted-foreground mt-1">Visual drag-and-drop workflow builder</p></div>
          <div className="flex gap-2">
            <button className="btn-secondary flex items-center gap-2"><Save className="w-4 h-4" /> Save</button>
            <button className="btn-primary flex items-center gap-2"><Play className="w-4 h-4" /> Run</button>
          </div>
        </div>
        <div className="flex gap-4 flex-1 h-full">
          <div className="w-64 glass-panel p-4 flex flex-col gap-2">
            <h3 className="font-semibold text-sm mb-2">Node Types</h3>
            {nodeTypes.map((nt) => (
              <div key={nt.type} className="flex items-center gap-3 p-3 rounded-lg bg-accent/50 hover:bg-accent transition-colors cursor-pointer">
                <div className={`w-8 h-8 rounded-lg ${nt.color} flex items-center justify-center text-white`}><nt.icon className="w-4 h-4" /></div>
                <div><p className="text-sm font-medium">{nt.label}</p><p className="text-xs text-muted-foreground">Drag to canvas</p></div>
              </div>
            ))}
          </div>
          <div className="flex-1 glass-panel relative overflow-hidden">
            <svg className="w-full h-full" viewBox="0 0 900 400">
              {edges.map((edge) => {
                const source = nodes.find((n) => n.id === edge.source);
                const target = nodes.find((n) => n.id === edge.target);
                if (!source || !target) return null;
                return (
                  <g key={edge.id}>
                    <line x1={source.x + 80} y1={source.y + 30} x2={target.x} y2={target.y + 30} stroke="currentColor" strokeWidth="2" className="text-zanox-400" />
                    <polygon points={`${target.x},${target.y + 30} ${target.x - 8},${target.y + 25} ${target.x - 8},${target.y + 35}`} fill="currentColor" className="text-zanox-400" />
                  </g>
                );
              })}
              {nodes.map((node) => {
                const nt = nodeTypes.find((t) => t.type === node.type);
                if (!nt) return null;
                return (
                  <g key={node.id} onClick={() => setSelectedNode(node)} className="cursor-pointer">
                    <rect x={node.x} y={node.y} width="160" height="60" rx="8" fill="var(--card)" stroke={selectedNode?.id === node.id ? '#0ea5e9' : 'var(--border)'} strokeWidth="2" />
                    <foreignObject x={node.x + 10} y={node.y + 10} width="140" height="40">
                      <div className="flex items-center gap-2">
                        <div className={`w-6 h-6 rounded ${nt.color} flex items-center justify-center text-white`}><nt.icon className="w-3 h-3" /></div>
                        <div className="text-xs"><div className="font-medium">{node.name}</div><div className="text-muted-foreground">{node.description}</div></div>
                      </div>
                    </foreignObject>
                  </g>
                );
              })}
            </svg>
          </div>
          {selectedNode && (
            <div className="w-80 glass-panel p-4">
              <h3 className="font-semibold mb-4">Node Configuration</h3>
              <div className="space-y-4">
                <div><label className="text-sm font-medium">Name</label><input type="text" value={selectedNode.name} className="w-full mt-1 px-3 py-2 bg-background border border-input rounded-lg text-sm input-focus" readOnly /></div>
                <div><label className="text-sm font-medium">Type</label><input type="text" value={selectedNode.type} className="w-full mt-1 px-3 py-2 bg-background border border-input rounded-lg text-sm input-focus" readOnly /></div>
                <div><label className="text-sm font-medium">Configuration</label><pre className="mt-1 p-3 bg-accent rounded-lg text-xs overflow-auto">{JSON.stringify(selectedNode.config, null, 2)}</pre></div>
              </div>
            </div>
          )}
        </div>
      </div>
    </AppShell>
  );
}
