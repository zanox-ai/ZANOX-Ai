'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Palette, Plus, Search, Image, Video, Music, Mic, Box, FileText, Presentation, Wand2, Sparkles, Download, Share2, Clock, Star } from 'lucide-react';
import { AppShell } from '@/components/AppShell';

const creativeTypes = [
  { id: 'image', name: 'Image Generation', icon: Image, color: 'bg-purple-500', description: 'AI-powered image creation' },
  { id: 'video', name: 'Video Generation', icon: Video, color: 'bg-blue-500', description: 'Text-to-video synthesis' },
  { id: 'animation', name: 'Animation', icon: Sparkles, color: 'bg-pink-500', description: 'Motion graphics and animation' },
  { id: 'voice', name: 'Voice Generation', icon: Mic, color: 'bg-green-500', description: 'Text-to-speech and voice cloning' },
  { id: 'music', name: 'Music Generation', icon: Music, color: 'bg-orange-500', description: 'AI music composition' },
  { id: 'song', name: 'Song Generation', icon: Music, color: 'bg-red-500', description: 'Full song production' },
  { id: '3d', name: '3D Generation', icon: Box, color: 'bg-cyan-500', description: '3D model creation' },
  { id: 'presentation', name: 'Presentations', icon: Presentation, color: 'bg-indigo-500', description: 'Auto-generated slides' },
  { id: 'document', name: 'Documents', icon: FileText, color: 'bg-teal-500', description: 'AI document creation' },
];

const mockAssets = [
  { id: '1', name: 'Brand Hero Image', type: 'image', model: 'DALL-E 3', status: 'completed', created: '2 min ago', size: '2.4 MB', stars: 12 },
  { id: '2', name: 'Product Demo Video', type: 'video', model: 'Sora', status: 'processing', created: '15 min ago', size: '45.2 MB', stars: 8 },
  { id: '3', name: 'Podcast Intro', type: 'music', model: 'Suno', status: 'completed', created: '1 hour ago', size: '4.1 MB', stars: 23 },
  { id: '4', name: '3D Product Model', type: '3d', model: 'Shap-E', status: 'completed', created: '3 hours ago', size: '12.8 MB', stars: 15 },
  { id: '5', name: 'Q4 Report Deck', type: 'presentation', model: 'GPT-4', status: 'completed', created: '30 min ago', size: '1.2 MB', stars: 34 },
];

export default function CreativePage() {
  const [selectedType, setSelectedType] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredAssets = mockAssets.filter((asset) => {
    const matchesSearch = asset.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = selectedType === 'all' || asset.type === selectedType;
    return matchesSearch && matchesType;
  });

  return (
    <AppShell>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div><h1 className="text-2xl font-bold">Creative Center</h1><p className="text-muted-foreground mt-1">AI-powered creative content generation</p></div>
          <button className="btn-primary flex items-center gap-2"><Wand2 className="w-4 h-4" /> Create New</button>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {creativeTypes.map((type) => (
            <button key={type.id} onClick={() => setSelectedType(type.id === selectedType ? 'all' : type.id)}
              className={`p-4 rounded-xl transition-all ${selectedType === type.id ? 'bg-zanox-50 dark:bg-zanox-900/30 border-2 border-zanox-500' : 'glass-panel hover:border-zanox-300'}`}>
              <div className={`w-10 h-10 rounded-lg ${type.color} flex items-center justify-center text-white mb-3`}><type.icon className="w-5 h-5" /></div>
              <h3 className="font-medium text-sm">{type.name}</h3>
              <p className="text-xs text-muted-foreground mt-1">{type.description}</p>
            </button>
          ))}
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Search creative assets..." className="w-full pl-9 pr-4 py-2 bg-background border border-input rounded-lg input-focus text-sm" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredAssets.map((asset, index) => (
            <motion.div key={asset.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.05 }}
              className="glass-panel p-5 card-hover group">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-zanox-500 to-accent-purple flex items-center justify-center text-white"><Palette className="w-5 h-5" /></div>
                  <div><h3 className="font-semibold">{asset.name}</h3><p className="text-xs text-muted-foreground">{asset.model}</p></div>
                </div>
                <span className={`px-2 py-0.5 text-xs rounded-full ${asset.status === 'completed' ? 'bg-green-500/10 text-green-600' : 'bg-yellow-500/10 text-yellow-600'}`}>{asset.status}</span>
              </div>
              <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                <span className="flex items-center gap-1"><Clock className="w-4 h-4" /> {asset.created}</span>
                <span>{asset.size}</span>
                <span className="flex items-center gap-1"><Star className="w-4 h-4" /> {asset.stars}</span>
              </div>
              <div className="flex gap-2">
                <button className="flex-1 py-2 bg-zanox-50 dark:bg-zanox-900/20 text-zanox-700 dark:text-zanox-300 rounded-lg text-sm font-medium hover:bg-zanox-100 dark:hover:bg-zanox-900/40 transition-colors flex items-center justify-center gap-1"><Download className="w-4 h-4" /> Download</button>
                <button className="p-2 hover:bg-accent rounded-lg transition-colors"><Share2 className="w-4 h-4" /></button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </AppShell>
  );
}
