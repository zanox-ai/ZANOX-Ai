/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: 'class',
  content: ['./app/**/*.{js,ts,jsx,tsx,mdx}', './components/**/*.{js,ts,jsx,tsx,mdx}', './hooks/**/*.{js,ts,jsx,tsx,mdx}', './utils/**/*.{js,ts,jsx,tsx,mdx}', './types/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      colors: { zanox: { 50: '#f0f9ff', 100: '#e0f2fe', 200: '#bae6fd', 300: '#7dd3fc', 400: '#38bdf8', 500: '#0ea5e9', 600: '#0284c7', 700: '#0369a1', 800: '#075985', 900: '#0c4a6e', 950: '#082f49' }, accent: { purple: '#8b5cf6', pink: '#ec4899', orange: '#f97316', green: '#10b981', red: '#ef4444' }, dark: { bg: '#0a0a0f', surface: '#12121a', elevated: '#1a1a2e', border: '#2a2a3e' } },
      fontFamily: { sans: ['Inter', 'system-ui', 'sans-serif'], mono: ['JetBrains Mono', 'Fira Code', 'monospace'] },
      animation: { 'fade-in': 'fadeIn 0.3s ease-in-out', 'slide-up': 'slideUp 0.4s ease-out', 'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite', 'glow': 'glow 2s ease-in-out infinite alternate' },
      keyframes: { fadeIn: { '0%': { opacity: '0' }, '100%': { opacity: '1' } }, slideUp: { '0%': { transform: 'translateY(20px)', opacity: '0' }, '100%': { transform: 'translateY(0)', opacity: '1' } }, glow: { '0%': { boxShadow: '0 0 5px rgba(14, 165, 233, 0.2)' }, '100%': { boxShadow: '0 0 20px rgba(14, 165, 233, 0.6)' } } },
    },
  },
  plugins: [require('@tailwindcss/forms'), require('@tailwindcss/typography')],
};
