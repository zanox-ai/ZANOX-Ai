'use client';

import { useEffect, useRef, useState, useCallback, createContext, useContext, ReactNode } from 'react';

interface WebSocketMessage {
  type: string;
  payload: any;
  timestamp: string;
  id: string;
}

interface WebSocketContextType {
  socket: WebSocket | null;
  connected: boolean;
  send: (message: any) => void;
  lastMessage: WebSocketMessage | null;
  subscribe: (type: string, callback: (payload: any) => void) => () => void;
}

const WebSocketContext = createContext<WebSocketContextType>({
  socket: null, connected: false, send: () => {}, lastMessage: null, subscribe: () => () => {},
});

export function WebSocketProvider({ children, url }: { children: ReactNode; url: string }) {
  const [connected, setConnected] = useState(false);
  const [lastMessage, setLastMessage] = useState<WebSocketMessage | null>(null);
  const socketRef = useRef<WebSocket | null>(null);
  const subscribersRef = useRef<Map<string, Set<(payload: any) => void>>>(new Map());
  const reconnectTimeoutRef = useRef<NodeJS.Timeout>();
  const reconnectAttemptsRef = useRef(0);
  const maxReconnectAttempts = 10;

  const connect = useCallback(() => {
    if (socketRef.current?.readyState === WebSocket.OPEN) return;
    try {
      const ws = new WebSocket(url);
      ws.onopen = () => {
        setConnected(true);
        reconnectAttemptsRef.current = 0;
        const token = localStorage.getItem('zanox-token');
        if (token) ws.send(JSON.stringify({ type: 'auth', token }));
      };
      ws.onmessage = (event) => {
        try {
          const message: WebSocketMessage = JSON.parse(event.data);
          setLastMessage(message);
          const callbacks = subscribersRef.current.get(message.type);
          if (callbacks) callbacks.forEach((cb) => cb(message.payload));
          const wildcards = subscribersRef.current.get('*');
          if (wildcards) wildcards.forEach((cb) => cb(message));
        } catch (error) { console.error('WebSocket message parse error:', error); }
      };
      ws.onclose = () => {
        setConnected(false);
        if (reconnectAttemptsRef.current < maxReconnectAttempts) {
          const delay = Math.min(1000 * 2 ** reconnectAttemptsRef.current, 30000);
          reconnectTimeoutRef.current = setTimeout(() => { reconnectAttemptsRef.current++; connect(); }, delay);
        }
      };
      ws.onerror = (error) => { console.error('WebSocket error:', error); };
      socketRef.current = ws;
    } catch (error) { console.error('WebSocket connection error:', error); }
  }, [url]);

  const send = useCallback((message: any) => {
    if (socketRef.current?.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify(message));
    } else { console.warn('WebSocket not connected, message queued'); }
  }, []);

  const subscribe = useCallback((type: string, callback: (payload: any) => void) => {
    if (!subscribersRef.current.has(type)) subscribersRef.current.set(type, new Set());
    subscribersRef.current.get(type)!.add(callback);
    return () => { subscribersRef.current.get(type)?.delete(callback); };
  }, []);

  useEffect(() => {
    connect();
    return () => {
      if (reconnectTimeoutRef.current) clearTimeout(reconnectTimeoutRef.current);
      socketRef.current?.close();
    };
  }, [connect]);

  return (
    <WebSocketContext.Provider value={{ socket: socketRef.current, connected, send, lastMessage, subscribe }}>
      {children}
    </WebSocketContext.Provider>
  );
}

export function useWebSocket() {
  return useContext(WebSocketContext);
}
