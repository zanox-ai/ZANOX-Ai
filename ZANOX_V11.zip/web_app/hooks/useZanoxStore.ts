'use client';

import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { ReactNode, createContext, useContext } from 'react';

export interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  role: 'admin' | 'owner' | 'member' | 'viewer';
  permissions: string[];
  preferences: UserPreferences;
}

export interface UserPreferences {
  theme: 'light' | 'dark' | 'system';
  language: string;
  timezone: string;
  notifications: boolean;
  compactMode: boolean;
  sidebarCollapsed: boolean;
  defaultWorkspace: string;
}

export interface Workspace {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  ownerId: string;
  members: WorkspaceMember[];
  projects: string[];
  createdAt: string;
  updatedAt: string;
}

export interface WorkspaceMember {
  userId: string;
  role: 'admin' | 'editor' | 'viewer';
  joinedAt: string;
}

export interface Agent {
  id: string;
  name: string;
  description: string;
  type: 'chat' | 'automation' | 'creative' | 'code' | 'business' | 'game';
  status: 'active' | 'idle' | 'busy' | 'error' | 'offline';
  model: string;
  provider: string;
  capabilities: string[];
  config: Record<string, any>;
  workspaceId: string;
  createdAt: string;
  lastActive: string;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  type: 'ai' | 'automation' | 'builder' | 'creative' | 'game' | 'business';
  status: 'active' | 'archived' | 'draft';
  workspaceId: string;
  agents: string[];
  files: string[];
  settings: Record<string, any>;
  createdAt: string;
  updatedAt: string;
}

export interface Notification {
  id: string;
  type: 'info' | 'success' | 'warning' | 'error';
  title: string;
  message: string;
  read: boolean;
  timestamp: string;
  action?: { label: string; href: string };
}

interface ZanoxState {
  user: User | null;
  workspaces: Workspace[];
  activeWorkspace: string | null;
  agents: Agent[];
  projects: Project[];
  notifications: Notification[];
  sidebarOpen: boolean;
  activePanel: string;
  isLoading: boolean;
  setUser: (user: User | null) => void;
  setWorkspaces: (workspaces: Workspace[]) => void;
  setActiveWorkspace: (id: string | null) => void;
  addWorkspace: (workspace: Workspace) => void;
  removeWorkspace: (id: string) => void;
  setAgents: (agents: Agent[]) => void;
  addAgent: (agent: Agent) => void;
  updateAgent: (id: string, updates: Partial<Agent>) => void;
  removeAgent: (id: string) => void;
  setProjects: (projects: Project[]) => void;
  addProject: (project: Project) => void;
  addNotification: (notification: Notification) => void;
  markNotificationRead: (id: string) => void;
  clearNotifications: () => void;
  setSidebarOpen: (open: boolean) => void;
  setActivePanel: (panel: string) => void;
  setLoading: (loading: boolean) => void;
  logout: () => void;
}

export const useZanoxStore = create<ZanoxState>()(
  persist(
    (set, get) => ({
      user: null, workspaces: [], activeWorkspace: null, agents: [], projects: [], notifications: [], sidebarOpen: true, activePanel: 'dashboard', isLoading: false,
      setUser: (user) => set({ user }),
      setWorkspaces: (workspaces) => set({ workspaces }),
      setActiveWorkspace: (id) => set({ activeWorkspace: id }),
      addWorkspace: (workspace) => set((state) => ({ workspaces: [...state.workspaces, workspace] })),
      removeWorkspace: (id) => set((state) => ({ workspaces: state.workspaces.filter((w) => w.id !== id), activeWorkspace: state.activeWorkspace === id ? null : state.activeWorkspace })),
      setAgents: (agents) => set({ agents }),
      addAgent: (agent) => set((state) => ({ agents: [...state.agents, agent] })),
      updateAgent: (id, updates) => set((state) => ({ agents: state.agents.map((a) => a.id === id ? { ...a, ...updates } : a) })),
      removeAgent: (id) => set((state) => ({ agents: state.agents.filter((a) => a.id !== id) })),
      setProjects: (projects) => set({ projects }),
      addProject: (project) => set((state) => ({ projects: [...state.projects, project] })),
      addNotification: (notification) => set((state) => ({ notifications: [notification, ...state.notifications].slice(0, 100) })),
      markNotificationRead: (id) => set((state) => ({ notifications: state.notifications.map((n) => n.id === id ? { ...n, read: true } : n) })),
      clearNotifications: () => set({ notifications: [] }),
      setSidebarOpen: (open) => set({ sidebarOpen: open }),
      setActivePanel: (panel) => set({ activePanel: panel }),
      setLoading: (loading) => set({ isLoading: loading }),
      logout: () => set({ user: null, workspaces: [], activeWorkspace: null, agents: [], projects: [], notifications: [] }),
    }),
    { name: 'zanox-storage', storage: createJSONStorage(() => localStorage), partialize: (state) => ({ user: state.user, workspaces: state.workspaces, activeWorkspace: state.activeWorkspace, sidebarOpen: state.sidebarOpen }) }
  )
);

const ZanoxContext = createContext<ReturnType<typeof useZanoxStore> | null>(null);

export function ZanoxStoreProvider({ children }: { children: ReactNode }) {
  return <>{children}</>;
}

export function useZanox() {
  return useZanoxStore();
}
