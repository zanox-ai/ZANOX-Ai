/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: { appDir: true, serverActions: true },
  images: { domains: ['localhost', 'api.zanox.io', 'cdn.zanox.io'], remotePatterns: [{ protocol: 'https', hostname: '**.zanox.io' }, { protocol: 'https', hostname: '**.openai.com' }, { protocol: 'https', hostname: '**.anthropic.com' }] },
  async rewrites() { return [{ source: '/api/:path*', destination: 'http://localhost:4000/api/:path*' }, { source: '/ws/:path*', destination: 'http://localhost:4001/ws/:path*' }]; },
  async headers() { return [{ source: '/:path*', headers: [{ key: 'X-DNS-Prefetch-Control', value: 'on' }, { key: 'X-Frame-Options', value: 'SAMEORIGIN' }, { key: 'X-Content-Type-Options', value: 'nosniff' }, { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' }] }]; },
  webpack: (config, { isServer }) => { if (!isServer) { config.resolve.fallback = { ...config.resolve.fallback, fs: false, net: false, tls: false }; } return config; },
};
module.exports = nextConfig;
