'use client';

import { useZanox } from '@/hooks/useZanoxStore';
import { usePathname } from 'next/navigation';
import Link from 'next/link';
import { LayoutDashboard, Bot, Brain, Workflow, Hammer, Palette, Gamepad2, Building2, Sparkles, FolderKanban, BarChart3, Shield, Settings, Users, ChevronLeft, ChevronRight, Zap } from 'lucide-react';

const navigation = [
  { name: 'Dashboard', href: '/', icon: LayoutDashboard, panel: 'dashboard' },
  { name: 'Agent Center', href: '/agents', icon: Bot, panel: 'agent_center' },
  { name: 'AI Center', href: '/ai', icon: Brain, panel: 'ai_center' },
  { name: 'Automation', href: '/automation', icon: Workflow, panel: 'automation_center' },
  { name: 'Builder', href: '/builder', icon: Hammer, panel: 'builder_center' },
  { name: 'Creative', href: '/creative', icon: Palette, panel: 'creative_center' },
  { name: 'Game Dev', href: '/games', icon: Gamepad2, panel: 'game_center' },
  { name: 'Business', href: '/business', icon: Building2, panel: 'business_center' },
  { name: 'Workflows', href: '/workflows', icon: Sparkles, panel: 'workflow_studio' },
  { name: 'Projects', href: '/projects', icon: FolderKanban, panel: 'project_manager' },
  { name: 'Analytics', href: '/analytics', icon: BarChart3, panel: 'analytics' },
  { name: 'Team', href: '/team', icon: Users, panel: 'team' },
  { name: 'Security', href: '/security', icon: Shield, panel: 'security' },
  { name: 'Settings', href: '/settings', icon: Settings, panel: 'admin' },
];

export function Sidebar({ collapsed }: { collapsed: boolean }) {
  const { setSidebarOpen, sidebarOpen, setActivePanel, activePanel } = useZanox();
  const pathname = usePathname();

  return (
    <div className="flex flex-col h-full">
      <div className={`flex items-center gap-3 px-4 py-4 border-b border-border ${collapsed ? 'justify-center' : ''}`}>
        <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-zanox-500 to-accent-purple flex items-center justify-center flex-shrink-0">
          <Zap className="w-5 h-5 text-white" />
        </div>
        {!collapsed && (
          <div className="flex-1 min-w-0">
            <h1 className="font-bold text-lg text-gradient truncate">ZANOX</h1>
            <p className="text-xs text-muted-foreground">V11 Experience</p>
          </div>
        )}
      </div>
      <nav className="flex-1 overflow-y-auto py-4 px-2 space-y-1">
        {navigation.map((item) => {
          const isActive = pathname === item.href || activePanel === item.panel;
          const Icon = item.icon;
          return (
            <Link key={item.name} href={item.href} onClick={() => setActivePanel(item.panel)}
              className={`sidebar-item ${isActive ? 'active' : ''} ${collapsed ? 'justify-center px-2' : ''}`}
              title={collapsed ? item.name : undefined}>
              <Icon className={`w-5 h-5 flex-shrink-0 ${isActive ? 'text-zanox-500' : ''}`} />
              {!collapsed && <span className="truncate">{item.name}</span>}
            </Link>
          );
        })}
      </nav>
      <div className="p-2 border-t border-border">
        <button onClick={() => setSidebarOpen(!sidebarOpen)} className="w-full flex items-center justify-center p-2 rounded-lg hover:bg-accent transition-colors">
          {sidebarOpen ? <ChevronLeft className="w-5 h-5 text-muted-foreground" /> : <ChevronRight className="w-5 h-5 text-muted-foreground" />}
        </button>
      </div>
    </div>
  );
}
