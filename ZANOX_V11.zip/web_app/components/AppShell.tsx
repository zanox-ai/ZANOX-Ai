'use client';

import { useState } from 'react';
import { useZanox } from '@/hooks/useZanoxStore';
import { Sidebar } from './Sidebar';
import { TopBar } from './TopBar';
import { MobileNav } from './MobileNav';
import { NotificationPanel } from './NotificationPanel';

export function AppShell({ children }: { children: React.ReactNode }) {
  const { sidebarOpen } = useZanox();
  const [showNotifications, setShowNotifications] = useState(false);

  return (
    <div className="min-h-screen bg-background flex">
      <aside className={`hidden lg:flex flex-col border-r border-border bg-card transition-all duration-300 ${sidebarOpen ? 'w-64' : 'w-16'}`}>
        <Sidebar collapsed={!sidebarOpen} />
      </aside>
      <div className="flex-1 flex flex-col min-w-0">
        <TopBar onNotificationClick={() => setShowNotifications(!showNotifications)} />
        <main className="flex-1 overflow-auto p-4 lg:p-6">
          <div className="max-w-7xl mx-auto">{children}</div>
        </main>
        <MobileNav />
      </div>
      {showNotifications && <NotificationPanel onClose={() => setShowNotifications(false)} />}
    </div>
  );
}
