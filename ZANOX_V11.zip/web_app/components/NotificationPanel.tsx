'use client';

import { useZanox } from '@/hooks/useZanoxStore';
import { X, Bell, Info, AlertTriangle, AlertCircle, CheckCircle } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

const iconMap = { info: Info, success: CheckCircle, warning: AlertTriangle, error: AlertCircle };
const colorMap = { info: 'text-blue-500 bg-blue-50 dark:bg-blue-900/20', success: 'text-green-500 bg-green-50 dark:bg-green-900/20', warning: 'text-orange-500 bg-orange-50 dark:bg-orange-900/20', error: 'text-red-500 bg-red-50 dark:bg-red-900/20' };

export function NotificationPanel({ onClose }: { onClose: () => void }) {
  const { notifications, markNotificationRead, clearNotifications } = useZanox();
  return (
    <div className="fixed inset-y-0 right-0 w-96 bg-card border-l border-border shadow-2xl z-50 flex flex-col animate-in">
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center gap-2">
          <Bell className="w-5 h-5" />
          <h2 className="font-semibold">Notifications</h2>
          <span className="px-2 py-0.5 bg-zanox-100 dark:bg-zanox-900/30 text-zanox-700 dark:text-zanox-300 text-xs rounded-full">
            {notifications.filter((n) => !n.read).length}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={clearNotifications} className="text-xs text-muted-foreground hover:text-foreground transition-colors">Clear all</button>
          <button onClick={onClose} className="p-1 hover:bg-accent rounded-lg transition-colors"><X className="w-5 h-5" /></button>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto p-2 space-y-1">
        {notifications.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-40 text-muted-foreground">
            <Bell className="w-10 h-10 mb-2 opacity-50" />
            <p className="text-sm">No notifications yet</p>
          </div>
        ) : (
          notifications.map((notification) => {
            const Icon = iconMap[notification.type];
            const colors = colorMap[notification.type];
            return (
              <div key={notification.id} onClick={() => markNotificationRead(notification.id)}
                className={`p-3 rounded-lg cursor-pointer transition-all ${notification.read ? 'opacity-60 hover:opacity-80' : 'bg-accent/50 hover:bg-accent'}`}>
                <div className="flex gap-3">
                  <div className={`p-2 rounded-lg ${colors} flex-shrink-0`}><Icon className="w-4 h-4" /></div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium">{notification.title}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{notification.message}</p>
                    <p className="text-xs text-muted-foreground mt-1">{formatDistanceToNow(new Date(notification.timestamp), { addSuffix: true })}</p>
                  </div>
                  {!notification.read && <div className="w-2 h-2 bg-zanox-500 rounded-full flex-shrink-0 mt-1" />}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
