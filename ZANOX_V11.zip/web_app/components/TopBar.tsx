'use client';

import { useZanox } from '@/hooks/useZanoxStore';
import { useState } from 'react';
import { Search, Bell, Moon, Sun, Menu, Command, User, LogOut, ChevronDown } from 'lucide-react';
import { useTheme } from 'next-themes';
import { useRouter } from 'next/navigation';

export function TopBar({ onNotificationClick }: { onNotificationClick: () => void }) {
  const { user, setSidebarOpen, sidebarOpen, notifications, logout } = useZanox();
  const { theme, setTheme } = useTheme();
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const router = useRouter();
  const unreadCount = notifications.filter((n) => !n.read).length;

  const handleLogout = () => {
    logout();
    localStorage.removeItem('zanox-token');
    router.push('/auth/login');
  };

  return (
    <header className="h-16 border-b border-border bg-card/50 backdrop-blur-sm flex items-center justify-between px-4 lg:px-6 sticky top-0 z-50">
      <div className="flex items-center gap-4">
        <button onClick={() => setSidebarOpen(!sidebarOpen)} className="lg:hidden p-2 hover:bg-accent rounded-lg transition-colors">
          <Menu className="w-5 h-5" />
        </button>
        <div className="hidden md:flex items-center relative">
          <Search className="absolute left-3 w-4 h-4 text-muted-foreground" />
          <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search agents, projects, commands..."
            className="w-80 pl-9 pr-4 py-2 bg-accent rounded-lg text-sm input-focus placeholder:text-muted-foreground" />
          <kbd className="absolute right-3 hidden lg:flex items-center gap-1 text-xs text-muted-foreground bg-background px-1.5 py-0.5 rounded border">
            <Command className="w-3 h-3" /> K
          </kbd>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <button onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')} className="p-2 hover:bg-accent rounded-lg transition-colors">
          {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
        </button>
        <button onClick={onNotificationClick} className="relative p-2 hover:bg-accent rounded-lg transition-colors">
          <Bell className="w-5 h-5" />
          {unreadCount > 0 && (
            <span className="absolute top-1 right-1 w-4 h-4 bg-accent-red text-white text-xs rounded-full flex items-center justify-center">
              {unreadCount > 9 ? '9+' : unreadCount}
            </span>
          )}
        </button>
        <div className="relative">
          <button onClick={() => setShowUserMenu(!showUserMenu)} className="flex items-center gap-2 p-1.5 hover:bg-accent rounded-lg transition-colors">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-zanox-500 to-accent-purple flex items-center justify-center text-white text-sm font-medium">
              {user?.name?.charAt(0) || 'U'}
            </div>
            <div className="hidden md:block text-left">
              <p className="text-sm font-medium">{user?.name || 'User'}</p>
              <p className="text-xs text-muted-foreground">{user?.role || 'Member'}</p>
            </div>
            <ChevronDown className="w-4 h-4 text-muted-foreground" />
          </button>
          {showUserMenu && (
            <div className="absolute right-0 mt-2 w-56 bg-card border border-border rounded-xl shadow-xl py-2 z-50">
              <div className="px-4 py-2 border-b border-border">
                <p className="font-medium">{user?.name}</p>
                <p className="text-sm text-muted-foreground">{user?.email}</p>
              </div>
              <button onClick={() => router.push('/settings/profile')} className="w-full flex items-center gap-2 px-4 py-2 text-sm hover:bg-accent transition-colors">
                <User className="w-4 h-4" /> Profile
              </button>
              <button onClick={handleLogout} className="w-full flex items-center gap-2 px-4 py-2 text-sm text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors">
                <LogOut className="w-4 h-4" /> Sign Out
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
