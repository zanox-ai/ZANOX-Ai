'use client';

import { usePathname } from 'next/navigation';
import Link from 'next/link';
import { LayoutDashboard, Bot, Brain, Workflow, Hammer, Palette, MoreHorizontal } from 'lucide-react';

const mobileNav = [
  { name: 'Home', href: '/', icon: LayoutDashboard },
  { name: 'Agents', href: '/agents', icon: Bot },
  { name: 'AI', href: '/ai', icon: Brain },
  { name: 'Flow', href: '/workflows', icon: Workflow },
  { name: 'Build', href: '/builder', icon: Hammer },
  { name: 'Create', href: '/creative', icon: Palette },
  { name: 'More', href: '/menu', icon: MoreHorizontal },
];

export function MobileNav() {
  const pathname = usePathname();
  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-card border-t border-border z-50">
      <div className="flex items-center justify-around py-2">
        {mobileNav.map((item) => {
          const isActive = pathname === item.href;
          const Icon = item.icon;
          return (
            <Link key={item.name} href={item.href} className={`flex flex-col items-center gap-1 px-3 py-1 rounded-lg transition-colors ${isActive ? 'text-zanox-500' : 'text-muted-foreground'}`}>
              <Icon className="w-5 h-5" />
              <span className="text-xs">{item.name}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
