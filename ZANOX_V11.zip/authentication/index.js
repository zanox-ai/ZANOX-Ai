const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
class AuthService {
  constructor(secret) { this.secret = secret; this.users = new Map(); }
  async register(email, password, name) {
    const hashed = await bcrypt.hash(password, 12);
    const user = { id: Date.now().toString(), email, name, password: hashed, role: 'member', createdAt: new Date() };
    this.users.set(email, user);
    return this.generateToken(user);
  }
  async login(email, password) {
    const user = this.users.get(email);
    if (!user) throw new Error('User not found');
    const valid = await bcrypt.compare(password, user.password);
    if (!valid) throw new Error('Invalid password');
    return this.generateToken(user);
  }
  generateToken(user) { return jwt.sign({ userId: user.id, email: user.email, role: user.role }, this.secret, { expiresIn: '7d' }); }
  verifyToken(token) { return jwt.verify(token, this.secret); }
}
module.exports = { AuthService };
