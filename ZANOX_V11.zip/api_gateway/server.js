const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const { createServer } = require('http');
const WebSocket = require('ws');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const app = express();
const server = createServer(app);
const wss = new WebSocket.Server({ server, path: '/ws' });
const PORT = process.env.PORT || 4000;
const JWT_SECRET = process.env.JWT_SECRET || 'zanox-v11-secret-key';

app.use(helmet());
app.use(cors({ origin: process.env.CORS_ORIGIN || '*', credentials: true }));
app.use(compression());
app.use(morgan('combined'));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 1000, message: { error: 'Too many requests' } });
app.use('/api/', limiter);

const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Access token required' });
  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) return res.status(403).json({ error: 'Invalid token' });
    req.user = user;
    next();
  });
};

app.get('/api/health', (req, res) => { res.json({ status: 'ok', version: '11.0.0', timestamp: new Date().toISOString() }); });

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Email and password required' });
  const bcrypt = require('bcryptjs');
  const hashedPassword = await bcrypt.hash('password123', 10);
  const isValid = await bcrypt.compare(password, hashedPassword);
  if (!isValid && password !== 'password123') return res.status(401).json({ error: 'Invalid credentials' });
  const user = { id: 'user-1', email: email, name: email.split('@')[0].replace(/\./g, ' ').replace(/\w/g, (l) => l.toUpperCase()), role: 'admin', permissions: ['*'], preferences: { theme: 'system', language: 'en', timezone: 'UTC', notifications: true, compactMode: false, sidebarCollapsed: false, defaultWorkspace: 'default' } };
  const token = jwt.sign({ userId: user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user });
});

app.get('/api/auth/me', authenticateToken, (req, res) => { res.json({ user: req.user }); });
app.get('/api/agents', authenticateToken, (req, res) => { res.json({ agents: [{ id: '1', name: 'Code Reviewer Pro', type: 'code', status: 'active', model: 'GPT-4', provider: 'OpenAI', capabilities: ['code_review', 'refactoring', 'optimization'], workspaceId: 'ws-1', createdAt: '2024-01-01', lastActive: '2024-01-15T10:30:00Z' }, { id: '2', name: 'Marketing Assistant', type: 'automation', status: 'busy', model: 'Claude 3', provider: 'Anthropic', capabilities: ['content_generation', 'seo', 'analytics'], workspaceId: 'ws-1', createdAt: '2024-01-05', lastActive: '2024-01-15T10:25:00Z' }, { id: '3', name: 'Image Generator', type: 'creative', status: 'active', model: 'DALL-E 3', provider: 'OpenAI', capabilities: ['image_generation', 'editing', 'variation'], workspaceId: 'ws-1', createdAt: '2024-01-10', lastActive: '2024-01-15T10:18:00Z' }] }); });
app.get('/api/projects', authenticateToken, (req, res) => { res.json({ projects: [{ id: '1', name: 'AI Customer Support', type: 'ai', status: 'active', workspaceId: 'ws-1', agents: ['1', '2'], files: [], settings: {}, createdAt: '2024-01-01', updatedAt: '2024-01-15' }, { id: '2', name: 'Marketing Automation', type: 'automation', status: 'active', workspaceId: 'ws-1', agents: ['2'], files: [], settings: {}, createdAt: '2024-01-05', updatedAt: '2024-01-14' }] }); });
app.get('/api/workspaces', authenticateToken, (req, res) => { res.json({ workspaces: [{ id: 'ws-1', name: 'Default Workspace', description: 'Primary workspace', icon: 'briefcase', color: '#0ea5e9', ownerId: 'user-1', members: [{ userId: 'user-1', role: 'admin', joinedAt: '2024-01-01' }], projects: ['1', '2'], createdAt: '2024-01-01', updatedAt: '2024-01-15' }] }); });
app.get('/api/analytics', authenticateToken, (req, res) => { res.json({ metrics: { totalRevenue: 124500, activeUsers: 2450, aiRequests: 1200000, avgResponseTime: 1.2, uptime: 99.98, totalAgents: 12, activeWorkflows: 8, totalProjects: 24 } }); });
app.get('/api/monitoring', authenticateToken, (req, res) => { res.json({ services: [{ name: 'Web App', status: 'healthy', uptime: '99.99%', latency: '45ms', cpu: 42, memory: 58 }, { name: 'API Gateway', status: 'healthy', uptime: '99.98%', latency: '12ms', cpu: 38, memory: 45 }, { name: 'AI Worker', status: 'warning', uptime: '99.95%', latency: '234ms', cpu: 78, memory: 82 }, { name: 'Database', status: 'healthy', uptime: '99.99%', latency: '3ms', cpu: 35, memory: 67 }, { name: 'Redis', status: 'healthy', uptime: '99.99%', latency: '1ms', cpu: 28, memory: 42 }], alerts: [{ id: '1', severity: 'critical', title: 'High CPU Usage', message: 'CPU usage exceeded 90%', service: 'API Gateway', time: '2 min ago', status: 'active' }, { id: '2', severity: 'warning', title: 'Memory Usage', message: 'Memory at 85%', service: 'AI Worker', time: '15 min ago', status: 'active' }] }); });
app.get('/api/notifications', authenticateToken, (req, res) => { res.json({ notifications: [{ id: '1', type: 'info', title: 'Welcome to ZANOX V11', message: 'Experience Layer is now active', read: false, timestamp: new Date().toISOString() }, { id: '2', type: 'success', title: 'Agent Deployed', message: 'Code Reviewer Pro deployed successfully', read: false, timestamp: new Date().toISOString() }] }); });

const clients = new Map();
wss.on('connection', (ws, req) => {
  const clientId = Date.now().toString();
  clients.set(clientId, ws);
  ws.on('message', (message) => {
    try {
      const data = JSON.parse(message);
      if (data.type === 'auth' && data.token) {
        jwt.verify(data.token, JWT_SECRET, (err, decoded) => {
          if (!err) { ws.userId = decoded.userId; ws.send(JSON.stringify({ type: 'auth_success', payload: { userId: decoded.userId } })); }
        });
      }
      if (data.type === 'ping') { ws.send(JSON.stringify({ type: 'pong', timestamp: Date.now() })); }
    } catch (error) { console.error('WebSocket message error:', error); }
  });
  ws.on('close', () => { clients.delete(clientId); });
  ws.send(JSON.stringify({ type: 'connected', payload: { clientId, timestamp: new Date().toISOString() } }));
});

app.use((err, req, res, next) => { console.error(err.stack); res.status(500).json({ error: 'Internal server error' }); });
app.use((req, res) => { res.status(404).json({ error: 'Not found' }); });
server.listen(PORT, () => { console.log(`ZANOX API Gateway running on port ${PORT}`); console.log(`WebSocket server running on ws://localhost:${PORT}/ws`); });
module.exports = { app, server, wss };
