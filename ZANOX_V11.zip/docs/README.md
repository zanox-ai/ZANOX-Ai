# ZANOX V11 Experience Layer

## Overview
ZANOX V11 transforms the backend operating system into a complete end-user platform with web, desktop, and mobile applications.

## Architecture
- **Web App**: Next.js 14, React, TypeScript, TailwindCSS
- **Desktop App**: Electron with auto-updater
- **Mobile App**: React Native with cross-platform support
- **API Gateway**: Express.js with WebSocket support
- **Database**: PostgreSQL with Prisma ORM
- **Cache**: Redis for sessions and real-time data
- **Infrastructure**: Docker, Kubernetes, Nginx

## Quick Start

### Development
```bash
pnpm install
docker-compose up -d postgres redis
pnpm --filter api_gateway dev
pnpm --filter web_app dev
pnpm --filter desktop_app start
pnpm --filter mobile_app ios
```

### Production
```bash
pnpm build
docker-compose up -d
kubectl apply -f k8s/
```

## Features
- Unified Dashboard with real-time metrics
- Multi-AI Chat (GPT-4, Claude, Gemini, Kimi, etc.)
- Visual Workflow Builder
- Agent Management Center
- Creative Content Generation
- Game Development Tools
- Business Operating System (CRM, ERP, Marketing)
- File and Asset Management
- Team Collaboration
- Security Center with 2FA
- Deployment Management
- System Monitoring
- Marketplace

## API Endpoints
- GET /api/health - Health check
- POST /api/auth/login - Authentication
- GET /api/agents - List agents
- GET /api/projects - List projects
- GET /api/analytics - Analytics data
- GET /api/monitoring - System metrics
- WS /ws - WebSocket for real-time updates

## License
Proprietary - ZANOX Digital Marketplace
