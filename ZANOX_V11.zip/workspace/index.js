module.exports = {
  WorkspaceManager: class {
    constructor() { this.workspaces = new Map(); }
    create(data) { const id = Date.now().toString(); this.workspaces.set(id, { ...data, id, createdAt: new Date() }); return id; }
    get(id) { return this.workspaces.get(id); }
    update(id, data) { const ws = this.workspaces.get(id); if (ws) { this.workspaces.set(id, { ...ws, ...data, updatedAt: new Date() }); } }
    delete(id) { this.workspaces.delete(id); }
    list() { return Array.from(this.workspaces.values()); }
  }
};
