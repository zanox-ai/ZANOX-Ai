"""Asset Library for Nexus Core V7.

Central repository for all creative assets.
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

logger = logging.getLogger(__name__)


class AssetStatus(Enum):
    DRAFT = "draft"
    REVIEWING = "reviewing"
    APPROVED = "approved"
    PUBLISHED = "published"
    ARCHIVED = "archived"
    REJECTED = "rejected"


@dataclass
class CreativeAsset:
    """A creative asset in the library."""
    asset_id: str
    name: str
    asset_type: str
    format: str
    url: str
    path: str
    project_id: Optional[str] = None
    brand_id: Optional[str] = None
    tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    status: AssetStatus = AssetStatus.DRAFT
    quality_score: float = 0.0
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    created_by: str = "system"
    version: int = 1
    parent_id: Optional[str] = None


class AssetLibrary:
    """Library for managing creative assets."""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._assets: Dict[str, CreativeAsset] = {}
        self._project_index: Dict[str, List[str]] = {}
        self._brand_index: Dict[str, List[str]] = {}
        self._type_index: Dict[str, List[str]] = {}
        self._tag_index: Dict[str, List[str]] = {}
        self._lock = asyncio.Lock()

    async def store_asset(self, name: str, asset_type: str, format: str,
                         url: str, path: str, **kwargs) -> CreativeAsset:
        """Store a new asset in the library."""
        asset_id = f"asset:{datetime.now().isoformat()}"

        asset = CreativeAsset(
            asset_id=asset_id,
            name=name,
            asset_type=asset_type,
            format=format,
            url=url,
            path=path,
            project_id=kwargs.get("project_id"),
            brand_id=kwargs.get("brand_id"),
            tags=kwargs.get("tags", []),
            metadata=kwargs.get("metadata", {}),
            status=AssetStatus.DRAFT,
            quality_score=kwargs.get("quality_score", 0.0),
            created_by=kwargs.get("created_by", "system"),
        )

        async with self._lock:
            self._assets[asset_id] = asset

            if asset.project_id:
                if asset.project_id not in self._project_index:
                    self._project_index[asset.project_id] = []
                self._project_index[asset.project_id].append(asset_id)

            if asset.brand_id:
                if asset.brand_id not in self._brand_index:
                    self._brand_index[asset.brand_id] = []
                self._brand_index[asset.brand_id].append(asset_id)

            if asset_type not in self._type_index:
                self._type_index[asset_type] = []
            self._type_index[asset_type].append(asset_id)

            for tag in asset.tags:
                if tag not in self._tag_index:
                    self._tag_index[tag] = []
                self._tag_index[tag].append(asset_id)

        logger.info(f"Stored asset: {name} ({asset_id})")
        return asset

    async def get_asset(self, asset_id: str) -> Optional[CreativeAsset]:
        """Get an asset by ID."""
        return self._assets.get(asset_id)

    async def update_asset(self, asset_id: str, updates: Dict[str, Any]) -> bool:
        """Update an asset."""
        async with self._lock:
            if asset_id not in self._assets:
                return False

            asset = self._assets[asset_id]

            if "name" in updates:
                asset.name = updates["name"]
            if "status" in updates:
                asset.status = AssetStatus(updates["status"]) if isinstance(updates["status"], str) else updates["status"]
            if "tags" in updates:
                asset.tags = updates["tags"]
            if "metadata" in updates:
                asset.metadata.update(updates["metadata"])
            if "quality_score" in updates:
                asset.quality_score = updates["quality_score"]

            asset.updated_at = datetime.now()
            return True

    async def list_assets(self, project_id: Optional[str] = None,
                         asset_type: Optional[str] = None,
                         status: Optional[AssetStatus] = None,
                         tags: Optional[List[str]] = None) -> List[CreativeAsset]:
        """List assets with filters."""
        assets = list(self._assets.values())

        if project_id:
            asset_ids = self._project_index.get(project_id, [])
            assets = [a for a in assets if a.asset_id in asset_ids]

        if asset_type:
            asset_ids = self._type_index.get(asset_type, [])
            assets = [a for a in assets if a.asset_id in asset_ids]

        if status:
            assets = [a for a in assets if a.status == status]

        if tags:
            assets = [a for a in assets if any(t in a.tags for t in tags)]

        return assets

    async def delete_asset(self, asset_id: str) -> bool:
        """Delete an asset."""
        async with self._lock:
            if asset_id not in self._assets:
                return False

            asset = self._assets[asset_id]

            # Remove from indexes
            if asset.project_id and asset.project_id in self._project_index:
                self._project_index[asset.project_id] = [a for a in self._project_index[asset.project_id] if a != asset_id]

            if asset.brand_id and asset.brand_id in self._brand_index:
                self._brand_index[asset.brand_id] = [a for a in self._brand_index[asset.brand_id] if a != asset_id]

            if asset.asset_type in self._type_index:
                self._type_index[asset.asset_type] = [a for a in self._type_index[asset.asset_type] if a != asset_id]

            for tag in asset.tags:
                if tag in self._tag_index:
                    self._tag_index[tag] = [a for a in self._tag_index[tag] if a != asset_id]

            del self._assets[asset_id]

        logger.info(f"Deleted asset {asset_id}")
        return True

    def get_stats(self) -> Dict[str, Any]:
        """Get library statistics."""
        statuses = {}
        for asset in self._assets.values():
            statuses[asset.status.value] = statuses.get(asset.status.value, 0) + 1

        return {
            "assets": len(self._assets),
            "projects": len(self._project_index),
            "brands": len(self._brand_index),
            "types": len(self._type_index),
            "tags": len(self._tag_index),
            "statuses": statuses,
        }
