"""Creative Workflow Engine for Nexus Core V7.

Manages creative production workflows and pipelines.
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import uuid

logger = logging.getLogger(__name__)


class WorkflowStatus(Enum):
    DRAFT = "draft"
    PENDING = "pending"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    REVIEWING = "reviewing"
    PUBLISHING = "publishing"


class StageStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"
    REVIEWING = "reviewing"
    APPROVED = "approved"
    REJECTED = "rejected"


@dataclass
class WorkflowStage:
    stage_id: str
    name: str
    capability_id: str
    agent_id: Optional[str] = None
    provider_id: Optional[str] = None
    dependencies: List[str] = field(default_factory=list)
    parameters: Dict[str, Any] = field(default_factory=dict)
    status: StageStatus = StageStatus.PENDING
    output: Optional[Dict] = None
    error: Optional[str] = None
    review_required: bool = False
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    duration_ms: float = 0.0


@dataclass
class CreativeWorkflow:
    workflow_id: str
    project_id: str
    name: str
    stages: List[WorkflowStage] = field(default_factory=list)
    status: WorkflowStatus = WorkflowStatus.DRAFT
    created_at: datetime = field(default_factory=datetime.now)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    parallel_execution: bool = True
    auto_retry: bool = True
    max_retries: int = 3
    quality_threshold: float = 0.7


class CreativeWorkflowEngine:
    def __init__(self, routing_engine, agent_registry, config: Optional[Dict] = None):
        self.config = config or {}
        self._routing_engine = routing_engine
        self._agent_registry = agent_registry
        self._workflows: Dict[str, CreativeWorkflow] = {}
        self._active_executions: Dict[str, asyncio.Task] = {}
        self._lock = asyncio.Lock()

    async def create_workflow(self, project_id: str, name: str, stages: List[Dict], **kwargs) -> CreativeWorkflow:
        workflow_id = f"wf:{uuid.uuid4().hex[:8]}"
        workflow_stages = []
        for i, stage_def in enumerate(stages):
            stage = WorkflowStage(
                stage_id=f"stage:{workflow_id}:{i}",
                name=stage_def["name"],
                capability_id=stage_def["capability_id"],
                dependencies=stage_def.get("dependencies", []),
                parameters=stage_def.get("parameters", {}),
                review_required=stage_def.get("review_required", False),
            )
            workflow_stages.append(stage)

        workflow = CreativeWorkflow(
            workflow_id=workflow_id, project_id=project_id, name=name,
            stages=workflow_stages, parallel_execution=kwargs.get("parallel_execution", True),
            auto_retry=kwargs.get("auto_retry", True), max_retries=kwargs.get("max_retries", 3),
            quality_threshold=kwargs.get("quality_threshold", 0.7), metadata=kwargs.get("metadata", {}),
        )

        async with self._lock:
            self._workflows[workflow_id] = workflow

        logger.info(f"Created workflow: {name} ({workflow_id}) with {len(stages)} stages")
        return workflow

    async def execute_workflow(self, workflow_id: str) -> bool:
        async with self._lock:
            if workflow_id not in self._workflows:
                return False
            workflow = self._workflows[workflow_id]
            if workflow.status in [WorkflowStatus.RUNNING, WorkflowStatus.COMPLETED]:
                return False
            workflow.status = WorkflowStatus.RUNNING
            workflow.started_at = datetime.now()

        try:
            if workflow.parallel_execution:
                await self._execute_parallel(workflow)
            else:
                await self._execute_sequential(workflow)

            async with self._lock:
                workflow.status = WorkflowStatus.COMPLETED
                workflow.completed_at = datetime.now()

            logger.info(f"Workflow {workflow_id} completed successfully")
            return True
        except Exception as e:
            async with self._lock:
                workflow.status = WorkflowStatus.FAILED
            logger.error(f"Workflow {workflow_id} failed: {e}")
            return False

    async def _execute_sequential(self, workflow: CreativeWorkflow):
        for stage in workflow.stages:
            if stage.status == StageStatus.SKIPPED:
                continue
            await self._execute_stage(workflow, stage)
            if stage.status == StageStatus.FAILED and not workflow.auto_retry:
                raise Exception(f"Stage {stage.stage_id} failed")

    async def _execute_parallel(self, workflow: CreativeWorkflow):
        completed = set()
        failed = False

        while len(completed) < len(workflow.stages) and not failed:
            ready = []
            for stage in workflow.stages:
                if stage.status != StageStatus.PENDING:
                    if stage.status == StageStatus.COMPLETED:
                        completed.add(stage.stage_id)
                    continue
                deps_satisfied = all(
                    any(s.stage_id == dep and s.status in [StageStatus.COMPLETED, StageStatus.APPROVED] for s in workflow.stages)
                    for dep in stage.dependencies
                )
                if deps_satisfied:
                    ready.append(stage)

            if not ready:
                if len(completed) < len(workflow.stages):
                    failed = True
                break

            tasks = [self._execute_stage(workflow, stage) for stage in ready]
            await asyncio.gather(*tasks, return_exceptions=True)

        if failed:
            raise Exception("Workflow failed due to dependency issues or stage failures")

    async def _execute_stage(self, workflow: CreativeWorkflow, stage: WorkflowStage):
        stage.status = StageStatus.RUNNING
        stage.started_at = datetime.now()

        try:
            task_id = f"task:{stage.stage_id}"
            decision = await self._routing_engine.route_task(
                task_id=task_id, capability_id=stage.capability_id, parameters=stage.parameters,
            )

            stage.provider_id = decision.provider_id

            task_id = await self._agent_registry.assign_task(
                agent_id=decision.agent_id, project_id=workflow.project_id,
                capability_id=stage.capability_id, description=stage.name, parameters=stage.parameters,
            )

            await asyncio.sleep(0.1)

            await self._agent_registry.complete_task(
                task_id=task_id, result={"output": f"Generated {stage.name}", "quality_score": 0.85},
                success=True,
            )

            if stage.review_required:
                stage.status = StageStatus.REVIEWING
            else:
                stage.status = StageStatus.COMPLETED

            stage.output = {"task_id": task_id, "result": f"Generated {stage.name}", "provider_id": decision.provider_id}
            stage.completed_at = datetime.now()
            stage.duration_ms = (stage.completed_at - stage.started_at).total_seconds() * 1000

        except Exception as e:
            stage.status = StageStatus.FAILED
            stage.error = str(e)
            logger.error(f"Stage {stage.stage_id} failed: {e}")

    async def approve_stage(self, workflow_id: str, stage_id: str) -> bool:
        async with self._lock:
            if workflow_id not in self._workflows:
                return False
            workflow = self._workflows[workflow_id]
            for stage in workflow.stages:
                if stage.stage_id == stage_id and stage.status == StageStatus.REVIEWING:
                    stage.status = StageStatus.APPROVED
                    return True
            return False

    async def reject_stage(self, workflow_id: str, stage_id: str, reason: str) -> bool:
        async with self._lock:
            if workflow_id not in self._workflows:
                return False
            workflow = self._workflows[workflow_id]
            for stage in workflow.stages:
                if stage.stage_id == stage_id and stage.status == StageStatus.REVIEWING:
                    stage.status = StageStatus.REJECTED
                    stage.error = reason
                    return True
            return False

    async def get_workflow(self, workflow_id: str) -> Optional[CreativeWorkflow]:
        return self._workflows.get(workflow_id)

    async def cancel_workflow(self, workflow_id: str) -> bool:
        async with self._lock:
            if workflow_id not in self._workflows:
                return False
            workflow = self._workflows[workflow_id]
            if workflow.status != WorkflowStatus.RUNNING:
                return False
            workflow.status = WorkflowStatus.CANCELLED
            if workflow_id in self._active_executions:
                self._active_executions[workflow_id].cancel()
        logger.info(f"Workflow {workflow_id} cancelled")
        return True

    def get_stats(self) -> Dict[str, Any]:
        statuses = {}
        for wf in self._workflows.values():
            statuses[wf.status.value] = statuses.get(wf.status.value, 0) + 1
        return {"workflows": len(self._workflows), "active_executions": len(self._active_executions), "statuses": statuses}
