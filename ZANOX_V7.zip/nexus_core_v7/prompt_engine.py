"""Prompt Engineering System for Nexus Core V7.

Manages prompt creation, optimization, and templating for all creative domains.
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
import re

logger = logging.getLogger(__name__)


@dataclass
class PromptTemplate:
    """A prompt template for creative generation."""
    template_id: str
    name: str
    domain: str
    template_text: str
    variables: List[str] = field(default_factory=list)
    examples: List[str] = field(default_factory=list)
    negative_prompt: str = ""
    parameters: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.now)
    usage_count: int = 0
    avg_quality: float = 0.0


@dataclass
class PromptResult:
    """Result of prompt processing."""
    result_id: str
    final_prompt: str
    negative_prompt: str
    parameters: Dict[str, Any]
    estimated_tokens: int
    complexity_score: float
    quality_estimate: float


class PromptEngineeringSystem:
    """Engineers and optimizes prompts for creative AI."""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._templates: Dict[str, PromptTemplate] = {}
        self._domain_patterns: Dict[str, List[str]] = {}
        self._style_keywords: Dict[str, List[str]] = {}
        self._lock = asyncio.Lock()
        self._initialize_patterns()

    def _initialize_patterns(self):
        """Initialize domain-specific prompt patterns."""
        self._domain_patterns = {
            "image_generation": [
                "masterpiece, best quality, highly detailed",
                "professional photography, 8k uhd, sharp focus",
                "digital art, trending on artstation, cinematic lighting",
            ],
            "logo_design": [
                "minimalist logo design, vector style, clean lines",
                "professional brand mark, scalable, monochrome",
                "modern geometric logo, flat design, memorable",
            ],
            "ui_design": [
                "modern UI design, clean interface, intuitive",
                "mobile app design, iOS guidelines, material design",
                "dashboard UI, data visualization, dark mode",
            ],
            "video_generation": [
                "cinematic shot, smooth camera movement, high quality",
                "professional video, color graded, 4k resolution",
                "dynamic motion, dramatic lighting, film grain",
            ],
            "music_generation": [
                "high quality audio, professional production, mastered",
                "catchy melody, rich harmonies, full arrangement",
                "studio recording, balanced mix, polished sound",
            ],
            "voice_generation": [
                "natural speech, clear pronunciation, emotional tone",
                "professional narration, consistent pacing, warm voice",
                "broadcast quality, noise-free, crisp articulation",
            ],
            "3d_generation": [
                "high poly model, clean topology, PBR textures",
                "detailed 3D asset, optimized geometry, UV mapped",
                "photorealistic render, accurate proportions, game-ready",
            ],
        }

        self._style_keywords = {
            "photorealistic": ["photorealistic", "hyperrealistic", "lifelike", "8k uhd"],
            "artistic": ["digital art", "oil painting", "watercolor", "concept art"],
            "minimalist": ["minimalist", "clean", "simple", "elegant"],
            "vibrant": ["vibrant colors", "saturated", "colorful", "bold"],
            "dark": ["dark atmosphere", "moody", "dramatic lighting", "noir"],
            "futuristic": ["futuristic", "sci-fi", "cyberpunk", "high-tech"],
            "vintage": ["vintage", "retro", "classic", "nostalgic"],
            "professional": ["professional", "corporate", "business", "polished"],
        }

        logger.info("Initialized prompt engineering patterns")

    async def create_prompt(self, domain: str, base_description: str,
                           style: Optional[str] = None,
                           technical_specs: Optional[Dict] = None,
                           brand_guidelines: Optional[Dict] = None) -> PromptResult:
        """Create an optimized prompt for a creative task."""
        # Build the prompt
        components = []

        # Add domain quality boosters
        if domain in self._domain_patterns:
            components.append(self._domain_patterns[domain][0])

        # Add base description
        components.append(base_description)

        # Add style keywords
        if style and style in self._style_keywords:
            components.append(", ".join(self._style_keywords[style][:2]))

        # Add technical specifications
        if technical_specs:
            tech_parts = []
            if "resolution" in technical_specs:
                tech_parts.append(f"{technical_specs['resolution']}")
            if "aspect_ratio" in technical_specs:
                tech_parts.append(f"aspect ratio {technical_specs['aspect_ratio']}")
            if "format" in technical_specs:
                tech_parts.append(f"format {technical_specs['format']}")
            if tech_parts:
                components.append(", ".join(tech_parts))

        # Add brand guidelines
        if brand_guidelines:
            brand_parts = []
            if "colors" in brand_guidelines:
                brand_parts.append(f"brand colors: {brand_guidelines['colors']}")
            if "tone" in brand_guidelines:
                brand_parts.append(f"brand tone: {brand_guidelines['tone']}")
            if brand_parts:
                components.append(", ".join(brand_parts))

        final_prompt = ", ".join(components)

        # Calculate metrics
        estimated_tokens = len(final_prompt.split()) * 1.3
        complexity_score = min(1.0, len(final_prompt) / 500)
        quality_estimate = 0.7 + (0.1 if style else 0) + (0.1 if technical_specs else 0) + (0.1 if brand_guidelines else 0)

        return PromptResult(
            result_id=f"prompt:{datetime.now().isoformat()}",
            final_prompt=final_prompt,
            negative_prompt="low quality, blurry, distorted, watermark, signature, text, error, cropped, worst quality",
            parameters=technical_specs or {},
            estimated_tokens=int(estimated_tokens),
            complexity_score=complexity_score,
            quality_estimate=min(1.0, quality_estimate),
        )

    async def enhance_prompt(self, base_prompt: str, enhancement_level: str = "standard") -> str:
        """Enhance an existing prompt."""
        enhancements = {
            "minimal": "detailed, clear",
            "standard": "highly detailed, professional quality, best lighting",
            "premium": "masterpiece, best quality, ultra-detailed, 8k uhd, professional photography, perfect composition",
            "cinematic": "cinematic shot, dramatic lighting, film grain, anamorphic lens, color graded, blockbuster quality",
        }

        enhancer = enhancements.get(enhancement_level, enhancements["standard"])
        return f"{enhancer}, {base_prompt}"

    async def create_template(self, name: str, domain: str, template_text: str,
                             variables: List[str], **kwargs) -> PromptTemplate:
        """Create a reusable prompt template."""
        template = PromptTemplate(
            template_id=f"template:{name}:{datetime.now().isoformat()}",
            name=name,
            domain=domain,
            template_text=template_text,
            variables=variables,
            examples=kwargs.get("examples", []),
            negative_prompt=kwargs.get("negative_prompt", ""),
            parameters=kwargs.get("parameters", {}),
        )

        async with self._lock:
            self._templates[template.template_id] = template

        logger.info(f"Created prompt template: {name}")
        return template

    async def apply_template(self, template_id: str, variable_values: Dict[str, str]) -> str:
        """Apply a template with variable values."""
        template = self._templates.get(template_id)
        if not template:
            raise ValueError(f"Template {template_id} not found")

        result = template.template_text
        for var, value in variable_values.items():
            result = result.replace(f"{{{var}}}", value)

        template.usage_count += 1

        return result

    async def extract_keywords(self, prompt: str) -> List[str]:
        """Extract keywords from a prompt."""
        # Simple keyword extraction
        words = re.findall(r'\w+', prompt.lower())
        # Filter common words
        stop_words = {"the", "a", "an", "and", "or", "but", "in", "on", "at", "to", "for", "of", "with", "by"}
        keywords = [w for w in words if w not in stop_words and len(w) > 3]
        return list(set(keywords))[:20]

    def get_stats(self) -> Dict[str, Any]:
        return {
            "templates": len(self._templates),
            "domains": len(self._domain_patterns),
            "style_categories": len(self._style_keywords),
        }
