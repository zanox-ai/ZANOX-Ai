"""Creative Analytics for Nexus Core V7."""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
from collections import defaultdict

logger = logging.getLogger(__name__)

@dataclass
class AnalyticsEvent:
    event_id: str
    event_type: str
    timestamp: datetime
    data: Dict[str, Any] = field(default_factory=dict)
    user_id: Optional[str] = None
    session_id: Optional[str] = None

class CreativeAnalytics:
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._events: List[AnalyticsEvent] = []
        self._metrics: Dict[str, List[float]] = defaultdict(list)
        self._lock = asyncio.Lock()

    async def track_event(self, event_type: str, data: Dict[str, Any], user_id: Optional[str] = None, session_id: Optional[str] = None):
        event = AnalyticsEvent(
            event_id=f"evt:{datetime.now().isoformat()}", event_type=event_type,
            timestamp=datetime.now(), data=data, user_id=user_id, session_id=session_id,
        )
        async with self._lock:
            self._events.append(event)
            if len(self._events) > 100000:
                self._events = self._events[-50000:]
        logger.debug(f"Tracked event: {event_type}")

    async def track_generation(self, capability_id: str, provider_id: str, duration_ms: float, success: bool, quality_score: float):
        await self.track_event("generation", {"capability_id": capability_id, "provider_id": provider_id, "duration_ms": duration_ms, "success": success, "quality_score": quality_score})
        async with self._lock:
            self._metrics["generation_duration"].append(duration_ms)
            self._metrics["quality_scores"].append(quality_score)

    async def get_dashboard(self, time_range: str = "24h") -> Dict[str, Any]:
        now = datetime.now()
        if time_range == "24h":
            cutoff = now.timestamp() - 86400
        elif time_range == "7d":
            cutoff = now.timestamp() - 604800
        elif time_range == "30d":
            cutoff = now.timestamp() - 2592000
        else:
            cutoff = 0
        recent_events = [e for e in self._events if e.timestamp.timestamp() > cutoff]
        generations = [e for e in recent_events if e.event_type == "generation"]
        successes = sum(1 for e in generations if e.data.get("success", False))
        avg_duration = sum(e.data.get("duration_ms", 0) for e in generations) / max(1, len(generations))
        avg_quality = sum(e.data.get("quality_score", 0) for e in generations) / max(1, len(generations))
        provider_stats = defaultdict(lambda: {"count": 0, "success": 0})
        for e in generations:
            pid = e.data.get("provider_id", "unknown")
            provider_stats[pid]["count"] += 1
            if e.data.get("success"):
                provider_stats[pid]["success"] += 1
        return {"time_range": time_range, "total_events": len(recent_events), "generations": len(generations), "success_rate": successes / max(1, len(generations)), "avg_duration_ms": avg_duration, "avg_quality_score": avg_quality, "provider_breakdown": dict(provider_stats)}

    def get_stats(self) -> Dict[str, Any]:
        return {"total_events": len(self._events), "metrics_tracked": len(self._metrics)}
