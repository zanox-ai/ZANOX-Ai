"""Template Manager for Nexus Core V7.

Manages creative templates and reusable designs.
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime

logger = logging.getLogger(__name__)


@dataclass
class CreativeTemplate:
    """A creative template."""
    template_id: str
    name: str
    template_type: str
    domain: str
    format: str
    content: Dict[str, Any] = field(default_factory=dict)
    variables: List[str] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    usage_count: int = 0
    avg_rating: float = 0.0
    created_at: datetime = field(default_factory=datetime.now)
    created_by: str = "system"


class TemplateManager:
    """Manager for creative templates."""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._templates: Dict[str, CreativeTemplate] = {}
        self._domain_index: Dict[str, List[str]] = {}
        self._type_index: Dict[str, List[str]] = {}
        self._lock = asyncio.Lock()

    async def create_template(self, name: str, template_type: str,
                             domain: str, format: str,
                             content: Dict[str, Any],
                             variables: List[str],
                             **kwargs) -> CreativeTemplate:
        """Create a new template."""
        template_id = f"tmpl:{template_type}:{name.lower().replace(' ', '_')}"

        template = CreativeTemplate(
            template_id=template_id,
            name=name,
            template_type=template_type,
            domain=domain,
            format=format,
            content=content,
            variables=variables,
            tags=kwargs.get("tags", []),
            created_by=kwargs.get("created_by", "system"),
        )

        async with self._lock:
            self._templates[template_id] = template

            if domain not in self._domain_index:
                self._domain_index[domain] = []
            self._domain_index[domain].append(template_id)

            if template_type not in self._type_index:
                self._type_index[template_type] = []
            self._type_index[template_type].append(template_id)

        logger.info(f"Created template: {name} ({template_id})")
        return template

    async def get_template(self, template_id: str) -> Optional[CreativeTemplate]:
        """Get a template."""
        return self._templates.get(template_id)

    async def apply_template(self, template_id: str,
                            variable_values: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Apply a template with variable values."""
        template = self._templates.get(template_id)
        if not template:
            return None

        result = template.content.copy()

        # Replace variables
        def replace_vars(obj):
            if isinstance(obj, dict):
                return {k: replace_vars(v) for k, v in obj.items()}
            elif isinstance(obj, list):
                return [replace_vars(i) for i in obj]
            elif isinstance(obj, str):
                for var, val in variable_values.items():
                    obj = obj.replace(f"{{{var}}}", str(val))
                return obj
            return obj

        result = replace_vars(result)

        template.usage_count += 1

        return result

    async def list_templates(self, domain: Optional[str] = None,
                            template_type: Optional[str] = None) -> List[CreativeTemplate]:
        """List templates."""
        templates = list(self._templates.values())

        if domain:
            ids = self._domain_index.get(domain, [])
            templates = [t for t in templates if t.template_id in ids]

        if template_type:
            ids = self._type_index.get(template_type, [])
            templates = [t for t in templates if t.template_id in ids]

        return templates

    async def rate_template(self, template_id: str, rating: float):
        """Rate a template."""
        if template_id in self._templates:
            t = self._templates[template_id]
            t.avg_rating = (t.avg_rating * t.usage_count + rating) / (t.usage_count + 1)

    def get_stats(self) -> Dict[str, Any]:
        return {"templates": len(self._templates), "domains": len(self._domain_index), "types": len(self._type_index)}
