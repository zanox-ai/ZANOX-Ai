"""Creative Security Layer for Nexus Core V7."""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
import hashlib

logger = logging.getLogger(__name__)

class Permission(Enum):
    READ = "read"
    WRITE = "write"
    DELETE = "delete"
    PUBLISH = "publish"
    ADMIN = "admin"

@dataclass
class AccessPolicy:
    policy_id: str
    resource_type: str
    resource_id: str
    allowed_users: List[str]
    allowed_roles: List[str]
    permissions: List[Permission]
    created_at: datetime

class CreativeSecurityLayer:
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._policies: Dict[str, AccessPolicy] = {}
        self._user_roles: Dict[str, List[str]] = {}
        self._audit_log: List[Dict] = []
        self._lock = asyncio.Lock()

    async def create_policy(self, resource_type: str, resource_id: str, permissions: List[Permission], allowed_users: Optional[List[str]] = None, allowed_roles: Optional[List[str]] = None) -> AccessPolicy:
        policy_id = f"policy:{resource_type}:{resource_id}"
        policy = AccessPolicy(
            policy_id=policy_id, resource_type=resource_type, resource_id=resource_id,
            allowed_users=allowed_users or [], allowed_roles=allowed_roles or [],
            permissions=permissions, created_at=datetime.now(),
        )
        async with self._lock:
            self._policies[policy_id] = policy
        logger.info(f"Created policy: {policy_id}")
        return policy

    async def check_access(self, user_id: str, resource_type: str, resource_id: str, permission: Permission) -> bool:
        policy_id = f"policy:{resource_type}:{resource_id}"
        policy = self._policies.get(policy_id)
        if not policy:
            return False
        if user_id in policy.allowed_users:
            return permission in policy.permissions
        user_roles = self._user_roles.get(user_id, [])
        if any(r in policy.allowed_roles for r in user_roles):
            return permission in policy.permissions
        return False

    async def assign_role(self, user_id: str, role: str):
        async with self._lock:
            if user_id not in self._user_roles:
                self._user_roles[user_id] = []
            if role not in self._user_roles[user_id]:
                self._user_roles[user_id].append(role)

    async def log_access(self, user_id: str, action: str, resource_type: str, resource_id: str, success: bool):
        async with self._lock:
            self._audit_log.append({"timestamp": datetime.now().isoformat(), "user_id": user_id, "action": action, "resource_type": resource_type, "resource_id": resource_id, "success": success})
            if len(self._audit_log) > 100000:
                self._audit_log = self._audit_log[-50000:]

    async def hash_content(self, content: bytes) -> str:
        return hashlib.sha256(content).hexdigest()

    def get_stats(self) -> Dict[str, Any]:
        return {"policies": len(self._policies), "users": len(self._user_roles), "audit_entries": len(self._audit_log)}
