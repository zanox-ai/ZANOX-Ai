"""Creative Agent Registry for Nexus Core V7.

Manages specialized creative AI agents.
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import uuid

logger = logging.getLogger(__name__)


class AgentRole(Enum):
    DESIGNER = "designer"
    ILLUSTRATOR = "illustrator"
    ANIMATOR = "animator"
    VIDEO_EDITOR = "video_editor"
    SOUND_DESIGNER = "sound_designer"
    MUSICIAN = "musician"
    WRITER = "writer"
    PHOTOGRAPHER = "photographer"
    MODELER = "modeler"
    COMPOSITOR = "compositor"
    DIRECTOR = "director"
    STRATEGIST = "strategist"
    VOICE_ARTIST = "voice_artist"
    AUDIO_ENGINEER = "audio_engineer"
    PRESENTATION_DESIGNER = "presentation_designer"
    DOCUMENT_SPECIALIST = "document_specialist"
    CONTENT_STRATEGIST = "content_strategist"
    BRAND_MANAGER = "brand_manager"
    UX_RESEARCHER = "ux_researcher"


class AgentStatus(Enum):
    IDLE = "idle"
    BUSY = "busy"
    TRAINING = "training"
    OFFLINE = "offline"
    ERROR = "error"


@dataclass
class CreativeAgent:
    """A creative AI agent."""
    agent_id: str
    name: str
    role: AgentRole
    capabilities: List[str] = field(default_factory=list)
    models: List[str] = field(default_factory=list)
    tools: List[str] = field(default_factory=list)
    status: AgentStatus = AgentStatus.IDLE
    current_task: Optional[str] = None
    completed_tasks: int = 0
    success_rate: float = 1.0
    quality_score: float = 0.8
    speed_score: float = 0.8
    cost_efficiency: float = 0.8
    created_at: datetime = field(default_factory=datetime.now)
    last_active: datetime = field(default_factory=datetime.now)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class AgentTask:
    """A task assigned to an agent."""
    task_id: str
    agent_id: str
    project_id: str
    capability_id: str
    description: str
    parameters: Dict[str, Any] = field(default_factory=dict)
    status: str = "pending"
    priority: int = 5
    created_at: datetime = field(default_factory=datetime.now)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    result: Optional[Dict] = None
    error: Optional[str] = None


class CreativeAgentRegistry:
    """Registry for managing creative AI agents."""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._agents: Dict[str, CreativeAgent] = {}
        self._tasks: Dict[str, AgentTask] = {}
        self._role_index: Dict[AgentRole, List[str]] = {r: [] for r in AgentRole}
        self._lock = asyncio.Lock()
        self._initialize_default_agents()

    def _initialize_default_agents(self):
        """Initialize default creative agents."""
        defaults = [
            CreativeAgent(agent_id="agent:designer:001", name="Visual Designer", role=AgentRole.DESIGNER,
                capabilities=["cap:graphic:design", "cap:ui:design", "cap:poster:design", "cap:banner:design", "cap:landing:page"],
                models=["dalle-3", "midjourney", "claude", "flux"], tools=["figma", "photoshop", "illustrator", "canva"]),
            CreativeAgent(agent_id="agent:illustrator:001", name="AI Illustrator", role=AgentRole.ILLUSTRATOR,
                capabilities=["cap:logo:design", "cap:brand:identity", "cap:image:gen", "cap:illustration", "cap:concept:art"],
                models=["dalle-3", "midjourney", "stable-diffusion", "flux", "ideogram"], tools=["illustrator", "vectorizer", "photoshop", "procreate"]),
            CreativeAgent(agent_id="agent:animator:001", name="Motion Animator", role=AgentRole.ANIMATOR,
                capabilities=["cap:animation", "cap:motion:graphics", "cap:2d:animation", "cap:3d:animation"],
                models=["runway", "pika", "kaiber"], tools=["after-effects", "blender", "cinema-4d", "toon-boom"]),
            CreativeAgent(agent_id="agent:video:001", name="Video Producer", role=AgentRole.VIDEO_EDITOR,
                capabilities=["cap:video:gen", "cap:video:edit", "cap:video:enhance", "cap:short:video", "cap:long:video"],
                models=["sora", "runway", "pika", "luma", "kling"], tools=["premiere", "davinci", "final-cut", "capcut"]),
            CreativeAgent(agent_id="agent:sound:001", name="Sound Designer", role=AgentRole.SOUND_DESIGNER,
                capabilities=["cap:sound:design", "cap:audio:enhance", "cap:audio:restore"],
                models=["elevenlabs", "stable-audio"], tools=["pro-tools", "audition", "reaper", "izotope"]),
            CreativeAgent(agent_id="agent:music:001", name="AI Composer", role=AgentRole.MUSICIAN,
                capabilities=["cap:music:gen", "cap:song:gen", "cap:bg:music", "cap:instrumental"],
                models=["suno", "udio", "aiva", "soundraw"], tools=["ableton", "fl-studio", "logic", "garageband"]),
            CreativeAgent(agent_id="agent:writer:001", name="Content Writer", role=AgentRole.WRITER,
                capabilities=["cap:content", "cap:document", "cap:presentation", "cap:blog", "cap:marketing:copy"],
                models=["claude", "gpt-4o", "gemini", "kimi"], tools=["notion", "word", "google-docs"]),
            CreativeAgent(agent_id="agent:modeler:001", name="3D Modeler", role=AgentRole.MODELER,
                capabilities=["cap:3d:model", "cap:3d:asset", "cap:3d:character", "cap:3d:environment"],
                models=["meshy", "tripo", "rodin", "spline"], tools=["blender", "maya", "zbrush", "unreal"]),
            CreativeAgent(agent_id="agent:director:001", name="Creative Director", role=AgentRole.DIRECTOR,
                capabilities=["cap:brand:identity", "cap:marketing:design", "cap:product:cover", "cap:advertising:design"],
                models=["claude", "gpt-4o", "dalle-3"], tools=["figma", "indesign", "photoshop"]),
            CreativeAgent(agent_id="agent:strategist:001", name="Brand Strategist", role=AgentRole.STRATEGIST,
                capabilities=["cap:brand:identity", "cap:social:media", "cap:marketing:design", "cap:content"],
                models=["claude", "gpt-4o"], tools=["figma", "canva", "notion"]),
            CreativeAgent(agent_id="agent:voice:001", name="Voice Artist", role=AgentRole.VOICE_ARTIST,
                capabilities=["cap:voice:gen", "cap:voice:clone", "cap:voice:convert", "cap:narration", "cap:podcast", "cap:speech:synth"],
                models=["elevenlabs", "playht", "cartesia", "azure-tts"], tools=["audition", "reaper"]),
            CreativeAgent(agent_id="agent:audio:001", name="Audio Engineer", role=AgentRole.AUDIO_ENGINEER,
                capabilities=["cap:audio:enhance", "cap:audio:restore", "cap:audio:mix", "cap:sound:design"],
                models=["elevenlabs", "stable-audio"], tools=["pro-tools", "logic", "ableton", "izotope"]),
            CreativeAgent(agent_id="agent:preso:001", name="Presentation Designer", role=AgentRole.PRESENTATION_DESIGNER,
                capabilities=["cap:presentation", "cap:pitch:deck", "cap:biz:presentation"],
                models=["claude", "gpt-4o", "dalle-3", "gamma", "beautiful-ai"], tools=["powerpoint", "google-slides", "keynote", "gamma"]),
            CreativeAgent(agent_id="agent:doc:001", name="Document Specialist", role=AgentRole.DOCUMENT_SPECIALIST,
                capabilities=["cap:document", "cap:ebook", "cap:pdf:gen", "cap:report"],
                models=["claude", "gpt-4o", "gemini"], tools=["word", "indesign", "scrivener", "notion"]),
            CreativeAgent(agent_id="agent:content:001", name="Content Strategist", role=AgentRole.CONTENT_STRATEGIST,
                capabilities=["cap:content", "cap:blog", "cap:marketing:copy", "cap:social:media"],
                models=["claude", "gpt-4o", "gemini", "kimi"], tools=["notion", "wordpress", "medium"]),
            CreativeAgent(agent_id="agent:brand:001", name="Brand Manager", role=AgentRole.BRAND_MANAGER,
                capabilities=["cap:brand:identity", "cap:logo:design", "cap:packaging:design", "cap:product:cover"],
                models=["claude", "gpt-4o", "dalle-3"], tools=["figma", "illustrator", "indesign"]),
            CreativeAgent(agent_id="agent:ux:001", name="UX Researcher", role=AgentRole.UX_RESEARCHER,
                capabilities=["cap:ux:design", "cap:ui:design", "cap:landing:page"],
                models=["claude", "gpt-4o"], tools=["figma", "maze", "hotjar", "webflow"]),
            CreativeAgent(agent_id="agent:photo:001", name="Photo Editor", role=AgentRole.PHOTOGRAPHER,
                capabilities=["cap:photo:gen", "cap:photo:edit", "cap:image:upscale", "cap:image:restore", "cap:image:variations"],
                models=["dalle-3", "midjourney", "stable-diffusion", "flux"], tools=["photoshop", "lightroom", "capture-one", "topaz"]),
            CreativeAgent(agent_id="agent:3d:anim:001", name="3D Animator", role=AgentRole.ANIMATOR,
                capabilities=["cap:3d:animation", "cap:character:anim", "cap:3d:anim:asset"],
                models=["runway", "pika"], tools=["blender", "maya", "after-effects"]),
            CreativeAgent(agent_id="agent:cinematic:001", name="Cinematic Director", role=AgentRole.DIRECTOR,
                capabilities=["cap:cinematic", "cap:video:gen", "cap:animation", "cap:motion:graphics"],
                models=["sora", "runway", "luma"], tools=["davinci", "premiere", "after-effects"]),
        ]
        for agent in defaults:
            self._agents[agent.agent_id] = agent
            self._role_index[agent.role].append(agent.agent_id)
        logger.info(f"Initialized {len(defaults)} default creative agents")

    async def register_agent(self, agent: CreativeAgent) -> str:
        async with self._lock:
            self._agents[agent.agent_id] = agent
            if agent.role not in self._role_index:
                self._role_index[agent.role] = []
            self._role_index[agent.role].append(agent.agent_id)
        logger.info(f"Registered agent: {agent.name} ({agent.agent_id})")
        return agent.agent_id

    async def get_agent(self, agent_id: str) -> Optional[CreativeAgent]:
        return self._agents.get(agent_id)

    async def find_agents_by_capability(self, capability_id: str, status: Optional[AgentStatus] = None) -> List[CreativeAgent]:
        agents = [a for a in self._agents.values() if capability_id in a.capabilities]
        if status:
            agents = [a for a in agents if a.status == status]
        agents.sort(key=lambda a: (a.quality_score * a.success_rate * a.speed_score), reverse=True)
        return agents

    async def find_agents_by_role(self, role: AgentRole) -> List[CreativeAgent]:
        agent_ids = self._role_index.get(role, [])
        return [self._agents[i] for i in agent_ids if i in self._agents]

    async def assign_task(self, agent_id: str, project_id: str, capability_id: str, description: str,
                         parameters: Dict[str, Any], priority: int = 5) -> str:
        async with self._lock:
            if agent_id not in self._agents:
                raise ValueError(f"Agent {agent_id} not found")
            agent = self._agents[agent_id]
            if agent.status != AgentStatus.IDLE:
                raise ValueError(f"Agent {agent_id} is not available")
            task_id = f"task:{uuid.uuid4().hex[:8]}"
            task = AgentTask(task_id=task_id, agent_id=agent_id, project_id=project_id,
                capability_id=capability_id, description=description, parameters=parameters, priority=priority)
            self._tasks[task_id] = task
            agent.status = AgentStatus.BUSY
            agent.current_task = task_id
            agent.last_active = datetime.now()
        logger.info(f"Assigned task {task_id} to agent {agent_id}")
        return task_id

    async def complete_task(self, task_id: str, result: Dict[str, Any], success: bool = True, error: Optional[str] = None):
        async with self._lock:
            if task_id not in self._tasks:
                return
            task = self._tasks[task_id]
            task.status = "completed" if success else "failed"
            task.completed_at = datetime.now()
            task.result = result
            task.error = error
            agent = self._agents.get(task.agent_id)
            if agent:
                agent.status = AgentStatus.IDLE
                agent.current_task = None
                agent.completed_tasks += 1
                total = agent.completed_tasks
                agent.success_rate = ((agent.success_rate * (total - 1)) + (1.0 if success else 0.0)) / total
                if success and "quality_score" in result:
                    agent.quality_score = (agent.quality_score * 0.9) + (result["quality_score"] * 0.1)
                if success and "speed_score" in result:
                    agent.speed_score = (agent.speed_score * 0.9) + (result["speed_score"] * 0.1)
        logger.info(f"Task {task_id} completed: {'success' if success else 'failure'}")

    async def get_agent_stats(self, agent_id: str) -> Optional[Dict[str, Any]]:
        agent = self._agents.get(agent_id)
        if not agent:
            return None
        tasks = [t for t in self._tasks.values() if t.agent_id == agent_id]
        completed = [t for t in tasks if t.status == "completed"]
        failed = [t for t in tasks if t.status == "failed"]
        return {"agent_id": agent.agent_id, "name": agent.name, "role": agent.role.value,
            "status": agent.status.value, "capabilities": len(agent.capabilities),
            "completed_tasks": len(completed), "failed_tasks": len(failed),
            "success_rate": agent.success_rate, "quality_score": agent.quality_score,
            "speed_score": agent.speed_score, "cost_efficiency": agent.cost_efficiency}

    def get_stats(self) -> Dict[str, Any]:
        return {"agents": len(self._agents), "tasks": len(self._tasks),
            "roles": len([r for r in self._role_index if self._role_index[r]]),
            "idle_agents": sum(1 for a in self._agents.values() if a.status == AgentStatus.IDLE),
            "busy_agents": sum(1 for a in self._agents.values() if a.status == AgentStatus.BUSY)}
