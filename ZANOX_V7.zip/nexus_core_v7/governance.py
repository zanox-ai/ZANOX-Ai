"""Creative Governance Layer for Nexus Core V7."""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

logger = logging.getLogger(__name__)

class ComplianceStatus(Enum):
    COMPLIANT = "compliant"
    PENDING = "pending"
    VIOLATION = "violation"
    EXEMPT = "exempt"

@dataclass
class ComplianceRule:
    rule_id: str
    name: str
    description: str
    rule_type: str
    parameters: Dict[str, Any] = field(default_factory=dict)
    severity: str = "warning"
    active: bool = True

@dataclass
class ComplianceCheck:
    check_id: str
    rule_id: str
    asset_id: str
    status: ComplianceStatus
    details: str
    checked_at: datetime = field(default_factory=datetime.now)

class CreativeGovernanceLayer:
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._rules: Dict[str, ComplianceRule] = {}
        self._checks: Dict[str, List[ComplianceCheck]] = {}
        self._policies: Dict[str, Dict[str, Any]] = {}
        self._lock = asyncio.Lock()
        self._initialize_default_rules()

    def _initialize_default_rules(self):
        rules = [
            ComplianceRule("rule:copyright", "Copyright Check", "Verify no copyright infringement", "content", {"check_sources": ["reverse_image_search", "text_similarity"]}, "critical"),
            ComplianceRule("rule:brand", "Brand Compliance", "Verify brand guideline adherence", "brand", {"required_elements": ["logo", "colors", "typography"]}, "warning"),
            ComplianceRule("rule:quality", "Quality Threshold", "Minimum quality requirements", "quality", {"min_score": 0.6}, "warning"),
            ComplianceRule("rule:ethical", "Ethical AI", "Check for ethical AI usage", "ethical", {"no_deepfakes": True, "consent_required": True}, "critical"),
            ComplianceRule("rule:accessibility", "Accessibility", "WCAG compliance check", "accessibility", {"min_contrast": 4.5, "alt_text_required": True}, "warning"),
            ComplianceRule("rule:privacy", "Privacy Protection", "No PII in generated content", "privacy", {"detect_faces": True, "detect_text": True}, "critical"),
        ]
        for rule in rules:
            self._rules[rule.rule_id] = rule
        logger.info(f"Initialized {len(rules)} compliance rules")

    async def check_compliance(self, asset_id: str, asset_type: str, metadata: Dict[str, Any]) -> List[ComplianceCheck]:
        checks = []
        for rule in self._rules.values():
            if not rule.active:
                continue
            status = ComplianceStatus.COMPLIANT
            details = "Passed"
            if rule.rule_id == "rule:quality":
                score = metadata.get("quality_score", 0)
                if score < rule.parameters.get("min_score", 0.6):
                    status = ComplianceStatus.VIOLATION
                    details = f"Quality score {score} below threshold"
            elif rule.rule_id == "rule:brand":
                if metadata.get("brand_compliant") is False:
                    status = ComplianceStatus.VIOLATION
                    details = "Brand guidelines not followed"
            check = ComplianceCheck(
                check_id=f"check:{asset_id}:{rule.rule_id}:{datetime.now().isoformat()}",
                rule_id=rule.rule_id, asset_id=asset_id, status=status, details=details,
            )
            checks.append(check)
            async with self._lock:
                if asset_id not in self._checks:
                    self._checks[asset_id] = []
                self._checks[asset_id].append(check)
        logger.info(f"Completed {len(checks)} compliance checks for {asset_id}")
        return checks

    async def add_rule(self, name: str, description: str, rule_type: str, parameters: Dict[str, Any], severity: str = "warning") -> ComplianceRule:
        rule_id = f"rule:custom:{name.lower().replace(' ', '_')}"
        rule = ComplianceRule(rule_id=rule_id, name=name, description=description, rule_type=rule_type, parameters=parameters, severity=severity)
        async with self._lock:
            self._rules[rule_id] = rule
        logger.info(f"Added compliance rule: {name}")
        return rule

    async def get_compliance_report(self, asset_id: str) -> Dict[str, Any]:
        checks = self._checks.get(asset_id, [])
        violations = [c for c in checks if c.status == ComplianceStatus.VIOLATION]
        pending = [c for c in checks if c.status == ComplianceStatus.PENDING]
        return {"asset_id": asset_id, "total_checks": len(checks), "violations": len(violations), "pending": len(pending), "compliant": len(checks) - len(violations) - len(pending), "details": [{"rule": c.rule_id, "status": c.status.value, "details": c.details} for c in checks]}

    async def approve_violation(self, asset_id: str, rule_id: str, reason: str, approved_by: str):
        checks = self._checks.get(asset_id, [])
        for check in checks:
            if check.rule_id == rule_id and check.status == ComplianceStatus.VIOLATION:
                check.status = ComplianceStatus.EXEMPT
                check.details = f"Exempted by {approved_by}: {reason}"

    def get_stats(self) -> Dict[str, Any]:
        total_checks = sum(len(c) for c in self._checks.values())
        violations = sum(1 for checks in self._checks.values() for c in checks if c.status == ComplianceStatus.VIOLATION)
        return {"rules": len(self._rules), "total_checks": total_checks, "violations": violations, "compliance_rate": (total_checks - violations) / max(1, total_checks)}
