"""Multi Modal Orchestrator for Nexus Core V7.

Orchestrates multi-modal creative production combining text, image, video, audio, and 3D.
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

logger = logging.getLogger(__name__)


class ModalityType(Enum):
    TEXT = "text"
    IMAGE = "image"
    VIDEO = "video"
    AUDIO = "audio"
    THREE_D = "3d"
    DOCUMENT = "document"


@dataclass
class ModalityInput:
    """Input for a specific modality."""
    modality: ModalityType
    content: Any
    format: str
    parameters: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ModalityOutput:
    """Output from a specific modality."""
    modality: ModalityType
    content: Any
    format: str
    quality_score: float
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class MultiModalJob:
    """A multi-modal creative job."""
    job_id: str
    project_id: str
    inputs: List[ModalityInput]
    outputs: List[ModalityOutput] = field(default_factory=list)
    status: str = "pending"
    created_at: datetime = field(default_factory=datetime.now)
    completed_at: Optional[datetime] = None
    orchestration_plan: Dict[str, Any] = field(default_factory=dict)


class MultiModalOrchestrator:
    """Orchestrates multi-modal creative production."""

    def __init__(self, workflow_engine, config: Optional[Dict] = None):
        self.config = config or {}
        self._workflow_engine = workflow_engine
        self._jobs: Dict[str, MultiModalJob] = {}
        self._modality_handlers: Dict[ModalityType, Any] = {}
        self._lock = asyncio.Lock()

    async def register_handler(self, modality: ModalityType, handler: Any):
        """Register a handler for a modality."""
        async with self._lock:
            self._modality_handlers[modality] = handler
        logger.info(f"Registered handler for {modality.value}")

    async def create_job(self, project_id: str, inputs: List[Dict[str, Any]]) -> MultiModalJob:
        """Create a multi-modal job."""
        job_id = f"mm:{datetime.now().isoformat()}"

        modality_inputs = []
        for inp in inputs:
            modality_inputs.append(ModalityInput(
                modality=ModalityType(inp["modality"]),
                content=inp["content"],
                format=inp["format"],
                parameters=inp.get("parameters", {}),
            ))

        job = MultiModalJob(
            job_id=job_id,
            project_id=project_id,
            inputs=modality_inputs,
            orchestration_plan=await self._plan_orchestration(modality_inputs),
        )

        async with self._lock:
            self._jobs[job_id] = job

        logger.info(f"Created multi-modal job {job_id} with {len(inputs)} modalities")
        return job

    async def execute_job(self, job_id: str) -> bool:
        """Execute a multi-modal job."""
        async with self._lock:
            if job_id not in self._jobs:
                return False
            job = self._jobs[job_id]
            job.status = "running"

        try:
            # Execute each modality in the planned order
            for step in job.orchestration_plan.get("steps", []):
                modality = ModalityType(step["modality"])
                handler = self._modality_handlers.get(modality)

                if handler:
                    result = await handler.process(step)
                    job.outputs.append(ModalityOutput(
                        modality=modality,
                        content=result["content"],
                        format=result["format"],
                        quality_score=result.get("quality_score", 0.8),
                        metadata=result.get("metadata", {}),
                    ))

            async with self._lock:
                job.status = "completed"
                job.completed_at = datetime.now()

            logger.info(f"Multi-modal job {job_id} completed with {len(job.outputs)} outputs")
            return True

        except Exception as e:
            async with self._lock:
                job.status = "failed"
            logger.error(f"Multi-modal job {job_id} failed: {e}")
            return False

    async def _plan_orchestration(self, inputs: List[ModalityInput]) -> Dict[str, Any]:
        """Plan the orchestration of modalities."""
        # Determine execution order based on dependencies
        # Text usually goes first, then image, then video/audio, then 3D
        modality_order = {
            ModalityType.TEXT: 1,
            ModalityType.IMAGE: 2,
            ModalityType.VIDEO: 3,
            ModalityType.AUDIO: 3,
            ModalityType.THREE_D: 4,
            ModalityType.DOCUMENT: 5,
        }

        steps = []
        for inp in sorted(inputs, key=lambda x: modality_order.get(x.modality, 99)):
            steps.append({
                "modality": inp.modality.value,
                "format": inp.format,
                "parameters": inp.parameters,
            })

        return {"steps": steps, "parallel_groups": self._find_parallel_groups(inputs)}

    def _find_parallel_groups(self, inputs: List[ModalityInput]) -> List[List[str]]:
        """Find modalities that can be executed in parallel."""
        # Video and audio can often be generated in parallel
        groups = []
        current_group = []

        for inp in inputs:
            if inp.modality in [ModalityType.VIDEO, ModalityType.AUDIO]:
                current_group.append(inp.modality.value)
            else:
                if current_group:
                    groups.append(current_group)
                    current_group = []
                groups.append([inp.modality.value])

        if current_group:
            groups.append(current_group)

        return groups

    async def get_job(self, job_id: str) -> Optional[MultiModalJob]:
        """Get a job by ID."""
        return self._jobs.get(job_id)

    def get_stats(self) -> Dict[str, Any]:
        """Get orchestrator statistics."""
        completed = sum(1 for j in self._jobs.values() if j.status == "completed")
        failed = sum(1 for j in self._jobs.values() if j.status == "failed")

        return {
            "jobs": len(self._jobs),
            "completed": completed,
            "failed": failed,
            "handlers": len(self._modality_handlers),
        }
