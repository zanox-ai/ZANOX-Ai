"""Creative Registry for Nexus Core V7.

Manages all creative capabilities, domains, and production types.
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any, Set
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import uuid

logger = logging.getLogger(__name__)


class CreativeDomain(Enum):
    GRAPHIC_DESIGN = "graphic_design"
    LOGO_DESIGN = "logo_design"
    BRAND_IDENTITY = "brand_identity"
    UI_DESIGN = "ui_design"
    UX_DESIGN = "ux_design"
    POSTER_DESIGN = "poster_design"
    SOCIAL_MEDIA = "social_media_design"
    MARKETING = "marketing_design"
    ADVERTISING = "advertising_design"
    BANNER_DESIGN = "banner_design"
    LANDING_PAGE = "landing_page"
    PRODUCT_COVER = "product_cover"
    BOOK_COVER = "book_cover"
    PACKAGING = "packaging_design"
    ILLUSTRATION = "illustration"
    CONCEPT_ART = "concept_art"
    IMAGE_GENERATION = "image_generation"
    PHOTO_GENERATION = "photo_generation"
    PHOTO_EDITING = "photo_editing"
    IMAGE_UPSCALING = "image_upscaling"
    IMAGE_RESTORATION = "image_restoration"
    IMAGE_VARIATIONS = "image_variations"
    IMAGE_TO_IMAGE = "image_to_image"
    TEXT_TO_IMAGE = "text_to_image"
    VIDEO_GENERATION = "video_generation"
    IMAGE_TO_VIDEO = "image_to_video"
    TEXT_TO_VIDEO = "text_to_video"
    VIDEO_EDITING = "video_editing"
    VIDEO_ENHANCEMENT = "video_enhancement"
    VIDEO_UPSCALING = "video_upscaling"
    VIDEO_AUTOMATION = "video_automation"
    SHORT_FORM_VIDEO = "short_form_video"
    LONG_FORM_VIDEO = "long_form_video"
    ANIMATION = "animation"
    ANIMATION_2D = "2d_animation"
    ANIMATION_3D = "3d_animation"
    MOTION_GRAPHICS = "motion_graphics"
    CHARACTER_ANIMATION = "character_animation"
    CINEMATIC = "cinematic_generation"
    VOICE_GENERATION = "voice_generation"
    VOICE_CLONING = "voice_cloning"
    VOICE_CONVERSION = "voice_conversion"
    NARRATION = "narration_generation"
    PODCAST = "podcast_generation"
    SPEECH_SYNTHESIS = "speech_synthesis"
    MUSIC_GENERATION = "music_generation"
    SONG_GENERATION = "song_generation"
    LYRICS_GENERATION = "lyrics_generation"
    BACKGROUND_MUSIC = "background_music"
    INSTRUMENTAL = "instrumental_generation"
    SOUND_DESIGN = "sound_design"
    AUDIO_ENHANCEMENT = "audio_enhancement"
    AUDIO_RESTORATION = "audio_restoration"
    AUDIO_MIXING = "audio_mixing"
    MODEL_3D = "3d_model"
    ASSET_3D = "3d_asset"
    CHARACTER_3D = "3d_character"
    ENVIRONMENT_3D = "3d_environment"
    ANIMATION_ASSET_3D = "3d_animation_asset"
    PRESENTATION = "presentation"
    PITCH_DECK = "pitch_deck"
    BUSINESS_PRESENTATION = "business_presentation"
    DOCUMENT = "document"
    EBOOK = "ebook"
    PDF = "pdf_generation"
    REPORT = "report_generation"
    CONTENT = "content"
    BLOG = "blog_generation"
    MARKETING_COPY = "marketing_copy"


class ProductionType(Enum):
    STATIC = "static"
    DYNAMIC = "dynamic"
    INTERACTIVE = "interactive"
    AUDIO = "audio"
    VIDEO = "video"
    THREE_D = "3d"
    DOCUMENT = "document"


@dataclass
class CreativeCapability:
    capability_id: str
    domain: CreativeDomain
    production_type: ProductionType
    name: str
    description: str
    required_models: List[str] = field(default_factory=list)
    required_tools: List[str] = field(default_factory=list)
    output_formats: List[str] = field(default_factory=list)
    quality_levels: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.now)
    is_active: bool = True


@dataclass
class CreativeProject:
    project_id: str
    name: str
    domain: CreativeDomain
    capabilities: List[str] = field(default_factory=list)
    brand_id: Optional[str] = None
    design_system_id: Optional[str] = None
    status: str = "draft"
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    metadata: Dict[str, Any] = field(default_factory=dict)


class CreativeRegistry:
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._capabilities: Dict[str, CreativeCapability] = {}
        self._projects: Dict[str, CreativeProject] = {}
        self._domain_index: Dict[CreativeDomain, Set[str]] = {d: set() for d in CreativeDomain}
        self._type_index: Dict[ProductionType, Set[str]] = {t: set() for t in ProductionType}
        self._lock = asyncio.Lock()
        self._initialize_capabilities()

    def _initialize_capabilities(self):
        capabilities = [
            CreativeCapability("cap:graphic:design", CreativeDomain.GRAPHIC_DESIGN, ProductionType.STATIC, "Graphic Design", "Create visual graphics, layouts, and compositions", ["dalle-3", "midjourney", "stable-diffusion", "flux"], ["photoshop", "figma", "canva"], ["png", "jpg", "svg", "pdf"], ["draft", "standard", "premium", "master"]),
            CreativeCapability("cap:logo:design", CreativeDomain.LOGO_DESIGN, ProductionType.STATIC, "Logo Design", "Design logos and brand marks", ["dalle-3", "midjourney", "ideogram"], ["illustrator", "figma", "vectorizer"], ["svg", "png", "pdf", "eps"], ["concept", "refined", "final"]),
            CreativeCapability("cap:brand:identity", CreativeDomain.BRAND_IDENTITY, ProductionType.STATIC, "Brand Identity", "Complete brand identity systems", ["dalle-3", "claude", "gpt-4o"], ["figma", "illustrator", "indesign"], ["pdf", "png", "svg", "indd"], ["basic", "standard", "premium"]),
            CreativeCapability("cap:ui:design", CreativeDomain.UI_DESIGN, ProductionType.INTERACTIVE, "UI Design", "User interface design for apps and websites", ["dalle-3", "claude"], ["figma", "sketch", "adobe-xd"], ["fig", "sketch", "xd", "pdf"], ["wireframe", "mockup", "prototype", "production"]),
            CreativeCapability("cap:ux:design", CreativeDomain.UX_DESIGN, ProductionType.INTERACTIVE, "UX Design", "User experience design and research", ["claude", "gpt-4o"], ["figma", "maze", "hotjar"], ["pdf", "html", "fig"], ["research", "concept", "tested", "final"]),
            CreativeCapability("cap:poster:design", CreativeDomain.POSTER_DESIGN, ProductionType.STATIC, "Poster Design", "Design posters for print and digital", ["dalle-3", "midjourney", "flux"], ["photoshop", "illustrator"], ["png", "jpg", "pdf", "tiff"], ["draft", "print", "billboard"]),
            CreativeCapability("cap:social:media", CreativeDomain.SOCIAL_MEDIA, ProductionType.STATIC, "Social Media Design", "Create social media content and templates", ["dalle-3", "midjourney", "canva-ai"], ["canva", "figma", "photoshop"], ["png", "jpg", "mp4", "gif"], ["story", "feed", "banner", "campaign"]),
            CreativeCapability("cap:marketing:design", CreativeDomain.MARKETING, ProductionType.STATIC, "Marketing Design", "Marketing materials and campaigns", ["dalle-3", "claude", "gpt-4o"], ["photoshop", "illustrator", "indesign"], ["pdf", "png", "jpg", "html"], ["draft", "campaign", "premium"]),
            CreativeCapability("cap:advertising:design", CreativeDomain.ADVERTISING, ProductionType.STATIC, "Advertising Design", "Advertising creatives and banners", ["dalle-3", "midjourney", "adobe-firefly"], ["photoshop", "illustrator", "figma"], ["png", "jpg", "gif", "html5"], ["concept", "a/b_test", "production"]),
            CreativeCapability("cap:banner:design", CreativeDomain.BANNER_DESIGN, ProductionType.STATIC, "Banner Design", "Web and display banners", ["dalle-3", "midjourney"], ["photoshop", "figma", "canva"], ["png", "jpg", "gif", "svg"], ["standard", "animated", "interactive"]),
            CreativeCapability("cap:landing:page", CreativeDomain.LANDING_PAGE, ProductionType.INTERACTIVE, "Landing Page Design", "Landing page creation and optimization", ["claude", "gpt-4o", "dalle-3"], ["figma", "webflow", "framer"], ["html", "css", "fig", "pdf"], ["wireframe", "design", "developed", "live"]),
            CreativeCapability("cap:product:cover", CreativeDomain.PRODUCT_COVER, ProductionType.STATIC, "Product Cover Design", "Design product packaging and covers", ["dalle-3", "midjourney", "flux"], ["photoshop", "illustrator", "blender"], ["png", "jpg", "pdf", "psd"], ["concept", "mockup", "production"]),
            CreativeCapability("cap:book:cover", CreativeDomain.BOOK_COVER, ProductionType.STATIC, "Book Cover Design", "Book cover and jacket design", ["dalle-3", "midjourney", "stable-diffusion"], ["photoshop", "illustrator", "indesign"], ["png", "jpg", "pdf", "tiff"], ["concept", "draft", "final", "print_ready"]),
            CreativeCapability("cap:packaging:design", CreativeDomain.PACKAGING, ProductionType.STATIC, "Packaging Design", "Product packaging design", ["dalle-3", "midjourney", "flux"], ["illustrator", "photoshop", "blender"], ["pdf", "ai", "eps", "dieline"], ["concept", "prototype", "production"]),
            CreativeCapability("cap:illustration", CreativeDomain.ILLUSTRATION, ProductionType.STATIC, "Illustration", "Custom illustration creation", ["dalle-3", "midjourney", "stable-diffusion", "flux"], ["illustrator", "photoshop", "procreate"], ["png", "jpg", "svg", "psd"], ["sketch", "line_art", "colored", "detailed"]),
            CreativeCapability("cap:concept:art", CreativeDomain.CONCEPT_ART, ProductionType.STATIC, "Concept Art", "Concept art and visualization", ["dalle-3", "midjourney", "stable-diffusion"], ["photoshop", "blender", "zbrush"], ["png", "jpg", "psd", "tiff"], ["rough", "refined", "final"]),
            CreativeCapability("cap:image:gen", CreativeDomain.IMAGE_GENERATION, ProductionType.STATIC, "Image Generation", "AI-powered image generation", ["dalle-3", "midjourney", "stable-diffusion", "flux", "ideogram", "leonardo"], ["comfyui", "automatic1111", "invoke"], ["png", "jpg", "webp", "tiff"], ["fast", "standard", "hd", "ultra"]),
            CreativeCapability("cap:photo:gen", CreativeDomain.PHOTO_GENERATION, ProductionType.STATIC, "Photo Generation", "AI photo generation", ["dalle-3", "midjourney", "stable-diffusion", "flux"], ["photoshop", "lightroom"], ["jpg", "png", "raw", "tiff"], ["standard", "hd", "raw", "print"]),
            CreativeCapability("cap:photo:edit", CreativeDomain.PHOTO_EDITING, ProductionType.STATIC, "Photo Editing", "Professional photo editing and retouching", ["claude", "gpt-4o"], ["photoshop", "lightroom", "capture-one"], ["jpg", "png", "tiff", "psd"], ["basic", "standard", "high_end", "master"]),
            CreativeCapability("cap:image:upscale", CreativeDomain.IMAGE_UPSCALING, ProductionType.STATIC, "Image Upscaling", "AI image upscaling and enhancement", ["stable-diffusion", "topaz", "magnific"], ["photoshop", "topaz-gigapixel"], ["png", "jpg", "tiff"], ["2x", "4x", "8x", "16x"]),
            CreativeCapability("cap:image:restore", CreativeDomain.IMAGE_RESTORATION, ProductionType.STATIC, "Image Restoration", "Restore and repair old/damaged images", ["stable-diffusion", "topaz", "codeformer"], ["photoshop", "topaz-photo"], ["png", "jpg", "tiff"], ["basic", "standard", "museum"]),
            CreativeCapability("cap:image:variations", CreativeDomain.IMAGE_VARIATIONS, ProductionType.STATIC, "Image Variations", "Generate variations of existing images", ["dalle-3", "midjourney", "stable-diffusion"], ["comfyui", "automatic1111"], ["png", "jpg", "webp"], ["subtle", "strong", "creative"]),
            CreativeCapability("cap:image2image", CreativeDomain.IMAGE_TO_IMAGE, ProductionType.STATIC, "Image-to-Image", "Transform images with AI", ["stable-diffusion", "midjourney", "flux"], ["comfyui", "automatic1111"], ["png", "jpg", "webp"], ["standard", "hd", "ultra"]),
            CreativeCapability("cap:text2image", CreativeDomain.TEXT_TO_IMAGE, ProductionType.STATIC, "Text-to-Image", "Generate images from text prompts", ["dalle-3", "midjourney", "stable-diffusion", "flux", "ideogram"], ["comfyui", "automatic1111", "invoke"], ["png", "jpg", "webp"], ["fast", "standard", "hd", "ultra"]),
            CreativeCapability("cap:video:gen", CreativeDomain.VIDEO_GENERATION, ProductionType.VIDEO, "Video Generation", "AI-powered video generation", ["sora", "runway", "pika", "luma", "kling", "hailuo"], ["ffmpeg", "after-effects"], ["mp4", "mov", "avi"], ["preview", "standard", "hd", "4k"]),
            CreativeCapability("cap:image2video", CreativeDomain.IMAGE_TO_VIDEO, ProductionType.VIDEO, "Image-to-Video", "Convert images to video", ["runway", "pika", "luma", "kling"], ["ffmpeg", "after-effects"], ["mp4", "mov", "webm"], ["standard", "hd", "4k"]),
            CreativeCapability("cap:text2video", CreativeDomain.TEXT_TO_VIDEO, ProductionType.VIDEO, "Text-to-Video", "Generate videos from text", ["sora", "runway", "pika", "luma"], ["ffmpeg"], ["mp4", "mov"], ["standard", "hd", "4k"]),
            CreativeCapability("cap:video:edit", CreativeDomain.VIDEO_EDITING, ProductionType.VIDEO, "Video Editing", "Professional video editing", ["claude", "gpt-4o"], ["premiere", "davinci", "final-cut"], ["mp4", "mov", "prores"], ["rough", "assembly", "fine", "final"]),
            CreativeCapability("cap:video:enhance", CreativeDomain.VIDEO_ENHANCEMENT, ProductionType.VIDEO, "Video Enhancement", "AI video enhancement and color grading", ["topaz", "davinci"], ["davinci", "premiere"], ["mp4", "mov", "prores"], ["standard", "premium", "cinematic"]),
            CreativeCapability("cap:video:upscale", CreativeDomain.VIDEO_UPSCALING, ProductionType.VIDEO, "Video Upscaling", "AI video upscaling", ["topaz", "waifu2x"], ["topaz-video", "ffmpeg"], ["mp4", "mov"], ["2x", "4x", "8x"]),
            CreativeCapability("cap:video:auto", CreativeDomain.VIDEO_AUTOMATION, ProductionType.VIDEO, "Video Automation", "Automated video creation and editing", ["runway", "pika", "claude"], ["ffmpeg", "after-effects"], ["mp4", "mov"], ["standard", "hd", "4k"]),
            CreativeCapability("cap:short:video", CreativeDomain.SHORT_FORM_VIDEO, ProductionType.VIDEO, "Short Form Video", "Short-form video creation", ["runway", "pika", "sora"], ["capcut", "premiere", "ffmpeg"], ["mp4", "mov"], ["standard", "viral", "premium"]),
            CreativeCapability("cap:long:video", CreativeDomain.LONG_FORM_VIDEO, ProductionType.VIDEO, "Long Form Video", "Long-form video creation", ["sora", "runway", "claude"], ["premiere", "davinci", "final-cut"], ["mp4", "mov", "prores"], ["standard", "hd", "4k", "cinematic"]),
            CreativeCapability("cap:animation", CreativeDomain.ANIMATION, ProductionType.DYNAMIC, "Animation", "2D and 3D animation creation", ["runway", "pika", "kaiber"], ["after-effects", "blender", "maya"], ["mp4", "gif", "mov", "webm"], ["sketch", "animatic", "production", "cinematic"]),
            CreativeCapability("cap:2d:animation", CreativeDomain.ANIMATION_2D, ProductionType.DYNAMIC, "2D Animation", "2D animation and motion graphics", ["runway", "pika"], ["after-effects", "toon-boom", "anime-studio"], ["mp4", "mov", "gif"], ["standard", "hd", "premium"]),
            CreativeCapability("cap:3d:animation", CreativeDomain.ANIMATION_3D, ProductionType.DYNAMIC, "3D Animation", "3D animation creation", ["runway", "pika"], ["blender", "maya", "cinema-4d"], ["mp4", "mov", "avi"], ["standard", "hd", "4k", "cinematic"]),
            CreativeCapability("cap:motion:graphics", CreativeDomain.MOTION_GRAPHICS, ProductionType.DYNAMIC, "Motion Graphics", "Animated graphic elements and titles", ["runway"], ["after-effects", "cinema-4d"], ["mp4", "mov", "gif"], ["draft", "standard", "premium"]),
            CreativeCapability("cap:character:anim", CreativeDomain.CHARACTER_ANIMATION, ProductionType.DYNAMIC, "Character Animation", "Character animation and rigging", ["runway", "pika"], ["blender", "maya", "after-effects"], ["mp4", "mov", "fbx"], ["standard", "hd", "cinematic"]),
            CreativeCapability("cap:cinematic", CreativeDomain.CINEMATIC, ProductionType.VIDEO, "Cinematic Generation", "Cinematic video generation", ["sora", "runway", "luma"], ["davinci", "premiere"], ["mp4", "mov", "prores"], ["standard", "hd", "4k", "imax"]),
            CreativeCapability("cap:voice:gen", CreativeDomain.VOICE_GENERATION, ProductionType.AUDIO, "Voice Generation", "AI voice and speech synthesis", ["elevenlabs", "azure-tts", "google-tts", "playht", "cartesia"], ["audition", "reaper"], ["mp3", "wav", "ogg"], ["standard", "hd", "studio"]),
            CreativeCapability("cap:voice:clone", CreativeDomain.VOICE_CLONING, ProductionType.AUDIO, "Voice Cloning", "Clone voices with AI", ["elevenlabs", "playht"], ["audition"], ["mp3", "wav"], ["standard", "premium", "studio"]),
            CreativeCapability("cap:voice:convert", CreativeDomain.VOICE_CONVERSION, ProductionType.AUDIO, "Voice Conversion", "Convert voice characteristics", ["elevenlabs", "playht"], ["audition", "reaper"], ["mp3", "wav"], ["standard", "premium"]),
            CreativeCapability("cap:narration", CreativeDomain.NARRATION, ProductionType.AUDIO, "Narration Generation", "AI narration and audiobook creation", ["elevenlabs", "azure-tts", "cartesia"], ["audition", "reaper"], ["mp3", "wav", "m4b"], ["standard", "hd", "studio"]),
            CreativeCapability("cap:podcast", CreativeDomain.PODCAST, ProductionType.AUDIO, "Podcast Generation", "AI podcast creation and editing", ["elevenlabs", "claude", "gpt-4o"], ["audition", "reaper", "garageband"], ["mp3", "wav", "m4a"], ["standard", "hd", "studio"]),
            CreativeCapability("cap:speech:synth", CreativeDomain.SPEECH_SYNTHESIS, ProductionType.AUDIO, "Speech Synthesis", "Text-to-speech synthesis", ["elevenlabs", "azure-tts", "google-tts", "cartesia"], ["audition"], ["mp3", "wav", "ogg"], ["standard", "hd", "natural"]),
            CreativeCapability("cap:music:gen", CreativeDomain.MUSIC_GENERATION, ProductionType.AUDIO, "Music Generation", "AI music composition", ["suno", "udio", "aiva", "soundraw"], ["ableton", "fl-studio", "logic"], ["mp3", "wav", "midi"], ["draft", "standard", "master"]),
            CreativeCapability("cap:song:gen", CreativeDomain.SONG_GENERATION, ProductionType.AUDIO, "Song Generation", "AI song creation with vocals", ["suno", "udio"], ["ableton", "fl-studio"], ["mp3", "wav"], ["draft", "standard", "master"]),
            CreativeCapability("cap:lyrics:gen", CreativeDomain.LYRICS_GENERATION, ProductionType.DOCUMENT, "Lyrics Generation", "AI lyrics and songwriting", ["claude", "gpt-4o", "suno"], ["notion", "word"], ["txt", "docx", "pdf"], ["draft", "edited", "final"]),
            CreativeCapability("cap:bg:music", CreativeDomain.BACKGROUND_MUSIC, ProductionType.AUDIO, "Background Music", "AI background music generation", ["suno", "aiva", "soundraw"], ["ableton", "fl-studio"], ["mp3", "wav", "midi"], ["loop", "standard", "extended"]),
            CreativeCapability("cap:instrumental", CreativeDomain.INSTRUMENTAL, ProductionType.AUDIO, "Instrumental Generation", "AI instrumental music", ["suno", "aiva", "soundraw", "udio"], ["ableton", "fl-studio", "logic"], ["mp3", "wav", "midi"], ["draft", "standard", "master"]),
            CreativeCapability("cap:sound:design", CreativeDomain.SOUND_DESIGN, ProductionType.AUDIO, "Sound Design", "Audio effects and sound design", ["elevenlabs", "stable-audio"], ["pro-tools", "audition", "reaper"], ["wav", "mp3", "aiff"], ["lofi", "standard", "cinematic"]),
            CreativeCapability("cap:audio:enhance", CreativeDomain.AUDIO_ENHANCEMENT, ProductionType.AUDIO, "Audio Enhancement", "AI audio enhancement and cleanup", ["topaz", "adobe-podcast"], ["audition", "pro-tools"], ["wav", "mp3", "flac"], ["standard", "premium", "studio"]),
            CreativeCapability("cap:audio:restore", CreativeDomain.AUDIO_RESTORATION, ProductionType.AUDIO, "Audio Restoration", "Restore and repair audio", ["topaz", "adobe-podcast"], ["audition", "izotope"], ["wav", "mp3", "flac"], ["standard", "premium", "archival"]),
            CreativeCapability("cap:audio:mix", CreativeDomain.AUDIO_MIXING, ProductionType.AUDIO, "Audio Mixing", "Professional audio mixing", ["claude"], ["pro-tools", "logic", "ableton"], ["wav", "mp3", "aiff"], ["rough", "balanced", "polished", "master"]),
            CreativeCapability("cap:3d:model", CreativeDomain.MODEL_3D, ProductionType.THREE_D, "3D Model Generation", "AI 3D model creation", ["meshy", "tripo", "rodin", "spline"], ["blender", "maya", "zbrush"], ["obj", "fbx", "gltf", "stl"], ["lowpoly", "standard", "highpoly", "sculpt"]),
            CreativeCapability("cap:3d:asset", CreativeDomain.ASSET_3D, ProductionType.THREE_D, "3D Asset Generation", "Generate 3D assets", ["meshy", "tripo", "spline"], ["blender", "unreal", "unity"], ["obj", "fbx", "gltf", "usd"], ["game", "standard", "film"]),
            CreativeCapability("cap:3d:character", CreativeDomain.CHARACTER_3D, ProductionType.THREE_D, "3D Character Generation", "AI 3D character creation", ["meshy", "tripo", "rodin"], ["blender", "maya", "zbrush"], ["obj", "fbx", "gltf", "blend"], ["standard", "detailed", "rigged"]),
            CreativeCapability("cap:3d:environment", CreativeDomain.ENVIRONMENT_3D, ProductionType.THREE_D, "3D Environment Generation", "AI 3D environment creation", ["meshy", "tripo"], ["blender", "unreal", "unity"], ["obj", "fbx", "gltf", "usd"], ["standard", "detailed", "cinematic"]),
            CreativeCapability("cap:3d:anim:asset", CreativeDomain.ANIMATION_ASSET_3D, ProductionType.THREE_D, "3D Animation Assets", "3D assets for animation", ["meshy", "tripo"], ["blender", "maya"], ["obj", "fbx", "gltf"], ["standard", "detailed", "production"]),
            CreativeCapability("cap:presentation", CreativeDomain.PRESENTATION, ProductionType.DOCUMENT, "Presentation Generation", "AI presentation creation", ["claude", "gpt-4o", "dalle-3", "gamma", "beautiful-ai"], ["powerpoint", "google-slides", "keynote"], ["pptx", "pdf", "html"], ["outline", "draft", "polished", "executive"]),
            CreativeCapability("cap:pitch:deck", CreativeDomain.PITCH_DECK, ProductionType.DOCUMENT, "Pitch Deck Generation", "AI pitch deck creation", ["claude", "gpt-4o", "gamma", "beautiful-ai"], ["powerpoint", "google-slides", "keynote"], ["pptx", "pdf", "html"], ["outline", "draft", "investor_ready"]),
            CreativeCapability("cap:biz:presentation", CreativeDomain.BUSINESS_PRESENTATION, ProductionType.DOCUMENT, "Business Presentation", "Business presentation creation", ["claude", "gpt-4o", "gamma"], ["powerpoint", "google-slides"], ["pptx", "pdf"], ["standard", "executive", "board"]),
            CreativeCapability("cap:document", CreativeDomain.DOCUMENT, ProductionType.DOCUMENT, "Document Generation", "AI document creation", ["claude", "gpt-4o", "gemini", "kimi"], ["word", "google-docs", "indesign"], ["docx", "pdf", "html", "epub"], ["draft", "review", "final", "print"]),
            CreativeCapability("cap:ebook", CreativeDomain.EBOOK, ProductionType.DOCUMENT, "Ebook Generation", "AI ebook creation", ["claude", "gpt-4o", "gemini"], ["indesign", "word", "scrivener"], ["pdf", "epub", "mobi"], ["outline", "draft", "edited", "published"]),
            CreativeCapability("cap:pdf:gen", CreativeDomain.PDF, ProductionType.DOCUMENT, "PDF Generation", "AI PDF creation and layout", ["claude", "gpt-4o"], ["indesign", "word", "acrobat"], ["pdf"], ["standard", "interactive", "print"]),
            CreativeCapability("cap:report", CreativeDomain.REPORT, ProductionType.DOCUMENT, "Report Generation", "AI report creation", ["claude", "gpt-4o", "gemini"], ["word", "indesign", "notion"], ["pdf", "docx", "html"], ["draft", "review", "final", "executive"]),
            CreativeCapability("cap:content", CreativeDomain.CONTENT, ProductionType.STATIC, "Content Generation", "Multi-format content creation", ["claude", "gpt-4o", "gemini", "kimi"], ["notion", "wordpress", "medium"], ["md", "html", "txt", "json"], ["outline", "draft", "edited", "published"]),
            CreativeCapability("cap:blog", CreativeDomain.BLOG, ProductionType.DOCUMENT, "Blog Generation", "AI blog post creation", ["claude", "gpt-4o", "gemini", "kimi"], ["wordpress", "notion", "medium"], ["md", "html", "txt"], ["outline", "draft", "edited", "published"]),
            CreativeCapability("cap:marketing:copy", CreativeDomain.MARKETING_COPY, ProductionType.DOCUMENT, "Marketing Copy", "AI marketing copywriting", ["claude", "gpt-4o", "gemini"], ["notion", "word", "google-docs"], ["md", "html", "txt"], ["draft", "a/b_test", "final"]),
        ]
        for cap in capabilities:
            self._capabilities[cap.capability_id] = cap
            self._domain_index[cap.domain].add(cap.capability_id)
            self._type_index[cap.production_type].add(cap.capability_id)
        logger.info(f"Initialized {len(capabilities)} creative capabilities")

    async def get_capability(self, capability_id: str) -> Optional[CreativeCapability]:
        return self._capabilities.get(capability_id)

    async def get_capabilities_by_domain(self, domain: CreativeDomain) -> List[CreativeCapability]:
        ids = self._domain_index.get(domain, set())
        return [self._capabilities[i] for i in ids if i in self._capabilities]

    async def get_capabilities_by_type(self, production_type: ProductionType) -> List[CreativeCapability]:
        ids = self._type_index.get(production_type, set())
        return [self._capabilities[i] for i in ids if i in self._capabilities]

    async def create_project(self, name: str, domain: CreativeDomain, capabilities: List[str], **kwargs) -> CreativeProject:
        project_id = f"proj:{uuid.uuid4().hex[:8]}"
        project = CreativeProject(project_id=project_id, name=name, domain=domain, capabilities=capabilities,
            brand_id=kwargs.get("brand_id"), design_system_id=kwargs.get("design_system_id"), status="draft", metadata=kwargs.get("metadata", {}))
        async with self._lock:
            self._projects[project_id] = project
        logger.info(f"Created project: {name} ({project_id})")
        return project

    async def get_project(self, project_id: str) -> Optional[CreativeProject]:
        return self._projects.get(project_id)

    async def update_project(self, project_id: str, updates: Dict[str, Any]) -> bool:
        async with self._lock:
            if project_id not in self._projects:
                return False
            project = self._projects[project_id]
            if "name" in updates: project.name = updates["name"]
            if "status" in updates: project.status = updates["status"]
            if "capabilities" in updates: project.capabilities = updates["capabilities"]
            if "metadata" in updates: project.metadata.update(updates["metadata"])
            project.updated_at = datetime.now()
            return True

    async def list_projects(self, domain: Optional[CreativeDomain] = None, status: Optional[str] = None) -> List[CreativeProject]:
        projects = list(self._projects.values())
        if domain: projects = [p for p in projects if p.domain == domain]
        if status: projects = [p for p in projects if p.status == status]
        return projects

    def get_stats(self) -> Dict[str, Any]:
        return {"capabilities": len(self._capabilities), "projects": len(self._projects),
            "domains": len([d for d in self._domain_index if self._domain_index[d]]),
            "production_types": len([t for t in self._type_index if self._type_index[t]])}
