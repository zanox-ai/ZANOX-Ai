"""Content Builder for Nexus Core V7."""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime

logger = logging.getLogger(__name__)

@dataclass
class ContentPiece:
    content_id: str
    title: str
    content_type: str
    body: str
    tags: List[str] = field(default_factory=list)
    seo_metadata: Dict[str, Any] = field(default_factory=dict)
    status: str = "draft"
    created_at: datetime = field(default_factory=datetime.now)
    published_at: Optional[datetime] = None

class ContentBuilder:
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._content: Dict[str, ContentPiece] = {}
        self._lock = asyncio.Lock()

    async def create_content(self, title: str, content_type: str, **kwargs) -> ContentPiece:
        content_id = f"content:{content_type}:{title.lower().replace(' ', '_')}"
        piece = ContentPiece(
            content_id=content_id, title=title, content_type=content_type,
            body=kwargs.get("body", ""), tags=kwargs.get("tags", []),
            seo_metadata=kwargs.get("seo_metadata", {}),
        )
        async with self._lock:
            self._content[content_id] = piece
        logger.info(f"Created content: {title}")
        return piece

    async def generate_blog_post(self, topic: str, keywords: List[str], **kwargs) -> ContentPiece:
        title = f"The Complete Guide to {topic}"
        body = f"# {title}\n\n## Introduction\n\n{topic} is an important subject.\n\n## Key Points\n\n"
        for kw in keywords:
            body += f"\n### {kw}\n\nDetailed information about {kw}.\n"
        body += f"\n## Conclusion\n\nIn conclusion, {topic} offers many opportunities.\n"
        content = await self.create_content(title, "blog_post", body=body, tags=keywords,
            seo_metadata={"title": title, "description": f"Learn about {topic}", "keywords": keywords})
        content.status = "ready"
        return content

    async def generate_social_posts(self, content_id: str, platforms: List[str]) -> List[str]:
        content = self._content.get(content_id)
        if not content:
            return []
        posts = []
        for platform in platforms:
            if platform == "twitter":
                posts.append(f"📝 {content.title[:100]}... #thread")
            elif platform == "linkedin":
                posts.append(f"New article: {content.title}\n\nCheck it out!")
            elif platform == "instagram":
                posts.append(f"✨ {content.title}\n\nSwipe to learn more! 👆")
        return posts

    async def publish(self, content_id: str) -> bool:
        content = self._content.get(content_id)
        if not content:
            return False
        content.status = "published"
        content.published_at = datetime.now()
        logger.info(f"Published content {content_id}")
        return True

    def get_stats(self) -> Dict[str, Any]:
        statuses = {}
        for c in self._content.values():
            statuses[c.status] = statuses.get(c.status, 0) + 1
        return {"content_pieces": len(self._content), "statuses": statuses}
