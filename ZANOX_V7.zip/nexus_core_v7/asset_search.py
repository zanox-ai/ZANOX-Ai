"""Asset Search Engine for Nexus Core V7.

Full-text and semantic search for creative assets.
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from datetime import datetime

logger = logging.getLogger(__name__)


@dataclass
class SearchResult:
    """A search result."""
    asset_id: str
    score: float
    matched_fields: List[str]
    highlights: List[str]


class AssetSearchEngine:
    """Search engine for creative assets."""

    def __init__(self, asset_library, config: Optional[Dict] = None):
        self.config = config or {}
        self._asset_library = asset_library
        self._search_index: Dict[str, Dict[str, Any]] = {}
        self._lock = asyncio.Lock()

    async def index_asset(self, asset_id: str):
        """Index an asset for search."""
        asset = await self._asset_library.get_asset(asset_id)
        if not asset:
            return

        # Build search document
        doc = {
            "name": asset.name.lower(),
            "type": asset.asset_type.lower(),
            "format": asset.format.lower(),
            "tags": [t.lower() for t in asset.tags],
            "metadata": str(asset.metadata).lower(),
            "project_id": asset.project_id or "",
            "brand_id": asset.brand_id or "",
        }

        async with self._lock:
            self._search_index[asset_id] = doc

        logger.debug(f"Indexed asset {asset_id}")

    async def search(self, query: str, filters: Optional[Dict[str, Any]] = None,
                    limit: int = 20) -> List[SearchResult]:
        """Search assets."""
        query_lower = query.lower()
        query_terms = query_lower.split()

        results = []

        for asset_id, doc in self._search_index.items():
            score = 0.0
            matched_fields = []

            # Check name
            if query_lower in doc["name"]:
                score += 10.0
                matched_fields.append("name")

            # Check tags
            for tag in doc["tags"]:
                if any(term in tag for term in query_terms):
                    score += 5.0
                    matched_fields.append("tags")

            # Check type
            if query_lower in doc["type"]:
                score += 3.0
                matched_fields.append("type")

            # Check metadata
            if query_lower in doc["metadata"]:
                score += 1.0
                matched_fields.append("metadata")

            if score > 0:
                # Apply filters
                if filters:
                    if "type" in filters and filters["type"] != doc["type"]:
                        continue
                    if "project_id" in filters and filters["project_id"] != doc["project_id"]:
                        continue
                    if "brand_id" in filters and filters["brand_id"] != doc["brand_id"]:
                        continue

                results.append(SearchResult(
                    asset_id=asset_id,
                    score=score,
                    matched_fields=list(set(matched_fields)),
                    highlights=[query],
                ))

        # Sort by score
        results.sort(key=lambda r: r.score, reverse=True)

        return results[:limit]

    async def reindex_all(self):
        """Reindex all assets."""
        async with self._lock:
            self._search_index.clear()

        assets = await self._asset_library.list_assets()
        for asset in assets:
            await self.index_asset(asset.asset_id)

        logger.info(f"Reindexed {len(assets)} assets")

    def get_stats(self) -> Dict[str, Any]:
        return {
            "indexed_assets": len(self._search_index),
        }
