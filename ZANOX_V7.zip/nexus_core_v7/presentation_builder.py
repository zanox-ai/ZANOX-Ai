"""Presentation Builder for Nexus Core V7."""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime

logger = logging.getLogger(__name__)

@dataclass
class Presentation:
    presentation_id: str
    title: str
    slides: List[Dict] = field(default_factory=list)
    theme: str = "default"
    transition: str = "fade"
    status: str = "draft"
    created_at: datetime = field(default_factory=datetime.now)
    completed_at: Optional[datetime] = None

class PresentationBuilder:
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._presentations: Dict[str, Presentation] = {}
        self._lock = asyncio.Lock()

    async def create_presentation(self, title: str, **kwargs) -> Presentation:
        presentation_id = f"preso:{title.lower().replace(' ', '_')}"
        presentation = Presentation(
            presentation_id=presentation_id, title=title,
            theme=kwargs.get("theme", "default"), transition=kwargs.get("transition", "fade"),
        )
        async with self._lock:
            self._presentations[presentation_id] = presentation
        logger.info(f"Created presentation: {title}")
        return presentation

    async def add_slide(self, presentation_id: str, layout: str, content: Dict[str, Any]) -> bool:
        presentation = self._presentations.get(presentation_id)
        if not presentation:
            return False
        presentation.slides.append({"slide_number": len(presentation.slides) + 1, "layout": layout, "content": content})
        return True

    async def generate_from_outline(self, title: str, outline: List[str], **kwargs) -> Presentation:
        presentation = await self.create_presentation(title, **kwargs)
        for i, section in enumerate(outline):
            await self.add_slide(presentation.presentation_id, "title_content", {"title": section, "body": f"Content for {section}", "slide_number": i + 1})
        presentation.status = "completed"
        presentation.completed_at = datetime.now()
        logger.info(f"Generated presentation from outline: {title}")
        return presentation

    async def export(self, presentation_id: str, format: str = "pptx") -> Optional[str]:
        presentation = self._presentations.get(presentation_id)
        if not presentation:
            return None
        output_path = f"/presentations/{presentation_id}.{format}"
        logger.info(f"Exported presentation {presentation_id}")
        return output_path

    def get_stats(self) -> Dict[str, Any]:
        total_slides = sum(len(p.slides) for p in self._presentations.values())
        return {"presentations": len(self._presentations), "total_slides": total_slides}
