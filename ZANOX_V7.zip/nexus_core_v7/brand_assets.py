"""Brand Asset Manager for Nexus Core V7.

Manages brand identity assets and guidelines.
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime

logger = logging.getLogger(__name__)


@dataclass
class BrandIdentity:
    """A brand identity system."""
    brand_id: str
    name: str
    description: str
    logo_asset_id: Optional[str] = None
    color_palette: Dict[str, str] = field(default_factory=dict)
    typography: Dict[str, Any] = field(default_factory=dict)
    voice_tone: str = ""
    imagery_style: str = ""
    guidelines_url: Optional[str] = None
    assets: List[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)


class BrandAssetManager:
    """Manager for brand assets and identities."""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._brands: Dict[str, BrandIdentity] = {}
        self._lock = asyncio.Lock()

    async def create_brand(self, name: str, description: str,
                          color_palette: Dict[str, str],
                          typography: Dict[str, Any],
                          **kwargs) -> BrandIdentity:
        """Create a new brand identity."""
        brand_id = f"brand:{name.lower().replace(' ', '_')}"

        brand = BrandIdentity(
            brand_id=brand_id,
            name=name,
            description=description,
            color_palette=color_palette,
            typography=typography,
            voice_tone=kwargs.get("voice_tone", "professional"),
            imagery_style=kwargs.get("imagery_style", "modern"),
            guidelines_url=kwargs.get("guidelines_url"),
            assets=kwargs.get("assets", []),
        )

        async with self._lock:
            self._brands[brand_id] = brand

        logger.info(f"Created brand identity: {name} ({brand_id})")
        return brand

    async def get_brand(self, brand_id: str) -> Optional[BrandIdentity]:
        """Get a brand by ID."""
        return self._brands.get(brand_id)

    async def update_brand(self, brand_id: str, updates: Dict[str, Any]) -> bool:
        """Update a brand identity."""
        async with self._lock:
            if brand_id not in self._brands:
                return False

            brand = self._brands[brand_id]

            if "color_palette" in updates:
                brand.color_palette.update(updates["color_palette"])
            if "typography" in updates:
                brand.typography.update(updates["typography"])
            if "voice_tone" in updates:
                brand.voice_tone = updates["voice_tone"]
            if "imagery_style" in updates:
                brand.imagery_style = updates["imagery_style"]
            if "assets" in updates:
                brand.assets = updates["assets"]

            brand.updated_at = datetime.now()
            return True

    async def add_asset(self, brand_id: str, asset_id: str) -> bool:
        """Add an asset to a brand."""
        async with self._lock:
            if brand_id not in self._brands:
                return False

            if asset_id not in self._brands[brand_id].assets:
                self._brands[brand_id].assets.append(asset_id)

        logger.info(f"Added asset {asset_id} to brand {brand_id}")
        return True

    async def validate_asset(self, brand_id: str, asset_metadata: Dict) -> Dict[str, Any]:
        """Validate an asset against brand guidelines."""
        brand = self._brands.get(brand_id)
        if not brand:
            return {"valid": False, "error": "Brand not found"}

        issues = []

        # Check color compliance
        if "colors" in asset_metadata:
            for color in asset_metadata["colors"]:
                if color not in brand.color_palette.values():
                    issues.append(f"Color {color} not in brand palette")

        # Check typography
        if "font" in asset_metadata:
            allowed_fonts = brand.typography.get("fonts", [])
            if allowed_fonts and asset_metadata["font"] not in allowed_fonts:
                issues.append(f"Font {asset_metadata['font']} not in brand typography")

        return {
            "valid": len(issues) == 0,
            "issues": issues,
            "brand_id": brand_id,
        }

    def get_stats(self) -> Dict[str, Any]:
        return {"brands": len(self._brands), "total_assets": sum(len(b.assets) for b in self._brands.values())}
