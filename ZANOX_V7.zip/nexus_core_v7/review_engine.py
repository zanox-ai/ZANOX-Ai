"""Creative Review Engine for Nexus Core V7.

Manages review workflows for creative assets.
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

logger = logging.getLogger(__name__)


class ReviewStatus(Enum):
    PENDING = "pending"
    IN_REVIEW = "in_review"
    APPROVED = "approved"
    REJECTED = "rejected"
    CHANGES_REQUESTED = "changes_requested"
    ESCALATED = "escalated"


@dataclass
class ReviewComment:
    """A comment on a review."""
    comment_id: str
    review_id: str
    author: str
    text: str
    position: Optional[Dict[str, Any]] = None
    created_at: datetime = field(default_factory=datetime.now)
    resolved: bool = False


@dataclass
class Review:
    """A review of a creative asset."""
    review_id: str
    asset_id: str
    reviewer: str
    status: ReviewStatus
    comments: List[ReviewComment] = field(default_factory=list)
    decision: Optional[str] = None
    feedback: str = ""
    created_at: datetime = field(default_factory=datetime.now)
    completed_at: Optional[datetime] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


class CreativeReviewEngine:
    """Engine for managing creative reviews."""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._reviews: Dict[str, Review] = {}
        self._asset_reviews: Dict[str, List[str]] = {}
        self._review_queue: List[str] = []
        self._lock = asyncio.Lock()

    async def create_review(self, asset_id: str, reviewer: str,
                           review_type: str = "standard") -> Review:
        """Create a new review for an asset."""
        review_id = f"review:{asset_id}:{datetime.now().isoformat()}"

        review = Review(
            review_id=review_id,
            asset_id=asset_id,
            reviewer=reviewer,
            status=ReviewStatus.PENDING,
            metadata={"review_type": review_type},
        )

        async with self._lock:
            self._reviews[review_id] = review

            if asset_id not in self._asset_reviews:
                self._asset_reviews[asset_id] = []
            self._asset_reviews[asset_id].append(review_id)

            self._review_queue.append(review_id)

        logger.info(f"Created review {review_id} for asset {asset_id}")
        return review

    async def start_review(self, review_id: str) -> bool:
        """Start a review."""
        async with self._lock:
            if review_id not in self._reviews:
                return False

            review = self._reviews[review_id]
            if review.status != ReviewStatus.PENDING:
                return False

            review.status = ReviewStatus.IN_REVIEW
            if review_id in self._review_queue:
                self._review_queue.remove(review_id)

        logger.info(f"Started review {review_id}")
        return True

    async def add_comment(self, review_id: str, author: str, text: str,
                         position: Optional[Dict] = None) -> ReviewComment:
        """Add a comment to a review."""
        if review_id not in self._reviews:
            raise ValueError(f"Review {review_id} not found")

        comment = ReviewComment(
            comment_id=f"comment:{review_id}:{len(self._reviews[review_id].comments)}",
            review_id=review_id,
            author=author,
            text=text,
            position=position,
        )

        self._reviews[review_id].comments.append(comment)
        logger.info(f"Added comment to review {review_id}")
        return comment

    async def submit_decision(self, review_id: str, decision: str,
                             feedback: str = "") -> bool:
        """Submit a review decision."""
        async with self._lock:
            if review_id not in self._reviews:
                return False

            review = self._reviews[review_id]

            if decision == "approve":
                review.status = ReviewStatus.APPROVED
            elif decision == "reject":
                review.status = ReviewStatus.REJECTED
            elif decision == "changes":
                review.status = ReviewStatus.CHANGES_REQUESTED
            elif decision == "escalate":
                review.status = ReviewStatus.ESCALATED
            else:
                return False

            review.decision = decision
            review.feedback = feedback
            review.completed_at = datetime.now()

        logger.info(f"Review {review_id} decision: {decision}")
        return True

    async def get_reviews_for_asset(self, asset_id: str) -> List[Review]:
        """Get all reviews for an asset."""
        review_ids = self._asset_reviews.get(asset_id, [])
        return [self._reviews[rid] for rid in review_ids if rid in self._reviews]

    async def get_pending_reviews(self, reviewer: Optional[str] = None) -> List[Review]:
        """Get pending reviews."""
        reviews = []
        for rid in self._review_queue:
            review = self._reviews.get(rid)
            if review and review.status == ReviewStatus.PENDING:
                if reviewer is None or review.reviewer == reviewer:
                    reviews.append(review)
        return reviews

    def get_stats(self) -> Dict[str, Any]:
        """Get review statistics."""
        statuses = {}
        for review in self._reviews.values():
            statuses[review.status.value] = statuses.get(review.status.value, 0) + 1

        return {
            "reviews": len(self._reviews),
            "assets_reviewed": len(self._asset_reviews),
            "pending_queue": len(self._review_queue),
            "statuses": statuses,
        }
