"""Document Builder for Nexus Core V7."""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime

logger = logging.getLogger(__name__)

@dataclass
class Document:
    document_id: str
    title: str
    sections: List[Dict] = field(default_factory=list)
    style: str = "default"
    status: str = "draft"
    created_at: datetime = field(default_factory=datetime.now)
    completed_at: Optional[datetime] = None

class DocumentBuilder:
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._documents: Dict[str, Document] = {}
        self._lock = asyncio.Lock()

    async def create_document(self, title: str, **kwargs) -> Document:
        document_id = f"doc:{title.lower().replace(' ', '_')}"
        document = Document(document_id=document_id, title=title, style=kwargs.get("style", "default"))
        async with self._lock:
            self._documents[document_id] = document
        logger.info(f"Created document: {title}")
        return document

    async def add_section(self, document_id: str, heading: str, content: str, level: int = 1) -> bool:
        document = self._documents.get(document_id)
        if not document:
            return False
        document.sections.append({"heading": heading, "content": content, "level": level, "order": len(document.sections)})
        return True

    async def generate_from_prompt(self, title: str, prompt: str, **kwargs) -> Document:
        document = await self.create_document(title, **kwargs)
        sections = [
            {"heading": "Introduction", "content": f"Introduction about {prompt}", "level": 1},
            {"heading": "Main Content", "content": f"Detailed content about {prompt}", "level": 1},
            {"heading": "Conclusion", "content": f"Conclusion about {prompt}", "level": 1},
        ]
        for section in sections:
            await self.add_section(document.document_id, section["heading"], section["content"], section["level"])
        document.status = "completed"
        document.completed_at = datetime.now()
        logger.info(f"Generated document from prompt: {title}")
        return document

    async def export(self, document_id: str, format: str = "pdf") -> Optional[str]:
        document = self._documents.get(document_id)
        if not document:
            return None
        output_path = f"/documents/{document_id}.{format}"
        logger.info(f"Exported document {document_id}")
        return output_path

    def get_stats(self) -> Dict[str, Any]:
        total_sections = sum(len(d.sections) for d in self._documents.values())
        return {"documents": len(self._documents), "total_sections": total_sections}
