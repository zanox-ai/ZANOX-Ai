"""Creative Provider Registry for Nexus Core V7.

Manages all creative AI providers and their capabilities.
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import uuid

logger = logging.getLogger(__name__)


class ProviderStatus(Enum):
    ACTIVE = "active"
    DEGRADED = "degraded"
    MAINTENANCE = "maintenance"
    OFFLINE = "offline"
    DEPRECATED = "deprecated"


@dataclass
class CreativeProvider:
    """A creative AI provider."""
    provider_id: str
    name: str
    provider_type: str
    api_endpoint: str
    supported_capabilities: List[str] = field(default_factory=list)
    supported_formats: List[str] = field(default_factory=list)
    pricing_tier: str = "standard"
    cost_per_request: float = 0.0
    cost_per_token: float = 0.0
    max_resolution: str = "1024x1024"
    max_duration: int = 60
    status: ProviderStatus = ProviderStatus.ACTIVE
    health_score: float = 1.0
    avg_latency_ms: float = 1000.0
    rate_limit_rpm: int = 60
    rate_limit_tpm: int = 100000
    auth_type: str = "api_key"
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.now)


class CreativeProviderRegistry:
    """Registry for managing creative AI providers."""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._providers: Dict[str, CreativeProvider] = {}
        self._capability_index: Dict[str, List[str]] = {}
        self._lock = asyncio.Lock()
        self._initialize_default_providers()

    def _initialize_default_providers(self):
        """Initialize all creative AI providers."""
        providers = [
            CreativeProvider("prov:midjourney", "Midjourney", "image_generation", "https://api.midjourney.com/v1",
                ["cap:image:gen", "cap:text2image", "cap:image:variations", "cap:illustration", "cap:concept:art"],
                ["png", "jpg", "webp"], "premium", 0.04, 0.0, "4096x4096", 0, ProviderStatus.ACTIVE, 1.0, 2000, 60, 100000, "api_key"),
            CreativeProvider("prov:flux", "Flux", "image_generation", "https://api.flux.ai/v1",
                ["cap:image:gen", "cap:text2image", "cap:image2image", "cap:image:upscale", "cap:logo:design", "cap:product:cover"],
                ["png", "jpg", "webp", "tiff"], "standard", 0.02, 0.0, "2048x2048", 0, ProviderStatus.ACTIVE, 1.0, 1500, 120, 200000, "api_key"),
            CreativeProvider("prov:stable-diffusion", "Stable Diffusion", "image_generation", "https://api.stability.ai/v1",
                ["cap:image:gen", "cap:text2image", "cap:image2image", "cap:image:upscale", "cap:image:restore", "cap:image:variations"],
                ["png", "jpg", "webp"], "standard", 0.01, 0.0, "2048x2048", 0, ProviderStatus.ACTIVE, 0.95, 1800, 100, 150000, "api_key"),
            CreativeProvider("prov:ideogram", "Ideogram", "image_generation", "https://api.ideogram.ai/v1",
                ["cap:text2image", "cap:logo:design", "cap:poster:design", "cap:typography"],
                ["png", "jpg"], "standard", 0.02, 0.0, "1024x1024", 0, ProviderStatus.ACTIVE, 1.0, 1200, 60, 100000, "api_key"),
            CreativeProvider("prov:leonardo", "Leonardo AI", "image_generation", "https://api.leonardo.ai/v1",
                ["cap:image:gen", "cap:text2image", "cap:illustration", "cap:concept:art"],
                ["png", "jpg", "webp"], "standard", 0.015, 0.0, "1536x1536", 0, ProviderStatus.ACTIVE, 0.98, 1600, 80, 120000, "api_key"),
            CreativeProvider("prov:adobe-firefly", "Adobe Firefly", "image_generation", "https://api.adobe.io/firefly/v1",
                ["cap:image:gen", "cap:text2image", "cap:photo:gen", "cap:advertising:design"],
                ["png", "jpg", "psd"], "premium", 0.05, 0.0, "4096x4096", 0, ProviderStatus.ACTIVE, 1.0, 2500, 30, 50000, "oauth"),
            CreativeProvider("prov:dalle", "DALL-E 3", "image_generation", "https://api.openai.com/v1/images",
                ["cap:image:gen", "cap:text2image", "cap:photo:gen", "cap:illustration"],
                ["png", "jpg", "webp"], "standard", 0.04, 0.0, "1024x1024", 0, ProviderStatus.ACTIVE, 1.0, 3000, 50, 80000, "api_key"),
            CreativeProvider("prov:runway", "Runway", "video_generation", "https://api.runwayml.com/v1",
                ["cap:video:gen", "cap:image2video", "cap:text2video", "cap:video:edit", "cap:motion:graphics", "cap:animation"],
                ["mp4", "mov", "webm"], "premium", 0.15, 0.0, "1920x1080", 16, ProviderStatus.ACTIVE, 1.0, 8000, 30, 50000, "api_key"),
            CreativeProvider("prov:pika", "Pika", "video_generation", "https://api.pika.art/v1",
                ["cap:video:gen", "cap:image2video", "cap:text2video", "cap:short:video", "cap:animation"],
                ["mp4", "mov"], "standard", 0.08, 0.0, "1280x720", 3, ProviderStatus.ACTIVE, 0.95, 5000, 60, 100000, "api_key"),
            CreativeProvider("prov:luma", "Luma", "video_generation", "https://api.lumalabs.ai/v1",
                ["cap:video:gen", "cap:image2video", "cap:text2video", "cap:cinematic"],
                ["mp4", "mov"], "premium", 0.20, 0.0, "1920x1080", 10, ProviderStatus.ACTIVE, 0.98, 10000, 20, 40000, "api_key"),
            CreativeProvider("prov:kling", "Kling", "video_generation", "https://api.klingai.com/v1",
                ["cap:video:gen", "cap:image2video", "cap:text2video"],
                ["mp4", "mov"], "standard", 0.10, 0.0, "1920x1080", 5, ProviderStatus.ACTIVE, 0.9, 6000, 40, 80000, "api_key"),
            CreativeProvider("prov:hailuo", "Hailuo", "video_generation", "https://api.hailuo.ai/v1",
                ["cap:video:gen", "cap:short:video", "cap:animation"],
                ["mp4", "mov"], "standard", 0.06, 0.0, "1280x720", 6, ProviderStatus.ACTIVE, 0.92, 4500, 50, 90000, "api_key"),
            CreativeProvider("prov:sora", "Sora", "video_generation", "https://api.openai.com/v1/videos",
                ["cap:video:gen", "cap:text2video", "cap:cinematic", "cap:long:video"],
                ["mp4", "mov"], "premium", 0.50, 0.0, "1920x1080", 60, ProviderStatus.ACTIVE, 1.0, 15000, 10, 20000, "api_key"),
            CreativeProvider("prov:elevenlabs", "ElevenLabs", "voice_generation", "https://api.elevenlabs.io/v1",
                ["cap:voice:gen", "cap:voice:clone", "cap:voice:convert", "cap:narration", "cap:podcast", "cap:speech:synth"],
                ["mp3", "wav", "ogg"], "premium", 0.03, 0.0, "0", 0, ProviderStatus.ACTIVE, 1.0, 800, 100, 200000, "api_key"),
            CreativeProvider("prov:playht", "PlayHT", "voice_generation", "https://api.play.ht/v1",
                ["cap:voice:gen", "cap:voice:clone", "cap:voice:convert", "cap:speech:synth"],
                ["mp3", "wav"], "standard", 0.02, 0.0, "0", 0, ProviderStatus.ACTIVE, 0.95, 1200, 80, 150000, "api_key"),
            CreativeProvider("prov:cartesia", "Cartesia", "voice_generation", "https://api.cartesia.ai/v1",
                ["cap:voice:gen", "cap:speech:synth", "cap:narration"],
                ["mp3", "wav"], "standard", 0.015, 0.0, "0", 0, ProviderStatus.ACTIVE, 0.97, 600, 120, 250000, "api_key"),
            CreativeProvider("prov:suno", "Suno", "music_generation", "https://api.suno.ai/v1",
                ["cap:music:gen", "cap:song:gen", "cap:bg:music", "cap:instrumental", "cap:lyrics:gen"],
                ["mp3", "wav"], "standard", 0.05, 0.0, "0", 120, ProviderStatus.ACTIVE, 1.0, 2000, 60, 100000, "api_key"),
            CreativeProvider("prov:udio", "Udio", "music_generation", "https://api.udio.com/v1",
                ["cap:music:gen", "cap:song:gen", "cap:bg:music", "cap:instrumental"],
                ["mp3", "wav"], "standard", 0.04, 0.0, "0", 120, ProviderStatus.ACTIVE, 0.95, 2500, 50, 80000, "api_key"),
            CreativeProvider("prov:aiva", "AIVA", "music_generation", "https://api.aiva.ai/v1",
                ["cap:music:gen", "cap:bg:music", "cap:instrumental"],
                ["mp3", "wav", "midi"], "standard", 0.03, 0.0, "0", 300, ProviderStatus.ACTIVE, 0.93, 3000, 40, 60000, "api_key"),
            CreativeProvider("prov:soundraw", "Soundraw", "music_generation", "https://api.soundraw.io/v1",
                ["cap:bg:music", "cap:instrumental"],
                ["mp3", "wav"], "standard", 0.02, 0.0, "0", 300, ProviderStatus.ACTIVE, 0.94, 1500, 60, 100000, "api_key"),
            CreativeProvider("prov:meshy", "Meshy", "3d_generation", "https://api.meshy.ai/v1",
                ["cap:3d:model", "cap:3d:asset", "cap:3d:character", "cap:3d:environment"],
                ["obj", "fbx", "gltf", "stl"], "premium", 0.10, 0.0, "0", 0, ProviderStatus.ACTIVE, 0.96, 5000, 30, 50000, "api_key"),
            CreativeProvider("prov:tripo", "Tripo", "3d_generation", "https://api.tripo3d.ai/v1",
                ["cap:3d:model", "cap:3d:asset", "cap:3d:character"],
                ["obj", "fbx", "gltf"], "standard", 0.08, 0.0, "0", 0, ProviderStatus.ACTIVE, 0.94, 4000, 40, 60000, "api_key"),
            CreativeProvider("prov:spline", "Spline AI", "3d_generation", "https://api.spline.design/v1",
                ["cap:3d:model", "cap:3d:asset", "cap:3d:environment"],
                ["obj", "gltf", "usdz"], "standard", 0.05, 0.0, "0", 0, ProviderStatus.ACTIVE, 0.92, 3500, 50, 80000, "api_key"),
            CreativeProvider("prov:gamma", "Gamma", "presentation", "https://api.gamma.app/v1",
                ["cap:presentation", "cap:pitch:deck", "cap:biz:presentation"],
                ["pptx", "pdf", "html"], "standard", 0.03, 0.0, "0", 0, ProviderStatus.ACTIVE, 0.98, 2000, 60, 100000, "api_key"),
            CreativeProvider("prov:beautiful-ai", "Beautiful AI", "presentation", "https://api.beautiful.ai/v1",
                ["cap:presentation", "cap:pitch:deck"],
                ["pptx", "pdf"], "standard", 0.02, 0.0, "0", 0, ProviderStatus.ACTIVE, 0.97, 1800, 80, 120000, "api_key"),
            CreativeProvider("prov:canva", "Canva AI", "design", "https://api.canva.com/v1",
                ["cap:graphic:design", "cap:social:media", "cap:banner:design", "cap:presentation", "cap:marketing:design"],
                ["png", "jpg", "pdf", "mp4"], "standard", 0.01, 0.0, "0", 0, ProviderStatus.ACTIVE, 1.0, 1000, 200, 300000, "api_key"),
            CreativeProvider("prov:adobe-express", "Adobe Express", "design", "https://api.adobe.io/express/v1",
                ["cap:graphic:design", "cap:social:media", "cap:marketing:design"],
                ["png", "jpg", "pdf", "mp4"], "standard", 0.015, 0.0, "0", 0, ProviderStatus.ACTIVE, 0.99, 1500, 150, 250000, "oauth"),
            CreativeProvider("prov:kaiber", "Kaiber", "animation", "https://api.kaiber.ai/v1",
                ["cap:animation", "cap:motion:graphics", "cap:video:gen"],
                ["mp4", "mov", "gif"], "standard", 0.07, 0.0, "0", 8, ProviderStatus.ACTIVE, 0.93, 6000, 40, 70000, "api_key"),
            CreativeProvider("prov:topaz", "Topaz Labs", "enhancement", "https://api.topazlabs.com/v1",
                ["cap:image:upscale", "cap:image:restore", "cap:video:upscale", "cap:video:enhance", "cap:audio:enhance", "cap:audio:restore"],
                ["png", "jpg", "mp4", "wav"], "premium", 0.06, 0.0, "0", 0, ProviderStatus.ACTIVE, 0.97, 4000, 30, 50000, "api_key"),
        ]
        for prov in providers:
            self._providers[prov.provider_id] = prov
            for cap in prov.supported_capabilities:
                if cap not in self._capability_index:
                    self._capability_index[cap] = []
                self._capability_index[cap].append(prov.provider_id)
        logger.info(f"Initialized {len(providers)} creative providers")

    async def get_provider(self, provider_id: str) -> Optional[CreativeProvider]:
        return self._providers.get(provider_id)

    async def find_providers_by_capability(self, capability_id: str, status: Optional[ProviderStatus] = None) -> List[CreativeProvider]:
        provider_ids = self._capability_index.get(capability_id, [])
        providers = [self._providers[pid] for pid in provider_ids if pid in self._providers]
        if status:
            providers = [p for p in providers if p.status == status]
        providers.sort(key=lambda p: (p.health_score * 1000 / max(1, p.avg_latency_ms)), reverse=True)
        return providers

    async def find_providers_by_type(self, provider_type: str) -> List[CreativeProvider]:
        return [p for p in self._providers.values() if p.provider_type == provider_type]

    async def update_provider_health(self, provider_id: str, health_score: float, latency_ms: float):
        async with self._lock:
            if provider_id in self._providers:
                self._providers[provider_id].health_score = health_score
                self._providers[provider_id].avg_latency_ms = latency_ms

    async def get_cheapest_provider(self, capability_id: str) -> Optional[CreativeProvider]:
        providers = await self.find_providers_by_capability(capability_id)
        if not providers:
            return None
        return min(providers, key=lambda p: p.cost_per_request)

    async def get_fastest_provider(self, capability_id: str) -> Optional[CreativeProvider]:
        providers = await self.find_providers_by_capability(capability_id)
        if not providers:
            return None
        return min(providers, key=lambda p: p.avg_latency_ms)

    def get_stats(self) -> Dict[str, Any]:
        active = sum(1 for p in self._providers.values() if p.status == ProviderStatus.ACTIVE)
        return {"providers": len(self._providers), "active": active,
            "capabilities_indexed": len(self._capability_index),
            "provider_types": len(set(p.provider_type for p in self._providers.values()))}
