"""Creative Routing Engine for Nexus Core V7.

Routes creative tasks to optimal providers, agents, and models.
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

logger = logging.getLogger(__name__)


class RoutingStrategy(Enum):
    QUALITY_FIRST = "quality_first"
    SPEED_FIRST = "speed_first"
    COST_FIRST = "cost_first"
    BALANCED = "balanced"
    CAPABILITY_MATCH = "capability_match"
    REDUNDANCY = "redundancy"


@dataclass
class RoutingDecision:
    decision_id: str
    task_id: str
    agent_id: str
    provider_id: str
    model_id: str
    tool_id: str
    strategy: RoutingStrategy
    confidence: float
    estimated_time: float
    estimated_cost: float
    estimated_quality: float
    reasoning: str
    fallback_providers: List[str] = field(default_factory=list)
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass
class RoutingScore:
    agent_id: str
    provider_id: str
    model_id: str
    tool_id: str
    quality_score: float
    speed_score: float
    cost_score: float
    capability_score: float
    reliability_score: float
    overall_score: float


class CreativeRoutingEngine:
    def __init__(self, agent_registry, provider_registry, config: Optional[Dict] = None):
        self.config = config or {}
        self._agent_registry = agent_registry
        self._provider_registry = provider_registry
        self._decisions: Dict[str, RoutingDecision] = {}
        self._strategy = RoutingStrategy.BALANCED
        self._weights = config.get("weights", {"quality": 0.35, "speed": 0.25, "cost": 0.20, "capability": 0.10, "reliability": 0.10})
        self._lock = asyncio.Lock()

    async def route_task(self, task_id: str, capability_id: str, parameters: Dict[str, Any],
                        strategy: Optional[RoutingStrategy] = None) -> RoutingDecision:
        strategy = strategy or self._strategy

        from .creative_registry import CreativeRegistry
        capability = None

        agents = await self._agent_registry.find_agents_by_capability(capability_id, status=None)
        if not agents:
            raise ValueError(f"No agents available for capability {capability_id}")

        providers = await self._provider_registry.find_providers_by_capability(capability_id)
        if not providers:
            raise ValueError(f"No providers available for capability {capability_id}")

        scores = []
        for agent in agents:
            for provider in providers:
                for model in agent.models:
                    if model in provider.supported_capabilities or any(m in provider.name.lower() for m in agent.models):
                        for tool in agent.tools:
                            score = self._score_candidate(agent, provider, model, tool, capability_id, strategy, parameters)
                            scores.append(score)

        if not scores:
            raise ValueError("No valid routing candidates found")

        scores.sort(key=lambda s: s.overall_score, reverse=True)
        best = scores[0]

        fallback = [s.provider_id for s in scores[1:4]]

        decision = RoutingDecision(
            decision_id=f"route:{task_id}:{datetime.now().isoformat()}",
            task_id=task_id, agent_id=best.agent_id, provider_id=best.provider_id,
            model_id=best.model_id, tool_id=best.tool_id, strategy=strategy,
            confidence=best.overall_score, estimated_time=1.0 / max(0.01, best.speed_score),
            estimated_cost=1.0 / max(0.01, best.cost_score), estimated_quality=best.quality_score,
            reasoning=f"Selected based on {strategy.value} strategy with score {best.overall_score:.3f}",
            fallback_providers=fallback,
        )

        async with self._lock:
            self._decisions[decision.decision_id] = decision

        logger.info(f"Routed task {task_id} to agent {best.agent_id} via provider {best.provider_id} (confidence: {best.overall_score:.3f})")
        return decision

    def _score_candidate(self, agent, provider, model: str, tool: str, capability_id: str,
                        strategy: RoutingStrategy, parameters: Dict) -> RoutingScore:
        quality_score = agent.quality_score * provider.health_score * (0.95 if model in provider.supported_capabilities else 0.75)
        speed_score = (1.0 if agent.status.value == "idle" else 0.5) * (1000.0 / max(100, provider.avg_latency_ms))
        cost_score = 1.0 / (1.0 + provider.cost_per_request * 10)
        capability_score = 1.0 if tool in ["figma", "photoshop", "blender", "premiere"] else 0.85
        reliability_score = agent.success_rate * provider.health_score

        if strategy == RoutingStrategy.QUALITY_FIRST:
            overall = quality_score * 0.6 + speed_score * 0.15 + cost_score * 0.05 + capability_score * 0.1 + reliability_score * 0.1
        elif strategy == RoutingStrategy.SPEED_FIRST:
            overall = speed_score * 0.6 + quality_score * 0.15 + cost_score * 0.05 + capability_score * 0.1 + reliability_score * 0.1
        elif strategy == RoutingStrategy.COST_FIRST:
            overall = cost_score * 0.6 + quality_score * 0.15 + speed_score * 0.15 + capability_score * 0.05 + reliability_score * 0.05
        else:
            overall = (quality_score * self._weights["quality"] + speed_score * self._weights["speed"] +
                      cost_score * self._weights["cost"] + capability_score * self._weights["capability"] +
                      reliability_score * self._weights["reliability"])

        return RoutingScore(
            agent_id=agent.agent_id, provider_id=provider.provider_id, model_id=model, tool_id=tool,
            quality_score=quality_score, speed_score=speed_score, cost_score=cost_score,
            capability_score=capability_score, reliability_score=reliability_score, overall_score=overall,
        )

    async def get_decision(self, decision_id: str) -> Optional[RoutingDecision]:
        return self._decisions.get(decision_id)

    async def set_strategy(self, strategy: RoutingStrategy):
        self._strategy = strategy
        logger.info(f"Routing strategy set to {strategy.value}")

    def get_stats(self) -> Dict[str, Any]:
        return {"total_decisions": len(self._decisions), "current_strategy": self._strategy.value, "weights": self._weights}
