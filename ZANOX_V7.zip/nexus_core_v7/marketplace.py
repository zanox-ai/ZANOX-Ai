"""Creative Marketplace for Nexus Core V7."""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
from collections import defaultdict

logger = logging.getLogger(__name__)

@dataclass
class MarketplaceListing:
    listing_id: str
    asset_id: str
    seller_id: str
    title: str
    description: str
    price: float
    currency: str = "USD"
    tags: List[str] = field(default_factory=list)
    downloads: int = 0
    rating: float = 0.0
    reviews: int = 0
    status: str = "active"
    created_at: datetime = field(default_factory=datetime.now)

class CreativeMarketplace:
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._listings: Dict[str, MarketplaceListing] = {}
        self._seller_listings: Dict[str, List[str]] = {}
        self._tag_index: Dict[str, List[str]] = {}
        self._lock = asyncio.Lock()

    async def create_listing(self, asset_id: str, seller_id: str, title: str, description: str, price: float, **kwargs) -> MarketplaceListing:
        listing_id = f"listing:{asset_id}:{seller_id}"
        listing = MarketplaceListing(
            listing_id=listing_id, asset_id=asset_id, seller_id=seller_id,
            title=title, description=description, price=price,
            currency=kwargs.get("currency", "USD"), tags=kwargs.get("tags", []),
        )
        async with self._lock:
            self._listings[listing_id] = listing
            if seller_id not in self._seller_listings:
                self._seller_listings[seller_id] = []
            self._seller_listings[seller_id].append(listing_id)
            for tag in listing.tags:
                if tag not in self._tag_index:
                    self._tag_index[tag] = []
                self._tag_index[tag].append(listing_id)
        logger.info(f"Created listing: {title} ({listing_id})")
        return listing

    async def search_listings(self, query: str, tags: Optional[List[str]] = None, max_price: Optional[float] = None) -> List[MarketplaceListing]:
        results = []
        query_lower = query.lower()
        for listing in self._listings.values():
            if listing.status != "active":
                continue
            if query_lower in listing.title.lower() or query_lower in listing.description.lower():
                if tags and not any(t in listing.tags for t in tags):
                    continue
                if max_price and listing.price > max_price:
                    continue
                results.append(listing)
        results.sort(key=lambda l: (l.rating * l.downloads), reverse=True)
        return results[:20]

    async def purchase(self, listing_id: str, buyer_id: str) -> Optional[str]:
        listing = self._listings.get(listing_id)
        if not listing:
            return None
        listing.downloads += 1
        return f"https://marketplace.uaos.io/download/{listing.asset_id}?buyer={buyer_id}"

    async def rate_listing(self, listing_id: str, rating: float, review: str = ""):
        if listing_id in self._listings:
            listing = self._listings[listing_id]
            listing.reviews += 1
            listing.rating = (listing.rating * (listing.reviews - 1) + rating) / listing.reviews

    def get_stats(self) -> Dict[str, Any]:
        return {"listings": len(self._listings), "sellers": len(self._seller_listings), "total_downloads": sum(l.downloads for l in self._listings.values())}
