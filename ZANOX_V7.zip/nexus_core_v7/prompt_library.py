"""Prompt Library for Nexus Core V7.

Central repository for curated prompts and prompt collections.
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime

logger = logging.getLogger(__name__)


@dataclass
class PromptCollection:
    """A collection of related prompts."""
    collection_id: str
    name: str
    description: str
    domain: str
    prompts: List[Dict[str, Any]] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)
    usage_count: int = 0
    avg_rating: float = 0.0


@dataclass
class CuratedPrompt:
    """A curated prompt with metadata."""
    prompt_id: str
    text: str
    domain: str
    category: str
    tags: List[str] = field(default_factory=list)
    rating: float = 0.0
    usage_count: int = 0
    success_rate: float = 0.0
    created_by: str = "system"
    created_at: datetime = field(default_factory=datetime.now)


class PromptLibrary:
    """Library for managing curated prompts."""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._collections: Dict[str, PromptCollection] = {}
        self._prompts: Dict[str, CuratedPrompt] = {}
        self._domain_index: Dict[str, List[str]] = {}
        self._tag_index: Dict[str, List[str]] = {}
        self._lock = asyncio.Lock()
        self._initialize_default_collections()

    def _initialize_default_collections(self):
        """Initialize default prompt collections."""
        collections = [
            PromptCollection("coll:image:portraits", "Portrait Photography", "Professional portrait prompts", "image_generation",
                [{"text": "professional portrait, studio lighting, 85mm lens, shallow depth of field, sharp focus on eyes, natural skin texture", "category": "studio"},
                 {"text": "environmental portrait, natural light, candid moment, authentic expression, documentary style", "category": "environmental"}],
                ["portrait", "photography", "people"]),
            PromptCollection("coll:image:landscapes", "Landscape Photography", "Stunning landscape prompts", "image_generation",
                [{"text": "epic landscape, golden hour, dramatic clouds, mountain vista, 8k uhd, national geographic style", "category": "mountain"},
                 {"text": "serene seascape, long exposure, silky water, sunset colors, peaceful atmosphere", "category": "ocean"}],
                ["landscape", "nature", "scenic"]),
            PromptCollection("coll:logo:minimal", "Minimalist Logos", "Clean minimalist logo prompts", "logo_design",
                [{"text": "minimalist logo, single line art, geometric shape, negative space, scalable vector", "category": "geometric"},
                 {"text": "abstract monogram, elegant typography, premium brand mark, timeless design", "category": "monogram"}],
                ["logo", "minimalist", "brand"]),
            PromptCollection("coll:ui:dashboard", "Dashboard UI", "Dashboard and admin UI prompts", "ui_design",
                [{"text": "modern dashboard UI, data visualization, dark mode, clean charts, intuitive navigation, material design", "category": "dark"},
                 {"text": "analytics dashboard, real-time metrics, card-based layout, responsive grid, professional SaaS", "category": "analytics"}],
                ["ui", "dashboard", "web"]),
            PromptCollection("coll:video:cinematic", "Cinematic Videos", "Cinematic video generation prompts", "video_generation",
                [{"text": "cinematic establishing shot, golden hour, smooth dolly movement, shallow depth of field, film grain", "category": "establishing"},
                 {"text": "dramatic close-up, intense emotion, chiaroscuro lighting, anamorphic lens flare", "category": "closeup"}],
                ["video", "cinematic", "film"]),
            PromptCollection("coll:music:ambient", "Ambient Music", "Ambient and atmospheric music prompts", "music_generation",
                [{"text": "ambient soundscape, ethereal pads, soft piano, nature sounds, meditative atmosphere, 60bpm", "category": "meditative"},
                 {"text": "cinematic ambient, orchestral drones, subtle percussion, emotional undertones, wide stereo field", "category": "cinematic"}],
                ["music", "ambient", "atmospheric"]),
            PromptCollection("coll:voice:narration", "Professional Narration", "Voice narration prompts", "voice_generation",
                [{"text": "warm, authoritative narration, clear diction, measured pace, professional broadcast quality", "category": "professional"},
                 {"text": "friendly, conversational tone, natural inflections, engaging storytelling voice", "category": "conversational"}],
                ["voice", "narration", "audio"]),
            PromptCollection("coll:3d:product", "Product 3D Models", "Product visualization 3D prompts", "3d_model",
                [{"text": "photorealistic product render, studio lighting, white background, clean reflections, e-commerce quality", "category": "studio"},
                 {"text": "lifestyle product shot, natural environment, soft shadows, material accurate, hero angle", "category": "lifestyle"}],
                ["3d", "product", "render"]),
            PromptCollection("coll:content:marketing", "Marketing Content", "Marketing copy prompts", "content",
                [{"text": "compelling headline, benefit-driven copy, clear call-to-action, conversion optimized, A/B test ready", "category": "headline"},
                 {"text": "engaging product description, emotional storytelling, feature benefits, SEO optimized", "category": "description"}],
                ["content", "marketing", "copy"]),
            PromptCollection("coll:brand:identity", "Brand Identity", "Brand identity system prompts", "brand_identity",
                [{"text": "comprehensive brand identity, color palette, typography system, visual guidelines, cohesive aesthetic", "category": "system"},
                 {"text": "luxury brand identity, premium feel, sophisticated color scheme, elegant typography, high-end positioning", "category": "luxury"}],
                ["brand", "identity", "design"]),
        ]

        for coll in collections:
            self._collections[coll.collection_id] = coll
            for prompt in coll.prompts:
                pid = f"prompt:{coll.collection_id}:{len(self._prompts)}"
                cp = CuratedPrompt(prompt_id=pid, text=prompt["text"], domain=coll.domain,
                    category=prompt.get("category", "general"), tags=coll.tags, created_by="system")
                self._prompts[pid] = cp

                if coll.domain not in self._domain_index:
                    self._domain_index[coll.domain] = []
                self._domain_index[coll.domain].append(pid)

                for tag in coll.tags:
                    if tag not in self._tag_index:
                        self._tag_index[tag] = []
                    self._tag_index[tag].append(pid)

        logger.info(f"Initialized {len(collections)} prompt collections with {len(self._prompts)} prompts")

    async def search_prompts(self, query: str, domain: Optional[str] = None,
                          tags: Optional[List[str]] = None) -> List[CuratedPrompt]:
        """Search prompts by query, domain, and tags."""
        results = []
        query_lower = query.lower()

        for prompt in self._prompts.values():
            if domain and prompt.domain != domain:
                continue
            if tags and not any(t in prompt.tags for t in tags):
                continue

            if query_lower in prompt.text.lower() or query_lower in prompt.category.lower():
                results.append(prompt)

        results.sort(key=lambda p: (p.rating * p.success_rate), reverse=True)
        return results[:20]

    async def get_collection(self, collection_id: str) -> Optional[PromptCollection]:
        """Get a prompt collection by ID."""
        return self._collections.get(collection_id)

    async def add_prompt(self, collection_id: str, text: str, category: str,
                        rating: float = 0.0, created_by: str = "user") -> str:
        """Add a new prompt to a collection."""
        collection = self._collections.get(collection_id)
        if not collection:
            raise ValueError(f"Collection {collection_id} not found")

        prompt_id = f"prompt:{collection_id}:{len(self._prompts)}"

        prompt = CuratedPrompt(
            prompt_id=prompt_id,
            text=text,
            domain=collection.domain,
            category=category,
            tags=collection.tags,
            rating=rating,
            created_by=created_by,
        )

        async with self._lock:
            self._prompts[prompt_id] = prompt
            collection.prompts.append({"text": text, "category": category})

        logger.info(f"Added prompt to collection {collection_id}")
        return prompt_id

    async def rate_prompt(self, prompt_id: str, rating: float, success: bool = True):
        """Rate a prompt based on results."""
        if prompt_id not in self._prompts:
            return

        prompt = self._prompts[prompt_id]
        prompt.usage_count += 1
        prompt.rating = (prompt.rating * (prompt.usage_count - 1) + rating) / prompt.usage_count
        prompt.success_rate = (prompt.success_rate * (prompt.usage_count - 1) + (1.0 if success else 0.0)) / prompt.usage_count

    def get_stats(self) -> Dict[str, Any]:
        return {
            "collections": len(self._collections),
            "prompts": len(self._prompts),
            "domains": len(self._domain_index),
            "tags": len(self._tag_index),
        }
