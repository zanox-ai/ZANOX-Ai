"""Asset Version Control for Nexus Core V7.

Manages versioning of creative assets.
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime

logger = logging.getLogger(__name__)


@dataclass
class AssetVersion:
    """A version of an asset."""
    version_id: str
    asset_id: str
    version_number: int
    url: str
    path: str
    changes: str
    created_by: str
    created_at: datetime = field(default_factory=datetime.now)
    metadata: Dict[str, Any] = field(default_factory=dict)


class AssetVersionControl:
    """Version control for creative assets."""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._versions: Dict[str, List[AssetVersion]] = {}
        self._lock = asyncio.Lock()

    async def create_version(self, asset_id: str, url: str, path: str,
                            changes: str, created_by: str,
                            metadata: Optional[Dict] = None) -> AssetVersion:
        """Create a new version of an asset."""
        async with self._lock:
            if asset_id not in self._versions:
                self._versions[asset_id] = []

            version_number = len(self._versions[asset_id]) + 1
            version_id = f"ver:{asset_id}:{version_number}"

            version = AssetVersion(
                version_id=version_id,
                asset_id=asset_id,
                version_number=version_number,
                url=url,
                path=path,
                changes=changes,
                created_by=created_by,
                metadata=metadata or {},
            )

            self._versions[asset_id].append(version)

        logger.info(f"Created version {version_number} for asset {asset_id}")
        return version

    async def get_versions(self, asset_id: str) -> List[AssetVersion]:
        """Get all versions of an asset."""
        return self._versions.get(asset_id, [])

    async def get_version(self, asset_id: str, version_number: int) -> Optional[AssetVersion]:
        """Get a specific version."""
        versions = self._versions.get(asset_id, [])
        for v in versions:
            if v.version_number == version_number:
                return v
        return None

    async def rollback(self, asset_id: str, version_number: int) -> Optional[AssetVersion]:
        """Rollback to a specific version."""
        target = await self.get_version(asset_id, version_number)
        if not target:
            return None

        # Create a new version based on the target
        new_version = await self.create_version(
            asset_id=asset_id,
            url=target.url,
            path=target.path,
            changes=f"Rollback to version {version_number}",
            created_by="system",
            metadata={"rollback_from": len(self._versions.get(asset_id, [])), "target_version": version_number},
        )

        logger.info(f"Rolled back asset {asset_id} to version {version_number}")
        return new_version

    async def compare_versions(self, asset_id: str, v1: int, v2: int) -> Dict[str, Any]:
        """Compare two versions."""
        ver1 = await self.get_version(asset_id, v1)
        ver2 = await self.get_version(asset_id, v2)

        if not ver1 or not ver2:
            return {"error": "Version not found"}

        return {
            "version_1": v1,
            "version_2": v2,
            "created_by_1": ver1.created_by,
            "created_by_2": ver2.created_by,
            "time_diff": (ver2.created_at - ver1.created_at).total_seconds(),
            "changes_1": ver1.changes,
            "changes_2": ver2.changes,
        }

    def get_stats(self) -> Dict[str, Any]:
        total_versions = sum(len(v) for v in self._versions.values())
        return {
            "assets_tracked": len(self._versions),
            "total_versions": total_versions,
            "avg_versions_per_asset": total_versions / max(1, len(self._versions)),
        }
