"""Quality Scoring Engine for Nexus Core V7.

Evaluates and scores creative asset quality.
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from datetime import datetime

logger = logging.getLogger(__name__)


@dataclass
class QualityScore:
    """Quality score for an asset."""
    asset_id: str
    overall_score: float
    technical_score: float
    aesthetic_score: float
    relevance_score: float
    originality_score: float
    consistency_score: float
    details: Dict[str, Any]
    evaluated_at: datetime


class QualityScoringEngine:
    """Engine for scoring creative asset quality."""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._scores: Dict[str, QualityScore] = {}
        self._criteria_weights = config.get("weights", {
            "technical": 0.25,
            "aesthetic": 0.25,
            "relevance": 0.20,
            "originality": 0.15,
            "consistency": 0.15,
        })
        self._lock = asyncio.Lock()

    async def evaluate(self, asset_id: str, asset_type: str,
                      metadata: Dict[str, Any],
                      reference_data: Optional[Dict] = None) -> QualityScore:
        """Evaluate the quality of an asset."""
        # Technical evaluation
        technical_score = await self._evaluate_technical(asset_type, metadata)

        # Aesthetic evaluation
        aesthetic_score = await self._evaluate_aesthetic(asset_type, metadata)

        # Relevance evaluation
        relevance_score = await self._evaluate_relevance(metadata, reference_data)

        # Originality evaluation
        originality_score = await self._evaluate_originality(metadata)

        # Consistency evaluation
        consistency_score = await self._evaluate_consistency(metadata, reference_data)

        # Calculate overall score
        overall = (
            technical_score * self._criteria_weights["technical"] +
            aesthetic_score * self._criteria_weights["aesthetic"] +
            relevance_score * self._criteria_weights["relevance"] +
            originality_score * self._criteria_weights["originality"] +
            consistency_score * self._criteria_weights["consistency"]
        )

        score = QualityScore(
            asset_id=asset_id,
            overall_score=overall,
            technical_score=technical_score,
            aesthetic_score=aesthetic_score,
            relevance_score=relevance_score,
            originality_score=originality_score,
            consistency_score=consistency_score,
            details={
                "technical_details": await self._get_technical_details(metadata),
                "aesthetic_details": await self._get_aesthetic_details(metadata),
            },
            evaluated_at=datetime.now(),
        )

        async with self._lock:
            self._scores[asset_id] = score

        logger.info(f"Evaluated asset {asset_id}: overall={overall:.2f}")
        return score

    async def _evaluate_technical(self, asset_type: str, metadata: Dict) -> float:
        """Evaluate technical quality."""
        scores = []

        if "resolution" in metadata:
            res = metadata["resolution"]
            if isinstance(res, str) and "x" in res:
                w, h = map(int, res.split("x"))
                scores.append(min(1.0, (w * h) / (1920 * 1080)))

        if "file_size" in metadata:
            scores.append(min(1.0, metadata["file_size"] / 10_000_000))

        if "format" in metadata:
            lossless = metadata["format"] in ["png", "tiff", "wav", "flac"]
            scores.append(1.0 if lossless else 0.8)

        return sum(scores) / max(1, len(scores)) if scores else 0.7

    async def _evaluate_aesthetic(self, asset_type: str, metadata: Dict) -> float:
        """Evaluate aesthetic quality."""
        # In production, this would use ML models
        # For now, return a score based on metadata
        if "quality_tags" in metadata:
            tags = metadata["quality_tags"]
            high_quality = sum(1 for t in tags if t in ["masterpiece", "best_quality", "highly_detailed"])
            return 0.5 + (high_quality / max(1, len(tags))) * 0.5
        return 0.7

    async def _evaluate_relevance(self, metadata: Dict, reference: Optional[Dict]) -> float:
        """Evaluate relevance to requirements."""
        if not reference:
            return 0.8

        # Compare metadata with reference
        match_score = 0.0
        checks = 0

        for key in ["domain", "style", "format"]:
            if key in metadata and key in reference:
                checks += 1
                if metadata[key] == reference[key]:
                    match_score += 1.0

        return match_score / max(1, checks) if checks > 0 else 0.8

    async def _evaluate_originality(self, metadata: Dict) -> float:
        """Evaluate originality."""
        # Check for uniqueness indicators
        if "generation_id" in metadata:
            return 0.9
        if "is_unique" in metadata and metadata["is_unique"]:
            return 0.95
        return 0.7

    async def _evaluate_consistency(self, metadata: Dict, reference: Optional[Dict]) -> float:
        """Evaluate consistency with brand/style guidelines."""
        if not reference:
            return 0.8

        if "brand_id" in metadata and "brand_id" in reference:
            if metadata["brand_id"] == reference["brand_id"]:
                return 0.95

        return 0.7

    async def _get_technical_details(self, metadata: Dict) -> Dict:
        """Get technical details."""
        return {
            "resolution": metadata.get("resolution", "unknown"),
            "format": metadata.get("format", "unknown"),
            "file_size": metadata.get("file_size", 0),
        }

    async def _get_aesthetic_details(self, metadata: Dict) -> Dict:
        """Get aesthetic details."""
        return {
            "style": metadata.get("style", "unknown"),
            "color_palette": metadata.get("color_palette", []),
            "composition": metadata.get("composition", "unknown"),
        }

    async def get_score(self, asset_id: str) -> Optional[QualityScore]:
        """Get quality score for an asset."""
        return self._scores.get(asset_id)

    def get_stats(self) -> Dict[str, Any]:
        """Get scoring statistics."""
        if not self._scores:
            return {"evaluated": 0}

        overall_scores = [s.overall_score for s in self._scores.values()]
        return {
            "evaluated": len(self._scores),
            "avg_overall": sum(overall_scores) / len(overall_scores),
            "min_score": min(overall_scores),
            "max_score": max(overall_scores),
        }
