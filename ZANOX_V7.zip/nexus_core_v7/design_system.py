"""Design System Manager for Nexus Core V7.

Manages design systems and component libraries.
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime

logger = logging.getLogger(__name__)


@dataclass
class DesignSystem:
    """A design system."""
    system_id: str
    name: str
    description: str
    components: Dict[str, Any] = field(default_factory=dict)
    tokens: Dict[str, Any] = field(default_factory=dict)
    patterns: Dict[str, Any] = field(default_factory=dict)
    brand_id: Optional[str] = None
    version: str = "1.0.0"
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)


class DesignSystemManager:
    """Manager for design systems."""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._systems: Dict[str, DesignSystem] = {}
        self._lock = asyncio.Lock()

    async def create_system(self, name: str, description: str,
                           brand_id: Optional[str] = None,
                           **kwargs) -> DesignSystem:
        """Create a new design system."""
        system_id = f"ds:{name.lower().replace(' ', '_')}"

        system = DesignSystem(
            system_id=system_id,
            name=name,
            description=description,
            brand_id=brand_id,
            components=kwargs.get("components", {}),
            tokens=kwargs.get("tokens", {}),
            patterns=kwargs.get("patterns", {}),
            version=kwargs.get("version", "1.0.0"),
        )

        async with self._lock:
            self._systems[system_id] = system

        logger.info(f"Created design system: {name} ({system_id})")
        return system

    async def get_system(self, system_id: str) -> Optional[DesignSystem]:
        """Get a design system."""
        return self._systems.get(system_id)

    async def add_component(self, system_id: str, component_name: str,
                           component_def: Dict[str, Any]) -> bool:
        """Add a component to a design system."""
        async with self._lock:
            if system_id not in self._systems:
                return False

            self._systems[system_id].components[component_name] = component_def
            self._systems[system_id].updated_at = datetime.now()

        logger.info(f"Added component {component_name} to {system_id}")
        return True

    async def add_token(self, system_id: str, token_name: str,
                       token_value: Any) -> bool:
        """Add a design token."""
        async with self._lock:
            if system_id not in self._systems:
                return False

            self._systems[system_id].tokens[token_name] = token_value
            self._systems[system_id].updated_at = datetime.now()

        return True

    async def export_system(self, system_id: str, format: str = "json") -> Dict[str, Any]:
        """Export a design system."""
        system = self._systems.get(system_id)
        if not system:
            return {"error": "System not found"}

        return {
            "name": system.name,
            "version": system.version,
            "tokens": system.tokens,
            "components": system.components,
            "patterns": system.patterns,
        }

    def get_stats(self) -> Dict[str, Any]:
        total_components = sum(len(s.components) for s in self._systems.values())
        total_tokens = sum(len(s.tokens) for s in self._systems.values())
        return {"systems": len(self._systems), "components": total_components, "tokens": total_tokens}
