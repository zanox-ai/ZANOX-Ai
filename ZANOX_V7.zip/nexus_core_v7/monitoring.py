"""Creative Monitoring Layer for Nexus Core V7."""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

logger = logging.getLogger(__name__)

class AlertSeverity(Enum):
    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"

@dataclass
class HealthCheck:
    check_id: str
    component: str
    status: str
    latency_ms: float
    timestamp: datetime
    details: Dict[str, Any] = field(default_factory=dict)

@dataclass
class Alert:
    alert_id: str
    severity: AlertSeverity
    component: str
    message: str
    timestamp: datetime
    resolved: bool = False
    resolved_at: Optional[datetime] = None

class CreativeMonitoringLayer:
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._health_checks: Dict[str, List[HealthCheck]] = {}
        self._alerts: List[Alert] = []
        self._is_monitoring = False
        self._monitor_task: Optional[asyncio.Task] = None
        self._components: List[str] = []
        self._lock = asyncio.Lock()

    async def start(self):
        self._is_monitoring = True
        self._monitor_task = asyncio.create_task(self._monitor_loop())
        logger.info("Monitoring started")

    async def stop(self):
        self._is_monitoring = False
        if self._monitor_task:
            self._monitor_task.cancel()
        logger.info("Monitoring stopped")

    async def _monitor_loop(self):
        interval = self.config.get("interval", 30)
        while self._is_monitoring:
            try:
                for component in self._components:
                    await self._check_component(component)
                await asyncio.sleep(interval)
            except Exception as e:
                logger.error(f"Monitoring error: {e}")
                await asyncio.sleep(interval)

    async def _check_component(self, component: str):
        check = HealthCheck(
            check_id=f"check:{component}:{datetime.now().isoformat()}",
            component=component, status="healthy", latency_ms=100.0, details={},
        )
        async with self._lock:
            if component not in self._health_checks:
                self._health_checks[component] = []
            self._health_checks[component].append(check)
            if len(self._health_checks[component]) > 100:
                self._health_checks[component] = self._health_checks[component][-50:]

    async def register_component(self, component: str):
        if component not in self._components:
            self._components.append(component)
            logger.info(f"Registered component for monitoring: {component}")

    async def create_alert(self, severity: AlertSeverity, component: str, message: str) -> Alert:
        alert = Alert(
            alert_id=f"alert:{component}:{datetime.now().isoformat()}",
            severity=severity, component=component, message=message, timestamp=datetime.now(),
        )
        async with self._lock:
            self._alerts.append(alert)
        logger.warning(f"Alert: [{severity.value}] {component} - {message}")
        return alert

    async def resolve_alert(self, alert_id: str) -> bool:
        async with self._lock:
            for alert in self._alerts:
                if alert.alert_id == alert_id and not alert.resolved:
                    alert.resolved = True
                    alert.resolved_at = datetime.now()
                    return True
        return False

    async def get_health(self, component: Optional[str] = None) -> Dict[str, Any]:
        if component:
            checks = self._health_checks.get(component, [])
            if checks:
                latest = checks[-1]
                return {"component": component, "status": latest.status, "latency_ms": latest.latency_ms, "last_check": latest.timestamp.isoformat()}
            return {"component": component, "status": "unknown"}
        return {"components": len(self._components), "checks_performed": sum(len(c) for c in self._health_checks.values())}

    def get_stats(self) -> Dict[str, Any]:
        active_alerts = sum(1 for a in self._alerts if not a.resolved)
        return {"components": len(self._components), "total_alerts": len(self._alerts), "active_alerts": active_alerts, "is_monitoring": self._is_monitoring}
