"""Publishing Pipeline for Nexus Core V7.

Manages publishing of creative assets to various platforms.
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

logger = logging.getLogger(__name__)


class PublishStatus(Enum):
    DRAFT = "draft"
    SCHEDULED = "scheduled"
    PUBLISHING = "publishing"
    PUBLISHED = "published"
    FAILED = "failed"
    UNPUBLISHED = "unpublished"


@dataclass
class PublishTarget:
    """A publishing target platform."""
    target_id: str
    name: str
    platform_type: str
    config: Dict[str, Any] = field(default_factory=dict)
    supported_formats: List[str] = field(default_factory=list)
    max_file_size: int = 50_000_000


@dataclass
class PublishJob:
    """A publishing job."""
    job_id: str
    asset_id: str
    target_id: str
    status: PublishStatus
    publish_url: Optional[str] = None
    scheduled_at: Optional[datetime] = None
    published_at: Optional[datetime] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None


class PublishingPipeline:
    """Pipeline for publishing creative assets."""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._targets: Dict[str, PublishTarget] = {}
        self._jobs: Dict[str, PublishJob] = {}
        self._lock = asyncio.Lock()
        self._initialize_default_targets()

    def _initialize_default_targets(self):
        """Initialize default publishing targets."""
        targets = [
            PublishTarget("target:cdn", "CDN Storage", "cdn", {"url": "https://cdn.uaos.io"}, ["png", "jpg", "mp4", "mp3", "pdf"]),
            PublishTarget("target:social:instagram", "Instagram", "social", {"api": "instagram"}, ["jpg", "png", "mp4"]),
            PublishTarget("target:social:twitter", "Twitter/X", "social", {"api": "twitter"}, ["jpg", "png", "gif", "mp4"]),
            PublishTarget("target:social:linkedin", "LinkedIn", "social", {"api": "linkedin"}, ["jpg", "png", "pdf"]),
            PublishTarget("target:web:wordpress", "WordPress", "cms", {"api": "wordpress"}, ["jpg", "png", "mp4", "pdf"]),
            PublishTarget("target:web:shopify", "Shopify", "ecommerce", {"api": "shopify"}, ["jpg", "png"]),
            PublishTarget("target:marketplace:etsy", "Etsy", "marketplace", {"api": "etsy"}, ["jpg", "png"]),
            PublishTarget("target:cloud:aws", "AWS S3", "cloud", {"bucket": "uaos-assets"}, ["*"]),
            PublishTarget("target:cloud:gcp", "Google Cloud", "cloud", {"bucket": "uaos-assets"}, ["*"]),
            PublishTarget("target:design:figma", "Figma", "design", {"api": "figma"}, ["png", "svg", "pdf"]),
            PublishTarget("target:design:canva", "Canva", "design", {"api": "canva"}, ["png", "jpg", "mp4"]),
        ]
        for t in targets:
            self._targets[t.target_id] = t
        logger.info(f"Initialized {len(targets)} publishing targets")

    async def publish(self, asset_id: str, target_id: str,
                     schedule: Optional[datetime] = None,
                     metadata: Optional[Dict] = None) -> str:
        """Publish an asset to a target."""
        if target_id not in self._targets:
            raise ValueError(f"Target {target_id} not found")

        job_id = f"pub:{asset_id}:{target_id}:{datetime.now().isoformat()}"

        job = PublishJob(
            job_id=job_id,
            asset_id=asset_id,
            target_id=target_id,
            status=PublishStatus.SCHEDULED if schedule else PublishStatus.PUBLISHING,
            scheduled_at=schedule,
            metadata=metadata or {},
        )

        async with self._lock:
            self._jobs[job_id] = job

        if not schedule:
            await self._execute_publish(job)

        logger.info(f"Created publish job {job_id}")
        return job_id

    async def _execute_publish(self, job: PublishJob):
        """Execute a publishing job."""
        job.status = PublishStatus.PUBLISHING

        try:
            target = self._targets[job.target_id]

            # Simulate publishing
            await asyncio.sleep(0.05)

            job.publish_url = f"{target.config.get('url', '')}/{job.asset_id}"
            job.status = PublishStatus.PUBLISHED
            job.published_at = datetime.now()

            logger.info(f"Published {job.asset_id} to {target.name}")
        except Exception as e:
            job.status = PublishStatus.FAILED
            job.error = str(e)
            logger.error(f"Publish failed: {e}")

    async def unpublish(self, job_id: str) -> bool:
        """Unpublish an asset."""
        async with self._lock:
            if job_id not in self._jobs:
                return False

            job = self._jobs[job_id]
            if job.status != PublishStatus.PUBLISHED:
                return False

            job.status = PublishStatus.UNPUBLISHED
            job.publish_url = None

        logger.info(f"Unpublished job {job_id}")
        return True

    async def get_publish_status(self, job_id: str) -> Optional[Dict]:
        """Get publish status."""
        job = self._jobs.get(job_id)
        if not job:
            return None

        return {
            "job_id": job.job_id,
            "status": job.status.value,
            "url": job.publish_url,
            "published_at": job.published_at.isoformat() if job.published_at else None,
        }

    def get_stats(self) -> Dict[str, Any]:
        statuses = {}
        for job in self._jobs.values():
            statuses[job.status.value] = statuses.get(job.status.value, 0) + 1
        return {"targets": len(self._targets), "jobs": len(self._jobs), "statuses": statuses}
