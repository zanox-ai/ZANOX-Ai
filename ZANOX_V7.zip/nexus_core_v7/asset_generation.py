"""Asset Generation Engine for Nexus Core V7.

Orchestrates generation of creative assets across all modalities.
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import uuid

logger = logging.getLogger(__name__)


class AssetType(Enum):
    IMAGE = "image"
    VIDEO = "video"
    AUDIO = "audio"
    MUSIC = "music"
    THREE_D = "3d"
    DOCUMENT = "document"
    PRESENTATION = "presentation"
    TEMPLATE = "template"


class GenerationStatus(Enum):
    QUEUED = "queued"
    GENERATING = "generating"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class GenerationJob:
    job_id: str
    asset_type: AssetType
    capability_id: str
    provider_id: str
    prompt: str
    parameters: Dict[str, Any] = field(default_factory=dict)
    status: GenerationStatus = GenerationStatus.QUEUED
    output_url: Optional[str] = None
    output_path: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.now)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    error: Optional[str] = None


class AssetGenerationEngine:
    """Engine for generating creative assets."""

    def __init__(self, routing_engine, provider_registry, config: Optional[Dict] = None):
        self.config = config or {}
        self._routing_engine = routing_engine
        self._provider_registry = provider_registry
        self._jobs: Dict[str, GenerationJob] = {}
        self._queue: asyncio.Queue = asyncio.Queue()
        self._workers: List[asyncio.Task] = []
        self._max_workers = config.get("max_workers", 5)
        self._lock = asyncio.Lock()
        self._start_workers()

    def _start_workers(self):
        """Start generation workers."""
        for i in range(self._max_workers):
            task = asyncio.create_task(self._worker_loop(i))
            self._workers.append(task)
        logger.info(f"Started {self._max_workers} generation workers")

    async def _worker_loop(self, worker_id: int):
        """Worker loop for processing generation jobs."""
        while True:
            try:
                job = await self._queue.get()
                await self._process_job(job)
            except Exception as e:
                logger.error(f"Worker {worker_id} error: {e}")

    async def submit_job(self, asset_type: AssetType, capability_id: str,
                        prompt: str, parameters: Dict[str, Any],
                        project_id: Optional[str] = None) -> str:
        """Submit a generation job."""
        job_id = f"gen:{uuid.uuid4().hex[:8]}"

        # Find best provider
        providers = await self._provider_registry.find_providers_by_capability(capability_id)
        if not providers:
            raise ValueError(f"No providers available for {capability_id}")

        provider = providers[0]

        job = GenerationJob(
            job_id=job_id,
            asset_type=asset_type,
            capability_id=capability_id,
            provider_id=provider.provider_id,
            prompt=prompt,
            parameters=parameters,
            metadata={"project_id": project_id},
        )

        async with self._lock:
            self._jobs[job_id] = job

        await self._queue.put(job)
        logger.info(f"Submitted generation job {job_id} for {asset_type.value}")
        return job_id

    async def _process_job(self, job: GenerationJob):
        """Process a generation job."""
        job.status = GenerationStatus.GENERATING
        job.started_at = datetime.now()

        try:
            # Simulate generation (in production, this would call the actual provider API)
            await asyncio.sleep(0.1)

            # Generate output path
            output_path = f"/assets/{job.asset_type.value}/{job.job_id}.{self._get_extension(job.asset_type)}"
            job.output_path = output_path
            job.output_url = f"https://assets.uaos.io{output_path}"

            job.status = GenerationStatus.COMPLETED
            job.completed_at = datetime.now()
            job.metadata["duration_ms"] = (job.completed_at - job.started_at).total_seconds() * 1000

            logger.info(f"Generation job {job.job_id} completed")

        except Exception as e:
            job.status = GenerationStatus.FAILED
            job.error = str(e)
            logger.error(f"Generation job {job.job_id} failed: {e}")

    def _get_extension(self, asset_type: AssetType) -> str:
        """Get file extension for asset type."""
        extensions = {
            AssetType.IMAGE: "png",
            AssetType.VIDEO: "mp4",
            AssetType.AUDIO: "mp3",
            AssetType.MUSIC: "mp3",
            AssetType.THREE_D: "gltf",
            AssetType.DOCUMENT: "pdf",
            AssetType.PRESENTATION: "pptx",
            AssetType.TEMPLATE: "json",
        }
        return extensions.get(asset_type, "bin")

    async def get_job(self, job_id: str) -> Optional[GenerationJob]:
        """Get a generation job by ID."""
        return self._jobs.get(job_id)

    async def cancel_job(self, job_id: str) -> bool:
        """Cancel a generation job."""
        async with self._lock:
            if job_id not in self._jobs:
                return False
            job = self._jobs[job_id]
            if job.status in [GenerationStatus.COMPLETED, GenerationStatus.FAILED]:
                return False
            job.status = GenerationStatus.CANCELLED
        logger.info(f"Cancelled generation job {job_id}")
        return True

    def get_stats(self) -> Dict[str, Any]:
        """Get generation engine statistics."""
        statuses = {}
        for job in self._jobs.values():
            statuses[job.status.value] = statuses.get(job.status.value, 0) + 1
        return {
            "jobs": len(self._jobs),
            "queue_size": self._queue.qsize(),
            "workers": len(self._workers),
            "statuses": statuses,
        }
