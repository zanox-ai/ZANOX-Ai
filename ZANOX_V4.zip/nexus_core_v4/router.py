"""Intelligent Model Router for Nexus Core V4."""

import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from enum import Enum
import time

from .config import RoutingConfig, ProviderType
from .providers import ProviderManager


logger = logging.getLogger(__name__)


class RoutingStrategy(Enum):
    COST_OPTIMIZED = "cost_optimized"
    PERFORMANCE = "performance"
    BALANCED = "balanced"
    ROUND_ROBIN = "round_robin"
    CAPABILITY_BASED = "capability_based"
    CONTEXT_AWARE = "context_aware"


@dataclass
class RoutingDecision:
    """Result of a routing decision."""
    provider: ProviderType
    model: str
    confidence: float
    reasoning: str
    estimated_cost: float
    estimated_latency: float
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "provider": self.provider.value,
            "model": self.model,
            "confidence": self.confidence,
            "reasoning": self.reasoning,
            "estimated_cost": self.estimated_cost,
            "estimated_latency": self.estimated_latency,
            "metadata": self.metadata,
        }


@dataclass
class ModelCapability:
    """Capabilities of a specific model."""
    provider: ProviderType
    model: str
    context_window: int
    supports_vision: bool
    supports_tools: bool
    supports_json_mode: bool
    supports_streaming: bool
    supports_system_messages: bool
    max_output_tokens: int
    strengths: List[str] = field(default_factory=list)
    weaknesses: List[str] = field(default_factory=list)
    average_latency_ms: float = 0.0
    reliability_score: float = 1.0


class ModelRouter:
    """Intelligent router that selects the best provider and model for each request."""
    
    def __init__(self, config: RoutingConfig, provider_manager: ProviderManager):
        self.config = config
        self.provider_manager = provider_manager
        self.strategy = RoutingStrategy(config.routing_strategy)
        self._round_robin_index = 0
        self._capability_map: Dict[str, ModelCapability] = {}
        self._request_history: List[Dict[str, Any]] = []
        self._build_capability_map()
    
    def _build_capability_map(self):
        """Build a map of all model capabilities."""
        capabilities = {
            "gpt-4o": ModelCapability(
                ProviderType.CHATGPT, "gpt-4o", 128000, True, True, True, True, True, 4096,
                ["general", "vision", "coding", "reasoning"], [], 2000, 0.98
            ),
            "gpt-4o-mini": ModelCapability(
                ProviderType.CHATGPT, "gpt-4o-mini", 128000, True, True, True, True, True, 4096,
                ["fast", "cheap", "general"], ["complex reasoning"], 800, 0.95
            ),
            "gpt-4-turbo": ModelCapability(
                ProviderType.CHATGPT, "gpt-4-turbo", 128000, True, True, True, True, True, 4096,
                ["general", "coding", "analysis"], ["cost"], 2500, 0.97
            ),
            "claude-3-5-sonnet-20241022": ModelCapability(
                ProviderType.CLAUDE, "claude-3-5-sonnet-20241022", 200000, True, True, False, True, True, 8192,
                ["long context", "analysis", "writing", "coding"], [], 1800, 0.99
            ),
            "claude-3-opus-20240229": ModelCapability(
                ProviderType.CLAUDE, "claude-3-opus-20240229", 200000, True, True, False, True, True, 4096,
                ["complex reasoning", "analysis", "research"], ["cost", "speed"], 3500, 0.98
            ),
            "claude-3-haiku-20240307": ModelCapability(
                ProviderType.CLAUDE, "claude-3-haiku-20240307", 200000, True, False, False, True, True, 4096,
                ["fast", "cheap", "simple tasks"], ["complex reasoning"], 600, 0.94
            ),
            "gemini-1.5-pro": ModelCapability(
                ProviderType.GEMINI, "gemini-1.5-pro", 1000000, True, True, True, True, True, 8192,
                ["long context", "multimodal", "analysis"], [], 1500, 0.96
            ),
            "gemini-1.5-flash": ModelCapability(
                ProviderType.GEMINI, "gemini-1.5-flash", 1000000, True, True, True, True, True, 8192,
                ["fast", "cheap", "long context"], ["complex reasoning"], 700, 0.94
            ),
            "grok-2": ModelCapability(
                ProviderType.GROK, "grok-2", 131072, True, True, False, True, True, 4096,
                ["general", "coding", "analysis"], [], 1200, 0.93
            ),
            "grok-2-mini": ModelCapability(
                ProviderType.GROK, "grok-2-mini", 131072, True, False, False, True, True, 4096,
                ["fast", "cheap"], ["complex tasks"], 500, 0.90
            ),
            "kimi-k2": ModelCapability(
                ProviderType.KIMI, "kimi-k2", 200000, True, True, True, True, True, 8192,
                ["long context", "chinese", "coding", "analysis"], [], 1600, 0.95
            ),
            "kimi-k1.5": ModelCapability(
                ProviderType.KIMI, "kimi-k1.5", 200000, True, True, True, True, True, 8192,
                ["long context", "reasoning", "chinese"], [], 2000, 0.94
            ),
            "llama-3.1-sonar-large-128k-online": ModelCapability(
                ProviderType.PERPLEXITY, "llama-3.1-sonar-large-128k-online", 128000, False, False, False, True, True, 4096,
                ["web search", "research", "current events"], ["vision"], 1500, 0.92
            ),
            "qwen-max": ModelCapability(
                ProviderType.QWEN, "qwen-max", 128000, True, True, True, True, True, 8192,
                ["chinese", "coding", "analysis", "long context"], [], 1400, 0.93
            ),
            "qwen-plus": ModelCapability(
                ProviderType.QWEN, "qwen-plus", 128000, True, True, True, True, True, 8192,
                ["chinese", "general", "balanced"], [], 1000, 0.92
            ),
            "copilot-chat": ModelCapability(
                ProviderType.COPILOT, "copilot-chat", 8192, False, True, False, True, True, 4096,
                ["coding", "github integration"], ["general tasks"], 1200, 0.90
            ),
            "manus-default": ModelCapability(
                ProviderType.MANUS, "manus-default", 128000, True, True, True, True, True, 4096,
                ["agent tasks", "automation", "general"], [], 2000, 0.88
            ),
        }
        self._capability_map = capabilities
    
    async def route(self, request) -> RoutingDecision:
        """Route a request to the best provider and model."""
        
        if request.provider:
            model = request.model or await self._get_default_model(request.provider)
            return RoutingDecision(
                provider=request.provider,
                model=model,
                confidence=1.0,
                reasoning="Explicit provider selection",
                estimated_cost=0.0,
                estimated_latency=0.0,
            )
        
        if self.strategy == RoutingStrategy.COST_OPTIMIZED:
            return await self._route_cost_optimized(request)
        elif self.strategy == RoutingStrategy.PERFORMANCE:
            return await self._route_performance(request)
        elif self.strategy == RoutingStrategy.BALANCED:
            return await self._route_balanced(request)
        elif self.strategy == RoutingStrategy.ROUND_ROBIN:
            return await self._route_round_robin(request)
        elif self.strategy == RoutingStrategy.CAPABILITY_BASED:
            return await self._route_capability_based(request)
        else:
            return await self._route_balanced(request)
    
    async def _route_cost_optimized(self, request) -> RoutingDecision:
        """Route to the cheapest available provider."""
        providers = await self.provider_manager.get_available_providers()
        best_provider = None
        best_model = None
        best_cost = float('inf')
        
        for provider in providers:
            models = await self.provider_manager.get_models(provider)
            for model in models:
                cost = self._estimate_cost(provider, model, request)
                if cost < best_cost:
                    best_cost = cost
                    best_provider = provider
                    best_model = model
        
        return RoutingDecision(
            provider=best_provider or self.config.default_provider,
            model=best_model or "gpt-4o-mini",
            confidence=0.85,
            reasoning="Cost-optimized routing selected cheapest provider",
            estimated_cost=best_cost,
            estimated_latency=0.0,
        )
    
    async def _route_performance(self, request) -> RoutingDecision:
        """Route to the fastest available provider."""
        providers = await self.provider_manager.get_available_providers()
        best_provider = None
        best_model = None
        best_latency = float('inf')
        
        for provider in providers:
            models = await self.provider_manager.get_models(provider)
            for model in models:
                capability = self._capability_map.get(model)
                if capability and capability.average_latency_ms < best_latency:
                    best_latency = capability.average_latency_ms
                    best_provider = provider
                    best_model = model
        
        return RoutingDecision(
            provider=best_provider or self.config.default_provider,
            model=best_model or "gpt-4o",
            confidence=0.85,
            reasoning="Performance routing selected fastest provider",
            estimated_cost=0.0,
            estimated_latency=best_latency,
        )
    
    async def _route_balanced(self, request) -> RoutingDecision:
        """Route balancing cost and performance."""
        providers = await self.provider_manager.get_available_providers()
        best_score = -1
        best_provider = None
        best_model = None
        
        for provider in providers:
            models = await self.provider_manager.get_models(provider)
            for model in models:
                capability = self._capability_map.get(model)
                if not capability:
                    continue
                
                cost_score = 1.0 / (1.0 + self._estimate_cost(provider, model, request))
                latency_score = 1.0 / (1.0 + capability.average_latency_ms / 1000)
                reliability_score = capability.reliability_score
                
                score = (cost_score * 0.4) + (latency_score * 0.3) + (reliability_score * 0.3)
                
                if score > best_score:
                    best_score = score
                    best_provider = provider
                    best_model = model
        
        return RoutingDecision(
            provider=best_provider or self.config.default_provider,
            model=best_model or "gpt-4o",
            confidence=0.80,
            reasoning="Balanced routing optimized for cost, speed, and reliability",
            estimated_cost=0.0,
            estimated_latency=0.0,
        )
    
    async def _route_round_robin(self, request) -> RoutingDecision:
        """Route using round-robin strategy."""
        providers = await self.provider_manager.get_available_providers()
        if not providers:
            providers = [self.config.default_provider]
        
        self._round_robin_index = (self._round_robin_index + 1) % len(providers)
        provider = providers[self._round_robin_index]
        model = await self._get_default_model(provider)
        
        return RoutingDecision(
            provider=provider,
            model=model,
            confidence=0.70,
            reasoning="Round-robin routing for load distribution",
            estimated_cost=0.0,
            estimated_latency=0.0,
        )
    
    async def _route_capability_based(self, request) -> RoutingDecision:
        """Route based on request capabilities needed."""
        required_capabilities = self._analyze_request_capabilities(request)
        
        best_match = None
        best_score = -1
        
        for model_name, capability in self._capability_map.items():
            score = self._calculate_capability_match(capability, required_capabilities)
            if score > best_score:
                best_score = score
                best_match = capability
        
        if best_match:
            return RoutingDecision(
                provider=best_match.provider,
                model=best_match.model,
                confidence=best_score,
                reasoning=f"Capability-based routing matched {', '.join(required_capabilities)}",
                estimated_cost=0.0,
                estimated_latency=best_match.average_latency_ms,
            )
        
        return await self._route_balanced(request)
    
    def _analyze_request_capabilities(self, request) -> List[str]:
        """Analyze what capabilities are needed for a request."""
        capabilities = ["general"]
        
        for msg in request.messages:
            if isinstance(msg.get("content"), list):
                capabilities.append("vision")
        
        if request.tools:
            capabilities.append("tools")
        
        if request.response_format and request.response_format.get("type") == "json_object":
            capabilities.append("json_mode")
        
        total_length = sum(len(str(m.get("content", ""))) for m in request.messages)
        if total_length > 100000:
            capabilities.append("long_context")
        
        return capabilities
    
    def _calculate_capability_match(self, capability: ModelCapability, required: List[str]) -> float:
        """Calculate how well a model matches required capabilities."""
        if not required:
            return 0.5
        
        matches = sum(1 for cap in required if cap in capability.strengths)
        mismatches = sum(1 for cap in required if cap in capability.weaknesses)
        
        score = (matches / len(required)) - (mismatches * 0.3)
        return max(0.0, min(1.0, score))
    
    def _estimate_cost(self, provider: ProviderType, model: str, request) -> float:
        """Estimate the cost of a request."""
        config = self.provider_manager.get_provider_config(provider)
        if not config:
            return 0.0
        
        input_tokens = sum(len(str(m.get("content", ""))) // 4 for m in request.messages)
        output_tokens = request.max_tokens or 1000
        
        cost = (input_tokens / 1000 * config.cost_per_1k_input + 
                output_tokens / 1000 * config.cost_per_1k_output)
        
        return cost
    
    async def _get_default_model(self, provider: ProviderType) -> str:
        """Get the default model for a provider."""
        models = await self.provider_manager.get_models(provider)
        return models[0] if models else "default"
    
    def set_strategy(self, strategy: RoutingStrategy):
        """Change the routing strategy."""
        self.strategy = strategy
        logger.info(f"Routing strategy changed to {strategy.value}")
    
    async def get_routing_stats(self) -> Dict[str, Any]:
        """Get routing statistics."""
        return {
            "strategy": self.strategy.value,
            "total_requests": len(self._request_history),
            "capability_map_size": len(self._capability_map),
        }
