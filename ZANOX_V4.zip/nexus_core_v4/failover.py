"""Failover Manager for Nexus Core V4."""

import asyncio
import logging
from typing import Dict, Optional, List, Any
from dataclasses import dataclass, field
from enum import Enum
from collections import defaultdict
import time

from .config import FailoverConfig, ProviderType
from .providers import ProviderManager


logger = logging.getLogger(__name__)


class HealthStatus(Enum):
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    CIRCUIT_OPEN = "circuit_open"


@dataclass
class ProviderHealth:
    """Health status of a provider."""
    provider: ProviderType
    status: HealthStatus
    last_check: float
    consecutive_failures: int
    consecutive_successes: int
    total_requests: int
    total_failures: int
    average_latency: float
    last_failure_reason: Optional[str] = None
    circuit_open_until: float = 0.0


class FailoverManager:
    """Manages health checks and failover between providers."""
    
    def __init__(self, config: FailoverConfig, provider_manager: ProviderManager):
        self.config = config
        self.provider_manager = provider_manager
        self._health: Dict[ProviderType, ProviderHealth] = {}
        self._health_check_task: Optional[asyncio.Task] = None
        self._lock = asyncio.Lock()
        self._initialize_health()
    
    def _initialize_health(self):
        """Initialize health tracking for all providers."""
        for provider in self.provider_manager.providers.keys():
            self._health[provider] = ProviderHealth(
                provider=provider,
                status=HealthStatus.HEALTHY,
                last_check=time.time(),
                consecutive_failures=0,
                consecutive_successes=0,
                total_requests=0,
                total_failures=0,
                average_latency=0.0,
            )
    
    async def initialize(self):
        """Start health check loop."""
        if self.config.health_check_interval > 0:
            self._health_check_task = asyncio.create_task(self._health_check_loop())
    
    async def shutdown(self):
        """Stop health check loop."""
        if self._health_check_task:
            self._health_check_task.cancel()
            try:
                await self._health_check_task
            except asyncio.CancelledError:
                pass
    
    async def _health_check_loop(self):
        """Background health check loop."""
        while True:
            try:
                await self._check_all_providers()
                await asyncio.sleep(self.config.health_check_interval)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Health check error: {e}")
                await asyncio.sleep(self.config.health_check_interval)
    
    async def _check_all_providers(self):
        """Check health of all providers."""
        for provider in self.provider_manager.providers.keys():
            await self._check_provider(provider)
    
    async def _check_provider(self, provider: ProviderType):
        """Check health of a single provider."""
        try:
            await self.provider_manager.get_models(provider)
            
            async with self._lock:
                health = self._health[provider]
                health.last_check = time.time()
                health.consecutive_successes += 1
                health.consecutive_failures = 0
                
                if health.consecutive_successes >= 3:
                    health.status = HealthStatus.HEALTHY
                    health.circuit_open_until = 0.0
                elif health.status == HealthStatus.UNHEALTHY:
                    health.status = HealthStatus.DEGRADED
                    
        except Exception as e:
            async with self._lock:
                health = self._health[provider]
                health.last_check = time.time()
                health.consecutive_failures += 1
                health.consecutive_successes = 0
                health.last_failure_reason = str(e)
                
                if health.consecutive_failures >= self.config.failure_threshold:
                    health.status = HealthStatus.UNHEALTHY
                    
                    if self.config.circuit_breaker_timeout > 0:
                        health.status = HealthStatus.CIRCUIT_OPEN
                        health.circuit_open_until = time.time() + self.config.circuit_breaker_timeout
                        logger.warning(f"Circuit breaker opened for {provider.value}")
    
    async def is_healthy(self, provider: ProviderType) -> bool:
        """Check if a provider is healthy."""
        async with self._lock:
            health = self._health.get(provider)
            if not health:
                return False
            
            if health.status == HealthStatus.CIRCUIT_OPEN:
                if time.time() > health.circuit_open_until:
                    health.status = HealthStatus.DEGRADED
                    return True
                return False
            
            return health.status in [HealthStatus.HEALTHY, HealthStatus.DEGRADED]
    
    async def get_fallback(self, provider: ProviderType) -> Optional[ProviderType]:
        """Get a fallback provider for a failed one."""
        for p in self.provider_manager.provider_manager.configs.values():
            if p.provider_type != provider and await self.is_healthy(p.provider_type):
                return p.provider_type
        
        for p, health in self._health.items():
            if p != provider and await self.is_healthy(p):
                return p
        
        return None
    
    async def record_success(self, provider: ProviderType, latency: float = 0.0):
        """Record a successful request."""
        async with self._lock:
            health = self._health.get(provider)
            if health:
                health.total_requests += 1
                health.consecutive_successes += 1
                health.consecutive_failures = 0
                
                if health.total_requests > 1:
                    health.average_latency = (
                        (health.average_latency * (health.total_requests - 1) + latency) 
                        / health.total_requests
                    )
                else:
                    health.average_latency = latency
    
    async def record_failure(self, provider: ProviderType, reason: str):
        """Record a failed request."""
        async with self._lock:
            health = self._health.get(provider)
            if health:
                health.total_requests += 1
                health.total_failures += 1
                health.consecutive_failures += 1
                health.consecutive_successes = 0
                health.last_failure_reason = reason
                
                if health.consecutive_failures >= self.config.failure_threshold:
                    health.status = HealthStatus.UNHEALTHY
                    logger.warning(
                        f"Provider {provider.value} marked unhealthy after "
                        f"{health.consecutive_failures} consecutive failures"
                    )
    
    async def get_health_status(self) -> Dict[str, Any]:
        """Get health status of all providers."""
        return {
            p.value: {
                "status": h.status.value,
                "consecutive_failures": h.consecutive_failures,
                "consecutive_successes": h.consecutive_successes,
                "total_requests": h.total_requests,
                "total_failures": h.total_failures,
                "average_latency_ms": h.average_latency,
                "last_failure_reason": h.last_failure_reason,
            }
            for p, h in self._health.items()
        }
