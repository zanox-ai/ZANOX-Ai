"""Context Router for Nexus Core V4."""

import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from collections import defaultdict
import hashlib
import json
import time

from .config import ContextConfig, ProviderType


logger = logging.getLogger(__name__)


@dataclass
class ContextSession:
    """A context session for maintaining conversation state."""
    session_id: str
    provider: ProviderType
    model: str
    messages: List[Dict[str, str]] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: float = 0.0
    last_accessed: float = 0.0
    total_tokens: int = 0


class ContextRouter:
    """Routes requests based on context and maintains session state."""
    
    def __init__(self, config: ContextConfig):
        self.config = config
        self._sessions: Dict[str, ContextSession] = {}
        self._provider_contexts: Dict[ProviderType, List[str]] = defaultdict(list)
    
    def create_session(
        self,
        session_id: str,
        provider: ProviderType,
        model: str,
        initial_messages: Optional[List[Dict[str, str]]] = None
    ) -> ContextSession:
        """Create a new context session."""
        session = ContextSession(
            session_id=session_id,
            provider=provider,
            model=model,
            messages=initial_messages or [],
            created_at=time.time(),
            last_accessed=time.time(),
        )
        self._sessions[session_id] = session
        self._provider_contexts[provider].append(session_id)
        logger.info(f"Created context session: {session_id}")
        return session
    
    def get_session(self, session_id: str) -> Optional[ContextSession]:
        """Get an existing context session."""
        session = self._sessions.get(session_id)
        if session:
            session.last_accessed = time.time()
        return session
    
    def add_to_session(self, session_id: str, messages: List[Dict[str, str]]):
        """Add messages to a session."""
        session = self._sessions.get(session_id)
        if session:
            session.messages.extend(messages)
            session.total_tokens = sum(len(str(m.get('content', ''))) for m in session.messages) // 4
            
            if session.total_tokens > self.config.max_context_length * 0.8:
                session.messages = self._compress_context(session.messages)
    
    def _compress_context(self, messages: List[Dict[str, str]]) -> List[Dict[str, str]]:
        """Compress context to fit within limits."""
        if self.config.context_window_strategy == "sliding_window":
            keep_count = max(10, len(messages) // 4)
            return messages[-keep_count:]
        elif self.config.context_window_strategy == "summarization":
            system_msgs = [m for m in messages if m.get('role') == 'system']
            recent = messages[-5:]
            return system_msgs + recent
        else:
            return messages[::2] + messages[-3:]
    
    def route_by_context(self, request, available_providers: List[ProviderType]) -> ProviderType:
        """Route based on context requirements."""
        total_length = sum(len(str(m.get('content', ''))) for m in request.messages)
        
        if total_length > 100000:
            for provider in available_providers:
                if provider in [ProviderType.GEMINI, ProviderType.CLAUDE, ProviderType.KIMI]:
                    return provider
        
        if request.tools:
            for provider in available_providers:
                if provider in [ProviderType.CHATGPT, ProviderType.CLAUDE, ProviderType.KIMI]:
                    return provider
        
        return available_providers[0] if available_providers else ProviderType.CHATGPT
    
    def get_session_context(self, session_id: str) -> List[Dict[str, str]]:
        """Get context messages for a session."""
        session = self._sessions.get(session_id)
        return session.messages if session else []
    
    def clear_session(self, session_id: str):
        """Clear a context session."""
        if session_id in self._sessions:
            session = self._sessions[session_id]
            self._provider_contexts[session.provider].remove(session_id)
            del self._sessions[session_id]
            logger.info(f"Cleared context session: {session_id}")
    
    def get_stats(self) -> Dict[str, Any]:
        """Get context routing statistics."""
        return {
            "total_sessions": len(self._sessions),
            "provider_distribution": {
                p.value: len(sessions) for p, sessions in self._provider_contexts.items()
            },
            "total_tokens_across_sessions": sum(s.total_tokens for s in self._sessions.values()),
        }
