"""Configuration management for Nexus Core V4."""

import os
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from enum import Enum


class ProviderType(Enum):
    CHATGPT = "chatgpt"
    CLAUDE = "claude"
    GEMINI = "gemini"
    GROK = "grok"
    KIMI = "kimi"
    PERPLEXITY = "perplexity"
    QWEN = "qwen"
    COPILOT = "copilot"
    MANUS = "manus"


@dataclass
class ProviderConfig:
    """Configuration for a single AI provider."""
    name: str
    provider_type: ProviderType
    api_key: str
    base_url: str
    models: List[str]
    priority: int = 1
    weight: float = 1.0
    timeout: int = 30
    max_retries: int = 3
    cost_per_1k_input: float = 0.0
    cost_per_1k_output: float = 0.0
    context_window: int = 4096
    rate_limit_rpm: int = 60
    rate_limit_tpm: int = 100000
    enabled: bool = True
    custom_headers: Dict[str, str] = field(default_factory=dict)
    extra_params: Dict[str, Any] = field(default_factory=dict)


@dataclass
class RoutingConfig:
    """Configuration for model routing."""
    default_provider: ProviderType = ProviderType.CHATGPT
    fallback_order: List[ProviderType] = field(default_factory=list)
    routing_strategy: str = "cost_optimized"
    enable_auto_fallback: bool = True
    enable_load_balancing: bool = True
    enable_cost_tracking: bool = True


@dataclass
class TokenConfig:
    """Configuration for token management."""
    max_tokens_per_request: int = 4096
    token_buffer_ratio: float = 0.1
    enable_token_caching: bool = True
    cache_ttl_seconds: int = 3600
    enable_compression: bool = True


@dataclass
class RateLimitConfig:
    """Configuration for rate limiting."""
    global_rpm: int = 1000
    global_tpm: int = 1000000
    per_provider_rpm: int = 100
    per_provider_tpm: int = 100000
    burst_size: int = 10
    enable_adaptive_throttling: bool = True


@dataclass
class FailoverConfig:
    """Configuration for failover management."""
    health_check_interval: int = 30
    failure_threshold: int = 3
    recovery_timeout: int = 60
    circuit_breaker_timeout: int = 300
    enable_graceful_degradation: bool = True


@dataclass
class LoadBalancerConfig:
    """Configuration for load balancing."""
    algorithm: str = "weighted_round_robin"
    health_check_enabled: bool = True
    sticky_sessions: bool = False
    session_ttl: int = 300


@dataclass
class ContextConfig:
    """Configuration for context management."""
    max_context_length: int = 128000
    context_window_strategy: str = "sliding_window"
    enable_context_compression: bool = True
    context_cache_size: int = 1000


@dataclass
class NexusConfig:
    """Main configuration for Nexus Core V4."""
    providers: Dict[str, ProviderConfig] = field(default_factory=dict)
    routing: RoutingConfig = field(default_factory=RoutingConfig)
    tokens: TokenConfig = field(default_factory=TokenConfig)
    rate_limits: RateLimitConfig = field(default_factory=RateLimitConfig)
    failover: FailoverConfig = field(default_factory=FailoverConfig)
    load_balancer: LoadBalancerConfig = field(default_factory=LoadBalancerConfig)
    context: ContextConfig = field(default_factory=ContextConfig)
    debug: bool = False
    log_level: str = "INFO"


DEFAULT_PROVIDER_CONFIGS = {
    "chatgpt": ProviderConfig(
        name="ChatGPT",
        provider_type=ProviderType.CHATGPT,
        api_key=os.getenv("OPENAI_API_KEY", ""),
        base_url="https://api.openai.com/v1",
        models=["gpt-4o", "gpt-4o-mini", "gpt-4-turbo", "gpt-3.5-turbo"],
        cost_per_1k_input=0.005,
        cost_per_1k_output=0.015,
        context_window=128000,
        rate_limit_rpm=500,
        rate_limit_tpm=2000000,
    ),
    "claude": ProviderConfig(
        name="Claude",
        provider_type=ProviderType.CLAUDE,
        api_key=os.getenv("ANTHROPIC_API_KEY", ""),
        base_url="https://api.anthropic.com/v1",
        models=["claude-3-5-sonnet-20241022", "claude-3-opus-20240229", "claude-3-haiku-20240307"],
        cost_per_1k_input=0.003,
        cost_per_1k_output=0.015,
        context_window=200000,
        rate_limit_rpm=50,
        rate_limit_tpm=40000,
    ),
    "gemini": ProviderConfig(
        name="Gemini",
        provider_type=ProviderType.GEMINI,
        api_key=os.getenv("GOOGLE_API_KEY", ""),
        base_url="https://generativelanguage.googleapis.com/v1",
        models=["gemini-1.5-pro", "gemini-1.5-flash", "gemini-1.0-pro"],
        cost_per_1k_input=0.00125,
        cost_per_1k_output=0.005,
        context_window=1000000,
        rate_limit_rpm=60,
        rate_limit_tpm=1000000,
    ),
    "grok": ProviderConfig(
        name="Grok",
        provider_type=ProviderType.GROK,
        api_key=os.getenv("XAI_API_KEY", ""),
        base_url="https://api.x.ai/v1",
        models=["grok-2", "grok-2-mini", "grok-1.5"],
        cost_per_1k_input=0.005,
        cost_per_1k_output=0.015,
        context_window=131072,
        rate_limit_rpm=60,
        rate_limit_tpm=100000,
    ),
    "kimi": ProviderConfig(
        name="Kimi",
        provider_type=ProviderType.KIMI,
        api_key=os.getenv("KIMI_API_KEY", ""),
        base_url="https://api.moonshot.cn/v1",
        models=["kimi-k2", "kimi-k1.5", "kimi-moonshot-v1-8k", "kimi-moonshot-v1-32k", "kimi-moonshot-v1-128k"],
        cost_per_1k_input=0.001,
        cost_per_1k_output=0.002,
        context_window=200000,
        rate_limit_rpm=60,
        rate_limit_tpm=100000,
    ),
    "perplexity": ProviderConfig(
        name="Perplexity",
        provider_type=ProviderType.PERPLEXITY,
        api_key=os.getenv("PERPLEXITY_API_KEY", ""),
        base_url="https://api.perplexity.ai",
        models=["llama-3.1-sonar-large-128k-online", "llama-3.1-sonar-small-128k-online", "llama-3.1-sonar-huge-128k-online"],
        cost_per_1k_input=0.001,
        cost_per_1k_output=0.001,
        context_window=128000,
        rate_limit_rpm=60,
        rate_limit_tpm=100000,
    ),
    "qwen": ProviderConfig(
        name="Qwen",
        provider_type=ProviderType.QWEN,
        api_key=os.getenv("QWEN_API_KEY", ""),
        base_url="https://dashscope.aliyuncs.com/api/v1",
        models=["qwen-max", "qwen-plus", "qwen-turbo", "qwen-long"],
        cost_per_1k_input=0.0005,
        cost_per_1k_output=0.001,
        context_window=128000,
        rate_limit_rpm=60,
        rate_limit_tpm=100000,
    ),
    "copilot": ProviderConfig(
        name="Copilot",
        provider_type=ProviderType.COPILOT,
        api_key=os.getenv("GITHUB_COPILOT_API_KEY", ""),
        base_url="https://api.github.com/copilot",
        models=["copilot-chat", "copilot-code"],
        cost_per_1k_input=0.0,
        cost_per_1k_output=0.0,
        context_window=8192,
        rate_limit_rpm=30,
        rate_limit_tpm=50000,
    ),
    "manus": ProviderConfig(
        name="Manus",
        provider_type=ProviderType.MANUS,
        api_key=os.getenv("MANUS_API_KEY", ""),
        base_url="https://api.manus.im/v1",
        models=["manus-default", "manus-pro"],
        cost_per_1k_input=0.01,
        cost_per_1k_output=0.03,
        context_window=128000,
        rate_limit_rpm=30,
        rate_limit_tpm=50000,
    ),
}


def create_default_config() -> NexusConfig:
    """Create a default configuration with all providers."""
    return NexusConfig(
        providers=DEFAULT_PROVIDER_CONFIGS.copy(),
        routing=RoutingConfig(
            default_provider=ProviderType.CHATGPT,
            fallback_order=[
                ProviderType.CLAUDE,
                ProviderType.GEMINI,
                ProviderType.KIMI,
                ProviderType.GROK,
                ProviderType.QWEN,
                ProviderType.PERPLEXITY,
                ProviderType.COPILOT,
                ProviderType.MANUS,
            ],
            routing_strategy="cost_optimized",
        ),
    )
