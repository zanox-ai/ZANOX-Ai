"""Unified API Gateway for Nexus Core V4."""

import asyncio
import logging
from typing import Dict, List, Optional, Any, AsyncIterator, Union
from dataclasses import dataclass, field
from enum import Enum
import time
import json

from .config import NexusConfig, ProviderType, create_default_config
from .router import ModelRouter, RoutingDecision
from .providers import ProviderManager, ProviderResponse
from .cost_optimizer import CostOptimizer
from .token_manager import TokenManager
from .rate_limiter import RateLimitManager
from .failover import FailoverManager
from .load_balancer import LoadBalancer
from .context_router import ContextRouter
from .long_context import LongContextCoordinator


logger = logging.getLogger(__name__)


class RequestType(Enum):
    CHAT = "chat"
    COMPLETION = "completion"
    EMBEDDING = "embedding"
    IMAGE = "image"
    AUDIO = "audio"


@dataclass
class UnifiedRequest:
    """Standardized request format for all providers."""
    messages: List[Dict[str, str]]
    model: Optional[str] = None
    provider: Optional[ProviderType] = None
    temperature: float = 0.7
    max_tokens: Optional[int] = None
    top_p: float = 1.0
    frequency_penalty: float = 0.0
    presence_penalty: float = 0.0
    stream: bool = False
    request_type: RequestType = RequestType.CHAT
    context_id: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    tools: Optional[List[Dict]] = None
    tool_choice: Optional[str] = None
    response_format: Optional[Dict] = None


@dataclass
class UnifiedResponse:
    """Standardized response format from all providers."""
    content: str
    provider: ProviderType
    model: str
    usage: Dict[str, int]
    latency_ms: float
    cost_usd: float
    request_id: str
    finish_reason: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    tool_calls: Optional[List[Dict]] = None


@dataclass
class StreamChunk:
    """Standardized streaming chunk format."""
    content: str
    provider: ProviderType
    model: str
    is_finished: bool
    finish_reason: Optional[str] = None
    usage: Optional[Dict[str, int]] = None


class NexusGateway:
    """Main gateway class that orchestrates all components."""
    
    def __init__(self, config: Optional[NexusConfig] = None):
        self.config = config or create_default_config()
        self.provider_manager = ProviderManager(self.config.providers)
        self.router = ModelRouter(self.config.routing, self.provider_manager)
        self.cost_optimizer = CostOptimizer(self.config, self.provider_manager)
        self.token_manager = TokenManager(self.config.tokens)
        self.rate_limiter = RateLimitManager(self.config.rate_limits)
        self.failover = FailoverManager(self.config.failover, self.provider_manager)
        self.load_balancer = LoadBalancer(self.config.load_balancer, self.provider_manager)
        self.context_router = ContextRouter(self.config.context)
        self.long_context = LongContextCoordinator(self.config.context, self.token_manager)
        
        self._initialized = False
        self._request_count = 0
        self._total_cost = 0.0
        self._lock = asyncio.Lock()
        
        logger.info("NexusGateway initialized with %d providers", len(self.config.providers))
    
    async def initialize(self):
        """Initialize all components."""
        if self._initialized:
            return
        
        await self.provider_manager.initialize()
        await self.failover.initialize()
        await self.load_balancer.initialize()
        
        self._initialized = True
        logger.info("NexusGateway fully initialized")
    
    async def shutdown(self):
        """Shutdown all components gracefully."""
        await self.provider_manager.shutdown()
        await self.failover.shutdown()
        await self.load_balancer.shutdown()
        self._initialized = False
        logger.info("NexusGateway shutdown complete")
    
    async def chat(
        self,
        messages: List[Dict[str, str]],
        model: Optional[str] = None,
        provider: Optional[ProviderType] = None,
        **kwargs
    ) -> UnifiedResponse:
        """Send a chat request through the unified gateway."""
        request = UnifiedRequest(
            messages=messages,
            model=model,
            provider=provider,
            **kwargs
        )
        return await self._process_request(request)
    
    async def stream_chat(
        self,
        messages: List[Dict[str, str]],
        model: Optional[str] = None,
        provider: Optional[ProviderType] = None,
        **kwargs
    ) -> AsyncIterator[StreamChunk]:
        """Send a streaming chat request through the unified gateway."""
        request = UnifiedRequest(
            messages=messages,
            model=model,
            provider=provider,
            stream=True,
            **kwargs
        )
        async for chunk in self._process_stream_request(request):
            yield chunk
    
    async def _process_request(self, request: UnifiedRequest) -> UnifiedResponse:
        """Process a single request with full orchestration."""
        start_time = time.time()
        self._request_count += 1
        request_id = f"nexus-{self._request_count}-{int(start_time * 1000)}"
        
        try:
            # 1. Check rate limits
            await self.rate_limiter.acquire_global()
            
            # 2. Handle long context if needed
            if self.long_context.is_long_context(request.messages):
                request = await self.long_context.coordinate(request)
            
            # 3. Route to appropriate provider
            routing_decision = await self.router.route(request)
            provider = routing_decision.provider
            model = routing_decision.model
            
            # 4. Check provider rate limit
            await self.rate_limiter.acquire_provider(provider)
            
            # 5. Check provider health
            if not await self.failover.is_healthy(provider):
                provider = await self.failover.get_fallback(provider)
                if not provider:
                    raise Exception("No healthy providers available")
            
            # 6. Optimize cost
            cost_estimate = self.cost_optimizer.estimate_cost(provider, model, request)
            
            # 7. Manage tokens
            request = await self.token_manager.optimize(request, provider)
            
            # 8. Load balance
            provider = await self.load_balancer.select_provider(provider, request)
            
            # 9. Execute request
            response = await self._execute_with_failover(request, provider, model)
            
            # 10. Track cost
            actual_cost = self.cost_optimizer.calculate_actual_cost(response)
            async with self._lock:
                self._total_cost += actual_cost
            
            # 11. Update metrics
            latency = (time.time() - start_time) * 1000
            await self.failover.record_success(provider)
            await self.load_balancer.record_success(provider, latency)
            
            return UnifiedResponse(
                content=response.content,
                provider=provider,
                model=response.model,
                usage=response.usage,
                latency_ms=latency,
                cost_usd=actual_cost,
                request_id=request_id,
                finish_reason=response.finish_reason,
                metadata={
                    "routing_decision": routing_decision.to_dict(),
                    "cost_estimate": cost_estimate,
                    "fallback_used": routing_decision.provider != provider,
                }
            )
            
        except Exception as e:
            logger.error(f"Request {request_id} failed: {e}")
            raise
    
    async def _process_stream_request(self, request: UnifiedRequest) -> AsyncIterator[StreamChunk]:
        """Process a streaming request."""
        start_time = time.time()
        self._request_count += 1
        
        # Route and validate
        routing_decision = await self.router.route(request)
        provider = routing_decision.provider
        model = routing_decision.model
        
        await self.rate_limiter.acquire_provider(provider)
        
        if not await self.failover.is_healthy(provider):
            provider = await self.failover.get_fallback(provider)
        
        request = await self.token_manager.optimize(request, provider)
        provider = await self.load_balancer.select_provider(provider, request)
        
        # Execute streaming request
        stream = await self.provider_manager.stream_chat(provider, model, request)
        
        async for chunk in stream:
            yield StreamChunk(
                content=chunk.content,
                provider=provider,
                model=model,
                is_finished=chunk.is_finished,
                finish_reason=chunk.finish_reason,
                usage=chunk.usage
            )
        
        latency = (time.time() - start_time) * 1000
        await self.failover.record_success(provider)
        await self.load_balancer.record_success(provider, latency)
    
    async def _execute_with_failover(
        self,
        request: UnifiedRequest,
        provider: ProviderType,
        model: str
    ) -> ProviderResponse:
        """Execute request with automatic failover."""
        last_error = None
        providers_to_try = [provider] + [
            p for p in self.config.routing.fallback_order if p != provider
        ]
        
        for p in providers_to_try:
            if not await self.failover.is_healthy(p):
                continue
            
            try:
                await self.rate_limiter.acquire_provider(p)
                response = await self.provider_manager.chat(p, model, request)
                return response
            except Exception as e:
                last_error = e
                await self.failover.record_failure(p, str(e))
                logger.warning(f"Provider {p.value} failed: {e}")
                continue
        
        raise Exception(f"All providers failed. Last error: {last_error}")
    
    async def get_status(self) -> Dict[str, Any]:
        """Get comprehensive system status."""
        return {
            "initialized": self._initialized,
            "request_count": self._request_count,
            "total_cost_usd": self._total_cost,
            "providers": await self.provider_manager.get_status(),
            "health": await self.failover.get_health_status(),
            "load_balancer": await self.load_balancer.get_status(),
            "rate_limits": await self.rate_limiter.get_status(),
        }
    
    async def get_available_models(self) -> Dict[str, List[str]]:
        """Get all available models grouped by provider."""
        return await self.provider_manager.get_available_models()
