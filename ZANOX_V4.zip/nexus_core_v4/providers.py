"""Provider Abstraction Layer for Nexus Core V4."""

import asyncio
import logging
from typing import Dict, List, Optional, Any, AsyncIterator
from dataclasses import dataclass, field
from abc import ABC, abstractmethod
import aiohttp
import json

from .config import ProviderConfig, ProviderType


logger = logging.getLogger(__name__)


@dataclass
class ProviderResponse:
    """Standardized response from any provider."""
    content: str
    model: str
    usage: Dict[str, int]
    finish_reason: str
    raw_response: Dict[str, Any] = field(default_factory=dict)
    tool_calls: Optional[List[Dict]] = None


@dataclass
class StreamChunk:
    """Standardized streaming chunk."""
    content: str
    is_finished: bool
    finish_reason: Optional[str] = None
    usage: Optional[Dict[str, int]] = None


class BaseProvider(ABC):
    """Abstract base class for all AI providers."""
    
    def __init__(self, config: ProviderConfig):
        self.config = config
        self.session: Optional[aiohttp.ClientSession] = None
        self._initialized = False
    
    async def initialize(self):
        """Initialize the provider session."""
        if not self._initialized:
            self.session = aiohttp.ClientSession(
                headers=self.config.custom_headers,
                timeout=aiohttp.ClientTimeout(total=self.config.timeout),
            )
            self._initialized = True
    
    async def shutdown(self):
        """Shutdown the provider session."""
        if self.session:
            await self.session.close()
            self.session = None
        self._initialized = False
    
    @abstractmethod
    async def chat(self, model: str, messages: List[Dict], **kwargs) -> ProviderResponse:
        """Send a chat request."""
        pass
    
    @abstractmethod
    async def stream_chat(self, model: str, messages: List[Dict], **kwargs) -> AsyncIterator[StreamChunk]:
        """Send a streaming chat request."""
        pass
    
    @abstractmethod
    def format_request(self, messages: List[Dict], **kwargs) -> Dict[str, Any]:
        """Format request for this provider."""
        pass
    
    @abstractmethod
    def parse_response(self, raw_response: Dict) -> ProviderResponse:
        """Parse provider-specific response."""
        pass


class OpenAICompatibleProvider(BaseProvider):
    """Provider for OpenAI-compatible APIs (ChatGPT, Grok, Kimi, etc.)."""
    
    async def chat(self, model: str, messages: List[Dict], **kwargs) -> ProviderResponse:
        payload = self.format_request(messages, model=model, **kwargs)
        
        async with self.session.post(
            f"{self.config.base_url}/chat/completions",
            headers={"Authorization": f"Bearer {self.config.api_key}", "Content-Type": "application/json"},
            json=payload
        ) as response:
            if response.status != 200:
                error_text = await response.text()
                raise Exception(f"API error {response.status}: {error_text}")
            
            raw = await response.json()
            return self.parse_response(raw)
    
    async def stream_chat(self, model: str, messages: List[Dict], **kwargs) -> AsyncIterator[StreamChunk]:
        payload = self.format_request(messages, model=model, stream=True, **kwargs)
        
        async with self.session.post(
            f"{self.config.base_url}/chat/completions",
            headers={"Authorization": f"Bearer {self.config.api_key}", "Content-Type": "application/json"},
            json=payload
        ) as response:
            if response.status != 200:
                error_text = await response.text()
                raise Exception(f"API error {response.status}: {error_text}")
            
            async for line in response.content:
                line = line.decode('utf-8').strip()
                if line.startswith('data: '):
                    data = line[6:]
                    if data == '[DONE]':
                        yield StreamChunk(content="", is_finished=True, finish_reason="stop")
                        break
                    
                    try:
                        chunk = json.loads(data)
                        delta = chunk.get('choices', [{}])[0].get('delta', {})
                        content = delta.get('content', '')
                        finish_reason = chunk.get('choices', [{}])[0].get('finish_reason')
                        
                        yield StreamChunk(
                            content=content,
                            is_finished=finish_reason is not None,
                            finish_reason=finish_reason,
                            usage=chunk.get('usage')
                        )
                    except json.JSONDecodeError:
                        continue
    
    def format_request(self, messages: List[Dict], **kwargs) -> Dict[str, Any]:
        """Format request in OpenAI-compatible format."""
        return {
            "model": kwargs.get('model'),
            "messages": messages,
            "temperature": kwargs.get('temperature', 0.7),
            "max_tokens": kwargs.get('max_tokens'),
            "top_p": kwargs.get('top_p', 1.0),
            "frequency_penalty": kwargs.get('frequency_penalty', 0.0),
            "presence_penalty": kwargs.get('presence_penalty', 0.0),
            "stream": kwargs.get('stream', False),
            "tools": kwargs.get('tools'),
            "tool_choice": kwargs.get('tool_choice'),
            "response_format": kwargs.get('response_format'),
        }
    
    def parse_response(self, raw_response: Dict) -> ProviderResponse:
        """Parse OpenAI-compatible response."""
        choice = raw_response.get('choices', [{}])[0]
        message = choice.get('message', {})
        
        return ProviderResponse(
            content=message.get('content', ''),
            model=raw_response.get('model', 'unknown'),
            usage=raw_response.get('usage', {'prompt_tokens': 0, 'completion_tokens': 0, 'total_tokens': 0}),
            finish_reason=choice.get('finish_reason', 'unknown'),
            raw_response=raw_response,
            tool_calls=message.get('tool_calls')
        )


class ClaudeProvider(BaseProvider):
    """Provider for Anthropic Claude API."""
    
    async def chat(self, model: str, messages: List[Dict], **kwargs) -> ProviderResponse:
        system_msg = None
        chat_messages = []
        
        for msg in messages:
            if msg.get('role') == 'system':
                system_msg = msg.get('content')
            else:
                chat_messages.append(msg)
        
        payload = {
            "model": model,
            "messages": chat_messages,
            "max_tokens": kwargs.get('max_tokens', 4096),
            "temperature": kwargs.get('temperature', 0.7),
            "top_p": kwargs.get('top_p', 1.0),
        }
        
        if system_msg:
            payload["system"] = system_msg
        
        if kwargs.get('tools'):
            payload["tools"] = kwargs['tools']
        
        async with self.session.post(
            f"{self.config.base_url}/messages",
            headers={
                "x-api-key": self.config.api_key,
                "anthropic-version": "2023-06-01",
                "Content-Type": "application/json"
            },
            json=payload
        ) as response:
            if response.status != 200:
                error_text = await response.text()
                raise Exception(f"Claude API error {response.status}: {error_text}")
            
            raw = await response.json()
            return self.parse_response(raw)
    
    async def stream_chat(self, model: str, messages: List[Dict], **kwargs) -> AsyncIterator[StreamChunk]:
        system_msg = None
        chat_messages = []
        
        for msg in messages:
            if msg.get('role') == 'system':
                system_msg = msg.get('content')
            else:
                chat_messages.append(msg)
        
        payload = {
            "model": model,
            "messages": chat_messages,
            "max_tokens": kwargs.get('max_tokens', 4096),
            "temperature": kwargs.get('temperature', 0.7),
            "stream": True,
        }
        
        if system_msg:
            payload["system"] = system_msg
        
        async with self.session.post(
            f"{self.config.base_url}/messages",
            headers={
                "x-api-key": self.config.api_key,
                "anthropic-version": "2023-06-01",
                "Content-Type": "application/json"
            },
            json=payload
        ) as response:
            async for line in response.content:
                line = line.decode('utf-8').strip()
                if line.startswith('data: '):
                    data = line[6:]
                    try:
                        chunk = json.loads(data)
                        if chunk.get('type') == 'content_block_delta':
                            yield StreamChunk(
                                content=chunk.get('delta', {}).get('text', ''),
                                is_finished=False
                            )
                        elif chunk.get('type') == 'message_stop':
                            yield StreamChunk(content="", is_finished=True, finish_reason="stop")
                    except json.JSONDecodeError:
                        continue
    
    def format_request(self, messages: List[Dict], **kwargs) -> Dict[str, Any]:
        return kwargs
    
    def parse_response(self, raw_response: Dict) -> ProviderResponse:
        content = ""
        for block in raw_response.get('content', []):
            if block.get('type') == 'text':
                content += block.get('text', '')
        
        usage = raw_response.get('usage', {})
        return ProviderResponse(
            content=content,
            model=raw_response.get('model', 'claude'),
            usage={
                'prompt_tokens': usage.get('input_tokens', 0),
                'completion_tokens': usage.get('output_tokens', 0),
                'total_tokens': usage.get('input_tokens', 0) + usage.get('output_tokens', 0)
            },
            finish_reason=raw_response.get('stop_reason', 'unknown'),
            raw_response=raw_response
        )


class GeminiProvider(BaseProvider):
    """Provider for Google Gemini API."""
    
    async def chat(self, model: str, messages: List[Dict], **kwargs) -> ProviderResponse:
        contents = []
        system_instruction = None
        
        for msg in messages:
            role = msg.get('role')
            content = msg.get('content')
            
            if role == 'system':
                system_instruction = {"parts": [{"text": content}]}
            elif role == 'user':
                contents.append({"role": "user", "parts": [{"text": content}]}
            elif role == 'assistant':
                contents.append({"role": "model", "parts": [{"text": content}]}
        
        payload = {
            "contents": contents,
            "generationConfig": {
                "temperature": kwargs.get('temperature', 0.7),
                "maxOutputTokens": kwargs.get('max_tokens', 4096),
                "topP": kwargs.get('top_p', 1.0),
            }
        }
        
        if system_instruction:
            payload["systemInstruction"] = system_instruction
        
        model_name = model.replace("gemini-", "")
        async with self.session.post(
            f"{self.config.base_url}/models/{model_name}:generateContent?key={self.config.api_key}",
            headers={"Content-Type": "application/json"},
            json=payload
        ) as response:
            if response.status != 200:
                error_text = await response.text()
                raise Exception(f"Gemini API error {response.status}: {error_text}")
            
            raw = await response.json()
            return self.parse_response(raw)
    
    async def stream_chat(self, model: str, messages: List[Dict], **kwargs) -> AsyncIterator[StreamChunk]:
        contents = []
        for msg in messages:
            role = msg.get('role')
            content = msg.get('content')
            if role == 'user':
                contents.append({"role": "user", "parts": [{"text": content}]}
            elif role == 'assistant':
                contents.append({"role": "model", "parts": [{"text": content}]}
        
        payload = {
            "contents": contents,
            "generationConfig": {
                "temperature": kwargs.get('temperature', 0.7),
                "maxOutputTokens": kwargs.get('max_tokens', 4096),
            }
        }
        
        model_name = model.replace("gemini-", "")
        async with self.session.post(
            f"{self.config.base_url}/models/{model_name}:streamGenerateContent?key={self.config.api_key}",
            headers={"Content-Type": "application/json"},
            json=payload
        ) as response:
            async for line in response.content:
                line = line.decode('utf-8').strip()
                if line:
                    try:
                        chunk = json.loads(line)
                        text = ""
                        for candidate in chunk.get('candidates', []):
                            for part in candidate.get('content', {}).get('parts', []):
                                text += part.get('text', '')
                        
                        finish_reason = None
                        for candidate in chunk.get('candidates', []):
                            if candidate.get('finishReason'):
                                finish_reason = candidate['finishReason']
                        
                        yield StreamChunk(
                            content=text,
                            is_finished=finish_reason is not None,
                            finish_reason=finish_reason
                        )
                    except json.JSONDecodeError:
                        continue
    
    def format_request(self, messages: List[Dict], **kwargs) -> Dict[str, Any]:
        return kwargs
    
    def parse_response(self, raw_response: Dict) -> ProviderResponse:
        content = ""
        for candidate in raw_response.get('candidates', []):
            for part in candidate.get('content', {}).get('parts', []):
                content += part.get('text', '')
        
        usage = raw_response.get('usageMetadata', {})
        return ProviderResponse(
            content=content,
            model="gemini",
            usage={
                'prompt_tokens': usage.get('promptTokenCount', 0),
                'completion_tokens': usage.get('candidatesTokenCount', 0),
                'total_tokens': usage.get('totalTokenCount', 0)
            },
            finish_reason='stop',
            raw_response=raw_response
        )


class PerplexityProvider(OpenAICompatibleProvider):
    """Provider for Perplexity API (OpenAI-compatible with search)."""
    
    def format_request(self, messages: List[Dict], **kwargs) -> Dict[str, Any]:
        payload = super().format_request(messages, **kwargs)
        payload["return_images"] = False
        payload["return_related_questions"] = False
        payload["search_recency_filter"] = "month"
        return payload


class QwenProvider(OpenAICompatibleProvider):
    """Provider for Alibaba Qwen API."""
    
    def format_request(self, messages: List[Dict], **kwargs) -> Dict[str, Any]:
        payload = super().format_request(messages, **kwargs)
        payload["enable_search"] = kwargs.get('enable_search', False)
        return payload


class CopilotProvider(BaseProvider):
    """Provider for GitHub Copilot API."""
    
    async def chat(self, model: str, messages: List[Dict], **kwargs) -> ProviderResponse:
        payload = {
            "messages": messages,
            "temperature": kwargs.get('temperature', 0.7),
            "top_p": kwargs.get('top_p', 1.0),
        }
        
        async with self.session.post(
            f"{self.config.base_url}/chat/completions",
            headers={
                "Authorization": f"Bearer {self.config.api_key}",
                "Content-Type": "application/json",
                "Accept": "application/json"
            },
            json=payload
        ) as response:
            if response.status != 200:
                error_text = await response.text()
                raise Exception(f"Copilot API error {response.status}: {error_text}")
            
            raw = await response.json()
            return self.parse_response(raw)
    
    async def stream_chat(self, model: str, messages: List[Dict], **kwargs) -> AsyncIterator[StreamChunk]:
        payload = {
            "messages": messages,
            "temperature": kwargs.get('temperature', 0.7),
            "stream": True,
        }
        
        async with self.session.post(
            f"{self.config.base_url}/chat/completions",
            headers={
                "Authorization": f"Bearer {self.config.api_key}",
                "Content-Type": "application/json"
            },
            json=payload
        ) as response:
            async for line in response.content:
                line = line.decode('utf-8').strip()
                if line.startswith('data: '):
                    data = line[6:]
                    if data == '[DONE]':
                        yield StreamChunk(content="", is_finished=True, finish_reason="stop")
                        break
                    try:
                        chunk = json.loads(data)
                        delta = chunk.get('choices', [{}])[0].get('delta', {})
                        yield StreamChunk(
                            content=delta.get('content', ''),
                            is_finished=chunk.get('choices', [{}])[0].get('finish_reason') is not None,
                            finish_reason=chunk.get('choices', [{}])[0].get('finish_reason')
                        )
                    except json.JSONDecodeError:
                        continue
    
    def format_request(self, messages: List[Dict], **kwargs) -> Dict[str, Any]:
        return kwargs
    
    def parse_response(self, raw_response: Dict) -> ProviderResponse:
        choice = raw_response.get('choices', [{}])[0]
        message = choice.get('message', {})
        return ProviderResponse(
            content=message.get('content', ''),
            model=raw_response.get('model', 'copilot'),
            usage=raw_response.get('usage', {'prompt_tokens': 0, 'completion_tokens': 0, 'total_tokens': 0}),
            finish_reason=choice.get('finish_reason', 'unknown'),
            raw_response=raw_response
        )


class ManusProvider(OpenAICompatibleProvider):
    """Provider for Manus AI API."""
    
    def format_request(self, messages: List[Dict], **kwargs) -> Dict[str, Any]:
        payload = super().format_request(messages, **kwargs)
        payload["agent_mode"] = kwargs.get('agent_mode', True)
        payload["tools_enabled"] = kwargs.get('tools_enabled', True)
        return payload


class ProviderManager:
    """Manages all AI provider instances."""
    
    PROVIDER_MAP = {
        ProviderType.CHATGPT: OpenAICompatibleProvider,
        ProviderType.CLAUDE: ClaudeProvider,
        ProviderType.GEMINI: GeminiProvider,
        ProviderType.GROK: OpenAICompatibleProvider,
        ProviderType.KIMI: OpenAICompatibleProvider,
        ProviderType.PERPLEXITY: PerplexityProvider,
        ProviderType.QWEN: QwenProvider,
        ProviderType.COPILOT: CopilotProvider,
        ProviderType.MANUS: ManusProvider,
    }
    
    def __init__(self, configs: Dict[str, ProviderConfig]):
        self.configs = configs
        self.providers: Dict[ProviderType, BaseProvider] = {}
        self._build_providers()
    
    def _build_providers(self):
        """Build provider instances from configurations."""
        for name, config in self.configs.items():
            if not config.enabled:
                continue
            
            provider_class = self.PROVIDER_MAP.get(config.provider_type)
            if provider_class:
                self.providers[config.provider_type] = provider_class(config)
                logger.info(f"Initialized provider: {config.name}")
    
    async def initialize(self):
        """Initialize all providers."""
        for provider in self.providers.values():
            await provider.initialize()
    
    async def shutdown(self):
        """Shutdown all providers."""
        for provider in self.providers.values():
            await provider.shutdown()
    
    async def chat(self, provider_type: ProviderType, model: str, request) -> ProviderResponse:
        """Send chat request to specific provider."""
        provider = self.providers.get(provider_type)
        if not provider:
            raise ValueError(f"Provider {provider_type.value} not found")
        
        return await provider.chat(
            model=model,
            messages=request.messages,
            temperature=request.temperature,
            max_tokens=request.max_tokens,
            top_p=request.top_p,
            frequency_penalty=request.frequency_penalty,
            presence_penalty=request.presence_penalty,
            tools=request.tools,
            tool_choice=request.tool_choice,
            response_format=request.response_format,
        )
    
    async def stream_chat(self, provider_type: ProviderType, model: str, request) -> AsyncIterator[StreamChunk]:
        """Send streaming chat request to specific provider."""
        provider = self.providers.get(provider_type)
        if not provider:
            raise ValueError(f"Provider {provider_type.value} not found")
        
        async for chunk in provider.stream_chat(
            model=model,
            messages=request.messages,
            temperature=request.temperature,
            max_tokens=request.max_tokens,
            top_p=request.top_p,
            tools=request.tools,
            tool_choice=request.tool_choice,
        ):
            yield chunk
    
    def get_provider_config(self, provider_type: ProviderType) -> Optional[ProviderConfig]:
        """Get configuration for a provider."""
        for config in self.configs.values():
            if config.provider_type == provider_type:
                return config
        return None
    
    async def get_available_providers(self) -> List[ProviderType]:
        """Get list of available (enabled) providers."""
        return [pt for pt, p in self.providers.items() if p.config.enabled]
    
    async def get_models(self, provider_type: ProviderType) -> List[str]:
        """Get available models for a provider."""
        config = self.get_provider_config(provider_type)
        return config.models if config else []
    
    async def get_available_models(self) -> Dict[str, List[str]]:
        """Get all available models grouped by provider."""
        result = {}
        for pt in await self.get_available_providers():
            result[pt.value] = await self.get_models(pt)
        return result
    
    async def get_status(self) -> Dict[str, Any]:
        """Get status of all providers."""
        return {
            pt.value: {
                "enabled": p.config.enabled,
                "models": p.config.models,
                "base_url": p.config.base_url,
            }
            for pt, p in self.providers.items()
        }
