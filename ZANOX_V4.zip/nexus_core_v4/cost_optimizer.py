"""Cost Optimizer for Nexus Core V4."""

import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from collections import defaultdict
import time

from .config import NexusConfig, ProviderType
from .providers import ProviderManager, ProviderResponse


logger = logging.getLogger(__name__)


@dataclass
class CostEstimate:
    """Cost estimate for a request."""
    provider: ProviderType
    model: str
    estimated_input_cost: float
    estimated_output_cost: float
    estimated_total_cost: float
    confidence: float


@dataclass
class CostRecord:
    """Record of an actual cost incurred."""
    provider: ProviderType
    model: str
    input_tokens: int
    output_tokens: int
    input_cost: float
    output_cost: float
    total_cost: float
    timestamp: float
    request_id: str


class CostOptimizer:
    """Optimizes and tracks costs across all providers."""
    
    def __init__(self, config: NexusConfig, provider_manager: ProviderManager):
        self.config = config
        self.provider_manager = provider_manager
        self._cost_records: List[CostRecord] = []
        self._provider_costs: Dict[ProviderType, float] = defaultdict(float)
        self._model_costs: Dict[str, float] = defaultdict(float)
        self._daily_budget: float = 100.0
        self._daily_spent: float = 0.0
        self._last_budget_reset: float = time.time()
    
    def estimate_cost(self, provider: ProviderType, model: str, request) -> CostEstimate:
        """Estimate the cost of a request before sending."""
        config = self.provider_manager.get_provider_config(provider)
        if not config:
            return CostEstimate(provider, model, 0.0, 0.0, 0.0, 0.0)
        
        input_tokens = self._estimate_input_tokens(request)
        output_tokens = request.max_tokens or 1000
        
        input_cost = (input_tokens / 1000) * config.cost_per_1k_input
        output_cost = (output_tokens / 1000) * config.cost_per_1k_output
        total_cost = input_cost + output_cost
        
        return CostEstimate(
            provider=provider,
            model=model,
            estimated_input_cost=input_cost,
            estimated_output_cost=output_cost,
            estimated_total_cost=total_cost,
            confidence=0.8
        )
    
    def calculate_actual_cost(self, response: ProviderResponse) -> float:
        """Calculate the actual cost from a response."""
        usage = response.usage
        total_tokens = usage.get('total_tokens', 0)
        cost = (total_tokens / 1000) * 0.01
        return cost
    
    def _estimate_input_tokens(self, request) -> int:
        """Estimate the number of input tokens."""
        total_chars = 0
        for msg in request.messages:
            content = msg.get('content', '')
            if isinstance(content, str):
                total_chars += len(content)
            elif isinstance(content, list):
                for item in content:
                    if isinstance(item, dict):
                        total_chars += len(str(item.get('text', '')))
        
        return total_chars // 4
    
    def record_cost(self, record: CostRecord):
        """Record an actual cost for tracking."""
        self._cost_records.append(record)
        self._provider_costs[record.provider] += record.total_cost
        self._model_costs[record.model] += record.total_cost
        self._daily_spent += record.total_cost
        self._check_budget()
    
    def _check_budget(self):
        """Check if daily budget is exceeded."""
        if time.time() - self._last_budget_reset > 86400:
            self._daily_spent = 0.0
            self._last_budget_reset = time.time()
        
        if self._daily_spent > self._daily_budget:
            logger.warning(f"Daily budget exceeded: ${self._daily_spent:.2f} / ${self._daily_budget:.2f}")
    
    def get_cheapest_provider(self, request) -> Optional[ProviderType]:
        """Find the cheapest provider for a request."""
        providers = self.provider_manager.get_available_providers()
        best_cost = float('inf')
        best_provider = None
        
        for provider in providers:
            models = self.provider_manager.get_models(provider)
            for model in models:
                estimate = self.estimate_cost(provider, model, request)
                if estimate.estimated_total_cost < best_cost:
                    best_cost = estimate.estimated_total_cost
                    best_provider = provider
        
        return best_provider
    
    def get_cost_summary(self) -> Dict[str, Any]:
        """Get a summary of all costs."""
        total_cost = sum(r.total_cost for r in self._cost_records)
        
        return {
            "total_cost_usd": total_cost,
            "total_requests": len(self._cost_records),
            "average_cost_per_request": total_cost / len(self._cost_records) if self._cost_records else 0,
            "daily_budget": self._daily_budget,
            "daily_spent": self._daily_spent,
            "provider_breakdown": {p.value: c for p, c in self._provider_costs.items()},
            "model_breakdown": dict(self._model_costs),
        }
    
    def set_budget(self, budget: float):
        """Set the daily budget."""
        self._daily_budget = budget
        logger.info(f"Daily budget set to ${budget:.2f}")
