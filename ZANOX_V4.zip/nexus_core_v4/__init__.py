"""
Nexus Core V4 - Universal AI Connector Layer
A unified gateway for managing multiple AI providers with intelligent routing,
cost optimization, and failover capabilities.

Version: 4.0.0
Author: Nexus Team
License: MIT
"""

__version__ = "4.0.0"
__author__ = "Nexus Team"

from .gateway import NexusGateway
from .router import ModelRouter
from .providers import ProviderManager
from .cost_optimizer import CostOptimizer
from .token_manager import TokenManager
from .rate_limiter import RateLimitManager
from .failover import FailoverManager
from .load_balancer import LoadBalancer
from .context_router import ContextRouter
from .long_context import LongContextCoordinator

__all__ = [
    "NexusGateway",
    "ModelRouter", 
    "ProviderManager",
    "CostOptimizer",
    "TokenManager",
    "RateLimitManager",
    "FailoverManager",
    "LoadBalancer",
    "ContextRouter",
    "LongContextCoordinator",
]
