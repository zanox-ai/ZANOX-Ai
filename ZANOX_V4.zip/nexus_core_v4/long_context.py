"""Long Context Coordinator for Nexus Core V4."""

import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
import time

from .config import ContextConfig, ProviderType
from .token_manager import TokenManager


logger = logging.getLogger(__name__)


@dataclass
class ContextChunk:
    """A chunk of a long context."""
    index: int
    content: str
    token_count: int
    overlap: str = ""


class LongContextCoordinator:
    """Coordinates handling of long context requests."""
    
    def __init__(self, config: ContextConfig, token_manager: TokenManager):
        self.config = config
        self.token_manager = token_manager
        self._chunk_size = 32000
        self._overlap_size = 1000
    
    def is_long_context(self, messages: List[Dict[str, str]]) -> bool:
        """Check if messages constitute a long context."""
        total_tokens = self.token_manager.count_tokens(messages)
        return total_tokens > self.config.max_context_length * 0.8
    
    async def coordinate(self, request):
        """Coordinate a long context request."""
        messages = request.messages
        total_tokens = self.token_manager.count_tokens(messages)
        
        if total_tokens <= self.config.max_context_length:
            return request
        
        logger.info(f"Long context detected: {total_tokens} tokens")
        
        if self.config.context_window_strategy == "sliding_window":
            request.messages = self._sliding_window(messages)
        elif self.config.context_window_strategy == "summarization":
            request.messages = await self._summarize_context(messages)
        elif self.config.context_window_strategy == "hierarchical":
            request.messages = self._hierarchical_chunking(messages)
        else:
            request.messages = self._sliding_window(messages)
        
        return request
    
    def _sliding_window(self, messages: List[Dict[str, str]]) -> List[Dict[str, str]]:
        """Apply sliding window to keep most recent messages."""
        system_msgs = [m for m in messages if m.get('role') == 'system']
        other_msgs = [m for m in messages if m.get('role') != 'system']
        
        kept_messages = []
        token_count = sum(len(str(m.get('content', ''))) // 4 for m in system_msgs)
        
        for msg in reversed(other_msgs):
            msg_tokens = len(str(msg.get('content', ''))) // 4
            if token_count + msg_tokens > self.config.max_context_length * 0.9:
                break
            kept_messages.insert(0, msg)
            token_count += msg_tokens
        
        return system_msgs + kept_messages
    
    async def _summarize_context(self, messages: List[Dict[str, str]]) -> List[Dict[str, str]]:
        """Summarize older context to fit within limits."""
        system_msgs = [m for m in messages if m.get('role') == 'system']
        recent_msgs = messages[-5:] if len(messages) > 5 else messages
        older_msgs = messages[len(system_msgs):-5] if len(messages) > 5 + len(system_msgs) else []
        
        if older_msgs:
            summary_content = f"[Previous context: {len(older_msgs)} messages summarized]"
            summary_msg = {"role": "system", "content": summary_content}
            return system_msgs + [summary_msg] + recent_msgs
        
        return system_msgs + recent_msgs
    
    def _hierarchical_chunking(self, messages: List[Dict[str, str]]) -> List[Dict[str, str]]:
        """Apply hierarchical chunking for very long contexts."""
        system_msgs = [m for m in messages if m.get('role') == 'system']
        remaining = [m for m in messages if m.get('role') != 'system']
        chunks = []
        current_chunk = []
        current_tokens = 0
        
        for msg in remaining:
            msg_tokens = len(str(msg.get('content', ''))) // 4
            
            if current_tokens + msg_tokens > self._chunk_size and current_chunk:
                chunks.append(current_chunk)
                current_chunk = current_chunk[-2:] if len(current_chunk) >= 2 else []
                current_tokens = sum(len(str(m.get('content', ''))) // 4 for m in current_chunk)
            
            current_chunk.append(msg)
            current_tokens += msg_tokens
        
        if current_chunk:
            chunks.append(current_chunk)
        
        if chunks:
            return system_msgs + chunks[-1]
        
        return system_msgs
    
    def chunk_document(self, document: str, chunk_size: Optional[int] = None) -> List[ContextChunk]:
        """Chunk a long document into manageable pieces."""
        chunk_size = chunk_size or self._chunk_size
        words = document.split()
        chunks = []
        words_per_chunk = int(chunk_size * 0.75)
        
        for i in range(0, len(words), words_per_chunk - int(self._overlap_size * 0.75)):
            chunk_words = words[i:i + words_per_chunk]
            content = ' '.join(chunk_words)
            
            overlap = ""
            if i > 0:
                overlap_words = words[max(0, i - int(self._overlap_size * 0.75)):i]
                overlap = ' '.join(overlap_words)
            
            chunks.append(ContextChunk(
                index=len(chunks),
                content=content,
                token_count=len(content) // 4,
                overlap=overlap
            ))
        
        return chunks
    
    def get_stats(self) -> Dict[str, Any]:
        """Get long context coordinator statistics."""
        return {
            "chunk_size": self._chunk_size,
            "overlap_size": self._overlap_size,
            "max_context_length": self.config.max_context_length,
            "strategy": self.config.context_window_strategy,
        }
