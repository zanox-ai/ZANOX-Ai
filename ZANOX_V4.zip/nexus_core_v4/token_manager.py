"""Token Manager for Nexus Core V4."""

import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from collections import OrderedDict
import hashlib
import json
import time

from .config import TokenConfig, ProviderType


logger = logging.getLogger(__name__)


@dataclass
class TokenCacheEntry:
    """Entry in the token cache."""
    key: str
    tokens: int
    timestamp: float
    provider: ProviderType


class TokenManager:
    """Manages token counting, caching, and optimization."""
    
    def __init__(self, config: TokenConfig):
        self.config = config
        self._cache: OrderedDict[str, TokenCacheEntry] = OrderedDict()
        self._cache_hits = 0
        self._cache_misses = 0
        self._total_tokens_saved = 0
    
    def count_tokens(self, messages: List[Dict[str, str]]) -> int:
        """Count tokens in a message list (rough estimate)."""
        total_chars = 0
        for msg in messages:
            content = msg.get('content', '')
            if isinstance(content, str):
                total_chars += len(content)
            elif isinstance(content, list):
                for item in content:
                    if isinstance(item, dict):
                        total_chars += len(str(item.get('text', '')))
                    else:
                        total_chars += len(str(item))
        
        return total_chars // 4
    
    async def optimize(self, request, provider: ProviderType):
        """Optimize a request for token efficiency."""
        cache_key = self._generate_cache_key(request.messages)
        
        if self.config.enable_token_caching and cache_key in self._cache:
            entry = self._cache[cache_key]
            if time.time() - entry.timestamp < self.config.cache_ttl_seconds:
                self._cache_hits += 1
                self._total_tokens_saved += entry.tokens
                logger.debug(f"Token cache hit: {entry.tokens} tokens saved")
        else:
            self._cache_misses += 1
        
        if request.max_tokens:
            buffer = int(request.max_tokens * self.config.token_buffer_ratio)
            request.max_tokens = request.max_tokens + buffer
        
        if self.config.enable_compression:
            request = self._compress_messages(request, provider)
        
        if self.config.enable_token_caching:
            tokens = self.count_tokens(request.messages)
            self._cache[cache_key] = TokenCacheEntry(
                key=cache_key,
                tokens=tokens,
                timestamp=time.time(),
                provider=provider
            )
            
            while len(self._cache) > self.config.max_tokens_per_request:
                self._cache.popitem(last=False)
        
        return request
    
    def _generate_cache_key(self, messages: List[Dict[str, str]]) -> str:
        """Generate a cache key for a message list."""
        content = json.dumps(messages, sort_keys=True)
        return hashlib.md5(content.encode()).hexdigest()
    
    def _compress_messages(self, request, provider: ProviderType):
        """Compress messages to reduce token count."""
        compressed = []
        seen_system = False
        
        for msg in request.messages:
            role = msg.get('role', '')
            content = msg.get('content', '')
            
            if role == 'system':
                if seen_system:
                    continue
                seen_system = True
            
            if isinstance(content, str):
                content = ' '.join(content.split())
            
            compressed.append({"role": role, "content": content})
        
        request.messages = compressed
        return request
    
    def get_cache_stats(self) -> Dict[str, Any]:
        """Get token cache statistics."""
        total = self._cache_hits + self._cache_misses
        hit_rate = self._cache_hits / total if total > 0 else 0
        
        return {
            "cache_size": len(self._cache),
            "cache_hits": self._cache_hits,
            "cache_misses": self._cache_misses,
            "hit_rate": hit_rate,
            "total_tokens_saved": self._total_tokens_saved,
        }
    
    def clear_cache(self):
        """Clear the token cache."""
        self._cache.clear()
        self._cache_hits = 0
        self._cache_misses = 0
        self._total_tokens_saved = 0
        logger.info("Token cache cleared")
