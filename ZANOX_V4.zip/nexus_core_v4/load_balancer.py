"""Load Balancer for Nexus Core V4."""

import asyncio
import logging
from typing import Dict, Optional, Any, List
from dataclasses import dataclass, field
from enum import Enum
from collections import defaultdict
import time
import random

from .config import LoadBalancerConfig, ProviderType
from .providers import ProviderManager


logger = logging.getLogger(__name__)


class LoadBalancerAlgorithm(Enum):
    WEIGHTED_ROUND_ROBIN = "weighted_round_robin"
    LEAST_CONNECTIONS = "least_connections"
    LEAST_LATENCY = "least_latency"
    RANDOM = "random"
    IP_HASH = "ip_hash"


@dataclass
class ProviderLoad:
    """Load metrics for a provider."""
    provider: ProviderType
    active_connections: int = 0
    total_requests: int = 0
    total_latency: float = 0.0
    average_latency: float = 0.0
    weight: float = 1.0
    last_used: float = 0.0
    session_map: Dict[str, str] = field(default_factory=dict)


class LoadBalancer:
    """Distributes load across providers."""
    
    def __init__(self, config: LoadBalancerConfig, provider_manager: ProviderManager):
        self.config = config
        self.provider_manager = provider_manager
        self.algorithm = LoadBalancerAlgorithm(config.algorithm)
        self._provider_loads: Dict[ProviderType, ProviderLoad] = {}
        self._round_robin_index = 0
        self._lock = asyncio.Lock()
        self._initialize_loads()
    
    def _initialize_loads(self):
        """Initialize load tracking for all providers."""
        for provider_type, provider in self.provider_manager.providers.items():
            self._provider_loads[provider_type] = ProviderLoad(
                provider=provider_type,
                weight=provider.config.weight,
            )
    
    async def initialize(self):
        """Initialize load balancer."""
        logger.info(f"Load balancer initialized with algorithm: {self.algorithm.value}")
    
    async def shutdown(self):
        """Shutdown load balancer."""
        pass
    
    async def select_provider(self, preferred: ProviderType, request) -> ProviderType:
        """Select the best provider based on load balancing algorithm."""
        if not self.config.enable_load_balancing:
            return preferred
        
        if self.algorithm == LoadBalancerAlgorithm.WEIGHTED_ROUND_ROBIN:
            return await self._weighted_round_robin()
        elif self.algorithm == LoadBalancerAlgorithm.LEAST_CONNECTIONS:
            return await self._least_connections()
        elif self.algorithm == LoadBalancerAlgorithm.LEAST_LATENCY:
            return await self._least_latency()
        elif self.algorithm == LoadBalancerAlgorithm.RANDOM:
            return await self._random_selection()
        elif self.algorithm == LoadBalancerAlgorithm.IP_HASH:
            return await self._ip_hash(request)
        else:
            return preferred
    
    async def _weighted_round_robin(self) -> ProviderType:
        """Weighted round-robin selection."""
        async with self._lock:
            providers = list(self._provider_loads.keys())
            if not providers:
                return list(self.provider_manager.providers.keys())[0]
            
            self._round_robin_index = (self._round_robin_index + 1) % len(providers)
            return providers[self._round_robin_index]
    
    async def _least_connections(self) -> ProviderType:
        """Select provider with least active connections."""
        async with self._lock:
            best_provider = None
            min_connections = float('inf')
            
            for provider, load in self._provider_loads.items():
                if load.active_connections < min_connections:
                    min_connections = load.active_connections
                    best_provider = provider
            
            return best_provider or list(self.provider_manager.providers.keys())[0]
    
    async def _least_latency(self) -> ProviderType:
        """Select provider with lowest average latency."""
        async with self._lock:
            best_provider = None
            min_latency = float('inf')
            
            for provider, load in self._provider_loads.items():
                if load.average_latency > 0 and load.average_latency < min_latency:
                    min_latency = load.average_latency
                    best_provider = provider
            
            return best_provider or list(self.provider_manager.providers.keys())[0]
    
    async def _random_selection(self) -> ProviderType:
        """Random selection."""
        providers = list(self.provider_manager.providers.keys())
        return random.choice(providers) if providers else None
    
    async def _ip_hash(self, request) -> ProviderType:
        """Select provider based on IP hash for sticky sessions."""
        client_ip = request.metadata.get('client_ip', 'default')
        
        providers = list(self.provider_manager.providers.keys())
        if not providers:
            return None
        
        hash_val = hash(client_ip) % len(providers)
        return providers[hash_val]
    
    async def record_success(self, provider: ProviderType, latency: float):
        """Record a successful request."""
        async with self._lock:
            load = self._provider_loads.get(provider)
            if load:
                load.active_connections = max(0, load.active_connections - 1)
                load.total_requests += 1
                load.total_latency += latency
                load.average_latency = load.total_latency / load.total_requests
                load.last_used = time.time()
    
    async def record_start(self, provider: ProviderType):
        """Record the start of a request."""
        async with self._lock:
            load = self._provider_loads.get(provider)
            if load:
                load.active_connections += 1
    
    async def get_status(self) -> Dict[str, Any]:
        """Get load balancer status."""
        return {
            "algorithm": self.algorithm.value,
            "providers": {
                p.value: {
                    "active_connections": l.active_connections,
                    "total_requests": l.total_requests,
                    "average_latency_ms": l.average_latency,
                    "weight": l.weight,
                }
                for p, l in self._provider_loads.items()
            },
        }
