"""Rate Limit Manager for Nexus Core V4."""

import asyncio
import logging
from typing import Dict, Optional, Any
from dataclasses import dataclass
from collections import defaultdict
import time

from .config import RateLimitConfig, ProviderType


logger = logging.getLogger(__name__)


@dataclass
class RateLimitState:
    """State of rate limiting for a provider."""
    requests_last_minute: int = 0
    tokens_last_minute: int = 0
    last_request_time: float = 0.0
    consecutive_failures: int = 0
    is_throttled: bool = False
    throttle_until: float = 0.0


class RateLimitManager:
    """Manages rate limiting across all providers."""
    
    def __init__(self, config: RateLimitConfig):
        self.config = config
        self._global_state = RateLimitState()
        self._provider_states: Dict[ProviderType, RateLimitState] = defaultdict(RateLimitState)
        self._lock = asyncio.Lock()
        self._global_lock = asyncio.Lock()
        self._last_reset = time.time()
    
    async def acquire_global(self):
        """Acquire global rate limit."""
        async with self._global_lock:
            await self._check_and_wait(self._global_state, self.config.global_rpm, self.config.global_tpm)
            self._global_state.requests_last_minute += 1
    
    async def acquire_provider(self, provider: ProviderType):
        """Acquire provider-specific rate limit."""
        async with self._lock:
            state = self._provider_states[provider]
            
            if state.is_throttled and time.time() < state.throttle_until:
                wait_time = state.throttle_until - time.time()
                logger.warning(f"Provider {provider.value} throttled. Waiting {wait_time:.1f}s")
                await asyncio.sleep(wait_time)
            
            await self._check_and_wait(state, self.config.per_provider_rpm, self.config.per_provider_tpm)
            state.requests_last_minute += 1
    
    async def _check_and_wait(self, state: RateLimitState, rpm: int, tpm: int):
        """Check rate limits and wait if necessary."""
        current_time = time.time()
        
        if current_time - self._last_reset > 60:
            state.requests_last_minute = 0
            state.tokens_last_minute = 0
            self._last_reset = current_time
        
        if state.requests_last_minute >= rpm:
            wait_time = 60 - (current_time - self._last_reset)
            if wait_time > 0:
                logger.info(f"Rate limit reached. Waiting {wait_time:.1f}s")
                await asyncio.sleep(wait_time)
                state.requests_last_minute = 0
        
        if state.tokens_last_minute >= tpm:
            wait_time = 60 - (current_time - self._last_reset)
            if wait_time > 0:
                logger.info(f"Token limit reached. Waiting {wait_time:.1f}s")
                await asyncio.sleep(wait_time)
                state.tokens_last_minute = 0
        
        if state.last_request_time > 0:
            elapsed = current_time - state.last_request_time
            min_interval = 60.0 / rpm
            if elapsed < min_interval:
                await asyncio.sleep(min_interval - elapsed)
        
        state.last_request_time = time.time()
    
    def record_tokens(self, provider: ProviderType, tokens: int):
        """Record tokens used for a provider."""
        state = self._provider_states[provider]
        state.tokens_last_minute += tokens
    
    def throttle_provider(self, provider: ProviderType, duration: float):
        """Throttle a provider for a specified duration."""
        state = self._provider_states[provider]
        state.is_throttled = True
        state.throttle_until = time.time() + duration
        state.consecutive_failures += 1
        logger.warning(f"Provider {provider.value} throttled for {duration}s")
    
    def reset_provider(self, provider: ProviderType):
        """Reset rate limit state for a provider."""
        self._provider_states[provider] = RateLimitState()
        logger.info(f"Rate limit reset for {provider.value}")
    
    async def get_status(self) -> Dict[str, Any]:
        """Get rate limit status."""
        return {
            "global": {
                "requests_last_minute": self._global_state.requests_last_minute,
                "limit_rpm": self.config.global_rpm,
            },
            "providers": {
                p.value: {
                    "requests_last_minute": s.requests_last_minute,
                    "tokens_last_minute": s.tokens_last_minute,
                    "is_throttled": s.is_throttled,
                    "consecutive_failures": s.consecutive_failures,
                }
                for p, s in self._provider_states.items()
            },
        }
