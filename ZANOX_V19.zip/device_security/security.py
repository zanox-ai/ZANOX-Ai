"""
ZANOX V19 - Device Security
Device security management and threat detection.
"""
import asyncio
import logging
import hashlib
import hmac
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone

logger = logging.getLogger(__name__)

class DeviceSecurity:
    """Device security management"""

    def __init__(self, registry=None):
        self.registry = registry
        self._threats = []
        self._policies = {}
        self._lock = asyncio.Lock()

    async def authenticate_device(self, device_id: str, credentials: Dict[str, Any]) -> bool:
        """Authenticate device credentials"""
        if self.registry:
            device = await self.registry.get(device_id)
            if not device:
                return False

            stored = device.get("credentials", {})
            provided_token = credentials.get("token")
            stored_token = stored.get("token")

            if provided_token and stored_token:
                return hmac.compare_digest(provided_token.encode(), stored_token.encode())

        return False

    async def rotate_credentials(self, device_id: str) -> Dict[str, Any]:
        """Rotate device credentials"""
        new_token = hashlib.sha256(f"{device_id}:{datetime.now(timezone.utc).isoformat()}".encode()).hexdigest()

        if self.registry:
            device = await self.registry.get(device_id)
            if device:
                device["credentials"] = {"token": new_token, "rotated_at": datetime.now(timezone.utc).isoformat()}
                await self.registry.update(device_id, device)

        logger.info(f"Credentials rotated for {device_id}")
        return {"token": new_token, "expires_at": None}

    async def check_security_policy(self, device_id: str) -> Dict[str, Any]:
        """Check device against security policies"""
        violations = []

        if self.registry:
            device = await self.registry.get(device_id)
            if device:
                # Check firmware version
                firmware = device.get("firmware_version", "1.0.0")
                # Would compare against minimum required version

                # Check encryption
                if not device.get("encryption_enabled", False):
                    violations.append("Encryption not enabled")

                # Check certificate expiry
                cert_expiry = device.get("cert_expiry")
                if cert_expiry:
                    expiry = datetime.fromisoformat(cert_expiry)
                    if expiry < datetime.now(timezone.utc):
                        violations.append("Certificate expired")

        return {
            "device_id": device_id,
            "compliant": len(violations) == 0,
            "violations": violations
        }

    async def report_threat(self, device_id: str, threat_type: str, details: Dict[str, Any]):
        """Report security threat"""
        threat = {
            "device_id": device_id,
            "type": threat_type,
            "details": details,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "status": "open"
        }

        async with self._lock:
            self._threats.append(threat)

        logger.warning(f"Security threat: {device_id} - {threat_type}")

    async def get_threats(self, device_id: Optional[str] = None, status: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get security threats"""
        async with self._lock:
            threats = self._threats
            if device_id:
                threats = [t for t in threats if t["device_id"] == device_id]
            if status:
                threats = [t for t in threats if t["status"] == status]
            return threats

    async def resolve_threat(self, threat_index: int) -> bool:
        """Resolve security threat"""
        async with self._lock:
            if 0 <= threat_index < len(self._threats):
                self._threats[threat_index]["status"] = "resolved"
                self._threats[threat_index]["resolved_at"] = datetime.now(timezone.utc).isoformat()
                return True
        return False

    async def set_security_policy(self, policy_name: str, policy: Dict[str, Any]):
        """Set security policy"""
        self._policies[policy_name] = {
            "name": policy_name,
            "policy": policy,
            "created_at": datetime.now(timezone.utc).isoformat()
        }

    async def get_security_policy(self, policy_name: str) -> Optional[Dict[str, Any]]:
        """Get security policy"""
        return self._policies.get(policy_name)
