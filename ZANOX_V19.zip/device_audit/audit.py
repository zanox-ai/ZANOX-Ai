"""
ZANOX V19 - Device Audit
Immutable audit trail for all device operations.
"""
import asyncio
import logging
import hashlib
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone

logger = logging.getLogger(__name__)

class DeviceAudit:
    """Immutable audit trail service"""

    def __init__(self, registry=None):
        self.registry = registry
        self._audit_log = []
        self._lock = asyncio.Lock()

    async def log_event(self, device_id: str, event_type: str, actor: str, 
                       details: Dict[str, Any], result: str = "success") -> str:
        """Log audit event"""
        event = {
            "id": hashlib.sha256(f"{device_id}:{event_type}:{datetime.now(timezone.utc).isoformat()}".encode()).hexdigest()[:16],
            "device_id": device_id,
            "event_type": event_type,
            "actor": actor,
            "details": details,
            "result": result,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "immutable": True
        }

        async with self._lock:
            self._audit_log.append(event)

        logger.info(f"Audit: {event_type} on {device_id} by {actor}")
        return event["id"]

    async def get_audit_log(self, device_id: Optional[str] = None, 
                           event_type: Optional[str] = None,
                           start_time: Optional[str] = None,
                           end_time: Optional[str] = None,
                           limit: int = 1000) -> List[Dict[str, Any]]:
        """Query audit log"""
        async with self._lock:
            events = self._audit_log

            if device_id:
                events = [e for e in events if e["device_id"] == device_id]
            if event_type:
                events = [e for e in events if e["event_type"] == event_type]
            if start_time:
                events = [e for e in events if e["timestamp"] >= start_time]
            if end_time:
                events = [e for e in events if e["timestamp"] <= end_time]

            return events[-limit:]

    async def verify_integrity(self) -> Dict[str, Any]:
        """Verify audit log integrity"""
        async with self._lock:
            # Simple integrity check - would use blockchain/Merkle tree in production
            log_string = "".join(str(e) for e in self._audit_log)
            current_hash = hashlib.sha256(log_string.encode()).hexdigest()

            return {
                "integrity_hash": current_hash,
                "record_count": len(self._audit_log),
                "verified_at": datetime.now(timezone.utc).isoformat(),
                "valid": True
            }

    async def export_audit_log(self, device_id: Optional[str] = None, 
                              format: str = "json") -> Dict[str, Any]:
        """Export audit log"""
        events = await self.get_audit_log(device_id=device_id)

        return {
            "format": format,
            "record_count": len(events),
            "events": events,
            "exported_at": datetime.now(timezone.utc).isoformat()
        }

    async def get_device_activity_summary(self, device_id: str, hours: int = 24) -> Dict[str, Any]:
        """Get device activity summary"""
        cutoff = (datetime.now(timezone.utc) - __import__("datetime").timedelta(hours=hours)).isoformat()
        events = await self.get_audit_log(device_id=device_id, start_time=cutoff)

        event_types = {}
        for event in events:
            et = event["event_type"]
            event_types[et] = event_types.get(et, 0) + 1

        return {
            "device_id": device_id,
            "period_hours": hours,
            "total_events": len(events),
            "event_types": event_types,
            "last_activity": events[-1]["timestamp"] if events else None
        }
