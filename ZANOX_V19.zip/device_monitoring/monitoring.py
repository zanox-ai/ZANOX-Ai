"""
ZANOX V19 - Device Monitoring
Real-time device monitoring and health checks.
"""
import asyncio
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone, timedelta
import json

logger = logging.getLogger(__name__)

class DeviceMonitoring:
    """Real-time device monitoring service"""

    def __init__(self, engine=None, registry=None):
        self.engine = engine
        self.registry = registry
        self._metrics = {}
        self._alerts = []
        self._running = False
        self._lock = asyncio.Lock()

    async def start_monitoring(self, interval: int = 30):
        """Start continuous monitoring loop"""
        self._running = True
        logger.info(f"DeviceMonitoring: Started with {interval}s interval")

        while self._running:
            try:
                await self._check_all_devices()
                await asyncio.sleep(interval)
            except Exception as e:
                logger.error(f"Monitoring error: {e}")
                await asyncio.sleep(5)

    async def stop_monitoring(self):
        """Stop monitoring loop"""
        self._running = False
        logger.info("DeviceMonitoring: Stopped")

    async def _check_all_devices(self):
        """Check health of all devices"""
        if not self.registry:
            return

        devices = await self.registry.list_all(limit=10000)

        for device in devices:
            device_id = device["device_id"]
            health = await self._check_device_health(device)

            async with self._lock:
                self._metrics[device_id] = health

            if health["status"] == "critical":
                await self._trigger_alert(device_id, health)

    async def _check_device_health(self, device: Dict[str, Any]) -> Dict[str, Any]:
        """Check individual device health"""
        device_id = device["device_id"]
        last_seen = device.get("last_seen")

        if not last_seen:
            return {"status": "unknown", "score": 0}

        last_seen_dt = datetime.fromisoformat(last_seen)
        elapsed = (datetime.now(timezone.utc) - last_seen_dt).total_seconds()

        if elapsed > 300:  # 5 minutes
            return {"status": "critical", "score": 0, "reason": "No heartbeat for 5+ minutes"}
        elif elapsed > 120:  # 2 minutes
            return {"status": "warning", "score": 50, "reason": "Delayed heartbeat"}
        else:
            return {"status": "healthy", "score": 100, "reason": "Active"}

    async def _trigger_alert(self, device_id: str, health: Dict[str, Any]):
        """Trigger health alert"""
        alert = {
            "device_id": device_id,
            "severity": health["status"],
            "message": health["reason"],
            "timestamp": datetime.now(timezone.utc).isoformat()
        }

        async with self._lock:
            self._alerts.append(alert)

        logger.warning(f"Health alert: {device_id} - {health['reason']}")

    async def get_metrics(self, device_id: Optional[str] = None) -> Dict[str, Any]:
        """Get monitoring metrics"""
        async with self._lock:
            if device_id:
                return self._metrics.get(device_id, {})
            return dict(self._metrics)

    async def get_alerts(self, severity: Optional[str] = None, limit: int = 100) -> List[Dict[str, Any]]:
        """Get monitoring alerts"""
        async with self._lock:
            alerts = self._alerts[-limit:]
            if severity:
                alerts = [a for a in alerts if a["severity"] == severity]
            return alerts

    async def clear_alerts(self):
        """Clear all alerts"""
        async with self._lock:
            self._alerts.clear()

    async def get_uptime(self, device_id: str, hours: int = 24) -> float:
        """Calculate device uptime percentage"""
        # Implementation would track online/offline history
        return 99.9
