"""ZANOX V19 - Sensor Networks
Industrial sensor network management."""
import asyncio, logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone
from collections import defaultdict
logger = logging.getLogger(__name__)

class SensorNetworks:
    def __init__(self, engine=None):
        self.engine = engine
        self._networks = {}
        self._readings = defaultdict(list)

    async def create_network(self, network_id: str, name: str, protocol: str = "modbus", metadata: Dict = None):
        self._networks[network_id] = {"name": name, "protocol": protocol, "metadata": metadata or {}, "sensors": [], "created_at": datetime.now(timezone.utc).isoformat()}
        return True

    async def add_sensor(self, network_id: str, sensor_id: str, sensor_type: str, address: str):
        if network_id in self._networks:
            self._networks[network_id]["sensors"].append({"id": sensor_id, "type": sensor_type, "address": address})
        return True

    async def record_reading(self, sensor_id: str, value: float, unit: str):
        self._readings[sensor_id].append({"value": value, "unit": unit, "timestamp": datetime.now(timezone.utc).isoformat()})
        return True

    async def get_network(self, network_id: str) -> Optional[Dict[str, Any]]:
        return self._networks.get(network_id)

    async def get_sensor_readings(self, sensor_id: str, limit: int = 100) -> List[Dict[str, Any]]:
        return self._readings.get(sensor_id, [])[-limit:]
