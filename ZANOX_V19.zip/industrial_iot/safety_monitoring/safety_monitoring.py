"""ZANOX V19 - Safety Monitoring
Industrial safety monitoring and alerts."""
import asyncio, logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone
logger = logging.getLogger(__name__)

class SafetyMonitoring:
    def __init__(self, engine=None):
        self.engine = engine
        self._incidents = []
        self._sensors = {}

    async def register_safety_sensor(self, sensor_id: str, sensor_type: str, zone: str, threshold: float):
        self._sensors[sensor_id] = {"type": sensor_type, "zone": zone, "threshold": threshold, "status": "active"}
        return True

    async def record_reading(self, sensor_id: str, value: float):
        sensor = self._sensors.get(sensor_id)
        if sensor and value > sensor["threshold"]:
            await self._trigger_alert(sensor_id, value)
        return True

    async def _trigger_alert(self, sensor_id: str, value: float):
        sensor = self._sensors.get(sensor_id, {})
        incident = {"sensor_id": sensor_id, "type": sensor.get("type"), "zone": sensor.get("zone"), "value": value, "threshold": sensor.get("threshold"), "timestamp": datetime.now(timezone.utc).isoformat(), "status": "open"}
        self._incidents.append(incident)
        logger.warning(f"Safety alert: {sensor_id} - {value}")

    async def get_incidents(self, status: str = None, limit: int = 100) -> List[Dict[str, Any]]:
        incidents = self._incidents
        if status:
            incidents = [i for i in incidents if i["status"] == status]
        return incidents[-limit:]

    async def resolve_incident(self, incident_id: int) -> bool:
        if 0 <= incident_id < len(self._incidents):
            self._incidents[incident_id]["status"] = "resolved"
            self._incidents[incident_id]["resolved_at"] = datetime.now(timezone.utc).isoformat()
            return True
        return False
