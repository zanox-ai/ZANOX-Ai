"""ZANOX V19 - Machine Monitoring
Individual machine monitoring and diagnostics."""
import asyncio, logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone
from collections import defaultdict
logger = logging.getLogger(__name__)

class MachineMonitoring:
    def __init__(self, engine=None):
        self.engine = engine
        self._machines = {}
        self._telemetry = defaultdict(list)

    async def register_machine(self, machine_id: str, name: str, machine_type: str, line_id: str = None):
        self._machines[machine_id] = {"name": name, "type": machine_type, "line_id": line_id, "status": "idle", "registered_at": datetime.now(timezone.utc).isoformat()}
        return True

    async def record_telemetry(self, machine_id: str, temperature: float = None, vibration: float = None, pressure: float = None, rpm: float = None):
        self._telemetry[machine_id].append({"temperature": temperature, "vibration": vibration, "pressure": pressure, "rpm": rpm, "timestamp": datetime.now(timezone.utc).isoformat()})
        return True

    async def get_machine_status(self, machine_id: str) -> Optional[Dict[str, Any]]:
        return self._machines.get(machine_id)

    async def get_telemetry(self, machine_id: str, limit: int = 100) -> List[Dict[str, Any]]:
        return self._telemetry.get(machine_id, [])[-limit:]

    async def detect_anomaly(self, machine_id: str) -> bool:
        telemetry = await self.get_telemetry(machine_id, 100)
        if len(telemetry) < 10:
            return False
        temps = [t["temperature"] for t in telemetry if t["temperature"] is not None]
        if temps and max(temps) > 100:
            return True
        return False
