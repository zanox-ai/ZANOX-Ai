"""ZANOX V19 - Equipment Management
Industrial equipment lifecycle and asset management."""
import asyncio, logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone
logger = logging.getLogger(__name__)

class EquipmentManagement:
    def __init__(self, registry=None):
        self.registry = registry
        self._equipment = {}

    async def register_equipment(self, equipment_id: str, name: str, equipment_type: str, manufacturer: str, model: str, serial_number: str, purchase_date: str, warranty_years: int = 1):
        self._equipment[equipment_id] = {"name": name, "type": equipment_type, "manufacturer": manufacturer, "model": model, "serial_number": serial_number, "purchase_date": purchase_date, "warranty_years": warranty_years, "registered_at": datetime.now(timezone.utc).isoformat()}
        return True

    async def get_equipment(self, equipment_id: str) -> Optional[Dict[str, Any]]:
        return self._equipment.get(equipment_id)

    async def get_all_equipment(self) -> List[Dict[str, Any]]:
        return list(self._equipment.values())

    async def check_warranty(self, equipment_id: str) -> Dict[str, Any]:
        equip = self._equipment.get(equipment_id)
        if not equip:
            return {"error": "Equipment not found"}

        purchase = datetime.fromisoformat(equip["purchase_date"])
        warranty_end = purchase.replace(year=purchase.year + equip["warranty_years"])
        remaining = (warranty_end - datetime.now(timezone.utc)).days

        return {"equipment_id": equipment_id, "warranty_end": warranty_end.isoformat(), "days_remaining": remaining, "valid": remaining > 0}
