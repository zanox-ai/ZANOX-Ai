"""
ZANOX V19 - Device Firmware
Firmware management and version control.
"""
import asyncio
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone
import hashlib

logger = logging.getLogger(__name__)

class DeviceFirmware:
    """Firmware management service"""

    def __init__(self, registry=None, manager=None):
        self.registry = registry
        self.manager = manager
        self._firmware_db = {}
        self._lock = asyncio.Lock()

    async def register_firmware(self, version: str, url: str, checksum: str, 
                              device_types: List[str], size: int = 0) -> str:
        """Register new firmware version"""
        firmware_id = hashlib.sha256(f"{version}:{url}".encode()).hexdigest()[:16]

        async with self._lock:
            self._firmware_db[firmware_id] = {
                "id": firmware_id,
                "version": version,
                "url": url,
                "checksum": checksum,
                "device_types": device_types,
                "size": size,
                "registered_at": datetime.now(timezone.utc).isoformat(),
                "status": "available"
            }

        logger.info(f"Firmware registered: {version} ({firmware_id})")
        return firmware_id

    async def get_firmware(self, firmware_id: str) -> Optional[Dict[str, Any]]:
        """Get firmware details"""
        async with self._lock:
            return self._firmware_db.get(firmware_id)

    async def list_firmware(self, device_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """List available firmware"""
        async with self._lock:
            firmwares = list(self._firmware_db.values())
            if device_type:
                firmwares = [f for f in firmwares if device_type in f.get("device_types", [])]
            return firmwares

    async def get_latest_for_device(self, device_type: str) -> Optional[Dict[str, Any]]:
        """Get latest firmware for device type"""
        firmwares = await self.list_firmware(device_type)
        if not firmwares:
            return None

        # Sort by version (simplified)
        return max(firmwares, key=lambda f: f["version"])

    async def check_device_firmware(self, device_id: str) -> Dict[str, Any]:
        """Check if device firmware is up to date"""
        if not self.registry:
            return {"error": "No registry"}

        device = await self.registry.get(device_id)
        if not device:
            return {"error": "Device not found"}

        current_version = device.get("firmware_version", "1.0.0")
        device_type = device.get("device_type")

        latest = await self.get_latest_for_device(device_type)

        if not latest:
            return {
                "device_id": device_id,
                "current_version": current_version,
                "latest_version": current_version,
                "update_available": False
            }

        return {
            "device_id": device_id,
            "current_version": current_version,
            "latest_version": latest["version"],
            "update_available": latest["version"] != current_version,
            "firmware_id": latest["id"] if latest["version"] != current_version else None
        }

    async def schedule_update(self, device_id: str, firmware_id: str) -> bool:
        """Schedule firmware update for device"""
        firmware = await self.get_firmware(firmware_id)
        if not firmware:
            return False

        if self.manager:
            await self.manager.update_firmware(device_id, firmware["version"], firmware["url"])

        logger.info(f"Firmware update scheduled: {device_id} -> {firmware['version']}")
        return True

    async def validate_firmware(self, firmware_id: str, checksum: str) -> bool:
        """Validate firmware checksum"""
        firmware = await self.get_firmware(firmware_id)
        if not firmware:
            return False
        return firmware["checksum"] == checksum
