"""ZANOX V19 - IoT Smart Device & Physical World Intelligence Layer"""
