"""
ZANOX V19 - Device Compliance
Regulatory compliance management (GDPR, SOC2, ISO27001, NIST).
"""
import asyncio
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone

logger = logging.getLogger(__name__)

class DeviceCompliance:
    """Regulatory compliance management"""

    def __init__(self, registry=None, governance=None):
        self.registry = registry
        self.governance = governance
        self._frameworks = {
            "gdpr": self._gdpr_requirements(),
            "soc2": self._soc2_requirements(),
            "iso27001": self._iso27001_requirements(),
            "nist": self._nist_requirements()
        }
        self._assessments = []
        self._lock = asyncio.Lock()

    def _gdpr_requirements(self) -> List[Dict[str, Any]]:
        return [
            {"id": "gdpr-1", "name": "Data Minimization", "description": "Collect only necessary data"},
            {"id": "gdpr-2", "name": "Purpose Limitation", "description": "Use data only for stated purposes"},
            {"id": "gdpr-3", "name": "Storage Limitation", "description": "Retain data only as long as needed"},
            {"id": "gdpr-4", "name": "Data Subject Rights", "description": "Enable access, rectification, erasure"},
            {"id": "gdpr-5", "name": "Security", "description": "Implement appropriate security measures"}
        ]

    def _soc2_requirements(self) -> List[Dict[str, Any]]:
        return [
            {"id": "soc2-1", "name": "Security", "description": "System is protected against unauthorized access"},
            {"id": "soc2-2", "name": "Availability", "description": "System is available for operation"},
            {"id": "soc2-3", "name": "Processing Integrity", "description": "System processing is complete and accurate"},
            {"id": "soc2-4", "name": "Confidentiality", "description": "Information designated confidential is protected"},
            {"id": "soc2-5", "name": "Privacy", "description": "Personal information is collected, used, and disposed properly"}
        ]

    def _iso27001_requirements(self) -> List[Dict[str, Any]]:
        return [
            {"id": "iso-1", "name": "Information Security Policy", "description": "Management direction for information security"},
            {"id": "iso-2", "name": "Organization of Information Security", "description": "Internal organization and mobile devices"},
            {"id": "iso-3", "name": "Human Resource Security", "description": "Prior to employment and during employment"},
            {"id": "iso-4", "name": "Asset Management", "description": "Responsibility for assets and acceptable use"},
            {"id": "iso-5", "name": "Access Control", "description": "Business requirements and user access management"}
        ]

    def _nist_requirements(self) -> List[Dict[str, Any]]:
        return [
            {"id": "nist-1", "name": "Identify", "description": "Asset management and risk assessment"},
            {"id": "nist-2", "name": "Protect", "description": "Access control and data security"},
            {"id": "nist-3", "name": "Detect", "description": "Anomalies and events and continuous monitoring"},
            {"id": "nist-4", "name": "Respond", "description": "Response planning and communications"},
            {"id": "nist-5", "name": "Recover", "description": "Recovery planning and improvements"}
        ]

    async def assess_compliance(self, device_id: str, framework: str) -> Dict[str, Any]:
        """Assess device compliance against framework"""
        requirements = self._frameworks.get(framework, [])

        if not self.registry:
            return {"error": "No registry"}

        device = await self.registry.get(device_id)
        if not device:
            return {"error": "Device not found"}

        results = []
        for req in requirements:
            # Simplified assessment - would be more thorough in production
            passed = device.get("compliance", {}).get(req["id"], False)
            results.append({
                "requirement": req,
                "passed": passed,
                "evidence": device.get("compliance_evidence", {}).get(req["id"])
            })

        passed_count = len([r for r in results if r["passed"]])
        total = len(results)

        assessment = {
            "device_id": device_id,
            "framework": framework,
            "passed": passed_count,
            "total": total,
            "score": (passed_count / total * 100) if total > 0 else 0,
            "results": results,
            "assessed_at": datetime.now(timezone.utc).isoformat()
        }

        async with self._lock:
            self._assessments.append(assessment)

        return assessment

    async def get_frameworks(self) -> List[str]:
        """Get available compliance frameworks"""
        return list(self._frameworks.keys())

    async def get_framework_requirements(self, framework: str) -> List[Dict[str, Any]]:
        """Get requirements for framework"""
        return self._frameworks.get(framework, [])

    async def get_assessments(self, device_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get compliance assessments"""
        async with self._lock:
            if device_id:
                return [a for a in self._assessments if a["device_id"] == device_id]
            return list(self._assessments)

    async def generate_compliance_report(self, framework: str) -> Dict[str, Any]:
        """Generate fleet compliance report"""
        if not self.registry:
            return {"error": "No registry"}

        devices = await self.registry.list_all(limit=10000)
        assessments = []

        for device in devices:
            assessment = await self.assess_compliance(device["device_id"], framework)
            assessments.append(assessment)

        scores = [a.get("score", 0) for a in assessments if "score" in a]
        avg_score = sum(scores) / len(scores) if scores else 0

        return {
            "framework": framework,
            "total_devices": len(devices),
            "assessed_devices": len(assessments),
            "average_score": avg_score,
            "assessments": assessments,
            "generated_at": datetime.now(timezone.utc).isoformat()
        }
