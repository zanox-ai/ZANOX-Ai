"""
ZANOX V19 - Device Health
Device health scoring and diagnostics.
"""
import asyncio
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone, timedelta

logger = logging.getLogger(__name__)

class DeviceHealth:
    """Device health assessment engine"""

    def __init__(self, registry=None, monitoring=None):
        self.registry = registry
        self.monitoring = monitoring
        self._health_scores = {}
        self._diagnostics = {}
        self._lock = asyncio.Lock()

    async def calculate_health_score(self, device_id: str) -> float:
        """Calculate comprehensive health score (0-100)"""
        score = 100.0
        factors = []

        if self.registry:
            device = await self.registry.get(device_id)
            if not device:
                return 0.0

            # Check last seen
            last_seen = device.get("last_seen")
            if last_seen:
                elapsed = (datetime.now(timezone.utc) - datetime.fromisoformat(last_seen)).total_seconds()
                if elapsed > 300:
                    score -= 40
                    factors.append("No heartbeat > 5min")
                elif elapsed > 120:
                    score -= 20
                    factors.append("Delayed heartbeat")
            else:
                score -= 50
                factors.append("Never seen")

            # Check firmware age
            firmware = device.get("firmware_version", "1.0.0")
            # Simplified check - would compare against latest

            # Check error rate
            errors = device.get("error_count", 0)
            if errors > 10:
                score -= 20
                factors.append(f"High errors: {errors}")

        score = max(0.0, min(100.0, score))

        async with self._lock:
            self._health_scores[device_id] = {
                "score": score,
                "factors": factors,
                "calculated_at": datetime.now(timezone.utc).isoformat()
            }

        return score

    async def run_diagnostics(self, device_id: str) -> Dict[str, Any]:
        """Run comprehensive device diagnostics"""
        diagnostics = {
            "device_id": device_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "checks": []
        }

        if self.registry:
            device = await self.registry.get(device_id)
            if device:
                # Connectivity check
                diagnostics["checks"].append({
                    "name": "connectivity",
                    "status": "pass" if device.get("status") == "online" else "fail",
                    "details": f"Status: {device.get('status')}"
                })

                # Heartbeat check
                last_seen = device.get("last_seen")
                if last_seen:
                    elapsed = (datetime.now(timezone.utc) - datetime.fromisoformat(last_seen)).total_seconds()
                    diagnostics["checks"].append({
                        "name": "heartbeat",
                        "status": "pass" if elapsed < 120 else "fail",
                        "details": f"Last seen: {elapsed:.0f}s ago"
                    })

                # Configuration check
                config = device.get("config")
                diagnostics["checks"].append({
                    "name": "configuration",
                    "status": "pass" if config else "warning",
                    "details": "Config present" if config else "No config"
                })

        async with self._lock:
            self._diagnostics[device_id] = diagnostics

        return diagnostics

    async def get_health_score(self, device_id: str) -> Optional[Dict[str, Any]]:
        """Get cached health score"""
        async with self._lock:
            return self._health_scores.get(device_id)

    async def get_all_health_scores(self) -> Dict[str, Any]:
        """Get all health scores"""
        async with self._lock:
            return dict(self._health_scores)

    async def get_diagnostics(self, device_id: str) -> Optional[Dict[str, Any]]:
        """Get cached diagnostics"""
        async with self._lock:
            return self._diagnostics.get(device_id)

    async def identify_unhealthy_devices(self, threshold: float = 50.0) -> List[str]:
        """Identify devices with health score below threshold"""
        unhealthy = []
        async with self._lock:
            for device_id, health in self._health_scores.items():
                if health["score"] < threshold:
                    unhealthy.append(device_id)
        return unhealthy

    async def schedule_health_checks(self, interval: int = 300):
        """Schedule periodic health checks"""
        while True:
            if self.registry:
                devices = await self.registry.list_all(limit=10000)
                for device in devices:
                    await self.calculate_health_score(device["device_id"])
            await asyncio.sleep(interval)
