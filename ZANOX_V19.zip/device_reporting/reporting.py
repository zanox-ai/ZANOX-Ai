"""
ZANOX V19 - Device Reporting
Comprehensive reporting and analytics export.
"""
import asyncio
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone, timedelta
import json

logger = logging.getLogger(__name__)

class DeviceReporting:
    """Device reporting and export service"""

    def __init__(self, registry=None, analytics=None, monitoring=None):
        self.registry = registry
        self.analytics = analytics
        self.monitoring = monitoring
        self._reports = {}
        self._lock = asyncio.Lock()

    async def generate_device_report(self, device_id: str, report_type: str = "summary") -> Dict[str, Any]:
        """Generate device report"""
        report = {
            "device_id": device_id,
            "report_type": report_type,
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "data": {}
        }

        if self.registry:
            device = await self.registry.get(device_id)
            if device:
                report["data"]["device_info"] = device

        if self.analytics:
            report["data"]["analytics"] = await self.analytics.get_device_summary(device_id)

        if self.monitoring:
            report["data"]["metrics"] = await self.monitoring.get_metrics(device_id)

        return report

    async def generate_fleet_report(self, device_type: Optional[str] = None) -> Dict[str, Any]:
        """Generate fleet-wide report"""
        report = {
            "report_type": "fleet",
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "data": {}
        }

        if self.analytics:
            report["data"]["fleet_summary"] = await self.analytics.get_fleet_summary(device_type)

        if self.registry:
            devices = await self.registry.list_all(limit=10000)
            report["data"]["total_devices"] = len(devices)
            report["data"]["device_types"] = list(set(d.get("device_type") for d in devices if d.get("device_type")))

        return report

    async def generate_health_report(self, hours: int = 24) -> Dict[str, Any]:
        """Generate health report"""
        report = {
            "report_type": "health",
            "period_hours": hours,
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "data": {}
        }

        if self.monitoring:
            report["data"]["alerts"] = await self.monitoring.get_alerts(limit=100)

        if self.registry:
            devices = await self.registry.list_all(limit=10000)
            online = len([d for d in devices if d.get("status") == "online"])
            report["data"]["online_count"] = online
            report["data"]["offline_count"] = len(devices) - online

        return report

    async def export_report(self, report_id: str, format: str = "json") -> Dict[str, Any]:
        """Export report in specified format"""
        async with self._lock:
            report = self._reports.get(report_id)
            if not report:
                return {"error": "Report not found"}

            if format == "json":
                return {"format": "json", "data": json.dumps(report)}
            elif format == "csv":
                # Would convert to CSV
                return {"format": "csv", "data": "CSV conversion not implemented"}
            else:
                return {"error": f"Unsupported format: {format}"}

    async def schedule_report(self, report_type: str, schedule: str, 
                             recipients: List[str]) -> str:
        """Schedule recurring report"""
        schedule_id = f"sch_{report_type}_{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}"

        async with self._lock:
            self._reports[schedule_id] = {
                "id": schedule_id,
                "report_type": report_type,
                "schedule": schedule,
                "recipients": recipients,
                "created_at": datetime.now(timezone.utc).isoformat(),
                "active": True
            }

        return schedule_id

    async def get_scheduled_reports(self) -> List[Dict[str, Any]]:
        """Get scheduled reports"""
        async with self._lock:
            return [r for r in self._reports.values() if r.get("active")]
