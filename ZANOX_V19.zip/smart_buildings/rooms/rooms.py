"""ZANOX V19 - Smart Building Rooms
Room-level management and monitoring."""
import asyncio, logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone
logger = logging.getLogger(__name__)

class RoomManagement:
    def __init__(self, engine=None):
        self.engine = engine
        self._rooms = {}

    async def register_room(self, floor_id: str, room_id: str, name: str, room_type: str = "office", metadata: Dict = None):
        self._rooms[room_id] = {"floor_id": floor_id, "name": name, "type": room_type, "metadata": metadata or {}, "devices": [], "registered_at": datetime.now(timezone.utc).isoformat()}
        return True

    async def add_device(self, room_id: str, device_id: str):
        if room_id in self._rooms:
            self._rooms[room_id]["devices"].append(device_id)
        return True

    async def get_room(self, room_id: str) -> Optional[Dict[str, Any]]:
        return self._rooms.get(room_id)

    async def get_all_rooms(self, floor_id: str = None) -> List[Dict[str, Any]]:
        rooms = list(self._rooms.values())
        if floor_id:
            rooms = [r for r in rooms if r["floor_id"] == floor_id]
        return rooms
