"""ZANOX V19 - Occupancy Detection
Real-time occupancy monitoring and analytics."""
import asyncio, logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone
from collections import defaultdict
logger = logging.getLogger(__name__)

class OccupancyDetection:
    def __init__(self, engine=None):
        self.engine = engine
        self._occupancy = defaultdict(int)
        self._history = defaultdict(list)

    async def update_occupancy(self, room_id: str, count: int):
        self._occupancy[room_id] = count
        self._history[room_id].append({"count": count, "timestamp": datetime.now(timezone.utc).isoformat()})
        return True

    async def get_occupancy(self, room_id: str) -> int:
        return self._occupancy.get(room_id, 0)

    async def get_total_occupancy(self, floor_id: str = None) -> int:
        if floor_id:
            return sum(self._occupancy.get(r, 0) for r in self._get_rooms_on_floor(floor_id))
        return sum(self._occupancy.values())

    def _get_rooms_on_floor(self, floor_id: str) -> List[str]:
        return [r for r, data in self._occupancy.items()]

    async def get_occupancy_history(self, room_id: str, hours: int = 24) -> List[Dict[str, Any]]:
        cutoff = (datetime.now(timezone.utc) - __import__("datetime").timedelta(hours=hours)).isoformat()
        return [h for h in self._history.get(room_id, []) if h["timestamp"] > cutoff]

    async def detect_anomaly(self, room_id: str) -> bool:
        current = await self.get_occupancy(room_id)
        history = await self.get_occupancy_history(room_id, hours=168)
        if not history:
            return False
        avg = sum(h["count"] for h in history) / len(history)
        return abs(current - avg) > avg * 2
