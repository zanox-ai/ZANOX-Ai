"""ZANOX V19 - Visitor Management
Visitor tracking and management."""
import asyncio, logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone
logger = logging.getLogger(__name__)

class VisitorManagement:
    def __init__(self, engine=None):
        self.engine = engine
        self._visitors = {}
        self._checkins = []

    async def register_visitor(self, visitor_id: str, name: str, host: str, purpose: str, metadata: Dict = None):
        self._visitors[visitor_id] = {"name": name, "host": host, "purpose": purpose, "metadata": metadata or {}, "registered_at": datetime.now(timezone.utc).isoformat()}
        return True

    async def check_in(self, visitor_id: str):
        self._checkins.append({"visitor_id": visitor_id, "action": "check_in", "timestamp": datetime.now(timezone.utc).isoformat()})
        return True

    async def check_out(self, visitor_id: str):
        self._checkins.append({"visitor_id": visitor_id, "action": "check_out", "timestamp": datetime.now(timezone.utc).isoformat()})
        return True

    async def get_visitor(self, visitor_id: str) -> Optional[Dict[str, Any]]:
        return self._visitors.get(visitor_id)

    async def get_current_visitors(self) -> List[Dict[str, Any]]:
        checked_in = set()
        checked_out = set()
        for c in self._checkins:
            if c["action"] == "check_in":
                checked_in.add(c["visitor_id"])
            elif c["action"] == "check_out":
                checked_out.add(c["visitor_id"])
        current = checked_in - checked_out
        return [self._visitors.get(v) for v in current if v in self._visitors]
