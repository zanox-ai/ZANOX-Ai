"""ZANOX V19 - Building Environment
Environmental monitoring and control for buildings."""
import asyncio, logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone
from collections import defaultdict
logger = logging.getLogger(__name__)

class BuildingEnvironment:
    def __init__(self, engine=None):
        self.engine = engine
        self._readings = defaultdict(list)

    async def record_reading(self, zone_id: str, metric: str, value: float, unit: str):
        self._readings[f"{zone_id}:{metric}"].append({"value": value, "unit": unit, "timestamp": datetime.now(timezone.utc).isoformat()})
        return True

    async def get_current(self, zone_id: str, metric: str) -> Optional[Dict[str, Any]]:
        readings = self._readings.get(f"{zone_id}:{metric}", [])
        return readings[-1] if readings else None

    async def get_average(self, zone_id: str, metric: str, hours: int = 24) -> float:
        readings = self._readings.get(f"{zone_id}:{metric}", [])
        cutoff = (datetime.now(timezone.utc) - __import__("datetime").timedelta(hours=hours)).isoformat()
        recent = [r["value"] for r in readings if r["timestamp"] > cutoff]
        return sum(recent) / len(recent) if recent else 0.0

    async def check_comfort(self, zone_id: str) -> Dict[str, Any]:
        temp = await self.get_current(zone_id, "temperature")
        humidity = await self.get_current(zone_id, "humidity")

        comfort_score = 100
        issues = []

        if temp and temp["value"] > 26:
            comfort_score -= 20
            issues.append("Too hot")
        elif temp and temp["value"] < 18:
            comfort_score -= 20
            issues.append("Too cold")

        if humidity and humidity["value"] > 60:
            comfort_score -= 15
            issues.append("Too humid")
        elif humidity and humidity["value"] < 30:
            comfort_score -= 15
            issues.append("Too dry")

        return {"score": comfort_score, "issues": issues, "temperature": temp, "humidity": humidity}
