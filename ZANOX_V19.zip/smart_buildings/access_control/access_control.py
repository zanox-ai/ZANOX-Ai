"""ZANOX V19 - Access Control
Building access control and credential management."""
import asyncio, logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone
logger = logging.getLogger(__name__)

class AccessControl:
    def __init__(self, engine=None):
        self.engine = engine
        self._credentials = {}
        self._access_log = []
        self._lock = asyncio.Lock()

    async def register_credential(self, user_id: str, credential_type: str, credential_data: str, access_level: str = "standard"):
        self._credentials[user_id] = {"type": credential_type, "data": credential_data, "level": access_level, "created_at": datetime.now(timezone.utc).isoformat()}
        return True

    async def authenticate(self, user_id: str, credential_data: str) -> bool:
        cred = self._credentials.get(user_id)
        if not cred:
            return False
        return cred["data"] == credential_data

    async def grant_access(self, user_id: str, door_id: str) -> bool:
        if await self.authenticate(user_id, self._credentials.get(user_id, {}).get("data", "")):
            self._access_log.append({"user_id": user_id, "door_id": door_id, "action": "grant", "timestamp": datetime.now(timezone.utc).isoformat()})
            if self.engine:
                await self.engine.send_command(door_id, "unlock", {"user_id": user_id})
            return True
        return False

    async def revoke_access(self, user_id: str):
        self._credentials.pop(user_id, None)
        return True

    async def get_access_log(self, user_id: str = None, door_id: str = None, limit: int = 100) -> List[Dict[str, Any]]:
        logs = self._access_log
        if user_id:
            logs = [l for l in logs if l["user_id"] == user_id]
        if door_id:
            logs = [l for l in logs if l["door_id"] == door_id]
        return logs[-limit:]
