"""
ZANOX V19 - IoT Engine
Core orchestration engine for IoT device management.
Integrates with V1-V18 layers completely.
"""
import asyncio
import logging
import json
import time
import os
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
import uuid
import redis.asyncio as redis
from fastapi import FastAPI, WebSocket, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
import asyncpg
from prometheus_client import Counter, Histogram, Gauge
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

DEVICE_CONNECTIONS = Gauge("zanox_device_connections", "Active connections", ["protocol"])
DEVICE_MESSAGES = Counter("zanox_device_messages_total", "Total messages", ["direction", "protocol"])
DEVICE_LATENCY = Histogram("zanox_device_latency_seconds", "Latency", ["protocol"])
DEVICE_ERRORS = Counter("zanox_device_errors_total", "Errors", ["error_type"])
DEVICE_HEALTH_SCORE = Gauge("zanox_device_health_score", "Health score", ["device_id"])

trace.set_tracer_provider(TracerProvider())
tracer = trace.get_tracer(__name__)
otlp_exporter = OTLPSpanExporter(endpoint="http://localhost:4317", insecure=True)
span_processor = BatchSpanProcessor(otlp_exporter)
trace.get_tracer_provider().add_span_processor(span_processor)

class DeviceStatus(Enum):
    OFFLINE = "offline"
    ONLINE = "online"
    CONNECTING = "connecting"
    ERROR = "error"
    MAINTENANCE = "maintenance"
    DECOMMISSIONED = "decommissioned"

class DeviceProtocol(Enum):
    MQTT = "mqtt"
    AMQP = "amqp"
    COAP = "coap"
    MODBUS = "modbus"
    OPCUA = "opcua"
    CANBUS = "canbus"
    BLE = "ble"
    ZIGBEE = "zigbee"
    ZWAVE = "zwave"
    LORAWAN = "lorawan"
    NBIOT = "nbiot"
    FIVE_G = "5g"

@dataclass
class DeviceCapabilities:
    sensors: List[str] = field(default_factory=list)
    actuators: List[str] = field(default_factory=list)
    protocols: List[str] = field(default_factory=list)
    features: List[str] = field(default_factory=list)

@dataclass
class Device:
    device_id: str
    name: str
    device_type: str
    protocol: DeviceProtocol
    status: DeviceStatus
    ip_address: Optional[str] = None
    port: Optional[int] = None
    capabilities: DeviceCapabilities = field(default_factory=DeviceCapabilities)
    metadata: Dict[str, Any] = field(default_factory=dict)
    location: Dict[str, Any] = field(default_factory=dict)
    firmware_version: str = "1.0.0"
    last_seen: Optional[str] = None
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    health_score: float = 100.0
    is_active: bool = True
    tenant_id: Optional[str] = None
    parent_device_id: Optional[str] = None
    children_ids: List[str] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict:
        data = asdict(self)
        data["protocol"] = self.protocol.value
        data["status"] = self.status.value
        return data

@dataclass
class DeviceMessage:
    message_id: str
    device_id: str
    message_type: str
    payload: Dict[str, Any]
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    qos: int = 1
    retained: bool = False
    topic: str = ""
    correlation_id: Optional[str] = None
    
    def to_dict(self) -> Dict:
        return asdict(self)

class IoTEngine:
    """Main IoT Engine orchestrating all device operations"""
    
    def __init__(self, config=None):
        self.config = config or IoTConfig()
        self.devices = {}
        self.device_messages = asyncio.Queue(maxsize=100000)
        self.sensor_readings = asyncio.Queue(maxsize=1000000)
        self.commands = asyncio.Queue(maxsize=10000)
        self.active_connections = {}
        self.redis = None
        self.db_pool = None
        self.kafka_producer = None
        self.running = False
        self._lock = asyncio.Lock()
    
    async def initialize(self):
        """Initialize all connections and services"""
        logger.info(f"Initializing ZANOX V{self.config.version} IoT Engine...")
        
        if self.config.redis_url:
            self.redis = redis.from_url(
                self.config.redis_url,
                decode_responses=True,
                max_connections=50
            )
            await self.redis.ping()
            logger.info("Redis connection established")
        
        if self.config.postgres_dsn:
            self.db_pool = await asyncpg.create_pool(
                self.config.postgres_dsn,
                min_size=5,
                max_size=20,
                command_timeout=60
            )
            logger.info("PostgreSQL connection pool created")
        
        self.running = True
        logger.info("ZANOX V19 IoT Engine initialized successfully")
    
    async def shutdown(self):
        """Graceful shutdown of all services"""
        logger.info("Shutting down ZANOX V19 IoT Engine...")
        self.running = False
        
        if self.db_pool:
            await self.db_pool.close()
            logger.info("PostgreSQL pool closed")
        
        if self.redis:
            await self.redis.close()
            logger.info("Redis connection closed")
        
        logger.info("ZANOX V19 IoT Engine shutdown complete")
    
    async def register_device(self, device):
        """Register a new device in the system"""
        async with self._lock:
            if len(self.devices) >= self.config.max_devices:
                raise HTTPException(status_code=429, detail="Maximum device limit reached")
            
            if device.device_id in self.devices:
                raise HTTPException(status_code=409, detail="Device already registered")
            
            device.created_at = datetime.now(timezone.utc).isoformat()
            device.updated_at = device.created_at
            device.status = DeviceStatus.CONNECTING
            
            self.devices[device.device_id] = device
            
            if self.redis:
                await self.redis.setex(
                    f"device:{device.device_id}",
                    self.config.device_shadow_ttl,
                    json.dumps(device.to_dict())
                )
            
            logger.info(f"Device registered: {device.device_id} ({device.name})")
            return device
    
    async def unregister_device(self, device_id):
        """Unregister a device from the system"""
        async with self._lock:
            if device_id not in self.devices:
                return False
            
            device = self.devices[device_id]
            device.status = DeviceStatus.DECOMMISSIONED
            device.is_active = False
            device.updated_at = datetime.now(timezone.utc).isoformat()
            
            if self.redis:
                await self.redis.delete(f"device:{device_id}")
                await self.redis.delete(f"device_shadow:{device_id}")
            
            del self.devices[device_id]
            logger.info(f"Device unregistered: {device_id}")
            return True
    
    async def get_device(self, device_id):
        """Get device by ID with caching"""
        if device_id in self.devices:
            return self.devices[device_id]
        
        if self.redis:
            cached = await self.redis.get(f"device:{device_id}")
            if cached:
                data = json.loads(cached)
                return Device(
                    device_id=data["device_id"],
                    name=data["name"],
                    device_type=data["device_type"],
                    protocol=DeviceProtocol(data["protocol"]),
                    status=DeviceStatus(data["status"]),
                    **{k: v for k, v in data.items() if k not in ["device_id", "name", "device_type", "protocol", "status"]}
                )
        
        return None
    
    async def update_device_status(self, device_id, status):
        """Update device status"""
        async with self._lock:
            if device_id not in self.devices:
                return False
            
            device = self.devices[device_id]
            device.status = status
            device.last_seen = datetime.now(timezone.utc).isoformat()
            device.updated_at = device.last_seen
            
            if self.redis:
                await self.redis.setex(
                    f"device:{device_id}",
                    self.config.device_shadow_ttl,
                    json.dumps(device.to_dict())
                )
            
            logger.info(f"Device {device_id} status updated to {status.value}")
            return True
    
    async def process_message(self, message):
        """Process incoming device message"""
        DEVICE_MESSAGES.labels(direction="inbound", protocol="mqtt").inc()
        
        if message.device_id not in self.devices:
            DEVICE_ERRORS.labels(error_type="unknown_device").inc()
            logger.warning(f"Message from unknown device: {message.device_id}")
            return False
        
        device = self.devices[message.device_id]
        device.last_seen = datetime.now(timezone.utc).isoformat()
        device.updated_at = device.last_seen
        
        if message.message_type == "heartbeat":
            await self.update_device_status(message.device_id, DeviceStatus.ONLINE)
        elif message.message_type == "sensor_reading":
            await self.sensor_readings.put(message.payload)
        elif message.message_type == "alert":
            logger.warning(f"Alert from {message.device_id}: {message.payload}")
        
        logger.info(f"Message processed from {message.device_id}: {message.message_type}")
        return True
    
    async def send_command(self, device_id, command_type, parameters=None):
        """Send command to device"""
        if device_id not in self.devices:
            raise HTTPException(status_code=404, detail="Device not found")
        
        device = self.devices[device_id]
        if device.status != DeviceStatus.ONLINE:
            raise HTTPException(status_code=400, detail="Device is not online")
        
        command = {
            "command_id": str(uuid.uuid4()),
            "device_id": device_id,
            "command_type": command_type,
            "parameters": parameters or {},
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "timeout": 30
        }
        
        await self.commands.put(command)
        DEVICE_MESSAGES.labels(direction="outbound", protocol=device.protocol.value).inc()
        
        logger.info(f"Command sent to {device_id}: {command_type}")
        return command
    
    def get_all_devices(self):
        """Get all registered devices"""
        return list(self.devices.values())
    
    def get_devices_by_status(self, status):
        """Get devices filtered by status"""
        return [d for d in self.devices.values() if d.status == status]
    
    def get_devices_by_type(self, device_type):
        """Get devices filtered by type"""
        return [d for d in self.devices.values() if d.device_type == device_type]
    
    def get_device_count(self):
        """Get total device count"""
        return len(self.devices)
    
    def get_online_device_count(self):
        """Get online device count"""
        return len([d for d in self.devices.values() if d.status == DeviceStatus.ONLINE])
    
    def get_offline_device_count(self):
        """Get offline device count"""
        return len([d for d in self.devices.values() if d.status == DeviceStatus.OFFLINE])
    
    def get_health_score_average(self):
        """Get average health score across all devices"""
        if not self.devices:
            return 0.0
        return sum(d.health_score for d in self.devices.values()) / len(self.devices)
    
    async def health_check(self):
        """Perform health check on all devices"""
        for device in self.devices.values():
            if device.status == DeviceStatus.ONLINE:
                last_seen = datetime.fromisoformat(device.last_seen) if device.last_seen else None
                if last_seen:
                    elapsed = (datetime.now(timezone.utc) - last_seen).total_seconds()
                    if elapsed > self.config.heartbeat_interval * 3:
                        await self.update_device_status(device.device_id, DeviceStatus.OFFLINE)
                        logger.warning(f"Device {device.device_id} marked offline - no heartbeat")
        
        return {
            "total_devices": self.get_device_count(),
            "online_devices": self.get_online_device_count(),
            "offline_devices": self.get_offline_device_count(),
            "average_health": self.get_health_score_average()
        }
