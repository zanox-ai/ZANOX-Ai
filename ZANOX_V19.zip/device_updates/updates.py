"""
ZANOX V19 - Device Updates
Over-the-air (OTA) update management.
"""
import asyncio
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone
from enum import Enum

logger = logging.getLogger(__name__)

class UpdateStatus(Enum):
    PENDING = "pending"
    DOWNLOADING = "downloading"
    DOWNLOADED = "downloaded"
    INSTALLING = "installing"
    INSTALLED = "installed"
    FAILED = "failed"
    ROLLED_BACK = "rolled_back"

class DeviceUpdates:
    """OTA update management service"""

    def __init__(self, firmware=None, engine=None):
        self.firmware = firmware
        self.engine = engine
        self._update_queue = []
        self._update_history = []
        self._lock = asyncio.Lock()

    async def queue_update(self, device_id: str, firmware_id: str, 
                          scheduled_at: Optional[str] = None) -> str:
        """Queue OTA update for device"""
        update_id = f"upd_{device_id}_{firmware_id}_{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}"

        update = {
            "id": update_id,
            "device_id": device_id,
            "firmware_id": firmware_id,
            "status": UpdateStatus.PENDING.value,
            "queued_at": datetime.now(timezone.utc).isoformat(),
            "scheduled_at": scheduled_at,
            "started_at": None,
            "completed_at": None,
            "error": None
        }

        async with self._lock:
            self._update_queue.append(update)

        logger.info(f"Update queued: {update_id}")
        return update_id

    async def start_update(self, update_id: str) -> bool:
        """Start OTA update"""
        async with self._lock:
            update = next((u for u in self._update_queue if u["id"] == update_id), None)
            if not update:
                return False

            update["status"] = UpdateStatus.DOWNLOADING.value
            update["started_at"] = datetime.now(timezone.utc).isoformat()

        if self.engine:
            try:
                await self.engine.send_command(
                    update["device_id"],
                    "ota_update",
                    {"firmware_id": update["firmware_id"]}
                )
            except Exception as e:
                async with self._lock:
                    update["status"] = UpdateStatus.FAILED.value
                    update["error"] = str(e)
                return False

        logger.info(f"Update started: {update_id}")
        return True

    async def confirm_update(self, update_id: str, success: bool, error: Optional[str] = None) -> bool:
        """Confirm update completion"""
        async with self._lock:
            update = next((u for u in self._update_queue if u["id"] == update_id), None)
            if not update:
                return False

            update["completed_at"] = datetime.now(timezone.utc).isoformat()

            if success:
                update["status"] = UpdateStatus.INSTALLED.value
                logger.info(f"Update completed: {update_id}")
            else:
                update["status"] = UpdateStatus.FAILED.value
                update["error"] = error or "Unknown error"
                logger.error(f"Update failed: {update_id} - {error}")

            self._update_history.append(update)
            self._update_queue = [u for u in self._update_queue if u["id"] != update_id]

        return True

    async def get_update_status(self, update_id: str) -> Optional[Dict[str, Any]]:
        """Get update status"""
        async with self._lock:
            update = next((u for u in self._update_queue if u["id"] == update_id), None)
            if not update:
                update = next((u for u in self._update_history if u["id"] == update_id), None)
            return update

    async def get_pending_updates(self) -> List[Dict[str, Any]]:
        """Get all pending updates"""
        async with self._lock:
            return [u for u in self._update_queue if u["status"] == UpdateStatus.PENDING.value]

    async def get_update_history(self, device_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get update history"""
        async with self._lock:
            if device_id:
                return [u for u in self._update_history if u["device_id"] == device_id]
            return list(self._update_history)

    async def cancel_update(self, update_id: str) -> bool:
        """Cancel pending update"""
        async with self._lock:
            update = next((u for u in self._update_queue if u["id"] == update_id), None)
            if not update:
                return False

            if update["status"] not in [UpdateStatus.PENDING.value, UpdateStatus.DOWNLOADING.value]:
                return False

            self._update_queue = [u for u in self._update_queue if u["id"] != update_id]
            logger.info(f"Update cancelled: {update_id}")
            return True

    async def process_update_queue(self):
        """Process pending updates"""
        pending = await self.get_pending_updates()
        for update in pending:
            await self.start_update(update["id"])
            await asyncio.sleep(1)  # Rate limiting
