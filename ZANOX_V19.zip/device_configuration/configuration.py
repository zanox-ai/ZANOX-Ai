"""
ZANOX V19 - Device Configuration
Dynamic device configuration management.
"""
import asyncio
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone
import json

logger = logging.getLogger(__name__)

class DeviceConfiguration:
    """Device configuration management"""

    def __init__(self, registry=None, engine=None):
        self.registry = registry
        self.engine = engine
        self._config_templates = {}
        self._lock = asyncio.Lock()

    async def get_config(self, device_id: str) -> Optional[Dict[str, Any]]:
        """Get device configuration"""
        if self.registry:
            device = await self.registry.get(device_id)
            if device:
                return device.get("config", {})
        return None

    async def set_config(self, device_id: str, config: Dict[str, Any]) -> bool:
        """Set device configuration"""
        async with self._lock:
            if self.registry:
                device = await self.registry.get(device_id)
                if not device:
                    return False

                device["config"] = config
                device["config_updated_at"] = datetime.now(timezone.utc).isoformat()
                await self.registry.update(device_id, device)

            if self.engine:
                await self.engine.send_command(device_id, "apply_config", config)

            logger.info(f"Configuration updated for {device_id}")
            return True

    async def update_config(self, device_id: str, partial_config: Dict[str, Any]) -> bool:
        """Partial configuration update"""
        current = await self.get_config(device_id) or {}
        current.update(partial_config)
        return await self.set_config(device_id, current)

    async def create_template(self, name: str, config: Dict[str, Any]) -> str:
        """Create configuration template"""
        template_id = f"tpl_{name}_{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}"
        self._config_templates[template_id] = {
            "id": template_id,
            "name": name,
            "config": config,
            "created_at": datetime.now(timezone.utc).isoformat()
        }
        return template_id

    async def apply_template(self, device_id: str, template_id: str) -> bool:
        """Apply configuration template to device"""
        template = self._config_templates.get(template_id)
        if not template:
            return False
        return await self.set_config(device_id, template["config"])

    async def reset_config(self, device_id: str) -> bool:
        """Reset to default configuration"""
        return await self.set_config(device_id, {})

    async def validate_config(self, device_id: str, config: Dict[str, Any]) -> Dict[str, Any]:
        """Validate configuration for device"""
        errors = []
        warnings = []

        # Basic validation
        if not isinstance(config, dict):
            errors.append("Config must be a dictionary")

        return {
            "valid": len(errors) == 0,
            "errors": errors,
            "warnings": warnings
        }

    async def get_config_history(self, device_id: str) -> List[Dict[str, Any]]:
        """Get configuration change history"""
        # Would be implemented with proper history tracking
        return []
