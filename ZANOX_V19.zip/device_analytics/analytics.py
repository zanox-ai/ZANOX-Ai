"""
ZANOX V19 - Device Analytics
Analytics and insights for IoT devices.
"""
import asyncio
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone, timedelta
from collections import defaultdict
import statistics

logger = logging.getLogger(__name__)

class DeviceAnalytics:
    """Device analytics and reporting engine"""

    def __init__(self, registry=None, monitoring=None):
        self.registry = registry
        self.monitoring = monitoring
        self._data_points = defaultdict(list)
        self._lock = asyncio.Lock()

    async def record_metric(self, device_id: str, metric_name: str, value: float, timestamp: Optional[str] = None):
        """Record a metric data point"""
        ts = timestamp or datetime.now(timezone.utc).isoformat()
        async with self._lock:
            self._data_points[f"{device_id}:{metric_name}"].append({
                "value": value,
                "timestamp": ts
            })

    async def get_average(self, device_id: str, metric_name: str, hours: int = 24) -> Optional[float]:
        """Get average metric value over time period"""
        key = f"{device_id}:{metric_name}"
        cutoff = datetime.now(timezone.utc) - timedelta(hours=hours)

        async with self._lock:
            points = self._data_points.get(key, [])
            recent = [p["value"] for p in points if datetime.fromisoformat(p["timestamp"]) > cutoff]

            if recent:
                return statistics.mean(recent)
        return None

    async def get_statistics(self, device_id: str, metric_name: str, hours: int = 24) -> Dict[str, Any]:
        """Get statistical analysis of metric"""
        key = f"{device_id}:{metric_name}"
        cutoff = datetime.now(timezone.utc) - timedelta(hours=hours)

        async with self._lock:
            points = self._data_points.get(key, [])
            recent = [p["value"] for p in points if datetime.fromisoformat(p["timestamp"]) > cutoff]

            if not recent:
                return {"count": 0}

            return {
                "count": len(recent),
                "mean": statistics.mean(recent),
                "median": statistics.median(recent),
                "stdev": statistics.stdev(recent) if len(recent) > 1 else 0,
                "min": min(recent),
                "max": max(recent)
            }

    async def get_device_summary(self, device_id: str) -> Dict[str, Any]:
        """Get comprehensive device analytics summary"""
        summary = {
            "device_id": device_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "metrics": {}
        }

        # Get all metrics for device
        async with self._lock:
            for key, points in self._data_points.items():
                if key.startswith(f"{device_id}:"):
                    metric_name = key.split(":", 1)[1]
                    if points:
                        summary["metrics"][metric_name] = {
                            "latest": points[-1]["value"],
                            "latest_time": points[-1]["timestamp"],
                            "count": len(points)
                        }

        return summary

    async def get_fleet_summary(self, device_type: Optional[str] = None) -> Dict[str, Any]:
        """Get fleet-wide analytics summary"""
        if not self.registry:
            return {}

        devices = await self.registry.list_all(limit=10000)

        if device_type:
            devices = [d for d in devices if d.get("device_type") == device_type]

        total = len(devices)
        online = len([d for d in devices if d.get("status") == "online"])
        offline = len([d for d in devices if d.get("status") == "offline"])

        return {
            "total_devices": total,
            "online": online,
            "offline": offline,
            "online_percentage": (online / total * 100) if total > 0 else 0,
            "device_types": self._count_by_field(devices, "device_type"),
            "protocols": self._count_by_field(devices, "protocol")
        }

    def _count_by_field(self, devices: List[Dict], field: str) -> Dict[str, int]:
        """Count devices by field value"""
        counts = defaultdict(int)
        for d in devices:
            counts[d.get(field, "unknown")] += 1
        return dict(counts)

    async def generate_report(self, device_id: Optional[str] = None, hours: int = 24) -> Dict[str, Any]:
        """Generate analytics report"""
        report = {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "period_hours": hours,
            "fleet_summary": await self.get_fleet_summary()
        }

        if device_id:
            report["device_summary"] = await self.get_device_summary(device_id)

        return report

    async def cleanup_old_data(self, days: int = 30):
        """Clean up data points older than specified days"""
        cutoff = datetime.now(timezone.utc) - timedelta(days=days)

        async with self._lock:
            for key in list(self._data_points.keys()):
                self._data_points[key] = [
                    p for p in self._data_points[key]
                    if datetime.fromisoformat(p["timestamp"]) > cutoff
                ]

        logger.info(f"Analytics data cleaned up (older than {days} days)")
