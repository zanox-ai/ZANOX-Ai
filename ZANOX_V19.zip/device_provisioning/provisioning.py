"""
ZANOX V19 - Device Provisioning
Automated device provisioning and onboarding.
"""
import asyncio
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone
import uuid
import json

logger = logging.getLogger(__name__)

class DeviceProvisioning:
    """Automated device provisioning service"""

    def __init__(self, registry=None, manager=None):
        self.registry = registry
        self.manager = manager
        self._templates = {}
        self._lock = asyncio.Lock()

    async def create_template(self, template_name: str, template_config: Dict[str, Any]) -> str:
        """Create device provisioning template"""
        template_id = str(uuid.uuid4())
        self._templates[template_id] = {
            "id": template_id,
            "name": template_name,
            "config": template_config,
            "created_at": datetime.now(timezone.utc).isoformat()
        }
        logger.info(f"Provisioning template created: {template_name}")
        return template_id

    async def provision_from_template(self, template_id: str, device_info: Dict[str, Any]) -> Dict[str, Any]:
        """Provision device using template"""
        template = self._templates.get(template_id)
        if not template:
            raise ValueError(f"Template {template_id} not found")

        device_config = template["config"].copy()
        device_config.update(device_info)
        device_config["device_id"] = device_info.get("device_id") or str(uuid.uuid4())
        device_config["provisioned_from"] = template_id
        device_config["provisioned_at"] = datetime.now(timezone.utc).isoformat()
        device_config["status"] = "provisioning"

        if self.registry:
            await self.registry.register(device_config)

        logger.info(f"Device provisioned from template: {device_config['device_id']}")
        return device_config

    async def bulk_provision(self, template_id: str, devices: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Bulk provision multiple devices"""
        results = []
        for device_info in devices:
            try:
                result = await self.provision_from_template(template_id, device_info)
                results.append({"success": True, "device": result})
            except Exception as e:
                results.append({"success": False, "error": str(e)})
        return results

    async def get_template(self, template_id: str) -> Optional[Dict[str, Any]]:
        """Get provisioning template"""
        return self._templates.get(template_id)

    async def list_templates(self) -> List[Dict[str, Any]]:
        """List all provisioning templates"""
        return list(self._templates.values())

    async def delete_template(self, template_id: str) -> bool:
        """Delete provisioning template"""
        if template_id in self._templates:
            del self._templates[template_id]
            return True
        return False

    async def onboard_device(self, device_id: str, credentials: Dict[str, Any]) -> bool:
        """Complete device onboarding"""
        if self.registry:
            device = await self.registry.get(device_id)
            if not device:
                return False

            device["status"] = "online"
            device["onboarded_at"] = datetime.now(timezone.utc).isoformat()
            device["credentials"] = credentials
            await self.registry.update(device_id, device)

        logger.info(f"Device onboarded: {device_id}")
        return True
