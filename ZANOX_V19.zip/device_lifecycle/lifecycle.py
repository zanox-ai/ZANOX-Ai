"""
ZANOX V19 - Device Lifecycle
Manages complete device lifecycle from provisioning to decommissioning.
"""
import asyncio
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone, timedelta
from enum import Enum

logger = logging.getLogger(__name__)

class LifecycleState(Enum):
    CREATED = "created"
    PROVISIONING = "provisioning"
    PROVISIONED = "provisioned"
    ACTIVATING = "activating"
    ACTIVE = "active"
    UPDATING = "updating"
    MAINTENANCE = "maintenance"
    SUSPENDED = "suspended"
    DECOMMISSIONING = "decommissioning"
    DECOMMISSIONED = "decommissioned"
    ARCHIVED = "archived"

class DeviceLifecycle:
    """Device lifecycle state machine"""

    def __init__(self, registry=None):
        self.registry = registry
        self._state_history = {}
        self._lock = asyncio.Lock()

    async def transition(self, device_id: str, from_state: LifecycleState, to_state: LifecycleState, reason: str = "") -> bool:
        """Execute lifecycle state transition"""
        async with self._lock:
            if self.registry:
                device = await self.registry.get(device_id)
                if not device:
                    return False

                current_state = LifecycleState(device.get("lifecycle_state", "created"))
                if current_state != from_state:
                    logger.warning(f"Lifecycle transition mismatch: {current_state} != {from_state}")
                    return False

                device["lifecycle_state"] = to_state.value
                device["lifecycle_updated_at"] = datetime.now(timezone.utc).isoformat()
                device["lifecycle_reason"] = reason

                await self.registry.update(device_id, device)

            # Record state history
            if device_id not in self._state_history:
                self._state_history[device_id] = []

            self._state_history[device_id].append({
                "from": from_state.value,
                "to": to_state.value,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "reason": reason
            })

            logger.info(f"Device {device_id} transitioned: {from_state.value} -> {to_state.value}")
            return True

    async def get_state(self, device_id: str) -> Optional[LifecycleState]:
        """Get current lifecycle state"""
        if self.registry:
            device = await self.registry.get(device_id)
            if device:
                return LifecycleState(device.get("lifecycle_state", "created"))
        return None

    async def get_history(self, device_id: str) -> List[Dict[str, Any]]:
        """Get lifecycle state history"""
        return self._state_history.get(device_id, [])

    async def can_transition(self, device_id: str, to_state: LifecycleState) -> bool:
        """Check if transition is allowed"""
        current = await self.get_state(device_id)
        if not current:
            return False

        # Define allowed transitions
        allowed = {
            LifecycleState.CREATED: [LifecycleState.PROVISIONING],
            LifecycleState.PROVISIONING: [LifecycleState.PROVISIONED, LifecycleState.DECOMMISSIONING],
            LifecycleState.PROVISIONED: [LifecycleState.ACTIVATING, LifecycleState.DECOMMISSIONING],
            LifecycleState.ACTIVATING: [LifecycleState.ACTIVE, LifecycleState.MAINTENANCE],
            LifecycleState.ACTIVE: [LifecycleState.UPDATING, LifecycleState.MAINTENANCE, LifecycleState.SUSPENDED, LifecycleState.DECOMMISSIONING],
            LifecycleState.UPDATING: [LifecycleState.ACTIVE, LifecycleState.MAINTENANCE],
            LifecycleState.MAINTENANCE: [LifecycleState.ACTIVE, LifecycleState.DECOMMISSIONING],
            LifecycleState.SUSPENDED: [LifecycleState.ACTIVE, LifecycleState.DECOMMISSIONING],
            LifecycleState.DECOMMISSIONING: [LifecycleState.DECOMMISSIONED],
            LifecycleState.DECOMMISSIONED: [LifecycleState.ARCHIVED]
        }

        return to_state in allowed.get(current, [])

    async def auto_archive(self, days_after_decommission: int = 30):
        """Auto-archive decommissioned devices after specified days"""
        if not self.registry:
            return

        cutoff = datetime.now(timezone.utc) - timedelta(days=days_after_decommission)
        devices = await self.registry.list_all(limit=10000)

        for device in devices:
            if device.get("lifecycle_state") == "decommissioned":
                decommissioned_at = device.get("lifecycle_updated_at")
                if decommissioned_at:
                    decommissioned_date = datetime.fromisoformat(decommissioned_at)
                    if decommissioned_date < cutoff:
                        await self.transition(
                            device["device_id"],
                            LifecycleState.DECOMMISSIONED,
                            LifecycleState.ARCHIVED,
                            "Auto-archived after 30 days"
                        )
