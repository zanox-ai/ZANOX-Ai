"""ZANOX V19 - Fuel Monitoring
Fuel consumption monitoring and optimization."""
import asyncio, logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone
from collections import defaultdict
logger = logging.getLogger(__name__)

class FuelMonitoring:
    def __init__(self, engine=None):
        self.engine = engine
        self._readings = defaultdict(list)

    async def record_fuel_level(self, vehicle_id: str, level: float, capacity: float):
        self._readings[vehicle_id].append({"level": level, "capacity": capacity, "percentage": (level/capacity)*100, "timestamp": datetime.now(timezone.utc).isoformat()})
        return True

    async def get_fuel_level(self, vehicle_id: str) -> Optional[Dict[str, Any]]:
        readings = self._readings.get(vehicle_id, [])
        return readings[-1] if readings else None

    async def get_consumption_rate(self, vehicle_id: str, hours: int = 24) -> float:
        return 0.0  # Would calculate from fuel level changes

    async def check_low_fuel(self, vehicle_id: str, threshold: float = 15.0) -> bool:
        level = await self.get_fuel_level(vehicle_id)
        if not level:
            return False
        return level["percentage"] < threshold
