"""ZANOX V19 - Vehicle Diagnostics
OBD-II and vehicle diagnostics."""
import asyncio, logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone
from collections import defaultdict
logger = logging.getLogger(__name__)

class VehicleDiagnostics:
    def __init__(self, engine=None):
        self.engine = engine
        self._diagnostics = defaultdict(list)
        self._dtc_codes = defaultdict(list)

    async def record_diagnostic(self, vehicle_id: str, parameter: str, value: float, unit: str):
        self._diagnostics[vehicle_id].append({"parameter": parameter, "value": value, "unit": unit, "timestamp": datetime.now(timezone.utc).isoformat()})
        return True

    async def record_dtc(self, vehicle_id: str, code: str, severity: str = "warning"):
        self._dtc_codes[vehicle_id].append({"code": code, "severity": severity, "timestamp": datetime.now(timezone.utc).isoformat(), "status": "active"})
        logger.warning(f"DTC recorded: {vehicle_id} - {code}")
        return True

    async def get_diagnostics(self, vehicle_id: str, parameter: str = None, limit: int = 100) -> List[Dict[str, Any]]:
        data = self._diagnostics.get(vehicle_id, [])
        if parameter:
            data = [d for d in data if d["parameter"] == parameter]
        return data[-limit:]

    async def get_dtc_codes(self, vehicle_id: str, active_only: bool = True) -> List[Dict[str, Any]]:
        codes = self._dtc_codes.get(vehicle_id, [])
        if active_only:
            codes = [c for c in codes if c["status"] == "active"]
        return codes

    async def clear_dtc(self, vehicle_id: str, code: str) -> bool:
        for c in self._dtc_codes.get(vehicle_id, []):
            if c["code"] == code:
                c["status"] = "cleared"
                c["cleared_at"] = datetime.now(timezone.utc).isoformat()
        return True

    async def get_health_report(self, vehicle_id: str) -> Dict[str, Any]:
        dtcs = await self.get_dtc_codes(vehicle_id)
        return {"vehicle_id": vehicle_id, "dtc_count": len(dtcs), "critical": len([c for c in dtcs if c["severity"] == "critical"]), "status": "needs_attention" if dtcs else "healthy"}
