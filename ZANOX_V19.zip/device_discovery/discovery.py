"""
ZANOX V19 - Device Discovery
Auto-discovery of IoT devices on network.
"""
import asyncio
import logging
import socket
import struct
from typing import Dict, List, Optional, Any, Set
from datetime import datetime, timezone
import json
import aiohttp

logger = logging.getLogger(__name__)

class DeviceDiscovery:
    """Network device discovery service"""

    def __init__(self, engine=None):
        self.engine = engine
        self.discovered_devices = {}
        self._scanning = False
        self._lock = asyncio.Lock()

    async def scan_network(self, subnet: str = "192.168.1.0/24", ports: List[int] = None) -> List[Dict[str, Any]]:
        """Scan network for IoT devices"""
        ports = ports or [80, 443, 1883, 5683, 502, 4840]
        results = []

        logger.info(f"DeviceDiscovery: Scanning subnet {subnet}")

        # Parse subnet
        base_ip = subnet.rsplit(".", 1)[0]

        tasks = []
        for i in range(1, 255):
            ip = f"{base_ip}.{i}"
            tasks.append(self._probe_host(ip, ports))

        responses = await asyncio.gather(*tasks, return_exceptions=True)

        for response in responses:
            if isinstance(response, dict) and response.get("found"):
                results.append(response)
                async with self._lock:
                    self.discovered_devices[response["ip"]] = response

        logger.info(f"DeviceDiscovery: Found {len(results)} devices")
        return results

    async def _probe_host(self, ip: str, ports: List[int]) -> Dict[str, Any]:
        """Probe single host for IoT services"""
        for port in ports:
            try:
                reader, writer = await asyncio.wait_for(
                    asyncio.open_connection(ip, port),
                    timeout=2.0
                )
                writer.close()
                await writer.wait_closed()

                return {
                    "found": True,
                    "ip": ip,
                    "port": port,
                    "protocol": self._detect_protocol(port),
                    "discovered_at": datetime.now(timezone.utc).isoformat()
                }
            except Exception:
                continue

        return {"found": False, "ip": ip}

    def _detect_protocol(self, port: int) -> str:
        """Detect protocol from port number"""
        protocols = {
            1883: "mqtt", 8883: "mqtts",
            80: "http", 443: "https",
            5683: "coap", 5684: "coaps",
            502: "modbus",
            4840: "opcua",
            5672: "amqp",
            22: "ssh"
        }
        return protocols.get(port, "unknown")

    async def discover_ble_devices(self, scan_duration: int = 10) -> List[Dict[str, Any]]:
        """Discover Bluetooth Low Energy devices"""
        logger.info(f"DeviceDiscovery: BLE scanning for {scan_duration}s")
        # BLE discovery implementation would use bleak library
        return []

    async def discover_zigbee_devices(self, coordinator_url: str) -> List[Dict[str, Any]]:
        """Discover Zigbee devices via coordinator"""
        logger.info(f"DeviceDiscovery: Zigbee discovery via {coordinator_url}")
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"{coordinator_url}/api/devices") as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        return data.get("devices", [])
        except Exception as e:
            logger.warning(f"Zigbee discovery failed: {e}")
        return []

    async def get_discovered_devices(self) -> Dict[str, Any]:
        """Get all discovered devices"""
        async with self._lock:
            return dict(self.discovered_devices)

    async def clear_discovered(self):
        """Clear discovery cache"""
        async with self._lock:
            self.discovered_devices.clear()
