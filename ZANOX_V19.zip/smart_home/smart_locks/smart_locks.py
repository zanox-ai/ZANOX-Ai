"""ZANOX V19 - Smart Home Locks
Smart lock control and access management."""
import asyncio, logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone
logger = logging.getLogger(__name__)

class SmartLocks:
    def __init__(self, engine=None):
        self.engine = engine
        self._locks = {}
        self._access_log = []

    async def lock(self, device_id: str):
        if self.engine:
            await self.engine.send_command(device_id, "lock")
        self._locks[device_id] = {"state": "locked", "updated_at": datetime.now(timezone.utc).isoformat()}
        return True

    async def unlock(self, device_id: str, user_id: str = ""):
        if self.engine:
            await self.engine.send_command(device_id, "unlock", {"user_id": user_id})
        self._locks[device_id] = {"state": "unlocked", "user_id": user_id, "updated_at": datetime.now(timezone.utc).isoformat()}
        self._access_log.append({"device_id": device_id, "action": "unlock", "user_id": user_id, "timestamp": datetime.now(timezone.utc).isoformat()})
        return True

    async def get_status(self, device_id: str) -> Dict[str, Any]:
        return self._locks.get(device_id, {"state": "unknown"})

    async def get_access_log(self, device_id: str, limit: int = 100) -> List[Dict[str, Any]]:
        return [entry for entry in self._access_log if entry["device_id"] == device_id][-limit:]
