"""ZANOX V19 - Temperature Sensors
Temperature monitoring and control."""
import asyncio, logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone
logger = logging.getLogger(__name__)

class TemperatureSensors:
    def __init__(self, engine=None):
        self.engine = engine
        self._readings = {}

    async def record_reading(self, device_id: str, temperature: float, unit: str = "celsius"):
        self._readings[device_id] = {"temperature": temperature, "unit": unit, "timestamp": datetime.now(timezone.utc).isoformat()}
        return True

    async def get_reading(self, device_id: str) -> Optional[Dict[str, Any]]:
        return self._readings.get(device_id)

    async def get_average(self, device_ids: List[str]) -> float:
        temps = [self._readings.get(d, {}).get("temperature", 0) for d in device_ids if d in self._readings]
        return sum(temps) / len(temps) if temps else 0.0

    async def check_threshold(self, device_id: str, min_temp: float, max_temp: float) -> bool:
        reading = await self.get_reading(device_id)
        if not reading:
            return True
        temp = reading["temperature"]
        return min_temp <= temp <= max_temp
