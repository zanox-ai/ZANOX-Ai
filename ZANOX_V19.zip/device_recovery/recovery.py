"""
ZANOX V19 - Device Recovery
Automatic device recovery and remediation.
"""
import asyncio
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone

logger = logging.getLogger(__name__)

class DeviceRecovery:
    """Automatic device recovery service"""

    def __init__(self, engine=None, health=None, manager=None):
        self.engine = engine
        self.health = health
        self.manager = manager
        self._recovery_log = []
        self._lock = asyncio.Lock()

    async def attempt_recovery(self, device_id: str) -> Dict[str, Any]:
        """Attempt to recover a failed device"""
        result = {
            "device_id": device_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "attempts": [],
            "success": False
        }

        # Attempt 1: Ping/reconnect
        result["attempts"].append({
            "step": 1,
            "action": "ping",
            "status": "attempting"
        })

        if self.engine:
            try:
                await self.engine.send_command(device_id, "ping")
                result["attempts"][0]["status"] = "success"
                result["success"] = True
                logger.info(f"DeviceRecovery: {device_id} recovered via ping")
            except Exception as e:
                result["attempts"][0]["status"] = "failed"
                result["attempts"][0]["error"] = str(e)

        # Attempt 2: Reboot if ping failed
        if not result["success"]:
            result["attempts"].append({
                "step": 2,
                "action": "reboot",
                "status": "attempting"
            })

            if self.manager:
                try:
                    await self.manager.reboot_device(device_id)
                    result["attempts"][1]["status"] = "success"
                    result["success"] = True
                    logger.info(f"DeviceRecovery: {device_id} recovered via reboot")
                except Exception as e:
                    result["attempts"][1]["status"] = "failed"
                    result["attempts"][1]["error"] = str(e)

        # Attempt 3: Factory reset if reboot failed
        if not result["success"]:
            result["attempts"].append({
                "step": 3,
                "action": "factory_reset",
                "status": "attempting"
            })

            if self.manager:
                try:
                    await self.manager.factory_reset(device_id)
                    result["attempts"][2]["status"] = "success"
                    result["success"] = True
                    logger.warning(f"DeviceRecovery: {device_id} recovered via factory reset")
                except Exception as e:
                    result["attempts"][2]["status"] = "failed"
                    result["attempts"][2]["error"] = str(e)

        async with self._lock:
            self._recovery_log.append(result)

        return result

    async def auto_recover_unhealthy(self, threshold: float = 30.0):
        """Auto-recover devices with health below threshold"""
        if not self.health:
            return

        unhealthy = await self.health.identify_unhealthy_devices(threshold)

        for device_id in unhealthy:
            logger.info(f"Auto-recovery triggered for {device_id}")
            await self.attempt_recovery(device_id)

    async def get_recovery_log(self, device_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get recovery log"""
        async with self._lock:
            if device_id:
                return [r for r in self._recovery_log if r["device_id"] == device_id]
            return list(self._recovery_log)

    async def schedule_auto_recovery(self, interval: int = 600):
        """Schedule automatic recovery checks"""
        while True:
            await self.auto_recover_unhealthy()
            await asyncio.sleep(interval)
