"""
ZANOX V19 - Device Registry
Central registry for all IoT devices.
"""
import asyncio
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone
import json
import redis.asyncio as redis
import asyncpg

logger = logging.getLogger(__name__)

class DeviceRegistry:
    """Central device registry with persistent storage"""

    def __init__(self, redis_url=None, postgres_dsn=None):
        self.redis = redis.from_url(redis_url, decode_responses=True) if redis_url else None
        self.postgres_dsn = postgres_dsn
        self.db_pool = None
        self._cache = {}
        self._lock = asyncio.Lock()

    async def initialize(self):
        if self.postgres_dsn:
            self.db_pool = await asyncpg.create_pool(self.postgres_dsn, min_size=5, max_size=20)
            logger.info("DeviceRegistry: PostgreSQL pool created")

    async def register(self, device_data: Dict[str, Any]) -> Dict[str, Any]:
        async with self._lock:
            device_id = device_data["device_id"]
            device_data["registered_at"] = datetime.now(timezone.utc).isoformat()
            device_data["updated_at"] = device_data["registered_at"]

            if self.redis:
                await self.redis.setex(f"registry:{device_id}", 3600, json.dumps(device_data))

            if self.db_pool:
                async with self.db_pool.acquire() as conn:
                    await conn.execute("""
                        INSERT INTO device_registry (device_id, name, device_type, protocol, status, metadata, registered_at, updated_at)
                        VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
                        ON CONFLICT (device_id) DO UPDATE SET
                        name = EXCLUDED.name, status = EXCLUDED.status, metadata = EXCLUDED.metadata, updated_at = EXCLUDED.updated_at
                    """, device_id, device_data.get("name"), device_data.get("device_type"),
                    device_data.get("protocol"), device_data.get("status"), 
                    json.dumps(device_data.get("metadata", {})), device_data["registered_at"], device_data["updated_at"])

            self._cache[device_id] = device_data
            logger.info(f"DeviceRegistry: Registered device {device_id}")
            return device_data

    async def get(self, device_id: str) -> Optional[Dict[str, Any]]:
        if device_id in self._cache:
            return self._cache[device_id]

        if self.redis:
            cached = await self.redis.get(f"registry:{device_id}")
            if cached:
                return json.loads(cached)

        if self.db_pool:
            async with self.db_pool.acquire() as conn:
                row = await conn.fetchrow("SELECT * FROM device_registry WHERE device_id = $1", device_id)
                if row:
                    return dict(row)

        return None

    async def update(self, device_id: str, updates: Dict[str, Any]) -> bool:
        async with self._lock:
            device = await self.get(device_id)
            if not device:
                return False

            device.update(updates)
            device["updated_at"] = datetime.now(timezone.utc).isoformat()

            if self.redis:
                await self.redis.setex(f"registry:{device_id}", 3600, json.dumps(device))

            if self.db_pool:
                async with self.db_pool.acquire() as conn:
                    await conn.execute("""
                        UPDATE device_registry SET status = $1, metadata = $2, updated_at = $3 WHERE device_id = $4
                    """, device.get("status"), json.dumps(device.get("metadata", {})), device["updated_at"], device_id)

            self._cache[device_id] = device
            return True

    async def delete(self, device_id: str) -> bool:
        async with self._lock:
            if self.redis:
                await self.redis.delete(f"registry:{device_id}")

            if self.db_pool:
                async with self.db_pool.acquire() as conn:
                    await conn.execute("DELETE FROM device_registry WHERE device_id = $1", device_id)

            self._cache.pop(device_id, None)
            logger.info(f"DeviceRegistry: Deleted device {device_id}")
            return True

    async def list_all(self, limit=100, offset=0) -> List[Dict[str, Any]]:
        if self.db_pool:
            async with self.db_pool.acquire() as conn:
                rows = await conn.fetch("SELECT * FROM device_registry LIMIT $1 OFFSET $2", limit, offset)
                return [dict(row) for row in rows]
        return list(self._cache.values())

    async def count(self) -> int:
        if self.db_pool:
            async with self.db_pool.acquire() as conn:
                row = await conn.fetchrow("SELECT COUNT(*) as count FROM device_registry")
                return row["count"]
        return len(self._cache)

    async def search_by_type(self, device_type: str) -> List[Dict[str, Any]]:
        if self.db_pool:
            async with self.db_pool.acquire() as conn:
                rows = await conn.fetch("SELECT * FROM device_registry WHERE device_type = $1", device_type)
                return [dict(row) for row in rows]
        return [d for d in self._cache.values() if d.get("device_type") == device_type]

    async def search_by_status(self, status: str) -> List[Dict[str, Any]]:
        if self.db_pool:
            async with self.db_pool.acquire() as conn:
                rows = await conn.fetch("SELECT * FROM device_registry WHERE status = $1", status)
                return [dict(row) for row in rows]
        return [d for d in self._cache.values() if d.get("status") == status]

    async def search_by_tag(self, tag: str) -> List[Dict[str, Any]]:
        if self.db_pool:
            async with self.db_pool.acquire() as conn:
                rows = await conn.fetch("SELECT * FROM device_registry WHERE metadata::jsonb @> $1", json.dumps({"tags": [tag]}))
                return [dict(row) for row in rows]
        return [d for d in self._cache.values() if tag in d.get("metadata", {}).get("tags", [])]
