"""
ZANOX V19 - Device Manager
Manages device lifecycle, configuration, and operations.
"""
import asyncio
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone
import json

logger = logging.getLogger(__name__)

class DeviceManager:
    """Device lifecycle and operations manager"""

    def __init__(self, registry=None, engine=None):
        self.registry = registry
        self.engine = engine
        self._operations = {}
        self._lock = asyncio.Lock()

    async def provision_device(self, device_config: Dict[str, Any]) -> Dict[str, Any]:
        """Provision a new device with initial configuration"""
        device_id = device_config.get("device_id") or str(uuid.uuid4())
        device_config["device_id"] = device_id
        device_config["status"] = "provisioning"
        device_config["provisioned_at"] = datetime.now(timezone.utc).isoformat()

        if self.registry:
            await self.registry.register(device_config)

        logger.info(f"DeviceManager: Provisioned device {device_id}")
        return device_config

    async def configure_device(self, device_id: str, config: Dict[str, Any]) -> bool:
        """Apply configuration to device"""
        async with self._lock:
            if self.registry:
                device = await self.registry.get(device_id)
                if not device:
                    return False

                device["config"] = config
                device["config_updated_at"] = datetime.now(timezone.utc).isoformat()
                await self.registry.update(device_id, device)

            logger.info(f"DeviceManager: Configured device {device_id}")
            return True

    async def update_firmware(self, device_id: str, firmware_version: str, firmware_url: str) -> bool:
        """Trigger firmware update on device"""
        async with self._lock:
            if self.registry:
                device = await self.registry.get(device_id)
                if not device:
                    return False

                device["firmware_update"] = {
                    "version": firmware_version,
                    "url": firmware_url,
                    "status": "pending",
                    "requested_at": datetime.now(timezone.utc).isoformat()
                }
                await self.registry.update(device_id, device)

            logger.info(f"DeviceManager: Firmware update queued for {device_id} -> {firmware_version}")
            return True

    async def reboot_device(self, device_id: str) -> bool:
        """Send reboot command to device"""
        if self.engine:
            await self.engine.send_command(device_id, "reboot")
        logger.info(f"DeviceManager: Reboot command sent to {device_id}")
        return True

    async def factory_reset(self, device_id: str) -> bool:
        """Factory reset device"""
        async with self._lock:
            if self.registry:
                device = await self.registry.get(device_id)
                if not device:
                    return False

                device["status"] = "resetting"
                device["config"] = {}
                device["reset_at"] = datetime.now(timezone.utc).isoformat()
                await self.registry.update(device_id, device)

            if self.engine:
                await self.engine.send_command(device_id, "factory_reset")

            logger.info(f"DeviceManager: Factory reset initiated for {device_id}")
            return True

    async def get_device_status(self, device_id: str) -> Optional[Dict[str, Any]]:
        """Get comprehensive device status"""
        if self.registry:
            device = await self.registry.get(device_id)
            if device:
                return {
                    "device_id": device_id,
                    "status": device.get("status"),
                    "health": device.get("health_score", 100),
                    "last_seen": device.get("last_seen"),
                    "firmware_version": device.get("firmware_version"),
                    "config_version": device.get("config_updated_at"),
                    "connected": device.get("status") == "online"
                }
        return None

    async def list_operations(self, device_id: str) -> List[Dict[str, Any]]:
        """List pending operations for device"""
        return self._operations.get(device_id, [])

    async def cancel_operation(self, device_id: str, operation_id: str) -> bool:
        """Cancel pending operation"""
        if device_id in self._operations:
            ops = self._operations[device_id]
            self._operations[device_id] = [op for op in ops if op.get("id") != operation_id]
            return True
        return False
