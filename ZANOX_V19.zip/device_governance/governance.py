"""
ZANOX V19 - Device Governance
Policy enforcement and compliance governance.
"""
import asyncio
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone

logger = logging.getLogger(__name__)

class DeviceGovernance:
    """Device governance and policy enforcement"""

    def __init__(self, registry=None, security=None):
        self.registry = registry
        self.security = security
        self._policies = {}
        self._compliance_reports = []
        self._lock = asyncio.Lock()

    async def define_policy(self, policy_name: str, rules: List[Dict[str, Any]]) -> str:
        """Define governance policy"""
        policy_id = f"pol_{policy_name}_{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}"

        self._policies[policy_id] = {
            "id": policy_id,
            "name": policy_name,
            "rules": rules,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "active": True
        }

        logger.info(f"Governance policy defined: {policy_name}")
        return policy_id

    async def evaluate_compliance(self, device_id: str, policy_id: str) -> Dict[str, Any]:
        """Evaluate device compliance against policy"""
        policy = self._policies.get(policy_id)
        if not policy:
            return {"error": "Policy not found"}

        if not self.registry:
            return {"error": "No registry"}

        device = await self.registry.get(device_id)
        if not device:
            return {"error": "Device not found"}

        violations = []

        for rule in policy["rules"]:
            field = rule.get("field")
            operator = rule.get("operator")
            value = rule.get("value")

            device_value = device.get(field)

            if operator == "equals" and device_value != value:
                violations.append(f"{field} must equal {value}")
            elif operator == "not_equals" and device_value == value:
                violations.append(f"{field} must not equal {value}")
            elif operator == "exists" and not device_value:
                violations.append(f"{field} must exist")

        result = {
            "device_id": device_id,
            "policy_id": policy_id,
            "compliant": len(violations) == 0,
            "violations": violations,
            "evaluated_at": datetime.now(timezone.utc).isoformat()
        }

        async with self._lock:
            self._compliance_reports.append(result)

        return result

    async def evaluate_fleet_compliance(self, policy_id: str) -> Dict[str, Any]:
        """Evaluate fleet-wide compliance"""
        if not self.registry:
            return {"error": "No registry"}

        devices = await self.registry.list_all(limit=10000)
        results = []

        for device in devices:
            result = await self.evaluate_compliance(device["device_id"], policy_id)
            results.append(result)

        compliant = len([r for r in results if r.get("compliant")])
        total = len(results)

        return {
            "policy_id": policy_id,
            "total_devices": total,
            "compliant_devices": compliant,
            "compliance_rate": (compliant / total * 100) if total > 0 else 0,
            "results": results
        }

    async def get_policies(self) -> List[Dict[str, Any]]:
        """Get all governance policies"""
        return list(self._policies.values())

    async def get_policy(self, policy_id: str) -> Optional[Dict[str, Any]]:
        """Get specific policy"""
        return self._policies.get(policy_id)

    async def deactivate_policy(self, policy_id: str) -> bool:
        """Deactivate policy"""
        if policy_id in self._policies:
            self._policies[policy_id]["active"] = False
            return True
        return False

    async def get_compliance_history(self, device_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get compliance history"""
        async with self._lock:
            if device_id:
                return [r for r in self._compliance_reports if r["device_id"] == device_id]
            return list(self._compliance_reports)
