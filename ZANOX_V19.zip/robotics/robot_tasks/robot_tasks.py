"""ZANOX V19 - Robot Tasks
Task scheduling and management for robots."""
import asyncio, logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone
from collections import defaultdict
logger = logging.getLogger(__name__)

class RobotTasks:
    def __init__(self, engine=None):
        self.engine = engine
        self._tasks = defaultdict(list)
        self._task_queue = asyncio.Queue()

    async def create_task(self, robot_id: str, task_type: str, parameters: Dict[str, Any], priority: int = 0) -> str:
        task_id = f"task_{robot_id}_{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}"
        task = {"id": task_id, "robot_id": robot_id, "type": task_type, "parameters": parameters, "priority": priority, "status": "pending", "created_at": datetime.now(timezone.utc).isoformat()}
        self._tasks[robot_id].append(task)
        await self._task_queue.put(task)
        return task_id

    async def start_task(self, task_id: str) -> bool:
        for tasks in self._tasks.values():
            for task in tasks:
                if task["id"] == task_id:
                    task["status"] = "running"
                    task["started_at"] = datetime.now(timezone.utc).isoformat()
                    if self.engine:
                        await self.engine.send_command(task["robot_id"], "execute_task", task["parameters"])
                    return True
        return False

    async def complete_task(self, task_id: str, result: Dict[str, Any] = None) -> bool:
        for tasks in self._tasks.values():
            for task in tasks:
                if task["id"] == task_id:
                    task["status"] = "completed"
                    task["completed_at"] = datetime.now(timezone.utc).isoformat()
                    task["result"] = result
                    return True
        return False

    async def get_tasks(self, robot_id: str, status: str = None) -> List[Dict[str, Any]]:
        tasks = self._tasks.get(robot_id, [])
        if status:
            tasks = [t for t in tasks if t["status"] == status]
        return tasks
