"""ZANOX V19 - Robot Registry
Robot registration and metadata management."""
import asyncio, logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone
logger = logging.getLogger(__name__)

class RobotRegistry:
    def __init__(self, engine=None):
        self.engine = engine
        self._robots = {}

    async def register_robot(self, robot_id: str, name: str, robot_type: str, manufacturer: str, model: str, capabilities: List[str] = None):
        self._robots[robot_id] = {"name": name, "type": robot_type, "manufacturer": manufacturer, "model": model, "capabilities": capabilities or [], "status": "idle", "registered_at": datetime.now(timezone.utc).isoformat()}
        return True

    async def get_robot(self, robot_id: str) -> Optional[Dict[str, Any]]:
        return self._robots.get(robot_id)

    async def update_status(self, robot_id: str, status: str, location: Dict = None):
        if robot_id in self._robots:
            self._robots[robot_id]["status"] = status
            if location:
                self._robots[robot_id]["location"] = location
            self._robots[robot_id]["updated_at"] = datetime.now(timezone.utc).isoformat()
        return True

    async def list_robots(self, robot_type: str = None) -> List[Dict[str, Any]]:
        robots = list(self._robots.values())
        if robot_type:
            robots = [r for r in robots if r["type"] == robot_type]
        return robots
