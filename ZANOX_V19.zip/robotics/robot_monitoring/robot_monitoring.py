"""ZANOX V19 - Robot Monitoring
Robot health and performance monitoring."""
import asyncio, logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone
from collections import defaultdict
logger = logging.getLogger(__name__)

class RobotMonitoring:
    def __init__(self, engine=None):
        self.engine = engine
        self._telemetry = defaultdict(list)

    async def record_telemetry(self, robot_id: str, battery: float = None, motor_temp: float = None, cpu_usage: float = None, memory_usage: float = None):
        self._telemetry[robot_id].append({"battery": battery, "motor_temp": motor_temp, "cpu_usage": cpu_usage, "memory_usage": memory_usage, "timestamp": datetime.now(timezone.utc).isoformat()})
        return True

    async def get_telemetry(self, robot_id: str, limit: int = 100) -> List[Dict[str, Any]]:
        return self._telemetry.get(robot_id, [])[-limit:]

    async def get_health_status(self, robot_id: str) -> Dict[str, Any]:
        telemetry = await self.get_telemetry(robot_id, 10)
        if not telemetry:
            return {"status": "unknown"}

        latest = telemetry[-1]
        issues = []

        if latest.get("battery", 100) < 20:
            issues.append("Low battery")
        if latest.get("motor_temp", 0) > 80:
            issues.append("Motor overheating")
        if latest.get("cpu_usage", 0) > 90:
            issues.append("High CPU usage")

        return {"status": "healthy" if not issues else "warning", "issues": issues, "latest": latest}
