"""
ZANOX V20 - Configuration
Enterprise OS + Infinite Expansion Framework
"""
import os
from typing import Dict, List


class ZANOXConfig:
    POSTGRES_URL = os.getenv("ZANOX_POSTGRES_URL", "postgresql://zanox:zanox@localhost:5432/zanox_enterprise")
    REDIS_URL = os.getenv("ZANOX_REDIS_URL", "redis://localhost:6379/0")
    NEO4J_URL = os.getenv("ZANOX_NEO4J_URL", "bolt://localhost:7687")
    NEO4J_USER = os.getenv("ZANOX_NEO4J_USER", "neo4j")
    NEO4J_PASSWORD = os.getenv("ZANOX_NEO4J_PASSWORD", "zanox")
    ELASTICSEARCH_URL = os.getenv("ZANOX_ES_URL", "http://localhost:9200")
    KAFKA_BOOTSTRAP = os.getenv("ZANOX_KAFKA", "localhost:9092")

    SECRET_KEY = os.getenv("ZANOX_SECRET_KEY", "zanox-v20-enterprise-secret-key-change-in-production")
    JWT_ALGORITHM = "HS256"
    JWT_EXPIRATION_HOURS = 24

    MAX_CONCURRENT_AGENTS = int(os.getenv("MAX_AGENTS", "50"))
    AGENT_TIMEOUT = int(os.getenv("AGENT_TIMEOUT", "300"))

    PLUGIN_DIR = os.getenv("ZANOX_PLUGIN_DIR", "/app/plugins")
    MODULE_REGISTRY_TTL = 86400
    CAPABILITY_REGISTRY_TTL = 86400

    RATE_LIMITS: Dict[str, Dict[str, int]] = {
        "api": {"max": 1000, "window": 60},
        "auth": {"max": 10, "window": 60},
        "plugin": {"max": 50, "window": 60},
    }

    TRUSTED_DOMAINS: List[str] = [
        ".edu", ".gov", "reuters.com", "bloomberg.com", "ft.com",
        "nature.com", "science.org", "arxiv.org", "ieee.org", "acm.org"
    ]

    ALERT_WEBHOOK = os.getenv("ALERT_WEBHOOK", "")
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")

    @classmethod
    def get_kafka_topics(cls) -> List[str]:
        return [
            "enterprise.events", "agent.events", "plugin.events",
            "workflow.events", "audit.events", "security.events",
            "hr.events", "compliance.events", "expansion.events"
        ]
