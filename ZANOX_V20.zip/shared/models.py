"""
ZANOX V20 - Shared Models
Enterprise OS + Infinite Expansion Framework
"""
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Union
from pydantic import BaseModel, Field
from uuid import uuid4


class EntityStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"
    SUSPENDED = "suspended"
    ARCHIVED = "archived"
    DELETED = "deleted"


class Priority(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class BaseZANOXModel(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid4()))
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    version: str = "V20"
    status: EntityStatus = EntityStatus.ACTIVE
    metadata: Dict[str, Any] = Field(default_factory=dict)

    class Config:
        json_encoders = {datetime: lambda v: v.isoformat()}


class Organization(BaseZANOXModel):
    name: str
    legal_name: Optional[str] = None
    tax_id: Optional[str] = None
    industry: Optional[str] = None
    size: Optional[str] = None
    website: Optional[str] = None
    address: Optional[str] = None
    country: Optional[str] = None
    timezone: str = "UTC"
    currency: str = "USD"
    parent_id: Optional[str] = None
    settings: Dict[str, Any] = Field(default_factory=dict)


class Company(BaseZANOXModel):
    organization_id: str
    name: str
    legal_name: Optional[str] = None
    registration_number: Optional[str] = None
    industry: Optional[str] = None
    address: Optional[str] = None
    country: Optional[str] = None
    timezone: str = "UTC"
    currency: str = "USD"
    parent_id: Optional[str] = None


class Department(BaseZANOXModel):
    company_id: str
    name: str
    description: Optional[str] = None
    manager_id: Optional[str] = None
    parent_id: Optional[str] = None
    budget: Optional[float] = None
    headcount: int = 0


class Team(BaseZANOXModel):
    department_id: str
    name: str
    description: Optional[str] = None
    lead_id: Optional[str] = None
    members: List[str] = Field(default_factory=list)
    projects: List[str] = Field(default_factory=list)


class Employee(BaseZANOXModel):
    company_id: str
    department_id: Optional[str] = None
    team_id: Optional[str] = None
    user_id: str
    employee_number: Optional[str] = None
    job_title: str
    job_level: Optional[str] = None
    employment_type: str = "full_time"
    hire_date: Optional[datetime] = None
    termination_date: Optional[datetime] = None
    salary: Optional[float] = None
    currency: str = "USD"
    manager_id: Optional[str] = None
    skills: List[str] = Field(default_factory=list)
    certifications: List[str] = Field(default_factory=list)
    contact_info: Dict[str, Any] = Field(default_factory=dict)


class Role(BaseZANOXModel):
    name: str
    description: Optional[str] = None
    permissions: List[str] = Field(default_factory=list)
    scope: str = "organization"
    is_system: bool = False


class Permission(BaseZANOXModel):
    resource: str
    action: str
    description: Optional[str] = None
    scope: str = "organization"
    conditions: Optional[Dict[str, Any]] = None


class Identity(BaseZANOXModel):
    user_id: str
    provider: str
    provider_id: str
    email: str
    phone: Optional[str] = None
    password_hash: Optional[str] = None
    mfa_enabled: bool = False
    mfa_secret: Optional[str] = None
    last_login: Optional[datetime] = None
    login_attempts: int = 0
    locked_until: Optional[datetime] = None


class SSOConfig(BaseZANOXModel):
    organization_id: str
    provider: str
    client_id: str
    client_secret: Optional[str] = None
    redirect_uri: str
    authorization_url: Optional[str] = None
    token_url: Optional[str] = None
    user_info_url: Optional[str] = None
    scopes: List[str] = Field(default_factory=list)
    enabled: bool = True


class AccessPolicy(BaseZANOXModel):
    name: str
    description: Optional[str] = None
    resource_type: str
    resource_id: Optional[str] = None
    actions: List[str] = Field(default_factory=list)
    conditions: Dict[str, Any] = Field(default_factory=dict)
    effect: str = "allow"
    priority: int = 100


class HRRecord(BaseZANOXModel):
    employee_id: str
    record_type: str
    category: str
    data: Dict[str, Any] = Field(default_factory=dict)
    effective_date: Optional[datetime] = None
    expiry_date: Optional[datetime] = None


class Recruitment(BaseZANOXModel):
    company_id: str
    department_id: Optional[str] = None
    team_id: Optional[str] = None
    position_title: str
    description: str
    requirements: List[str] = Field(default_factory=list)
    salary_range_min: Optional[float] = None
    salary_range_max: Optional[float] = None
    currency: str = "USD"
    location: Optional[str] = None
    employment_type: str = "full_time"
    status: str = "open"
    applicants: List[str] = Field(default_factory=list)
    hired_employee_id: Optional[str] = None


class Onboarding(BaseZANOXModel):
    employee_id: str
    template_id: Optional[str] = None
    tasks: List[Dict[str, Any]] = Field(default_factory=list)
    progress: float = 0.0
    start_date: Optional[datetime] = None
    completion_date: Optional[datetime] = None
    assigned_to: Optional[str] = None


class Payroll(BaseZANOXModel):
    employee_id: str
    period_start: datetime
    period_end: datetime
    base_salary: float
    bonuses: float = 0.0
    deductions: float = 0.0
    taxes: float = 0.0
    net_pay: float = 0.0
    currency: str = "USD"
    status: str = "draft"
    approved_by: Optional[str] = None
    approved_at: Optional[datetime] = None


class PerformanceReview(BaseZANOXModel):
    employee_id: str
    reviewer_id: str
    period_start: datetime
    period_end: datetime
    goals: List[Dict[str, Any]] = Field(default_factory=list)
    achievements: List[str] = Field(default_factory=list)
    ratings: Dict[str, float] = Field(default_factory=dict)
    overall_score: Optional[float] = None
    feedback: Optional[str] = None
    status: str = "draft"


class KPI(BaseZANOXModel):
    name: str
    description: Optional[str] = None
    category: str
    target_value: float
    current_value: float = 0.0
    unit: str = "count"
    frequency: str = "monthly"
    owner_id: Optional[str] = None
    entity_type: str = "organization"
    entity_id: str


class OKR(BaseZANOXModel):
    owner_id: str
    entity_type: str = "organization"
    entity_id: str
    objective: str
    key_results: List[Dict[str, Any]] = Field(default_factory=list)
    progress: float = 0.0
    quarter: str
    year: int
    parent_id: Optional[str] = None


class Workflow(BaseZANOXModel):
    name: str
    description: Optional[str] = None
    definition: Dict[str, Any] = Field(default_factory=dict)
    trigger_type: str = "manual"
    trigger_config: Dict[str, Any] = Field(default_factory=dict)
    version: int = 1
    is_active: bool = True


class Approval(BaseZANOXModel):
    workflow_id: str
    requester_id: str
    title: str
    description: Optional[str] = None
    data: Dict[str, Any] = Field(default_factory=dict)
    approvers: List[Dict[str, Any]] = Field(default_factory=list)
    current_step: int = 0
    status: str = "pending"
    approved_by: List[str] = Field(default_factory=list)
    rejected_by: Optional[str] = None
    comments: List[Dict[str, Any]] = Field(default_factory=list)


class Policy(BaseZANOXModel):
    organization_id: str
    title: str
    content: str
    category: str
    version: int = 1
    effective_date: Optional[datetime] = None
    expiry_date: Optional[datetime] = None
    acknowledged_by: List[str] = Field(default_factory=list)


class AuditLog(BaseZANOXModel):
    entity_type: str
    entity_id: str
    action: str
    actor_id: str
    actor_type: str = "user"
    changes: Dict[str, Any] = Field(default_factory=dict)
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    severity: str = "info"


class Risk(BaseZANOXModel):
    organization_id: str
    title: str
    description: Optional[str] = None
    category: str
    likelihood: int = 3
    impact: int = 3
    score: float = 0.0
    status: str = "open"
    owner_id: Optional[str] = None
    mitigation_plan: Optional[str] = None
    residual_risk: Optional[float] = None


class ComplianceRequirement(BaseZANOXModel):
    organization_id: str
    regulation: str
    requirement: str
    description: Optional[str] = None
    category: str
    priority: str = "medium"
    status: str = "pending"
    evidence: List[str] = Field(default_factory=list)
    due_date: Optional[datetime] = None
    completed_date: Optional[datetime] = None


class Contract(BaseZANOXModel):
    organization_id: str
    title: str
    parties: List[Dict[str, Any]] = Field(default_factory=list)
    content: Optional[str] = None
    value: Optional[float] = None
    currency: str = "USD"
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    status: str = "draft"
    signed_by: List[str] = Field(default_factory=list)
    signed_at: Optional[datetime] = None


class Vendor(BaseZANOXModel):
    organization_id: str
    name: str
    contact_info: Dict[str, Any] = Field(default_factory=dict)
    services: List[str] = Field(default_factory=list)
    status: str = "active"
    rating: Optional[float] = None
    contracts: List[str] = Field(default_factory=list)


class Asset(BaseZANOXModel):
    organization_id: str
    name: str
    asset_type: str
    serial_number: Optional[str] = None
    purchase_date: Optional[datetime] = None
    purchase_value: Optional[float] = None
    current_value: Optional[float] = None
    location: Optional[str] = None
    assigned_to: Optional[str] = None
    status: str = "active"


class SecurityIncident(BaseZANOXModel):
    organization_id: str
    title: str
    description: Optional[str] = None
    severity: str = "medium"
    category: str
    status: str = "open"
    detected_at: Optional[datetime] = None
    resolved_at: Optional[datetime] = None
    assigned_to: Optional[str] = None
    affected_assets: List[str] = Field(default_factory=list)
    remediation: Optional[str] = None


class BusinessContinuityPlan(BaseZANOXModel):
    organization_id: str
    name: str
    description: Optional[str] = None
    scenarios: List[Dict[str, Any]] = Field(default_factory=list)
    procedures: List[Dict[str, Any]] = Field(default_factory=list)
    rto: int = 0
    rpo: int = 0
    last_tested: Optional[datetime] = None
    test_results: Optional[str] = None


class Report(BaseZANOXModel):
    organization_id: str
    title: str
    report_type: str
    category: str
    data: Dict[str, Any] = Field(default_factory=dict)
    format: str = "json"
    generated_by: Optional[str] = None
    scheduled: bool = False
    schedule_config: Optional[Dict[str, Any]] = None


class Dashboard(BaseZANOXModel):
    organization_id: str
    name: str
    description: Optional[str] = None
    widgets: List[Dict[str, Any]] = Field(default_factory=list)
    layout: Dict[str, Any] = Field(default_factory=dict)
    is_default: bool = False
    is_shared: bool = False
    owner_id: str


class EnterpriseAgent(BaseZANOXModel):
    name: str
    description: Optional[str] = None
    agent_type: str
    team: str
    capabilities: List[str] = Field(default_factory=list)
    skills: List[str] = Field(default_factory=list)
    config: Dict[str, Any] = Field(default_factory=dict)
    runtime_id: Optional[str] = None
    last_active: Optional[datetime] = None
    total_tasks: int = 0
    success_rate: float = 0.0


class Plugin(BaseZANOXModel):
    name: str
    description: Optional[str] = None
    version: str
    author: Optional[str] = None
    entry_point: str
    dependencies: List[str] = Field(default_factory=list)
    capabilities: List[str] = Field(default_factory=list)
    config_schema: Dict[str, Any] = Field(default_factory=dict)
    installed_at: Optional[datetime] = None
    is_active: bool = False
    is_system: bool = False


class ModuleRegistration(BaseZANOXModel):
    name: str
    version: str
    description: Optional[str] = None
    module_type: str
    entry_point: str
    dependencies: List[str] = Field(default_factory=list)
    provides: List[str] = Field(default_factory=list)
    requires: List[str] = Field(default_factory=list)
    config: Dict[str, Any] = Field(default_factory=dict)
    is_active: bool = False


class CapabilityRegistration(BaseZANOXModel):
    name: str
    description: Optional[str] = None
    category: str
    provider_module: str
    provider_version: str
    interface: str
    schema: Dict[str, Any] = Field(default_factory=dict)
    is_active: bool = True


class VersionRegistration(BaseZANOXModel):
    version_number: str
    layer_name: str
    description: Optional[str] = None
    modules: List[str] = Field(default_factory=list)
    capabilities: List[str] = Field(default_factory=list)
    agents: List[str] = Field(default_factory=list)
    dependencies: List[str] = Field(default_factory=list)
    migration_path: Optional[str] = None
    is_installed: bool = False
    is_active: bool = False


class FutureLayer(BaseZANOXModel):
    version_number: str
    layer_name: str
    description: Optional[str] = None
    status: str = "planned"
    dependencies: List[str] = Field(default_factory=list)
    estimated_modules: int = 0
    plugin_id: Optional[str] = None
    generated_at: Optional[datetime] = None
