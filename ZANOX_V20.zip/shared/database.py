"""
ZANOX V20 - Database Layer
Enterprise OS + Infinite Expansion Framework
"""
import asyncpg
import redis.asyncio as redis
from neo4j import AsyncGraphDatabase
from elasticsearch import AsyncElasticsearch
from shared.config import ZANOXConfig


class DatabaseManager:
    _postgres = None
    _redis = None
    _neo4j = None
    _es = None

    @classmethod
    async def get_postgres(cls):
        if cls._postgres is None:
            cls._postgres = await asyncpg.create_pool(ZANOXConfig.POSTGRES_URL, min_size=5, max_size=20)
        return cls._postgres

    @classmethod
    async def get_redis(cls):
        if cls._redis is None:
            cls._redis = redis.from_url(ZANOXConfig.REDIS_URL, decode_responses=True)
        return cls._redis

    @classmethod
    async def get_neo4j(cls):
        if cls._neo4j is None:
            cls._neo4j = AsyncGraphDatabase.driver(
                ZANOXConfig.NEO4J_URL,
                auth=(ZANOXConfig.NEO4J_USER, ZANOXConfig.NEO4J_PASSWORD)
            )
        return cls._neo4j

    @classmethod
    async def get_elasticsearch(cls):
        if cls._es is None:
            cls._es = AsyncElasticsearch([ZANOXConfig.ELASTICSEARCH_URL])
        return cls._es

    @classmethod
    async def close_all(cls):
        if cls._postgres: await cls._postgres.close()
        if cls._redis: await cls._redis.close()
        if cls._neo4j: await cls._neo4j.close()
        if cls._es: await cls._es.close()


class PostgresSchema:
    ORGANIZATIONS_TABLE = """
    CREATE TABLE IF NOT EXISTS organizations (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        name TEXT NOT NULL,
        legal_name TEXT,
        tax_id TEXT,
        industry TEXT,
        size TEXT,
        website TEXT,
        address TEXT,
        country TEXT,
        timezone TEXT DEFAULT 'UTC',
        currency TEXT DEFAULT 'USD',
        parent_id UUID,
        settings JSONB,
        status TEXT DEFAULT 'active',
        metadata JSONB,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW(),
        version TEXT DEFAULT 'V20'
    );
    CREATE INDEX IF NOT EXISTS idx_org_status ON organizations(status);
    """

    COMPANIES_TABLE = """
    CREATE TABLE IF NOT EXISTS companies (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        organization_id UUID NOT NULL,
        name TEXT NOT NULL,
        legal_name TEXT,
        registration_number TEXT,
        industry TEXT,
        address TEXT,
        country TEXT,
        timezone TEXT DEFAULT 'UTC',
        currency TEXT DEFAULT 'USD',
        parent_id UUID,
        status TEXT DEFAULT 'active',
        metadata JSONB,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
    );
    CREATE INDEX IF NOT EXISTS idx_companies_org ON companies(organization_id);
    """

    DEPARTMENTS_TABLE = """
    CREATE TABLE IF NOT EXISTS departments (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        company_id UUID NOT NULL,
        name TEXT NOT NULL,
        description TEXT,
        manager_id UUID,
        parent_id UUID,
        budget FLOAT,
        headcount INT DEFAULT 0,
        status TEXT DEFAULT 'active',
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
    );
    CREATE INDEX IF NOT EXISTS idx_dept_company ON departments(company_id);
    """

    TEAMS_TABLE = """
    CREATE TABLE IF NOT EXISTS teams (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        department_id UUID NOT NULL,
        name TEXT NOT NULL,
        description TEXT,
        lead_id UUID,
        members UUID[],
        projects UUID[],
        status TEXT DEFAULT 'active',
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
    );
    """

    EMPLOYEES_TABLE = """
    CREATE TABLE IF NOT EXISTS employees (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        company_id UUID NOT NULL,
        department_id UUID,
        team_id UUID,
        user_id UUID NOT NULL,
        employee_number TEXT,
        job_title TEXT NOT NULL,
        job_level TEXT,
        employment_type TEXT DEFAULT 'full_time',
        hire_date TIMESTAMP,
        termination_date TIMESTAMP,
        salary FLOAT,
        currency TEXT DEFAULT 'USD',
        manager_id UUID,
        skills TEXT[],
        certifications TEXT[],
        contact_info JSONB,
        status TEXT DEFAULT 'active',
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
    );
    CREATE INDEX IF NOT EXISTS idx_employees_company ON employees(company_id);
    CREATE INDEX IF NOT EXISTS idx_employees_user ON employees(user_id);
    """

    ROLES_TABLE = """
    CREATE TABLE IF NOT EXISTS roles (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        name TEXT NOT NULL,
        description TEXT,
        permissions TEXT[],
        scope TEXT DEFAULT 'organization',
        is_system BOOLEAN DEFAULT FALSE,
        status TEXT DEFAULT 'active',
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
    );
    """

    PERMISSIONS_TABLE = """
    CREATE TABLE IF NOT EXISTS permissions (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        resource TEXT NOT NULL,
        action TEXT NOT NULL,
        description TEXT,
        scope TEXT DEFAULT 'organization',
        conditions JSONB,
        created_at TIMESTAMP DEFAULT NOW()
    );
    """

    IDENTITIES_TABLE = """
    CREATE TABLE IF NOT EXISTS identities (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        user_id UUID NOT NULL,
        provider TEXT NOT NULL,
        provider_id TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT,
        password_hash TEXT,
        mfa_enabled BOOLEAN DEFAULT FALSE,
        mfa_secret TEXT,
        last_login TIMESTAMP,
        login_attempts INT DEFAULT 0,
        locked_until TIMESTAMP,
        status TEXT DEFAULT 'active',
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
    );
    CREATE INDEX IF NOT EXISTS idx_identities_email ON identities(email);
    """

    WORKFLOWS_TABLE = """
    CREATE TABLE IF NOT EXISTS workflows (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        name TEXT NOT NULL,
        description TEXT,
        definition JSONB,
        trigger_type TEXT DEFAULT 'manual',
        trigger_config JSONB,
        version INT DEFAULT 1,
        is_active BOOLEAN DEFAULT TRUE,
        status TEXT DEFAULT 'active',
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
    );
    """

    APPROVALS_TABLE = """
    CREATE TABLE IF NOT EXISTS approvals (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        workflow_id UUID,
        requester_id UUID NOT NULL,
        title TEXT NOT NULL,
        description TEXT,
        data JSONB,
        approvers JSONB,
        current_step INT DEFAULT 0,
        status TEXT DEFAULT 'pending',
        approved_by UUID[],
        rejected_by UUID,
        comments JSONB,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
    );
    """

    AUDIT_LOGS_TABLE = """
    CREATE TABLE IF NOT EXISTS audit_logs (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        entity_type TEXT NOT NULL,
        entity_id TEXT NOT NULL,
        action TEXT NOT NULL,
        actor_id TEXT NOT NULL,
        actor_type TEXT DEFAULT 'user',
        changes JSONB,
        ip_address TEXT,
        user_agent TEXT,
        severity TEXT DEFAULT 'info',
        created_at TIMESTAMP DEFAULT NOW()
    );
    CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_logs(entity_type, entity_id);
    CREATE INDEX IF NOT EXISTS idx_audit_actor ON audit_logs(actor_id);
    """

    RISKS_TABLE = """
    CREATE TABLE IF NOT EXISTS risks (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        organization_id UUID NOT NULL,
        title TEXT NOT NULL,
        description TEXT,
        category TEXT,
        likelihood INT DEFAULT 3,
        impact INT DEFAULT 3,
        score FLOAT DEFAULT 0.0,
        status TEXT DEFAULT 'open',
        owner_id UUID,
        mitigation_plan TEXT,
        residual_risk FLOAT,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
    );
    """

    COMPLIANCE_TABLE = """
    CREATE TABLE IF NOT EXISTS compliance_requirements (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        organization_id UUID NOT NULL,
        regulation TEXT NOT NULL,
        requirement TEXT NOT NULL,
        description TEXT,
        category TEXT,
        priority TEXT DEFAULT 'medium',
        status TEXT DEFAULT 'pending',
        evidence TEXT[],
        due_date TIMESTAMP,
        completed_date TIMESTAMP,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
    );
    """

    CONTRACTS_TABLE = """
    CREATE TABLE IF NOT EXISTS contracts (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        organization_id UUID NOT NULL,
        title TEXT NOT NULL,
        parties JSONB,
        content TEXT,
        value FLOAT,
        currency TEXT DEFAULT 'USD',
        start_date TIMESTAMP,
        end_date TIMESTAMP,
        status TEXT DEFAULT 'draft',
        signed_by UUID[],
        signed_at TIMESTAMP,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
    );
    """

    ASSETS_TABLE = """
    CREATE TABLE IF NOT EXISTS assets (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        organization_id UUID NOT NULL,
        name TEXT NOT NULL,
        asset_type TEXT NOT NULL,
        serial_number TEXT,
        purchase_date TIMESTAMP,
        purchase_value FLOAT,
        current_value FLOAT,
        location TEXT,
        assigned_to UUID,
        status TEXT DEFAULT 'active',
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
    );
    """

    SECURITY_INCIDENTS_TABLE = """
    CREATE TABLE IF NOT EXISTS security_incidents (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        organization_id UUID NOT NULL,
        title TEXT NOT NULL,
        description TEXT,
        severity TEXT DEFAULT 'medium',
        category TEXT,
        status TEXT DEFAULT 'open',
        detected_at TIMESTAMP,
        resolved_at TIMESTAMP,
        assigned_to UUID,
        affected_assets UUID[],
        remediation TEXT,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
    );
    """

    PLUGINS_TABLE = """
    CREATE TABLE IF NOT EXISTS plugins (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        name TEXT NOT NULL,
        description TEXT,
        version TEXT NOT NULL,
        author TEXT,
        entry_point TEXT NOT NULL,
        dependencies TEXT[],
        capabilities TEXT[],
        config_schema JSONB,
        installed_at TIMESTAMP,
        is_active BOOLEAN DEFAULT FALSE,
        is_system BOOLEAN DEFAULT FALSE,
        status TEXT DEFAULT 'inactive',
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
    );
    """

    MODULE_REGISTRY_TABLE = """
    CREATE TABLE IF NOT EXISTS module_registry (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        name TEXT NOT NULL,
        version TEXT NOT NULL,
        description TEXT,
        module_type TEXT NOT NULL,
        entry_point TEXT NOT NULL,
        dependencies TEXT[],
        provides TEXT[],
        requires TEXT[],
        config JSONB,
        is_active BOOLEAN DEFAULT FALSE,
        status TEXT DEFAULT 'inactive',
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
    );
    CREATE INDEX IF NOT EXISTS idx_module_name ON module_registry(name);
    """

    CAPABILITY_REGISTRY_TABLE = """
    CREATE TABLE IF NOT EXISTS capability_registry (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        name TEXT NOT NULL,
        description TEXT,
        category TEXT,
        provider_module TEXT NOT NULL,
        provider_version TEXT NOT NULL,
        interface TEXT NOT NULL,
        schema JSONB,
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
    );
    """

    VERSION_REGISTRY_TABLE = """
    CREATE TABLE IF NOT EXISTS version_registry (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        version_number TEXT NOT NULL,
        layer_name TEXT NOT NULL,
        description TEXT,
        modules TEXT[],
        capabilities TEXT[],
        agents TEXT[],
        dependencies TEXT[],
        migration_path TEXT,
        is_installed BOOLEAN DEFAULT FALSE,
        is_active BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
    );
    CREATE INDEX IF NOT EXISTS idx_version_number ON version_registry(version_number);
    """

    AGENTS_TABLE = """
    CREATE TABLE IF NOT EXISTS enterprise_agents (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        name TEXT NOT NULL,
        description TEXT,
        agent_type TEXT NOT NULL,
        team TEXT NOT NULL,
        capabilities TEXT[],
        skills TEXT[],
        config JSONB,
        runtime_id TEXT,
        last_active TIMESTAMP,
        total_tasks INT DEFAULT 0,
        success_rate FLOAT DEFAULT 0.0,
        status TEXT DEFAULT 'active',
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
    );
    CREATE INDEX IF NOT EXISTS idx_agents_type ON enterprise_agents(agent_type);
    CREATE INDEX IF NOT EXISTS idx_agents_team ON enterprise_agents(team);
    """

    REPORTS_TABLE = """
    CREATE TABLE IF NOT EXISTS reports (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        organization_id UUID NOT NULL,
        title TEXT NOT NULL,
        report_type TEXT NOT NULL,
        category TEXT,
        data JSONB,
        format TEXT DEFAULT 'json',
        generated_by UUID,
        scheduled BOOLEAN DEFAULT FALSE,
        schedule_config JSONB,
        status TEXT DEFAULT 'active',
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
    );
    """

    DASHBOARDS_TABLE = """
    CREATE TABLE IF NOT EXISTS dashboards (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        organization_id UUID NOT NULL,
        name TEXT NOT NULL,
        description TEXT,
        widgets JSONB,
        layout JSONB,
        is_default BOOLEAN DEFAULT FALSE,
        is_shared BOOLEAN DEFAULT FALSE,
        owner_id UUID NOT NULL,
        status TEXT DEFAULT 'active',
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
    );
    """

    @classmethod
    async def initialize(cls):
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            for table_sql in [
                cls.ORGANIZATIONS_TABLE, cls.COMPANIES_TABLE, cls.DEPARTMENTS_TABLE,
                cls.TEAMS_TABLE, cls.EMPLOYEES_TABLE, cls.ROLES_TABLE,
                cls.PERMISSIONS_TABLE, cls.IDENTITIES_TABLE, cls.WORKFLOWS_TABLE,
                cls.APPROVALS_TABLE, cls.AUDIT_LOGS_TABLE, cls.RISKS_TABLE,
                cls.COMPLIANCE_TABLE, cls.CONTRACTS_TABLE, cls.ASSETS_TABLE,
                cls.SECURITY_INCIDENTS_TABLE, cls.PLUGINS_TABLE, cls.MODULE_REGISTRY_TABLE,
                cls.CAPABILITY_REGISTRY_TABLE, cls.VERSION_REGISTRY_TABLE, cls.AGENTS_TABLE,
                cls.REPORTS_TABLE, cls.DASHBOARDS_TABLE
            ]:
                await conn.execute(table_sql)
