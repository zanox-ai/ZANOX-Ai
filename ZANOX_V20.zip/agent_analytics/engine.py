"""ZANOX V20 - Agent Analytics Engine"""
import logging
from typing import Dict, List, Any
from shared.database import DatabaseManager
from shared.utils import ZANOXUtils

logger = logging.getLogger('zanox.agent_analytics')

class AgentAnalyticsEngine:
    def __init__(self):
        self.metrics = {}

    async def get_summary(self) -> Dict[str, Any]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            total = await conn.fetchval("SELECT COUNT(*) FROM enterprise_agents WHERE status = 'active'")
            avg_success = await conn.fetchval("SELECT AVG(success_rate) FROM enterprise_agents WHERE status = 'active'")
            total_tasks = await conn.fetchval("SELECT SUM(total_tasks) FROM enterprise_agents")
            return {
                "total_agents": total or 0,
                "average_success_rate": avg_success or 0,
                "total_tasks_completed": total_tasks or 0
            }

    async def track(self, agent_id: str, metric: str, value: float) -> bool:
        if agent_id not in self.metrics:
            self.metrics[agent_id] = {}
        self.metrics[agent_id][metric] = value
        return True

    async def get_agent_metrics(self, agent_id: str) -> Dict[str, Any]:
        return self.metrics.get(agent_id, {})
