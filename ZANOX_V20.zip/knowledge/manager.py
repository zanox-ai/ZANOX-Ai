"""ZANOX V20 - Enterprise Knowledge System"""
import logging
from typing import Dict, List, Any
from shared.database import DatabaseManager
from shared.utils import ZANOXUtils

logger = logging.getLogger('zanox.knowledge')

class KnowledgeManager:
    def __init__(self):
        self.articles = []

    async def create_article(self, data: Dict[str, Any]) -> Dict[str, Any]:
        article_id = ZANOXUtils.generate_id("article")
        self.articles.append({"id": article_id, **data})
        return {"id": article_id, "status": "created"}

    async def query(self, query: str) -> List[Dict[str, Any]]:
        results = [a for a in self.articles if query.lower() in a.get("title", "").lower() or query.lower() in a.get("content", "").lower()]
        return results

    async def search(self, query: str) -> List[Dict[str, Any]]:
        return await self.query(query)
