"""ZANOX V20 - Performance Management"""
import logging
from typing import Dict, List, Any, Optional
from shared.database import DatabaseManager
from shared.models import PerformanceReview
from shared.utils import ZANOXUtils

logger = logging.getLogger('zanox.performance')

class PerformanceManager:
    def __init__(self):
        self.reviews = []

    async def create_review(self, data: Dict[str, Any]) -> Dict[str, Any]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            review_id = ZANOXUtils.generate_id("perf")
            await conn.execute("""
                INSERT INTO performance_reviews (id, employee_id, reviewer_id, period_start, period_end, goals, achievements, ratings, overall_score, feedback, status)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
            """, review_id, data.get("employee_id"), data.get("reviewer_id"), data.get("period_start"),
            data.get("period_end"), data.get("goals", []), data.get("achievements", []),
            data.get("ratings", {}), data.get("overall_score"), data.get("feedback"), "draft")
            return {"id": review_id, "status": "draft"}

    async def get_summary(self) -> Dict[str, Any]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            avg = await conn.fetchval("SELECT AVG(overall_score) FROM performance_reviews WHERE status = 'completed'")
            return {"average_score": avg or 0, "status": "active"}

    async def submit(self, review_id: str) -> bool:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            await conn.execute("UPDATE performance_reviews SET status = 'submitted', updated_at = NOW() WHERE id = $1", review_id)
            return True
