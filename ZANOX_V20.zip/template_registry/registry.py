"""ZANOX V20 - Template Registry"""
import logging
from typing import Dict, List, Any
from shared.utils import ZANOXUtils

logger = logging.getLogger('zanox.template_registry')

class TemplateRegistry:
    def __init__(self):
        self.templates = {}

    async def get_registry(self) -> List[Dict[str, Any]]:
        return list(self.templates.values())

    async def register(self, data: Dict[str, Any]) -> Dict[str, Any]:
        tmpl_id = ZANOXUtils.generate_id("tmpl")
        self.templates[tmpl_id] = {"id": tmpl_id, **data}
        return {"id": tmpl_id, "status": "registered"}

    async def get(self, tmpl_id: str) -> Dict[str, Any]:
        return self.templates.get(tmpl_id, {})

    async def render(self, tmpl_id: str, context: Dict[str, Any]) -> str:
        tmpl = self.templates.get(tmpl_id, {})
        content = tmpl.get("content", "")
        for key, value in context.items():
            content = content.replace(f"{{{{{key}}}}}", str(value))
        return content
