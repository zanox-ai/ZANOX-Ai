"""ZANOX V20 - Agent Registry"""
import logging
from typing import Dict, List, Any, Optional
from shared.database import DatabaseManager
from shared.models import EnterpriseAgent
from shared.utils import ZANOXUtils

logger = logging.getLogger('zanox.agent_registry')

class AgentRegistry:
    def __init__(self):
        self.agents = {}

    async def register(self, data: Dict[str, Any]) -> Dict[str, Any]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            agent_id = ZANOXUtils.generate_id("agent")
            await conn.execute("""
                INSERT INTO enterprise_agents (id, name, description, agent_type, team, capabilities, skills, config)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
            """, agent_id, data.get("name"), data.get("description"), data.get("agent_type"),
            data.get("team"), data.get("capabilities", []), data.get("skills", []), data.get("config", {}))
            self.agents[agent_id] = data
            return {"id": agent_id, "status": "registered", "name": data.get("name")}

    async def get(self, agent_id: str) -> Optional[Dict[str, Any]]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("SELECT * FROM enterprise_agents WHERE id = $1", agent_id)
            return dict(row) if row else None

    async def list_agents(self, team: Optional[str] = None, agent_type: Optional[str] = None) -> List[Dict[str, Any]]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            if team and agent_type:
                rows = await conn.fetch("SELECT * FROM enterprise_agents WHERE team = $1 AND agent_type = $2 AND status = 'active'", team, agent_type)
            elif team:
                rows = await conn.fetch("SELECT * FROM enterprise_agents WHERE team = $1 AND status = 'active'", team)
            elif agent_type:
                rows = await conn.fetch("SELECT * FROM enterprise_agents WHERE agent_type = $1 AND status = 'active'", agent_type)
            else:
                rows = await conn.fetch("SELECT * FROM enterprise_agents WHERE status = 'active'")
            return [dict(row) for row in rows]

    async def unregister(self, agent_id: str) -> bool:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            await conn.execute("UPDATE enterprise_agents SET status = 'inactive', updated_at = NOW() WHERE id = $1", agent_id)
            self.agents.pop(agent_id, None)
            return True
