"""ZANOX V20 - Team Management"""
import logging
from typing import Dict, List, Any, Optional
from shared.database import DatabaseManager
from shared.models import Team
from shared.utils import ZANOXUtils

logger = logging.getLogger('zanox.teams')

class TeamManager:
    def __init__(self):
        pass

    async def create(self, data: Dict[str, Any]) -> Dict[str, Any]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            team_id = ZANOXUtils.generate_id("team")
            await conn.execute("""
                INSERT INTO teams (id, department_id, name, description, lead_id, members, projects)
                VALUES ($1, $2, $3, $4, $5, $6, $7)
            """, team_id, data.get("department_id"), data.get("name"), data.get("description"),
            data.get("lead_id"), data.get("members", []), data.get("projects", []))
            return {"id": team_id, "status": "created", "name": data.get("name")}

    async def get(self, team_id: str) -> Optional[Dict[str, Any]]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("SELECT * FROM teams WHERE id = $1", team_id)
            return dict(row) if row else None

    async def list_by_department(self, dept_id: str) -> List[Dict[str, Any]]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            rows = await conn.fetch("SELECT * FROM teams WHERE department_id = $1 AND status = 'active'", dept_id)
            return [dict(row) for row in rows]

    async def add_member(self, team_id: str, employee_id: str) -> bool:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            await conn.execute("UPDATE teams SET members = array_append(members, $1), updated_at = NOW() WHERE id = $2", employee_id, team_id)
            return True

    async def remove_member(self, team_id: str, employee_id: str) -> bool:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            await conn.execute("UPDATE teams SET members = array_remove(members, $1), updated_at = NOW() WHERE id = $2", employee_id, team_id)
            return True
