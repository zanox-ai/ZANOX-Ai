"""ZANOX V20 - Agent Knowledge Manager"""
import logging
from typing import Dict, List, Any
from shared.database import DatabaseManager
from shared.utils import ZANOXUtils

logger = logging.getLogger('zanox.agent_knowledge')

class AgentKnowledgeManager:
    def __init__(self):
        self.knowledge_bases = {}

    async def add_knowledge(self, agent_id: str, topic: str, content: str) -> bool:
        if agent_id not in self.knowledge_bases:
            self.knowledge_bases[agent_id] = {}
        self.knowledge_bases[agent_id][topic] = content
        return True

    async def query(self, agent_id: str, query: str) -> List[Dict[str, Any]]:
        kb = self.knowledge_bases.get(agent_id, {})
        results = []
        for topic, content in kb.items():
            if query.lower() in topic.lower() or query.lower() in content.lower():
                results.append({"topic": topic, "content": content[:500]})
        return results

    async def share(self, from_agent: str, to_agent: str, topic: str) -> bool:
        kb = self.knowledge_bases.get(from_agent, {})
        if topic in kb:
            if to_agent not in self.knowledge_bases:
                self.knowledge_bases[to_agent] = {}
            self.knowledge_bases[to_agent][topic] = kb[topic]
            return True
        return False
