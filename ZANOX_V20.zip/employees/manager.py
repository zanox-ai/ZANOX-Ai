"""ZANOX V20 - Employee Management"""
import logging
from typing import Dict, List, Any, Optional
from shared.database import DatabaseManager
from shared.models import Employee
from shared.utils import ZANOXUtils

logger = logging.getLogger('zanox.employees')

class EmployeeManager:
    def __init__(self):
        pass

    async def create(self, data: Dict[str, Any]) -> Dict[str, Any]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            emp_id = ZANOXUtils.generate_id("emp")
            await conn.execute("""
                INSERT INTO employees (id, company_id, department_id, team_id, user_id, employee_number, job_title, job_level, employment_type, hire_date, salary, currency, manager_id, skills, certifications, contact_info)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16)
            """, emp_id, data.get("company_id"), data.get("department_id"), data.get("team_id"),
            data.get("user_id"), data.get("employee_number"), data.get("job_title"), data.get("job_level"),
            data.get("employment_type", "full_time"), data.get("hire_date"), data.get("salary"),
            data.get("currency", "USD"), data.get("manager_id"), data.get("skills", []),
            data.get("certifications", []), data.get("contact_info", {}))
            return {"id": emp_id, "status": "created", "job_title": data.get("job_title")}

    async def get(self, emp_id: str) -> Optional[Dict[str, Any]]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("SELECT * FROM employees WHERE id = $1", emp_id)
            return dict(row) if row else None

    async def list_by_company(self, company_id: str) -> List[Dict[str, Any]]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            rows = await conn.fetch("SELECT * FROM employees WHERE company_id = $1 AND status = 'active'", company_id)
            return [dict(row) for row in rows]

    async def update(self, emp_id: str, data: Dict[str, Any]) -> bool:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            await conn.execute("UPDATE employees SET job_title = $1, salary = $2, updated_at = NOW() WHERE id = $3", data.get("job_title"), data.get("salary"), emp_id)
            return True

    async def terminate(self, emp_id: str, termination_date: str) -> bool:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            await conn.execute("UPDATE employees SET termination_date = $1, status = 'inactive', updated_at = NOW() WHERE id = $2", termination_date, emp_id)
            return True
