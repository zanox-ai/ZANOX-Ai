"""ZANOX V20 - Payroll Engine"""
import logging
from typing import Dict, List, Any, Optional
from shared.database import DatabaseManager
from shared.models import Payroll
from shared.utils import ZANOXUtils

logger = logging.getLogger('zanox.payroll')

class PayrollEngine:
    def __init__(self):
        self.payrolls = []

    async def create(self, data: Dict[str, Any]) -> Dict[str, Any]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            payroll_id = ZANOXUtils.generate_id("pay")
            base = data.get("base_salary", 0.0)
            bonuses = data.get("bonuses", 0.0)
            deductions = data.get("deductions", 0.0)
            taxes = data.get("taxes", 0.0)
            net = base + bonuses - deductions - taxes
            await conn.execute("""
                INSERT INTO payrolls (id, employee_id, period_start, period_end, base_salary, bonuses, deductions, taxes, net_pay, currency, status)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
            """, payroll_id, data.get("employee_id"), data.get("period_start"), data.get("period_end"),
            base, bonuses, deductions, taxes, net, data.get("currency", "USD"), "draft")
            return {"id": payroll_id, "status": "draft", "net_pay": net}

    async def get_summary(self) -> Dict[str, Any]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            total = await conn.fetchval("SELECT SUM(net_pay) FROM payrolls WHERE status = 'approved'")
            return {"total_payroll": total or 0, "currency": "USD"}

    async def approve(self, payroll_id: str, approved_by: str) -> bool:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            await conn.execute("UPDATE payrolls SET status = 'approved', approved_by = $1, approved_at = NOW() WHERE id = $2", approved_by, payroll_id)
            return True
