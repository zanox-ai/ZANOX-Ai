"""ZANOX V20 - Dynamic Service Loader"""
import logging
from typing import Dict, List, Any
from shared.utils import ZANOXUtils

logger = logging.getLogger('zanox.service_loader')

class ServiceLoader:
    def __init__(self):
        self.services = {}

    async def load(self, data: Dict[str, Any]) -> Dict[str, Any]:
        service_name = data.get("service_name")
        service_class = data.get("service_class")
        self.services[service_name] = {"class": service_class, "status": "loaded"}
        return {"service": service_name, "status": "loaded"}

    async def start(self, service_name: str) -> Dict[str, Any]:
        if service_name in self.services:
            self.services[service_name]["status"] = "running"
            return {"service": service_name, "status": "started"}
        return {"service": service_name, "status": "not_found"}

    async def stop(self, service_name: str) -> Dict[str, Any]:
        if service_name in self.services:
            self.services[service_name]["status"] = "stopped"
            return {"service": service_name, "status": "stopped"}
        return {"service": service_name, "status": "not_found"}

    async def list_services(self) -> List[Dict[str, Any]]:
        return [{"name": k, "status": v["status"]} for k, v in self.services.items()]
