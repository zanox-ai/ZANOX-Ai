"""ZANOX V20 - Capability Registry"""
import logging
from typing import Dict, List, Any, Optional
from shared.database import DatabaseManager
from shared.models import CapabilityRegistration
from shared.utils import ZANOXUtils

logger = logging.getLogger('zanox.capability_registry')

class CapabilityRegistry:
    def __init__(self):
        self.capabilities = {}

    async def register(self, data: Dict[str, Any]) -> Dict[str, Any]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            cap_id = ZANOXUtils.generate_id("cap")
            await conn.execute("""
                INSERT INTO capability_registry (id, name, description, category, provider_module, provider_version, interface, schema, is_active)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
            """, cap_id, data.get("name"), data.get("description"), data.get("category"),
            data.get("provider_module"), data.get("provider_version"), data.get("interface"),
            data.get("schema", {}), data.get("is_active", True))
            self.capabilities[cap_id] = data
            return {"id": cap_id, "status": "registered", "name": data.get("name")}

    async def get(self, cap_id: str) -> Optional[Dict[str, Any]]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("SELECT * FROM capability_registry WHERE id = $1", cap_id)
            return dict(row) if row else None

    async def list_capabilities(self) -> List[Dict[str, Any]]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            rows = await conn.fetch("SELECT * FROM capability_registry WHERE is_active = TRUE")
            return [dict(row) for row in rows]

    async def find_by_category(self, category: str) -> List[Dict[str, Any]]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            rows = await conn.fetch("SELECT * FROM capability_registry WHERE category = $1 AND is_active = TRUE", category)
            return [dict(row) for row in rows]

    async def discover(self, query: str) -> List[Dict[str, Any]]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            rows = await conn.fetch("SELECT * FROM capability_registry WHERE name ILIKE $1 AND is_active = TRUE", f"%{query}%")
            return [dict(row) for row in rows]
