"""ZANOX V20 - Version Registry"""
import logging
from typing import Dict, List, Any, Optional
from shared.database import DatabaseManager
from shared.models import VersionRegistration
from shared.utils import ZANOXUtils

logger = logging.getLogger('zanox.version_registry')

class VersionRegistry:
    def __init__(self):
        self.versions = {}

    async def register(self, data: Dict[str, Any]) -> Dict[str, Any]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            ver_id = ZANOXUtils.generate_id("ver")
            await conn.execute("""
                INSERT INTO version_registry (id, version_number, layer_name, description, modules, capabilities, agents, dependencies, migration_path, is_installed, is_active)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
            """, ver_id, data.get("version_number"), data.get("layer_name"), data.get("description"),
            data.get("modules", []), data.get("capabilities", []), data.get("agents", []),
            data.get("dependencies", []), data.get("migration_path"), data.get("is_installed", False),
            data.get("is_active", False))
            self.versions[ver_id] = data
            return {"id": ver_id, "status": "registered", "version": data.get("version_number")}

    async def get(self, ver_id: str) -> Optional[Dict[str, Any]]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("SELECT * FROM version_registry WHERE id = $1", ver_id)
            return dict(row) if row else None

    async def list_versions(self) -> List[Dict[str, Any]]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            rows = await conn.fetch("SELECT * FROM version_registry ORDER BY version_number")
            return [dict(row) for row in rows]

    async def install(self, ver_id: str) -> bool:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            await conn.execute("UPDATE version_registry SET is_installed = TRUE, updated_at = NOW() WHERE id = $1", ver_id)
            return True

    async def activate(self, ver_id: str) -> bool:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            await conn.execute("UPDATE version_registry SET is_active = TRUE, updated_at = NOW() WHERE id = $1", ver_id)
            return True

    async def get_future_versions(self) -> List[Dict[str, Any]]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            rows = await conn.fetch("SELECT * FROM version_registry WHERE is_installed = FALSE")
            return [dict(row) for row in rows]
