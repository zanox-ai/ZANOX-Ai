"""ZANOX V20 - Workflow Registry"""
import logging
from typing import Dict, List, Any
from shared.utils import ZANOXUtils

logger = logging.getLogger('zanox.workflow_registry')

class WorkflowRegistry:
    def __init__(self):
        self.workflows = {}

    async def get_registry(self) -> List[Dict[str, Any]]:
        return list(self.workflows.values())

    async def register(self, data: Dict[str, Any]) -> Dict[str, Any]:
        wf_id = ZANOXUtils.generate_id("wfr")
        self.workflows[wf_id] = {"id": wf_id, **data}
        return {"id": wf_id, "status": "registered"}

    async def get_template(self, wf_id: str) -> Dict[str, Any]:
        return self.workflows.get(wf_id, {})

    async def list_by_category(self, category: str) -> List[Dict[str, Any]]:
        return [w for w in self.workflows.values() if w.get("category") == category]
