"""ZANOX V20 - Module Registry"""
import logging
from typing import Dict, List, Any, Optional
from shared.database import DatabaseManager
from shared.models import ModuleRegistration
from shared.utils import ZANOXUtils

logger = logging.getLogger('zanox.module_registry')

class ModuleRegistry:
    def __init__(self):
        self.modules = {}

    async def register(self, data: Dict[str, Any]) -> Dict[str, Any]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            mod_id = ZANOXUtils.generate_id("mod")
            await conn.execute("""
                INSERT INTO module_registry (id, name, version, description, module_type, entry_point, dependencies, provides, requires, config, is_active)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
            """, mod_id, data.get("name"), data.get("version"), data.get("description"),
            data.get("module_type"), data.get("entry_point"), data.get("dependencies", []),
            data.get("provides", []), data.get("requires", []), data.get("config", {}), data.get("is_active", False))
            self.modules[mod_id] = data
            return {"id": mod_id, "status": "registered", "name": data.get("name")}

    async def get(self, mod_id: str) -> Optional[Dict[str, Any]]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("SELECT * FROM module_registry WHERE id = $1", mod_id)
            return dict(row) if row else None

    async def list_modules(self) -> List[Dict[str, Any]]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            rows = await conn.fetch("SELECT * FROM module_registry")
            return [dict(row) for row in rows]

    async def activate(self, mod_id: str) -> bool:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            await conn.execute("UPDATE module_registry SET is_active = TRUE, status = 'active', updated_at = NOW() WHERE id = $1", mod_id)
            return True

    async def deactivate(self, mod_id: str) -> bool:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            await conn.execute("UPDATE module_registry SET is_active = FALSE, status = 'inactive', updated_at = NOW() WHERE id = $1", mod_id)
            return True

    async def find_by_capability(self, capability: str) -> List[Dict[str, Any]]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            rows = await conn.fetch("SELECT * FROM module_registry WHERE $1 = ANY(provides) AND is_active = TRUE", capability)
            return [dict(row) for row in rows]
