"""ZANOX V20 - Extension SDK"""
import logging
from typing import Dict, List, Any
from shared.utils import ZANOXUtils

logger = logging.getLogger('zanox.extension_sdk')

class ExtensionSDK:
    def __init__(self):
        self.extensions = {}

    def register_extension(self, name: str, extension: Any) -> bool:
        self.extensions[name] = extension
        return True

    def get_extension(self, name: str) -> Any:
        return self.extensions.get(name)

    def list_extensions(self) -> List[str]:
        return list(self.extensions.keys())

    def create_extension_template(self, name: str) -> Dict[str, Any]:
        return {
            "name": name,
            "type": "extension",
            "version": "1.0.0",
            "entry_point": f"{name}/main.py",
            "config": {},
            "dependencies": []
        }
