"""ZANOX V20 - Organization Management"""
import logging
from typing import Dict, List, Any, Optional
from shared.database import DatabaseManager
from shared.models import Organization
from shared.utils import ZANOXUtils

logger = logging.getLogger('zanox.organization')

class OrganizationManager:
    def __init__(self):
        self.cache = {}

    async def create(self, data: Dict[str, Any]) -> Dict[str, Any]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            org_id = ZANOXUtils.generate_id("org")
            await conn.execute("""
                INSERT INTO organizations (id, name, legal_name, tax_id, industry, size, website, address, country, timezone, currency, parent_id, settings, metadata)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
            """, org_id, data.get("name"), data.get("legal_name"), data.get("tax_id"),
            data.get("industry"), data.get("size"), data.get("website"), data.get("address"),
            data.get("country"), data.get("timezone", "UTC"), data.get("currency", "USD"),
            data.get("parent_id"), data.get("settings", {}), data.get("metadata", {}))
            return {"id": org_id, "status": "created", "name": data.get("name")}

    async def get(self, org_id: str) -> Optional[Dict[str, Any]]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("SELECT * FROM organizations WHERE id = $1", org_id)
            return dict(row) if row else None

    async def list_all(self) -> List[Dict[str, Any]]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            rows = await conn.fetch("SELECT * FROM organizations WHERE status = 'active'")
            return [dict(row) for row in rows]

    async def update(self, org_id: str, data: Dict[str, Any]) -> bool:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            await conn.execute("UPDATE organizations SET name = $1, updated_at = NOW() WHERE id = $2", data.get("name"), org_id)
            return True

    async def delete(self, org_id: str) -> bool:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            await conn.execute("UPDATE organizations SET status = 'deleted', updated_at = NOW() WHERE id = $1", org_id)
            return True
