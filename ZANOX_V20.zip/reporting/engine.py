"""ZANOX V20 - Enterprise Reporting"""
import logging
from typing import Dict, List, Any, Optional
from shared.database import DatabaseManager
from shared.models import Report
from shared.utils import ZANOXUtils

logger = logging.getLogger('zanox.reporting')

class ReportingEngine:
    def __init__(self):
        self.reports = []

    async def create(self, data: Dict[str, Any]) -> Dict[str, Any]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            report_id = ZANOXUtils.generate_id("report")
            await conn.execute("""
                INSERT INTO reports (id, organization_id, title, report_type, category, data, format, generated_by, scheduled, schedule_config)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
            """, report_id, data.get("organization_id"), data.get("title"), data.get("report_type"),
            data.get("category"), data.get("data", {}), data.get("format", "json"), data.get("generated_by"),
            data.get("scheduled", False), data.get("schedule_config"))
            return {"id": report_id, "status": "generated", "title": data.get("title")}

    async def get(self, report_id: str) -> Optional[Dict[str, Any]]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("SELECT * FROM reports WHERE id = $1", report_id)
            return dict(row) if row else None

    async def list_by_organization(self, org_id: str) -> List[Dict[str, Any]]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            rows = await conn.fetch("SELECT * FROM reports WHERE organization_id = $1 ORDER BY created_at DESC", org_id)
            return [dict(row) for row in rows]
