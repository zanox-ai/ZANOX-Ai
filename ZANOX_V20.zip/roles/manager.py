"""ZANOX V20 - Role Management"""
import logging
from typing import Dict, List, Any, Optional
from shared.database import DatabaseManager
from shared.models import Role
from shared.utils import ZANOXUtils

logger = logging.getLogger('zanox.roles')

class RoleManager:
    def __init__(self):
        pass

    async def create(self, data: Dict[str, Any]) -> Dict[str, Any]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            role_id = ZANOXUtils.generate_id("role")
            await conn.execute("""
                INSERT INTO roles (id, name, description, permissions, scope, is_system)
                VALUES ($1, $2, $3, $4, $5, $6)
            """, role_id, data.get("name"), data.get("description"), data.get("permissions", []),
            data.get("scope", "organization"), data.get("is_system", False))
            return {"id": role_id, "status": "created", "name": data.get("name")}

    async def get(self, role_id: str) -> Optional[Dict[str, Any]]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("SELECT * FROM roles WHERE id = $1", role_id)
            return dict(row) if row else None

    async def list_roles(self) -> List[Dict[str, Any]]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            rows = await conn.fetch("SELECT * FROM roles WHERE status = 'active'")
            return [dict(row) for row in rows]

    async def assign_permission(self, role_id: str, permission: str) -> bool:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            await conn.execute("UPDATE roles SET permissions = array_append(permissions, $1), updated_at = NOW() WHERE id = $2", permission, role_id)
            return True

    async def revoke_permission(self, role_id: str, permission: str) -> bool:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            await conn.execute("UPDATE roles SET permissions = array_remove(permissions, $1), updated_at = NOW() WHERE id = $2", permission, role_id)
            return True
