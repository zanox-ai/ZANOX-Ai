"""ZANOX V20 - Asset Management"""
import logging
from typing import Dict, List, Any, Optional
from shared.database import DatabaseManager
from shared.models import Asset
from shared.utils import ZANOXUtils

logger = logging.getLogger('zanox.assets')

class AssetManager:
    def __init__(self):
        self.assets = []

    async def create(self, data: Dict[str, Any]) -> Dict[str, Any]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            asset_id = ZANOXUtils.generate_id("asset")
            await conn.execute("""
                INSERT INTO assets (id, organization_id, name, asset_type, serial_number, purchase_date, purchase_value, current_value, location, assigned_to, status)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
            """, asset_id, data.get("organization_id"), data.get("name"), data.get("asset_type"),
            data.get("serial_number"), data.get("purchase_date"), data.get("purchase_value"),
            data.get("current_value"), data.get("location"), data.get("assigned_to"), "active")
            return {"id": asset_id, "status": "active", "name": data.get("name")}

    async def get_summary(self) -> Dict[str, Any]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            total = await conn.fetchval("SELECT COUNT(*) FROM assets WHERE status = 'active'")
            value = await conn.fetchval("SELECT SUM(current_value) FROM assets WHERE status = 'active'")
            return {"total_assets": total or 0, "total_value": value or 0}

    async def assign(self, asset_id: str, employee_id: str) -> bool:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            await conn.execute("UPDATE assets SET assigned_to = $1, updated_at = NOW() WHERE id = $2", employee_id, asset_id)
            return True
