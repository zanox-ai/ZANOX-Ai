"""ZANOX V20 - Department Management"""
import logging
from typing import Dict, List, Any, Optional
from shared.database import DatabaseManager
from shared.models import Department
from shared.utils import ZANOXUtils

logger = logging.getLogger('zanox.departments')

class DepartmentManager:
    def __init__(self):
        pass

    async def create(self, data: Dict[str, Any]) -> Dict[str, Any]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            dept_id = ZANOXUtils.generate_id("dept")
            await conn.execute("""
                INSERT INTO departments (id, company_id, name, description, manager_id, parent_id, budget, headcount)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
            """, dept_id, data.get("company_id"), data.get("name"), data.get("description"),
            data.get("manager_id"), data.get("parent_id"), data.get("budget"), data.get("headcount", 0))
            return {"id": dept_id, "status": "created", "name": data.get("name")}

    async def get(self, dept_id: str) -> Optional[Dict[str, Any]]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("SELECT * FROM departments WHERE id = $1", dept_id)
            return dict(row) if row else None

    async def list_by_company(self, company_id: str) -> List[Dict[str, Any]]:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            rows = await conn.fetch("SELECT * FROM departments WHERE company_id = $1 AND status = 'active'", company_id)
            return [dict(row) for row in rows]

    async def update(self, dept_id: str, data: Dict[str, Any]) -> bool:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            await conn.execute("UPDATE departments SET name = $1, updated_at = NOW() WHERE id = $2", data.get("name"), dept_id)
            return True

    async def delete(self, dept_id: str) -> bool:
        pool = await DatabaseManager.get_postgres()
        async with pool.acquire() as conn:
            await conn.execute("UPDATE departments SET status = 'deleted', updated_at = NOW() WHERE id = $1", dept_id)
            return True
