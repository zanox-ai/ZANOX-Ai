"""Continuous Learning System for Nexus Core V9."""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
from collections import deque

logger = logging.getLogger(__name__)


@dataclass
class LearningEpisode:
    """A single learning episode."""
    episode_id: str
    context: Dict[str, Any]
    action: str
    outcome: Dict[str, Any]
    reward: float
    timestamp: datetime
    learned: bool = False


@dataclass
class KnowledgeUpdate:
    """An update to the knowledge base."""
    update_id: str
    category: str
    key: str
    old_value: Any
    new_value: Any
    confidence: float
    source: str
    timestamp: datetime


class ContinuousLearningSystem:
    """Continuously learns from interactions and updates knowledge."""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._episodes: deque = deque(maxlen=config.get("max_episodes", 10000))
        self._knowledge: Dict[str, Any] = {}
        self._updates: List[KnowledgeUpdate] = []
        self._learning_rate = config.get("learning_rate", 0.1)
        self._discount_factor = config.get("discount_factor", 0.95)
        self._is_learning = False
        self._lock = asyncio.Lock()

    async def start(self):
        """Start continuous learning."""
        self._is_learning = True
        asyncio.create_task(self._learning_loop())
        logger.info("Continuous learning started")

    async def stop(self):
        """Stop continuous learning."""
        self._is_learning = False
        logger.info("Continuous learning stopped")

    async def _learning_loop(self):
        """Main learning loop."""
        while self._is_learning:
            try:
                await self._process_episodes()
                await self._update_knowledge()
                await asyncio.sleep(self.config.get("learning_interval", 60))
            except Exception as e:
                logger.error(f"Learning error: {e}")
                await asyncio.sleep(10)

    async def record_episode(self, context: Dict, action: str, outcome: Dict, reward: float):
        """Record a learning episode."""
        episode = LearningEpisode(
            episode_id=f"ep:{datetime.now().isoformat()}",
            context=context,
            action=action,
            outcome=outcome,
            reward=reward,
            timestamp=datetime.now(),
        )

        async with self._lock:
            self._episodes.append(episode)

        logger.debug(f"Recorded episode: {episode.episode_id} (reward: {reward})")

    async def _process_episodes(self):
        """Process recorded episodes to extract learning."""
        async with self._lock:
            unlearned = [ep for ep in self._episodes if not ep.learned]

            if len(unlearned) < 10:
                return

            # Group by action
            action_groups = {}
            for ep in unlearned:
                if ep.action not in action_groups:
                    action_groups[ep.action] = []
                action_groups[ep.action].append(ep)

            # Calculate average reward per action
            for action, episodes in action_groups.items():
                avg_reward = sum(ep.reward for ep in episodes) / len(episodes)

                # Update knowledge about action effectiveness
                key = f"action_effectiveness:{action}"
                old_value = self._knowledge.get(key, 0.5)
                new_value = old_value + self._learning_rate * (avg_reward - old_value)

                self._knowledge[key] = new_value

                update = KnowledgeUpdate(
                    update_id=f"update:{key}:{datetime.now().isoformat()}",
                    category="action_effectiveness",
                    key=action,
                    old_value=old_value,
                    new_value=new_value,
                    confidence=min(1.0, len(episodes) / 100),
                    source="continuous_learning",
                    timestamp=datetime.now(),
                )

                self._updates.append(update)

                # Mark episodes as learned
                for ep in episodes:
                    ep.learned = True

            logger.info(f"Processed {len(unlearned)} episodes, updated {len(action_groups)} actions")

    async def _update_knowledge(self):
        """Update knowledge base with new learnings."""
        # Extract patterns from recent episodes
        async with self._lock:
            recent = list(self._episodes)[-100:]

            if len(recent) < 20:
                return

            # Find successful patterns
            successful = [ep for ep in recent if ep.reward > 0.7]

            for ep in successful:
                # Extract context features
                for key, value in ep.context.items():
                    knowledge_key = f"context_feature:{key}:{value}"

                    if knowledge_key not in self._knowledge:
                        self._knowledge[knowledge_key] = {"count": 0, "success_rate": 0.5}

                    self._knowledge[knowledge_key]["count"] += 1

                    # Update success rate
                    old_rate = self._knowledge[knowledge_key]["success_rate"]
                    self._knowledge[knowledge_key]["success_rate"] = (
                        old_rate + self._learning_rate * (ep.reward - old_rate)
                    )

    def get_knowledge(self, key: Optional[str] = None) -> Any:
        """Get knowledge from the learning system."""
        if key:
            return self._knowledge.get(key)
        return self._knowledge.copy()

    def get_best_action(self, context: Dict) -> Optional[str]:
        """Get the best action for a given context."""
        # Simple matching based on learned effectiveness
        best_action = None
        best_score = -1

        for action_key, effectiveness in self._knowledge.items():
            if action_key.startswith("action_effectiveness:"):
                action = action_key.split(":", 1)[1]

                if isinstance(effectiveness, (int, float)) and effectiveness > best_score:
                    best_score = effectiveness
                    best_action = action

        return best_action

    def get_stats(self) -> Dict[str, Any]:
        """Get learning system statistics."""
        return {
            "episodes_recorded": len(self._episodes),
            "knowledge_entries": len(self._knowledge),
            "updates_made": len(self._updates),
            "learning_rate": self._learning_rate,
            "is_learning": self._is_learning,
        }
