"""Self Learning Engine for Nexus Core V9."""

import asyncio
import logging
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field
from datetime import datetime
import json
import hashlib
from collections import defaultdict
import numpy as np

logger = logging.getLogger(__name__)


@dataclass
class LearningPattern:
    """Discovered pattern from system usage."""
    pattern_id: str
    pattern_type: str
    confidence: float
    frequency: int
    first_seen: datetime
    last_seen: datetime
    metadata: Dict[str, Any] = field(default_factory=dict)
    examples: List[Dict] = field(default_factory=list)


@dataclass
class ModelPerformance:
    """Performance metrics for a model/provider."""
    provider: str
    model: str
    avg_latency: float
    success_rate: float
    cost_per_1k: float
    quality_score: float
    sample_size: int


class SelfLearningEngine:
    """Learns from system usage to optimize decisions."""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._patterns: Dict[str, LearningPattern] = {}
        self._model_performance: Dict[str, ModelPerformance] = {}
        self._user_preferences: Dict[str, Any] = defaultdict(dict)
        self._interaction_history: List[Dict] = []
        self._learning_queue: asyncio.Queue = asyncio.Queue()
        self._is_running = False
        self._task: Optional[asyncio.Task] = None

    async def start(self):
        """Start the learning engine."""
        self._is_running = True
        self._task = asyncio.create_task(self._learning_loop())
        logger.info("SelfLearningEngine started")

    async def stop(self):
        """Stop the learning engine."""
        self._is_running = False
        if self._task:
            self._task.cancel()
        logger.info("SelfLearningEngine stopped")

    async def _learning_loop(self):
        """Main learning loop."""
        while self._is_running:
            try:
                data = await asyncio.wait_for(self._learning_queue.get(), timeout=5.0)
                await self._process_learning_data(data)
            except asyncio.TimeoutError:
                await self._periodic_analysis()
            except Exception as e:
                logger.error(f"Learning error: {e}")

    async def _process_learning_data(self, data: Dict):
        """Process incoming learning data."""
        data_type = data.get("type")

        if data_type == "interaction":
            await self._learn_from_interaction(data)
        elif data_type == "performance":
            await self._learn_from_performance(data)
        elif data_type == "feedback":
            await self._learn_from_feedback(data)
        elif data_type == "error":
            await self._learn_from_error(data)

    async def _learn_from_interaction(self, data: Dict):
        """Learn from user interactions."""
        self._interaction_history.append(data)

        # Extract patterns
        prompt_hash = hashlib.md5(data.get("prompt", "").encode()).hexdigest()[:16]

        if prompt_hash in self._patterns:
            pattern = self._patterns[prompt_hash]
            pattern.frequency += 1
            pattern.last_seen = datetime.now()
            pattern.confidence = min(1.0, pattern.confidence + 0.01)
        else:
            self._patterns[prompt_hash] = LearningPattern(
                pattern_id=prompt_hash,
                pattern_type="interaction",
                confidence=0.5,
                frequency=1,
                first_seen=datetime.now(),
                last_seen=datetime.now(),
                metadata={"prompt_length": len(data.get("prompt", ""))},
            )

        # Keep history manageable
        if len(self._interaction_history) > 10000:
            self._interaction_history = self._interaction_history[-5000:]

    async def _learn_from_performance(self, data: Dict):
        """Learn from performance metrics."""
        key = f"{data['provider']}:{data['model']}"

        if key in self._model_performance:
            existing = self._model_performance[key]
            n = existing.sample_size + 1
            existing.avg_latency = (existing.avg_latency * existing.sample_size + data["latency"]) / n
            existing.success_rate = (existing.success_rate * existing.sample_size + (1.0 if data["success"] else 0.0)) / n
            existing.cost_per_1k = (existing.cost_per_1k * existing.sample_size + data.get("cost", 0)) / n
            existing.sample_size = n
        else:
            self._model_performance[key] = ModelPerformance(
                provider=data["provider"],
                model=data["model"],
                avg_latency=data["latency"],
                success_rate=1.0 if data["success"] else 0.0,
                cost_per_1k=data.get("cost", 0),
                quality_score=data.get("quality", 0.8),
                sample_size=1,
            )

    async def _learn_from_feedback(self, data: Dict):
        """Learn from explicit feedback."""
        pattern_id = data.get("pattern_id")
        rating = data.get("rating", 0.5)

        if pattern_id and pattern_id in self._patterns:
            pattern = self._patterns[pattern_id]
            pattern.confidence = (pattern.confidence * 0.9) + (rating * 0.1)

    async def _learn_from_error(self, data: Dict):
        """Learn from errors."""
        error_type = data.get("error_type", "unknown")

        # Adjust model performance based on errors
        if "provider" in data and "model" in data:
            key = f"{data['provider']}:{data['model']}"
            if key in self._model_performance:
                self._model_performance[key].success_rate *= 0.95

    async def _periodic_analysis(self):
        """Periodic deep analysis."""
        if len(self._interaction_history) < 100:
            return

        # Analyze patterns
        await self._analyze_patterns()

        # Update model rankings
        await self._update_model_rankings()

        # Detect anomalies
        await self._detect_anomalies()

    async def _analyze_patterns(self):
        """Analyze discovered patterns."""
        # Find most frequent patterns
        sorted_patterns = sorted(
            self._patterns.values(),
            key=lambda p: p.frequency,
            reverse=True
        )

        top_patterns = sorted_patterns[:20]
        logger.info(f"Top 20 patterns analyzed: {len(top_patterns)} patterns")

    async def _update_model_rankings(self):
        """Update model rankings based on performance."""
        rankings = []
        for key, perf in self._model_performance.items():
            score = (
                perf.quality_score * 0.4 +
                (1.0 / (1.0 + perf.avg_latency / 1000)) * 0.3 +
                perf.success_rate * 0.2 +
                (1.0 / (1.0 + perf.cost_per_1k)) * 0.1
            )
            rankings.append((key, score, perf))

        rankings.sort(key=lambda x: x[1], reverse=True)
        logger.info(f"Model rankings updated: {len(rankings)} models ranked")

    async def _detect_anomalies(self):
        """Detect anomalous behavior."""
        if len(self._interaction_history) < 1000:
            return

        recent = self._interaction_history[-100:]
        latencies = [r.get("latency", 0) for r in recent]

        if latencies:
            mean_latency = np.mean(latencies)
            std_latency = np.std(latencies)

            for r in recent:
                if r.get("latency", 0) > mean_latency + 3 * std_latency:
                    logger.warning(f"Anomaly detected: latency spike in {r.get('provider', 'unknown')}")

    def submit_data(self, data: Dict):
        """Submit data for learning."""
        asyncio.create_task(self._learning_queue.put(data))

    def get_recommendations(self, context: Dict) -> List[Dict]:
        """Get recommendations based on learned patterns.""""
        recommendations = []

        # Recommend best model for context
        task_type = context.get("task_type", "general")

        # Filter models by task type
        suitable_models = [
            (k, p) for k, p in self._model_performance.items()
            if p.quality_score > 0.7 and p.success_rate > 0.9
        ]

        suitable_models.sort(key=lambda x: x[1].quality_score, reverse=True)

        for key, perf in suitable_models[:3]:
            recommendations.append({
                "type": "model",
                "provider": perf.provider,
                "model": perf.model,
                "confidence": perf.quality_score,
                "reason": f"High quality score ({perf.quality_score:.2f}) and reliability ({perf.success_rate:.2f})",
            })

        return recommendations

    def get_stats(self) -> Dict[str, Any]:
        """Get learning engine statistics."""
        return {
            "patterns_discovered": len(self._patterns),
            "models_tracked": len(self._model_performance),
            "interactions_recorded": len(self._interaction_history),
            "is_running": self._is_running,
        }
