"""Workflow Optimization Engine for Nexus Core V9."""

import asyncio
import logging
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field
from datetime import datetime
import json
from collections import defaultdict

logger = logging.getLogger(__name__)


@dataclass
class WorkflowStep:
    """A single step in a workflow."""
    step_id: str
    name: str
    action: str
    dependencies: List[str] = field(default_factory=list)
    estimated_duration: float = 1.0
    actual_duration: float = 0.0
    success: bool = True
    retry_count: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Workflow:
    """A complete workflow definition."""
    workflow_id: str
    name: str
    steps: List[WorkflowStep]
    parallel_groups: List[List[str]] = field(default_factory=list)
    total_executions: int = 0
    avg_duration: float = 0.0
    success_rate: float = 1.0
    created_at: datetime = field(default_factory=datetime.now)


@dataclass
class OptimizationResult:
    """Result of workflow optimization."""
    workflow_id: str
    improvements: List[str]
    estimated_speedup: float
    parallelization_gain: float
    bottleneck_removed: List[str]


class WorkflowOptimizationEngine:
    """Optimizes workflows through analysis and restructuring."""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._workflows: Dict[str, Workflow] = {}
        self._execution_history: Dict[str, List[Dict]] = defaultdict(list)
        self._step_performance: Dict[str, List[float]] = defaultdict(list)
        self._lock = asyncio.Lock()

    async def register_workflow(self, workflow: Workflow):
        """Register a workflow for optimization."""
        async with self._lock:
            self._workflows[workflow.workflow_id] = workflow
        logger.info(f"Registered workflow: {workflow.name} ({workflow.workflow_id})")

    async def record_execution(self, workflow_id: str, execution_data: Dict):
        """Record a workflow execution for analysis."""
        async with self._lock:
            if workflow_id not in self._workflows:
                return

            self._execution_history[workflow_id].append(execution_data)

            # Update step performance
            for step_data in execution_data.get("steps", []):
                step_id = step_data.get("step_id")
                duration = step_data.get("duration", 0)
                if step_id and duration > 0:
                    self._step_performance[step_id].append(duration)

            # Keep history manageable
            if len(self._execution_history[workflow_id]) > 1000:
                self._execution_history[workflow_id] = self._execution_history[workflow_id][-500:]

    async def optimize_workflow(self, workflow_id: str) -> Optional[OptimizationResult]:
        """Optimize a specific workflow."""
        async with self._lock:
            if workflow_id not in self._workflows:
                return None

            workflow = self._workflows[workflow_id]
            history = self._execution_history.get(workflow_id, [])

            if len(history) < 10:
                logger.info(f"Not enough history to optimize {workflow_id}")
                return None

            improvements = []
            bottlenecks = []

            # 1. Identify bottlenecks
            step_stats = self._analyze_step_performance(workflow)

            for step_id, stats in step_stats.items():
                if stats["avg_duration"] > stats["p95_duration"] * 0.8:
                    bottlenecks.append(step_id)
                    improvements.append(f"Bottleneck identified: {step_id} (avg: {stats['avg_duration']:.2f}s)")

            # 2. Find parallelization opportunities
            parallel_groups = self._find_parallel_groups(workflow)
            if parallel_groups != workflow.parallel_groups:
                improvements.append(f"Parallelization improved: {len(parallel_groups)} groups")

            # 3. Calculate estimated speedup
            original_duration = workflow.avg_duration
            optimized_duration = self._estimate_optimized_duration(workflow, step_stats, parallel_groups)
            speedup = original_duration / optimized_duration if optimized_duration > 0 else 1.0

            # 4. Update workflow
            workflow.parallel_groups = parallel_groups

            return OptimizationResult(
                workflow_id=workflow_id,
                improvements=improvements,
                estimated_speedup=speedup,
                parallelization_gain=len(parallel_groups) - len(workflow.parallel_groups),
                bottleneck_removed=bottlenecks,
            )

    def _analyze_step_performance(self, workflow: Workflow) -> Dict[str, Dict]:
        """Analyze performance of each step."""
        stats = {}

        for step in workflow.steps:
            durations = self._step_performance.get(step.step_id, [])
            if durations:
                import numpy as np
                stats[step.step_id] = {
                    "avg_duration": np.mean(durations),
                    "median_duration": np.median(durations),
                    "p95_duration": np.percentile(durations, 95),
                    "std_duration": np.std(durations),
                    "sample_size": len(durations),
                }
            else:
                stats[step.step_id] = {
                    "avg_duration": step.estimated_duration,
                    "median_duration": step.estimated_duration,
                    "p95_duration": step.estimated_duration * 2,
                    "std_duration": 0,
                    "sample_size": 0,
                }

        return stats

    def _find_parallel_groups(self, workflow: Workflow) -> List[List[str]]:
        """Find steps that can be executed in parallel."""
        # Build dependency graph
        dependencies = {step.step_id: set(step.dependencies) for step in workflow.steps}
        all_steps = set(step.step_id for step in workflow.steps)

        # Find parallel groups using topological levels
        remaining = all_steps.copy()
        groups = []

        while remaining:
            # Find steps with no remaining dependencies
            ready = {step_id for step_id in remaining if not (dependencies[step_id] & remaining)}

            if not ready:
                break

            groups.append(list(ready))
            remaining -= ready

        return groups

    def _estimate_optimized_duration(self, workflow: Workflow, step_stats: Dict, parallel_groups: List[List[str]]) -> float:
        """Estimate duration of optimized workflow."""
        total = 0.0

        for group in parallel_groups:
            group_duration = max(
                step_stats.get(step_id, {}).get("avg_duration", 1.0)
                for step_id in group
            )
            total += group_duration

        return total

    async def auto_optimize_all(self) -> List[OptimizationResult]:
        """Automatically optimize all workflows."""
        results = []

        for workflow_id in self._workflows:
            result = await self.optimize_workflow(workflow_id)
            if result and result.improvements:
                results.append(result)

        logger.info(f"Auto-optimized {len(results)} workflows")
        return results

    def get_stats(self) -> Dict[str, Any]:
        """Get optimization engine statistics."""
        return {
            "workflows_registered": len(self._workflows),
            "total_executions_recorded": sum(len(h) for h in self._execution_history.values()),
            "steps_tracked": len(self._step_performance),
        }
