"""Memory Evolution Layer for Nexus Core V9."""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
import hashlib
import json
from collections import OrderedDict

logger = logging.getLogger(__name__)


@dataclass
class MemoryEntry:
    """An evolved memory entry."""
    entry_id: str
    content: Any
    memory_type: str
    importance: float
    access_count: int
    created_at: datetime
    last_accessed: datetime
    associations: List[str] = field(default_factory=list)
    compression_level: int = 0
    evolution_history: List[Dict] = field(default_factory=list)


@dataclass
class MemoryPattern:
    """Pattern extracted from memory access."""
    pattern_id: str
    trigger: str
    related_entries: List[str] = field(default_factory=list)
    frequency: int = 0
    confidence: float = 0.5


class MemoryEvolutionLayer:
    """Evolves memory through compression, association, and pruning."""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._short_term: OrderedDict[str, MemoryEntry] = OrderedDict()
        self._long_term: Dict[str, MemoryEntry] = {}
        self._patterns: Dict[str, MemoryPattern] = {}
        self._max_short_term = config.get("max_short_term", 100)
        self._max_long_term = config.get("max_long_term", 10000)
        self._compression_threshold = config.get("compression_threshold", 0.8)
        self._lock = asyncio.Lock()

    async def store(self, content: Any, memory_type: str = "general", importance: float = 0.5) -> str:
        """Store a new memory entry."""
        entry_id = hashlib.md5(json.dumps(content, sort_keys=True, default=str).encode()).hexdigest()

        now = datetime.now()

        entry = MemoryEntry(
            entry_id=entry_id,
            content=content,
            memory_type=memory_type,
            importance=importance,
            access_count=0,
            created_at=now,
            last_accessed=now,
        )

        async with self._lock:
            # Store in short-term memory
            self._short_term[entry_id] = entry

            # Promote to long-term if important enough
            if importance > 0.7 or memory_type in ["critical", "learned"]:
                self._long_term[entry_id] = entry

            # Manage short-term memory size
            while len(self._short_term) > self._max_short_term:
                oldest = next(iter(self._short_term))
                del self._short_term[oldest]

            # Manage long-term memory size
            if len(self._long_term) > self._max_long_term:
                await self._compress_long_term()

        return entry_id

    async def retrieve(self, entry_id: str) -> Optional[MemoryEntry]:
        """Retrieve a memory entry by ID."""
        async with self._lock:
            # Check short-term first
            if entry_id in self._short_term:
                entry = self._short_term[entry_id]
                entry.access_count += 1
                entry.last_accessed = datetime.now()

                # Move to end (most recently used)
                self._short_term.move_to_end(entry_id)

                return entry

            # Check long-term
            if entry_id in self._long_term:
                entry = self._long_term[entry_id]
                entry.access_count += 1
                entry.last_accessed = datetime.now()

                # Promote to short-term
                self._short_term[entry_id] = entry

                return entry

            return None

    async def search(self, query: str, memory_type: Optional[str] = None) -> List[MemoryEntry]:
        """Search memory entries by content."""
        results = []
        query_lower = query.lower()

        async with self._lock:
            for entry in list(self._short_term.values()) + list(self._long_term.values()):
                if memory_type and entry.memory_type != memory_type:
                    continue

                content_str = json.dumps(entry.content, default=str).lower()

                if query_lower in content_str:
                    results.append(entry)

        # Sort by relevance (importance * access_count)
        results.sort(key=lambda e: e.importance * (1 + e.access_count), reverse=True)

        return results[:20]

    async def evolve(self):
        """Evolve memory through compression and association."""
        async with self._lock:
            # 1. Compress rarely accessed long-term memories
            for entry_id, entry in list(self._long_term.items()):
                if entry.access_count < 2 and entry.compression_level < 2:
                    entry.content = await self._compress_content(entry.content)
                    entry.compression_level += 1
                    entry.evolution_history.append({
                        "action": "compress",
                        "timestamp": datetime.now().isoformat(),
                        "level": entry.compression_level,
                    })

            # 2. Find associations between memories
            await self._find_associations()

            # 3. Prune obsolete memories
            await self._prune_memories()

    async def _compress_content(self, content: Any) -> Any:
        """Compress memory content."""
        if isinstance(content, dict):
            # Keep only important keys
            important_keys = [k for k in content.keys() if not k.startswith("_")]
            return {k: content[k] for k in important_keys[:10]}
        elif isinstance(content, list) and len(content) > 10:
            return content[:5] + [f"... ({len(content) - 5} more items)"]
        elif isinstance(content, str) and len(content) > 1000:
            return content[:500] + f"... ({len(content) - 500} chars truncated)"

        return content

    async def _find_associations(self):
        """Find associations between memory entries."""
        entries = list(self._long_term.values())

        for i, entry1 in enumerate(entries):
            for entry2 in entries[i+1:]:
                # Simple similarity check
                content1 = json.dumps(entry1.content, default=str)
                content2 = json.dumps(entry2.content, default=str)

                # Shared words
                words1 = set(content1.lower().split())
                words2 = set(content2.lower().split())

                if words1 and words2:
                    similarity = len(words1 & words2) / len(words1 | words2)

                    if similarity > 0.3:
                        if entry2.entry_id not in entry1.associations:
                            entry1.associations.append(entry2.entry_id)
                        if entry1.entry_id not in entry2.associations:
                            entry2.associations.append(entry1.entry_id)

    async def _prune_memories(self):
        """Prune old, low-importance memories."""
        now = datetime.now()

        to_remove = []
        for entry_id, entry in self._long_term.items():
            age_days = (now - entry.created_at).days

            # Remove if very old and low importance
            if age_days > 30 and entry.importance < 0.3 and entry.access_count < 3:
                to_remove.append(entry_id)

        for entry_id in to_remove[:100]:  # Limit pruning per cycle
            del self._long_term[entry_id]

        if to_remove:
            logger.info(f"Pruned {len(to_remove)} obsolete memories")

    async def _compress_long_term(self):
        """Compress long-term memory when it exceeds limits."""
        # Sort by importance * recency
        entries = sorted(
            self._long_term.values(),
            key=lambda e: e.importance * (1 + e.access_count) / (1 + (datetime.now() - e.last_accessed).days),
        )

        # Keep top entries, compress rest
        keep_count = int(self._max_long_term * 0.8)

        for entry in entries[keep_count:]:
            entry.content = await self._compress_content(entry.content)
            entry.compression_level += 1

    def get_stats(self) -> Dict[str, Any]:
        """Get memory statistics."""
        return {
            "short_term_entries": len(self._short_term),
            "long_term_entries": len(self._long_term),
            "total_patterns": len(self._patterns),
            "compression_threshold": self._compression_threshold,
        }
