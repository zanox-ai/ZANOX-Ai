"""API Schemas and Data Models for Nexus Core V9."""

from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum


class TaskStatus(Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class Priority(Enum):
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4


@dataclass
class EvolutionRequest:
    """Request to evolve a component."""
    component_id: str
    target_capabilities: List[str]
    priority: Priority = Priority.MEDIUM
    constraints: Dict[str, Any] = field(default_factory=dict)


@dataclass
class EvolutionResponse:
    """Response from an evolution request."""
    request_id: str
    status: TaskStatus
    new_genome_id: Optional[str] = None
    improvements: List[str] = field(default_factory=list)
    fitness_delta: float = 0.0
    estimated_completion: Optional[datetime] = None


@dataclass
class OptimizationRequest:
    """Request to optimize a workflow."""
    workflow_id: str
    optimization_type: str = "auto"
    constraints: Dict[str, Any] = field(default_factory=dict)


@dataclass
class OptimizationResponse:
    """Response from an optimization request."""
    request_id: str
    status: TaskStatus
    speedup_estimate: float = 1.0
    changes: List[str] = field(default_factory=list)
    risks: List[str] = field(default_factory=list)


@dataclass
class DiscoveryRequest:
    """Request to discover tools or connectors."""
    discovery_type: str  # "tools", "connectors", "apis"
    search_paths: List[str] = field(default_factory=list)
    filters: Dict[str, Any] = field(default_factory=dict)


@dataclass
class DiscoveryResponse:
    """Response from a discovery request."""
    request_id: str
    items_discovered: int
    items: List[Dict[str, Any]] = field(default_factory=list)
    confidence_scores: Dict[str, float] = field(default_factory=dict)


@dataclass
class HealthReport:
    """System health report."""
    report_id: str
    timestamp: datetime
    overall_status: str
    component_health: Dict[str, str] = field(default_factory=dict)
    metrics: Dict[str, float] = field(default_factory=dict)
    issues: List[str] = field(default_factory=list)
    recommendations: List[str] = field(default_factory=list)


@dataclass
class LearningReport:
    """Learning system report."""
    report_id: str
    timestamp: datetime
    episodes_processed: int
    knowledge_updates: int
    patterns_discovered: int
    model_rankings: Dict[str, float] = field(default_factory=dict)


@dataclass
class CostReport:
    """Cost analysis report."""
    report_id: str
    timestamp: datetime
    total_spend: float
    budget_remaining: float
    provider_breakdown: Dict[str, float] = field(default_factory=dict)
    optimizations: List[str] = field(default_factory=list)
    projections: Dict[str, float] = field(default_factory=dict)
