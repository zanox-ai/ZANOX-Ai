"""Self-Healing Infrastructure for Nexus Core V9."""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

logger = logging.getLogger(__name__)


class HealthStatus(Enum):
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    RECOVERING = "recovering"


@dataclass
class HealthCheck:
    """A health check result."""
    check_id: str
    component: str
    status: HealthStatus
    metric: float
    threshold: float
    message: str
    timestamp: datetime


@dataclass
class HealingAction:
    """A self-healing action."""
    action_id: str
    component: str
    action_type: str
    description: str
    success: bool
    timestamp: datetime
    error: Optional[str] = None


class SelfHealingInfrastructure:
    """Monitors system health and automatically heals issues."""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._health_checks: Dict[str, List[HealthCheck]] = {}
        self._healing_actions: List[HealingAction] = []
        self._components: Dict[str, Dict] = {}
        self._is_monitoring = False
        self._monitor_task: Optional[asyncio.Task] = None
        self._lock = asyncio.Lock()

    async def start(self):
        """Start self-healing monitoring."""
        self._is_monitoring = True
        self._monitor_task = asyncio.create_task(self._healing_loop())
        logger.info("Self-healing started")

    async def stop(self):
        """Stop self-healing monitoring."""
        self._is_monitoring = False
        if self._monitor_task:
            self._monitor_task.cancel()
        logger.info("Self-healing stopped")

    async def _healing_loop(self):
        """Main healing loop."""
        interval = self.config.get("check_interval", 10)

        while self._is_monitoring:
            try:
                await self._run_health_checks()
                await self._heal_issues()
                await asyncio.sleep(interval)
            except Exception as e:
                logger.error(f"Healing loop error: {e}")
                await asyncio.sleep(interval)

    async def register_component(self, component_id: str, check_func: callable, thresholds: Dict):
        """Register a component for health monitoring."""
        async with self._lock:
            self._components[component_id] = {
                "check_func": check_func,
                "thresholds": thresholds,
                "status": HealthStatus.HEALTHY,
            }
        logger.info(f"Registered component for healing: {component_id}")

    async def _run_health_checks(self):
        """Run health checks on all components."""
        for component_id, component in self._components.items():
            try:
                # Run check function
                metric = await component["check_func"]()

                # Determine status
                threshold = component["thresholds"].get("critical", 0.9)
                warning = component["thresholds"].get("warning", 0.7)

                if metric > threshold:
                    status = HealthStatus.UNHEALTHY
                elif metric > warning:
                    status = HealthStatus.DEGRADED
                else:
                    status = HealthStatus.HEALTHY

                check = HealthCheck(
                    check_id=f"check:{component_id}:{datetime.now().isoformat()}",
                    component=component_id,
                    status=status,
                    metric=metric,
                    threshold=threshold,
                    message=f"Health metric: {metric:.2f}",
                    timestamp=datetime.now(),
                )

                async with self._lock:
                    if component_id not in self._health_checks:
                        self._health_checks[component_id] = []
                    self._health_checks[component_id].append(check)

                    # Keep only recent checks
                    if len(self._health_checks[component_id]) > 100:
                        self._health_checks[component_id] = self._health_checks[component_id][-50:]

                    component["status"] = status

            except Exception as e:
                logger.error(f"Health check failed for {component_id}: {e}")

    async def _heal_issues(self):
        """Heal identified issues."""
        for component_id, checks in self._health_checks.items():
            if not checks:
                continue

            latest = checks[-1]

            if latest.status in [HealthStatus.UNHEALTHY, HealthStatus.DEGRADED]:
                await self._apply_healing(component_id, latest)

    async def _apply_healing(self, component_id: str, check: HealthCheck):
        """Apply healing to a component."""
        healing_strategies = {
            HealthStatus.DEGRADED: self._heal_degraded,
            HealthStatus.UNHEALTHY: self._heal_unhealthy,
        }

        strategy = healing_strategies.get(check.status)

        if strategy:
            success = await strategy(component_id, check)

            action = HealingAction(
                action_id=f"heal:{component_id}:{datetime.now().isoformat()}",
                component=component_id,
                action_type=check.status.value,
                description=f"Healed {component_id} from {check.status.value}",
                success=success,
                timestamp=datetime.now(),
            )

            async with self._lock:
                self._healing_actions.append(action)

    async def _heal_degraded(self, component_id: str, check: HealthCheck) -> bool:
        """Heal a degraded component."""
        logger.info(f"Applying degraded healing to {component_id}")
        # In a real system, this might restart services, clear caches, etc.
        return True

    async def _heal_unhealthy(self, component_id: str, check: HealthCheck) -> bool:
        """Heal an unhealthy component."""
        logger.warning(f"Applying critical healing to {component_id}")
        # In a real system, this might restart services, failover, etc.
        return True

    def get_component_health(self, component_id: str) -> Optional[Dict]:
        """Get health status of a component."""
        checks = self._health_checks.get(component_id, [])
        if not checks:
            return None

        latest = checks[-1]
        return {
            "component": component_id,
            "status": latest.status.value,
            "metric": latest.metric,
            "threshold": latest.threshold,
            "last_check": latest.timestamp.isoformat(),
        }

    def get_stats(self) -> Dict[str, Any]:
        """Get self-healing statistics."""
        healthy = sum(1 for c in self._components.values() if c.get("status") == HealthStatus.HEALTHY)
        degraded = sum(1 for c in self._components.values() if c.get("status") == HealthStatus.DEGRADED)
        unhealthy = sum(1 for c in self._components.values() if c.get("status") == HealthStatus.UNHEALTHY)

        return {
            "components_monitored": len(self._components),
            "healthy": healthy,
            "degraded": degraded,
            "unhealthy": unhealthy,
            "healing_actions": len(self._healing_actions),
            "is_monitoring": self._is_monitoring,
        }
