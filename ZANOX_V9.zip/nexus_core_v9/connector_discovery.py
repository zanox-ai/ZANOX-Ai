"""Automatic Connector Discovery for Nexus Core V9."""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
import socket
import urllib.parse

logger = logging.getLogger(__name__)


@dataclass
class DiscoveredConnector:
    """A discovered external service connector."""
    connector_id: str
    name: str
    protocol: str
    host: str
    port: int
    path: str
    auth_type: str
    capabilities: List[str] = field(default_factory=list)
    discovered_at: datetime = field(default_factory=datetime.now)
    health_status: str = "unknown"
    response_time_ms: float = 0.0
    confidence: float = 0.5


@dataclass
class ProtocolSignature:
    """Signature of a protocol."""
    protocol: str
    version: str
    features: List[str] = field(default_factory=list)
    auth_methods: List[str] = field(default_factory=list)


class AutomaticConnectorDiscovery:
    """Automatically discovers and tests external service connectors."""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._connectors: Dict[str, DiscoveredConnector] = {}
        self._protocols: Dict[str, ProtocolSignature] = {}
        self._scan_targets: List[str] = config.get("scan_targets", [])
        self._lock = asyncio.Lock()
        self._timeout = config.get("timeout", 5)

    async def scan_network(self, targets: Optional[List[str]] = None) -> List[DiscoveredConnector]:
        """Scan network targets for available services."""
        targets = targets or self._scan_targets
        discovered = []

        for target in targets:
            try:
                # Parse target
                parsed = urllib.parse.urlparse(target if "://" in target else f"http://{target}")
                host = parsed.hostname or target
                port = parsed.port or 80

                # Test connectivity
                result = await self._test_endpoint(host, port, parsed.path or "/")

                if result:
                    discovered.append(result)

                    async with self._lock:
                        self._connectors[result.connector_id] = result

            except Exception as e:
                logger.debug(f"Failed to scan {target}: {e}")

        logger.info(f"Discovered {len(discovered)} connectors from {len(targets)} targets")
        return discovered

    async def _test_endpoint(self, host: str, port: int, path: str) -> Optional[DiscoveredConnector]:
        """Test if an endpoint is reachable and identify it."""
        try:
            # Test TCP connection
            reader, writer = await asyncio.wait_for(
                asyncio.open_connection(host, port),
                timeout=self._timeout
            )

            start_time = asyncio.get_event_loop().time()

            # Send HTTP probe
            request = f"GET {path} HTTP/1.1\r\nHost: {host}\r\nConnection: close\r\n\r\n"
            writer.write(request.encode())
            await writer.drain()

            # Read response
            response = await asyncio.wait_for(reader.read(4096), timeout=self._timeout)
            response_time = (asyncio.get_event_loop().time() - start_time) * 1000

            writer.close()
            await writer.wait_closed()

            # Parse response
            response_str = response.decode('utf-8', errors='ignore')

            # Identify service type
            protocol = "http"
            capabilities = []
            auth_type = "none"

            if "OpenAPI" in response_str or "swagger" in response_str:
                capabilities.append("api")
                protocol = "openapi"
            elif "graphql" in response_str.lower():
                capabilities.append("query")
                protocol = "graphql"
            elif "grpc" in response_str.lower():
                capabilities.append("rpc")
                protocol = "grpc"

            if "401" in response_str or "Unauthorized" in response_str:
                auth_type = "required"
            elif "Bearer" in response_str:
                auth_type = "bearer"

            connector_id = f"{protocol}://{host}:{port}{path}"

            return DiscoveredConnector(
                connector_id=connector_id,
                name=f"{host}:{port}",
                protocol=protocol,
                host=host,
                port=port,
                path=path,
                auth_type=auth_type,
                capabilities=capabilities,
                health_status="healthy" if b"200" in response or b"401" in response else "degraded",
                response_time_ms=response_time,
                confidence=0.8 if capabilities else 0.4,
            )

        except asyncio.TimeoutError:
            return None
        except Exception as e:
            logger.debug(f"Endpoint test failed for {host}:{port}: {e}")
            return None

    async def discover_from_environment(self) -> List[DiscoveredConnector]:
        """Discover connectors from environment variables."""
        import os
        discovered = []

        # Common service env vars
        service_patterns = [
            ("API_URL", "api"),
            ("SERVICE_URL", "service"),
            ("DATABASE_URL", "database"),
            ("REDIS_URL", "cache"),
            ("KAFKA_URL", "messaging"),
            ("ELASTICSEARCH_URL", "search"),
        ]

        for pattern, service_type in service_patterns:
            for key, value in os.environ.items():
                if pattern in key and value:
                    try:
                        parsed = urllib.parse.urlparse(value)
                        connector_id = f"env:{key.lower()}"

                        connector = DiscoveredConnector(
                            connector_id=connector_id,
                            name=key,
                            protocol=parsed.scheme or "http",
                            host=parsed.hostname or "localhost",
                            port=parsed.port or 80,
                            path=parsed.path or "/",
                            auth_type="detected" if parsed.username else "none",
                            capabilities=[service_type],
                            confidence=0.9,
                        )

                        discovered.append(connector)

                        async with self._lock:
                            self._connectors[connector_id] = connector

                    except Exception as e:
                        logger.debug(f"Failed to parse env var {key}: {e}")

        logger.info(f"Discovered {len(discovered)} connectors from environment")
        return discovered

    async def health_check_all(self) -> Dict[str, str]:
        """Run health checks on all discovered connectors."""
        results = {}

        for connector_id, connector in self._connectors.items():
            try:
                result = await self._test_endpoint(connector.host, connector.port, connector.path)
                if result:
                    connector.health_status = result.health_status
                    connector.response_time_ms = result.response_time_ms
                    results[connector_id] = result.health_status
                else:
                    connector.health_status = "unhealthy"
                    results[connector_id] = "unhealthy"
            except Exception as e:
                connector.health_status = "error"
                results[connector_id] = f"error: {str(e)}"

        return results

    def get_connectors_by_capability(self, capability: str) -> List[DiscoveredConnector]:
        """Get connectors that support a specific capability."""
        return [
            c for c in self._connectors.values()
            if capability in c.capabilities
        ]

    def get_stats(self) -> Dict[str, Any]:
        """Get connector discovery statistics."""
        healthy = sum(1 for c in self._connectors.values() if c.health_status == "healthy")

        return {
            "connectors_discovered": len(self._connectors),
            "healthy_connectors": healthy,
            "scan_targets": len(self._scan_targets),
            "protocols_supported": len(self._protocols),
        }
