"""Agent Evolution System for Nexus Core V9."""

import asyncio
import logging
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field
from datetime import datetime
import uuid
import json
import copy

logger = logging.getLogger(__name__)


@dataclass
class AgentGene:
    """Genetic representation of an agent capability."""
    gene_id: str
    capability: str
    strength: float
    mutation_rate: float
    generation: int
    parent_genes: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class AgentGenome:
    """Complete genome of an agent."""
    genome_id: str
    agent_type: str
    genes: Dict[str, AgentGene]
    fitness_score: float
    generation: int
    created_at: datetime
    evolved_from: Optional[str] = None


@dataclass
class EvolutionResult:
    """Result of an evolution cycle."""
    new_genome: AgentGenome
    improvements: List[str]
    fitness_delta: float
    mutations_applied: int


class AgentEvolutionSystem:
    """Evolves agents through genetic algorithms."""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._population: Dict[str, AgentGenome] = {}
        self._fitness_history: Dict[str, List[float]] = {}
        self._evolution_count = 0
        self._lock = asyncio.Lock()
        self._selection_pressure = 0.7
        self._mutation_rate = 0.1
        self._crossover_rate = 0.6

    async def create_agent(self, agent_type: str, base_capabilities: List[str]) -> AgentGenome:
        """Create a new agent with initial genome."""
        genome_id = str(uuid.uuid4())
        genes = {}

        for cap in base_capabilities:
            gene = AgentGene(
                gene_id=str(uuid.uuid4()),
                capability=cap,
                strength=0.5,
                mutation_rate=self._mutation_rate,
                generation=0,
            )
            genes[cap] = gene

        genome = AgentGenome(
            genome_id=genome_id,
            agent_type=agent_type,
            genes=genes,
            fitness_score=0.5,
            generation=0,
            created_at=datetime.now(),
        )

        async with self._lock:
            self._population[genome_id] = genome
            self._fitness_history[genome_id] = [0.5]

        logger.info(f"Created agent {genome_id} of type {agent_type}")
        return genome

    async def evaluate_fitness(self, genome_id: str, metrics: Dict[str, float]) -> float:
        """Evaluate fitness of an agent."""
        async with self._lock:
            if genome_id not in self._population:
                return 0.0

            genome = self._population[genome_id]

            # Calculate fitness from metrics
            fitness = (
                metrics.get("task_success_rate", 0.5) * 0.3 +
                metrics.get("efficiency", 0.5) * 0.25 +
                metrics.get("accuracy", 0.5) * 0.25 +
                metrics.get("adaptability", 0.5) * 0.2
            )

            genome.fitness_score = fitness
            self._fitness_history[genome_id].append(fitness)

            # Keep history manageable
            if len(self._fitness_history[genome_id]) > 1000:
                self._fitness_history[genome_id] = self._fitness_history[genome_id][-500:]

            return fitness

    async def evolve_generation(self, agent_type: Optional[str] = None) -> List[EvolutionResult]:
        """Evolve a generation of agents."""
        async with self._lock:
            # Filter population
            candidates = [
                g for g in self._population.values()
                if agent_type is None or g.agent_type == agent_type
            ]

            if len(candidates) < 2:
                logger.warning("Not enough agents to evolve")
                return []

            # Sort by fitness
            candidates.sort(key=lambda g: g.fitness_score, reverse=True)

            # Select top performers
            survivors = candidates[:int(len(candidates) * self._selection_pressure)]

            results = []

            # Create offspring through crossover and mutation
            for i in range(0, len(survivors) - 1, 2):
                parent1 = survivors[i]
                parent2 = survivors[i + 1] if i + 1 < len(survivors) else survivors[0]

                result = await self._create_offspring(parent1, parent2)
                if result:
                    results.append(result)

            self._evolution_count += 1
            logger.info(f"Evolution cycle {self._evolution_count} complete: {len(results)} new agents")

            return results

    async def _create_offspring(self, parent1: AgentGenome, parent2: AgentGenome) -> Optional[EvolutionResult]:
        """Create offspring from two parents."""
        new_genome_id = str(uuid.uuid4())
        new_genes = {}
        improvements = []
        mutations = 0

        # Crossover: combine genes from both parents
        all_capabilities = set(parent1.genes.keys()) | set(parent2.genes.keys())

        for cap in all_capabilities:
            if cap in parent1.genes and cap in parent2.genes:
                # Average strength with slight bias toward better parent
                if parent1.fitness_score > parent2.fitness_score:
                    strength = parent1.genes[cap].strength * 0.6 + parent2.genes[cap].strength * 0.4
                else:
                    strength = parent1.genes[cap].strength * 0.4 + parent2.genes[cap].strength * 0.6
            elif cap in parent1.genes:
                strength = parent1.genes[cap].strength
            else:
                strength = parent2.genes[cap].strength

            # Mutation
            if np.random.random() < self._mutation_rate:
                mutation = np.random.normal(0, 0.1)
                strength = max(0.0, min(1.0, strength + mutation))
                mutations += 1
                improvements.append(f"Mutated {cap}: {strength:.3f}")

            new_genes[cap] = AgentGene(
                gene_id=str(uuid.uuid4()),
                capability=cap,
                strength=strength,
                mutation_rate=self._mutation_rate,
                generation=max(parent1.generation, parent2.generation) + 1,
                parent_genes=[parent1.genome_id, parent2.genome_id],
            )

        # Create new genome
        new_genome = AgentGenome(
            genome_id=new_genome_id,
            agent_type=parent1.agent_type,
            genes=new_genes,
            fitness_score=(parent1.fitness_score + parent2.fitness_score) / 2,
            generation=max(parent1.generation, parent2.generation) + 1,
            created_at=datetime.now(),
            evolved_from=f"{parent1.genome_id}+{parent2.genome_id}",
        )

        self._population[new_genome_id] = new_genome
        self._fitness_history[new_genome_id] = [new_genome.fitness_score]

        fitness_delta = new_genome.fitness_score - (parent1.fitness_score + parent2.fitness_score) / 2

        return EvolutionResult(
            new_genome=new_genome,
            improvements=improvements,
            fitness_delta=fitness_delta,
            mutations_applied=mutations,
        )

    async def mutate_agent(self, genome_id: str, target_capabilities: List[str]) -> Optional[EvolutionResult]:
        """Apply targeted mutation to an agent."""
        async with self._lock:
            if genome_id not in self._population:
                return None

            parent = self._population[genome_id]
            new_genes = copy.deepcopy(parent.genes)
            improvements = []
            mutations = 0

            for cap in target_capabilities:
                if cap in new_genes:
                    # Enhance existing capability
                    old_strength = new_genes[cap].strength
                    new_strength = min(1.0, old_strength + 0.15)
                    new_genes[cap].strength = new_strength
                    mutations += 1
                    improvements.append(f"Enhanced {cap}: {old_strength:.3f} -> {new_strength:.3f}")
                else:
                    # Add new capability
                    new_genes[cap] = AgentGene(
                        gene_id=str(uuid.uuid4()),
                        capability=cap,
                        strength=0.3,
                        mutation_rate=self._mutation_rate,
                        generation=parent.generation + 1,
                        parent_genes=[genome_id],
                    )
                    mutations += 1
                    improvements.append(f"Added {cap}: 0.300")

            new_genome = AgentGenome(
                genome_id=str(uuid.uuid4()),
                agent_type=parent.agent_type,
                genes=new_genes,
                fitness_score=parent.fitness_score * 0.9,
                generation=parent.generation + 1,
                created_at=datetime.now(),
                evolved_from=genome_id,
            )

            self._population[new_genome.genome_id] = new_genome
            self._fitness_history[new_genome.genome_id] = [new_genome.fitness_score]

            return EvolutionResult(
                new_genome=new_genome,
                improvements=improvements,
                fitness_delta=-0.1,
                mutations_applied=mutations,
            )

    def get_best_agent(self, agent_type: Optional[str] = None) -> Optional[AgentGenome]:
        """Get the best agent of a given type."""
        candidates = [
            g for g in self._population.values()
            if agent_type is None or g.agent_type == agent_type
        ]

        if not candidates:
            return None

        return max(candidates, key=lambda g: g.fitness_score)

    def get_stats(self) -> Dict[str, Any]:
        """Get evolution system statistics."""
        return {
            "population_size": len(self._population),
            "evolution_cycles": self._evolution_count,
            "mutation_rate": self._mutation_rate,
            "selection_pressure": self._selection_pressure,
            "average_fitness": np.mean([g.fitness_score for g in self._population.values()]) if self._population else 0,
            "best_fitness": max([g.fitness_score for g in self._population.values()]) if self._population else 0,
        }
