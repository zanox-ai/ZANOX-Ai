"""Autonomous Scaling Logic for Nexus Core V9."""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

logger = logging.getLogger(__name__)


class ScalingDirection(Enum):
    UP = "up"
    DOWN = "down"
    MAINTAIN = "maintain"


@dataclass
class ScalingDecision:
    """A scaling decision."""
    decision_id: str
    direction: ScalingDirection
    reason: str
    current_capacity: int
    target_capacity: int
    confidence: float
    timestamp: datetime


@dataclass
class CapacityMetrics:
    """Metrics for capacity planning."""
    metric_id: str
    load_factor: float
    queue_depth: int
    response_time_ms: float
    error_rate: float
    resource_utilization: float
    timestamp: datetime


class AutonomousScalingLogic:
    """Autonomously scales system capacity based on demand."""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._current_capacity = config.get("initial_capacity", 2)
        self._min_capacity = config.get("min_capacity", 1)
        self._max_capacity = config.get("max_capacity", 100)
        self._scale_up_threshold = config.get("scale_up_threshold", 0.8)
        self._scale_down_threshold = config.get("scale_down_threshold", 0.3)
        self._metrics_history: List[CapacityMetrics] = []
        self._decisions: List[ScalingDecision] = []
        self._is_scaling = False
        self._lock = asyncio.Lock()

    async def start(self):
        """Start autonomous scaling."""
        self._is_scaling = True
        asyncio.create_task(self._scaling_loop())
        logger.info(f"Autonomous scaling started (capacity: {self._current_capacity})")

    async def stop(self):
        """Stop autonomous scaling."""
        self._is_scaling = False
        logger.info("Autonomous scaling stopped")

    async def _scaling_loop(self):
        """Main scaling loop."""
        interval = self.config.get("check_interval", 30)

        while self._is_scaling:
            try:
                await self._evaluate_scaling()
                await asyncio.sleep(interval)
            except Exception as e:
                logger.error(f"Scaling error: {e}")
                await asyncio.sleep(interval)

    async def record_metrics(self, load_factor: float, queue_depth: int,
                            response_time_ms: float, error_rate: float,
                            resource_utilization: float):
        """Record capacity metrics."""
        metrics = CapacityMetrics(
            metric_id=f"metric:{datetime.now().isoformat()}",
            load_factor=load_factor,
            queue_depth=queue_depth,
            response_time_ms=response_time_ms,
            error_rate=error_rate,
            resource_utilization=resource_utilization,
            timestamp=datetime.now(),
        )

        async with self._lock:
            self._metrics_history.append(metrics)

            # Keep only recent metrics
            if len(self._metrics_history) > 1000:
                self._metrics_history = self._metrics_history[-500:]

    async def _evaluate_scaling(self):
        """Evaluate whether scaling is needed."""
        async with self._lock:
            if len(self._metrics_history) < 5:
                return

            # Calculate averages from recent metrics
            recent = self._metrics_history[-10:]
            avg_load = sum(m.load_factor for m in recent) / len(recent)
            avg_queue = sum(m.queue_depth for m in recent) / len(recent)
            avg_response = sum(m.response_time_ms for m in recent) / len(recent)
            avg_errors = sum(m.error_rate for m in recent) / len(recent)

            # Determine scaling direction
            direction = ScalingDirection.MAINTAIN
            reason = "Metrics within normal range"
            target = self._current_capacity

            # Scale up conditions
            if avg_load > self._scale_up_threshold:
                direction = ScalingDirection.UP
                reason = f"High load factor: {avg_load:.2f}"
                target = min(self._max_capacity, self._current_capacity + 1)
            elif avg_queue > self._current_capacity * 10:
                direction = ScalingDirection.UP
                reason = f"High queue depth: {avg_queue}"
                target = min(self._max_capacity, self._current_capacity + 2)
            elif avg_response > 5000:  # 5 seconds
                direction = ScalingDirection.UP
                reason = f"High response time: {avg_response:.0f}ms"
                target = min(self._max_capacity, self._current_capacity + 1)
            elif avg_errors > 0.1:  # 10% error rate
                direction = ScalingDirection.UP
                reason = f"High error rate: {avg_errors:.2f}"
                target = min(self._max_capacity, self._current_capacity + 1)

            # Scale down conditions
            elif avg_load < self._scale_down_threshold and avg_queue < 5:
                direction = ScalingDirection.DOWN
                reason = f"Low load factor: {avg_load:.2f}"
                target = max(self._min_capacity, self._current_capacity - 1)

            # Apply scaling if needed
            if direction != ScalingDirection.MAINTAIN and target != self._current_capacity:
                await self._apply_scaling(direction, target, reason)

    async def _apply_scaling(self, direction: ScalingDirection, target: int, reason: str):
        """Apply a scaling decision."""
        old_capacity = self._current_capacity
        self._current_capacity = target

        decision = ScalingDecision(
            decision_id=f"scale:{datetime.now().isoformat()}",
            direction=direction,
            reason=reason,
            current_capacity=old_capacity,
            target_capacity=target,
            confidence=0.8,
            timestamp=datetime.now(),
        )

        self._decisions.append(decision)

        logger.info(f"Scaled {direction.value}: {old_capacity} -> {target} ({reason})")

    async def manual_scale(self, target_capacity: int) -> bool:
        """Manually scale to a specific capacity."""
        if target_capacity < self._min_capacity or target_capacity > self._max_capacity:
            return False

        async with self._lock:
            old = self._current_capacity
            self._current_capacity = target_capacity

            decision = ScalingDecision(
                decision_id=f"manual:{datetime.now().isoformat()}",
                direction=ScalingDirection.UP if target_capacity > old else ScalingDirection.DOWN,
                reason="Manual scaling",
                current_capacity=old,
                target_capacity=target_capacity,
                confidence=1.0,
                timestamp=datetime.now(),
            )

            self._decisions.append(decision)

        logger.info(f"Manual scale: {old} -> {target_capacity}")
        return True

    def get_current_capacity(self) -> int:
        """Get current capacity."""
        return self._current_capacity

    def get_stats(self) -> Dict[str, Any]:
        """Get scaling statistics."""
        scale_up = sum(1 for d in self._decisions if d.direction == ScalingDirection.UP)
        scale_down = sum(1 for d in self._decisions if d.direction == ScalingDirection.DOWN)

        return {
            "current_capacity": self._current_capacity,
            "min_capacity": self._min_capacity,
            "max_capacity": self._max_capacity,
            "scale_up_count": scale_up,
            "scale_down_count": scale_down,
            "total_decisions": len(self._decisions),
            "is_scaling": self._is_scaling,
        }
