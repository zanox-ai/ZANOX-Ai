"""Performance Optimization System for Nexus Core V9."""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
import time
import psutil

logger = logging.getLogger(__name__)


@dataclass
class PerformanceMetric:
    """A performance metric snapshot."""
    metric_id: str
    category: str
    value: float
    unit: str
    timestamp: datetime
    threshold: float
    is_critical: bool = False


@dataclass
class OptimizationAction:
    """An optimization action taken."""
    action_id: str
    category: str
    action_type: str
    target: str
    before_value: float
    after_value: float
    improvement_pct: float
    timestamp: datetime


class PerformanceOptimizationSystem:
    """Monitors and optimizes system performance."""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._metrics: Dict[str, List[PerformanceMetric]] = {}
        self._actions: List[OptimizationAction] = []
        self._thresholds = config.get("thresholds", {
            "cpu_percent": 80.0,
            "memory_percent": 85.0,
            "disk_percent": 90.0,
            "latency_ms": 2000.0,
            "error_rate": 0.05,
        })
        self._is_monitoring = False
        self._monitor_task: Optional[asyncio.Task] = None
        self._lock = asyncio.Lock()

    async def start_monitoring(self):
        """Start performance monitoring."""
        self._is_monitoring = True
        self._monitor_task = asyncio.create_task(self._monitoring_loop())
        logger.info("Performance monitoring started")

    async def stop_monitoring(self):
        """Stop performance monitoring."""
        self._is_monitoring = False
        if self._monitor_task:
            self._monitor_task.cancel()
        logger.info("Performance monitoring stopped")

    async def _monitoring_loop(self):
        """Main monitoring loop."""
        interval = self.config.get("monitor_interval", 5.0)

        while self._is_monitoring:
            try:
                await self._collect_system_metrics()
                await self._check_thresholds()
                await asyncio.sleep(interval)
            except Exception as e:
                logger.error(f"Monitoring error: {e}")
                await asyncio.sleep(interval)

    async def _collect_system_metrics(self):
        """Collect system performance metrics."""
        now = datetime.now()

        # CPU
        cpu_percent = psutil.cpu_percent(interval=1)
        await self._record_metric("cpu", cpu_percent, "%", now)

        # Memory
        memory = psutil.virtual_memory()
        await self._record_metric("memory", memory.percent, "%", now)

        # Disk
        disk = psutil.disk_usage("/")
        disk_percent = (disk.used / disk.total) * 100
        await self._record_metric("disk", disk_percent, "%", now)

        # Network
        net_io = psutil.net_io_counters()
        await self._record_metric("network_sent", net_io.bytes_sent / 1024 / 1024, "MB", now)
        await self._record_metric("network_recv", net_io.bytes_recv / 1024 / 1024, "MB", now)

    async def _record_metric(self, category: str, value: float, unit: str, timestamp: datetime):
        """Record a performance metric."""
        metric = PerformanceMetric(
            metric_id=f"{category}:{timestamp.isoformat()}",
            category=category,
            value=value,
            unit=unit,
            timestamp=timestamp,
            threshold=self._thresholds.get(category, 100.0),
            is_critical=value > self._thresholds.get(category, 100.0),
        )

        async with self._lock:
            if category not in self._metrics:
                self._metrics[category] = []

            self._metrics[category].append(metric)

            # Keep only recent metrics
            if len(self._metrics[category]) > 1000:
                self._metrics[category] = self._metrics[category][-500:]

    async def _check_thresholds(self):
        """Check if any metrics exceed thresholds."""
        for category, metrics in self._metrics.items():
            if not metrics:
                continue

            latest = metrics[-1]

            if latest.is_critical:
                await self._apply_optimization(category, latest.value)

    async def _apply_optimization(self, category: str, current_value: float):
        """Apply optimization for a category."""
        before_value = current_value

        if category == "cpu":
            await self._optimize_cpu()
        elif category == "memory":
            await self._optimize_memory()
        elif category == "disk":
            await self._optimize_disk()
        elif category == "latency":
            await self._optimize_latency()

        # Measure improvement
        after_value = await self._get_current_value(category)

        if after_value < before_value:
            improvement = ((before_value - after_value) / before_value) * 100

            action = OptimizationAction(
                action_id=f"opt:{category}:{datetime.now().isoformat()}",
                category=category,
                action_type="auto_optimization",
                target=category,
                before_value=before_value,
                after_value=after_value,
                improvement_pct=improvement,
                timestamp=datetime.now(),
            )

            async with self._lock:
                self._actions.append(action)

            logger.info(f"Optimized {category}: {improvement:.1f}% improvement")

    async def _optimize_cpu(self):
        """Optimize CPU usage."""
        # In a real system, this might:
        # - Reduce worker threads
        # - Offload to background tasks
        # - Switch to lighter models
        logger.info("CPU optimization applied")

    async def _optimize_memory(self):
        """Optimize memory usage."""
        # Force garbage collection
        import gc
        gc.collect()
        logger.info("Memory optimization applied (GC)")

    async def _optimize_disk(self):
        """Optimize disk usage."""
        logger.info("Disk optimization applied")

    async def _optimize_latency(self):
        """Optimize latency."""
        logger.info("Latency optimization applied")

    async def _get_current_value(self, category: str) -> float:
        """Get current value for a category."""
        if category in self._metrics and self._metrics[category]:
            return self._metrics[category][-1].value
        return 0.0

    def record_custom_metric(self, category: str, value: float, unit: str = "ms"):
        """Record a custom performance metric."""
        asyncio.create_task(self._record_metric(category, value, unit, datetime.now()))

    def get_stats(self) -> Dict[str, Any]:
        """Get performance statistics."""
        return {
            "metrics_categories": len(self._metrics),
            "total_metrics": sum(len(m) for m in self._metrics.values()),
            "optimizations_applied": len(self._actions),
            "is_monitoring": self._is_monitoring,
            "thresholds": self._thresholds,
        }
