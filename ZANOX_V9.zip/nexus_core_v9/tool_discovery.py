"""Automatic Tool Discovery for Nexus Core V9."""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
import inspect
import importlib
import pkgutil

logger = logging.getLogger(__name__)


@dataclass
class DiscoveredTool:
    """A discovered tool with metadata."""
    tool_id: str
    name: str
    description: str
    module_path: str
    function_name: str
    parameters: List[Dict[str, Any]] = field(default_factory=list)
    return_type: str = "Any"
    capabilities: List[str] = field(default_factory=list)
    discovered_at: datetime = field(default_factory=datetime.now)
    confidence: float = 0.5


@dataclass
class ToolCapability:
    """Capability extracted from a tool."""
    capability_id: str
    name: str
    description: str
    required_tools: List[str] = field(default_factory=list)
    complexity_score: float = 0.5


class AutomaticToolDiscovery:
    """Automatically discovers and catalogs available tools."""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._discovered_tools: Dict[str, DiscoveredTool] = {}
        self._capabilities: Dict[str, ToolCapability] = {}
        self._search_paths: List[str] = config.get("search_paths", [])
        self._blacklist: List[str] = config.get("blacklist", [])
        self._lock = asyncio.Lock()

    async def scan_modules(self, package_paths: Optional[List[str]] = None) -> List[DiscoveredTool]:
        """Scan modules for callable functions."""
        paths = package_paths or self._search_paths
        discovered = []

        for path in paths:
            try:
                # Import module
                module = importlib.import_module(path)

                # Inspect all members
                for name, obj in inspect.getmembers(module):
                    if inspect.isfunction(obj) and not name.startswith("_"):
                        if name in self._blacklist:
                            continue

                        tool = await self._analyze_function(path, name, obj)
                        if tool:
                            discovered.append(tool)

                            async with self._lock:
                                self._discovered_tools[tool.tool_id] = tool

                # Recursively scan submodules
                if hasattr(module, "__path__"):
                    for importer, modname, ispkg in pkgutil.iter_modules(module.__path__):
                        full_name = f"{path}.{modname}"
                        sub_tools = await self.scan_modules([full_name])
                        discovered.extend(sub_tools)

            except Exception as e:
                logger.warning(f"Failed to scan {path}: {e}")

        logger.info(f"Discovered {len(discovered)} tools from {len(paths)} paths")
        return discovered

    async def _analyze_function(self, module_path: str, func_name: str, func) -> Optional[DiscoveredTool]:
        """Analyze a function to extract tool metadata."""
        try:
            sig = inspect.signature(func)
            doc = inspect.getdoc(func) or ""

            # Extract parameters
            parameters = []
            for param_name, param in sig.parameters.items():
                param_info = {
                    "name": param_name,
                    "type": str(param.annotation) if param.annotation != inspect.Parameter.empty else "Any",
                    "required": param.default == inspect.Parameter.empty,
                    "default": param.default if param.default != inspect.Parameter.empty else None,
                }
                parameters.append(param_info)

            # Determine return type
            return_type = str(sig.return_annotation) if sig.return_annotation != inspect.Signature.empty else "Any"

            # Extract capabilities from docstring
            capabilities = []
            keywords = ["search", "fetch", "parse", "transform", "analyze", "generate", "validate", "convert"]
            for keyword in keywords:
                if keyword.lower() in doc.lower():
                    capabilities.append(keyword)

            tool_id = f"{module_path}.{func_name}"

            return DiscoveredTool(
                tool_id=tool_id,
                name=func_name,
                description=doc[:200] if doc else f"Function {func_name}",
                module_path=module_path,
                function_name=func_name,
                parameters=parameters,
                return_type=return_type,
                capabilities=capabilities,
                confidence=0.7 if doc else 0.3,
            )

        except Exception as e:
            logger.debug(f"Failed to analyze {func_name}: {e}")
            return None

    async def discover_from_api(self, api_spec: Dict[str, Any]) -> List[DiscoveredTool]:
        """Discover tools from an API specification (OpenAPI, etc.)."""
        discovered = []

        paths = api_spec.get("paths", {})
        for path, methods in paths.items():
            for method, spec in methods.items():
                if method in ["get", "post", "put", "delete", "patch"]:
                    tool_id = f"api:{method}:{path}"

                    parameters = []
                    for param in spec.get("parameters", []):
                        parameters.append({
                            "name": param.get("name"),
                            "type": param.get("schema", {}).get("type", "string"),
                            "required": param.get("required", False),
                            "in": param.get("in", "query"),
                        })

                    tool = DiscoveredTool(
                        tool_id=tool_id,
                        name=spec.get("operationId", f"{method}_{path}"),
                        description=spec.get("summary", f"{method.upper()} {path}"),
                        module_path="api",
                        function_name=tool_id,
                        parameters=parameters,
                        return_type=spec.get("responses", {}).get("200", {}).get("content", {}).get("application/json", {}).get("schema", {}).get("type", "Any"),
                        capabilities=[method],
                        confidence=0.8,
                    )

                    discovered.append(tool)

                    async with self._lock:
                        self._discovered_tools[tool_id] = tool

        logger.info(f"Discovered {len(discovered)} tools from API spec")
        return discovered

    async def match_tools_to_task(self, task_description: str) -> List[DiscoveredTool]:
        """Match discovered tools to a task description."""
        matches = []

        # Simple keyword matching
        task_lower = task_description.lower()
        keywords = task_lower.split()

        for tool in self._discovered_tools.values():
            score = 0
            tool_text = f"{tool.name} {tool.description} {' '.join(tool.capabilities)}".lower()

            for keyword in keywords:
                if keyword in tool_text:
                    score += 1

            if score > 0:
                tool.confidence = min(1.0, score / len(keywords))
                matches.append(tool)

        matches.sort(key=lambda t: t.confidence, reverse=True)
        return matches[:10]

    def get_stats(self) -> Dict[str, Any]:
        """Get tool discovery statistics."""
        return {
            "tools_discovered": len(self._discovered_tools),
            "capabilities_extracted": len(self._capabilities),
            "search_paths": len(self._search_paths),
        }
