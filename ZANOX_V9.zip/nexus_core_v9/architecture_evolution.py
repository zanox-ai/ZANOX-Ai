"""Architecture Evolution Framework for Nexus Core V9."""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
import json

logger = logging.getLogger(__name__)


@dataclass
class ArchitectureComponent:
    """A component in the architecture."""
    component_id: str
    name: str
    component_type: str
    version: str
    dependencies: List[str] = field(default_factory=list)
    interfaces: List[str] = field(default_factory=list)
    health_score: float = 1.0
    evolution_count: int = 0


@dataclass
class ArchitectureEvolution:
    """An architecture evolution step."""
    evolution_id: str
    description: str
    components_added: List[str] = field(default_factory=list)
    components_removed: List[str] = field(default_factory=list)
    components_modified: List[str] = field(default_factory=list)
    breaking_changes: bool = False
    migration_guide: str = ""
    timestamp: datetime = field(default_factory=datetime.now)


class ArchitectureEvolutionFramework:
    """Manages evolution of system architecture."""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._components: Dict[str, ArchitectureComponent] = {}
        self._evolutions: List[ArchitectureEvolution] = []
        self._current_version = "1.0.0"
        self._lock = asyncio.Lock()

    async def register_component(self, component: ArchitectureComponent):
        """Register a new architecture component."""
        async with self._lock:
            self._components[component.component_id] = component
        logger.info(f"Registered component: {component.name} ({component.component_id})")

    async def evolve_component(self, component_id: str, changes: Dict[str, Any]) -> Optional[ArchitectureEvolution]:
        """Evolve a specific component."""
        async with self._lock:
            if component_id not in self._components:
                return None

            component = self._components[component_id]
            old_version = component.version

            # Apply changes
            if "version" in changes:
                component.version = changes["version"]
            if "dependencies" in changes:
                component.dependencies = changes["dependencies"]
            if "interfaces" in changes:
                component.interfaces = changes["interfaces"]

            component.evolution_count += 1
            component.health_score = changes.get("health_score", component.health_score)

            # Create evolution record
            evolution = ArchitectureEvolution(
                evolution_id=f"evo:{component_id}:{datetime.now().isoformat()}",
                description=f"Evolved {component.name} from {old_version} to {component.version}",
                components_modified=[component_id],
                breaking_changes=changes.get("breaking", False),
                migration_guide=changes.get("migration", ""),
            )

            self._evolutions.append(evolution)

            logger.info(f"Evolved component {component_id} to version {component.version}")
            return evolution

    async def propose_architecture_change(self, proposal: Dict[str, Any]) -> ArchitectureEvolution:
        """Propose and validate an architecture change."""
        # Validate proposal
        await self._validate_proposal(proposal)

        evolution = ArchitectureEvolution(
            evolution_id=f"proposal:{datetime.now().isoformat()}",
            description=proposal.get("description", "Architecture change"),
            components_added=proposal.get("add", []),
            components_removed=proposal.get("remove", []),
            components_modified=proposal.get("modify", []),
            breaking_changes=proposal.get("breaking", False),
            migration_guide=proposal.get("migration", "No migration needed"),
        )

        async with self._lock:
            self._evolutions.append(evolution)

        logger.info(f"Architecture change proposed: {evolution.description}")
        return evolution

    async def _validate_proposal(self, proposal: Dict[str, Any]):
        """Validate an architecture change proposal."""
        # Check for circular dependencies
        for comp_id in proposal.get("add", []) + proposal.get("modify", []):
            if comp_id in self._components:
                component = self._components[comp_id]
                deps = set(component.dependencies)

                for dep in deps:
                    if dep in self._components:
                        dep_component = self._components[dep]
                        if comp_id in dep_component.dependencies:
                            raise ValueError(f"Circular dependency detected: {comp_id} <-> {dep}")

        # Check for missing dependencies
        for comp_id in proposal.get("add", []):
            if comp_id not in self._components:
                continue
            component = self._components[comp_id]
            for dep in component.dependencies:
                if dep not in self._components:
                    raise ValueError(f"Missing dependency: {dep} for {comp_id}")

    async def get_architecture_graph(self) -> Dict[str, Any]:
        """Get the current architecture graph."""
        async with self._lock:
            return {
                "version": self._current_version,
                "components": {
                    comp_id: {
                        "name": comp.name,
                        "type": comp.component_type,
                        "version": comp.version,
                        "dependencies": comp.dependencies,
                        "interfaces": comp.interfaces,
                        "health": comp.health_score,
                    }
                    for comp_id, comp in self._components.items()
                },
                "evolution_count": len(self._evolutions),
            }

    async def rollback(self, evolution_id: str) -> bool:
        """Rollback to a previous evolution state."""
        # In a real system, this would restore previous state
        logger.info(f"Rollback requested for evolution: {evolution_id}")
        return True

    def get_stats(self) -> Dict[str, Any]:
        """Get architecture evolution statistics."""
        return {
            "components": len(self._components),
            "evolutions": len(self._evolutions),
            "current_version": self._current_version,
            "breaking_changes": sum(1 for e in self._evolutions if e.breaking_changes),
        }
