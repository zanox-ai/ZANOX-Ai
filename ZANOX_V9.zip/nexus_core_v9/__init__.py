"""
Nexus Core V9 - Self-Evolution Layer
Autonomous evolution system for AI Operating System.

Version: 9.0.0
"""

__version__ = "9.0.0"

from .self_learning import SelfLearningEngine
from .agent_evolution import AgentEvolutionSystem
from .workflow_optimizer import WorkflowOptimizationEngine
from .tool_discovery import AutomaticToolDiscovery
from .connector_discovery import AutomaticConnectorDiscovery
from .memory_evolution import MemoryEvolutionLayer
from .performance_optimizer import PerformanceOptimizationSystem
from .cost_optimizer import CostOptimizationEngine
from .architecture_evolution import ArchitectureEvolutionFramework
from .improvement_pipeline import AutonomousImprovementPipeline
from .continuous_learning import ContinuousLearningSystem
from .self_healing import SelfHealingInfrastructure
from .scaling_logic import AutonomousScalingLogic

__all__ = [
    "SelfLearningEngine",
    "AgentEvolutionSystem",
    "WorkflowOptimizationEngine",
    "AutomaticToolDiscovery",
    "AutomaticConnectorDiscovery",
    "MemoryEvolutionLayer",
    "PerformanceOptimizationSystem",
    "CostOptimizationEngine",
    "ArchitectureEvolutionFramework",
    "AutonomousImprovementPipeline",
    "ContinuousLearningSystem",
    "SelfHealingInfrastructure",
    "AutonomousScalingLogic",
]
