"""Cost Optimization Engine for Nexus Core V9."""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
from collections import defaultdict

logger = logging.getLogger(__name__)


@dataclass
class CostRecord:
    """A cost record."""
    record_id: str
    provider: str
    model: str
    operation: str
    input_tokens: int
    output_tokens: int
    cost_usd: float
    timestamp: datetime
    efficiency_score: float


@dataclass
class CostOptimization:
    """A cost optimization action."""
    optimization_id: str
    category: str
    description: str
    estimated_savings: float
    actual_savings: float
    applied_at: datetime


class CostOptimizationEngine:
    """Optimizes costs across all providers and operations."""

    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self._records: List[CostRecord] = []
        self._optimizations: List[CostOptimization] = []
        self._provider_costs: Dict[str, float] = defaultdict(float)
        self._model_costs: Dict[str, float] = defaultdict(float)
        self._daily_budget = config.get("daily_budget", 100.0)
        self._current_spend = 0.0
        self._last_reset = datetime.now()
        self._lock = asyncio.Lock()

    async def record_cost(self, provider: str, model: str, operation: str,
                          input_tokens: int, output_tokens: int, cost_usd: float):
        """Record a cost."""
        record = CostRecord(
            record_id=f"cost:{provider}:{model}:{datetime.now().isoformat()}",
            provider=provider,
            model=model,
            operation=operation,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cost_usd=cost_usd,
            timestamp=datetime.now(),
            efficiency_score=0.0,
        )

        async with self._lock:
            self._records.append(record)
            self._provider_costs[provider] += cost_usd
            self._model_costs[f"{provider}:{model}"] += cost_usd
            self._current_spend += cost_usd

            # Keep records manageable
            if len(self._records) > 10000:
                self._records = self._records[-5000:]

            # Check budget
            if self._current_spend > self._daily_budget:
                logger.warning(f"Daily budget exceeded: ${self._current_spend:.2f} / ${self._daily_budget:.2f}")

    async def optimize_costs(self) -> List[CostOptimization]:
        """Run cost optimization analysis."""
        optimizations = []

        async with self._lock:
            # 1. Find expensive models
            expensive_models = sorted(
                self._model_costs.items(),
                key=lambda x: x[1],
                reverse=True
            )[:5]

            for model_key, cost in expensive_models:
                if cost > self._daily_budget * 0.2:
                    opt = CostOptimization(
                        optimization_id=f"reduce:{model_key}",
                        category="model_selection",
                        description=f"Reduce usage of expensive model {model_key}",
                        estimated_savings=cost * 0.3,
                        actual_savings=0.0,
                        applied_at=datetime.now(),
                    )
                    optimizations.append(opt)

            # 2. Find inefficient operations
            operation_costs = defaultdict(float)
            for record in self._records[-1000:]:
                operation_costs[record.operation] += record.cost_usd

            for op, cost in operation_costs.items():
                if cost > self._daily_budget * 0.15:
                    opt = CostOptimization(
                        optimization_id=f"optimize:{op}",
                        category="operation",
                        description=f"Optimize {op} operations",
                        estimated_savings=cost * 0.25,
                        actual_savings=0.0,
                        applied_at=datetime.now(),
                    )
                    optimizations.append(opt)

        logger.info(f"Generated {len(optimizations)} cost optimizations")
        return optimizations

    async def get_cheapest_provider(self, task_type: str) -> Optional[str]:
        """Get the cheapest provider for a task type."""
        async with self._lock:
            # Calculate average cost per provider
            provider_avg = defaultdict(list)

            for record in self._records[-500:]:
                if record.operation == task_type or task_type == "general":
                    provider_avg[record.provider].append(record.cost_usd)

            if not provider_avg:
                return None

            # Find cheapest
            cheapest = min(
                provider_avg.items(),
                key=lambda x: sum(x[1]) / len(x[1])
            )

            return cheapest[0]

    async def get_cost_projection(self, days: int = 30) -> Dict[str, float]:
        """Project future costs."""
        async with self._lock:
            if not self._records:
                return {"projected": 0.0, "trend": "stable"}

            # Calculate daily average
            daily_spend = self._current_spend

            # Simple projection
            projected = daily_spend * days

            return {
                "projected": projected,
                "daily_average": daily_spend,
                "trend": "increasing" if len(self._records) > 100 and self._records[-1].cost_usd > self._records[-100].cost_usd else "stable",
            }

    def get_stats(self) -> Dict[str, Any]:
        """Get cost optimization statistics."""
        return {
            "total_records": len(self._records),
            "current_spend": self._current_spend,
            "daily_budget": self._daily_budget,
            "budget_utilization": (self._current_spend / self._daily_budget) * 100 if self._daily_budget > 0 else 0,
            "optimizations_generated": len(self._optimizations),
            "providers_tracked": len(self._provider_costs),
        }
